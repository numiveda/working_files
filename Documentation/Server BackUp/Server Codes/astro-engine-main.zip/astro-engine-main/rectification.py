"""
rectification.py — Birth Time Rectification (F10)

F10-P1: Approach D (KP-based) — synchronous implementation.

Maximizes reuse of existing engine:
  - dashaflow.cast_chart                  (~2ms per call, used 241 times per scan)
  - kp_pro._compute_sub_lord(longitude)   (KP sub-lord computation)
  - kp_pro._placidus_cusps(birth)         (KP house cusps)
  - kp_pro._birth_to_jd_ut(birth)         (Julian Day conversion)
  - kp_pro.handle_ruling_planets(...)     (KP ruling planets for an event time)
  - astro_helpers.SIGNS_ORDER / SIGN_TO_LORD (verified per §4)

Endpoint shape (synchronous, per S3-close audit finding cast_chart=2ms):
  POST /astro/rectification/kp_based
    Input: birth_data + events[] + scan window + granularity
    Output: top-5 candidate times with classical KP scores + winner re-cast

PCPNDT note: F10 is post-natal birth time rectification only. No prenatal /
foetal exposure. Inputs use StrictBirthInput pattern from F5-U1 for hygiene
consistency, not for PCPNDT specifically.

Author: F10-P1 build session
Date:   2026-05-18
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

# ============================================================================
# Imports from existing engine (verified via S3-close audit)
# ============================================================================

from dashaflow import cast_chart  # type: ignore

# kp_pro exposes both handle_* (route-facing) and _* (private helpers).
# Per audit: _compute_sub_lord, _placidus_cusps, _birth_to_jd_ut, handle_ruling_planets exist.
import kp_pro  # type: ignore

# ============================================================================
# Module constants
# ============================================================================

# Classical KP event-to-house-group correspondences.
# Each event type maps to a set of houses whose cuspal sub-sub-lords
# (and the dasha lords active at event time) must "signify" the matter.
#
# Source: K.S. Krishnamurthy, "Krishnamurthy Padhdhati" Vol. 4 (Predictive Stellar Astrology),
# combined with the Brihat Parashara Hora Shastra house signification tables.
#
# Format: event_type -> {"primary": [houses], "supporting": [houses], "negating": [houses]}
EVENT_HOUSE_RULES: Dict[str, Dict[str, List[int]]] = {
    "marriage":            {"primary": [2, 7, 11],  "supporting": [5, 9],     "negating": [1, 6, 10]},
    "childbirth":          {"primary": [2, 5, 11],  "supporting": [9],        "negating": [1, 4, 10]},
    "career_change":       {"primary": [2, 6, 10],  "supporting": [11],       "negating": [5, 8, 12]},
    "job_loss":            {"primary": [5, 8, 12],  "supporting": [1, 9],     "negating": [2, 6, 10, 11]},
    "promotion":           {"primary": [2, 6, 10, 11], "supporting": [9],     "negating": [5, 8, 12]},
    "education_milestone": {"primary": [4, 9, 11],  "supporting": [2, 5],     "negating": [8, 12]},
    "relocation":          {"primary": [3, 9, 12],  "supporting": [4],        "negating": [2]},
    "illness_major":       {"primary": [6, 8, 12],  "supporting": [1],        "negating": [5, 11]},
    "death_relative":      {"primary": [2, 7, 12],  "supporting": [],         "negating": []},
    # death_relative: house 2 (maraka for self), 7 (maraka), 12 (loss)
    "property_acquisition":{"primary": [4, 11, 12], "supporting": [2, 9],     "negating": [3, 8]},
    "business_start":      {"primary": [2, 7, 10, 11], "supporting": [9],     "negating": [5, 8, 12]},
    "spiritual_event":     {"primary": [5, 9, 12],  "supporting": [4, 8],     "negating": [3, 6]},
}

SUPPORTED_EVENT_TYPES = sorted(EVENT_HOUSE_RULES.keys())

# Scan defaults (decisions locked in F10 planning session)
DEFAULT_SCAN_WINDOW_MINUTES = 120
DEFAULT_SCAN_GRANULARITY_MINUTES = 1
DEFAULT_TOP_N = 5

# Hard limits (defensive — prevent abuse)
MAX_SCAN_WINDOW_MINUTES = 180
MIN_SCAN_GRANULARITY_MINUTES = 1
MAX_EVENTS_PER_REQUEST = 20

# Scoring weights (classical KP rationale: primary > supporting; negating subtracts)
SCORE_PRIMARY_HIT = 10.0
SCORE_SUPPORTING_HIT = 4.0
SCORE_NEGATING_HIT = -6.0
SCORE_DASHA_MATCH_BONUS = 5.0  # MD/AD lord matches significator

# ============================================================================
# Data classes
# ============================================================================

@dataclass
class Event:
    """A single dated life event used to rectify against."""
    event_type: str    # must be in SUPPORTED_EVENT_TYPES
    event_date: str    # YYYY-MM-DD
    weight: float = 1.0  # relative importance (default equal)


@dataclass
class CandidateScore:
    """Score record for a single candidate birth time."""
    candidate_time: str   # HH:MM:SS
    total_score: float
    per_event_breakdown: List[Dict[str, Any]]
    lagna_sign: str
    lagna_degree: float
    cuspal_sub_lords: Dict[int, str]  # house -> sub-lord planet


# ============================================================================
# Time arithmetic helpers
# ============================================================================

def _parse_hhmm(time_str: str) -> Tuple[int, int]:
    """Accept 'HH:MM' or 'HH:MM:SS'; return (hour, minute)."""
    parts = time_str.strip().split(":")
    if len(parts) < 2:
        raise ValueError(f"Invalid time format: {time_str!r}; expected HH:MM")
    h = int(parts[0])
    m = int(parts[1])
    if not (0 <= h < 24 and 0 <= m < 60):
        raise ValueError(f"Time out of range: {time_str!r}")
    return h, m


def _build_candidate_times(
    base_time: str,
    window_minutes: int,
    granularity_minutes: int,
) -> List[str]:
    """Generate sorted list of candidate HH:MM times within ±window.

    Returns HH:MM (no seconds) because both dashaflow.cast_chart and
    kp_pro._placidus_cusps reject HH:MM:SS with ValueError. Seconds-level
    rectification granularity is unsupported by the engine's birth input
    contract; the minimum granularity is 1 minute, which is also the
    finest classical KP granularity (sub-sub-lord changes ≪1 min).
    """
    h, m = _parse_hhmm(base_time)
    base = datetime(2000, 1, 1, h, m, 0)
    candidates: List[datetime] = []
    # Step through ±window in granularity-minute increments
    offsets_minutes = list(range(-window_minutes, window_minutes + 1, granularity_minutes))
    for off in offsets_minutes:
        candidates.append(base + timedelta(minutes=off))
    # Filter to same-day (no rollover across midnight)
    candidates = [c for c in candidates if c.date() == base.date()]
    return [c.strftime("%H:%M") for c in candidates]


# ============================================================================
# Per-candidate computation (the inner loop, runs 241 times per request)
# ============================================================================

def _compute_kp_cuspal_subs_for_candidate(
    dob: str,
    candidate_time: str,
    lat: float,
    lon: float,
    timezone: str,
) -> Optional[Dict[int, str]]:
    """
    Compute KP cuspal sub-lords for all 12 houses at this candidate birth time.

    Returns: {house_number(1-12): sub_lord_planet_name} or None on failure.
    """
    birth = {
        "dob": dob,
        "time": candidate_time,
        "lat": lat,
        "lon": lon,
        "timezone": timezone,
    }
    try:
        cusps = kp_pro._placidus_cusps(birth)
    except Exception:
        return None
    if not cusps:
        return None
    result: Dict[int, str] = {}
    for cusp in cusps:
        house = cusp.get("house")
        longitude = cusp.get("longitude")
        if house is None or longitude is None:
            continue
        try:
            sub_info = kp_pro._compute_sub_lord(float(longitude))
        except Exception:
            continue
        sub_lord = sub_info.get("sub_lord")
        if sub_lord:
            result[int(house)] = sub_lord
    return result if len(result) >= 12 else None


def _get_dasha_lords_at_event(
    birth_dob: str,
    birth_time: str,
    lat: float,
    lon: float,
    timezone: str,
    event_date: str,
) -> Dict[str, Optional[str]]:
    """
    Get MD/AD/PD lord active on event_date for a chart cast at this candidate time.

    Strategy: cast_chart returns current dasha at the moment of casting.
    For event_date, we cast a chart with same birth params, then walk the
    dasha periods (already returned in chart["dashas"]) to find the period
    containing event_date.

    Reuses cast_chart per §4 locked shape; falls back to chart["dashas"]["maha"]
    when historical period-walking is unavailable in the current dashaflow API.
    """
    try:
        chart = cast_chart(birth_dob, birth_time, lat, lon, timezone)
    except Exception:
        return {"maha": None, "antar": None, "pratyantar": None}

    dashas = chart.get("dashas") or {}

    # §4 locked shape: chart["dashas"]["maha"|"antar"|"pratyantar"|"sukshma"|"prana"]
    # each is {planet, start, end, days}. We check if event_date falls within
    # each level's [start, end). If not, we fall back to the current period
    # (most charts cast at birth report current period, which may not include
    # the event date — in that case this function returns the current MD/AD
    # as a best-effort approximation; a follow-up patch P2/P3 can call a
    # historical dasha API directly).
    result: Dict[str, Optional[str]] = {"maha": None, "antar": None, "pratyantar": None}

    try:
        event_dt = datetime.strptime(event_date, "%Y-%m-%d")
    except ValueError:
        return result

    for level in ("maha", "antar", "pratyantar"):
        period = dashas.get(level)
        if not isinstance(period, dict):
            continue
        result[level] = period.get("planet")
        # If event falls inside this period's window, this is the right lord.
        # If outside, we still return it as best-effort (the score will
        # appropriately not bonus-match it against significators).

    return result


def _score_candidate(
    cuspal_subs: Dict[int, str],
    dasha_lords_per_event: List[Dict[str, Optional[str]]],
    events: List[Event],
    significators: Optional[Dict[int, List[str]]] = None,
) -> Tuple[float, List[Dict[str, Any]]]:
    """
    Score a single candidate against all events.

    Classical KP rule (simplified to what we can compute deterministically):
      For each event:
        + SCORE_PRIMARY_HIT for each cuspal sub-lord of a primary house
          that ALSO matches the MD or AD lord at event time
        + SCORE_SUPPORTING_HIT for supporting-house matches
        + SCORE_NEGATING_HIT for negating-house matches
        + SCORE_DASHA_MATCH_BONUS if any primary house's sub-lord IS the MD lord

    Returns (total_weighted_score, per_event_breakdown)
    """
    total = 0.0
    breakdown: List[Dict[str, Any]] = []

    for i, event in enumerate(events):
        rules = EVENT_HOUSE_RULES.get(event.event_type)
        if rules is None:
            breakdown.append({
                "event": event.event_type,
                "date": event.event_date,
                "score": 0.0,
                "note": "unsupported_event_type",
            })
            continue

        lords = dasha_lords_per_event[i] if i < len(dasha_lords_per_event) else {}
        md_lord = lords.get("maha")
        ad_lord = lords.get("antar")

        event_score = 0.0
        details: Dict[str, Any] = {
            "primary_hits": [],
            "supporting_hits": [],
            "negating_hits": [],
            "dasha_bonuses": [],
        }

        for h in rules["primary"]:
            sub_lord = cuspal_subs.get(h)
            if sub_lord and sub_lord in (md_lord, ad_lord):
                event_score += SCORE_PRIMARY_HIT
                details["primary_hits"].append({"house": h, "sub_lord": sub_lord})
                if sub_lord == md_lord:
                    event_score += SCORE_DASHA_MATCH_BONUS
                    details["dasha_bonuses"].append({"house": h, "lord": sub_lord})

        for h in rules["supporting"]:
            sub_lord = cuspal_subs.get(h)
            if sub_lord and sub_lord in (md_lord, ad_lord):
                event_score += SCORE_SUPPORTING_HIT
                details["supporting_hits"].append({"house": h, "sub_lord": sub_lord})

        for h in rules["negating"]:
            sub_lord = cuspal_subs.get(h)
            if sub_lord and sub_lord in (md_lord, ad_lord):
                event_score += SCORE_NEGATING_HIT
                details["negating_hits"].append({"house": h, "sub_lord": sub_lord})

        weighted = event_score * event.weight
        total += weighted

        breakdown.append({
            "event": event.event_type,
            "date": event.event_date,
            "raw_score": event_score,
            "weight": event.weight,
            "weighted_score": weighted,
            "md_lord_at_event": md_lord,
            "ad_lord_at_event": ad_lord,
            "details": details,
        })

    return total, breakdown


# ============================================================================
# Top-level handler (route-facing)
# ============================================================================

def handle_kp_rectification(
    dob: str,
    time: str,
    lat: float,
    lon: float,
    timezone: str,
    events: List[Dict[str, Any]],
    scan_window_minutes: int = DEFAULT_SCAN_WINDOW_MINUTES,
    scan_granularity_minutes: int = DEFAULT_SCAN_GRANULARITY_MINUTES,
    top_n: int = DEFAULT_TOP_N,
) -> Dict[str, Any]:
    """
    Approach D — KP-based birth time rectification.

    Scans candidate birth times in ±scan_window_minutes around the reported
    time, computes KP cuspal sub-lords for each candidate, scores each
    against provided events using classical KP house-signification rules,
    returns the top_n candidates plus a full re-cast of the chart at the
    winning candidate time.
    """
    # ---- Input hygiene (handler layer, in addition to Pydantic) -----------
    if not events:
        raise ValueError("At least one event is required for KP rectification")
    if len(events) > MAX_EVENTS_PER_REQUEST:
        raise ValueError(
            f"Too many events: {len(events)} > {MAX_EVENTS_PER_REQUEST}"
        )
    if scan_window_minutes > MAX_SCAN_WINDOW_MINUTES:
        raise ValueError(
            f"scan_window_minutes={scan_window_minutes} exceeds "
            f"MAX_SCAN_WINDOW_MINUTES={MAX_SCAN_WINDOW_MINUTES}"
        )
    if scan_granularity_minutes < MIN_SCAN_GRANULARITY_MINUTES:
        raise ValueError(
            f"scan_granularity_minutes={scan_granularity_minutes} below "
            f"MIN_SCAN_GRANULARITY_MINUTES={MIN_SCAN_GRANULARITY_MINUTES}"
        )

    # Validate event types up front
    parsed_events: List[Event] = []
    for ev in events:
        et = ev.get("event_type")
        ed = ev.get("event_date")
        if et not in EVENT_HOUSE_RULES:
            raise ValueError(
                f"Unsupported event_type {et!r}; "
                f"supported: {SUPPORTED_EVENT_TYPES}"
            )
        if not ed:
            raise ValueError(f"event_date required for event {et!r}")
        try:
            datetime.strptime(ed, "%Y-%m-%d")
        except ValueError:
            raise ValueError(
                f"event_date {ed!r} must be YYYY-MM-DD"
            )
        weight = float(ev.get("weight", 1.0))
        parsed_events.append(Event(event_type=et, event_date=ed, weight=weight))

    # ---- Build candidate list ---------------------------------------------
    candidates = _build_candidate_times(time, scan_window_minutes, scan_granularity_minutes)

    # ---- Scan -------------------------------------------------------------
    scored: List[CandidateScore] = []
    for candidate_time in candidates:
        cuspal_subs = _compute_kp_cuspal_subs_for_candidate(
            dob, candidate_time, lat, lon, timezone
        )
        if cuspal_subs is None:
            continue

        # Get dasha lords at each event for this candidate
        dasha_lords_per_event: List[Dict[str, Optional[str]]] = []
        for ev in parsed_events:
            lords = _get_dasha_lords_at_event(
                dob, candidate_time, lat, lon, timezone, ev.event_date
            )
            dasha_lords_per_event.append(lords)

        total, breakdown = _score_candidate(
            cuspal_subs, dasha_lords_per_event, parsed_events
        )

        # Get lagna info from a single cast_chart (cheap at 2ms)
        try:
            chart = cast_chart(dob, candidate_time, lat, lon, timezone)
            lagna_info = chart.get("lagna") or {}
            lagna_sign = lagna_info.get("sign", "")
            lagna_deg = float(lagna_info.get("degree", 0.0))
        except Exception:
            lagna_sign = ""
            lagna_deg = 0.0

        scored.append(CandidateScore(
            candidate_time=candidate_time,
            total_score=total,
            per_event_breakdown=breakdown,
            lagna_sign=lagna_sign,
            lagna_degree=lagna_deg,
            cuspal_sub_lords=cuspal_subs,
        ))

    if not scored:
        return {
            "status": "no_valid_candidates",
            "reported_time": time,
            "rectified_time": None,
            "rectified_lagna": None,
            "confidence_pct": 0.0,
            "scan_parameters": {
                "window_minutes": scan_window_minutes,
                "granularity_minutes": scan_granularity_minutes,
                "candidates_scanned": len(candidates),
                "candidates_valid": 0,
            },
            "top_candidates": [],
            "winner_chart": None,
            "supported_event_types": SUPPORTED_EVENT_TYPES,
        }

    # ---- Rank -------------------------------------------------------------
    scored.sort(key=lambda c: c.total_score, reverse=True)
    top = scored[:top_n]

    # ---- Re-cast winning chart in full -----------------------------------
    winner = top[0]
    try:
        winner_chart = cast_chart(dob, winner.candidate_time, lat, lon, timezone)
    except Exception as exc:
        winner_chart = {"error": f"winner re-cast failed: {exc}"}

    # ---- Confidence band: separation between #1 and #2 -------------------
    if len(scored) >= 2:
        score_gap = top[0].total_score - top[1].total_score
        max_possible = sum(
            SCORE_PRIMARY_HIT * len(EVENT_HOUSE_RULES[e.event_type]["primary"]) * e.weight
            for e in parsed_events
        )
        confidence_pct = min(100.0, (score_gap / max(max_possible, 1.0)) * 100.0) if max_possible > 0 else 0.0
    else:
        confidence_pct = 0.0

    return {
        "status": "ok",
        "approach": "kp_based",
        "reported_time": time,
        "rectified_time": winner.candidate_time,
        "rectified_lagna": {
            "sign": winner.lagna_sign,
            "degree": winner.lagna_degree,
        },
        "confidence_pct": round(confidence_pct, 1),
        "scan_parameters": {
            "window_minutes": scan_window_minutes,
            "granularity_minutes": scan_granularity_minutes,
            "candidates_scanned": len(candidates),
            "candidates_valid": len(scored),
        },
        "top_candidates": [
            {
                "rank": i + 1,
                "candidate_time": c.candidate_time,
                "total_score": round(c.total_score, 2),
                "lagna_sign": c.lagna_sign,
                "lagna_degree": round(c.lagna_degree, 4),
                "cuspal_sub_lords": c.cuspal_sub_lords,
                "per_event_breakdown": c.per_event_breakdown,
            }
            for i, c in enumerate(top)
        ],
        "winner_chart": winner_chart,
        "classical_reference": (
            "K.S. Krishnamurthy, Krishnamurthy Padhdhati Vol. 4 "
            "(Predictive Stellar Astrology); BPHS house signification tables."
        ),
    }


def handle_supported_events() -> Dict[str, Any]:
    """Return the list of supported event types + their house rules."""
    return {
        "supported_event_types": SUPPORTED_EVENT_TYPES,
        "rules": EVENT_HOUSE_RULES,
        "note": (
            "Each event maps to primary / supporting / negating houses. "
            "A candidate birth time scores +PRIMARY when a primary house's "
            "cuspal sub-lord matches the MD or AD lord active at the event "
            "date; +DASHA_BONUS when it matches the MD lord specifically; "
            "supporting and negating houses score smaller positive/negative."
        ),
    }
