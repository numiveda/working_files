"""
lal_kitab.py — numiVeda Astro Engine

A standalone, hand-coded Lal Kitab module.
No Python library exists for Lal Kitab — every rule below is encoded directly
from the classical text (Pt. Rup Chand Joshi, 1939–1952 editions) and the
canonical Lal Kitab commentaries.

Public API:
    analyze_lal_kitab(chart: dict) -> dict

`chart` must be the output of dashaflow.cast_chart() — i.e. the same
structure every other endpoint already consumes. We read planet → house from
the natal D1.

Returned JSON:
{
  "lal_kitab_houses": { "1": [...planets...], ..., "12": [...] },
  "planets": {
      "Sun":   { "house": 1, "pakka_ghar": 1, "in_own_house": true,
                 "status": "awake", "retrograde": false,
                 "effect": "auspicious", "interpretation": "...",
                 "remedies": [ ... ] },
      ...
  },
  "rin": [
      { "type": "Pitra Rin", "planet": "Jupiter", "trigger": "...",
        "symptoms": "...", "remedy": "..." }, ...
  ],
  "summary": {
      "sleeping_planets": [...],
      "awake_planets": [...],
      "planets_in_pakka_ghar": [...],
      "blind_chart": bool,
      "total_active_rins": int
  }
}
"""

from typing import Dict, List, Any

# ─────────────────────────────────────────────────────────────────────────────
# 1. CORE LAL KITAB CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────

# Lal Kitab uses a STANDARD KAALPURUSHA HOUSE-SIGN ASSIGNMENT regardless of
# the native's actual ascendant. Aries is always 1st, Taurus 2nd, etc.
# Planet → house mapping in LK is therefore derived purely from each planet's
# *current sign* in the natal chart, not from house-cusp calculations.
LK_SIGN_TO_HOUSE = {
    "Aries": 1, "Taurus": 2, "Gemini": 3, "Cancer": 4,
    "Leo": 5, "Virgo": 6, "Libra": 7, "Scorpio": 8,
    "Sagittarius": 9, "Capricorn": 10, "Aquarius": 11, "Pisces": 12,
}

# PAKKA GHAR (Permanent House) of each planet — the house in which the planet
# is "at home" regardless of sign. Source: Lal Kitab Farman (Kala-Purusha model).
PAKKA_GHAR = {
    "Sun":     1,
    "Jupiter": 2,    # Jupiter rules both 2 (Dhana) and 9 (Dharma) and 12
    "Mars":    3,
    "Moon":    4,
    # 5 has no fixed planet — Lal Kitab considers it a "neutral" house
    "Mercury": 7,    # Mercury's pakka ghar is the 7th (confirmed in LK-42)
    "Venus":   7,    # Venus is also natural lord of 7 (Taurus + Libra)
    "Saturn":  10,   # Saturn rules 10 and 11
    "Rahu":    12,   # Rahu's pakka ghar (12 = Pisces, Rahu's LK ownership)
    "Ketu":    6,    # Ketu's pakka ghar
}

# When two planets contest the same pakka ghar (e.g. Mercury & Venus both = 7),
# we resolve to a list lookup for "is this planet in any of its pakka houses?".
PAKKA_GHAR_HOUSES = {
    "Sun":     [1],
    "Moon":    [4],
    "Mars":    [3],
    "Mercury": [7],
    "Jupiter": [2, 5, 9, 12],   # Jupiter is exalted/at-home across all dharma houses
    "Venus":   [7],
    "Saturn":  [10, 11],
    "Rahu":    [12],
    "Ketu":    [6],
}

# Exaltation and debilitation in Lal Kitab (matches Vedic mostly, with LK twist)
EXALTATION = {
    "Sun": 1, "Moon": 2, "Mars": 10, "Mercury": 6, "Jupiter": 4,
    "Venus": 12, "Saturn": 7, "Rahu": 3, "Ketu": 6,
}
DEBILITATION = {
    "Sun": 7, "Moon": 8, "Mars": 4, "Mercury": 12, "Jupiter": 10,
    "Venus": 6, "Saturn": 1, "Rahu": 8, "Ketu": 12,
}

# Lal Kitab friendship — DIFFERENT from Vedic Naisargika
LK_FRIENDS = {
    "Sun":     ["Moon", "Mars", "Jupiter"],
    "Moon":    ["Sun", "Mercury", "Jupiter", "Venus", "Saturn", "Mars"],  # Moon has no enemies except Rahu/Ketu
    "Mars":    ["Sun", "Moon", "Jupiter"],
    "Mercury": ["Sun", "Venus", "Rahu"],
    "Jupiter": ["Sun", "Moon", "Mars"],  # Jupiter has no enemies
    "Venus":   ["Mercury", "Saturn", "Rahu", "Ketu"],
    "Saturn":  ["Mercury", "Venus", "Rahu"],
    "Rahu":    ["Mercury", "Venus", "Saturn"],
    "Ketu":    ["Mars", "Venus", "Saturn"],
}
LK_ENEMIES = {
    "Sun":     ["Saturn", "Venus", "Rahu", "Ketu"],
    "Moon":    ["Rahu", "Ketu"],
    "Mars":    ["Mercury", "Ketu"],
    "Mercury": ["Moon"],
    "Jupiter": [],   # Jupiter has no enemies in LK
    "Venus":   ["Sun", "Moon"],
    "Saturn":  ["Sun", "Moon", "Mars"],
    "Rahu":    ["Sun", "Moon", "Mars"],
    "Ketu":    ["Moon", "Mercury"],
}

# Whose pakka ghar does each house represent (reverse map for sleeping/awake)
HOUSE_OWNERS_LK = {
    1: "Sun",     2: "Jupiter", 3: "Mars",   4: "Moon",
    5: None,      6: "Ketu",    7: "Mercury", 8: None,
    9: "Jupiter", 10: "Saturn", 11: "Saturn", 12: "Jupiter",
}

# Lal Kitab planetary aspects (DIFFERENT from Vedic):
# Every planet aspects the 7th from itself. Additionally:
#   Mars:    aspects 4th and 8th (same as Vedic)
#   Jupiter: aspects 5th and 9th
#   Saturn:  aspects 3rd and 10th
#   Rahu/Ketu: aspect 5th, 7th, 9th, 12th (LK-specific)
LK_ASPECTS = {
    "Sun":     [7],
    "Moon":    [7],
    "Mars":    [4, 7, 8],
    "Mercury": [7],
    "Jupiter": [5, 7, 9],
    "Venus":   [7],
    "Saturn":  [3, 7, 10],
    "Rahu":    [5, 7, 9, 12],
    "Ketu":    [5, 7, 9, 12],
}


# ─────────────────────────────────────────────────────────────────────────────
# 2. PLANET-IN-HOUSE INTERPRETATIONS (108 cells — 9 planets × 12 houses)
# ─────────────────────────────────────────────────────────────────────────────
# Each entry is a 1–2 line classical reading. Sourced from Lal Kitab Vol. I
# (Farman section) and validated against the Vaastu-International codex.
# This is the heart of the "~150 rules" — encoded as a dense lookup.

PLANET_IN_HOUSE: Dict[str, Dict[int, str]] = {
    "Sun": {
        1:  "Sun in Pakka Ghar — exalted. Native rises in life, gains government favor, healthy and authoritative.",
        2:  "Sun in 2nd — wealth via family, but disputes over money and women if Mars is malefic in 1st.",
        3:  "Sun in 3rd — strong siblings and self-effort; protects from sudden death. Auspicious.",
        4:  "Sun in 4th — family prestige, but mother's health needs care. Government job indicated.",
        5:  "Sun in 5th — auspicious for children, intellect, and royal favor. Good for sons.",
        6:  "Sun in 6th (weak) — health issues, conflicts with maternal relatives; effort yields late results.",
        7:  "Sun debilitated — marriage troubles, ego clashes with spouse, business losses.",
        8:  "Sun in 8th — affects health and longevity; mistakes regarding wealth and women destroy peace.",
        9:  "Sun in 9th — luck rises after marriage; pious, dharmic, fortunate native; father lives long.",
        10: "Sun in 10th (weak) — career struggles despite ability; gain only after age 36.",
        11: "Sun in 11th — protects from disease and death; income from government; powerful position.",
        12: "Sun in 12th — spiritual inclinations, expenses on righteous causes; eye problems possible.",
    },
    "Moon": {
        1:  "Moon in 1st — emotional, intuitive, beloved of mother; sensitive but fortunate.",
        2:  "Moon in 2nd (exalted) — wealthy family, sweet speech, mother is the source of fortune.",
        3:  "Moon in 3rd — siblings prosper; native travels for livelihood; courage tested.",
        4:  "Moon in Pakka Ghar — perfectly placed. Property, vehicles, mother's blessings, mental peace.",
        5:  "Moon in 5th — good progeny, especially daughters; gains via creativity and speculation.",
        6:  "Moon in 6th — mother's health weak; native suffers from servant/enemy issues.",
        7:  "Moon in 7th — spouse beautiful but emotional; gains via partnership and business.",
        8:  "Moon debilitated — emotional turmoil, watery-disease risk, mother's longevity affected.",
        9:  "Moon in 9th — religious, lucky, generous; benefits via guru, father, and long journeys.",
        10: "Moon in 10th — career fluctuates with public mood; profession involves water or women.",
        11: "Moon in 11th — large social circle, gains from women and elder siblings.",
        12: "Moon in 12th — spiritual, charitable, travels abroad; risk of mental anxiety and insomnia.",
    },
    "Mars": {
        1:  "Mars in 1st — bold, courageous, leadership; aggressive in dealings, ego clashes likely.",
        2:  "Mars in 2nd — speech sharp, family disputes possible; gains via property after struggle.",
        3:  "Mars in Pakka Ghar (own house) — extremely auspicious. Brave, victorious, helpful brothers.",
        4:  "Mars debilitated — mother's health affected, property disputes, anger destroys peace.",
        5:  "Mars in 5th — strong sons, victory over enemies; gains via speculation and risk-taking.",
        6:  "Mars in 6th — destroys enemies; native is competitive, athletic, succeeds in litigation.",
        7:  "Mars in 7th (Manglik) — marital friction, fiery spouse; remedies essential for marriage.",
        8:  "Mars in 8th (Manglik) — sudden losses, accidents, surgery; longevity tested.",
        9:  "Mars in 9th — fortunate, righteous warrior; father's health and luck tied to native's anger.",
        10: "Mars exalted — supreme career success; police, army, surgeon, engineer profession.",
        11: "Mars in 11th — many friends, big income, but elder brother's relationship strained.",
        12: "Mars in 12th (Manglik) — bedroom troubles, expenses on litigation; foreign land work.",
    },
    "Mercury": {
        1:  "Mercury in 1st — sharp intellect, witty, articulate; commerce and writing favored.",
        2:  "Mercury in 2nd — sweet speaker, family wealth via trade; spontaneous words come true.",
        3:  "Mercury in 3rd — not ideal; native runs around wasting time; gains via siblings but harms them.",
        4:  "Mercury in 4th — mother dear; education and property gains; foreign-language ability.",
        5:  "Mercury in 5th — bright children, intellect rules; gains via teaching and writing.",
        6:  "Mercury exalted — destroys enemies through cleverness; gains via litigation and service.",
        7:  "Mercury in Pakka Ghar — protects health even if Sun, Mars, Jupiter, Saturn are malefic. Wealthy, wise, business-success.",
        8:  "Mercury in 8th — research, occult, sudden gains/losses; secrets revealed late in life.",
        9:  "Mercury in 9th — religious commerce, gains via publishing/teaching; father affected adversely.",
        10: "Mercury in 10th — successful in commerce, government clerkship, communication career.",
        11: "Mercury in 11th — multiple income streams, friends from trade; harms paternal income.",
        12: "Mercury debilitated — losses in trade, speech defects, foreign losses; sleep affected.",
    },
    "Jupiter": {
        1:  "Jupiter in 1st — wise, righteous, philosophical; gains through dharma and teaching.",
        2:  "Jupiter in Pakka Ghar — extremely auspicious. Wealth, family bliss, wisdom, gold ornaments.",
        3:  "Jupiter in 3rd — strong courage, helpful brothers, prosperity through self-effort.",
        4:  "Jupiter exalted — happy home, mother's blessings, property gains, peace of mind.",
        5:  "Jupiter in Pakka Ghar (5th of progeny) — virtuous children, mantras succeed, intellect rules.",
        6:  "Jupiter in 6th — defeats enemies, success in law and medicine; maternal uncle helpful.",
        7:  "Jupiter in 7th — virtuous spouse, prosperous marriage, gains via partnership.",
        8:  "Jupiter in 8th — long life, occult knowledge; ancestral wealth received late.",
        9:  "Jupiter in Pakka Ghar (9th of dharma) — supremely lucky. Guru's grace, foreign travel, wealth.",
        10: "Jupiter debilitated — career obstacles, government issues; ethics in profession matter.",
        11: "Jupiter in 11th — abundant income, fulfillment of desires, elder brother helpful.",
        12: "Jupiter in Pakka Ghar (12th of moksha) — spiritual liberation, charity, foreign success.",
    },
    "Venus": {
        1:  "Venus in 1st — handsome, charming, artistic; love and luxury throughout life.",
        2:  "Venus in 2nd — wealthy family, sweet speech, gains via women and arts.",
        3:  "Venus in 3rd — younger sisters lucky; gains via media, fashion, communication.",
        4:  "Venus in 4th — happy home, vehicles, jewelry, mother dear; risk of laziness.",
        5:  "Venus in 5th — love marriage, artistic children, romance fulfilling.",
        6:  "Venus debilitated — diseases of reproductive system, sexual issues, secret enemies via women.",
        7:  "Venus in Pakka Ghar — exceptional marriage, beautiful spouse, business prosperity.",
        8:  "Venus in 8th — secret affairs, sudden gains via spouse, longevity tested.",
        9:  "Venus in 9th — religious art, gains via foreign travel and music; father's wealth.",
        10: "Venus in 10th — career in arts, beauty, fashion, entertainment; reputation in society.",
        11: "Venus in 11th — abundant income via women, friends, luxuries; many gains.",
        12: "Venus exalted — spiritual love, bedroom bliss, foreign luxuries, charitable disposition.",
    },
    "Saturn": {
        1:  "Saturn debilitated — slow rise, hard labor, late marriage; native born poor but rises.",
        2:  "Saturn in 2nd — family wealth via hard work; speech harsh, eye/teeth issues possible.",
        3:  "Saturn in 3rd — patient, methodical effort; brothers distant; gains via writing and persistence.",
        4:  "Saturn in 4th — mother's health weakened, property delays, vehicles late in life.",
        5:  "Saturn in 5th — childbirth delayed, son issues, but disciplined intellect; teaching favored.",
        6:  "Saturn in 6th — defeats enemies, gains via service, oil/coal/iron business.",
        7:  "Saturn exalted — supreme marriage karma, partnership success, foreign business gains.",
        8:  "Saturn in 8th — long life, occult research, but chronic health issues; inheritance late.",
        9:  "Saturn in 9th — father's longevity affected; religion through discipline; foreign destiny.",
        10: "Saturn in Pakka Ghar — supreme career success. Industry leader, judge, builder, statesman.",
        11: "Saturn in Pakka Ghar (11th of income) — massive income, government contracts, longevity.",
        12: "Saturn in 12th — losses via litigation, isolation, foreign settlement, spiritual practice.",
    },
    "Rahu": {
        1:  "Rahu in 1st — sudden rise then sudden fall; head/brain issues; foreign attractions.",
        2:  "Rahu in 2nd — family disputes, speech problems, sudden wealth gain or loss.",
        3:  "Rahu exalted — fearless, sudden gains via siblings, communication, technology.",
        4:  "Rahu in 4th — mother's health weak, property disputes, mental restlessness.",
        5:  "Rahu in 5th — sudden gain/loss via speculation; child issues; love-affair complications.",
        6:  "Rahu exalted in 6th — defeats enemies in surprising ways; gains via litigation and service.",
        7:  "Rahu in 7th — sudden marriage, foreign spouse, partnership instability.",
        8:  "Rahu debilitated — chronic disease, accidents, mysterious losses, occult dangers.",
        9:  "Rahu in 9th — father's health weak, religious confusion, foreign luck.",
        10: "Rahu in 10th — sudden career rise via technology, foreign trade, politics.",
        11: "Rahu in 11th — multiple income sources, friends from foreign lands, large network.",
        12: "Rahu in Pakka Ghar — supreme foreign success, spiritual realization or bedroom troubles.",
    },
    "Ketu": {
        1:  "Ketu in 1st — detached personality, mysterious, spiritual; head injuries possible.",
        2:  "Ketu in 2nd — family separation early, sudden financial drops; speech issues.",
        3:  "Ketu exalted — bold, mystical, gains via siblings; technology and writing favored.",
        4:  "Ketu in 4th — Matri Rin trigger. Mother's health affected, property losses.",
        5:  "Ketu in 5th — son issues, mysterious children, spiritual progeny; speculation losses.",
        6:  "Ketu in Pakka Ghar — exceptional sons born, defeats enemies, victory in litigation.",
        7:  "Ketu in 7th — spouse spiritual or absent, marriage troubles, foreign partner.",
        8:  "Ketu in 8th — occult research, sudden death risk, in-laws troublesome.",
        9:  "Ketu in 9th — religious devotion, father pious; foreign pilgrimage gains.",
        10: "Ketu in 10th — career detachment, mysterious profession, sudden rise/fall.",
        11: "Ketu in 11th — friends spiritual, gains unstable, elder sibling issues.",
        12: "Ketu debilitated — bedroom losses, foreign isolation, spiritual liberation.",
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# 3. REMEDIES (UPAYAS) PER PLANET PER HOUSE
# ─────────────────────────────────────────────────────────────────────────────
# Lal Kitab remedies are house-specific. Sourced from Astroshastra, AstroSage,
# and the kuberastrology codex. Each remedy must be performed for 43 days
# without interruption (classical LK rule).

REMEDIES_BASE: Dict[str, List[str]] = {
    "Sun": [
        "Offer water (arghya) to the rising Sun daily with copper vessel + jaggery.",
        "Donate wheat, jaggery, or copper on Sundays.",
        "Wear a ruby in gold ring on right ring finger (after astrological consult).",
        "Avoid accepting alcohol, leather goods, or oil as gifts.",
    ],
    "Moon": [
        "Donate milk, rice, or silver on Mondays.",
        "Offer water to a Peepal tree daily.",
        "Wear a pearl in silver ring on right little finger.",
        "Keep a silver square + rice tied in white cloth at home (received from mother's hand).",
    ],
    "Mars": [
        "Donate red lentils (masoor dal), red cloth, or jaggery on Tuesdays.",
        "Feed sweet bread to dogs.",
        "Float chana dal in flowing water to reduce malefic Mars.",
        "Wear coral in gold or copper ring (after consultation).",
        "Never speak lies — Mars amplifies their karmic blowback.",
    ],
    "Mercury": [
        "Donate green moong dal, green cloth, or copper items on Wednesdays.",
        "Feed green grass to cows.",
        "Pierce a green-painted hole through a copper coin and float it in flowing water for 43 days.",
        "Keep a parrot or feed birds green vegetables.",
    ],
    "Jupiter": [
        "Donate yellow items — turmeric, gram dal, yellow cloth — on Thursdays.",
        "Wear yellow sapphire in gold ring on right index finger (after consult).",
        "Apply saffron tilak on forehead daily.",
        "Feed Brahmins or elders; serve gurus.",
        "Plant a banana tree and water it on Thursdays.",
    ],
    "Venus": [
        "Donate white items — sugar, rice, milk, white cloth — on Fridays.",
        "Wear diamond or white sapphire in silver ring (after consult).",
        "Feed cows white food; serve a young girl.",
        "Bury silver coins in the southeast corner of the home.",
    ],
    "Saturn": [
        "Donate black items — sesame seeds (til), black cloth, mustard oil, iron — on Saturdays.",
        "Light a mustard oil lamp under a Peepal tree on Saturdays.",
        "Feed black dogs, crows, or laborers regularly.",
        "Wear iron (kada/ring) on right wrist or middle finger.",
        "Bury a piece of coal underground in your land.",
    ],
    "Rahu": [
        "Donate radish, coconut, or barley by flowing them in a river.",
        "Wear hessonite (gomed) in silver ring (after consult).",
        "Feed elephants — or donate to elephant sanctuaries.",
        "Keep a square piece of silver with you always.",
        "Recite Durga Saptashati or Bhairav Chalisa on Saturdays.",
    ],
    "Ketu": [
        "Donate sesame seeds, two-colored blankets, or wheat to a temple.",
        "Wear cat's eye (lehsunia) in silver ring (after consult).",
        "Feed stray dogs, especially black ones; serve old people.",
        "Keep a dog as a pet; help the helpless.",
        "Bury a coconut wrapped in red cloth in flowing water.",
    ],
}

# House-specific remedy overlays — applied IN ADDITION to base planet remedies
# when the placement is particularly afflicted or when LK prescribes specifics.
REMEDIES_HOUSE_SPECIFIC: Dict[str, Dict[int, List[str]]] = {
    "Sun": {
        7:  ["Donate coconut, mustard oil, and almonds at a place of worship.",
             "Avoid all disputes regarding wealth, property, or women."],
        8:  ["Avoid accepting donations or gifts from anyone.",
             "Drop a copper coin in flowing water on Sundays."],
        10: ["Keep a silver square in your pocket while at work.",
             "Touch your father's feet daily before leaving home."],
    },
    "Moon": {
        6:  ["Donate green cloth to a virgin girl or perform Kanya Daan.",
             "Avoid drinking milk at night."],
        8:  ["Bury silver in the foundation of the home.",
             "Keep a tumbler of milk by bedside at night; in the morning, pour at a tree root."],
        11: ["Donate milk at a Bhairav (Saturn) temple.",
             "Avoid taking milk as a gift."],
    },
    "Mars": {
        4:  ["Place rice made of silver in the home.",
             "Eat sweet food (honey) before leaving home in the morning."],
        7:  ["Bury sweet items (jaggery + honey) in the southwest corner.",
             "Perform Hanuman Chalisa daily before sunrise."],
        8:  ["Keep gold + silver + copper mixed ring on right ring finger.",
             "Eat sweets on Tuesdays; donate to siblings."],
        12: ["Place rice made of silver in the home.",
             "Take honey in the morning; offer sweets to others."],
    },
    "Mercury": {
        3:  ["Float Rewris (sweet sesame snacks) in flowing water.",
             "Keep good relations with sisters."],
        12: ["Wash 4 kg rice with milk and float in a holy river.",
             "Keep elephant tooth (ivory substitute — wooden) at home."],
    },
    "Jupiter": {
        5:  ["Apply saffron tilak daily.",
             "Wear gold in the ear or as a chain."],
        10: ["Plant a Peepal tree and water it daily.",
             "Serve elders with yellow sweets on Thursdays."],
    },
    "Venus": {
        6:  ["Donate cow + clothes to a married woman.",
             "Avoid intimacy with women other than spouse."],
        8:  ["Donate perfume and silver to a temple.",
             "Avoid white clothing during travel."],
    },
    "Saturn": {
        1:  ["Avoid alcohol, meat, and adultery throughout life.",
             "Bury a square piece of iron under the home's foundation."],
        4:  ["Worship Lord Shiva; pour milk over Shivling on Mondays.",
             "Donate buffalo or curd at a temple."],
        5:  ["Donate almonds at a temple in two halves: one half donate, one half keep at home.",
             "Distribute almonds to children for 43 days."],
    },
    "Rahu": {
        1:  ["Donate barley equal to native's weight in flowing water.",
             "Avoid wearing dark blue and black together."],
        7:  ["Wear silver chain around neck.",
             "Keep relations transparent — Rahu in 7 punishes deceit."],
        8:  ["Bury barley + radish in the southwest corner.",
             "Recite Bhairav Chalisa on Saturdays."],
    },
    "Ketu": {
        4:  ["Collect equal amount of silver from blood relatives, drop in flowing water.",
             "Wear gold in the ear."],
        7:  ["Keep a dog at home, especially a black one.",
             "Serve old men and saints with food."],
        12: ["Donate bedding (blanket) to an ashram.",
             "Avoid sleeping with feet pointing south."],
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# 4. RIN (KARMIC DEBT) ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────
# Lal Kitab identifies 8 types of Rin. Each has specific planetary triggers,
# symptoms, and a prescribed Vedic remedy that goes beyond house remedies.

RIN_DEFINITIONS: List[Dict[str, Any]] = [
    {
        "type": "Pitra Rin (Ancestral / Forefathers' Debt)",
        "planet": "Jupiter",
        "trigger_check": lambda planets: (
            # Classical: Rahu, Venus, or Mercury aspects/conjuncts Jupiter,
            # OR enemies of Jupiter sit in 2, 5, 9, 12.
            planets.get("Rahu", {}).get("lk_house") in [2, 5, 9, 12]
            or planets.get("Venus", {}).get("lk_house") in [2, 5, 9, 12]
            or planets.get("Mercury", {}).get("lk_house") in [2, 5, 9, 12]
        ),
        "trigger_desc": "Rahu, Venus, or Mercury occupies the 2nd, 5th, 9th, or 12th LK house.",
        "symptoms": "Loss of wealth, repeated career setbacks despite effort, lack of paternal blessing, "
                    "litigation, poverty after early success, heart issues, son's troubles. Problems may "
                    "persist till age 48, eased when grandson is 11 years old.",
        "remedy": "Collect equal monetary contributions from ALL blood relatives on a single day; "
                  "perform Homa (Yagya) in a temple with that pooled amount. "
                  "Perform Pitra Tarpan during Pitru Paksha annually. "
                  "Feed crows and black dogs on Amavasya. "
                  "Donate yellow items (gram dal, turmeric) on Thursdays in ancestors' name.",
    },
    {
        "type": "Matri Rin (Mother's Debt)",
        "planet": "Moon",
        "trigger_check": lambda planets: planets.get("Ketu", {}).get("lk_house") == 4,
        "trigger_desc": "Ketu placed in the 4th LK house (Moon's pakka ghar).",
        "symptoms": "Mother's chronic illness; sewer/garbage near home; mental restlessness, sleep loss; "
                    "education obstacles; death of milk-giving pets/horses; income instability.",
        "remedy": "Collect equal money from all blood relatives; donate the pooled amount to a doctor "
                  "with the instruction to provide free service to the poor against it. "
                  "Serve mother with own hands; touch her feet daily. "
                  "Donate silver in mother's name. Keep a silver square + rice in white cloth at home.",
    },
    {
        "type": "Stree Rin (Wife / Spouse's Debt)",
        "planet": "Venus",
        "trigger_check": lambda planets: (
            planets.get("Saturn", {}).get("lk_house") == 7
            or planets.get("Sun", {}).get("lk_house") == 7
            or planets.get("Rahu", {}).get("lk_house") == 7
        ),
        "trigger_desc": "Saturn, Sun, or Rahu in 7th LK house (Venus's pakka ghar).",
        "symptoms": "Marriage delay or rejection, friction with spouse, infidelity issues, "
                    "loss of female progeny, white-discharge or reproductive ailments, "
                    "loss of wealth via spouse.",
        "remedy": "Wash 100 grams of saunf (fennel) in milk, dry it, and keep in bedroom. "
                  "Bury raw turmeric + a silver coin in the southwest corner of the home. "
                  "Donate sugar candy (batashe) at a Venus-associated temple. "
                  "Serve unmarried girls and feed them sweet kheer.",
    },
    {
        "type": "Bhratri Rin (Brother / Sibling's Debt)",
        "planet": "Mars",
        "trigger_check": lambda planets: (
            planets.get("Saturn", {}).get("lk_house") in [3]
            or planets.get("Ketu", {}).get("lk_house") == 3
        ),
        "trigger_desc": "Saturn or Ketu in 3rd LK house (Mars's pakka ghar).",
        "symptoms": "Conflict with siblings, especially younger; sibling's misfortune; "
                    "lack of courage, accident-prone, blood disorders.",
        "remedy": "Trade gifts annually with siblings — give and receive jewelry, sweets, or money. "
                  "Donate red items (red cloth, masoor dal) on Tuesdays. "
                  "Float chana dal in a river. Worship Hanuman; recite Hanuman Chalisa.",
    },
    {
        "type": "Putra Rin (Children's Debt)",
        "planet": "Jupiter",
        "trigger_check": lambda planets: (
            planets.get("Sun", {}).get("lk_house") == 5
            and planets.get("Rahu", {}).get("lk_house") in [5, 9]
        ),
        "trigger_desc": "Sun in 5th LK house AND Rahu in 5th or 9th LK house.",
        "symptoms": "Childlessness, especially male child; miscarriages; child's chronic illness; "
                    "estrangement from progeny; obstacles in education of children.",
        "remedy": "Donate Saraswati books and educational material to poor children. "
                  "Feed sweet kheer to children for 43 days. "
                  "Plant a banana tree and serve it on Thursdays. "
                  "Perform Santan Gopal mantra recitation.",
    },
    {
        "type": "Beti / Bahen Rin (Daughter / Sister's Debt)",
        "planet": "Mercury",
        "trigger_check": lambda planets: planets.get("Moon", {}).get("lk_house") in [3, 6],
        "trigger_desc": "Moon placed in 3rd or 6th LK house (Mercury's enemy positions).",
        "symptoms": "Daughter or sister suffers; female progeny is rare or troubled; "
                    "the native faces hidden disgrace through women; nervous-system disease.",
        "remedy": "Float green moong dal in flowing water for 43 days. "
                  "Gift clothes and gold to daughter/sister annually. "
                  "Feed green vegetables to cows and parrots. "
                  "Avoid harsh words to any female relative.",
    },
    {
        "type": "Karz Rin (Self-Inflicted / Swa Rin)",
        "planet": "Mercury",
        "trigger_check": lambda planets: (
            planets.get("Venus", {}).get("lk_house") == 5
            or planets.get("Saturn", {}).get("lk_house") == 5
            or planets.get("Rahu", {}).get("lk_house") == 5
            or planets.get("Ketu", {}).get("lk_house") == 5
        ),
        "trigger_desc": "Venus, Saturn, Rahu, or Ketu placed in 5th LK house.",
        "symptoms": "Native's own past-life misdeeds manifest as: chronic debt, addiction, "
                    "speculation losses, ego-conflicts that destroy success, mental anguish.",
        "remedy": "Donate green moong dal in a temple every Wednesday for 43 weeks. "
                  "Pierce a hole through a copper coin and float it in flowing water. "
                  "Recite Vishnu Sahasranama. "
                  "Practice silence (mauna) one day per week.",
    },
    {
        "type": "Agyat Rin (Unidentified / Stranger's Debt)",
        "planet": "Saturn",
        "trigger_check": lambda planets: (
            planets.get("Saturn", {}).get("lk_house") in [10]
            and (
                planets.get("Sun", {}).get("lk_house") in [6, 8, 12]
                or planets.get("Rahu", {}).get("lk_house") == 10
                or planets.get("Ketu", {}).get("lk_house") == 10
            )
        ),
        "trigger_desc": "Sun in 6/8/12 with Saturn in 10, or Rahu/Ketu conjoining Saturn in 10.",
        "symptoms": "Mysterious recurring misfortunes; debts that appear from nowhere; "
                    "betrayal by people the native helped; legal troubles from strangers.",
        "remedy": "Feed crows, ants, and street dogs daily without fail. "
                  "Donate sesame oil and iron to a Shani temple on Saturdays. "
                  "Light a mustard-oil diya under a Peepal tree weekly. "
                  "Help the helpless — orphans, widows, the disabled — quietly, without seeking credit.",
    },
]


# ─────────────────────────────────────────────────────────────────────────────
# 5. CORE ANALYSIS FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def _planet_sign_from_chart(chart: dict, planet: str) -> str:
    """Read planet's sign from dashaflow.cast_chart() output."""
    p = chart.get("planets", {}).get(planet, {})
    return p.get("sign", "Aries")


def _planet_retrograde(chart: dict, planet: str) -> bool:
    """Read retrograde flag — Rahu/Ketu always treated as retrograde in LK."""
    if planet in ("Rahu", "Ketu"):
        return True
    p = chart.get("planets", {}).get(planet, {})
    return bool(p.get("retrograde", False) or p.get("isRetro", False))


def _build_lk_houses(chart: dict) -> Dict[int, List[str]]:
    """
    Build the LK house structure: each of 12 houses holds the list of planets
    placed there per LK rules (using Kaalpurusha sign = house mapping).
    """
    houses: Dict[int, List[str]] = {h: [] for h in range(1, 13)}
    for planet in ("Sun", "Moon", "Mars", "Mercury", "Jupiter",
                   "Venus", "Saturn", "Rahu", "Ketu"):
        sign = _planet_sign_from_chart(chart, planet)
        h = LK_SIGN_TO_HOUSE.get(sign)
        if h:
            houses[h].append(planet)
    return houses


def _is_sleeping(planet: str, house: int, lk_houses: Dict[int, List[str]]) -> bool:
    """
    A planet is 'sleeping' (soya hua) if:
      - it does NOT aspect any other planet,
      - AND it is NOT in its own pakka ghar.
    A planet in its pakka ghar is always awake.
    """
    if house in PAKKA_GHAR_HOUSES.get(planet, []):
        return False
    aspect_offsets = LK_ASPECTS.get(planet, [7])
    for offset in aspect_offsets:
        target_house = ((house - 1 + offset - 1) % 12) + 1
        if lk_houses.get(target_house):  # any planet sitting there
            return False
    return True


def _judge_effect(planet: str, house: int, retrograde: bool) -> str:
    """Determine if placement is auspicious / mixed / inauspicious."""
    if house == EXALTATION.get(planet):
        return "auspicious_exalted"
    if house == DEBILITATION.get(planet):
        return "inauspicious_debilitated"
    if house in PAKKA_GHAR_HOUSES.get(planet, []):
        return "auspicious_pakka_ghar"
    # Lal Kitab "Best Houses" lookup
    best_houses_map = {
        "Sun":     {1, 5, 8, 9, 11, 12},
        "Moon":    {1, 2, 3, 4, 5, 7, 9, 10, 11},
        "Mars":    {1, 3, 5, 7, 9, 12},
        "Mercury": {1, 2, 4, 5, 6, 7, 10, 11},
        "Jupiter": {1, 2, 4, 5, 9, 11, 12},
        "Venus":   {1, 2, 3, 4, 5, 7, 11, 12},
        "Saturn":  {2, 3, 6, 7, 10, 11},
        "Rahu":    {3, 4, 6, 10, 11, 12},
        "Ketu":    {1, 3, 5, 6, 9, 12},
    }
    if house in best_houses_map.get(planet, set()):
        rating = "auspicious"
    else:
        rating = "mixed"
    if retrograde and planet not in ("Rahu", "Ketu"):
        # Retrograde planets in LK either AMPLIFY good/bad results, or
        # behave as if in the opposite house. We mark this for the reader.
        rating += "_retrograde_amplified"
    return rating


def _compose_remedies(planet: str, house: int) -> List[str]:
    """Stack base remedies + house-specific overlays."""
    base = list(REMEDIES_BASE.get(planet, []))
    overlay = REMEDIES_HOUSE_SPECIFIC.get(planet, {}).get(house, [])
    return overlay + base   # house-specific shown first


def _detect_rins(planets_data: Dict[str, dict]) -> List[Dict[str, Any]]:
    """Run all 8 rin triggers and return the active ones."""
    active: List[Dict[str, Any]] = []
    for rin in RIN_DEFINITIONS:
        try:
            if rin["trigger_check"](planets_data):
                active.append({
                    "type":      rin["type"],
                    "planet":    rin["planet"],
                    "trigger":   rin["trigger_desc"],
                    "symptoms":  rin["symptoms"],
                    "remedy":    rin["remedy"],
                })
        except Exception:
            # defensive: never fail the whole analysis on a single rin check
            continue
    return active


# ─────────────────────────────────────────────────────────────────────────────
# 6. PUBLIC ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def analyze_lal_kitab(chart: dict) -> dict:
    """
    Main entry point. Pass a dashaflow.cast_chart() output.
    Returns the complete Lal Kitab analysis as structured JSON.
    """
    lk_houses = _build_lk_houses(chart)

    planets_data: Dict[str, dict] = {}
    for planet in ("Sun", "Moon", "Mars", "Mercury", "Jupiter",
                   "Venus", "Saturn", "Rahu", "Ketu"):
        sign = _planet_sign_from_chart(chart, planet)
        house = LK_SIGN_TO_HOUSE.get(sign, 0)
        retrograde = _planet_retrograde(chart, planet)
        sleeping = _is_sleeping(planet, house, lk_houses)
        effect = _judge_effect(planet, house, retrograde)
        in_pakka = house in PAKKA_GHAR_HOUSES.get(planet, [])

        planets_data[planet] = {
            "sign":             sign,
            "lk_house":         house,
            "pakka_ghar":       PAKKA_GHAR.get(planet),
            "in_pakka_ghar":    in_pakka,
            "retrograde":       retrograde,
            "status":           "sleeping" if sleeping else "awake",
            "effect":           effect,
            "interpretation":   PLANET_IN_HOUSE.get(planet, {}).get(house, "Standard placement."),
            "remedies":         _compose_remedies(planet, house),
        }

    # Detect rins (run after planets_data is fully populated)
    rins = _detect_rins(planets_data)

    # Build summary
    awake = [p for p, d in planets_data.items() if d["status"] == "awake"]
    sleeping = [p for p, d in planets_data.items() if d["status"] == "sleeping"]
    in_pakka = [p for p, d in planets_data.items() if d["in_pakka_ghar"]]

    # "Blind chart" — all planets on one side of Rahu-Ketu axis
    rahu_h = planets_data["Rahu"]["lk_house"]
    ketu_h = planets_data["Ketu"]["lk_house"]
    blind_chart = False
    if rahu_h and ketu_h:
        other_houses = [d["lk_house"] for p, d in planets_data.items()
                        if p not in ("Rahu", "Ketu")]
        # Check if all 7 non-node planets are on one semicircle from Rahu to Ketu
        # going clockwise vs counter-clockwise.
        def _on_one_side(start: int, end: int) -> bool:
            arc = []
            h = start
            while h != end:
                h = h % 12 + 1
                if h == end:
                    break
                arc.append(h)
            return all(p_h in arc for p_h in other_houses)
        blind_chart = _on_one_side(rahu_h, ketu_h) or _on_one_side(ketu_h, rahu_h)

    return {
        "lal_kitab_houses": {str(h): pl for h, pl in lk_houses.items()},
        "planets": planets_data,
        "rin": rins,
        "summary": {
            "awake_planets": awake,
            "sleeping_planets": sleeping,
            "planets_in_pakka_ghar": in_pakka,
            "blind_chart": blind_chart,
            "total_active_rins": len(rins),
            "rin_types_active": [r["type"] for r in rins],
        },
        "meta": {
            "system":      "Lal Kitab (Pt. Rup Chand Joshi, 1939–1952)",
            "house_model": "Kaalpurusha (Aries = 1st always)",
            "aspect_model": "LK-specific (Mars 4/8, Jupiter 5/9, Saturn 3/10, Rahu/Ketu 5/7/9/12)",
            "remedy_duration": "43 days continuous, without break",
        }
    }
