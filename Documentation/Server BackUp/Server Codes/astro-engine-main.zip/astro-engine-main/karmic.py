"""
karmic.py — numiVeda Kaaliyo Astro Engine — Module D1 (Past Life / Karmic)

8 endpoints for past-life, karmic, and moksha analysis.

Endpoints:
    handle_profile             — Master karmic synthesis
    handle_karakamsha          — AK in D9 / soul's direction
    handle_atmakaraka_journey  — AK by sign — past-life soul lesson
    handle_ketu_past_life      — Ketu's sign + nakshatra = past-life karma
    handle_rahu_forward_karma  — Rahu's sign = forward developmental karma
    handle_twelfth_house_moksha — 12th house liberation path
    handle_kaal_sarpa          — Kaal Sarpa type + escape route
    handle_upapada_karma       — Spouse karma reading
    handle_arudha_padas        — Worldly projections analysis

Note: D1 leverages chart fields already computed natively:
    chart["karakamsha"], chart["upapada"], chart["arudha_padas"],
    chart["kaal_sarpa"], chart["jaimini_karakas"]
"""

from typing import Dict, List, Optional, Any

from astro_helpers import (
    extract_chart_essentials,
    get_chart,
    SIGNS_ORDER,
    SIGN_TO_LORD,
    HOUSE_TO_LIFE_AREA,
)

from karmic_data import (
    AK_BY_SIGN_THEMES,
    KARAKAMSHA_HOUSE_DIRECTIONS,
    KETU_NAKSHATRA_KARMA,
    KETU_SIGN_PAST_LIFE,
    RAHU_FORWARD_KARMA,
    TWELFTH_HOUSE_MOKSHA,
    KAAL_SARPA_TYPES,
    KAAL_SARPA_PARTIAL_NOTE,
    UPAPADA_KARMA,
    ARUDHA_INTERPRETATIONS,
    KARAKA_PAST_LIFE_LESSONS,
    KARMIC_REMEDIES,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# HELPERS
# ════════════════════════════════════════════════════════════════════════

def _build(birth: Dict[str, Any]):
    raw = get_chart(
        dob=birth["dob"], time=birth["time"],
        lat=birth["lat"], lon=birth["lon"],
        timezone=birth.get("timezone", "Asia/Kolkata"),
    )
    return raw, extract_chart_essentials(raw)


def _sign_index(sign: Optional[str]) -> Optional[int]:
    if not sign or sign not in SIGNS_ORDER:
        return None
    return SIGNS_ORDER.index(sign)


def _kaal_sarpa_axis_label(rahu_house: int) -> str:
    """Return Kaal Sarpa type by Rahu's house — for type identification."""
    type_by_rahu_house = {
        1: "Anant",      2: "Kulik",       3: "Vasuki",     4: "Shankhapal",
        5: "Padma",      6: "Mahapadma",   7: "Takshak",    8: "Karkotaka",
        9: "Shankhachuda", 10: "Ghatak",   11: "Vishdhar",  12: "Sheshanag",
    }
    return type_by_rahu_house.get(rahu_house, "Unknown")


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT HANDLERS
# ════════════════════════════════════════════════════════════════════════

def handle_karakamsha(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 2: AK's D9 placement and soul direction."""
    raw, e = _build(birth)
    km = raw.get("karakamsha", {})

    karakamsha_house = km.get("karakamsha_house_from_lagna")
    direction = KARAKAMSHA_HOUSE_DIRECTIONS.get(karakamsha_house or 0, {})

    return {
        "atmakaraka_planet":    km.get("atmakaraka"),
        "karakamsha_sign":      km.get("karakamsha_sign"),
        "karakamsha_house_from_lagna": karakamsha_house,
        "planets_in_karakamsha":km.get("planets_in_karakamsha", []),
        "ishta_devata_sign":    km.get("ishta_devata_sign"),
        "ishta_devata_lord":    km.get("ishta_devata_lord"),
        "engine_description":   km.get("description"),
        "soul_direction":       direction,
        "citation":             CLASSICAL_CITATIONS["karakamsha"]
                                + "; " + CLASSICAL_CITATIONS["ishta_devata"],
    }


def handle_atmakaraka_journey(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 3: Atmakaraka by RASHI sign — past-life soul lesson."""
    raw, e = _build(birth)
    jk = raw.get("jaimini_karakas", {})
    ak = jk.get("Atmakaraka", {})

    ak_sign = ak.get("sign")
    theme = AK_BY_SIGN_THEMES.get(ak_sign, {})

    # AK degree intensity — 30° = highest intensity (sharpest karmic edge)
    ak_degree = ak.get("degree", 0)
    intensity = (
        "very_sharp" if ak_degree >= 26 else
        "sharp"      if ak_degree >= 20 else
        "moderate"   if ak_degree >= 10 else
        "softer"
    )

    return {
        "atmakaraka_planet":   ak.get("planet"),
        "atmakaraka_sign":     ak_sign,
        "atmakaraka_degree":   ak_degree,
        "atmakaraka_house":    ak.get("house"),
        "ak_d9_sign":          ak.get("d9_sign"),
        "intensity":           intensity,
        "intensity_note":      f"AK at {ak_degree:.2f}° — {intensity} karmic intensity (higher degree = sharper lesson focus)",
        "past_life_role":      theme.get("past_life_role"),
        "core_lesson":         theme.get("core_lesson"),
        "shadow":               theme.get("shadow"),
        "soul_direction":      theme.get("soul_direction"),
        "all_karakas_lessons": KARAKA_PAST_LIFE_LESSONS,
        "citation":            CLASSICAL_CITATIONS["atmakaraka"],
    }


def handle_ketu_past_life(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 4: Ketu's sign + nakshatra past-life reading."""
    raw, e = _build(birth)
    ketu = raw.get("planets", {}).get("Ketu", {})

    ketu_sign = ketu.get("sign")
    ketu_nak = ketu.get("nakshatra")
    ketu_house = ketu.get("house")
    ketu_d9_sign = ketu.get("d9_sign")

    return {
        "ketu_sign":         ketu_sign,
        "ketu_nakshatra":    ketu_nak,
        "ketu_pada":         ketu.get("pada"),
        "ketu_house":        ketu_house,
        "ketu_d9_sign":      ketu_d9_sign,
        "sign_past_life":    KETU_SIGN_PAST_LIFE.get(ketu_sign, "Sign-specific reading not in catalog"),
        "nakshatra_karma":   KETU_NAKSHATRA_KARMA.get(ketu_nak, "Nakshatra-specific reading not in catalog"),
        "house_meaning":     f"Past-life karma manifests in {HOUSE_TO_LIFE_AREA.get(ketu_house, 'multiple areas')} (house {ketu_house})",
        "note":              "Ketu = what soul mastered before; releases attachment in this area. Read alongside Rahu for full karmic axis.",
        "citation":          CLASSICAL_CITATIONS["ketu_past_life"],
    }


def handle_rahu_forward_karma(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 5: Rahu's sign — forward karma to develop."""
    raw, e = _build(birth)
    rahu = raw.get("planets", {}).get("Rahu", {})

    rahu_sign = rahu.get("sign")
    rahu_nak = rahu.get("nakshatra")
    rahu_house = rahu.get("house")
    rahu_d9_sign = rahu.get("d9_sign")

    return {
        "rahu_sign":         rahu_sign,
        "rahu_nakshatra":    rahu_nak,
        "rahu_pada":         rahu.get("pada"),
        "rahu_house":        rahu_house,
        "rahu_d9_sign":      rahu_d9_sign,
        "forward_karma":     RAHU_FORWARD_KARMA.get(rahu_sign, "Sign-specific reading not in catalog"),
        "house_arena":       f"Rahu activates karmic development in {HOUSE_TO_LIFE_AREA.get(rahu_house, 'multiple areas')} (house {rahu_house})",
        "note":              "Rahu = what soul must develop NOW. Often produces obsessive interest in this area. Embrace consciously to fulfill karmic curriculum.",
        "citation":          CLASSICAL_CITATIONS["rahu_forward"],
    }


def handle_twelfth_house_moksha(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 6: 12th house moksha path analysis."""
    raw, e = _build(birth)
    lagna = e.get("lagna_sign")

    # 12th sign and lord
    lagna_idx = _sign_index(lagna)
    twelfth_sign = SIGNS_ORDER[(lagna_idx - 1) % 12] if lagna_idx is not None else None
    twelfth_lord = SIGN_TO_LORD.get(twelfth_sign) if twelfth_sign else None
    twelfth_lord_data = e.get("planets", {}).get(twelfth_lord, {}) if twelfth_lord else {}

    # Planets occupying 12th house
    occupants = [p for p, pd in e.get("planets", {}).items()
                 if isinstance(pd, dict) and pd.get("house") == 12]

    # Build occupant moksha paths
    occupant_paths: List[Dict[str, Any]] = []
    for planet in occupants:
        key = f"occupant_{planet}"
        if key in TWELFTH_HOUSE_MOKSHA:
            occupant_paths.append({
                "planet":      planet,
                "moksha_path": TWELFTH_HOUSE_MOKSHA[key]["moksha_path"],
                "practice":    TWELFTH_HOUSE_MOKSHA[key]["practice"],
            })

    return {
        "lagna":               lagna,
        "twelfth_sign":        twelfth_sign,
        "twelfth_lord":        twelfth_lord,
        "twelfth_lord_data": {
            "sign":     twelfth_lord_data.get("sign"),
            "house":    twelfth_lord_data.get("house"),
            "dignity":  twelfth_lord_data.get("dignity"),
        },
        "occupants":           occupants,
        "occupant_moksha_paths": occupant_paths,
        "note":                "12th house = Vyaya Bhava = expenses, foreign, isolation, AND moksha. Multiple planets in 12th = layered liberation karma.",
        "remedy":              KARMIC_REMEDIES["12th_strong"] if occupants else "No 12th house occupants — moksha karma operates through 12th lord placement only",
        "citation":            CLASSICAL_CITATIONS["twelfth_house"],
    }


def handle_kaal_sarpa(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 7: Kaal Sarpa dosha detection + classical type identification."""
    raw, e = _build(birth)
    ks = raw.get("kaal_sarpa") or {}

    present = ks.get("present", False)
    if not present:
        return {
            "present":  False,
            "note":     "No Kaal Sarpa configuration in this chart",
            "citation": CLASSICAL_CITATIONS["kaal_sarpa"],
        }

    # Identify classical type by Rahu's house
    rahu_house = raw.get("planets", {}).get("Rahu", {}).get("house")
    type_name = _kaal_sarpa_axis_label(rahu_house)
    type_details = KAAL_SARPA_TYPES.get(type_name, {})

    # Engine-reported type (e.g., "Full", "Partial (Mars outside)")
    engine_type = ks.get("type", "")
    is_partial = "Partial" in engine_type or "partial" in engine_type

    return {
        "present":            True,
        "engine_classification": engine_type,
        "rahu_sign":          ks.get("rahu_sign"),
        "ketu_sign":          ks.get("ketu_sign"),
        "rahu_house":         rahu_house,
        "classical_type":     type_name,
        "type_axis":          type_details.get("axis"),
        "type_domain":        type_details.get("domain"),
        "engine_description": ks.get("description"),
        "is_partial":         is_partial,
        "partial_relief_note":KAAL_SARPA_PARTIAL_NOTE if is_partial else None,
        "remedy":             KARMIC_REMEDIES["kaal_sarpa"],
        "citation":           CLASSICAL_CITATIONS["kaal_sarpa"],
    }


def handle_upapada_karma(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 8: Upapada Lagna spouse karma reading."""
    raw, e = _build(birth)
    upapada = raw.get("upapada", {})

    ul_sign = upapada.get("sign")
    ul_lord = upapada.get("lord")
    second_from_ul = upapada.get("second_from_ul")

    return {
        "upapada_sign":         ul_sign,
        "upapada_lord":         ul_lord,
        "second_from_upapada":  second_from_ul,
        "second_from_ul_lord":  SIGN_TO_LORD.get(second_from_ul) if second_from_ul else None,
        "spouse_karma":         UPAPADA_KARMA.get(ul_sign, "Sign-specific reading not in catalog"),
        "engine_description":   upapada.get("description"),
        "note":                 "Upapada (UL/A12) is the marriage karma indicator. Second-from-UL (sustenance of marriage) shows longevity of union. UL afflictions can indicate karmic challenges in partnership.",
        "citation":             CLASSICAL_CITATIONS["upapada"],
    }


def handle_arudha_padas(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 9: All 12 Arudha Padas — worldly projections."""
    raw, e = _build(birth)
    padas_raw = raw.get("arudha_padas", {})

    padas: List[Dict[str, Any]] = []
    for h in range(1, 13):
        # The engine may use string or int keys
        pad_data = padas_raw.get(h) or padas_raw.get(str(h)) or {}
        interp = ARUDHA_INTERPRETATIONS.get(h, {})
        padas.append({
            "house":          h,
            "name":           pad_data.get("name") or interp.get("name"),
            "sign":           pad_data.get("sign"),
            "sign_index":     pad_data.get("sign_index"),
            "domain":         interp.get("domain"),
        })

    return {
        "lagna":         e.get("lagna_sign"),
        "arudha_padas":  padas,
        "interpretations_catalog": ARUDHA_INTERPRETATIONS,
        "note":          "Arudha = how the world PERCEIVES each life-area, distinct from actual house meaning. AL (A1) = how others see you. UL (A12) = how marriage is perceived. A10 = perceived profession.",
        "citation":      CLASSICAL_CITATIONS["arudha"],
    }


def handle_profile(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 1 (MASTER): Karmic master synthesis."""
    karakamsha = handle_karakamsha(birth)
    ak_journey = handle_atmakaraka_journey(birth)
    ketu = handle_ketu_past_life(birth)
    rahu = handle_rahu_forward_karma(birth)
    moksha = handle_twelfth_house_moksha(birth)
    ks = handle_kaal_sarpa(birth)
    upapada = handle_upapada_karma(birth)

    headlines: List[str] = []
    headlines.append(
        f"Atmakaraka: {ak_journey['atmakaraka_planet']} in {ak_journey['atmakaraka_sign']} "
        f"({ak_journey['atmakaraka_degree']:.2f}° — {ak_journey['intensity']} intensity)"
    )
    headlines.append(
        f"Karakamsha in {karakamsha['karakamsha_sign']} (H{karakamsha['karakamsha_house_from_lagna']} from Lagna) "
        f"— Ishta Devata: {karakamsha['ishta_devata_lord']}"
    )
    headlines.append(
        f"Ketu past-life mastery: {ketu['ketu_sign']} ({ketu['ketu_nakshatra']})"
    )
    headlines.append(
        f"Rahu forward karma: develop {rahu['rahu_sign']} themes"
    )
    if ks["present"]:
        headlines.append(
            f"⚠️ Kaal Sarpa: {ks['classical_type']} ({ks['engine_classification']})"
        )
    if moksha["occupants"]:
        headlines.append(
            f"12th house occupants: {moksha['occupants']} — direct moksha karma activations"
        )

    return {
        "headlines":              headlines,
        "karakamsha":             karakamsha,
        "atmakaraka_journey":     ak_journey,
        "ketu_past_life":         ketu,
        "rahu_forward_karma":     rahu,
        "twelfth_house_moksha":   moksha,
        "kaal_sarpa":             ks,
        "upapada":                upapada,
        "method":                 "Synthesis of Karakamsha + Atmakaraka journey + Ketu past-life + Rahu forward karma + 12th house moksha + Kaal Sarpa + Upapada per Jaimini Upadesha Sutras and BPHS Ch. 24/32",
        "general_remedy":         KARMIC_REMEDIES["general"],
        "citations": {
            "karakamsha":   CLASSICAL_CITATIONS["karakamsha"],
            "atmakaraka":   CLASSICAL_CITATIONS["atmakaraka"],
            "ketu":         CLASSICAL_CITATIONS["ketu_past_life"],
            "rahu":         CLASSICAL_CITATIONS["rahu_forward"],
            "moksha":       CLASSICAL_CITATIONS["twelfth_house"],
            "kaal_sarpa":   CLASSICAL_CITATIONS["kaal_sarpa"],
            "upapada":      CLASSICAL_CITATIONS["upapada"],
        },
    }
