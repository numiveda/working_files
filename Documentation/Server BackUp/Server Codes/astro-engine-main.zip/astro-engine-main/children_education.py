"""
children_education.py — numiVeda Kaaliyo Astro Engine — Module C5

8 endpoints for children (Putra Bhava) and education analysis.

Endpoints:
    handle_children_profile         — Master children analysis
    handle_5th_house_analysis       — 5th house deep-dive
    handle_conception_timing        — Dasha-based conception windows
    handle_d7_saptamsha             — D7 children-chart synthesis
    handle_putra_dosha              — Putra Dosha detection + cancellations
    handle_education_profile        — Master education analysis
    handle_4th_5th_synthesis        — 2/4/5/9 house education synthesis
    handle_foreign_study_yoga       — Foreign education yoga detection

Notes:
- No gender prediction (would be illegal under PCPNDT Act in India).
  Engine returns chart indicators only; no gender of unborn child claimed.
- D7 (Saptamsha) chart data is already provided in raw cast_chart output
  as `d7_sign` field on each planet (verified earlier).
"""

from typing import Dict, List, Optional, Any

from astro_helpers import (
    extract_chart_essentials,
    get_chart,
    compute_house_lords,
    SIGNS_ORDER,
    SIGN_TO_LORD,
    HOUSE_TO_LIFE_AREA,
)

from children_education_data import (
    PUTRA_KARAKAS,
    FIFTH_HOUSE_INDICATORS,
    PUTRA_DOSHA_RULES,
    PUTRA_DOSHA_REMEDIES,
    D7_SAPTAMSHA_NOTES,
    CONCEPTION_TIMING_PLANETS,
    EDUCATION_PLANETS,
    EDUCATION_HOUSES,
    FOREIGN_STUDY_PATTERNS,
    EDUCATION_SUCCESS_INDICATORS,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# HELPERS
# ════════════════════════════════════════════════════════════════════════

def _build(birth: Dict[str, Any]):
    raw = get_chart(
        dob=birth["dob"], time=birth["time"],
        lat=birth["lat"], lon=birth["lon"],
        timezone=birth.get("timezone", "Asia/Kolkata"),
    )
    return raw, extract_chart_essentials(raw)


def _sign_index(sign: Optional[str]) -> Optional[int]:
    if not sign or sign not in SIGNS_ORDER:
        return None
    return SIGNS_ORDER.index(sign)


def _nth_sign_from(base_sign: str, n: int) -> Optional[str]:
    """Return sign at position n from base_sign (1=base, 2=next, ...)."""
    idx = _sign_index(base_sign)
    if idx is None:
        return None
    return SIGNS_ORDER[(idx + n - 1) % 12]


def _planets_in_house(essentials: Dict[str, Any], house: int) -> List[str]:
    return [p for p, pd in essentials.get("planets", {}).items()
            if isinstance(pd, dict) and pd.get("house") == house]


def _planet_aspects_sign(planet_data: Dict[str, Any], target_sign: str) -> bool:
    """Check if planet aspects a given sign via its `aspects` list (raw chart format)."""
    if not isinstance(planet_data, dict):
        return False
    aspects = planet_data.get("aspects", [])
    return target_sign in aspects


# ════════════════════════════════════════════════════════════════════════
# CHILDREN ENDPOINTS
# ════════════════════════════════════════════════════════════════════════

def handle_5th_house_analysis(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 2: 5th house deep-dive."""
    raw, e = _build(birth)
    lagna = e.get("lagna_sign")
    fifth_sign = _nth_sign_from(lagna, 5)
    fifth_lord = SIGN_TO_LORD.get(fifth_sign) if fifth_sign else None
    fifth_lord_data = e.get("planets", {}).get(fifth_lord, {}) if fifth_lord else {}

    occupants = _planets_in_house(e, 5)

    # Aspecting planets (using raw chart's pre-computed aspects)
    aspecting_5th: List[str] = []
    for planet, pdata in raw.get("planets", {}).items():
        if isinstance(pdata, dict) and fifth_sign in pdata.get("aspects", []):
            aspecting_5th.append(planet)

    return {
        "lagna_sign":       lagna,
        "fifth_sign":       fifth_sign,
        "fifth_lord":       fifth_lord,
        "fifth_lord_data": {
            "sign":          fifth_lord_data.get("sign"),
            "house":         fifth_lord_data.get("house"),
            "dignity":       fifth_lord_data.get("dignity"),
            "is_retrograde": fifth_lord_data.get("is_retrograde", False),
            "is_combust":    fifth_lord_data.get("is_combust", False),
        },
        "planets_in_5th":   occupants,
        "planets_aspecting_5th": aspecting_5th,
        "indicators":       FIFTH_HOUSE_INDICATORS,
        "citation":         CLASSICAL_CITATIONS["putra_bhava"],
    }


def handle_putra_dosha(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 5: Putra Dosha detection with detailed pattern check."""
    raw, e = _build(birth)
    lagna = e.get("lagna_sign")
    fifth_sign = _nth_sign_from(lagna, 5)
    fifth_lord = SIGN_TO_LORD.get(fifth_sign) if fifth_sign else None
    occupants = _planets_in_house(e, 5)

    detected: List[Dict[str, Any]] = []

    # Pattern: malefic in 5th
    malefics = ["Mars", "Saturn", "Rahu", "Ketu"]
    bad_in_5th = [p for p in occupants if p in malefics]
    if bad_in_5th:
        detected.append({
            "pattern":  "malefic_in_5th",
            "details":  f"Malefic(s) in 5th: {', '.join(bad_in_5th)}",
            "rule":     PUTRA_DOSHA_RULES["malefic_in_5th"]["rule"],
            "effect":   PUTRA_DOSHA_RULES["malefic_in_5th"]["effect"],
            "severity": PUTRA_DOSHA_RULES["malefic_in_5th"]["severity"],
        })

    # Pattern: 5th lord in dushthana
    if fifth_lord:
        fl_data = e.get("planets", {}).get(fifth_lord, {})
        if fl_data.get("house") in (6, 8, 12):
            detected.append({
                "pattern":  "5th_lord_in_dushthana",
                "details":  f"{fifth_lord} (5th lord) in house {fl_data.get('house')}",
                "rule":     PUTRA_DOSHA_RULES["5th_lord_in_dushthana"]["rule"],
                "effect":   PUTRA_DOSHA_RULES["5th_lord_in_dushthana"]["effect"],
                "severity": PUTRA_DOSHA_RULES["5th_lord_in_dushthana"]["severity"],
            })
        if fl_data.get("is_combust") or fl_data.get("dignity") == "debilitated":
            detected.append({
                "pattern":  "5th_lord_combust_or_debilitated",
                "details":  f"{fifth_lord} (5th lord) is {('combust' if fl_data.get('is_combust') else 'debilitated')}",
                "rule":     PUTRA_DOSHA_RULES["5th_lord_combust_or_debilitated"]["rule"],
                "effect":   PUTRA_DOSHA_RULES["5th_lord_combust_or_debilitated"]["effect"],
                "severity": PUTRA_DOSHA_RULES["5th_lord_combust_or_debilitated"]["severity"],
            })

    # Pattern: Jupiter afflicted (primary karaka)
    jup = e.get("planets", {}).get("Jupiter", {})
    jup_afflicted = False
    jup_reasons: List[str] = []
    if jup:
        if jup.get("house") in (6, 8, 12):
            jup_afflicted = True
            jup_reasons.append(f"in dushthana H{jup.get('house')}")
        if jup.get("is_combust"):
            jup_afflicted = True
            jup_reasons.append("combust")
        if jup.get("dignity") == "debilitated":
            jup_afflicted = True
            jup_reasons.append("debilitated")
    if jup_afflicted:
        detected.append({
            "pattern":  "jupiter_afflicted",
            "details":  f"Jupiter (Putra Karaka): {', '.join(jup_reasons)}",
            "rule":     PUTRA_DOSHA_RULES["jupiter_afflicted"]["rule"],
            "effect":   PUTRA_DOSHA_RULES["jupiter_afflicted"]["effect"],
            "severity": PUTRA_DOSHA_RULES["jupiter_afflicted"]["severity"],
        })

    # Pattern: Rahu or Ketu in 5th
    if "Rahu" in occupants or "Ketu" in occupants:
        detected.append({
            "pattern":  "rahu_or_ketu_in_5th",
            "details":  f"Nodes in 5th: {', '.join([p for p in occupants if p in ('Rahu', 'Ketu')])}",
            "rule":     PUTRA_DOSHA_RULES["rahu_or_ketu_in_5th"]["rule"],
            "effect":   PUTRA_DOSHA_RULES["rahu_or_ketu_in_5th"]["effect"],
            "severity": PUTRA_DOSHA_RULES["rahu_or_ketu_in_5th"]["severity"],
        })

    # Severity bucket
    severities = [d["severity"] for d in detected]
    if "high" in severities:
        overall = "high"
    elif severities.count("moderate") >= 2:
        overall = "high"
    elif "moderate" in severities:
        overall = "moderate"
    elif severities:
        overall = "mild"
    else:
        overall = "none"

    return {
        "lagna":               lagna,
        "fifth_sign":          fifth_sign,
        "fifth_lord":          fifth_lord,
        "patterns_detected":   detected,
        "pattern_count":       len(detected),
        "overall_severity":    overall,
        "remedies":            PUTRA_DOSHA_REMEDIES,
        "all_rules_reference": PUTRA_DOSHA_RULES,
        "citation":            CLASSICAL_CITATIONS["putra_dosha"],
    }


def handle_conception_timing(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 3: Conception timing windows based on current/upcoming dashas."""
    raw, e = _build(birth)
    lagna = e.get("lagna_sign")
    fifth_lord = SIGN_TO_LORD.get(_nth_sign_from(lagna, 5))

    # Current dasha info
    current_md = e.get("current_md")
    current_ad = e.get("current_ad")

    # Children-favorable planets
    favorable_planets = set()
    favorable_planets.add(fifth_lord) if fifth_lord else None
    favorable_planets.add("Jupiter")
    favorable_planets.add("Moon")
    favorable_planets.add("Venus")

    # Planets occupying or aspecting 5th (favorable if not heavily afflicted)
    fifth_sign = _nth_sign_from(lagna, 5)
    occupants = _planets_in_house(e, 5)
    for p in occupants:
        if p not in ["Saturn", "Rahu", "Ketu", "Mars"]:
            favorable_planets.add(p)

    # Current dasha favorable?
    current_favorable = (current_md in favorable_planets) or (current_ad in favorable_planets)

    # Build remaining timeline from chart dasha sequence
    dasha_timeline = raw.get("dashas", {}).get("timeline", [])
    upcoming_favorable: List[Dict[str, Any]] = []
    if isinstance(dasha_timeline, list):
        for d in dasha_timeline[:10]:  # first 10 maha-dashas in timeline
            if isinstance(d, dict) and d.get("planet") in favorable_planets:
                upcoming_favorable.append({
                    "planet":     d.get("planet"),
                    "start":      d.get("start"),
                    "end":        d.get("end"),
                    "favorable_reason": (
                        "5th lord MD" if d.get("planet") == fifth_lord else
                        "Putra Karaka (Jupiter)" if d.get("planet") == "Jupiter" else
                        "Moon/Venus supportive"
                    ),
                })

    return {
        "lagna":                  lagna,
        "fifth_lord":             fifth_lord,
        "current_dasha":          {"md": current_md, "ad": current_ad,
                                    "favorable": current_favorable},
        "favorable_planets":      sorted(favorable_planets),
        "upcoming_favorable_md":  upcoming_favorable,
        "indicators":             CONCEPTION_TIMING_PLANETS,
        "note":                   "Favorable dashas of 5th lord, Jupiter, Moon, Venus support conception per classical texts. For exact muhurta timing within a window, use muhurta_pro endpoints with purpose='general' on candidate dates.",
        "citation":               CLASSICAL_CITATIONS["putra_bhava"],
    }


def handle_d7_saptamsha(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 4: D7 Saptamsha — children-specific divisional chart synthesis."""
    raw, e = _build(birth)

    # D7 Lagna
    d7_lagna = raw.get("lagna", {}).get("d7_sign")

    # D7 placements per planet
    d7_placements: Dict[str, Dict[str, Any]] = {}
    for planet, pdata in raw.get("planets", {}).items():
        if isinstance(pdata, dict):
            d7_placements[planet] = {
                "rashi_sign": pdata.get("sign"),
                "d7_sign":    pdata.get("d7_sign"),
            }

    # D7 5th house sign (where children specifically indicated within D7)
    d7_fifth_sign = _nth_sign_from(d7_lagna, 5)
    d7_fifth_lord = SIGN_TO_LORD.get(d7_fifth_sign) if d7_fifth_sign else None
    # Planets in D7 5th
    planets_in_d7_5th = [p for p, data in d7_placements.items() if data["d7_sign"] == d7_fifth_sign]

    # Jupiter's D7 placement (most critical per classical)
    jup_d7 = d7_placements.get("Jupiter", {})

    return {
        "rashi_lagna":          e.get("lagna_sign"),
        "d7_lagna":             d7_lagna,
        "d7_fifth_sign":        d7_fifth_sign,
        "d7_fifth_lord":        d7_fifth_lord,
        "planets_in_d7_5th":    planets_in_d7_5th,
        "jupiter_in_d7":        jup_d7,
        "all_d7_placements":    d7_placements,
        "interpretation_notes": D7_SAPTAMSHA_NOTES,
        "note":                 "Engine returns sign-types (male/female-dominant) only at architectural level. NO gender prediction is supported or claimed per Indian PCPNDT Act and ethical engine policy.",
        "citation":             CLASSICAL_CITATIONS["d7_saptamsha"],
    }


def handle_children_profile(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 1 (MASTER): Children master synthesis."""
    fifth = handle_5th_house_analysis(birth)
    dosha = handle_putra_dosha(birth)
    timing = handle_conception_timing(birth)
    d7 = handle_d7_saptamsha(birth)

    headlines: List[str] = []
    headlines.append(
        f"5th house: {fifth['fifth_sign']} (lord {fifth['fifth_lord']})"
    )
    if fifth["planets_in_5th"]:
        headlines.append(
            f"Planets in 5th: {', '.join(fifth['planets_in_5th'])}"
        )
    if dosha["overall_severity"] != "none":
        headlines.append(
            f"⚠️ Putra Dosha: {dosha['overall_severity']} severity ({dosha['pattern_count']} patterns)"
        )
    else:
        headlines.append("✅ No major Putra Dosha patterns detected")
    if timing["current_dasha"]["favorable"]:
        headlines.append(
            f"✅ Current dasha ({timing['current_dasha']['md']}/{timing['current_dasha']['ad']}) is children-favorable"
        )

    return {
        "headlines":            headlines,
        "fifth_house":          fifth,
        "putra_dosha":          dosha,
        "conception_timing":    timing,
        "d7_saptamsha":         d7,
        "karakas":              PUTRA_KARAKAS,
        "method":               "Synthesis of 5th house + Jupiter karaka + D7 Saptamsha + dasha timing per BPHS Ch. 28 and Saravali Ch. 35",
        "citation":             CLASSICAL_CITATIONS["putra_bhava"],
    }


# ════════════════════════════════════════════════════════════════════════
# EDUCATION ENDPOINTS
# ════════════════════════════════════════════════════════════════════════

def handle_4th_5th_synthesis(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 7: 2/4/5/9 house education synthesis."""
    raw, e = _build(birth)
    lagna = e.get("lagna_sign")

    house_analysis: Dict[int, Dict[str, Any]] = {}
    for h in [2, 4, 5, 9, 11]:
        h_sign = _nth_sign_from(lagna, h)
        h_lord = SIGN_TO_LORD.get(h_sign) if h_sign else None
        lord_data = e.get("planets", {}).get(h_lord, {}) if h_lord else {}
        occupants = _planets_in_house(e, h)
        house_analysis[h] = {
            "sign":           h_sign,
            "lord":           h_lord,
            "lord_house":     lord_data.get("house") if isinstance(lord_data, dict) else None,
            "lord_dignity":   lord_data.get("dignity") if isinstance(lord_data, dict) else None,
            "occupants":      occupants,
            "role":           EDUCATION_HOUSES.get(h, ""),
        }

    # Detect Saraswati Yoga: Mercury + Jupiter + Venus in kendras
    kendra_houses = {1, 4, 7, 10}
    merc_house = e.get("planets", {}).get("Mercury", {}).get("house")
    jup_house = e.get("planets", {}).get("Jupiter", {}).get("house")
    ven_house = e.get("planets", {}).get("Venus", {}).get("house")
    saraswati_yoga = (merc_house in kendra_houses
                      and jup_house in kendra_houses
                      and ven_house in kendra_houses)

    # Detect Budhaditya Yoga: Sun + Mercury conjunction
    sun_house = e.get("planets", {}).get("Sun", {}).get("house")
    sun_sign = e.get("planets", {}).get("Sun", {}).get("sign")
    merc_sign = e.get("planets", {}).get("Mercury", {}).get("sign")
    budhaditya_yoga = (sun_sign and merc_sign and sun_sign == merc_sign)

    yogas_detected: List[Dict[str, str]] = []
    if saraswati_yoga:
        yogas_detected.append({
            "name":         "Saraswati Yoga",
            "rule":         "Mercury + Jupiter + Venus all in kendras",
            "effect":       "Major learning yoga — scholarly aptitude, intellectual recognition",
        })
    if budhaditya_yoga:
        yogas_detected.append({
            "name":         "Budhaditya Yoga",
            "rule":         "Sun + Mercury conjunction",
            "effect":       "Intellectual recognition, sharp intelligence, success in education through ability",
        })

    return {
        "lagna":          lagna,
        "houses":         house_analysis,
        "education_planets": EDUCATION_PLANETS,
        "yogas_detected": yogas_detected,
        "success_indicators_to_check": EDUCATION_SUCCESS_INDICATORS,
        "citation":       CLASSICAL_CITATIONS["education"],
    }


def handle_foreign_study_yoga(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 8: Foreign education yoga detection."""
    raw, e = _build(birth)
    lagna = e.get("lagna_sign")
    fourth_sign = _nth_sign_from(lagna, 4)
    ninth_sign = _nth_sign_from(lagna, 9)
    twelfth_sign = _nth_sign_from(lagna, 12)
    fourth_lord = SIGN_TO_LORD.get(fourth_sign) if fourth_sign else None
    ninth_lord = SIGN_TO_LORD.get(ninth_sign) if ninth_sign else None
    twelfth_lord = SIGN_TO_LORD.get(twelfth_sign) if twelfth_sign else None

    planets = e.get("planets", {})

    detected: List[Dict[str, Any]] = []

    # Pattern 1: Rahu in 4th or 9th
    rahu_house = planets.get("Rahu", {}).get("house")
    if rahu_house in (4, 9):
        detected.append({
            "pattern":     "rahu_4th_or_9th",
            "details":     f"Rahu in {rahu_house}th house",
            **FOREIGN_STUDY_PATTERNS["rahu_4th_or_9th"],
        })

    # Pattern 2: 4th lord in 12th
    fl_house = planets.get(fourth_lord, {}).get("house") if fourth_lord else None
    if fl_house == 12:
        detected.append({
            "pattern":     "4th_lord_in_12th",
            "details":     f"{fourth_lord} (4th lord) in 12th house",
            **FOREIGN_STUDY_PATTERNS["4th_lord_in_12th"],
        })

    # Pattern 3: 9th lord in 12th or with Rahu
    nl_data = planets.get(ninth_lord, {}) if ninth_lord else {}
    nl_house = nl_data.get("house")
    nl_sign = nl_data.get("sign")
    rahu_sign = planets.get("Rahu", {}).get("sign")
    if nl_house == 12 or (nl_sign and nl_sign == rahu_sign):
        detected.append({
            "pattern":     "9th_lord_in_12th_or_with_rahu",
            "details":     f"{ninth_lord} (9th lord) in 12th: {nl_house == 12}, with Rahu: {nl_sign == rahu_sign}",
            **FOREIGN_STUDY_PATTERNS["9th_lord_in_12th_or_with_rahu"],
        })

    # Pattern 4: Moon + Jupiter in 4th or 9th together
    moon_house = planets.get("Moon", {}).get("house")
    jup_house = planets.get("Jupiter", {}).get("house")
    if moon_house in (4, 9) and jup_house == moon_house:
        detected.append({
            "pattern":     "moon_jupiter_4th_or_9th",
            "details":     f"Moon + Jupiter both in H{moon_house}",
            **FOREIGN_STUDY_PATTERNS["moon_jupiter_4th_or_9th"],
        })

    # Pattern 5: 12th lord well-placed in kendra
    twl_data = planets.get(twelfth_lord, {}) if twelfth_lord else {}
    twl_house = twl_data.get("house")
    if twl_house in (1, 4, 7, 10):
        detected.append({
            "pattern":     "12th_lord_strong_in_kendra",
            "details":     f"{twelfth_lord} (12th lord) in kendra H{twl_house}",
            **FOREIGN_STUDY_PATTERNS["12th_lord_strong_in_kendra"],
        })

    # Pattern 6: Mercury/Jupiter in 12th
    for planet in ["Mercury", "Jupiter"]:
        p_data = planets.get(planet, {})
        if p_data.get("house") == 12 and p_data.get("dignity") in ("exalted", "own", "moolatrikona", "friend", "great_friend"):
            detected.append({
                "pattern":     f"{planet.lower()}_in_12th",
                "details":     f"{planet} in 12th with dignity '{p_data.get('dignity')}'",
                **FOREIGN_STUDY_PATTERNS["mercury_or_jupiter_in_12th"],
            })

    # Strength rollup
    strength_score = 0
    for d in detected:
        s = d.get("strength", "moderate")
        if s == "very_strong": strength_score += 3
        elif s == "strong":    strength_score += 2
        elif s == "moderate":  strength_score += 1

    if strength_score >= 5:
        verdict = "very strong — foreign education highly indicated"
    elif strength_score >= 3:
        verdict = "strong — foreign education indications present"
    elif strength_score >= 1:
        verdict = "moderate — partial foreign education yoga"
    else:
        verdict = "none — classical foreign-study yogas not active in this chart"

    return {
        "lagna":               lagna,
        "fourth_sign":         fourth_sign, "fourth_lord":   fourth_lord,
        "ninth_sign":          ninth_sign,  "ninth_lord":    ninth_lord,
        "twelfth_sign":        twelfth_sign,"twelfth_lord":  twelfth_lord,
        "patterns_detected":   detected,
        "pattern_count":       len(detected),
        "strength_score":      strength_score,
        "verdict":             verdict,
        "all_patterns_reference": FOREIGN_STUDY_PATTERNS,
        "citation":            CLASSICAL_CITATIONS["foreign_study"],
    }


def handle_education_profile(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 6 (MASTER): Education master synthesis."""
    synth = handle_4th_5th_synthesis(birth)
    foreign = handle_foreign_study_yoga(birth)

    # Direct strength checks
    raw, e = _build(birth)
    merc = e.get("planets", {}).get("Mercury", {})
    jup = e.get("planets", {}).get("Jupiter", {})

    headlines: List[str] = []
    headlines.append(
        f"Mercury: {merc.get('sign')} H{merc.get('house')} ({merc.get('dignity')})"
    )
    headlines.append(
        f"Jupiter: {jup.get('sign')} H{jup.get('house')} ({jup.get('dignity')})"
    )
    if synth["yogas_detected"]:
        headlines.append(
            f"Education yogas detected: {[y['name'] for y in synth['yogas_detected']]}"
        )
    headlines.append(
        f"Foreign study: {foreign['verdict']}"
    )

    return {
        "headlines":              headlines,
        "house_synthesis":        synth,
        "foreign_study":          foreign,
        "key_planets": {
            "Mercury": {"sign": merc.get("sign"), "house": merc.get("house"),
                        "dignity": merc.get("dignity"),
                        "is_combust": merc.get("is_combust", False)},
            "Jupiter": {"sign": jup.get("sign"), "house": jup.get("house"),
                        "dignity": jup.get("dignity")},
        },
        "education_planets":      EDUCATION_PLANETS,
        "education_houses":       EDUCATION_HOUSES,
        "method":                 "Synthesis of 2/4/5/9 houses + Mercury/Jupiter/Sun karakas + Saraswati/Budhaditya yoga detection + foreign-study yoga patterns",
        "citation":               CLASSICAL_CITATIONS["education"],
    }
