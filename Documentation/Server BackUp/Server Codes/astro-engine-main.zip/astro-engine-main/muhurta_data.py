"""
muhurta_data.py — Classical Vedic electional astrology (Muhurta Pro) reference data.

Phase C — Module C3 (Muhurta Pro).

Public catalogs:
    PURPOSE_RULES          — Per-purpose scoring rules (marriage, business, etc.)
    WEEKDAY_SUITABILITY    — Day-of-week scoring per purpose
    TITHI_SUITABILITY      — Lunar-day scoring (favorable/unfavorable tithis)
    NAKSHATRA_SUITABILITY  — Per-purpose nakshatra favorability
    AVOID_YOGAS            — Inauspicious time bands (Bhadra, Vyatipata, Vaidhriti)
    LAGNA_SUITABILITY      — Rising-sign suitability per purpose
    CLASSICAL_CITATIONS

Primary sources: Muhurta Chintamani (Rama Daivajna, ~17th c. CE),
                 Muhurta Martanda, Muhurta Ganapati, Daivajna Mukha Mandana.
All public domain.
"""

from typing import Dict, List


# ════════════════════════════════════════════════════════════════════════
# PURPOSE_RULES — Per-purpose electional weight allocation
# Each purpose has a 100-point scoring scheme distributing across:
#   weekday (15-25%), tithi (10-20%), nakshatra (20-30%),
#   lagna (15-25%), moon_strength (10-15%), avoidance_clear (5-15%)
# ════════════════════════════════════════════════════════════════════════

PURPOSE_RULES: Dict[str, Dict[str, int]] = {
    "marriage": {
        "weekday":         15,
        "tithi":           15,
        "nakshatra":       25,
        "lagna":           20,
        "moon_strength":   15,
        "avoidance_clear": 10,
    },
    "business": {
        "weekday":         20,
        "tithi":           10,
        "nakshatra":       20,
        "lagna":           25,
        "moon_strength":   15,
        "avoidance_clear": 10,
    },
    "travel": {
        "weekday":         25,
        "tithi":           10,
        "nakshatra":       25,
        "lagna":           15,
        "moon_strength":   15,
        "avoidance_clear": 10,
    },
    "property": {
        "weekday":         15,
        "tithi":           15,
        "nakshatra":       25,
        "lagna":           20,
        "moon_strength":   15,
        "avoidance_clear": 10,
    },
    "medical": {
        "weekday":         20,
        "tithi":           15,
        "nakshatra":       20,
        "lagna":           20,
        "moon_strength":   15,
        "avoidance_clear": 10,
    },
    "general": {
        "weekday":         15,
        "tithi":           15,
        "nakshatra":       20,
        "lagna":           20,
        "moon_strength":   20,
        "avoidance_clear": 10,
    },
}


# ════════════════════════════════════════════════════════════════════════
# WEEKDAY SUITABILITY — 7 days × 6 purposes, 0-100 scale
# Source: Muhurta Chintamani Ch. 2 (Vara Phala)
# Day = Python weekday(): Mon=0, Tue=1, ..., Sun=6
# ════════════════════════════════════════════════════════════════════════

# Day → planet mapping (already in varshaphala_data; redeclared for clarity)
DAY_TO_PLANET: Dict[int, str] = {
    0: "Moon",  1: "Mars",   2: "Mercury", 3: "Jupiter",
    4: "Venus", 5: "Saturn", 6: "Sun",
}
DAY_NAMES: Dict[int, str] = {
    0: "Monday", 1: "Tuesday", 2: "Wednesday", 3: "Thursday",
    4: "Friday", 5: "Saturday", 6: "Sunday",
}

WEEKDAY_SUITABILITY: Dict[str, Dict[int, int]] = {
    "marriage": {
        0: 70,   # Monday (Moon) — favorable
        1: 30,   # Tuesday (Mars) — generally avoided
        2: 80,   # Wednesday (Mercury) — favorable
        3: 95,   # Thursday (Jupiter) — most favorable
        4: 90,   # Friday (Venus) — highly favorable
        5: 30,   # Saturday (Saturn) — avoided
        6: 40,   # Sunday (Sun) — not preferred
    },
    "business": {
        0: 60, 1: 50, 2: 90, 3: 90, 4: 75, 5: 40, 6: 60,
    },
    "travel": {
        0: 75, 1: 50, 2: 80, 3: 80, 4: 50, 5: 30, 6: 50,
    },
    "property": {
        0: 75, 1: 30, 2: 70, 3: 90, 4: 90, 5: 40, 6: 50,
    },
    "medical": {
        0: 80, 1: 60, 2: 75, 3: 85, 4: 75, 5: 30, 6: 50,
    },
    "general": {
        0: 70, 1: 50, 2: 80, 3: 85, 4: 80, 5: 40, 6: 55,
    },
}


# ════════════════════════════════════════════════════════════════════════
# TITHI SUITABILITY — 30 tithis × purposes
# Nanda (1,6,11), Bhadra (2,7,12), Jaya (3,8,13), Rikta (4,9,14), Purna (5,10,15)
# Plus same pattern in dark fortnight (16-30)
# Source: Muhurta Chintamani Ch. 3 (Tithi Phala)
# ════════════════════════════════════════════════════════════════════════

# Tithi class for tithis 1-15 (same pattern repeats for 16-30 Krishna paksha)
TITHI_CLASS: Dict[int, str] = {}
for _t in range(1, 31):
    base = ((_t - 1) % 15) + 1
    if base in (1, 6, 11):     TITHI_CLASS[_t] = "Nanda"
    elif base in (2, 7, 12):   TITHI_CLASS[_t] = "Bhadra"
    elif base in (3, 8, 13):   TITHI_CLASS[_t] = "Jaya"
    elif base in (4, 9, 14):   TITHI_CLASS[_t] = "Rikta"
    elif base in (5, 10, 15):  TITHI_CLASS[_t] = "Purna"

# Tithi-class suitability per purpose (0-100 scale)
TITHI_CLASS_SUITABILITY: Dict[str, Dict[str, int]] = {
    "marriage": {
        "Nanda":  60,   # ok
        "Bhadra": 80,   # good
        "Jaya":   90,   # very good
        "Rikta":  20,   # avoided
        "Purna":  85,   # excellent for completion-like marriage rites
    },
    "business": {
        "Nanda":  70, "Bhadra": 75, "Jaya": 85, "Rikta": 30, "Purna": 80,
    },
    "travel": {
        "Nanda":  75, "Bhadra": 70, "Jaya": 80, "Rikta": 40, "Purna": 60,
    },
    "property": {
        "Nanda":  65, "Bhadra": 80, "Jaya": 85, "Rikta": 25, "Purna": 90,
    },
    "medical": {
        "Nanda":  60, "Bhadra": 80, "Jaya": 85, "Rikta": 50, "Purna": 80,
    },
    "general": {
        "Nanda":  65, "Bhadra": 75, "Jaya": 85, "Rikta": 30, "Purna": 80,
    },
}

# Always-avoid tithis (special classical reservations)
AMAVASYA_TITHI = 30  # New Moon — most activities avoided
PURNIMA_TITHI = 15   # Full Moon — favored for many; mixed for marriage
ASHTAMI_TITHIS = [8, 23]    # 8th and 23rd often avoided
CHATURDASHI_TITHIS = [14, 29]   # 14th and 29th often avoided


# ════════════════════════════════════════════════════════════════════════
# NAKSHATRA SUITABILITY — per-purpose favorability
# Source: Muhurta Chintamani Ch. 4 (Nakshatra Phala for various acts)
# Categories: very_favorable (95), favorable (75), neutral (50), avoid (15)
# ════════════════════════════════════════════════════════════════════════

NAKSHATRA_SUITABILITY: Dict[str, Dict[str, int]] = {
    "marriage": {
        # Classically favored: Rohini, Mrigashira, Magha, Uttara Phalguni,
        # Hasta, Swati, Anuradha, Mula, Uttara Ashadha, Uttara Bhadrapada, Revati
        "Rohini": 95, "Mrigashira": 90, "Magha": 80, "Uttara Phalguni": 95,
        "Hasta": 90, "Swati": 85, "Anuradha": 90, "Mula": 75,
        "Uttara Ashadha": 95, "Uttara Bhadrapada": 95, "Revati": 90,
        # Generally avoided: Bharani, Krittika, Ardra, Ashlesha, Purva Phalguni,
        # Chitra, Vishakha, Jyeshtha, Dhanishta, Shatabhisha, Purva Bhadrapada,
        # Purva Ashadha — variable
        "Bharani": 30, "Krittika": 25, "Ardra": 20, "Ashlesha": 20,
        "Purva Phalguni": 55, "Chitra": 60, "Vishakha": 45, "Jyeshtha": 30,
        "Dhanishta": 60, "Shatabhisha": 50, "Purva Bhadrapada": 50,
        "Purva Ashadha": 60,
        "Ashwini": 65, "Punarvasu": 70, "Pushya": 75, "Shravana": 75,
    },
    "business": {
        "Pushya": 95, "Ashwini": 85, "Hasta": 95, "Chitra": 80,
        "Punarvasu": 80, "Mrigashira": 85, "Uttara Phalguni": 90,
        "Uttara Ashadha": 90, "Uttara Bhadrapada": 90, "Rohini": 85,
        "Magha": 75, "Anuradha": 85, "Revati": 80, "Shravana": 85,
        "Swati": 75, "Dhanishta": 80,
        # Avoid: Bharani, Krittika, Ardra, Ashlesha, Jyeshtha, Mula
        "Bharani": 30, "Krittika": 35, "Ardra": 25, "Ashlesha": 25,
        "Jyeshtha": 30, "Mula": 35, "Purva Phalguni": 50,
        "Vishakha": 55, "Purva Ashadha": 60, "Shatabhisha": 60,
        "Purva Bhadrapada": 50,
    },
    "travel": {
        "Ashwini": 95, "Pushya": 95, "Hasta": 90, "Punarvasu": 90,
        "Mrigashira": 85, "Anuradha": 80, "Shravana": 85, "Dhanishta": 80,
        "Revati": 90, "Swati": 85, "Uttara Phalguni": 80,
        "Uttara Ashadha": 75, "Uttara Bhadrapada": 75, "Chitra": 70,
        "Rohini": 70, "Magha": 65, "Vishakha": 65,
        # Avoid: Bharani, Krittika, Ardra, Ashlesha, Purva Phalguni,
        # Jyeshtha, Mula, Purva Ashadha
        "Bharani": 25, "Krittika": 30, "Ardra": 20, "Ashlesha": 25,
        "Purva Phalguni": 30, "Jyeshtha": 25, "Mula": 30,
        "Purva Ashadha": 35, "Shatabhisha": 50, "Purva Bhadrapada": 45,
    },
    "property": {
        "Rohini": 95, "Mrigashira": 85, "Hasta": 90, "Anuradha": 85,
        "Uttara Phalguni": 95, "Uttara Ashadha": 95, "Uttara Bhadrapada": 95,
        "Pushya": 90, "Magha": 80, "Revati": 80, "Chitra": 80,
        "Punarvasu": 75, "Swati": 75, "Shravana": 80, "Dhanishta": 70,
        "Ashwini": 65, "Vishakha": 65,
        "Bharani": 25, "Krittika": 30, "Ardra": 20, "Ashlesha": 25,
        "Purva Phalguni": 50, "Jyeshtha": 30, "Mula": 35,
        "Purva Ashadha": 55, "Shatabhisha": 55, "Purva Bhadrapada": 50,
    },
    "medical": {
        "Ashwini": 95, "Pushya": 90, "Hasta": 95, "Mrigashira": 80,
        "Revati": 90, "Punarvasu": 80, "Shravana": 85, "Anuradha": 80,
        "Swati": 75, "Chitra": 70, "Uttara Phalguni": 85, "Rohini": 75,
        "Uttara Ashadha": 80, "Uttara Bhadrapada": 80,
        "Bharani": 30, "Krittika": 35, "Ardra": 25, "Ashlesha": 30,
        "Magha": 55, "Purva Phalguni": 50, "Vishakha": 60, "Jyeshtha": 30,
        "Mula": 35, "Purva Ashadha": 55, "Dhanishta": 70,
        "Shatabhisha": 80,  # Shatabhisha = healing nakshatra (Varuna)
        "Purva Bhadrapada": 50,
    },
    "general": {
        "Ashwini": 75, "Bharani": 35, "Krittika": 40, "Rohini": 85,
        "Mrigashira": 80, "Ardra": 30, "Punarvasu": 80, "Pushya": 90,
        "Ashlesha": 30, "Magha": 70, "Purva Phalguni": 55,
        "Uttara Phalguni": 85, "Hasta": 90, "Chitra": 75, "Swati": 80,
        "Vishakha": 60, "Anuradha": 80, "Jyeshtha": 35, "Mula": 40,
        "Purva Ashadha": 60, "Uttara Ashadha": 85, "Shravana": 80,
        "Dhanishta": 70, "Shatabhisha": 65, "Purva Bhadrapada": 55,
        "Uttara Bhadrapada": 85, "Revati": 80,
    },
}


# ════════════════════════════════════════════════════════════════════════
# LAGNA SUITABILITY — Per purpose, score each rising sign
# Source: Muhurta Chintamani Ch. 5 (Lagna Shuddhi)
# ════════════════════════════════════════════════════════════════════════

LAGNA_SUITABILITY: Dict[str, Dict[str, int]] = {
    "marriage": {
        # Best: Taurus, Gemini, Cancer, Leo, Virgo, Libra
        # Per Muhurta Chintamani Vivaha Prakarana, fixed and dual signs preferred
        "Aries": 60, "Taurus": 90, "Gemini": 85, "Cancer": 80,
        "Leo": 90, "Virgo": 90, "Libra": 95, "Scorpio": 60,
        "Sagittarius": 85, "Capricorn": 75, "Aquarius": 70, "Pisces": 80,
    },
    "business": {
        # Fixed signs (Taurus, Leo, Scorpio, Aquarius) preferred for stability
        "Aries": 60, "Taurus": 90, "Gemini": 75, "Cancer": 70,
        "Leo": 90, "Virgo": 80, "Libra": 80, "Scorpio": 80,
        "Sagittarius": 75, "Capricorn": 85, "Aquarius": 90, "Pisces": 65,
    },
    "travel": {
        # Movable signs (Aries, Cancer, Libra, Capricorn) preferred for travel
        "Aries": 90, "Taurus": 60, "Gemini": 75, "Cancer": 85,
        "Leo": 55, "Virgo": 70, "Libra": 90, "Scorpio": 55,
        "Sagittarius": 85, "Capricorn": 90, "Aquarius": 55, "Pisces": 70,
    },
    "property": {
        # Fixed signs preferred
        "Aries": 50, "Taurus": 95, "Gemini": 65, "Cancer": 75,
        "Leo": 90, "Virgo": 80, "Libra": 70, "Scorpio": 90,
        "Sagittarius": 65, "Capricorn": 85, "Aquarius": 90, "Pisces": 65,
    },
    "medical": {
        # Watery signs (Cancer, Scorpio, Pisces) for healing
        "Aries": 60, "Taurus": 75, "Gemini": 70, "Cancer": 90,
        "Leo": 65, "Virgo": 90, "Libra": 75, "Scorpio": 85,
        "Sagittarius": 75, "Capricorn": 65, "Aquarius": 70, "Pisces": 90,
    },
    "general": {
        "Aries": 70, "Taurus": 80, "Gemini": 75, "Cancer": 75,
        "Leo": 75, "Virgo": 80, "Libra": 80, "Scorpio": 70,
        "Sagittarius": 80, "Capricorn": 75, "Aquarius": 75, "Pisces": 75,
    },
}


# ════════════════════════════════════════════════════════════════════════
# AVOID YOGAS — Inauspicious time bands present at a moment
# Engine returns whether these are flagged (true = avoid)
# Source: Muhurta Chintamani Ch. 6 (Inauspicious Yogas)
# ════════════════════════════════════════════════════════════════════════

# These require Sun-Moon longitudinal sum to fall in specific ranges
# Simplified rules — engine flags but does not exhaustively compute every one
AVOID_YOGAS_DEFINITIONS: Dict[str, str] = {
    "Vyatipata":  "Sun + Moon longitudes sum to 180° in specific nakshatra cluster",
    "Vaidhriti":  "Sun + Moon longitudes sum to 360° in specific cluster",
    "Bhadra":     "2nd, 7th, 8th, 13th tithi second-half + specific karana",
    "Visti":      "Same as Bhadra (alternate name)",
    "Krishna_Paksha_Chaturdashi": "14th tithi of dark fortnight",
    "Amavasya":   "30th tithi (new moon)",
    "Kshaya":     "Lunar month shorter than usual",
}

# Tithi-based avoid markers
TITHI_AVOID_FOR_PURPOSE: Dict[str, List[int]] = {
    "marriage": [4, 9, 14, 19, 24, 29, 30],  # Rikta + last + Amavasya
    "business": [4, 9, 14, 30],
    "travel":   [4, 9, 14, 30],
    "property": [4, 9, 14, 19, 24, 29, 30],
    "medical":  [30],  # Amavasya avoided; others context-dependent
    "general":  [4, 9, 14, 30],
}


# ════════════════════════════════════════════════════════════════════════
# SCORE INTERPRETATION
# ════════════════════════════════════════════════════════════════════════

SCORE_INTERPRETATION: Dict[str, str] = {
    "excellent":  "85-100 — exceptional muhurta; proceed with confidence",
    "good":       "70-84 — favorable; proceed with usual precautions",
    "acceptable": "55-69 — acceptable; minor concerns may be present",
    "marginal":   "40-54 — marginal; consider alternative timing if possible",
    "avoid":      "<40 — classically inauspicious; recommend alternative window",
}


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "muhurta":     "Muhurta Chintamani (Rama Daivajna, ~17th c. CE); Muhurta Martanda; Muhurta Ganapati",
    "weekday":     "Muhurta Chintamani Ch. 2 (Vara Phala)",
    "tithi":       "Muhurta Chintamani Ch. 3 (Tithi Phala)",
    "nakshatra":   "Muhurta Chintamani Ch. 4 (Nakshatra Phala); BPHS Ch. 99",
    "lagna":       "Muhurta Chintamani Ch. 5 (Lagna Shuddhi)",
    "avoidances":  "Muhurta Chintamani Ch. 6 (Yogas to avoid); Daivajna Mukha Mandana",
    "marriage":    "Muhurta Chintamani — Vivaha Prakarana; classical marriage Muhurta tradition",
    "business":    "Muhurta Chintamani — Karyarambh Prakarana; classical business inception tradition",
    "travel":      "Muhurta Chintamani — Yatra Prakarana",
    "property":    "Muhurta Chintamani — Griha Prakarana (Vastu Pravesh)",
    "medical":     "Muhurta Chintamani — Aushadha Prakarana; Sushruta Samhita on procedure timing",
}
