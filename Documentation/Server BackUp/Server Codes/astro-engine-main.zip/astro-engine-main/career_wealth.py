"""
career_wealth.py — Career + Wealth Analysis Engine (Module B2)

Architecture:
- Uses astro_helpers for shared chart extraction
- 12 endpoints across career (profile, D10, karakas, fields, timing, dasha)
  and wealth (profile, dhana yogas, income sources, risk, windows, remedies)

Classical sources cited per function.
"""

from typing import Dict, List, Optional, Any
from datetime import datetime

from astro_helpers import (
    extract_chart_essentials,
    get_chart,
    afflicted_planets,
    weakest_planet,
    SIGNS_ORDER,
    SIGN_TO_LORD,
)

from career_wealth_data import (
    CAREER_FIELDS_BY_PLANET,
    CAREER_HOUSES,
    DHANA_YOGAS,
    RAJA_YOGAS,
    INCOME_SOURCES_BY_11TH_LORD,
    WEALTH_RISK_INDICATORS,
    INCOME_TIMING_BY_DASHA,
    WEALTH_REMEDIES,
    D10_ANALYSIS_PRINCIPLES,
)


# ════════════════════════════════════════════════════════════════════════
# YOGA DETECTION HELPERS
# ════════════════════════════════════════════════════════════════════════

def _planets_in_house(ch: Dict, house: int) -> List[str]:
    """Return list of planet names in a given house."""
    return [p for p, pd in ch["planets"].items() if pd.get("house") == house]


def _planet_in_kendra(ch: Dict, planet: str) -> bool:
    """True if planet is in 1/4/7/10."""
    pdata = ch["planets"].get(planet, {})
    return pdata.get("house") in (1, 4, 7, 10)


def _planet_in_trikona(ch: Dict, planet: str) -> bool:
    """True if planet is in 1/5/9."""
    pdata = ch["planets"].get(planet, {})
    return pdata.get("house") in (1, 5, 9)


def _planets_conjoined(ch: Dict, p1: str, p2: str) -> bool:
    """True if two planets are in same sign."""
    pd1 = ch["planets"].get(p1, {})
    pd2 = ch["planets"].get(p2, {})
    return pd1.get("sign") and pd1.get("sign") == pd2.get("sign")


def _is_own_or_exalted(ch: Dict, planet: str) -> bool:
    """Check if planet is in own sign, moolatrikona, or exalted."""
    dignity = ch["planets"].get(planet, {}).get("dignity", "")
    return dignity in ("own_sign", "moolatrikona", "exalted")


def _detect_dhana_yogas(ch: Dict) -> List[Dict]:
    """Detect classical dhana yogas in chart."""
    found = []

    # Lakshmi Yoga — 9th lord in own/exalted + Lagna lord strong
    ninth_lord = ch["house_lords"].get(9)
    lagna_lord = ch["lagna_lord"]
    if ninth_lord and _is_own_or_exalted(ch, ninth_lord) and lagna_lord and _is_own_or_exalted(ch, lagna_lord):
        found.append({
            "name":   DHANA_YOGAS["yogas"]["lakshmi_yoga"]["name"],
            "rule":   DHANA_YOGAS["yogas"]["lakshmi_yoga"]["rule"],
            "effect": DHANA_YOGAS["yogas"]["lakshmi_yoga"]["effect"],
            "trigger":f"9th lord {ninth_lord} and Lagna lord {lagna_lord} both in own/exalted dignity",
        })

    # Kuber Yoga — 2nd lord and 11th lord in same kendra (or same planet ruling both)
    second_lord = ch["house_lords"].get(2)
    eleventh_lord = ch["house_lords"].get(11)

    # CASE A: Same planet rules both 2nd and 11th — automatic dhana indicator
    if second_lord and eleventh_lord and second_lord == eleventh_lord:
        lord_house = ch["planets"].get(second_lord, {}).get("house")
        lord_dignity = ch["planets"].get(second_lord, {}).get("dignity", "")
        # Classical: same planet ruling 2nd + 11th is itself a wealth yoga (Saraswati/single-lord dhana)
        is_in_dushthana = lord_house in (6, 8, 12)
        found.append({
            "name":   "Single-Lord Wealth Yoga (2nd = 11th lord)",
            "rule":   "When a single planet rules both 2nd (dhana) and 11th (laabha) houses",
            "effect": f"Wealth flow concentrated through one planet ({second_lord}). Strength depends on planet's placement.",
            "trigger":f"{second_lord} rules both 2nd and 11th, placed in house {lord_house} (dignity: {lord_dignity})",
            "strength_note": f"{'Weakened — lord in dushthana' if is_in_dushthana else 'Active — lord in good placement'}",
        })

    # CASE B: Different planets, conjoined in kendra (classical Kuber)
    if second_lord and eleventh_lord and second_lord != eleventh_lord:
        if _planets_conjoined(ch, second_lord, eleventh_lord):
            second_lord_house = ch["planets"].get(second_lord, {}).get("house")
            if second_lord_house in (1, 4, 7, 10):
                found.append({
                    "name":   DHANA_YOGAS["yogas"]["kuber_yoga"]["name"],
                    "rule":   DHANA_YOGAS["yogas"]["kuber_yoga"]["rule"],
                    "effect": DHANA_YOGAS["yogas"]["kuber_yoga"]["effect"],
                    "trigger":f"2nd lord {second_lord} and 11th lord {eleventh_lord} conjoined in house {second_lord_house}",
                })

    # Chandra-Mangala — Moon + Mars conjunction
    if _planets_conjoined(ch, "Moon", "Mars"):
        moon_house = ch["planets"].get("Moon", {}).get("house")
        found.append({
            "name":   DHANA_YOGAS["yogas"]["chandra_mangala_yoga"]["name"],
            "rule":   DHANA_YOGAS["yogas"]["chandra_mangala_yoga"]["rule"],
            "effect": DHANA_YOGAS["yogas"]["chandra_mangala_yoga"]["effect"],
            "trigger":f"Moon and Mars conjoined in house {moon_house}",
        })

    # Guru-Mangala — Jupiter + Mars conjunction
    if _planets_conjoined(ch, "Jupiter", "Mars"):
        jup_house = ch["planets"].get("Jupiter", {}).get("house")
        found.append({
            "name":   DHANA_YOGAS["yogas"]["guru_mangala_yoga"]["name"],
            "rule":   DHANA_YOGAS["yogas"]["guru_mangala_yoga"]["rule"],
            "effect": DHANA_YOGAS["yogas"]["guru_mangala_yoga"]["effect"],
            "trigger":f"Jupiter and Mars conjoined in house {jup_house}",
        })

    # Shukra-Guru — Venus + Jupiter (Lakshmi-Narayana)
    if _planets_conjoined(ch, "Venus", "Jupiter"):
        ven_house = ch["planets"].get("Venus", {}).get("house")
        found.append({
            "name":   DHANA_YOGAS["yogas"]["shukra_guru_yoga"]["name"],
            "rule":   DHANA_YOGAS["yogas"]["shukra_guru_yoga"]["rule"],
            "effect": DHANA_YOGAS["yogas"]["shukra_guru_yoga"]["effect"],
            "trigger":f"Venus and Jupiter conjoined in house {ven_house}",
        })

    # Vipreet Raja Yoga — 6/8/12 lords conjoined or exchange (simplified detection)
    sixth_lord = ch["house_lords"].get(6)
    eighth_lord = ch["house_lords"].get(8)
    twelfth_lord = ch["house_lords"].get(12)
    dushthana_lords = [l for l in (sixth_lord, eighth_lord, twelfth_lord) if l]

    # CASE A: Two dushthana lords conjoined
    if len(dushthana_lords) >= 2:
        for i, l1 in enumerate(dushthana_lords):
            for l2 in dushthana_lords[i+1:]:
                if l1 != l2 and _planets_conjoined(ch, l1, l2):
                    found.append({
                        "name":   DHANA_YOGAS["yogas"]["vipreet_raja_yoga"]["name"],
                        "rule":   DHANA_YOGAS["yogas"]["vipreet_raja_yoga"]["rule"],
                        "effect": DHANA_YOGAS["yogas"]["vipreet_raja_yoga"]["effect"],
                        "trigger":f"Dushthana lords {l1} and {l2} conjoined",
                    })

    # CASE B: Dushthana lord placed in another dushthana house (classical Vipreet form)
    # Lord of 6 in 8/12, Lord of 8 in 6/12, Lord of 12 in 6/8
    vipreet_placements = {
        sixth_lord:   {"home": 6, "elsewhere": (8, 12)},
        eighth_lord:  {"home": 8, "elsewhere": (6, 12)},
        twelfth_lord: {"home": 12, "elsewhere": (6, 8)},
    }
    seen_vipreet = set()
    for lord, info in vipreet_placements.items():
        if not lord: continue
        lord_house = ch["planets"].get(lord, {}).get("house")
        if lord_house in info["elsewhere"]:
            key = f"{lord}_h{lord_house}"
            if key in seen_vipreet: continue
            seen_vipreet.add(key)
            found.append({
                "name":   DHANA_YOGAS["yogas"]["vipreet_raja_yoga"]["name"] + " (simple form)",
                "rule":   "Dushthana lord placed in another dushthana house (without benefic conjunction)",
                "effect": "Transformation of difficulty into rise — Vipreet Raja Yoga via 'enemy of enemy' principle",
                "trigger":f"Lord of {info['home']} ({lord}) placed in dushthana house {lord_house}",
            })

    return found


def _detect_raja_yogas(ch: Dict) -> List[Dict]:
    """Detect classical raja yogas in chart."""
    found = []

    # Panch Mahapurusha Yogas
    mahapurusha_map = {
        "Mars":    "panch_mahapurusha_ruchaka",
        "Mercury": "panch_mahapurusha_bhadra",
        "Jupiter": "panch_mahapurusha_hamsa",
        "Venus":   "panch_mahapurusha_malavya",
        "Saturn":  "panch_mahapurusha_sasha",
    }
    for planet, yoga_key in mahapurusha_map.items():
        if _is_own_or_exalted(ch, planet) and _planet_in_kendra(ch, planet):
            found.append({
                "name":   RAJA_YOGAS["yogas"][yoga_key]["name"],
                "rule":   RAJA_YOGAS["yogas"][yoga_key]["rule"],
                "effect": RAJA_YOGAS["yogas"][yoga_key]["effect"],
                "trigger":f"{planet} in {ch['planets'][planet]['dignity']} dignity in house {ch['planets'][planet]['house']} (kendra)",
            })

    # Gaja-Kesari Yoga — Jupiter in kendra from Moon
    moon_data = ch["planets"].get("Moon", {})
    jupiter_data = ch["planets"].get("Jupiter", {})
    if moon_data.get("house") and jupiter_data.get("house"):
        moon_house = moon_data["house"]
        jup_house = jupiter_data["house"]
        # Calculate kendra positions from Moon
        kendra_from_moon = [(moon_house + i - 1) % 12 + 1 for i in (1, 4, 7, 10)]
        if jup_house in kendra_from_moon:
            found.append({
                "name":   RAJA_YOGAS["yogas"]["gaja_kesari_yoga"]["name"],
                "rule":   RAJA_YOGAS["yogas"]["gaja_kesari_yoga"]["rule"],
                "effect": RAJA_YOGAS["yogas"]["gaja_kesari_yoga"]["effect"],
                "trigger":f"Jupiter in house {jup_house}, kendra from Moon (house {moon_house})",
            })

    # Budha-Aditya Yoga — Sun + Mercury conjunction
    mercury_data = ch["planets"].get("Mercury", {})
    if _planets_conjoined(ch, "Sun", "Mercury"):
        is_combust = mercury_data.get("is_combust", False)
        found.append({
            "name":     RAJA_YOGAS["yogas"]["budha_aditya_yoga"]["name"],
            "rule":     RAJA_YOGAS["yogas"]["budha_aditya_yoga"]["rule"],
            "effect":   RAJA_YOGAS["yogas"]["budha_aditya_yoga"]["effect"],
            "trigger":  f"Sun and Mercury conjoined in house {mercury_data.get('house')}",
            "weakened": "Mercury is combust — yoga weakened" if is_combust else None,
        })

    # Classical Raja Yoga — kendra + trikona lord combinations
    kendra_houses = [1, 4, 7, 10]
    trikona_houses = [1, 5, 9]
    kendra_lords = list(set([ch["house_lords"].get(h) for h in kendra_houses if ch["house_lords"].get(h)]))
    trikona_lords = list(set([ch["house_lords"].get(h) for h in trikona_houses if ch["house_lords"].get(h)]))

    for kl in kendra_lords:
        for tl in trikona_lords:
            if kl == tl: continue
            if _planets_conjoined(ch, kl, tl):
                kl_house = ch["planets"].get(kl, {}).get("house")
                # Avoid duplicates with the same trigger
                trigger_str = f"Kendra lord {kl} + Trikona lord {tl} conjoined in house {kl_house}"
                if not any(f.get("trigger") == trigger_str for f in found):
                    found.append({
                        "name":   RAJA_YOGAS["yogas"]["classical_raja_yoga"]["name"],
                        "rule":   RAJA_YOGAS["yogas"]["classical_raja_yoga"]["rule"],
                        "effect": RAJA_YOGAS["yogas"]["classical_raja_yoga"]["effect"],
                        "trigger":trigger_str,
                    })

    return found


# ════════════════════════════════════════════════════════════════════════
# 1. CAREER MASTER PROFILE
# ════════════════════════════════════════════════════════════════════════

def full_career_profile(dob: str, time: str, lat: float, lon: float,
                         timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Master endpoint — full career profile."""
    chart = get_chart(dob, time, lat, lon, timezone)
    ch = extract_chart_essentials(chart)

    return {
        "input": {"dob": dob, "time": time, "lat": lat, "lon": lon},
        "chart_summary": {
            "lagna":          ch["lagna_sign"],
            "tenth_house":    _tenth_house_summary(ch),
            "atmakaraka":     ch["atmakaraka"],
            "amatyakaraka":   ch["amatyakaraka"],
            "current_md":     ch["current_md"],
        },
        "karaka_analysis":     _karaka_analysis(ch),
        "natural_fields":      _natural_career_fields(ch),
        "d10_principles":      D10_ANALYSIS_PRINCIPLES,
        "career_house_meanings": CAREER_HOUSES,
        "professional_dasha":  _professional_dasha(ch),
        "raja_yogas":          _detect_raja_yogas(ch),
        "classical_sources": [
            "BPHS Ch. 11 (Karma Bhava) + Ch. 35-37 (Raja Yogas)",
            "Phaladeepika Ch. 6 (Profession)",
            "Jataka Parijata Ch. 12-13",
            "Saravali Ch. 25-26",
        ],
    }


def _tenth_house_summary(ch: Dict) -> Dict:
    lagna = ch["lagna_sign"]
    tenth_sign = SIGNS_ORDER[(SIGNS_ORDER.index(lagna) + 9) % 12] if lagna in SIGNS_ORDER else None
    tenth_lord = ch["house_lords"].get(10)
    tenth_lord_data = ch["planets"].get(tenth_lord, {}) if tenth_lord else {}
    planets_in_10 = _planets_in_house(ch, 10)

    return {
        "sign":               tenth_sign,
        "sign_lord":          tenth_lord,
        "lord_house":         tenth_lord_data.get("house"),
        "lord_dignity":       tenth_lord_data.get("dignity"),
        "lord_is_retrograde": tenth_lord_data.get("is_retrograde"),
        "lord_is_combust":    tenth_lord_data.get("is_combust"),
        "planets_in_10":      planets_in_10,
        "interpretation":     f"10th house ruled by {tenth_lord} — primary career signification. Lord placed in house {tenth_lord_data.get('house')}.",
    }


# ════════════════════════════════════════════════════════════════════════
# 2. D10 DEEP DIVE
# ════════════════════════════════════════════════════════════════════════

# ── B2 D10 WIRE-UP (Round 3) ──
# Was: d10_deep_dive used D1 chart through "D10 principles" — never cast actual D10.
# Now: builds real D10 chart from dashaflow's pre-computed d10_sign fields,
#      analyses D10 lagna, D10 10th house, AmK's D10 placement, planet placements.

_SIGNS_ORDER_LOCAL = ["Aries","Taurus","Gemini","Cancer","Leo","Virgo",
                      "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"]

# Sign-lord lookup (Vedic standard, no exaltation/debility overrides here)
_SIGN_TO_LORD_LOCAL = {
    "Aries": "Mars",         "Taurus": "Venus",   "Gemini": "Mercury",
    "Cancer": "Moon",        "Leo": "Sun",        "Virgo": "Mercury",
    "Libra": "Venus",        "Scorpio": "Mars",   "Sagittarius": "Jupiter",
    "Capricorn": "Saturn",   "Aquarius": "Saturn","Pisces": "Jupiter",
}


def _compute_d10_chart(chart: Dict) -> Dict:
    """
    Build the actual D10 (Dashamsha) chart from dashaflow's pre-computed d10_sign
    fields. dashaflow already computes d10_sign for the lagna and every planet —
    we just extract and compute house numbers relative to D10 lagna.

    Returns:
        {
            "lagna": {"sign": "...", "lord": "..."},
            "planets": {
                "Sun":  {"sign": "...", "house": int},
                ...
            },
            "tenth_house": {
                "sign": "...",
                "sign_lord": "...",
                "planets_in_10": ["..."],
            },
            "lagna_lord_in_d10": {"planet": "...", "house": int, "sign": "..."}
        }
    """
    lagna_obj = chart.get("lagna", {})
    if isinstance(lagna_obj, dict):
        d10_lagna_sign = lagna_obj.get("d10_sign")
    else:
        d10_lagna_sign = None

    if not d10_lagna_sign or d10_lagna_sign not in _SIGNS_ORDER_LOCAL:
        # Fallback — D10 lagna unavailable
        return {
            "lagna":       None,
            "planets":     {},
            "tenth_house": None,
            "note":        "D10 data unavailable from chart cast",
        }

    lagna_idx = _SIGNS_ORDER_LOCAL.index(d10_lagna_sign)
    d10_lagna_lord = _SIGN_TO_LORD_LOCAL.get(d10_lagna_sign)

    def sign_to_house(sign):
        if not sign or sign not in _SIGNS_ORDER_LOCAL:
            return None
        return ((_SIGNS_ORDER_LOCAL.index(sign) - lagna_idx) % 12) + 1

    # Build D10 planet placements
    d10_planets = {}
    for planet, pdata in chart.get("planets", {}).items():
        if isinstance(pdata, dict):
            d10_sign = pdata.get("d10_sign")
            d10_house = sign_to_house(d10_sign)
            d10_planets[planet] = {
                "sign":  d10_sign,
                "house": d10_house,
            }

    # D10 10th house = sign at index (lagna_idx + 9) % 12
    d10_10th_sign = _SIGNS_ORDER_LOCAL[(lagna_idx + 9) % 12]
    d10_10th_lord = _SIGN_TO_LORD_LOCAL.get(d10_10th_sign)
    planets_in_d10_10th = [p for p, pd in d10_planets.items() if pd.get("house") == 10]
    d10_10th_lord_house = d10_planets.get(d10_10th_lord, {}).get("house") if d10_10th_lord else None

    # D10 Lagna lord's placement
    lagna_lord_data = d10_planets.get(d10_lagna_lord, {})

    return {
        "lagna": {
            "sign":   d10_lagna_sign,
            "lord":   d10_lagna_lord,
        },
        "planets": d10_planets,
        "tenth_house": {
            "sign":            d10_10th_sign,
            "sign_lord":       d10_10th_lord,
            "lord_house":      d10_10th_lord_house,
            "planets_in_10":   planets_in_d10_10th,
        },
        "lagna_lord_in_d10": {
            "planet": d10_lagna_lord,
            "house":  lagna_lord_data.get("house"),
            "sign":   lagna_lord_data.get("sign"),
        },
    }


def d10_deep_dive(dob: str, time: str, lat: float, lon: float,
                  timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """
    D10 Dashamsha deep dive — career direction, authority lines.

    Casts the ACTUAL D10 chart (not D1-through-D10-lens) using dashaflow's
    pre-computed d10_sign fields. Analyses D10 lagna, D10 10th house, the
    placement of Amatyakaraka in D10 (strongest Jaimini career indicator),
    and the location of the D10 Lagna lord (defines primary career field).

    Classical sources: Phaladeepika Ch. 7 (D10 Dashamsha doctrine), Jaimini
    Sutras Adhyaya 1 (Karakamsha/AmK methodology), BPHS Ch. 7 (Divisional
    chart construction).
    """
    chart = get_chart(dob, time, lat, lon, timezone)
    ch    = extract_chart_essentials(chart)
    d10   = _compute_d10_chart(chart)

    # Where is AmK in D10? (Most important Jaimini career signature.)
    amk_planet = ch.get("amatyakaraka")
    amk_in_d10 = d10.get("planets", {}).get(amk_planet, {}) if amk_planet else {}

    # Where is AK (Atmakaraka)? Sometimes used for soul-purpose career bridging
    ak_planet = ch.get("atmakaraka")
    ak_in_d10 = d10.get("planets", {}).get(ak_planet, {}) if ak_planet else {}

    # Sun + Saturn special placements in D10 (authority vs. service orientation)
    sun_in_d10    = d10.get("planets", {}).get("Sun", {})
    saturn_in_d10 = d10.get("planets", {}).get("Saturn", {})

    # Synthesize career signature
    signature_lines = []
    d10_lagna_data = d10.get("lagna") or {}
    if d10_lagna_data.get("sign"):
        signature_lines.append(
            f"D10 Lagna in {d10_lagna_data['sign']} ruled by {d10_lagna_data['lord']} — "
            f"primary career orientation defined by {d10_lagna_data['lord']}'s nature."
        )
    if d10.get("lagna_lord_in_d10", {}).get("house"):
        ll = d10["lagna_lord_in_d10"]
        signature_lines.append(
            f"D10 Lagna lord {ll['planet']} placed in D10 house {ll['house']} "
            f"(sign: {ll['sign']}) — primary career field indicator."
        )
    if amk_in_d10.get("house"):
        signature_lines.append(
            f"AmK ({amk_planet}) in D10 house {amk_in_d10['house']} "
            f"(sign: {amk_in_d10.get('sign')}) — Jaimini career karaka placement; "
            f"strongest indicator of profession's domain."
        )
    if d10.get("tenth_house", {}).get("planets_in_10"):
        planets_str = ", ".join(d10["tenth_house"]["planets_in_10"])
        signature_lines.append(
            f"Planets in D10's 10th house: {planets_str} — peak-career-defining placements."
        )
    if d10.get("tenth_house", {}).get("lord_house"):
        th = d10["tenth_house"]
        signature_lines.append(
            f"D10 10th lord {th['sign_lord']} placed in D10 house {th['lord_house']} — "
            f"defines where career peak energy manifests."
        )

    return {
        "actual_d10_chart":     d10,                           # NEW — real D10 data
        "career_signature":     signature_lines,               # NEW — synthesized reading
        "amatyakaraka": {                                      # ENHANCED — now with D10 placement
            "planet":            amk_planet,
            "d1_position":       ch.get("amatyakaraka_full"),
            "d10_position":      amk_in_d10,
        },
        "atmakaraka": {                                        # NEW — for soul-purpose bridging
            "planet":            ak_planet,
            "d10_position":      ak_in_d10,
        },
        "sun_in_d10":           sun_in_d10,                    # NEW — authority orientation
        "saturn_in_d10":        saturn_in_d10,                 # NEW — service orientation
        "d1_tenth_house":       _tenth_house_summary(ch),      # KEPT — D1 10th for cross-ref
        "d10_principles":       D10_ANALYSIS_PRINCIPLES,       # KEPT — interpretation rules
        "method":               "Real D10 chart synthesis via dashaflow d10_sign data + Jaimini AmK methodology + classical D10 doctrine. AmK and lagna lord placements computed in actual D10 (not D1).",
        "classical_source":     "Phaladeepika Ch. 7 (D10 Dashamsha) + Jaimini Sutras Adhyaya 1 (Karakamsha/AmK) + BPHS Ch. 7 (Divisional chart construction).",
    }
# ── END B2 D10 WIRE-UP ──
# ════════════════════════════════════════════════════════════════════════
# 3. KARAKA ANALYSIS
# ════════════════════════════════════════════════════════════════════════

def karaka_analysis_for_chart(dob: str, time: str, lat: float, lon: float,
                              timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Career karakas (natural) + Amatyakaraka (Jaimini) deep analysis."""
    chart = get_chart(dob, time, lat, lon, timezone)
    ch = extract_chart_essentials(chart)
    return _karaka_analysis(ch)


def _karaka_analysis(ch: Dict) -> Dict:
    # Natural karakas of career
    sun_data = ch["planets"].get("Sun", {})
    saturn_data = ch["planets"].get("Saturn", {})
    mercury_data = ch["planets"].get("Mercury", {})
    jupiter_data = ch["planets"].get("Jupiter", {})

    return {
        "natural_career_karakas": {
            "Sun": {
                "role":     "Authority, leadership, government",
                "house":    sun_data.get("house"),
                "dignity":  sun_data.get("dignity"),
                "fields":   CAREER_FIELDS_BY_PLANET["Sun"]["fields"][:5],
            },
            "Saturn": {
                "role":     "Service, structure, long-term work, labor",
                "house":    saturn_data.get("house"),
                "dignity":  saturn_data.get("dignity"),
                "fields":   CAREER_FIELDS_BY_PLANET["Saturn"]["fields"][:5],
            },
            "Mercury": {
                "role":     "Trade, communication, intellectual work",
                "house":    mercury_data.get("house"),
                "dignity":  mercury_data.get("dignity"),
                "fields":   CAREER_FIELDS_BY_PLANET["Mercury"]["fields"][:5],
            },
            "Jupiter": {
                "role":     "Teaching, advisory, wisdom-based work",
                "house":    jupiter_data.get("house"),
                "dignity":  jupiter_data.get("dignity"),
                "fields":   CAREER_FIELDS_BY_PLANET["Jupiter"]["fields"][:5],
            },
        },
        "amatyakaraka": {
            "planet":  ch["amatyakaraka"],
            "details": ch.get("amatyakaraka_full"),
            "role":    "Jaimini Amatyakaraka = profession karaka. Career field follows AmK's nature.",
            "fields":  CAREER_FIELDS_BY_PLANET.get(ch["amatyakaraka"], {}).get("fields", [])[:5] if ch["amatyakaraka"] else [],
        },
        "atmakaraka": {
            "planet":  ch["atmakaraka"],
            "details": ch.get("atmakaraka_full"),
            "role":    "Atmakaraka = soul karaka. Whole-life career arc shaped by AK.",
            "fields":  CAREER_FIELDS_BY_PLANET.get(ch["atmakaraka"], {}).get("fields", [])[:5] if ch["atmakaraka"] else [],
        },
        "classical_source": "Phaladeepika Ch. 6 + Jaimini Sutras Ch. 1",
    }


# ════════════════════════════════════════════════════════════════════════
# 4. NATURAL CAREER FIELDS
# ════════════════════════════════════════════════════════════════════════

def natural_career_fields_endpoint(dob: str, time: str, lat: float, lon: float,
                                    timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = get_chart(dob, time, lat, lon, timezone)
    ch = extract_chart_essentials(chart)
    return _natural_career_fields(ch)


def _natural_career_fields(ch: Dict) -> Dict:
    """Compatible career fields from chart."""
    tenth_lord = ch["house_lords"].get(10)
    ak = ch["atmakaraka"]
    amk = ch["amatyakaraka"]
    planets_in_10 = _planets_in_house(ch, 10)

    fields_by_source = {}

    if tenth_lord:
        fields_by_source["from_10th_lord"] = {
            "planet": tenth_lord,
            "fields": CAREER_FIELDS_BY_PLANET.get(tenth_lord, {}),
        }

    if planets_in_10:
        fields_by_source["from_planets_in_10th"] = []
        for p in planets_in_10:
            fields_by_source["from_planets_in_10th"].append({
                "planet": p,
                "fields": CAREER_FIELDS_BY_PLANET.get(p, {}),
            })

    if ak:
        fields_by_source["from_atmakaraka"] = {
            "planet": ak,
            "role":   "Soul karaka — lifelong career theme",
            "fields": CAREER_FIELDS_BY_PLANET.get(ak, {}),
        }

    if amk and amk != ak:
        fields_by_source["from_amatyakaraka"] = {
            "planet": amk,
            "role":   "Profession karaka (Jaimini)",
            "fields": CAREER_FIELDS_BY_PLANET.get(amk, {}),
        }

    return {
        "primary_indicators":  fields_by_source,
        "all_planets_fields":  CAREER_FIELDS_BY_PLANET,
        "career_houses":       CAREER_HOUSES,
        "classical_source":    "Phaladeepika Ch. 6 + Saravali Ch. 25 + Jaimini Sutras",
    }


# ════════════════════════════════════════════════════════════════════════
# 5. CAREER TIMING
# ════════════════════════════════════════════════════════════════════════

def career_timing_endpoint(dob: str, time: str, lat: float, lon: float,
                            timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = get_chart(dob, time, lat, lon, timezone)
    ch = extract_chart_essentials(chart)

    tenth_lord = ch["house_lords"].get(10)
    md = ch["current_md"]
    ad = ch["current_ad"]
    md_full = ch.get("current_md_full", {})

    favorable_dasha_planets = []
    if tenth_lord:
        favorable_dasha_planets.append(f"{tenth_lord} (10th lord)")
    if ch["atmakaraka"]:
        favorable_dasha_planets.append(f"{ch['atmakaraka']} (Atmakaraka)")
    if ch["amatyakaraka"] and ch["amatyakaraka"] != ch["atmakaraka"]:
        favorable_dasha_planets.append(f"{ch['amatyakaraka']} (Amatyakaraka)")
    # Planets in 10th house
    for p in _planets_in_house(ch, 10):
        favorable_dasha_planets.append(f"{p} (in 10th house)")

    is_md_career_friendly = False
    if md and tenth_lord and md == tenth_lord:
        is_md_career_friendly = True
    if md and ch["atmakaraka"] and md == ch["atmakaraka"]:
        is_md_career_friendly = True

    return {
        "current_md":           md,
        "current_md_period":    {"start": md_full.get("start"), "end": md_full.get("end")},
        "current_ad":           ad,
        "md_is_career_friendly":is_md_career_friendly,
        "favorable_dasha_planets_for_career": favorable_dasha_planets,
        "interpretation": f"Career moves favor MD/AD of: {', '.join(favorable_dasha_planets)}. Current MD is {md}.",
        "classical_source": "BPHS Vimshottari Dasha + Phaladeepika timing analysis",
    }


# ════════════════════════════════════════════════════════════════════════
# 6. PROFESSIONAL DASHA
# ════════════════════════════════════════════════════════════════════════

def professional_dasha_endpoint(dob: str, time: str, lat: float, lon: float,
                                 timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = get_chart(dob, time, lat, lon, timezone)
    ch = extract_chart_essentials(chart)
    return _professional_dasha(ch)


def _professional_dasha(ch: Dict) -> Dict:
    md = ch["current_md"]
    ad = ch["current_ad"]
    md_full = ch.get("current_md_full", {})
    ad_full = ch.get("current_ad_full", {})

    md_data = ch["planets"].get(md, {}) if md else {}
    ad_data = ch["planets"].get(ad, {}) if ad else {}

    md_fields = CAREER_FIELDS_BY_PLANET.get(md, {}) if md else {}
    ad_fields = CAREER_FIELDS_BY_PLANET.get(ad, {}) if ad else {}

    return {
        "current_md": {
            "planet":  md,
            "period":  {"start": md_full.get("start"), "end": md_full.get("end")},
            "house_in_chart": md_data.get("house"),
            "dignity": md_data.get("dignity"),
            "career_archetype": md_fields.get("core_archetype"),
            "top_fields": md_fields.get("fields", [])[:5],
        },
        "current_ad": {
            "planet":  ad,
            "period":  {"start": ad_full.get("start"), "end": ad_full.get("end")},
            "house_in_chart": ad_data.get("house"),
            "career_archetype": ad_fields.get("core_archetype"),
            "top_fields": ad_fields.get("fields", [])[:5],
        },
        "classical_source": "Vimshottari Dasha + Career karaka analysis",
    }


# ════════════════════════════════════════════════════════════════════════
# 7. WEALTH MASTER PROFILE
# ════════════════════════════════════════════════════════════════════════

def full_wealth_profile(dob: str, time: str, lat: float, lon: float,
                         timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Master endpoint — full wealth profile."""
    chart = get_chart(dob, time, lat, lon, timezone)
    ch = extract_chart_essentials(chart)

    return {
        "input": {"dob": dob, "time": time, "lat": lat, "lon": lon},
        "chart_summary": {
            "lagna":         ch["lagna_sign"],
            "second_house":  _wealth_house_summary(ch, 2),
            "eleventh_house":_wealth_house_summary(ch, 11),
            "current_md":    ch["current_md"],
        },
        "dhana_yogas":         _detect_dhana_yogas(ch),
        "income_sources":      _income_sources(ch),
        "wealth_risk_areas":   _wealth_risk_areas(ch),
        "income_windows":      _income_windows(ch),
        "wealth_remedies":     WEALTH_REMEDIES,
        "wealth_principles":   WEALTH_REMEDIES["investment_principles_by_chart"],
        "classical_sources": [
            "BPHS Ch. 38-40 (Dhana yogas)",
            "Phaladeepika Ch. 12",
            "Saravali Ch. 38",
            "Sarvartha Chintamani Ch. 12-13",
        ],
    }


def _wealth_house_summary(ch: Dict, house_num: int) -> Dict:
    lagna = ch["lagna_sign"]
    sign = SIGNS_ORDER[(SIGNS_ORDER.index(lagna) + house_num - 1) % 12] if lagna in SIGNS_ORDER else None
    lord = ch["house_lords"].get(house_num)
    lord_data = ch["planets"].get(lord, {}) if lord else {}
    planets_in = _planets_in_house(ch, house_num)

    return {
        "house":          house_num,
        "sign":           sign,
        "lord":           lord,
        "lord_house":     lord_data.get("house"),
        "lord_dignity":   lord_data.get("dignity"),
        "planets_present":planets_in,
    }


# ════════════════════════════════════════════════════════════════════════
# 8. DHANA YOGAS
# ════════════════════════════════════════════════════════════════════════

def dhana_yogas_endpoint(dob: str, time: str, lat: float, lon: float,
                          timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = get_chart(dob, time, lat, lon, timezone)
    ch = extract_chart_essentials(chart)

    yogas = _detect_dhana_yogas(ch)

    return {
        "lagna":               ch["lagna_sign"],
        "detected_yogas":      yogas,
        "detected_count":      len(yogas),
        "all_yoga_catalog":    DHANA_YOGAS["yogas"],
        "classical_source":    "BPHS Ch. 40 + Phaladeepika Ch. 12 + Saravali",
    }


# ════════════════════════════════════════════════════════════════════════
# 9. INCOME SOURCES
# ════════════════════════════════════════════════════════════════════════

def income_sources_endpoint(dob: str, time: str, lat: float, lon: float,
                             timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = get_chart(dob, time, lat, lon, timezone)
    ch = extract_chart_essentials(chart)
    return _income_sources(ch)


def _income_sources(ch: Dict) -> Dict:
    eleventh_lord = ch["house_lords"].get(11)
    eleventh_lord_data = ch["planets"].get(eleventh_lord, {}) if eleventh_lord else {}
    planets_in_11 = _planets_in_house(ch, 11)

    sources = []
    if eleventh_lord:
        sources.append({
            "indicator":   f"11th house lord: {eleventh_lord}",
            "income_type": INCOME_SOURCES_BY_11TH_LORD.get(eleventh_lord, "unknown"),
            "lord_house":  eleventh_lord_data.get("house"),
            "lord_dignity":eleventh_lord_data.get("dignity"),
        })

    for p in planets_in_11:
        sources.append({
            "indicator":   f"Planet in 11th house: {p}",
            "income_type": INCOME_SOURCES_BY_11TH_LORD.get(p, "unknown"),
            "details":     CAREER_FIELDS_BY_PLANET.get(p, {}).get("industries", []),
        })

    return {
        "primary_sources":       sources,
        "all_planet_income_map": INCOME_SOURCES_BY_11TH_LORD,
        "classical_source":      "BPHS Ch. 38 (Laabha Bhava / 11th house)",
    }


# ════════════════════════════════════════════════════════════════════════
# 10. WEALTH RISK AREAS
# ════════════════════════════════════════════════════════════════════════

def wealth_risk_areas_endpoint(dob: str, time: str, lat: float, lon: float,
                                timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = get_chart(dob, time, lat, lon, timezone)
    ch = extract_chart_essentials(chart)
    return _wealth_risk_areas(ch)


def _wealth_risk_areas(ch: Dict) -> Dict:
    planets_in_12 = _planets_in_house(ch, 12)
    planets_in_8 = _planets_in_house(ch, 8)
    twelfth_house_indicators = []

    for p in planets_in_12:
        loss_pattern = WEALTH_RISK_INDICATORS["12th_house_focus"]["by_planet_in_12"].get(p)
        if loss_pattern:
            twelfth_house_indicators.append({
                "planet":      p,
                "loss_pattern":loss_pattern,
            })

    # Check for Kemadruma Yoga (Moon alone, no planets in 2nd or 12th from Moon)
    kemadruma_present = False
    kemadruma_cancelled = False
    moon_data = ch["planets"].get("Moon", {})
    if moon_data:
        moon_house = moon_data.get("house")
        if moon_house:
            # 2nd from Moon
            second_from_moon = (moon_house % 12) + 1
            twelfth_from_moon = ((moon_house - 2) % 12) + 1
            planets_in_2nd_from_moon = _planets_in_house(ch, second_from_moon)
            planets_in_12th_from_moon = _planets_in_house(ch, twelfth_from_moon)
            # Exclude Moon itself from count
            if not planets_in_2nd_from_moon and not planets_in_12th_from_moon:
                kemadruma_present = True
                # Cancellation: if Moon is in kendra (1/4/7/10)
                if moon_house in (1, 4, 7, 10):
                    kemadruma_cancelled = True

    # Check for Daridra Yoga — 11th lord in 6, 8, or 12
    eleventh_lord = ch["house_lords"].get(11)
    daridra_present = False
    if eleventh_lord:
        eleventh_lord_house = ch["planets"].get(eleventh_lord, {}).get("house")
        if eleventh_lord_house in (6, 8, 12):
            daridra_present = True

    # 8th house wealth-loss check
    second_lord = ch["house_lords"].get(2)
    second_lord_in_8 = second_lord and ch["planets"].get(second_lord, {}).get("house") == 8
    eleventh_lord_in_8 = eleventh_lord and ch["planets"].get(eleventh_lord, {}).get("house") == 8

    # Debilitated benefics
    debilitated_benefics = []
    for benefic in ("Jupiter", "Venus", "Mercury", "Moon"):
        if ch["planets"].get(benefic, {}).get("dignity") == "debilitated":
            debilitated_benefics.append(benefic)

    return {
        "twelfth_house_planets":  planets_in_12,
        "twelfth_house_losses":   twelfth_house_indicators,
        "eighth_house_planets":   planets_in_8,
        "second_lord_in_8th":     second_lord_in_8,
        "eleventh_lord_in_8th":   eleventh_lord_in_8,
        "kemadruma_yoga":         {"present": kemadruma_present, "cancelled": kemadruma_cancelled},
        "daridra_yoga":           {"present": daridra_present, "details": "11th lord in 6/8/12 — challenges in gains"},
        "debilitated_benefics":   debilitated_benefics,
        "indicator_summary":      WEALTH_RISK_INDICATORS,
        "classical_source":       "BPHS Ch. 40 + Mantreshwar",
    }


# ════════════════════════════════════════════════════════════════════════
# 11. INCOME WINDOWS
# ════════════════════════════════════════════════════════════════════════

def income_windows_endpoint(dob: str, time: str, lat: float, lon: float,
                             timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = get_chart(dob, time, lat, lon, timezone)
    ch = extract_chart_essentials(chart)
    return _income_windows(ch)


def _income_windows(ch: Dict) -> Dict:
    md = ch["current_md"]
    md_full = ch.get("current_md_full", {})
    second_lord = ch["house_lords"].get(2)
    fifth_lord = ch["house_lords"].get(5)
    ninth_lord = ch["house_lords"].get(9)
    eleventh_lord = ch["house_lords"].get(11)

    wealth_dasha_lords = list(set([l for l in (second_lord, fifth_lord, ninth_lord, eleventh_lord) if l]))

    is_current_md_wealth_friendly = md in wealth_dasha_lords if md else False

    return {
        "current_md":                md,
        "current_md_period":         {"start": md_full.get("start"), "end": md_full.get("end")},
        "md_is_wealth_friendly":     is_current_md_wealth_friendly,
        "wealth_friendly_dasha_lords": {
            "2nd_lord":  second_lord,
            "5th_lord":  fifth_lord,
            "9th_lord":  ninth_lord,
            "11th_lord": eleventh_lord,
        },
        "wealth_dasha_principles": INCOME_TIMING_BY_DASHA["wealth_dasha_principles"],
        "classical_source":        "BPHS Vimshottari + Phaladeepika dhana timing",
    }


# ════════════════════════════════════════════════════════════════════════
# 12. WEALTH REMEDIES
# ════════════════════════════════════════════════════════════════════════

def wealth_remedies_endpoint(dob: str, time: str, lat: float, lon: float,
                              timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = get_chart(dob, time, lat, lon, timezone)
    ch = extract_chart_essentials(chart)

    weakest = weakest_planet(ch)
    afflicted = afflicted_planets(ch)
    second_lord = ch["house_lords"].get(2)
    eleventh_lord = ch["house_lords"].get(11)

    personalized = {
        "second_lord":       second_lord,
        "eleventh_lord":     eleventh_lord,
        "weakest_planet":    weakest,
        "specific_actions":  [],
    }

    if second_lord:
        personalized["specific_actions"].append(
            f"Strengthen 2nd lord {second_lord} through its yantra/mantra (see Module 3a)"
        )
    if eleventh_lord and ch["planets"].get(eleventh_lord, {}).get("house") in (6, 8, 12):
        personalized["specific_actions"].append(
            f"11th lord {eleventh_lord} in dushthana — special wealth remediation required (Lakshmi vrats, Kubera mantras)"
        )
    if any(b == "Jupiter" and ch["planets"].get(b, {}).get("dignity") == "debilitated" for b in ("Jupiter",)):
        personalized["specific_actions"].append(
            "Jupiter is debilitated — Guru remediation critical (Brihaspati Stotra, Yellow Sapphire if safe)"
        )

    return {
        "personalized_focus":  personalized,
        "general_remedies":    WEALTH_REMEDIES,
        "classical_source":    "Composite Vedic wealth remedial tradition",
    }
