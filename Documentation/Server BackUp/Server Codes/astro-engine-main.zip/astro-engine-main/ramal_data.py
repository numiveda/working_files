"""
ramal_data.py — numiVeda Kaaliyo Astro Engine — Module E1.

Ramal Shastra (Indian Zaycha tradition) catalogs.

Public catalogs:
    FIGURES                — 16 Ramal figures keyed by row pattern
    FIGURES_BY_NUMBER      — 16 figures indexed by classical number 1-16
    HOUSE_DOMAINS          — 15 houses with domain + primary question
    DOMAIN_TO_HOUSE        — Question category → primary house
    CATEGORIES             — Dakhil/Sabit/Munkalib/Kharij operational categories
    NATURES                — Saumya/Krura/Madhyama qualifier
    THEFT_INDICATORS       — 4 figures whose presence indicates theft
    CLASSICAL_CITATIONS

Sources: Classical Indian Ramal tradition (Zaycha system).
This differs from Western Geomancy in figure attribution and house structure.
"""

from typing import Dict, List


# ════════════════════════════════════════════════════════════════════════
# 16 RAMAL FIGURES
# Key format: "r1-r2-r3-r4" where r1=top row, r4=bottom row
# odd = single dot (active, •)
# even = double dot (passive, • •)
# ════════════════════════════════════════════════════════════════════════

FIGURES: Dict[str, Dict] = {
    "odd-even-even-even":  {"number":  1, "name": "Lihyan",        "arabic": "لهيان",      "category": "Kharij",   "nature": "Saumya",   "element": "Fire",  "planet": "Jupiter", "judge": "Favourable"},
    "even-odd-even-odd":   {"number":  2, "name": "Qabzul Dakhil", "arabic": "قبضة داخل",  "category": "Dakhil",   "nature": "Saumya",   "element": "Earth", "planet": "Sun",     "judge": "Favourable"},
    "odd-even-odd-even":   {"number":  3, "name": "Qabzul Kharij", "arabic": "قبضة خارج",  "category": "Kharij",   "nature": "Krura",    "element": "Fire",  "planet": "Rahu",    "judge": "Unfavourable"},
    "even-even-even-even": {"number":  4, "name": "Jamaat",        "arabic": "جماعة",       "category": "Sabit",    "nature": "Madhyama", "element": "Earth", "planet": "Mercury", "judge": "Mixed"},
    "odd-odd-even-odd":    {"number":  5, "name": "Farah",         "arabic": "فرح",         "category": "Munkalib", "nature": "Saumya",   "element": "Air",   "planet": "Venus",   "judge": "Favourable"},
    "odd-even-even-odd":   {"number":  6, "name": "Ukla",          "arabic": "عقلة",        "category": "Munkalib", "nature": "Krura",    "element": "Earth", "planet": "Saturn",  "judge": "Unfavourable"},
    "even-odd-odd-odd":    {"number":  7, "name": "Ankish",        "arabic": "انكيش",       "category": "Dakhil",   "nature": "Krura",    "element": "Earth", "planet": "Saturn",  "judge": "Unfavourable"},
    "even-even-odd-odd":   {"number":  8, "name": "Humra",         "arabic": "حمرا",        "category": "Sabit",    "nature": "Krura",    "element": "Air",   "planet": "Mars",    "judge": "Unfavourable"},
    "odd-odd-even-even":   {"number":  9, "name": "Bayaz",         "arabic": "بياض",        "category": "Sabit",    "nature": "Saumya",   "element": "Water", "planet": "Moon",    "judge": "Favourable"},
    "even-odd-odd-even":   {"number": 10, "name": "Nusrat Kharij", "arabic": "نصرت خارج",  "category": "Kharij",   "nature": "Saumya",   "element": "Fire",  "planet": "Sun",     "judge": "Favourable"},
    "odd-even-odd-odd":    {"number": 11, "name": "Nusrat Dakhil", "arabic": "نصرت داخل",  "category": "Dakhil",   "nature": "Saumya",   "element": "Water", "planet": "Jupiter", "judge": "Favourable"},
    "even-odd-even-even":  {"number": 12, "name": "Atave Kharij",  "arabic": "اتاوه خارج", "category": "Kharij",   "nature": "Krura",    "element": "Fire",  "planet": "Ketu",    "judge": "Unfavourable"},
    "odd-odd-odd-even":    {"number": 13, "name": "Naki",          "arabic": "ناكي",        "category": "Munkalib", "nature": "Krura",    "element": "Water", "planet": "Mars",    "judge": "Unfavourable"},
    "even-even-odd-even":  {"number": 14, "name": "Atave Dakhil",  "arabic": "اتاوه داخل", "category": "Dakhil",   "nature": "Saumya",   "element": "Air",   "planet": "Venus",   "judge": "Favourable"},
    "odd-odd-odd-odd":     {"number": 15, "name": "Ijtima",        "arabic": "اجتماع",      "category": "Sabit",    "nature": "Madhyama", "element": "Air",   "planet": "Mercury", "judge": "Mixed"},
    "even-even-even-odd":  {"number": 16, "name": "Tarikh",        "arabic": "تاريخ",       "category": "Munkalib", "nature": "Saumya",   "element": "Water", "planet": "Moon",    "judge": "Favourable"},
}


# Build reverse index: number → key
FIGURES_BY_NUMBER: Dict[int, str] = {v["number"]: k for k, v in FIGURES.items()}


# ════════════════════════════════════════════════════════════════════════
# THE 15 HOUSES — Each with domain and primary question
# H1-H4: Mothers, H5-H8: Daughters, H9-H12: Nieces, H13-H14: Witnesses, H15: Judge
# ════════════════════════════════════════════════════════════════════════

HOUSE_DOMAINS: Dict[int, Dict] = {
    1:  {"role": "Mother",          "domain": "Self, body, longevity",             "primary_question": "How much of my lifespan remains?"},
    2:  {"role": "Mother",          "domain": "Wealth, income, movable property",  "primary_question": "Will I gain wealth?"},
    3:  {"role": "Mother",          "domain": "Siblings, short journeys, dreams",  "primary_question": "What is the outcome of this dream?"},
    4:  {"role": "Mother",          "domain": "Home, property, hidden treasure",   "primary_question": "Is there hidden wealth here?"},
    5:  {"role": "Daughter",        "domain": "Children, pregnancy, creativity",   "primary_question": "Will I have children?"},
    6:  {"role": "Daughter",        "domain": "Illness, enemies, debt (INVERTED — Kharij=cured, Dakhil=worsening)",  "primary_question": "Will the patient recover?"},
    7:  {"role": "Daughter",        "domain": "Marriage, partnerships, theft",     "primary_question": "Is the thief an insider?"},
    8:  {"role": "Daughter",        "domain": "Death, transformation, debt",       "primary_question": "Will I be freed from debt?"},
    9:  {"role": "Niece",           "domain": "Long journeys, people abroad",      "primary_question": "Is the person abroad alive?"},
    10: {"role": "Niece",           "domain": "Career, authority, disputes",       "primary_question": "Who will win the dispute?"},
    11: {"role": "Niece",           "domain": "Hopes, wishes, desires",            "primary_question": "Will my hope be fulfilled?"},
    12: {"role": "Niece",           "domain": "Loss, captivity, confinement",     "primary_question": "Will the prisoner be released?"},
    13: {"role": "Right Witness",   "domain": "Past actions, present state",      "primary_question": "What has led to this moment?"},
    14: {"role": "Left Witness",    "domain": "Future direction, environment",    "primary_question": "Where is this moving?"},
    15: {"role": "Judge",           "domain": "Final overarching verdict",         "primary_question": "What is the overall outcome?"},
}


# ════════════════════════════════════════════════════════════════════════
# QUESTION DOMAIN → PRIMARY HOUSE
# Maps user's question category to the relevant Ramal house
# ════════════════════════════════════════════════════════════════════════

DOMAIN_TO_HOUSE: Dict[str, int] = {
    "health":    6,
    "wealth":    2,
    "marriage":  7,
    "career":    10,
    "travel":    9,
    "legal":     10,
    "children":  5,
    "captivity": 12,
    "dreams":    3,
    "hopes":     11,
    "other":     1,
}


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL OPERATIONAL FRAMEWORK
# ════════════════════════════════════════════════════════════════════════

CATEGORIES: Dict[str, Dict] = {
    "Dakhil":   {"meaning": "Entering",      "interpretation": "Full, complete, incoming outcome. Arrives soon, without delay.",
                 "figures": ["Qabzul Dakhil", "Ankish", "Nusrat Dakhil", "Atave Dakhil"]},
    "Sabit":    {"meaning": "Fixed/Stable",  "interpretation": "Partial, stable, enduring. Half outcome. After some time, lasting.",
                 "figures": ["Jamaat", "Humra", "Bayaz", "Ijtima"]},
    "Munkalib": {"meaning": "Transforming",  "interpretation": "Incomplete, unstable, quarter outcome. Delayed, changeable, may not hold.",
                 "figures": ["Farah", "Ukla", "Naki", "Tarikh"]},
    "Kharij":   {"meaning": "Exiting",       "interpretation": "Weak, departing, minimal. Very little, fading. Far away or receding.",
                 "figures": ["Lihyan", "Qabzul Kharij", "Nusrat Kharij", "Atave Kharij"]},
}

NATURES: Dict[str, Dict] = {
    "Saumya":   {"meaning": "Auspicious",    "interpretation": "Amplifies good outcomes, mitigates bad outcomes."},
    "Krura":    {"meaning": "Inauspicious",  "interpretation": "Weakens good outcomes, intensifies bad outcomes."},
    "Madhyama": {"meaning": "Mixed/Neutral", "interpretation": "Context-dependent."},
}


# ════════════════════════════════════════════════════════════════════════
# SPECIAL RULES — Theft indicators and exception triggers
# ════════════════════════════════════════════════════════════════════════

# If ALL absent from 15 houses → item not stolen, only misplaced
THEFT_INDICATORS: List[str] = ["Naki", "Humra", "Atave Kharij", "Qabzul Kharij"]

# Captivity exception: Kharij category in H12 + Ukla as Judge (H15) → no release
CAPTIVITY_EXCEPTION = {
    "h12_must_be_category": "Kharij",
    "h15_must_be_figure":   "Ukla",
    "verdict": "No release. The classical tradition warns of extreme danger.",
}

# Dot count thresholds for H9 (life/death rule)
DOT_COUNT_THRESHOLDS: Dict[str, Dict] = {
    "alive":            {"min": 33, "max": 60, "verdict": "alive"},
    "extreme_distress": {"min": 32, "max": 32, "verdict": "extreme distress, life hangs in balance"},
    "dead":             {"min":  0, "max": 31, "verdict": "dead or perished"},
}


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "ramal_tradition": "Classical Indian Ramal Shastra (Zaycha system). Hindi-Persian source tradition: distinct from Western Geomancy in figure-planet attribution and 15-house structure (vs. Western 16-figure shield chart).",
    "prastara":        "Prastara (multiplicative combination) rule — Indian Ramal multi-house derivations including 4 Mothers from throws, 4 Daughters by transpose, 4 Nieces by row-sum, 2 Witnesses, 1 Judge (15-house derivation).",
    "hope_formula":    "Hope formula (Triple Prastara for H11) — (H1 × H11) combined with (H1 × H14) → Final Figure; presence in any house determines fulfillment domain.",
    "theft_rule":      "Theft indicator rule — Naki, Humra, Atave Kharij, Qabzul Kharij as the four theft-signaling figures; their absence indicates misplacement, not theft.",
    "captivity_rule":  "Captivity exception — Kharij category in H12 with Ukla as Judge indicates no release in classical Indian Ramal tradition.",
    "dot_count":       "Bindu (dot) count — total active rows across all 15 houses; threshold 32 distinguishes life from death in classical Ramal life-questions.",
}
