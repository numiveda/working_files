# numiVeda Astro Engine

Vedic astrology + divination API engine. 327 endpoints across natal, predictive, compatibility, remedial, and esoteric domains.

## Stack

- Python 3 / FastAPI / uvicorn
- Swiss Ephemeris (pyswisseph)
- Ubuntu 24.04 LTS on Vultr
- Systemd-managed: systemctl {start|stop|restart} astro.service

## Service

- Port: 8001
- Workers: 2 (uvicorn)
- Auth: X-API-Key header
- Internal URL: http://65.20.75.166:8001/
- OpenAPI schema: http://65.20.75.166:8001/openapi.json

## Documentation

Full endpoint reference in 16 module-grouped docs (separate Google Drive folder).

## Operations

See BACKUP_RECOVERY_OPERATIONS.md for backup and recovery procedures.

## Baseline

- v1.0-f11 (2026-05-19): Post-F11 hotfix, 327 endpoints live, all tests passing.
