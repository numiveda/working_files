"""
prashna.py — Prashna (Horary) Engine (Module B3)

Architecture:
- Uses astro_helpers for chart extraction (same as birth charts)
- KEY DIFFERENCE: Chart is cast at QUESTION MOMENT, not birth moment
- 10 endpoints covering Lagna, Moon, KP, Aroodha, Swara, Timing, Yes/No

Classical sources cited per function.
"""

from typing import Dict, List, Optional, Any
from datetime import datetime

from astro_helpers import (
    extract_chart_essentials,
    get_chart,
    afflicted_planets,
    SIGNS_ORDER,
    SIGN_TO_LORD,
)

from prashna_data import (
    QUESTION_CATEGORIES,
    LAGNA_SIGNATURE_INTERPRETATIONS,
    SIGN_TYPE_INTERPRETATION,
    MOON_PRASHNA_RULES,
    KP_HORARY_SYSTEM,
    AROODHA_LAGNA,
    SWARA_RULES,
    TIMING_TECHNIQUES,
    YES_NO_SYNTHESIS,
    PRASHNA_MARGA_RULES,
)

# ── B3 KP WIRE-UP (Round 2) ─ Import KP Pro for full sub-lord computation ──
from kp_pro import handle_profile as kp_handle_profile


# ════════════════════════════════════════════════════════════════════════
# CHART CASTING — Question moment, not birth moment
# ════════════════════════════════════════════════════════════════════════

def _parse_question_datetime(question_datetime: str) -> Dict[str, str]:
    """
    Parse ISO datetime string into dob+time format that cast_chart expects.

    Input: "2026-05-16T11:30:00" or "2026-05-16T11:30"
    Output: {"dob": "2026-05-16", "time": "11:30"}
    """
    # Handle both "T" separator and space
    s = question_datetime.replace("T", " ")
    if " " in s:
        date_part, time_part = s.split(" ", 1)
    else:
        # If only date provided, default to noon
        date_part = s
        time_part = "12:00"

    # Trim seconds if present
    if time_part.count(":") == 2:
        time_part = ":".join(time_part.split(":")[:2])

    return {"dob": date_part, "time": time_part}


def _cast_prashna_chart(question_datetime: str, lat: float, lon: float,
                        timezone: str = "Asia/Kolkata") -> Dict:
    """Cast a chart for the moment of question."""
    parsed = _parse_question_datetime(question_datetime)
    return get_chart(dob=parsed["dob"], time=parsed["time"], lat=lat, lon=lon, timezone=timezone)


def _get_weekday(question_datetime: str) -> str:
    """Get weekday name from question datetime."""
    parsed = _parse_question_datetime(question_datetime)
    try:
        dt = datetime.strptime(f"{parsed['dob']} {parsed['time']}", "%Y-%m-%d %H:%M")
        return dt.strftime("%A")
    except Exception:
        return "Unknown"


WEEKDAY_LORDS = {
    "Sunday":    "Sun",
    "Monday":    "Moon",
    "Tuesday":   "Mars",
    "Wednesday": "Mercury",
    "Thursday":  "Jupiter",
    "Friday":    "Venus",
    "Saturday":  "Saturn",
}


# ════════════════════════════════════════════════════════════════════════
# 1. MASTER PROFILE
# ════════════════════════════════════════════════════════════════════════

def full_prashna_profile(question_datetime: str, lat: float, lon: float,
                          timezone: str = "Asia/Kolkata",
                          category: str = "general",
                          question_text: Optional[str] = None) -> Dict[str, Any]:
    """Master endpoint — full Prashna chart analysis."""
    chart = _cast_prashna_chart(question_datetime, lat, lon, timezone)
    ch = extract_chart_essentials(chart)

    return {
        "input": {
            "question_datetime": question_datetime,
            "lat": lat, "lon": lon,
            "category": category,
            "question_text": question_text,
        },
        "moment_chart": {
            "lagna":           ch["lagna_sign"],
            "lagna_lord":      ch["lagna_lord"],
            "lagna_nakshatra": ch["lagna_nakshatra"],
            "moon_sign":       ch["moon_sign"],
            "moon_house":      ch["moon_house"],
            "moon_nakshatra":  ch["moon_nakshatra"],
            "weekday":         _get_weekday(question_datetime),
            "weekday_lord":    WEEKDAY_LORDS.get(_get_weekday(question_datetime)),
        },
        "lagna_analysis":      _lagna_analysis(ch),
        "moon_analysis":       _moon_analysis(ch),
        "category_context":    QUESTION_CATEGORIES.get(category, QUESTION_CATEGORIES["general"]),
        "significator":        _significator(ch, category),
        "aroodha_lagna":       _aroodha_lagna(ch),
        "yes_no_synthesis":    _yes_no_synthesis(ch, category),
        "timing_indication":   _timing_indication(ch, category),
        "swara_guidance":      SWARA_RULES,
        "classical_sources": [
            "Tajik Neelakanthi (~16th c. CE)",
            "Prashna Marga (~1649 CE)",
            "Brihat Samhita with Bhattotpala (~10th c.)",
            "Daivagya Vallabha",
            "Krishnamurti Paddhati methodology",
        ],
    }


# ════════════════════════════════════════════════════════════════════════
# 2. LAGNA ANALYSIS
# ════════════════════════════════════════════════════════════════════════

def lagna_analysis_endpoint(question_datetime: str, lat: float, lon: float,
                             timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = _cast_prashna_chart(question_datetime, lat, lon, timezone)
    ch = extract_chart_essentials(chart)
    return _lagna_analysis(ch)


def _lagna_analysis(ch: Dict) -> Dict:
    lagna = ch["lagna_sign"]
    lagna_lord = ch["lagna_lord"]
    lagna_lord_data = ch["planets"].get(lagna_lord, {}) if lagna_lord else {}

    signature = LAGNA_SIGNATURE_INTERPRETATIONS.get(lagna, {})
    sign_type = signature.get("quality", "").split("_")[0] if "_" in signature.get("quality", "") else "unknown"

    return {
        "lagna_sign":          lagna,
        "lagna_lord":          lagna_lord,
        "lagna_lord_house":    lagna_lord_data.get("house"),
        "lagna_lord_sign":     lagna_lord_data.get("sign"),
        "lagna_lord_dignity":  lagna_lord_data.get("dignity"),
        "lagna_lord_retrograde":lagna_lord_data.get("is_retrograde"),
        "lagna_lord_combust":  lagna_lord_data.get("is_combust"),
        "signature":           signature,
        "sign_type":           sign_type,
        "sign_type_meaning":   SIGN_TYPE_INTERPRETATION.get(sign_type),
        "rashi_adhipati_rule": PRASHNA_MARGA_RULES["rashi_adhipati"],
        "classical_source":    "Prashna Marga Ch. 5",
    }


# ════════════════════════════════════════════════════════════════════════
# 3. MOON ANALYSIS
# ════════════════════════════════════════════════════════════════════════

def moon_analysis_endpoint(question_datetime: str, lat: float, lon: float,
                            timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = _cast_prashna_chart(question_datetime, lat, lon, timezone)
    ch = extract_chart_essentials(chart)
    return _moon_analysis(ch)


def _moon_analysis(ch: Dict) -> Dict:
    moon_data = ch["planets"].get("Moon", {})
    moon_house = moon_data.get("house")
    moon_sign = moon_data.get("sign")
    moon_nakshatra = ch.get("moon_nakshatra")
    moon_nakshatra_lord = ch.get("moon_nakshatra_lord")

    # Categorize moon house
    house_category = "neutral"
    house_meaning = ""
    if moon_house in (1, 4, 7, 10):
        house_category = "kendra"
        house_meaning = MOON_PRASHNA_RULES["moon_in_kendra"]
    elif moon_house in (1, 5, 9):
        house_category = "trikona"
        house_meaning = MOON_PRASHNA_RULES["moon_in_trikona"]
    elif moon_house in (6, 8, 12):
        house_category = "dushthana"
        house_meaning = MOON_PRASHNA_RULES["moon_in_dushthana"]
    elif moon_house in (3, 11):
        house_category = "upachaya"
        house_meaning = MOON_PRASHNA_RULES["moon_in_3_or_11"]

    return {
        "moon_sign":            moon_sign,
        "moon_house":           moon_house,
        "moon_nakshatra":       moon_nakshatra,
        "moon_nakshatra_lord":  moon_nakshatra_lord,
        "house_category":       house_category,
        "house_meaning":        house_meaning,
        "moon_dignity":         moon_data.get("dignity"),
        "nakshatra_significance":MOON_PRASHNA_RULES["moon_nakshatra_significance"],
        "additional_rules":     {k: v for k, v in MOON_PRASHNA_RULES.items() if k not in ("moon_in_kendra", "moon_in_trikona", "moon_in_dushthana", "moon_in_3_or_11")},
        "classical_source":     "Prashna Marga Ch. 3",
    }


# ════════════════════════════════════════════════════════════════════════
# 4. SIGNIFICATOR
# ════════════════════════════════════════════════════════════════════════

def significator_endpoint(question_datetime: str, lat: float, lon: float,
                           category: str = "general",
                           timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = _cast_prashna_chart(question_datetime, lat, lon, timezone)
    ch = extract_chart_essentials(chart)
    return _significator(ch, category)


def _significator(ch: Dict, category: str) -> Dict:
    cat_data = QUESTION_CATEGORIES.get(category, QUESTION_CATEGORIES["general"])
    primary_house = cat_data["primary_house"]

    # Get primary house lord and planets there
    primary_house_lord = ch["house_lords"].get(primary_house)
    primary_house_lord_data = ch["planets"].get(primary_house_lord, {}) if primary_house_lord else {}
    planets_in_primary = [p for p, pd in ch["planets"].items() if pd.get("house") == primary_house]

    secondary_info = []
    for h in cat_data["secondary_houses"]:
        lord = ch["house_lords"].get(h)
        lord_data = ch["planets"].get(lord, {}) if lord else {}
        secondary_info.append({
            "house": h,
            "lord":  lord,
            "lord_house": lord_data.get("house"),
            "lord_dignity":lord_data.get("dignity"),
            "planets_here":[p for p, pd in ch["planets"].items() if pd.get("house") == h],
        })

    return {
        "question_category":     category,
        "category_description":  cat_data["description"],
        "primary_house":         primary_house,
        "primary_house_lord":    primary_house_lord,
        "primary_house_lord_position": {
            "house":   primary_house_lord_data.get("house"),
            "sign":    primary_house_lord_data.get("sign"),
            "dignity": primary_house_lord_data.get("dignity"),
            "retrograde": primary_house_lord_data.get("is_retrograde"),
            "combust": primary_house_lord_data.get("is_combust"),
        },
        "planets_in_primary_house": planets_in_primary,
        "primary_karaka":        cat_data["primary_karaka"],
        "secondary_karakas":     cat_data["secondary_karakas"],
        "secondary_houses_analysis": secondary_info,
        "interpretation_focus":  cat_data["interpretation_focus"],
        "classical_source":      "Prashna Marga + Tajik Neelakanthi category significators",
    }


# ════════════════════════════════════════════════════════════════════════
# 5. TIMING
# ════════════════════════════════════════════════════════════════════════

def timing_endpoint(question_datetime: str, lat: float, lon: float,
                     category: str = "general",
                     timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = _cast_prashna_chart(question_datetime, lat, lon, timezone)
    ch = extract_chart_essentials(chart)
    return _timing_indication(ch, category)


def _timing_indication(ch: Dict, category: str) -> Dict:
    lagna = ch["lagna_sign"]
    signature = LAGNA_SIGNATURE_INTERPRETATIONS.get(lagna, {})
    quality = signature.get("quality", "")
    sign_type = quality.split("_")[0] if "_" in quality else "unknown"

    sign_type_timing = TIMING_TECHNIQUES["sign_type_timing"].get(sign_type, "uncertain")

    # Get primary house from category
    cat_data = QUESTION_CATEGORIES.get(category, QUESTION_CATEGORIES["general"])
    primary_house = cat_data["primary_house"]
    house_timing = TIMING_TECHNIQUES["house_timing"].get(str(primary_house), "uncertain")

    # Current dasha lord indicator
    md = ch["current_md"]
    primary_house_lord = ch["house_lords"].get(primary_house)
    dasha_supports = (md == primary_house_lord) if md and primary_house_lord else False

    return {
        "lagna_sign_type":         sign_type,
        "sign_type_timing":        sign_type_timing,
        "primary_house":           primary_house,
        "primary_house_timing":    house_timing,
        "current_md":              md,
        "primary_house_lord":      primary_house_lord,
        "dasha_directly_supports": dasha_supports,
        "dasha_indicator":         TIMING_TECHNIQUES["dasha_indicator"],
        "additional_techniques":   {
            "lord_aspect_timing":      TIMING_TECHNIQUES["lord_aspect_timing"],
            "moon_to_significator":    TIMING_TECHNIQUES["moon_to_significator_time"],
        },
        "classical_source":        "Prashna Marga Ch. 12 + Tajik timing",
    }


# ════════════════════════════════════════════════════════════════════════
# 6. YES/NO ANSWER
# ════════════════════════════════════════════════════════════════════════

def yes_no_endpoint(question_datetime: str, lat: float, lon: float,
                     category: str = "general",
                     timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = _cast_prashna_chart(question_datetime, lat, lon, timezone)
    ch = extract_chart_essentials(chart)
    return _yes_no_synthesis(ch, category)


def _yes_no_synthesis(ch: Dict, category: str) -> Dict:
    lagna_lord = ch["lagna_lord"]
    lagna_lord_house = ch["planets"].get(lagna_lord, {}).get("house") if lagna_lord else None

    # Method 1: Lagna lord placement
    method_1 = "uncertain"
    if lagna_lord_house in YES_NO_SYNTHESIS["method_1_lagna_lord"]["yes_houses"]:
        method_1 = "YES"
    elif lagna_lord_house in YES_NO_SYNTHESIS["method_1_lagna_lord"]["no_houses"]:
        method_1 = "NO"
    elif lagna_lord_house in YES_NO_SYNTHESIS["method_1_lagna_lord"]["neutral"]:
        method_1 = "NEUTRAL"

    # Method 3: Benefics vs Malefics in Lagna
    benefics_in_lagna = [p for p, pd in ch["planets"].items()
                          if pd.get("house") == 1 and p in ("Jupiter", "Venus", "Mercury", "Moon")]
    malefics_in_lagna = [p for p, pd in ch["planets"].items()
                          if pd.get("house") == 1 and p in ("Saturn", "Mars", "Rahu", "Ketu")]
    method_3 = "uncertain"
    if benefics_in_lagna and not malefics_in_lagna:
        method_3 = "YES"
    elif malefics_in_lagna and not benefics_in_lagna:
        method_3 = "NO"
    elif benefics_in_lagna and malefics_in_lagna:
        method_3 = "MIXED"

    # Method 4: KP cuspal sub-lord (simplified — needs actual KP sub-lord computation)
    cat_data = QUESTION_CATEGORIES.get(category, QUESTION_CATEGORIES["general"])
    primary_house = cat_data["primary_house"]
    primary_house_lord = ch["house_lords"].get(primary_house)
    primary_house_lord_house = ch["planets"].get(primary_house_lord, {}).get("house") if primary_house_lord else None

    kp_positive_houses = KP_HORARY_SYSTEM["cuspal_sublord_principle"]["houses_for_questions"].get(category, {}).get("positive", [])
    kp_negative_houses = KP_HORARY_SYSTEM["cuspal_sublord_principle"]["houses_for_questions"].get(category, {}).get("negative", [])

    method_4 = "uncertain"
    if primary_house_lord_house in kp_positive_houses:
        method_4 = "YES"
    elif primary_house_lord_house in kp_negative_houses:
        method_4 = "NO"

    # Synthesis
    answers = [method_1, method_3, method_4]
    yes_count = sum(1 for a in answers if a == "YES")
    no_count = sum(1 for a in answers if a == "NO")
    if yes_count > no_count and yes_count >= 2:
        final = "YES"
    elif no_count > yes_count and no_count >= 2:
        final = "NO"
    else:
        final = "UNCERTAIN — multiple methods diverge; consider rephrasing question"

    return {
        "question_category":       category,
        "method_1_lagna_lord":     {
            "result":  method_1,
            "rule":    YES_NO_SYNTHESIS["method_1_lagna_lord"]["rule"],
            "details": f"Lagna lord {lagna_lord} in house {lagna_lord_house}",
        },
        "method_3_lagna_benefic_malefic": {
            "result":  method_3,
            "rule":    YES_NO_SYNTHESIS["method_3_benefic_malefic_lagna"]["rule"],
            "benefics_in_lagna": benefics_in_lagna,
            "malefics_in_lagna": malefics_in_lagna,
        },
        "method_4_kp_simplified":  {
            "result":  method_4,
            "rule":    "Primary house lord placed in positive houses for category",
            "primary_house": primary_house,
            "primary_house_lord": primary_house_lord,
            "lord_placed_in": primary_house_lord_house,
            "positive_houses_for_category": kp_positive_houses,
            "negative_houses_for_category": kp_negative_houses,
        },
        "synthesis":               final,
        "synthesis_principle":     YES_NO_SYNTHESIS["synthesis_principle"],
        "classical_source":        "Prashna Marga Ch. 4 + Krishnamurti Paddhati methodology",
    }


# ════════════════════════════════════════════════════════════════════════
# 7. KP HORARY
# ════════════════════════════════════════════════════════════════════════

# ── B3 KP WIRE-UP (Round 2) ──
# Was: returned RP framework only, with "deferred sub-lord computation" note.
# Now: consumes kp_handle_profile() from kp_pro.py for full sub-lord analysis
#      at the question moment, plus category-focused yes/no synthesis.
def kp_horary_endpoint(question_datetime: str, lat: float, lon: float,
                        category: str = "general",
                        timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """
    KP Horary (Prashna) analysis at the question moment.

    Casts the question-moment chart as a "synthetic birth" and runs full
    D4 KP Pro analysis on it: lagna sub-lord, planet sub-lords, all 12
    cuspal sub-lords (Placidus + Lahiri), birth ruling planets, and the
    4-level significator hierarchy.

    Then synthesizes a category-focused KP yes/no signal by examining
    the sub-lords of the cusps relevant to the question category.

    Classical source: K.S. Krishnamurti "Krishnamurti Paddhati" Vol 1-6.
    """
    # ── Build synthetic-birth dict from question moment ──
    dob, time_part = question_datetime.split("T") if "T" in question_datetime else (question_datetime, "12:00:00")
    time_hm = ":".join(time_part.split(":")[:2])
    synthetic_birth = {
        "dob":      dob,
        "time":     time_hm,
        "lat":      lat,
        "lon":      lon,
        "timezone": timezone,
    }

    # ── Run full D4 KP Pro at question moment ──
    kp_pro_analysis = kp_handle_profile(synthetic_birth)

    # ── Existing B3 metadata (kept for backward compat) ──
    weekday = _get_weekday(question_datetime)
    cat_data = QUESTION_CATEGORIES.get(category, QUESTION_CATEGORIES["general"])

    # Category house mapping from existing data
    houses_for_cat = KP_HORARY_SYSTEM["cuspal_sublord_principle"]["houses_for_questions"].get(category, {})
    positive_houses = houses_for_cat.get("positive", [])
    negative_houses = houses_for_cat.get("negative", [])

    # ── B3 KP WIRE-UP (Round 2 v1.1) ── Fixed: cuspal_sub_lords is a LIST not dict
    # Extract cuspal sub-lords for relevant category houses ──
    cuspal_list = kp_pro_analysis.get("cuspal_sub_lords", {}).get("cuspal_sub_lords", [])
    # cuspal_list is a list of dicts like:
    #   {"house": 1, "cusp_sign": "Leo", "cusp_degree": 0.5976,
    #    "longitude": 120.5976, "nakshatra": "Magha",
    #    "star_lord": "Ketu", "sub_lord": "Ketu", "sub_sub_lord": "Saturn"}

    # Build house-keyed lookup for category houses
    cuspal_sublords_for_category = {}
    for cusp_data in cuspal_list:
        if not isinstance(cusp_data, dict):
            continue
        h = cusp_data.get("house")
        if h in positive_houses or h in negative_houses:
            cuspal_sublords_for_category[f"house_{h}"] = cusp_data

    # ── KP yes/no synthesis ──
    # Classical rule: If sub-lords of POSITIVE houses signify the matter, YES.
    # If negative-house sub-lords are involved, NO or obstacles.
    positive_sublords_set = set()
    negative_sublords_set = set()
    for cusp_data in cuspal_list:
        if not isinstance(cusp_data, dict):
            continue
        h = cusp_data.get("house")
        sl = cusp_data.get("sub_lord")
        if not sl:
            continue
        if h in positive_houses:
            positive_sublords_set.add(sl)
        elif h in negative_houses:
            negative_sublords_set.add(sl)

    # Get the 5 RPs from KP Pro
    brp = kp_pro_analysis.get("birth_ruling_planets", {})
    rps_unique = brp.get("unique_rps") if isinstance(brp, dict) else None
    if not rps_unique and isinstance(brp, dict):
        rps_unique = list({
            brp.get("lagna_sign_lord"),
            brp.get("lagna_star_lord"),
            brp.get("moon_sign_lord"),
            brp.get("moon_star_lord"),
            brp.get("day_lord"),
        } - {None})

    rps_set = set(rps_unique or [])

    # KP yes/no logic:
    # YES if positive-house sub-lords overlap with RPs (planets are "ready to deliver")
    # NO  if negative-house sub-lords overlap with RPs
    pos_rp_match = positive_sublords_set & rps_set
    neg_rp_match = negative_sublords_set & rps_set

    if pos_rp_match and not neg_rp_match:
        signal = "YES"
        reasoning = f"Positive-house sub-lord(s) {sorted(pos_rp_match)} match ruling planets"
    elif neg_rp_match and not pos_rp_match:
        signal = "NO"
        reasoning = f"Negative-house sub-lord(s) {sorted(neg_rp_match)} match ruling planets"
    elif pos_rp_match and neg_rp_match:
        signal = "MIXED"
        reasoning = f"Both positive ({sorted(pos_rp_match)}) and negative ({sorted(neg_rp_match)}) RP overlaps — outcome uncertain or delayed"
    else:
        signal = "INCONCLUSIVE"
        reasoning = "No RP overlap with positive or negative cuspal sub-lords — chart not ripe for prediction; consult again at different moment"

    return {
        # ── Backward-compatible keys ──
        "question_datetime":     question_datetime,
        "question_category":     category,
        "weekday":               weekday,
        "ruling_planets":        brp,  # now using KP Pro's 5-RP system
        "rp_use":                KP_HORARY_SYSTEM["ruling_planets_method"]["use"],
        "rp_method_components":  KP_HORARY_SYSTEM["ruling_planets_method"]["components"],
        "cuspal_principle":      KP_HORARY_SYSTEM["cuspal_sublord_principle"]["description"],
        "houses_for_category":   houses_for_cat,
        "house_groupings_kp":    KP_HORARY_SYSTEM["house_groupings_kp"],

        # ── NEW: full D4 KP Pro analysis at question moment ──
        "kp_pro_analysis":       kp_pro_analysis,

        # ── NEW: category-focused synthesis ──
        "cuspal_sublords_for_category": cuspal_sublords_for_category,
        "kp_yes_no_signal":      {
            "signal":     signal,
            "reasoning":  reasoning,
            "category":   category,
            "positive_houses":             positive_houses,
            "negative_houses":             negative_houses,
            "ruling_planets":              sorted(rps_set),
            "positive_house_sublords":     sorted(positive_sublords_set),
            "negative_house_sublords":     sorted(negative_sublords_set),
            "pos_rp_match":                sorted(pos_rp_match),
            "neg_rp_match":                sorted(neg_rp_match),
        },

        # ── Method + citation ──
        "method":            "Full KP horary via kp_pro D4: Placidus cusps + Lahiri ayanamsha + 249 sub-lord algorithm applied to question moment. Category synthesis via classical positive/negative house framework.",
        "classical_source":  "K.S. Krishnamurti 'Krishnamurti Paddhati' Vol 1-6; Vimshottari from BPHS.",
    }
# ── END B3 KP WIRE-UP ──
def _get_question_datetime_string(ch: Dict) -> str:
    """Helper to reconstruct datetime — not stored in ch, use proxy."""
    # This is a limitation; actual usage gets datetime from endpoint signature
    return ""


# ════════════════════════════════════════════════════════════════════════
# 8. AROODHA LAGNA
# ════════════════════════════════════════════════════════════════════════

def aroodha_lagna_endpoint(question_datetime: str, lat: float, lon: float,
                            timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = _cast_prashna_chart(question_datetime, lat, lon, timezone)
    ch = extract_chart_essentials(chart)
    return _aroodha_lagna(ch)


def _aroodha_lagna(ch: Dict) -> Dict:
    lagna = ch["lagna_sign"]
    lagna_lord = ch["lagna_lord"]
    lagna_lord_house = ch["planets"].get(lagna_lord, {}).get("house") if lagna_lord else None

    # Aroodha calculation:
    # Count from Lagna to Lagna lord's house. Then count same number forward from Lagna lord's house.
    aroodha_house = None
    aroodha_sign = None
    if lagna_lord_house and lagna in SIGNS_ORDER:
        # Houses from lagna to lagna lord = lagna_lord_house (since lagna is house 1)
        # Then count same number from lagna lord's house
        count = lagna_lord_house  # number of houses from lagna to lagna lord
        aroodha_house_num = ((lagna_lord_house - 1) + count) % 12 + 1
        # Vighatta exception: if aroodha falls in 1st or 7th, take 10th from there
        if aroodha_house_num == 1 or aroodha_house_num == 7:
            aroodha_house_num = ((aroodha_house_num - 1) + 9) % 12 + 1
        aroodha_house = aroodha_house_num
        aroodha_sign = SIGNS_ORDER[(SIGNS_ORDER.index(lagna) + aroodha_house - 1) % 12]

    # What's in Aroodha?
    planets_in_aroodha = []
    if aroodha_house:
        planets_in_aroodha = [p for p, pd in ch["planets"].items() if pd.get("house") == aroodha_house]

    benefics_in_aroodha = [p for p in planets_in_aroodha if p in ("Jupiter", "Venus", "Mercury", "Moon")]
    malefics_in_aroodha = [p for p in planets_in_aroodha if p in ("Saturn", "Mars", "Rahu", "Ketu")]

    interpretation = None
    if benefics_in_aroodha and not malefics_in_aroodha:
        interpretation = AROODHA_LAGNA["interpretation"]["AL_with_benefic"]
    elif malefics_in_aroodha and not benefics_in_aroodha:
        interpretation = AROODHA_LAGNA["interpretation"]["AL_with_malefic"]
    elif benefics_in_aroodha and malefics_in_aroodha:
        interpretation = "Mixed — benefic + malefic in Aroodha. Public perception is contested."

    return {
        "lagna":               lagna,
        "lagna_lord":          lagna_lord,
        "lagna_lord_house":    lagna_lord_house,
        "aroodha_house":       aroodha_house,
        "aroodha_sign":        aroodha_sign,
        "planets_in_aroodha":  planets_in_aroodha,
        "benefics_in_aroodha": benefics_in_aroodha,
        "malefics_in_aroodha": malefics_in_aroodha,
        "interpretation":      interpretation,
        "calculation_rule":    AROODHA_LAGNA["calculation_rule"],
        "exception_rule":      AROODHA_LAGNA["exception"],
        "uses_in_prashna":     AROODHA_LAGNA["uses_in_prashna"],
        "classical_source":    "Jaimini Sutras + Parashara commentary",
    }


# ════════════════════════════════════════════════════════════════════════
# 9. SWARA ANALYSIS
# ════════════════════════════════════════════════════════════════════════

def swara_endpoint(question_datetime: str, lat: float, lon: float,
                    timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = _cast_prashna_chart(question_datetime, lat, lon, timezone)
    ch = extract_chart_essentials(chart)

    lagna = ch["lagna_sign"]
    is_ascending = lagna in SWARA_RULES["matching_with_chart"]["ascending_signs"]
    is_descending = lagna in SWARA_RULES["matching_with_chart"]["descending_signs"]

    return {
        "lagna":                lagna,
        "lagna_type":           "ascending" if is_ascending else "descending" if is_descending else "unknown",
        "ida_nadi_left":        SWARA_RULES["ida_nadi_left"],
        "pingala_nadi_right":   SWARA_RULES["pingala_nadi_right"],
        "sushumna_both":        SWARA_RULES["sushumna_both"],
        "classical_rule":       SWARA_RULES["swara_classical_rule"],
        "matching_with_chart":  SWARA_RULES["matching_with_chart"],
        "user_action_required": "Practitioner/app must capture actual breath state at moment of question. Engine provides interpretation rules.",
        "classical_source":     "Shiva Swarodaya (~14th c. CE)",
    }


# ════════════════════════════════════════════════════════════════════════
# 10. SPECIFIC QUERY (templated)
# ════════════════════════════════════════════════════════════════════════

def specific_query_endpoint(question_datetime: str, lat: float, lon: float,
                             category: str = "general",
                             timezone: str = "Asia/Kolkata",
                             question_text: Optional[str] = None) -> Dict[str, Any]:
    """Category-templated prashna reading combining lagna, moon, significator, timing, yes/no."""
    chart = _cast_prashna_chart(question_datetime, lat, lon, timezone)
    ch = extract_chart_essentials(chart)

    cat_data = QUESTION_CATEGORIES.get(category, QUESTION_CATEGORIES["general"])

    return {
        "category":               category,
        "question_text":          question_text,
        "category_context":       cat_data,
        "lagna":                  _lagna_analysis(ch),
        "moon":                   _moon_analysis(ch),
        "significator":           _significator(ch, category),
        "yes_no":                 _yes_no_synthesis(ch, category),
        "timing":                 _timing_indication(ch, category),
        "category_specific_rule": _category_specific_rule(category),
        "classical_source":       "Composite — Prashna Marga + Tajik + Krishnamurti",
    }


def _category_specific_rule(category: str) -> str:
    """Return classical category-specific interpretation principle."""
    rules = {
        "marriage":     PRASHNA_MARGA_RULES["vivaha_prashna"],
        "health":       PRASHNA_MARGA_RULES["rogadhipati"],
        "travel":       PRASHNA_MARGA_RULES["yatra_prashna"],
        "career":       "10th lord + Saturn + Sun synthesis. 10th lord in kendra/trikona = career success.",
        "finance":      "2nd lord + 11th lord + Jupiter synthesis. Dhana yogas indicate flow.",
        "legal_matter": "6th lord = enemy/opponent; 7th lord = self in court; whoever's lord is stronger wins.",
        "missing_item": "Lagna lord + Moon's nakshatra direction (movable/fixed/dual signs indicate near/far/intermediate).",
        "general":      "Lagna and Moon synthesis. Multiple methods must converge for clear answer.",
    }
    return rules.get(category, rules["general"])
