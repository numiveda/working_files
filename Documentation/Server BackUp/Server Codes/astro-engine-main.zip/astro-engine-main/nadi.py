"""
nadi.py — numiVeda Kaaliyo Astro Engine — Module D5 (Nadi Astrology)

6 endpoints for nakshatra-pada-level karma analysis.

Endpoints:
    handle_profile                 — Master Nadi synthesis
    handle_moon_pada_analysis      — Moon's pada deep-dive (deity/animal/varna)
    handle_ak_nakshatra_signature  — Atmakaraka's nakshatra signature
    handle_pada_attributes         — Per-planet pada attributes
    handle_bhrigu_aspects          — 2nd-from-planet result patterns
    handle_nakshatra_yogas         — Classical nakshatra yogas (Gandanta, Mula, etc.)
"""

from typing import Dict, List, Optional, Any

from astro_helpers import (
    extract_chart_essentials,
    get_chart,
    SIGNS_ORDER,
    SIGN_TO_LORD,
    HOUSE_TO_LIFE_AREA,
)

from nadi_data import (
    NAKSHATRA_DETAILS,
    GANDANTA_ZONES,
    NAKSHATRA_YOGAS,
    BHRIGU_NADI_RULES,
    NADI_PARIHARAS,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# HELPERS
# ════════════════════════════════════════════════════════════════════════

def _build(birth: Dict[str, Any]):
    raw = get_chart(
        dob=birth["dob"], time=birth["time"],
        lat=birth["lat"], lon=birth["lon"],
        timezone=birth.get("timezone", "Asia/Kolkata"),
    )
    return raw, extract_chart_essentials(raw)


def _sign_index(sign: Optional[str]) -> Optional[int]:
    if not sign or sign not in SIGNS_ORDER:
        return None
    return SIGNS_ORDER.index(sign)


def _second_from(sign: str) -> Optional[str]:
    idx = _sign_index(sign)
    if idx is None:
        return None
    return SIGNS_ORDER[(idx + 1) % 12]


def _is_in_gandanta(sign: str, degree: float) -> Optional[Dict]:
    """Return Gandanta zone info if planet is within 3°20' of a water-fire junction."""
    # Water sign last 3°20' = degree >= 26.667 (30 - 3.333)
    # Fire sign first 3°20' = degree < 3.333
    if sign in ("Cancer", "Scorpio", "Pisces") and degree >= 26.667:
        for z in GANDANTA_ZONES:
            if z["water_sign"] == sign:
                return {**z, "side": "water_end"}
    if sign in ("Leo", "Sagittarius", "Aries") and degree < 3.333:
        for z in GANDANTA_ZONES:
            if z["fire_sign"] == sign:
                return {**z, "side": "fire_begin"}
    return None


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT HANDLERS
# ════════════════════════════════════════════════════════════════════════

def handle_moon_pada_analysis(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 2: Moon's pada deep-dive."""
    raw, e = _build(birth)
    moon = raw.get("planets", {}).get("Moon", {})

    nak = moon.get("nakshatra")
    pada = moon.get("pada")
    nak_lord = moon.get("nakshatra_lord")
    moon_sign = moon.get("sign")
    moon_degree = moon.get("degree", 0)

    details = NAKSHATRA_DETAILS.get(nak, {})

    # Check Gandanta
    gandanta = _is_in_gandanta(moon_sign, moon_degree)

    # Nadi-specific cautions
    cautions: List[Dict[str, str]] = []
    if nak == "Ashlesha":
        cautions.append({"pattern": "moon_in_ashlesha", "remedy": NADI_PARIHARAS["moon_in_ashlesha"]})
    if nak == "Mula":
        cautions.append({"pattern": "moon_in_mula", "remedy": NADI_PARIHARAS["moon_in_mula"]})
    if nak == "Jyeshtha":
        cautions.append({"pattern": "moon_in_jyeshtha", "remedy": NADI_PARIHARAS["moon_in_jyeshtha"]})
    if nak == "Revati":
        cautions.append({"pattern": "moon_in_revati", "remedy": NADI_PARIHARAS["moon_in_revati"]})
    if gandanta:
        cautions.append({"pattern": "gandanta_birth", "remedy": NADI_PARIHARAS["gandanta_birth"]})

    return {
        "moon_sign":          moon_sign,
        "moon_degree":        moon_degree,
        "moon_nakshatra":     nak,
        "moon_pada":          pada,
        "nakshatra_lord":     nak_lord,
        "nakshatra_details":  details,
        "gandanta_zone":      gandanta,
        "in_gandanta":        gandanta is not None,
        "cautions":           cautions,
        "note":               "Moon's nakshatra-pada is the Nadi primary identifier — determines Vimshottari dasha starting point and reveals deep mental/emotional karma.",
        "citation":           CLASSICAL_CITATIONS["nakshatra_lore"],
    }


def handle_ak_nakshatra_signature(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 3: Atmakaraka's nakshatra signature."""
    raw, e = _build(birth)
    jk = raw.get("jaimini_karakas", {})
    ak = jk.get("Atmakaraka", {})

    ak_planet = ak.get("planet")
    if not ak_planet:
        return {"error": "Atmakaraka not resolvable", "citation": CLASSICAL_CITATIONS["bhrigu_nadi"]}

    ak_data = raw.get("planets", {}).get(ak_planet, {})
    ak_nak = ak_data.get("nakshatra")
    ak_pada = ak_data.get("pada")
    ak_nak_lord = ak_data.get("nakshatra_lord")
    ak_sign = ak_data.get("sign")
    ak_degree = ak_data.get("degree", 0)

    details = NAKSHATRA_DETAILS.get(ak_nak, {})
    gandanta = _is_in_gandanta(ak_sign, ak_degree)

    return {
        "atmakaraka_planet":     ak_planet,
        "atmakaraka_sign":       ak_sign,
        "atmakaraka_degree":     ak_degree,
        "atmakaraka_nakshatra":  ak_nak,
        "atmakaraka_pada":       ak_pada,
        "atmakaraka_nakshatra_lord": ak_nak_lord,
        "nakshatra_details":     details,
        "gandanta_zone":         gandanta,
        "soul_signature":        (
            f"Soul karma signature: {ak_planet} carries the karma of "
            f"{details.get('deity', '?')} (deity), {details.get('theme', '?')} "
            f"under {details.get('lord', '?')} (Vimshottari lord). "
            f"Pada {ak_pada} = soul's micro-zone within this nakshatra."
        ),
        "note":                  "AK's nakshatra is the soul's specific karmic-vibrational identity — finer than AK's sign alone.",
        "citation":              CLASSICAL_CITATIONS["bhrigu_nadi"],
    }


def handle_pada_attributes(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 4: Per-planet pada attributes (deity/yoni/varna/gana/body_part)."""
    raw, e = _build(birth)
    planets_data = raw.get("planets", {})

    planets_to_analyze = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]
    results: Dict[str, Dict[str, Any]] = {}

    for planet in planets_to_analyze:
        pd = planets_data.get(planet, {})
        if not pd:
            continue
        nak = pd.get("nakshatra")
        details = NAKSHATRA_DETAILS.get(nak, {})
        results[planet] = {
            "sign":           pd.get("sign"),
            "degree":         pd.get("degree"),
            "nakshatra":      nak,
            "pada":           pd.get("pada"),
            "nakshatra_lord": pd.get("nakshatra_lord"),
            "deity":          details.get("deity"),
            "yoni":           details.get("yoni"),
            "varna":          details.get("varna"),
            "gana":           details.get("gana"),
            "body_part":      details.get("body_part"),
            "dosha":          details.get("dosha"),
            "guna":           details.get("guna"),
            "symbol":         details.get("symbol"),
            "theme":          details.get("theme"),
        }

    return {
        "planets":         results,
        "planet_count":    len(results),
        "note":            "Each planet's nakshatra reveals its karmic flavor at micro-resolution. Yoni/varna match analysis used in compatibility; gana shows temperament; body_part shows physical-health correspondence.",
        "citation":        CLASSICAL_CITATIONS["nakshatra_lore"],
    }


def handle_bhrigu_aspects(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 5: 2nd-from-planet result patterns per Bhrigu Nadi."""
    raw, e = _build(birth)
    planets_data = raw.get("planets", {})

    planets_to_analyze = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]
    bhrigu_patterns: List[Dict[str, Any]] = []

    for planet in planets_to_analyze:
        pd = planets_data.get(planet, {})
        if not pd:
            continue
        p_sign = pd.get("sign")
        second_sign = _second_from(p_sign)
        if not second_sign:
            continue
        second_lord = SIGN_TO_LORD.get(second_sign)
        second_lord_data = planets_data.get(second_lord, {}) if second_lord else {}

        bhrigu_patterns.append({
            "planet":          planet,
            "planet_sign":     p_sign,
            "planet_house":    pd.get("house"),
            "second_sign":     second_sign,
            "second_lord":     second_lord,
            "second_lord_house": second_lord_data.get("house") if isinstance(second_lord_data, dict) else None,
            "second_lord_dignity": second_lord_data.get("dignity") if isinstance(second_lord_data, dict) else None,
            "interpretation":  (
                f"{planet}'s fruits flow via {second_sign}, ruled by {second_lord}. "
                f"{second_lord} in H{second_lord_data.get('house', '?')} "
                f"({second_lord_data.get('dignity', '?')}) determines how {planet}'s significations actualize."
            ),
        })

    return {
        "bhrigu_patterns":      bhrigu_patterns,
        "pattern_count":        len(bhrigu_patterns),
        "bhrigu_principles":    BHRIGU_NADI_RULES,
        "note":                 "Bhrigu Nadi: every planet's fruits appear through the sign 2nd from it. The lord of that 2nd sign — its placement, dignity, house — modulates the actualization.",
        "citation":             CLASSICAL_CITATIONS["bhrigu_nadi"],
    }


def handle_nakshatra_yogas(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 6: Classical nakshatra yoga patterns detected in chart."""
    raw, e = _build(birth)
    planets_data = raw.get("planets", {})

    detected: List[Dict[str, str]] = []

    # Check each planet for Gandanta
    gandanta_planets: List[Dict[str, Any]] = []
    for planet, pd in planets_data.items():
        if not isinstance(pd, dict):
            continue
        zone = _is_in_gandanta(pd.get("sign", ""), pd.get("degree", 0))
        if zone:
            gandanta_planets.append({
                "planet":      planet,
                "sign":        pd.get("sign"),
                "degree":      pd.get("degree"),
                "junction":    zone["junction"],
                "intensity":   zone["intensity"],
            })

    if gandanta_planets:
        detected.append({
            "yoga":         "Gandanta",
            "rule":         NAKSHATRA_YOGAS["gandanta_birth"]["rule"],
            "effect":       NAKSHATRA_YOGAS["gandanta_birth"]["effect"],
            "planets":      [g["planet"] for g in gandanta_planets],
            "details":      gandanta_planets,
        })

    # Moon-specific warnings
    moon_nak = planets_data.get("Moon", {}).get("nakshatra")
    if moon_nak == "Mula":
        detected.append({
            "yoga":         "Mula Dasha (Moon)",
            "rule":         NAKSHATRA_YOGAS["mula_dasha_warning"]["rule"],
            "effect":       NAKSHATRA_YOGAS["mula_dasha_warning"]["effect"],
            "remedy":       NADI_PARIHARAS["moon_in_mula"],
        })
    if moon_nak == "Ashlesha":
        detected.append({
            "yoga":         "Ashlesha Dasha (Moon)",
            "rule":         NAKSHATRA_YOGAS["ashlesha_dasha_warning"]["rule"],
            "effect":       NAKSHATRA_YOGAS["ashlesha_dasha_warning"]["effect"],
            "remedy":       NADI_PARIHARAS["moon_in_ashlesha"],
        })
    if moon_nak == "Jyeshtha":
        detected.append({
            "yoga":         "Jyeshtha Dasha (Moon)",
            "rule":         NAKSHATRA_YOGAS["jyeshtha_dasha_warning"]["rule"],
            "effect":       NAKSHATRA_YOGAS["jyeshtha_dasha_warning"]["effect"],
            "remedy":       NADI_PARIHARAS["moon_in_jyeshtha"],
        })

    # Rahu-Ashlesha karma intensifier
    rahu_nak = planets_data.get("Rahu", {}).get("nakshatra")
    if rahu_nak == "Ashlesha":
        detected.append({
            "yoga":         "Rahu in Ashlesha",
            "rule":         "Rahu in serpent-deity nakshatra intensifies occult/kundalini karma",
            "effect":       "Serpent karma compounded — Rahu (eclipse-snake) in serpent nakshatra; classical remedies via Naga puja",
            "remedy":       NADI_PARIHARAS["rahu_in_ashlesha"],
        })

    # Ketu-Mula
    ketu_nak = planets_data.get("Ketu", {}).get("nakshatra")
    if ketu_nak == "Mula":
        detected.append({
            "yoga":         "Ketu in Mula",
            "rule":         "Ketu in root-cutting nakshatra signals deep karmic uprooting",
            "effect":       "Past-life severe-endings karma; Ketu in Mula = soul carries root-severance memory",
            "remedy":       NADI_PARIHARAS["ketu_in_mula"],
        })

    return {
        "yogas_detected": detected,
        "yoga_count":     len(detected),
        "all_yogas_catalog": NAKSHATRA_YOGAS,
        "note":           "Nakshatra-specific yogas operate at finer resolution than rashi yogas. Birth in Mula/Ashlesha/Jyeshtha or Gandanta zones is classically called Abhukta-Mula (un-fruited) — requires shanti before life can proceed smoothly.",
        "citation":       CLASSICAL_CITATIONS["nakshatra_yogas"],
    }


def handle_profile(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 1 (MASTER): Nadi master synthesis."""
    moon_analysis = handle_moon_pada_analysis(birth)
    ak_signature  = handle_ak_nakshatra_signature(birth)
    pada_attrs    = handle_pada_attributes(birth)
    bhrigu        = handle_bhrigu_aspects(birth)
    yogas         = handle_nakshatra_yogas(birth)

    headlines: List[str] = []
    headlines.append(
        f"Moon: {moon_analysis['moon_nakshatra']} pada {moon_analysis['moon_pada']} "
        f"(lord {moon_analysis['nakshatra_lord']}) — {moon_analysis['nakshatra_details'].get('theme', '')[:60]}"
    )
    if ak_signature.get("atmakaraka_planet"):
        headlines.append(
            f"AK: {ak_signature['atmakaraka_planet']} in {ak_signature['atmakaraka_nakshatra']} "
            f"pada {ak_signature['atmakaraka_pada']} (lord {ak_signature['atmakaraka_nakshatra_lord']})"
        )
    if moon_analysis["in_gandanta"]:
        headlines.append(
            f"⚠️ Moon in Gandanta zone — {moon_analysis['gandanta_zone']['junction']}"
        )
    if yogas["yoga_count"] > 0:
        yoga_names = [y["yoga"] for y in yogas["yogas_detected"]]
        headlines.append(
            f"Nakshatra yogas active ({yogas['yoga_count']}): {', '.join(yoga_names)}"
        )
    if moon_analysis["cautions"]:
        headlines.append(
            f"⚠️ Nadi cautions: {[c['pattern'] for c in moon_analysis['cautions']]}"
        )

    return {
        "headlines":          headlines,
        "moon_pada_analysis": moon_analysis,
        "ak_signature":       ak_signature,
        "pada_attributes":    pada_attrs,
        "bhrigu_aspects":     bhrigu,
        "nakshatra_yogas":    yogas,
        "method":             "Synthesis of Moon-pada + AK-nakshatra + per-planet pada attributes + Bhrigu Nadi 2nd-from logic + nakshatra yoga detection",
        "citations": {
            "nakshatra":   CLASSICAL_CITATIONS["nakshatra_lore"],
            "bhrigu_nadi": CLASSICAL_CITATIONS["bhrigu_nadi"],
            "gandanta":    CLASSICAL_CITATIONS["gandanta"],
        },
    }
