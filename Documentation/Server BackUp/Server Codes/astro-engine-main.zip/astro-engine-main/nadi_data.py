"""
nadi_data.py — Nadi Astrology reference data.

Phase D — Module D5 (Nadi Astrology).

Public catalogs:
    NAKSHATRA_DETAILS    — 27 nakshatras with deity/animal/varna/gana/yoni/body_part
    PADA_NAVAMSHA_MAP    — Each of 108 padas maps to D9 sign
    GANDANTA_ZONES       — 3 Gandanta junctions (water-fire) at 3°20' boundaries
    NAKSHATRA_YOGAS      — Abhijit, Mula-warning, Gandanta, junction patterns
    BHRIGU_NADI_RULES    — Conjunction + 2nd-from-planet patterns
    NADI_PARIHARAS       — Classical Nadi-specific remedies
    CLASSICAL_CITATIONS

Sources: Brihat Samhita (Varahamihira, ~6th c.), Bhrigu Samhita (traditional
         Bhrigu Nadi compendium), Chandra Nadi (classical),
         Surya Siddhanta on nakshatra divisions, Krishnamurti Paddhati on
         nakshatra-pada precision.
All sources public domain.
"""

from typing import Dict, List


# ════════════════════════════════════════════════════════════════════════
# NAKSHATRA DETAILS — 27 nakshatras
# Each: deity, ruling planet (lord), animal yoni, varna, gana, body_part,
# gender, direction, dosha (Ayurvedic), guna, symbol
# ════════════════════════════════════════════════════════════════════════

NAKSHATRA_DETAILS: Dict[str, Dict[str, str]] = {
    "Ashwini": {
        "deity":     "Ashwini Kumaras (twin horsemen, divine healers)",
        "lord":      "Ketu",
        "yoni":      "Horse (male)",
        "varna":     "Vaishya",
        "gana":      "Deva",
        "body_part": "Knees, head",
        "direction": "South",
        "dosha":     "Vata",
        "guna":      "Rajas-Tamas",
        "symbol":    "Horse's head",
        "theme":     "Initiation, healing, swift action, divine intervention",
    },
    "Bharani": {
        "deity":     "Yama (god of death/dharma)",
        "lord":      "Venus",
        "yoni":      "Elephant (male)",
        "varna":     "Mleccha",
        "gana":      "Manushya",
        "body_part": "Head, feet",
        "direction": "West",
        "dosha":     "Pitta",
        "guna":      "Rajas-Rajas",
        "symbol":    "Yoni (vulva), womb",
        "theme":     "Restraint, transformation, life-death cycles, bearing burdens",
    },
    "Krittika": {
        "deity":     "Agni (fire god)",
        "lord":      "Sun",
        "yoni":      "Sheep (female)",
        "varna":     "Brahmin",
        "gana":      "Rakshasa",
        "body_part": "Waist, hips",
        "direction": "North",
        "dosha":     "Kapha",
        "guna":      "Rajas-Sattva",
        "symbol":    "Razor, flame, knife",
        "theme":     "Cutting, purification, fierce mothering, sharp discernment",
    },
    "Rohini": {
        "deity":     "Brahma (creator) / Prajapati",
        "lord":      "Moon",
        "yoni":      "Serpent (male)",
        "varna":     "Shudra",
        "gana":      "Manushya",
        "body_part": "Legs, forehead",
        "direction": "East",
        "dosha":     "Kapha",
        "guna":      "Rajas-Rajas",
        "symbol":    "Chariot, ox cart, banyan tree",
        "theme":     "Growth, sensuality, fertility, beauty, magnetism",
    },
    "Mrigashira": {
        "deity":     "Soma (moon god)",
        "lord":      "Mars",
        "yoni":      "Serpent (female)",
        "varna":     "Servant",
        "gana":      "Deva",
        "body_part": "Eyes",
        "direction": "South",
        "dosha":     "Pitta",
        "guna":      "Tamas-Rajas",
        "symbol":    "Deer's head, antelope",
        "theme":     "Searching, gentle pursuit, curiosity, restless quest",
    },
    "Ardra": {
        "deity":     "Rudra (Shiva as destroyer)",
        "lord":      "Rahu",
        "yoni":      "Dog (female)",
        "varna":     "Butcher",
        "gana":      "Manushya",
        "body_part": "Hair, eyes",
        "direction": "West",
        "dosha":     "Vata",
        "guna":      "Tamas-Tamas",
        "symbol":    "Teardrop, diamond",
        "theme":     "Storm, dissolution, raw emotion, tears bringing growth",
    },
    "Punarvasu": {
        "deity":     "Aditi (mother of gods)",
        "lord":      "Jupiter",
        "yoni":      "Cat (female)",
        "varna":     "Vaishya",
        "gana":      "Deva",
        "body_part": "Fingers, nose",
        "direction": "North",
        "dosha":     "Vata",
        "guna":      "Rajas-Sattva",
        "symbol":    "Bow and quiver, house",
        "theme":     "Return, renewal, restoration, repeated chances",
    },
    "Pushya": {
        "deity":     "Brihaspati (priest of gods)",
        "lord":      "Saturn",
        "yoni":      "Goat (male)",
        "varna":     "Kshatriya",
        "gana":      "Deva",
        "body_part": "Mouth, face",
        "direction": "East",
        "dosha":     "Pitta",
        "guna":      "Tamas-Tamas",
        "symbol":    "Cow's udder, lotus, flower",
        "theme":     "Nourishment, generosity, well-being (most auspicious for many uses)",
    },
    "Ashlesha": {
        "deity":     "Sarpa/Naga (serpent deities)",
        "lord":      "Mercury",
        "yoni":      "Cat (male)",
        "varna":     "Mleccha",
        "gana":      "Rakshasa",
        "body_part": "Joints, nails",
        "direction": "South",
        "dosha":     "Kapha",
        "guna":      "Sattva-Sattva",
        "symbol":    "Coiled serpent",
        "theme":     "Hypnotic intelligence, occult power, kundalini, manipulation",
    },
    "Magha": {
        "deity":     "Pitris (ancestors)",
        "lord":      "Ketu",
        "yoni":      "Rat (male)",
        "varna":     "Shudra",
        "gana":      "Rakshasa",
        "body_part": "Lips, chin",
        "direction": "West",
        "dosha":     "Kapha",
        "guna":      "Tamas-Rajas",
        "symbol":    "Throne, palanquin",
        "theme":     "Ancestral karma, royal lineage, mighty inheritance",
    },
    "Purva Phalguni": {
        "deity":     "Bhaga (god of marital bliss)",
        "lord":      "Venus",
        "yoni":      "Rat (female)",
        "varna":     "Brahmin",
        "gana":      "Manushya",
        "body_part": "Genitals, right hand",
        "direction": "North",
        "dosha":     "Pitta",
        "guna":      "Rajas-Rajas",
        "symbol":    "Front legs of cot, hammock",
        "theme":     "Pleasure, indulgence, romance, creative rest",
    },
    "Uttara Phalguni": {
        "deity":     "Aryaman (god of contracts)",
        "lord":      "Sun",
        "yoni":      "Cow (male)",
        "varna":     "Kshatriya",
        "gana":      "Manushya",
        "body_part": "Left hand, genitals",
        "direction": "East",
        "dosha":     "Vata",
        "guna":      "Rajas-Sattva",
        "symbol":    "Rear legs of cot, four legs of bed",
        "theme":     "Sacred contracts, marriage, partnership commitment",
    },
    "Hasta": {
        "deity":     "Savitar (sun-aspect, creative power)",
        "lord":      "Moon",
        "yoni":      "Buffalo (female)",
        "varna":     "Vaishya",
        "gana":      "Deva",
        "body_part": "Hands",
        "direction": "South",
        "dosha":     "Vata",
        "guna":      "Rajas-Tamas",
        "symbol":    "Hand, fist, palm",
        "theme":     "Manifestation, skilled hands, manual mastery, craftsmanship",
    },
    "Chitra": {
        "deity":     "Vishvakarma/Tvashtar (cosmic architect)",
        "lord":      "Mars",
        "yoni":      "Tiger (female)",
        "varna":     "Servant",
        "gana":      "Rakshasa",
        "body_part": "Neck, forehead",
        "direction": "West",
        "dosha":     "Pitta",
        "guna":      "Tamas-Rajas",
        "symbol":    "Pearl, bright jewel",
        "theme":     "Artistic creation, design, illusion-mastery, brilliance",
    },
    "Swati": {
        "deity":     "Vayu (wind god)",
        "lord":      "Rahu",
        "yoni":      "Buffalo (male)",
        "varna":     "Butcher",
        "gana":      "Deva",
        "body_part": "Teeth",
        "direction": "North",
        "dosha":     "Kapha",
        "guna":      "Tamas-Tamas",
        "symbol":    "Young sprout in wind, coral",
        "theme":     "Independent movement, scattering, trade, flexibility",
    },
    "Vishakha": {
        "deity":     "Indra-Agni (lightning + fire pair)",
        "lord":      "Jupiter",
        "yoni":      "Tiger (male)",
        "varna":     "Mleccha",
        "gana":      "Rakshasa",
        "body_part": "Arms, breasts",
        "direction": "East",
        "dosha":     "Kapha",
        "guna":      "Sattva-Rajas",
        "symbol":    "Triumphal arch, potter's wheel",
        "theme":     "Goal-pursuit, intensity, focused achievement, triumph",
    },
    "Anuradha": {
        "deity":     "Mitra (god of friendship)",
        "lord":      "Saturn",
        "yoni":      "Deer (female)",
        "varna":     "Shudra",
        "gana":      "Deva",
        "body_part": "Stomach, breasts",
        "direction": "South",
        "dosha":     "Pitta",
        "guna":      "Tamas-Sattva",
        "symbol":    "Lotus flower, archway",
        "theme":     "Devotional friendship, loyal bonds, structured devotion",
    },
    "Jyeshtha": {
        "deity":     "Indra (king of gods)",
        "lord":      "Mercury",
        "yoni":      "Deer (male)",
        "varna":     "Servant",
        "gana":      "Rakshasa",
        "body_part": "Right side, neck",
        "direction": "West",
        "dosha":     "Vata",
        "guna":      "Sattva-Rajas",
        "symbol":    "Earring, umbrella, talisman",
        "theme":     "Senior leadership, eldest-born wisdom, hidden authority",
    },
    "Mula": {
        "deity":     "Nirriti (goddess of dissolution)",
        "lord":      "Ketu",
        "yoni":      "Dog (male)",
        "varna":     "Butcher",
        "gana":      "Rakshasa",
        "body_part": "Feet",
        "direction": "North",
        "dosha":     "Vata",
        "guna":      "Sattva-Sattva",
        "symbol":    "Tied roots, bunch of roots",
        "theme":     "Uprooting, getting to root cause, severe endings, foundational truths",
    },
    "Purva Ashadha": {
        "deity":     "Apas (water goddess)",
        "lord":      "Venus",
        "yoni":      "Monkey (male)",
        "varna":     "Brahmin",
        "gana":      "Manushya",
        "body_part": "Back, thighs",
        "direction": "East",
        "dosha":     "Pitta",
        "guna":      "Sattva-Rajas",
        "symbol":    "Hand fan, winnowing basket, tusk",
        "theme":     "Early-stage invincibility, purifying water, declaration of victory",
    },
    "Uttara Ashadha": {
        "deity":     "Vishvadevas (universal gods)",
        "lord":      "Sun",
        "yoni":      "Mongoose (male)",
        "varna":     "Kshatriya",
        "gana":      "Manushya",
        "body_part": "Thighs",
        "direction": "South",
        "dosha":     "Kapha",
        "guna":      "Sattva-Sattva",
        "symbol":    "Elephant tusk, planks of bed",
        "theme":     "Final victory, lasting dharma, completion of purpose",
    },
    "Shravana": {
        "deity":     "Vishnu (cosmic preserver)",
        "lord":      "Moon",
        "yoni":      "Monkey (female)",
        "varna":     "Mleccha",
        "gana":      "Deva",
        "body_part": "Ears, organs of hearing",
        "direction": "West",
        "dosha":     "Kapha",
        "guna":      "Rajas-Sattva",
        "symbol":    "Three footprints, ear",
        "theme":     "Listening, learning scripture, hearing truth, oral wisdom (shruti)",
    },
    "Dhanishta": {
        "deity":     "Eight Vasus (deities of wealth)",
        "lord":      "Mars",
        "yoni":      "Lion (female)",
        "varna":     "Servant",
        "gana":      "Rakshasa",
        "body_part": "Back",
        "direction": "North",
        "dosha":     "Pitta",
        "guna":      "Rajas-Tamas",
        "symbol":    "Drum, flute",
        "theme":     "Wealth from rhythm/music, group success, performance",
    },
    "Shatabhisha": {
        "deity":     "Varuna (cosmic waters, occult)",
        "lord":      "Rahu",
        "yoni":      "Mare (female)",
        "varna":     "Butcher",
        "gana":      "Rakshasa",
        "body_part": "Jaw, right thigh",
        "direction": "East",
        "dosha":     "Vata",
        "guna":      "Tamas-Rajas",
        "symbol":    "Empty circle, 100 healers, flower",
        "theme":     "Hundred healers, mystical healing, occult medicine, secret",
    },
    "Purva Bhadrapada": {
        "deity":     "Aja Ekapada (one-footed serpent)",
        "lord":      "Jupiter",
        "yoni":      "Lion (male)",
        "varna":     "Brahmin",
        "gana":      "Manushya",
        "body_part": "Left side, soles",
        "direction": "South",
        "dosha":     "Vata",
        "guna":      "Sattva-Rajas",
        "symbol":    "Sword, two front legs of cot",
        "theme":     "Fierce austerity, asceticism, fiery wisdom",
    },
    "Uttara Bhadrapada": {
        "deity":     "Ahirbudhnya (cosmic serpent of depths)",
        "lord":      "Saturn",
        "yoni":      "Cow (female)",
        "varna":     "Kshatriya",
        "gana":      "Manushya",
        "body_part": "Sides, shins",
        "direction": "West",
        "dosha":     "Pitta",
        "guna":      "Tamas-Sattva",
        "symbol":    "Twins, snake in the depths",
        "theme":     "Deep cosmic wisdom, mystic retreat, ancient knowledge",
    },
    "Revati": {
        "deity":     "Pushan (nourishing/path-protector god)",
        "lord":      "Mercury",
        "yoni":      "Elephant (female)",
        "varna":     "Shudra",
        "gana":      "Deva",
        "body_part": "Belly, ankles",
        "direction": "North",
        "dosha":     "Kapha",
        "guna":      "Sattva-Sattva",
        "symbol":    "Drum, fish swimming",
        "theme":     "Final completion, last journey, transcendent nourishment",
    },
}


# ════════════════════════════════════════════════════════════════════════
# GANDANTA ZONES — 3 junctions where water sign ends + fire sign begins
# Each Gandanta is the last 3°20' of (Cancer/Scorpio/Pisces) + first 3°20'
# of the next sign (Leo/Sagittarius/Aries). Total ~6°40' wide.
# Source: BPHS Ch. 4; classical Gandanta tradition
# ════════════════════════════════════════════════════════════════════════

GANDANTA_ZONES: List[Dict] = [
    {"junction":   "Cancer-Leo (Ashlesha → Magha)",
     "water_sign": "Cancer", "fire_sign": "Leo",
     "water_nak":  "Ashlesha (last 3°20')", "fire_nak": "Magha (first 3°20')",
     "intensity":  "very_high",
     "theme":      "Emotional dissolution → ancestral karma awakening; serpent-to-throne transition"},
    {"junction":   "Scorpio-Sagittarius (Jyeshtha → Mula)",
     "water_sign": "Scorpio", "fire_sign": "Sagittarius",
     "water_nak":  "Jyeshtha (last 3°20')", "fire_nak": "Mula (first 3°20')",
     "intensity":  "high",
     "theme":      "Senior authority → root-uprooting; oldest-elder to severe-truth transition"},
    {"junction":   "Pisces-Aries (Revati → Ashwini)",
     "water_sign": "Pisces", "fire_sign": "Aries",
     "water_nak":  "Revati (last 3°20')", "fire_nak": "Ashwini (first 3°20')",
     "intensity":  "high",
     "theme":      "Final completion → new beginning; transcendence to initiation"},
]


# ════════════════════════════════════════════════════════════════════════
# NAKSHATRA YOGAS — Classical patterns
# ════════════════════════════════════════════════════════════════════════

NAKSHATRA_YOGAS: Dict[str, Dict[str, str]] = {
    "abhijit_override": {
        "rule":   "Abhijit (~6°40'-10°53' Capricorn / last bit of Uttara Ashadha + start of Shravana) is a 28th nakshatra in some classical reckonings — used for Muhurta",
        "effect": "If Moon/planets fall in this zone, it's considered very auspicious for new starts",
    },
    "mula_dasha_warning": {
        "rule":   "Moon in Mula nakshatra at birth (especially pada 1) requires Mula Shanti ritual classically — birth at root-cutting",
        "effect": "Karmic intensity — uprooting karma in early life; remedied via classical Mula Shanti",
    },
    "ashlesha_dasha_warning": {
        "rule":   "Moon in Ashlesha at birth requires Sarpa Shanti ritual",
        "effect": "Serpent karma; classical remedy via Ashlesha Shanti ritual",
    },
    "jyeshtha_dasha_warning": {
        "rule":   "Moon in Jyeshtha at birth requires Jyeshtha Shanti ritual",
        "effect": "Elder/authority karma; relationship with elder family member; classical Jyeshtha Shanti",
    },
    "gandanta_birth": {
        "rule":   "Moon or Lagna in any of the 3 Gandanta zones (~6°40' total)",
        "effect": "Major karmic transition at birth; intense early-life dissolutions; classical Gandanta Shanti",
    },
    "tri_pushkara_yoga": {
        "rule":   "Specific tithi + day + nakshatra combination creating triple-strong moments",
        "effect": "Auspicious for completions; results manifest threefold",
    },
}


# ════════════════════════════════════════════════════════════════════════
# BHRIGU NADI PRINCIPLES — Conjunction + 2nd-from-planet logic
# Source: Bhrigu Samhita tradition (classical Bhrigu Nadi); public domain principles
# ════════════════════════════════════════════════════════════════════════

BHRIGU_NADI_RULES: Dict[str, Dict[str, str]] = {
    "second_from_planet": {
        "rule":     "Sign 2nd from any planet (or its house) reveals the RESULTS of that planet's significations",
        "example":  "If Jupiter is in sign A, the sign 2nd from Jupiter shows what wealth/wisdom Jupiter produces",
        "use":      "For each planet, check 2nd-from placement and its lord for fruit indications",
    },
    "conjunction_logic": {
        "rule":     "Planets in same sign blend significations — read combined karma, not separate",
        "example":  "Sun + Mercury conjunction = intellectual recognition (Budhaditya), not just two separate karmas",
        "use":      "Treat each planet-cluster as a single karmic unit",
    },
    "karaka_houses": {
        "rule":     "Each planet has natural house significations (Sun=1, Moon=4, Mars=3, Mercury=2, Jupiter=2/5/9/11, Venus=7, Saturn=8/10/12)",
        "example":  "Jupiter's strength uplifts 2/5/9/11 themes regardless of which house it occupies",
        "use":      "Always cross-check natural karaka houses for each planet",
    },
    "double_transit": {
        "rule":     "Events fruit when Jupiter + Saturn transit the same point/planet/karaka simultaneously",
        "example":  "Marriage typically requires Jupiter and Saturn to both aspect/transit 7th house, Venus, or Darakaraka",
        "use":      "Major life events = double-transit theory for timing",
    },
    "dasha_pratyantar_validation": {
        "rule":     "Event timing requires dasha (MD/AD/PD) + transit alignment + natal promise",
        "example":  "No promise in natal chart → no fulfillment even in supportive dasha",
        "use":      "All three conditions must align for event manifestation",
    },
}


# ════════════════════════════════════════════════════════════════════════
# NADI-SPECIFIC PARIHARAS (REMEDIES)
# Source: Nadi tradition classical remedies
# ════════════════════════════════════════════════════════════════════════

NADI_PARIHARAS: Dict[str, str] = {
    "moon_in_ashlesha": "Sarpa Suktam (Snake hymn) recitation; Naga Devata puja; Ashlesha Bali ritual",
    "moon_in_mula":     "Mula Shanti puja before age 8; Ganesha puja for root-blessing; tree-planting for atonement",
    "moon_in_jyeshtha": "Jyeshtha Shanti puja; respect for eldest family member; classical 27-priest ritual",
    "moon_in_revati":   "Pushan puja (path-protector); travel-blessing rituals at major life transitions",
    "gandanta_birth":   "Gandanta Shanti — 27 lamps + specific homa for nakshatra-junction transit",
    "rahu_in_ashlesha": "Mahamrityunjaya mantra; Naga puja; Rahu Shanti for serpent-nakshatra karma",
    "ketu_in_mula":     "Ganesha puja; Mula tree (banyan/peepal) circumambulation; Ketu Shanti",
    "general_nadi":     "Nakshatra Pushpa (flower of one's nakshatra) offered weekly to ruling deity",
}


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "nakshatra_lore":  "Brihat Samhita (Varahamihira, ~6th c. CE); Surya Siddhanta on nakshatra divisions",
    "pada_navamsha":   "BPHS Ch. 8 (Vargas); classical Navamsha-pada correspondence",
    "gandanta":        "BPHS Ch. 4; classical Gandanta tradition (~Kalachakra texts)",
    "bhrigu_nadi":     "Bhrigu Samhita (~traditional Bhrigu Nadi compendium); public domain principles",
    "chandra_nadi":    "Chandra Nadi (~classical Tamil/Sanskrit Nadi tradition)",
    "nakshatra_yogas": "BPHS Ch. 99 (Panchang); classical nakshatra-yoga literature",
    "pariharas":       "Classical Nadi remedy tradition; Mantra Pushpa; Brihat Samhita on shanti rituals",
}
