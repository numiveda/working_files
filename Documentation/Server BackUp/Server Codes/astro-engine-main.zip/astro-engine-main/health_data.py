"""
health_data.py — Static classical data for Health + Chakra + Ayurveda module

Sources (all public domain):
- Charaka Samhita (~300 BCE-200 CE)
- Sushruta Samhita (~600 BCE)
- Ashtanga Hridaya by Vagbhata (~600 CE)
- Hatha Yoga Pradipika by Svatmarama (~1500 CE)
- Gheranda Samhita (~17th c.)
- Brihat Parashara Hora Shastra (BPHS)
- Sarvartha Chintamani by Venkatesh (~17th c.)
- Yoga Sutras of Patanjali (~400 BCE)
"""

# ════════════════════════════════════════════════════════════════════════
# 1. DETAILED BODY-PART RULERSHIP BY HOUSE + PLANET
# Source: Charaka Samhita Ch. 8 + BPHS Ch. 30
# ════════════════════════════════════════════════════════════════════════

HOUSE_TO_BODY_PART = {
    1:  {"region": "head, brain, complexion, overall vitality, immune system", "system": "neurological + skin"},
    2:  {"region": "face, eyes (right), nose, mouth, teeth, throat (upper), tongue, speech", "system": "sensory + speech"},
    3:  {"region": "neck, shoulders, arms (right), hands, ears, lungs (right side)", "system": "respiratory + motor (right)"},
    4:  {"region": "chest, heart, lungs, breasts, stomach (upper)", "system": "cardio-pulmonary"},
    5:  {"region": "stomach (mid), liver (upper), spine (mid), heart (mental)", "system": "digestive + emotional"},
    6:  {"region": "intestines, kidneys, navel, lower abdomen, immune system (disease)", "system": "digestive + excretory + immunity"},
    7:  {"region": "kidneys (lower), uterus, ovaries, prostate, bladder, lower back", "system": "reproductive + urinary"},
    8:  {"region": "genitals, anus, rectum, sexual organs, chronic conditions, longevity", "system": "reproductive + chronic"},
    9:  {"region": "hips, thighs, liver (lower), gall bladder", "system": "hepatic + lower limbs (upper)"},
    10: {"region": "knees, joints, bones (whole body), career-related stress", "system": "musculoskeletal"},
    11: {"region": "calves, ankles, lower legs, circulation (lower)", "system": "circulatory (lower)"},
    12: {"region": "feet, lymphatic system, sleep, eyes (left), mental seclusion", "system": "lymphatic + sleep + foot"},
}


# Planet-specific organ rulership (more granular than astro_helpers.PLANET_TO_BODY_PART)
PLANET_DETAILED_ORGANS = {
    "Sun": {
        "primary":     ["heart", "right eye (males) / left eye (females)", "spine", "stomach"],
        "secondary":   ["arteries", "vitality", "bones (with Saturn)"],
        "dosha":       "pitta",
        "tissue":      "asthi (bones), majja (marrow)",
        "weak_when":   "afflicted, debilitated in Libra, combust planets near",
    },
    "Moon": {
        "primary":     ["mind", "blood", "lymph", "stomach", "breasts", "lungs (fluid)"],
        "secondary":   ["left eye (males) / right eye (females)", "fluids overall"],
        "dosha":       "vata + kapha",
        "tissue":      "rasa (lymph/plasma)",
        "weak_when":   "Krishna paksha (waning), in Scorpio (debilitated), conjoined Rahu/Ketu",
    },
    "Mars": {
        "primary":     ["muscles", "blood", "bone marrow", "head", "external genitalia"],
        "secondary":   ["energy", "courage", "fever production", "wounds"],
        "dosha":       "pitta",
        "tissue":      "rakta (blood), majja (marrow)",
        "weak_when":   "debilitated in Cancer, retrograde, in 6/8/12 with malefics",
    },
    "Mercury": {
        "primary":     ["skin", "nervous system", "lungs", "voice", "intestines", "fingers"],
        "secondary":   ["speech mechanics", "digestion-absorption", "tongue"],
        "dosha":       "tridoshic",
        "tissue":      "all (Mercury rules tissue formation)",
        "weak_when":   "combust (especially close to Sun), debilitated in Pisces",
    },
    "Jupiter": {
        "primary":     ["liver", "fat tissue", "thighs", "hips", "ears", "tongue (taste)"],
        "secondary":   ["pancreas", "sciatica (when afflicted)", "cholesterol"],
        "dosha":       "kapha",
        "tissue":      "meda (fat)",
        "weak_when":   "debilitated in Capricorn, retrograde causing weight issues",
    },
    "Venus": {
        "primary":     ["kidneys", "reproductive system", "throat (lower)", "semen/ova", "skin (beauty)"],
        "secondary":   ["genitourinary", "endocrine (with Mercury)", "hormones"],
        "dosha":       "kapha + vata",
        "tissue":      "shukra (reproductive)",
        "weak_when":   "debilitated in Virgo, combust, afflicted by Mars",
    },
    "Saturn": {
        "primary":     ["bones", "teeth", "knees", "nerves (chronic)", "joints"],
        "secondary":   ["chronic conditions", "aging", "vata disorders"],
        "dosha":       "vata",
        "tissue":      "asthi (bones), majja (marrow)",
        "weak_when":   "debilitated in Aries, in 6/8/12, sade sati period",
    },
    "Rahu": {
        "primary":     ["skin (chronic conditions)", "nervous afflictions", "addictions", "mysterious illness"],
        "secondary":   ["poisoning", "auto-immune (with Ketu)", "phobias"],
        "dosha":       "vata",
        "tissue":      "indirect — affects all tissues through anomalies",
        "weak_when":   "in 6/8/12 with malefics, retrograde",
    },
    "Ketu": {
        "primary":     ["abdomen (lower)", "immunity", "scars", "surgical conditions"],
        "secondary":   ["auto-immune", "spinal issues", "moksha-related body weakness"],
        "dosha":       "vata + pitta",
        "tissue":      "indirect — sudden tissue depletion",
        "weak_when":   "in 6/8/12, conjunct malefics",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 2. DISEASE PREDISPOSITION RULES
# Source: BPHS Ch. 30 (Rishtadhyaya) + Charaka Sutrasthana
# ════════════════════════════════════════════════════════════════════════

DISEASE_PREDISPOSITION_RULES = {
    "6th_house_analysis": {
        "description": "6th house = roga (disease) bhava. Sign + planets here indicate disease tendencies.",
        "by_sign": {
            "Aries":       "head/brain disorders, fevers, blood pressure (high)",
            "Taurus":      "throat, neck, thyroid, food poisoning",
            "Gemini":      "respiratory, nervous system, hands, mental anxiety",
            "Cancer":      "stomach, breasts, lungs, emotional eating",
            "Leo":         "heart, spine, vitality decline, ego-related stress",
            "Virgo":       "intestines, digestive sensitivities, IBS, perfectionism stress",
            "Libra":       "kidneys, lower back, hormonal balance issues",
            "Scorpio":     "reproductive, eliminative, chronic deep conditions",
            "Sagittarius": "hips, liver, sciatica, over-indulgence diseases",
            "Capricorn":   "joints, knees, bones, arthritis, depression",
            "Aquarius":    "circulation (lower), ankles, nervous system anomalies",
            "Pisces":      "feet, lymphatic, sleep disorders, addictions",
        },
        "planet_in_6th": {
            "Sun":     "heart strain, eye issues, paternal genetic conditions, ego conflict illness",
            "Moon":    "emotional/mental health, water retention, female cycle issues",
            "Mars":    "fevers, accidents, surgical conditions, blood disorders",
            "Mercury": "skin, nerves, IBS, anxiety-related",
            "Jupiter": "diabetes (with afflictions), liver, weight issues",
            "Venus":   "reproductive, kidney, sweet tooth diseases",
            "Saturn":  "chronic, slow-developing, arthritis (especially with age)",
            "Rahu":    "mysterious/undiagnosed, allergies, addictions, sudden onset",
            "Ketu":    "auto-immune, surgical, scars, sudden ending of conditions",
        },
    },
    "8th_house_analysis": {
        "description": "8th house = longevity + chronic + transformative conditions",
        "key_rule": "Malefics in 8th without benefic aspect = chronic conditions, longevity concerns",
        "lord_of_8_in": {
            "1st": "self-health concerns, head/brain region issues",
            "2nd": "wealth-stress related, throat/face conditions",
            "6th": "ironically protective (Vipareeta Rajayoga in some cases) — sudden recovery from disease",
            "8th": "longevity issues, deep transformation needed",
            "12th": "hospitalization, foreign treatment, hidden conditions",
        },
    },
    "12th_house_analysis": {
        "description": "12th house = hospitalization, sleep, eyes (left), foreign medical treatment",
        "key_rule": "Benefics in 12th = good sleep, peaceful death; Malefics = insomnia, hospitalization",
    },
    "ascendant_afflictions": {
        "description": "Lagna (1st house) = overall body. Affliction here = chronic constitutional weakness.",
        "by_lagna_lord_house": {
            "in_6th":  "lifelong battle with chronic disease",
            "in_8th":  "transformation through illness; potential longevity concerns",
            "in_12th": "loss of vitality; hospital/foreign-land health issues",
        },
    },
}


# ════════════════════════════════════════════════════════════════════════
# 3. AYURVEDIC PRAKRITI DETERMINATION
# Source: Charaka Vimana Sthana Ch. 8 + Sushruta Sharira Ch. 4
# ════════════════════════════════════════════════════════════════════════

PRAKRITI_BY_LAGNA = {
    # Lagna sign primary dosha + secondary
    "Aries":       {"primary": "pitta", "secondary": "kapha", "type": "Pitta-Kapha"},
    "Taurus":      {"primary": "kapha", "secondary": "vata",  "type": "Kapha-Vata"},
    "Gemini":      {"primary": "vata",  "secondary": "pitta", "type": "Vata-Pitta"},
    "Cancer":      {"primary": "kapha", "secondary": "pitta", "type": "Kapha-Pitta"},
    "Leo":         {"primary": "pitta", "secondary": "vata",  "type": "Pitta-Vata"},
    "Virgo":       {"primary": "vata",  "secondary": "pitta", "type": "Vata-Pitta"},
    "Libra":       {"primary": "vata",  "secondary": "kapha", "type": "Vata-Kapha"},
    "Scorpio":     {"primary": "kapha", "secondary": "pitta", "type": "Kapha-Pitta"},
    "Sagittarius": {"primary": "pitta", "secondary": "vata",  "type": "Pitta-Vata"},
    "Capricorn":   {"primary": "vata",  "secondary": "kapha", "type": "Vata-Kapha"},
    "Aquarius":    {"primary": "vata",  "secondary": "pitta", "type": "Vata-Pitta"},
    "Pisces":      {"primary": "kapha", "secondary": "vata",  "type": "Kapha-Vata"},
}


# Nakshatra-based dosha modifier (Moon's nakshatra refines prakriti)
NAKSHATRA_DOSHA_MODIFIER = {
    "Ashwini":           "vata",   "Bharani":           "pitta",  "Krittika":          "pitta",
    "Rohini":            "kapha",  "Mrigashira":        "vata",   "Ardra":             "vata",
    "Punarvasu":         "kapha",  "Pushya":            "kapha",  "Ashlesha":          "vata",
    "Magha":             "pitta",  "Purva Phalguni":    "pitta",  "Uttara Phalguni":   "vata",
    "Hasta":             "vata",   "Chitra":            "pitta",  "Swati":             "vata",
    "Vishakha":          "kapha",  "Anuradha":          "pitta",  "Jyeshtha":          "vata",
    "Mula":              "vata",   "Purva Ashadha":     "pitta",  "Uttara Ashadha":    "kapha",
    "Shravana":          "kapha",  "Dhanishta":         "pitta",  "Shatabhisha":       "vata",
    "Purva Bhadrapada":  "pitta",  "Uttara Bhadrapada": "pitta",  "Revati":            "kapha",
}


# Dosha characteristics
DOSHA_CHARACTERISTICS = {
    "vata": {
        "elements":  ["air", "ether"],
        "qualities": ["dry", "light", "cold", "rough", "subtle", "mobile"],
        "season":    "autumn, early winter",
        "tastes_pacify": ["sweet", "sour", "salty"],
        "tastes_aggravate": ["pungent", "bitter", "astringent"],
        "body_type": "thin, slim, light bones, dry skin, irregular features",
        "mental":    "creative, quick, enthusiastic, anxious when imbalanced",
        "diseases_prone": "joint pain, dryness, gas, insomnia, anxiety, constipation, tremors",
        "balancing_principles": "warmth, oil, routine, slow steady food, grounding",
    },
    "pitta": {
        "elements":  ["fire", "water"],
        "qualities": ["hot", "sharp", "light", "oily", "liquid", "spreading"],
        "season":    "summer, late autumn",
        "tastes_pacify": ["sweet", "bitter", "astringent"],
        "tastes_aggravate": ["pungent", "sour", "salty"],
        "body_type": "medium build, sharp features, warm skin, fair to reddish complexion",
        "mental":    "sharp intellect, decisive, irritable when imbalanced, perfectionist",
        "diseases_prone": "inflammation, fevers, ulcers, skin rashes, acidity, anger",
        "balancing_principles": "cooling, moderation, calm, sweet food, gentle exercise",
    },
    "kapha": {
        "elements":  ["earth", "water"],
        "qualities": ["heavy", "cold", "oily", "smooth", "dense", "soft", "stable"],
        "season":    "late winter, spring",
        "tastes_pacify": ["pungent", "bitter", "astringent"],
        "tastes_aggravate": ["sweet", "sour", "salty"],
        "body_type": "heavy build, strong bones, smooth skin, full features",
        "mental":    "calm, loyal, slow to learn but retentive; lethargic when imbalanced",
        "diseases_prone": "congestion, obesity, diabetes, lethargy, sinus, depression",
        "balancing_principles": "warmth, activity, light food, stimulation, change",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 4. AYURVEDIC DIET BY DOSHA
# Source: Charaka Sutra Sthana Ch. 25-27
# ════════════════════════════════════════════════════════════════════════

DIET_BY_DOSHA = {
    "vata": {
        "favor": {
            "grains":     ["rice (basmati, white)", "oats (cooked)", "wheat (warm bread)"],
            "vegetables": ["cooked root vegetables (carrots, beets, sweet potato)", "asparagus", "okra"],
            "fruits":     ["bananas (ripe)", "mangoes", "papaya", "stewed apples", "dates", "figs"],
            "proteins":   ["paneer", "fresh cheese", "ghee", "eggs (poached)", "chicken (warm)"],
            "spices":     ["ginger", "cinnamon", "cardamom", "cumin", "fennel", "asafetida"],
            "drinks":     ["warm water", "ginger tea", "almond milk (warm)"],
        },
        "avoid": {
            "grains":     ["raw oats", "rye", "millet (excess)"],
            "vegetables": ["raw salads (excess)", "broccoli (raw)", "cauliflower (raw)"],
            "fruits":     ["dried fruit (without soaking)", "unripe fruits", "apples (raw)"],
            "proteins":   ["red meat (heavy, in excess)", "tofu (cold)"],
            "spices":     ["excessive chili"],
            "drinks":     ["cold water", "ice", "carbonated drinks"],
        },
        "meal_principles": [
            "Eat warm, cooked, oily foods",
            "Regular meal times (vata needs routine)",
            "3 full meals; avoid skipping",
            "Sweet, sour, salty tastes dominate",
            "Slow-paced eating in calm environment",
        ],
    },
    "pitta": {
        "favor": {
            "grains":     ["wheat", "rice", "barley", "oats"],
            "vegetables": ["cucumber", "lettuce", "leafy greens", "cilantro", "zucchini"],
            "fruits":     ["sweet fruits", "grapes", "pears", "melons", "coconut"],
            "proteins":   ["paneer", "milk (cool)", "ghee", "egg whites", "fish (cool)"],
            "spices":     ["coriander", "fennel", "mint", "saffron (small amounts)", "cardamom"],
            "drinks":     ["coconut water", "rose water", "mint tea (cool)", "milk"],
        },
        "avoid": {
            "grains":     ["corn (excess)", "millet"],
            "vegetables": ["chili peppers", "raw onions", "garlic (in excess)", "tomatoes (ripe excess)"],
            "fruits":     ["sour citrus (excess)", "unripe fruits"],
            "proteins":   ["egg yolks (in excess)", "red meat", "shellfish"],
            "spices":     ["chili", "black pepper (excess)", "mustard"],
            "drinks":     ["coffee (in excess)", "alcohol", "carbonated"],
        },
        "meal_principles": [
            "Eat cool, slightly raw foods in summer",
            "Sweet, bitter, astringent tastes dominate",
            "Avoid eating when angry or rushed",
            "Lunch is biggest meal (when pitta is highest)",
            "Avoid skipping meals (pitta becomes irritable when hungry)",
        ],
    },
    "kapha": {
        "favor": {
            "grains":     ["barley", "millet", "rye", "buckwheat", "corn"],
            "vegetables": ["leafy greens", "cabbage", "broccoli", "cauliflower", "asparagus", "spinach"],
            "fruits":     ["apples", "pears", "berries", "pomegranate", "dried fruits (small amounts)"],
            "proteins":   ["legumes (small amounts)", "chicken (lean, dry)", "egg whites"],
            "spices":     ["ginger", "black pepper", "turmeric", "mustard", "cayenne", "cinnamon"],
            "drinks":     ["ginger tea", "tulsi tea", "warm water with lemon", "honey water"],
        },
        "avoid": {
            "grains":     ["wheat (excess)", "rice (excess white)"],
            "vegetables": ["raw heavy vegetables", "potatoes (in excess)"],
            "fruits":     ["bananas", "avocado (excess)", "very sweet fruits"],
            "proteins":   ["dairy (heavy)", "red meat", "shellfish", "tofu (excess)"],
            "spices":     ["salt (in excess)", "very sweet spices"],
            "drinks":     ["cold drinks", "milk (cool, heavy)", "sweet drinks", "alcohol"],
        },
        "meal_principles": [
            "Eat light, warm, dry foods",
            "Pungent, bitter, astringent tastes dominate",
            "2 main meals; light or skip dinner",
            "Lunch is biggest meal",
            "Walk after eating",
            "Avoid breakfast if not hungry",
        ],
    },
}


# ════════════════════════════════════════════════════════════════════════
# 5. YOGA + PRANAYAMA BY DOSHA / PLANET
# Source: Hatha Yoga Pradipika + Gheranda Samhita
# ════════════════════════════════════════════════════════════════════════

YOGA_BY_DOSHA = {
    "vata": {
        "asanas_favor": [
            "Surya Namaskar (slow, with breath)", "Tadasana", "Vrikshasana (Tree)",
            "Vajrasana (after meals)", "Balasana (Child)", "Setu Bandhasana (Bridge)",
            "Forward folds (gentle)", "Restorative poses",
        ],
        "asanas_avoid": ["fast vinyasa", "long-held inversions (without preparation)", "deep backbends without warmup"],
        "pranayama":    ["Nadi Shodhana (alternate nostril)", "Brahmari (humming)", "Ujjayi (slow)"],
        "principles":   ["slow, smooth, stable", "warming, grounding", "minimum 3-5 sessions per week"],
    },
    "pitta": {
        "asanas_favor": [
            "Moon salutations (Chandra Namaskar)", "Twists (gentle)", "Bhujangasana (Cobra, gentle)",
            "Matsyendrasana", "Janu Sirsasana", "Cooling forward folds", "Yoga Nidra",
        ],
        "asanas_avoid": ["intense heat practices", "long-held warrior poses (in summer)", "Bikram-style hot yoga (in excess)"],
        "pranayama":    ["Shitali (cooling tongue)", "Shitkari (cooling teeth)", "Chandra Bhedana (left-nostril)"],
        "principles":   ["cooling", "non-competitive", "easeful intensity", "avoid hot environments"],
    },
    "kapha": {
        "asanas_favor": [
            "Surya Namaskar (vigorous)", "Sun salutations × 12 rounds", "Warrior poses (Virabhadrasana)",
            "Standing balances", "Backbends (Dhanurasana, Ushtrasana)", "Twists (active)",
            "Strength sequences", "Headstand (Sirsasana) with preparation",
        ],
        "asanas_avoid": ["excessive restorative poses (without active practice)", "long savasana without preceding movement"],
        "pranayama":    ["Bhastrika (bellows breath)", "Kapalabhati (skull-shining)", "Surya Bhedana (right-nostril)"],
        "principles":   ["vigorous", "warming", "stimulating", "daily morning practice ideal"],
    },
}


YOGA_BY_PLANET = {
    # Asanas/practices that strengthen each planet
    "Sun":     ["Surya Namaskar", "Heart-opening backbends", "Bhastrika pranayama", "Tratak on flame"],
    "Moon":    ["Chandra Namaskar", "Setu Bandhasana", "Hip-opening", "Yoga Nidra", "Shitali"],
    "Mars":    ["Warrior poses", "Bhujangasana", "Kapalabhati", "Surya Bhedana"],
    "Mercury": ["Hand mudras", "Twists", "Tongue exercises", "Brahmari, Ujjayi"],
    "Jupiter": ["Vajrasana", "Padmasana (Lotus)", "Yamas/Niyamas study", "Wisdom practices"],
    "Venus":   ["Hip openers", "Sensual movement flows", "Heart practices", "Music + sound yoga"],
    "Saturn":  ["Long-held grounding poses", "Walking meditation", "Slow yin yoga", "Knee strengthening"],
    "Rahu":    ["Tratak", "Concentration practices", "Psychedelic awareness (cautious)"],
    "Ketu":    ["Meditation", "Detachment practices", "Letting-go pranayama", "Spinal awareness"],
}


# ════════════════════════════════════════════════════════════════════════
# 6. MENTAL HEALTH ANALYSIS
# Source: Charaka Sharirasthana Ch. 1 (Manas) + BPHS Ch. 30
# ════════════════════════════════════════════════════════════════════════

MENTAL_HEALTH_INDICATORS = {
    "moon_analysis": {
        "description": "Moon is karaka of mind (Chitta). Moon afflictions = mental health concerns.",
        "moon_signs": {
            "Aries":       "impulsive, quick-tempered mind; passionate ideas",
            "Taurus":      "stable, sensual, but stubborn; food-comfort tendencies",
            "Gemini":      "scattered, anxious, communicative; mental restlessness",
            "Cancer":      "emotional, nurturing, mood swings (exalted)",
            "Leo":         "proud, dramatic, attention-needing mind",
            "Virgo":       "analytical, perfectionist, prone to OCD tendencies",
            "Libra":       "balance-seeking, indecisive, harmony-prioritizing",
            "Scorpio":     "DEBILITATED — deep, intense, prone to obsession/depression",
            "Sagittarius": "philosophical, restless wandering mind",
            "Capricorn":   "serious, ambitious, prone to depression with afflictions",
            "Aquarius":    "detached, unconventional, can become isolated",
            "Pisces":      "imaginative, escapist, prone to addictions",
        },
        "moon_afflictions": {
            "with_saturn": "tendency to depression, isolation, melancholy",
            "with_mars":   "anger, irritability, impulsivity",
            "with_rahu":   "anxiety, paranoia, addictions, illusions",
            "with_ketu":   "detachment to depression, escapism",
            "in_6_8_12":   "chronic mental tendencies requiring conscious work",
        },
    },
    "mercury_analysis": {
        "description": "Mercury = Buddhi (intellect). Mercury afflictions = communication/learning challenges.",
        "key_rule": "Strong Mercury = clear thinking; afflicted = anxiety, indecision, speech issues",
    },
    "5th_house_analysis": {
        "description": "5th house = Purva Punya + intellect + creativity. Afflictions here = creative blocks.",
    },
    "stress_patterns_by_dosha": {
        "vata":  "anxiety, racing thoughts, insomnia, fear, restlessness",
        "pitta": "anger, irritability, perfectionism stress, burnout, impatience",
        "kapha": "depression, lethargy, attachment, grief that won't release",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 7. LONGEVITY (AYU) FACTORS
# Source: Sarvartha Chintamani + BPHS Ch. 75-76
# ════════════════════════════════════════════════════════════════════════

LONGEVITY_FACTORS = {
    "classification": {
        "alpaayu":   "short life (under 32 years) — by classical reckoning",
        "madhyaayu": "medium life (32-70 years)",
        "purnayu":   "long life (70+)",
        "ativrudh":  "very long life (100+, rare)",
    },
    "positive_factors": [
        "Strong Lagna and Lagna lord",
        "Benefics in kendra (1, 4, 7, 10) or trikona (1, 5, 9)",
        "Jupiter strong in 1st, 5th, or 9th",
        "Saturn in own sign or exaltation (8th house Saturn often gives long life)",
        "8th lord well-placed",
        "Moon strong (chitta balance)",
        "No major doshas in 8th or 12th",
    ],
    "challenging_factors": [
        "Malefics in 8th without benefic aspect",
        "Lagna lord in 8th, 12th, or with malefics",
        "Multiple debilitated planets",
        "Severe Kaal Sarpa Yoga without protective Jupiter",
        "Mars-Saturn-Rahu conjunctions afflicting Lagna",
        "Moon between malefics (Papakartari)",
    ],
    "preservation_practices": {
        "yoga":       "daily asana + pranayama (longevity is mentioned in Patanjali Yoga Sutras as one of the siddhis of practice)",
        "diet":       "Sattvic, dosha-balanced",
        "rituals":    "Mahamrityunjaya Mantra (108 daily)",
        "lifestyle":  "Brahma Muhurta wake, proper sleep, meditation",
        "remedies":   "Saturn pacification (if afflicted), Jupiter strengthening",
        "donations":  "regular charity reduces karmic lifespan burdens",
    },
    "ayurvedic_rasayana": [
        "Ashwagandha (rejuvenative, vata)",
        "Amalaki (rasayana for all doshas)",
        "Brahmi (mental rejuvenation)",
        "Shilajit (overall vitality)",
        "Triphala (digestive rasayana)",
        "Chyawanprash (general rasayana — combines all)",
    ],
}


# ════════════════════════════════════════════════════════════════════════
# 8. HEALING WINDOWS — TIMING FOR MEDICAL DECISIONS
# Source: Muhurta Chintamani + BPHS
# ════════════════════════════════════════════════════════════════════════

HEALING_WINDOWS = {
    "favorable_for_treatment_start": {
        "weekdays":   ["Monday (Moon — gentle)", "Wednesday (Mercury — healing)", "Thursday (Jupiter — blessings)"],
        "nakshatras": ["Ashwini (healing nakshatra)", "Pushya", "Hasta", "Rohini", "Mrigashira"],
        "tithis":     ["Panchami (5th)", "Saptami (7th)", "Trayodashi (13th)"],
        "lunar_phase":"Shukla paksha (waxing) for building/rejuvenative treatment",
    },
    "avoid_for_major_procedures": {
        "weekdays":   ["Tuesday (Mars — surgery risk)", "Saturday (Saturn — slow healing)"],
        "nakshatras": ["Bharani (transformation/death)", "Mula (uprooting)", "Jyeshtha (eldest, exposure)", "Ardra (storms)"],
        "tithis":     ["Chaturthi (4th)", "Ashtami (8th)", "Chaturdashi (14th)", "Amavasya"],
        "lunar_phase":"Krishna paksha (waning) — avoid for new beginnings; OK for surgical removal",
        "transit":    "When Moon is afflicted by Saturn or Rahu",
    },
    "specific_treatments": {
        "surgery":         "Krishna paksha, sharp nakshatras (Bharani, Krittika, Magha), Mars hora",
        "rejuvenation":    "Shukla paksha, soft nakshatras (Mrigashira, Chitra, Anuradha), Jupiter hora",
        "panchakarma":     "Late winter/early spring (kapha season), Mercury or Moon-favorable days",
        "yoga_initiation": "Guru Pushya yoga, Sravana, Ashwini, Pushya nakshatras",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 9. CHAKRA-SPECIFIC BALANCING PRACTICES
# Source: Hatha Yoga Pradipika + Shiva Samhita
# ════════════════════════════════════════════════════════════════════════

CHAKRA_BALANCING = {
    "muladhara": {
        "asanas":      ["Malasana (Garland)", "Mountain pose", "Bridge", "Warrior I"],
        "pranayama":   ["Mula Bandha", "deep belly breathing"],
        "mantras":     ["Lam (108 times)", "Ganesh mantras"],
        "meditation":  "focus on perineum/base of spine; visualize red 4-petaled lotus",
        "food":        "root vegetables, beets, red foods, grounding meals",
        "essential_oils": ["vetiver", "patchouli", "sandalwood"],
        "imbalance_signs": "fear, financial anxiety, lower body issues, instability",
    },
    "svadhisthana": {
        "asanas":      ["Hip openers", "Goddess pose", "Pigeon pose", "Cobra"],
        "pranayama":   ["belly breathing", "slow ujjayi"],
        "mantras":     ["Vam (108 times)"],
        "meditation":  "focus on lower abdomen; orange 6-petaled lotus",
        "food":        "sweet juicy fruits (mango, papaya), nuts, seeds",
        "essential_oils": ["jasmine", "rose", "ylang ylang"],
        "imbalance_signs": "creative blocks, sexual issues, emotional repression, hip stiffness",
    },
    "manipura": {
        "asanas":      ["Twists", "Plank", "Boat", "Warrior III"],
        "pranayama":   ["Kapalabhati", "Agnisara Kriya"],
        "mantras":     ["Ram (108 times)"],
        "meditation":  "focus on navel; yellow 10-petaled lotus",
        "food":        "yellow foods, ginger, turmeric, digestive fire-supporting",
        "essential_oils": ["lemon", "chamomile", "cinnamon"],
        "imbalance_signs": "low self-esteem, digestive issues, anger, over-control",
    },
    "anahata": {
        "asanas":      ["Camel", "Wheel", "Heart openers", "Bow"],
        "pranayama":   ["full yogic breath", "Sahita kumbhaka"],
        "mantras":     ["Yam (108 times)"],
        "meditation":  "focus on heart center; green/pink 12-petaled lotus",
        "food":        "leafy greens, green foods, heart-opening foods",
        "essential_oils": ["rose", "geranium", "bergamot"],
        "imbalance_signs": "grief, loneliness, heart issues, codependency, closed-off",
    },
    "vishuddha": {
        "asanas":      ["Plough", "Shoulder stand", "Fish pose", "Camel"],
        "pranayama":   ["Ujjayi", "Brahmari (humming)", "throat singing"],
        "mantras":     ["Ham (108 times)", "Om chanting"],
        "meditation":  "focus on throat; blue 16-petaled lotus",
        "food":        "blue/purple fruits, herbal teas, throat-soothing foods",
        "essential_oils": ["eucalyptus", "peppermint", "tea tree"],
        "imbalance_signs": "communication blocks, thyroid, voice/throat issues, lying",
    },
    "ajna": {
        "asanas":      ["Child's pose with focus", "Forward folds with third-eye contact", "Head balance"],
        "pranayama":   ["Nadi Shodhana", "Trataka (candle gazing)"],
        "mantras":     ["Om", "Sham"],
        "meditation":  "focus between eyebrows; indigo 2-petaled lotus",
        "food":        "purple foods, dark berries, brain-supporting foods",
        "essential_oils": ["frankincense", "clary sage", "juniper"],
        "imbalance_signs": "headaches, eye issues, confusion, lack of intuition, vivid dreams (excess)",
    },
    "sahasrara": {
        "asanas":      ["Headstand", "Tree pose", "Lotus"],
        "pranayama":   ["Kevala kumbhaka", "natural breath"],
        "mantras":     ["silence / Aum"],
        "meditation":  "focus on crown; thousand-petaled lotus",
        "food":        "fasting, light food, sattvic",
        "essential_oils": ["lotus", "rose", "frankincense"],
        "imbalance_signs": "spiritual disconnection, depression, headaches at crown, materialism",
    },
}
