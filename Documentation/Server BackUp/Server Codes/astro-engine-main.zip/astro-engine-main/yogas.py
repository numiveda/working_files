"""
yogas.py — numiVeda Astro Engine — Yogas Master Engine

Public API:
    detect_all(chart)        -> All 198 yogas with is_present status
    detect_active(chart)     -> Only yogas where is_present == True
    detect_positive(chart)   -> Active positive yogas only
    detect_negative(chart)   -> Active negative yogas only
    get_catalog()            -> Full catalog metadata (no chart)
    get_yoga(yoga_id)        -> Single yoga lookup

All outputs are structured data only — no narrative prose.
LLM writes Compass Report narratives from this data.
"""

from typing import Dict, Any, List, Optional
from yogas_catalog_1 import CATALOG_1
from yogas_catalog_2 import CATALOG_2
from yogas_catalog_3 import CATALOG_3
from yogas_helpers import (
    planet_summary, planet_house, planet_sign, lord_of_house,
    dignity, KENDRA_HOUSES, TRIKONA_HOUSES, DUSTHANA_HOUSES,
)

# ─────────────────────────────────────────────────────────────────────────────
# CONSOLIDATED CATALOG
# ─────────────────────────────────────────────────────────────────────────────

YOGA_CATALOG: List[Dict[str, Any]] = CATALOG_1 + CATALOG_2 + CATALOG_3

# Index for fast lookup
YOGA_BY_ID: Dict[str, Dict[str, Any]] = {y["yoga_id"]: y for y in YOGA_CATALOG}


# ─────────────────────────────────────────────────────────────────────────────
# STRENGTH ESTIMATOR (when no custom strength_fn provided)
# ─────────────────────────────────────────────────────────────────────────────

def _estimate_strength(chart: dict, yoga: dict) -> int:
    """
    Default strength estimator (0-100) based on:
    - Dignity of involved planets (from the formation logic — heuristic)
    - Yoga family weight
    - Polarity baseline
    """
    base = 50
    family = yoga.get("family", "")

    # Family-based adjustments
    if family in ("pancha_mahapurusha", "raja_yoga", "dhana_yoga"):
        base += 20
    elif family in ("vipreet_raja", "special_outcome"):
        base += 15
    elif family in ("arishta", "daridra"):
        base -= 10
    elif family in ("nabhasa_akriti", "nabhasa_sankhya", "nabhasa_ashraya", "nabhasa_dala"):
        base += 10
    elif family == "argala":
        base = 40  # argala is supportive but mild

    # Polarity baseline modifier
    polarity = yoga.get("polarity", "neutral")
    if polarity == "positive":   base += 5
    elif polarity == "negative": base -= 5

    return max(0, min(100, base))


# ─────────────────────────────────────────────────────────────────────────────
# DETECTION CORE
# ─────────────────────────────────────────────────────────────────────────────

def _build_yoga_result(chart: dict, yoga: dict, is_present: bool) -> Dict[str, Any]:
    """Assemble the output block for one yoga."""
    strength = 0
    if is_present:
        sf = yoga.get("strength_fn")
        if callable(sf):
            try:
                strength = sf(chart)
            except Exception:
                strength = _estimate_strength(chart, yoga)
        else:
            strength = _estimate_strength(chart, yoga)

    return {
        "yoga_id":         yoga["yoga_id"],
        "name_en":         yoga["name_en"],
        "name_sa":         yoga["name_sa"],
        "family":          yoga["family"],
        "polarity":        yoga["polarity"],
        "source":          yoga["source"],
        "formation_rule":  yoga["formation_rule"],
        "is_present":      bool(is_present),
        "strength":        int(strength),
        "domains":         yoga.get("domains", []),
        "general_effect":  yoga.get("general_effect", ""),
        "remedy_hooks":    yoga.get("remedy_hooks", []),
    }


def detect_all(chart: dict) -> Dict[str, Any]:
    """
    Run detection on every yoga in the catalog.
    Returns full results including non-present yogas (for static-style catalog views).
    """
    results = []
    errors = []
    for y in YOGA_CATALOG:
        try:
            is_present = bool(y["detect"](chart))
            results.append(_build_yoga_result(chart, y, is_present))
        except Exception as e:
            results.append(_build_yoga_result(chart, y, False))
            errors.append({"yoga_id": y["yoga_id"], "error": str(e)})

    active = [r for r in results if r["is_present"]]
    return {
        "total_yogas":     len(YOGA_CATALOG),
        "active_count":    len(active),
        "positive_count":  sum(1 for r in active if r["polarity"] == "positive"),
        "negative_count":  sum(1 for r in active if r["polarity"] == "negative"),
        "neutral_count":   sum(1 for r in active if r["polarity"] == "neutral"),
        "yogas":           results,
        "errors":          errors,
    }


def detect_active(chart: dict) -> Dict[str, Any]:
    """Return only the yogas that are present in the chart."""
    full = detect_all(chart)
    return {
        "active_count":    full["active_count"],
        "positive_count":  full["positive_count"],
        "negative_count":  full["negative_count"],
        "neutral_count":   full["neutral_count"],
        "yogas":           [y for y in full["yogas"] if y["is_present"]],
        "errors":          full["errors"],
    }


def detect_positive(chart: dict) -> Dict[str, Any]:
    """Return only the active positive yogas (Raja, Dhana, Special Outcome, etc.)."""
    full = detect_all(chart)
    positive_active = [y for y in full["yogas"] if y["is_present"] and y["polarity"] == "positive"]
    # Sort by strength descending
    positive_active.sort(key=lambda y: -y["strength"])
    return {
        "count":     len(positive_active),
        "yogas":     positive_active,
        "errors":    full["errors"],
    }


def detect_negative(chart: dict) -> Dict[str, Any]:
    """Return only the active negative yogas (Arishta, Daridra, doshas)."""
    full = detect_all(chart)
    negative_active = [y for y in full["yogas"] if y["is_present"] and y["polarity"] == "negative"]
    # Sort by strength descending (most impactful first)
    negative_active.sort(key=lambda y: -y["strength"])
    return {
        "count":     len(negative_active),
        "yogas":     negative_active,
        "errors":    full["errors"],
    }


# ─────────────────────────────────────────────────────────────────────────────
# STATIC CATALOG (no chart needed)
# ─────────────────────────────────────────────────────────────────────────────

def get_catalog(family_filter: Optional[str] = None) -> Dict[str, Any]:
    """
    Return the full yoga catalog metadata without running detection.
    Useful for the chat app and UI references.
    Optionally filter by family code.
    """
    entries = YOGA_CATALOG
    if family_filter:
        entries = [y for y in entries if y["family"] == family_filter]

    return {
        "total":     len(entries),
        "families":  sorted({y["family"] for y in YOGA_CATALOG}),
        "yogas":     [
            {
                "yoga_id":        y["yoga_id"],
                "name_en":        y["name_en"],
                "name_sa":        y["name_sa"],
                "family":         y["family"],
                "polarity":       y["polarity"],
                "source":         y["source"],
                "formation_rule": y["formation_rule"],
                "domains":        y.get("domains", []),
                "general_effect": y.get("general_effect", ""),
                "remedy_hooks":   y.get("remedy_hooks", []),
            }
            for y in entries
        ],
    }


def get_yoga(yoga_id: str) -> Dict[str, Any]:
    """Lookup a single yoga by ID (no chart, just metadata)."""
    y = YOGA_BY_ID.get(yoga_id)
    if not y:
        return {"error": f"Unknown yoga_id: {yoga_id}",
                "suggestions": [k for k in YOGA_BY_ID if yoga_id.lower() in k.lower()][:5]}
    return {
        "yoga_id":        y["yoga_id"],
        "name_en":        y["name_en"],
        "name_sa":        y["name_sa"],
        "family":         y["family"],
        "polarity":       y["polarity"],
        "source":         y["source"],
        "formation_rule": y["formation_rule"],
        "domains":        y.get("domains", []),
        "general_effect": y.get("general_effect", ""),
        "remedy_hooks":   y.get("remedy_hooks", []),
    }
