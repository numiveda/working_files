"""
numerology_v2.py — Comprehensive numerology engine.

Covers ALL static numerology numbers (single point in time, name + DOB):
  - Pythagorean: Moolank, Bhagyank, Destiny, Soul Urge, Personality, 
    Birth Day, Maturity, Cornerstone, Capstone, First Vowel
  - Chaldean: Compound + reduced name number
  - Cheiro / Sepharial: Day-of-birth meanings, name + DOB harmony
  - Karmic: Karmic Debt numbers (13/14/16/19), Karmic Lessons (missing digits),
    Hidden Passion (most-repeated digit)
  - Lo Shu Grid: 3×3 grid + 8 yogas + missing-numbers
  - Kua: Direction-based luck number

Time-cycle numbers (Personal Year, Pinnacles, etc.) are in numerology_v2_cycles.py
Compatibility is in numerology_v2_compatibility.py

Source authorities: Cheiro, Sepharial, Mantreshwara (Lo Shu),
   Pythagoras tradition, K.P. Pearson, Hans Decoz.
"""

from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, date


# ─────────────────────────────────────────────────────────────────────────────
# LETTER → NUMBER MAPS
# ─────────────────────────────────────────────────────────────────────────────

PYTHAGOREAN_MAP = {
    "A":1,"B":2,"C":3,"D":4,"E":5,"F":6,"G":7,"H":8,"I":9,
    "J":1,"K":2,"L":3,"M":4,"N":5,"O":6,"P":7,"Q":8,"R":9,
    "S":1,"T":2,"U":3,"V":4,"W":5,"X":6,"Y":7,"Z":8,
}

CHALDEAN_MAP = {
    "A":1,"I":1,"J":1,"Q":1,"Y":1,
    "B":2,"K":2,"R":2,
    "C":3,"G":3,"L":3,"S":3,
    "D":4,"M":4,"T":4,
    "E":5,"H":5,"N":5,"X":5,
    "U":6,"V":6,"W":6,
    "O":7,"Z":7,
    "F":8,"P":8,
    # No letter = 9 in Chaldean (9 is considered sacred)
}

VOWELS = set("AEIOU")
CONSONANTS = set("BCDFGHJKLMNPQRSTVWXZ")
# Y is sometimes vowel sometimes consonant — context-dependent. Default = consonant.


# ─────────────────────────────────────────────────────────────────────────────
# NUMBER → PLANET / TRAIT MAPS
# ─────────────────────────────────────────────────────────────────────────────

NUMBER_RULER = {
    1:  {"planet": "Sun",      "traits": "Leadership, individuality, originality, will, initiative"},
    2:  {"planet": "Moon",     "traits": "Sensitive, intuitive, diplomatic, partnership-oriented, gentle"},
    3:  {"planet": "Jupiter",  "traits": "Creative, expressive, optimistic, social, lucky"},
    4:  {"planet": "Rahu",     "traits": "Practical, disciplined, methodical, hardworking, foundation-builder"},
    5:  {"planet": "Mercury",  "traits": "Versatile, communicative, restless, freedom-loving, quick"},
    6:  {"planet": "Venus",    "traits": "Loving, responsible, nurturing, artistic, family-oriented"},
    7:  {"planet": "Ketu",     "traits": "Spiritual, analytical, mystical, introspective, philosophical"},
    8:  {"planet": "Saturn",   "traits": "Ambitious, authoritative, material success, karmic, disciplined"},
    9:  {"planet": "Mars",     "traits": "Humanitarian, courageous, idealistic, completion-oriented, intense"},
    11: {"planet": "Master 11", "traits": "Spiritual messenger, illumination, intuitive teacher, sensitive"},
    22: {"planet": "Master 22", "traits": "Master builder, large-scale manifestation, practical visionary"},
    33: {"planet": "Master 33", "traits": "Master teacher, selfless service, compassion in action"},
}


# ─────────────────────────────────────────────────────────────────────────────
# CORE REDUCTION FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def _reduce_to_single(n: int, preserve_masters: bool = True) -> int:
    """Repeatedly sum digits until single (1-9). Optionally preserve 11/22/33."""
    while n > 9:
        if preserve_masters and n in (11, 22, 33):
            return n
        n = sum(int(d) for d in str(n))
    return n


def _digit_sum(n: int) -> int:
    """Sum the digits once (not reduced to single)."""
    return sum(int(d) for d in str(abs(n)))


def _name_to_digits(name: str, letter_map: Dict[str, int]) -> List[int]:
    """Convert name string to list of digit values, ignoring spaces/punctuation."""
    name = name.upper()
    return [letter_map[ch] for ch in name if ch in letter_map]


# ─────────────────────────────────────────────────────────────────────────────
# 1. PYTHAGOREAN — All name-derived & DOB-derived numbers
# ─────────────────────────────────────────────────────────────────────────────

def pythagorean_moolank(dob: str) -> Dict[str, Any]:
    """Moolank = day of birth reduced to single digit (preserve masters)."""
    day = int(dob.split("-")[2])
    value = _reduce_to_single(day, preserve_masters=True)
    return {
        "value": value,
        "raw_day": day,
        "planet": NUMBER_RULER[value]["planet"],
        "traits": NUMBER_RULER[value]["traits"],
    }


def pythagorean_bhagyank(dob: str) -> Dict[str, Any]:
    """Bhagyank (Life Path) = full DOB summed, reduced."""
    parts = [int(x) for x in dob.replace("-", "").replace("/", "")]
    total = sum(parts)
    value = _reduce_to_single(total, preserve_masters=True)
    return {
        "value": value,
        "raw_sum": total,
        "planet": NUMBER_RULER[value]["planet"],
        "traits": NUMBER_RULER[value]["traits"],
    }


def pythagorean_destiny(name: str) -> Dict[str, Any]:
    """Destiny (Expression) = full name letters summed, reduced."""
    digits = _name_to_digits(name, PYTHAGOREAN_MAP)
    total = sum(digits)
    value = _reduce_to_single(total, preserve_masters=True)
    return {
        "value": value,
        "raw_sum": total,
        "planet": NUMBER_RULER[value]["planet"],
        "traits": NUMBER_RULER[value]["traits"],
    }


def pythagorean_soul_urge(name: str) -> Dict[str, Any]:
    """Soul Urge (Heart's Desire) = vowels only, summed and reduced.
    Reveals deepest motivations, what the soul truly wants."""
    name = name.upper()
    digits = [PYTHAGOREAN_MAP[ch] for ch in name if ch in PYTHAGOREAN_MAP and ch in VOWELS]
    total = sum(digits)
    value = _reduce_to_single(total, preserve_masters=True)
    return {
        "value": value,
        "raw_sum": total,
        "planet": NUMBER_RULER[value]["planet"],
        "meaning": f"Deepest motivation: {NUMBER_RULER[value]['traits']}",
        "interpretation_note": "Reveals what your soul truly desires beneath surface goals",
    }


def pythagorean_personality(name: str) -> Dict[str, Any]:
    """Personality (Outer Self) = consonants only, summed and reduced.
    How others perceive you on first impression."""
    name = name.upper()
    digits = [PYTHAGOREAN_MAP[ch] for ch in name if ch in PYTHAGOREAN_MAP and ch in CONSONANTS]
    total = sum(digits)
    value = _reduce_to_single(total, preserve_masters=True)
    return {
        "value": value,
        "raw_sum": total,
        "planet": NUMBER_RULER[value]["planet"],
        "meaning": f"How others see you: {NUMBER_RULER[value]['traits']}",
        "interpretation_note": "The outer mask — what people perceive before knowing you",
    }


def pythagorean_birthday(dob: str) -> Dict[str, Any]:
    """Birth Day Number = raw day (1-31), NOT reduced — each has its own meaning."""
    day = int(dob.split("-")[2])
    return {
        "value": day,
        "reduced": _reduce_to_single(day, preserve_masters=True),
        "interpretation_note": "Specific talent or gift you brought into this life",
    }


def pythagorean_maturity(name: str, dob: str) -> Dict[str, Any]:
    """Maturity Number = Life Path + Destiny, reduced. Becomes prominent after age ~35."""
    lp = pythagorean_bhagyank(dob)["value"]
    de = pythagorean_destiny(name)["value"]
    total = lp + de
    value = _reduce_to_single(total, preserve_masters=True)
    return {
        "value": value,
        "raw_sum": total,
        "components": {"life_path": lp, "destiny": de},
        "planet": NUMBER_RULER[value]["planet"],
        "meaning": f"Late-life direction (post age 35): {NUMBER_RULER[value]['traits']}",
    }


def pythagorean_cornerstone(name: str) -> Dict[str, Any]:
    """First letter of name = cornerstone. How you approach life."""
    name = name.upper().strip()
    if not name or name[0] not in PYTHAGOREAN_MAP:
        return {"letter": "", "value": 0, "meaning": "n/a"}
    letter = name[0]
    value = PYTHAGOREAN_MAP[letter]
    return {
        "letter": letter,
        "value": value,
        "planet": NUMBER_RULER[value]["planet"],
        "meaning": f"Approach to life: {NUMBER_RULER[value]['traits']}",
    }


def pythagorean_capstone(name: str) -> Dict[str, Any]:
    """Last letter of full name = capstone. How you complete things."""
    name = name.upper().strip().replace(" ", "")
    if not name or name[-1] not in PYTHAGOREAN_MAP:
        return {"letter": "", "value": 0, "meaning": "n/a"}
    letter = name[-1]
    value = PYTHAGOREAN_MAP[letter]
    return {
        "letter": letter,
        "value": value,
        "planet": NUMBER_RULER[value]["planet"],
        "meaning": f"How you complete things: {NUMBER_RULER[value]['traits']}",
    }


def pythagorean_first_vowel(name: str) -> Dict[str, Any]:
    """First vowel = inner-self glimpse. The first vowel of the first name."""
    name = name.upper()
    for ch in name:
        if ch in VOWELS:
            value = PYTHAGOREAN_MAP[ch]
            return {
                "letter": ch,
                "value": value,
                "planet": NUMBER_RULER[value]["planet"],
                "meaning": f"Inner self glimpse: {NUMBER_RULER[value]['traits']}",
            }
    return {"letter": "", "value": 0, "meaning": "n/a"}


# ─────────────────────────────────────────────────────────────────────────────
# 2. CHALDEAN
# ─────────────────────────────────────────────────────────────────────────────

def chaldean_name(name: str) -> Dict[str, Any]:
    """Chaldean name number — compound (preserved) AND reduced."""
    digits = _name_to_digits(name, CHALDEAN_MAP)
    compound = sum(digits)
    reduced = _reduce_to_single(compound, preserve_masters=False)
    return {
        "compound": compound,
        "reduced": reduced,
        "planet": NUMBER_RULER.get(reduced, {}).get("planet", "?"),
        "meaning": f"Vibrational essence of your name: {NUMBER_RULER.get(reduced,{}).get('traits','?')}",
        "interpretation_note": "Chaldean preserves the compound number — it carries karmic weight",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 3. KARMIC DEBT & LESSONS (Pythagorean)
# ─────────────────────────────────────────────────────────────────────────────

KARMIC_DEBT_MEANINGS = {
    13: "Past misuse of energy → must work hard to gain results; transformation through effort",
    14: "Past misuse of freedom → must learn discipline within independence",
    16: "Past misuse of love → ego-shattering events that lead to spiritual rebirth",
    19: "Past misuse of power → must learn to use authority without selfishness",
}


def karmic_debt(dob: str, name: str) -> Dict[str, Any]:
    """Detect karmic debt numbers 13/14/16/19 in DOB sum or name sum (before reduction)."""
    dob_parts = [int(x) for x in dob.replace("-", "")]
    dob_sum = sum(dob_parts)
    name_sum = sum(_name_to_digits(name, PYTHAGOREAN_MAP))
    found = []
    # Track intermediate sums during reduction
    for label, raw in (("life_path", dob_sum), ("destiny", name_sum)):
        n = raw
        while n > 9:
            if n in KARMIC_DEBT_MEANINGS:
                found.append({
                    "debt_number": n,
                    "location": label,
                    "meaning": KARMIC_DEBT_MEANINGS[n],
                })
                break
            n = sum(int(d) for d in str(n))
    return {
        "has_karmic_debt": len(found) > 0,
        "debts": found,
        "interpretation_note": "Karmic debts indicate past-life patterns to resolve in this lifetime",
    }


def karmic_lessons(name: str) -> Dict[str, Any]:
    """Karmic Lessons = numbers (1-9) MISSING from the name's digit set."""
    digits = set(_name_to_digits(name, PYTHAGOREAN_MAP))
    missing = sorted(set(range(1, 10)) - digits)
    lessons = []
    for m in missing:
        lessons.append({
            "missing_number": m,
            "planet": NUMBER_RULER[m]["planet"],
            "lesson": f"Develop the qualities of {m}: {NUMBER_RULER[m]['traits']}",
        })
    return {
        "lesson_count": len(lessons),
        "missing_numbers": missing,
        "lessons": lessons,
        "interpretation_note": "Numbers missing from your name are qualities you must consciously develop",
    }


def hidden_passion(name: str) -> Dict[str, Any]:
    """Hidden Passion = the most-repeated digit in the name."""
    digits = _name_to_digits(name, PYTHAGOREAN_MAP)
    if not digits:
        return {"value": 0, "frequency": 0, "meaning": "n/a"}
    counts = {}
    for d in digits:
        counts[d] = counts.get(d, 0) + 1
    max_count = max(counts.values())
    most_freq = sorted([d for d, c in counts.items() if c == max_count])
    return {
        "value": most_freq[0],
        "frequency": max_count,
        "all_top_values": most_freq,
        "planet": NUMBER_RULER[most_freq[0]]["planet"],
        "meaning": f"Latent talent: {NUMBER_RULER[most_freq[0]]['traits']}",
        "interpretation_note": "The most-repeated number in your name is your hidden gift or obsession",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 4. LO SHU GRID (Chinese / Vedic 3×3 grid)
# ─────────────────────────────────────────────────────────────────────────────

LOSHU_POSITIONS = {
    # 3×3 grid: (row, col) — row 0 = top
    4: (0, 0), 9: (0, 1), 2: (0, 2),
    3: (1, 0), 5: (1, 1), 7: (1, 2),
    8: (2, 0), 1: (2, 1), 6: (2, 2),
}


def lo_shu_grid(dob: str) -> Dict[str, Any]:
    """Lo Shu 3×3 grid: counts of digits 1-9 in DOB + yoga detection."""
    digits = [int(d) for d in dob.replace("-", "") if d.isdigit()]
    counts = {n: 0 for n in range(1, 10)}
    for d in digits:
        if 1 <= d <= 9:
            counts[d] += 1

    # Build the grid as a 3x3 with count values
    grid = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
    for n, (r, c) in LOSHU_POSITIONS.items():
        grid[r][c] = counts[n]

    # Detect yogas (full rows / columns / diagonals where all 3 cells have digits)
    yogas_present = []
    # Rows
    if grid[0][0] and grid[0][1] and grid[0][2]: yogas_present.append({"name": "Vidya Yoga (top row 4-9-2)", "axis": "row1", "meaning": "Strong intellect, education"})
    if grid[1][0] and grid[1][1] and grid[1][2]: yogas_present.append({"name": "Raja Yoga (middle row 3-5-7)", "axis": "row2", "meaning": "Royal status, recognition"})
    if grid[2][0] and grid[2][1] and grid[2][2]: yogas_present.append({"name": "Karma Yoga (bottom row 8-1-6)", "axis": "row3", "meaning": "Strong action, manifestation"})
    # Columns
    if grid[0][0] and grid[1][0] and grid[2][0]: yogas_present.append({"name": "Dharma Yoga (left col 4-3-8)", "axis": "col1", "meaning": "Dharmic discipline"})
    if grid[0][1] and grid[1][1] and grid[2][1]: yogas_present.append({"name": "Yash Yoga (middle col 9-5-1)", "axis": "col2", "meaning": "Fame, recognition"})
    if grid[0][2] and grid[1][2] and grid[2][2]: yogas_present.append({"name": "Dhana Yoga (right col 2-7-6)", "axis": "col3", "meaning": "Wealth accumulation"})
    # Diagonals
    if grid[0][0] and grid[1][1] and grid[2][2]: yogas_present.append({"name": "Punya Yoga (diag 4-5-6)", "axis": "diag1", "meaning": "Spiritual merit"})
    if grid[0][2] and grid[1][1] and grid[2][0]: yogas_present.append({"name": "Wealth Yoga (diag 2-5-8)", "axis": "diag2", "meaning": "Material gains"})

    missing = [n for n in range(1, 10) if counts[n] == 0]

    return {
        "counts": counts,
        "grid_3x3": grid,
        "yogas_present": yogas_present,
        "yoga_count": len(yogas_present),
        "missing_numbers": missing,
        "missing_count": len(missing),
        "interpretation_note": "Lo Shu reveals natal energy distribution; missing numbers indicate lessons; yogas indicate strengths",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 5. KUA NUMBER (Feng Shui)
# ─────────────────────────────────────────────────────────────────────────────

KUA_GROUPS = {
    1: {"group": "East",  "lucky_directions": ["E","SE","N","S"], "trigram": "Kan (water)"},
    2: {"group": "West",  "lucky_directions": ["NE","W","NW","SW"], "trigram": "Kun (earth)"},
    3: {"group": "East",  "lucky_directions": ["E","SE","N","S"], "trigram": "Chen (thunder)"},
    4: {"group": "East",  "lucky_directions": ["E","SE","N","S"], "trigram": "Sun (wind)"},
    5: {"group": "West",  "lucky_directions": ["NE","W","NW","SW"], "trigram": "Center"},
    6: {"group": "West",  "lucky_directions": ["NE","W","NW","SW"], "trigram": "Qian (heaven)"},
    7: {"group": "West",  "lucky_directions": ["NE","W","NW","SW"], "trigram": "Dui (lake)"},
    8: {"group": "West",  "lucky_directions": ["NE","W","NW","SW"], "trigram": "Gen (mountain)"},
    9: {"group": "East",  "lucky_directions": ["E","SE","N","S"], "trigram": "Li (fire)"},
}


def kua_number(dob: str, gender: str = "male") -> Dict[str, Any]:
    """Kua number for Feng Shui — based on year of birth + gender."""
    year = int(dob.split("-")[0])
    year_sum = _reduce_to_single(_digit_sum(year), preserve_masters=False)
    if gender.lower().startswith("m"):
        k = 11 - year_sum
        if k > 9: k = k - 9
        if k == 5: k = 2
    else:
        k = year_sum + 4
        if k > 9: k = k - 9
        if k == 5: k = 8
    info = KUA_GROUPS.get(k, {})
    return {
        "value": k,
        "group": info.get("group"),
        "trigram": info.get("trigram"),
        "lucky_directions": info.get("lucky_directions", []),
        "interpretation_note": "Kua determines compatible directions for sleeping, working, sitting",
    }
