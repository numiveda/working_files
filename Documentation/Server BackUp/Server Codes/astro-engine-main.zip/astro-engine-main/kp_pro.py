"""
kp_pro.py — numiVeda Kaaliyo Astro Engine — Module D4 (v2 — full Placidus).

V2 UPGRADE: Real Placidus cusps via direct Swiss Ephemeris call.
Replaces equal-house approximation from v1. KP-lite caveat removed.

The sub-lord algorithm itself is unchanged (it was already exact). What changes
is that intermediate house cusps (H2, H3, H5, H6, H8, H9, H11, H12) now use
genuine Placidus values, which means their cuspal sub-lords are accurate to
full-KP standards.

Endpoints (signatures unchanged):
    handle_profile
    handle_sub_lord_for_longitude
    handle_planet_sub_lords
    handle_lagna_sub_lord
    handle_cuspal_sub_lords         — NOW USES PLACIDUS
    handle_ruling_planets
    handle_significators
    handle_house_significators      — NOW USES PLACIDUS
    handle_moment_lookup
    handle_query_horoscope
"""

import swisseph as swe
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from zoneinfo import ZoneInfo

from astro_helpers import (
    extract_chart_essentials,
    get_chart,
    SIGNS_ORDER,
    SIGN_TO_LORD,
)

from kp_data import (
    NAKSHATRA_SEQUENCE,
    NAKSHATRA_LORD,
    VIMSHOTTARI_YEARS,
    VIMSHOTTARI_ORDER,
    PLANET_NATURAL_KARAKAS,
    KP_RULING_PLANETS_RULES,
    WEEKDAY_PLANET,
    KP_SIGNIFICATOR_HIERARCHY,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# SUB-LORD ALGORITHM (unchanged from v1 — already exact)
# ════════════════════════════════════════════════════════════════════════

NAKSHATRA_SPAN = 13 + 20.0/60.0  # 13°20' = 13.3333°
TOTAL_VIMS_YEARS = 120


def _absolute_longitude(sign: str, degree_within_sign: float) -> float:
    if sign not in SIGNS_ORDER:
        return 0.0
    return SIGNS_ORDER.index(sign) * 30.0 + float(degree_within_sign)


def _longitude_to_sign_degree(longitude: float) -> tuple:
    longitude = longitude % 360.0
    sign_idx = int(longitude // 30)
    deg = longitude - sign_idx * 30
    return SIGNS_ORDER[sign_idx], round(deg, 4)


def _nakshatra_of_longitude(longitude: float) -> Dict[str, Any]:
    longitude = longitude % 360.0
    nak_index = int(longitude // NAKSHATRA_SPAN)
    if nak_index >= 27:
        nak_index = 26
    nakshatra = NAKSHATRA_SEQUENCE[nak_index]
    nak_start = nak_index * NAKSHATRA_SPAN
    return {
        "nakshatra":       nakshatra,
        "nakshatra_index": nak_index,
        "nakshatra_lord":  NAKSHATRA_LORD[nakshatra],
        "nakshatra_start": nak_start,
        "nakshatra_end":   nak_start + NAKSHATRA_SPAN,
        "offset_into_nak": longitude - nak_start,
    }


def _vimshottari_sequence_from(start_planet: str) -> List[str]:
    if start_planet not in VIMSHOTTARI_ORDER:
        return list(VIMSHOTTARI_ORDER)
    idx = VIMSHOTTARI_ORDER.index(start_planet)
    return [VIMSHOTTARI_ORDER[(idx + i) % 9] for i in range(9)]


def _compute_sub_lord(longitude: float) -> Dict[str, Any]:
    nak_info = _nakshatra_of_longitude(longitude)
    nakshatra = nak_info["nakshatra"]
    nak_lord = nak_info["nakshatra_lord"]
    offset = nak_info["offset_into_nak"]

    sub_sequence = _vimshottari_sequence_from(nak_lord)
    cumulative = 0.0
    sub_lord = None
    sub_lord_start = 0.0
    sub_lord_span = 0.0

    for planet in sub_sequence:
        planet_share = (VIMSHOTTARI_YEARS[planet] / TOTAL_VIMS_YEARS) * NAKSHATRA_SPAN
        if offset < cumulative + planet_share:
            sub_lord = planet
            sub_lord_start = cumulative
            sub_lord_span = planet_share
            break
        cumulative += planet_share

    if sub_lord is None:
        sub_lord = sub_sequence[-1]
        sub_lord_start = cumulative
        sub_lord_span = (VIMSHOTTARI_YEARS[sub_lord] / TOTAL_VIMS_YEARS) * NAKSHATRA_SPAN

    offset_in_sub = offset - sub_lord_start
    sub_sub_sequence = _vimshottari_sequence_from(sub_lord)
    cumulative_in_sub = 0.0
    sub_sub_lord = None
    for planet in sub_sub_sequence:
        planet_share_in_sub = (VIMSHOTTARI_YEARS[planet] / TOTAL_VIMS_YEARS) * sub_lord_span
        if offset_in_sub < cumulative_in_sub + planet_share_in_sub:
            sub_sub_lord = planet
            break
        cumulative_in_sub += planet_share_in_sub
    if sub_sub_lord is None:
        sub_sub_lord = sub_sub_sequence[-1]

    return {
        "longitude":      round(longitude, 4),
        "sign":           _longitude_to_sign_degree(longitude)[0],
        "degree_in_sign": _longitude_to_sign_degree(longitude)[1],
        "nakshatra":      nakshatra,
        "star_lord":      nak_lord,
        "sub_lord":       sub_lord,
        "sub_sub_lord":   sub_sub_lord,
    }


# ════════════════════════════════════════════════════════════════════════
# CHART HELPERS
# ════════════════════════════════════════════════════════════════════════

def _build(birth: Dict[str, Any]):
    raw = get_chart(
        dob=birth["dob"], time=birth["time"],
        lat=birth["lat"], lon=birth["lon"],
        timezone=birth.get("timezone", "Asia/Kolkata"),
    )
    return raw, extract_chart_essentials(raw)


def _planet_to_longitude(planet_data: Dict[str, Any]) -> Optional[float]:
    if not isinstance(planet_data, dict):
        return None
    sign = planet_data.get("sign")
    degree = planet_data.get("degree")
    if sign is None or degree is None:
        return None
    return _absolute_longitude(sign, degree)


def _lagna_longitude(raw_chart: Dict[str, Any]) -> Optional[float]:
    return _planet_to_longitude(raw_chart.get("lagna", {}))


# ════════════════════════════════════════════════════════════════════════
# PLACIDUS CUSPS via Swiss Ephemeris (v2 UPGRADE)
# ════════════════════════════════════════════════════════════════════════

def _birth_to_jd_ut(birth: Dict[str, Any]) -> float:
    """Convert birth dob/time/timezone → Julian Day UT (absolute moment)."""
    dob = birth["dob"]
    time_str = birth["time"]
    tz_str = birth.get("timezone", "Asia/Kolkata")
    year, month, day = map(int, dob.split("-"))
    hour, minute = map(int, time_str.split(":"))
    tz = ZoneInfo(tz_str)
    local_dt = datetime(year, month, day, hour, minute, tzinfo=tz)
    ut_dt = local_dt.astimezone(ZoneInfo("UTC"))
    return swe.julday(
        ut_dt.year, ut_dt.month, ut_dt.day,
        ut_dt.hour + ut_dt.minute / 60.0 + ut_dt.second / 3600.0,
    )


def _placidus_cusps(birth: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Compute 12 Placidus house cusps using Swiss Ephemeris.
    Returns sidereal (Lahiri-adjusted) cusps.
    """
    jd_ut = _birth_to_jd_ut(birth)
    swe.set_sid_mode(swe.SIDM_LAHIRI)
    ayanamsha_deg = swe.get_ayanamsa_ut(jd_ut)

    cusps_tropical, ascmc = swe.houses_ex(jd_ut, birth["lat"], birth["lon"], b'P')

    cusps: List[Dict[str, Any]] = []
    for i in range(12):
        cusp_sidereal = (cusps_tropical[i] - ayanamsha_deg) % 360.0
        sign, deg = _longitude_to_sign_degree(cusp_sidereal)
        cusps.append({
            "house":     i + 1,
            "longitude": round(cusp_sidereal, 4),
            "sign":      sign,
            "degree":    deg,
        })
    return cusps


def _planet_house_from_cusps(planet_longitude: float, cusps: List[Dict[str, Any]]) -> int:
    """Determine house (1-12) a planet falls into given the 12 Placidus cusps."""
    cusp_lons = [c["longitude"] for c in cusps]
    for i in range(12):
        start = cusp_lons[i]
        end = cusp_lons[(i + 1) % 12]
        if start <= end:
            if start <= planet_longitude < end:
                return i + 1
        else:
            if planet_longitude >= start or planet_longitude < end:
                return i + 1
    return 1


# ════════════════════════════════════════════════════════════════════════
# RULING PLANETS LOGIC (unchanged from v1)
# ════════════════════════════════════════════════════════════════════════

def _ruling_planets_at_moment(dt_iso: str, lat: float, lon: float,
                              timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    dt = datetime.fromisoformat(dt_iso)
    chart = get_chart(
        dob=dt.date().isoformat(),
        time=dt.strftime("%H:%M"),
        lat=lat, lon=lon, timezone=timezone,
    )
    lagna = chart.get("lagna", {})
    moon = chart.get("planets", {}).get("Moon", {})

    lagna_sign = lagna.get("sign")
    lagna_sign_lord = SIGN_TO_LORD.get(lagna_sign)
    lagna_star_lord = NAKSHATRA_LORD.get(lagna.get("nakshatra", ""))

    moon_sign = moon.get("sign")
    moon_sign_lord = SIGN_TO_LORD.get(moon_sign)
    moon_star_lord = NAKSHATRA_LORD.get(moon.get("nakshatra", ""))

    weekday = dt.weekday()
    day_lord = WEEKDAY_PLANET[weekday]

    return {
        "moment":          dt_iso,
        "lagna_sign":      lagna_sign,
        "lagna_sign_lord": lagna_sign_lord,
        "lagna_star_lord": lagna_star_lord,
        "moon_sign":       moon_sign,
        "moon_sign_lord":  moon_sign_lord,
        "moon_star_lord":  moon_star_lord,
        "day_lord":        day_lord,
        "ruling_planets":  sorted(set(filter(None, [
            lagna_sign_lord, lagna_star_lord,
            moon_sign_lord,  moon_star_lord,
            day_lord,
        ]))),
    }


# ════════════════════════════════════════════════════════════════════════
# SIGNIFICATOR LOGIC (uses Placidus cusps for house-sign lookup)
# ════════════════════════════════════════════════════════════════════════

def _planets_in_house(essentials: Dict[str, Any], house: int) -> List[str]:
    return [p for p, pd in essentials.get("planets", {}).items()
            if isinstance(pd, dict) and pd.get("house") == house]


def _planets_in_nakshatra_of(target_planet: str,
                             planets_data: Dict[str, Any]) -> List[str]:
    result: List[str] = []
    for p, pd in planets_data.items():
        if isinstance(pd, dict) and pd.get("nakshatra_lord") == target_planet:
            result.append(p)
    return result


def _planet_signifies_houses(planet: str, raw: Dict, essentials: Dict) -> Dict[str, Any]:
    planet_data = essentials.get("planets", {}).get(planet, {})
    if not planet_data:
        return {"planet": planet, "signified_houses": []}

    signified_set = set()
    occ_house = planet_data.get("house")
    if occ_house:
        signified_set.add(occ_house)

    nak_lord = planet_data.get("nakshatra_lord")
    if nak_lord:
        nak_lord_house = essentials.get("planets", {}).get(nak_lord, {}).get("house")
        if nak_lord_house:
            signified_set.add(nak_lord_house)

    planet_sign = planet_data.get("sign")
    sign_lord = SIGN_TO_LORD.get(planet_sign) if planet_sign else None
    if sign_lord and sign_lord != planet:
        sign_lord_house = essentials.get("planets", {}).get(sign_lord, {}).get("house")
        if sign_lord_house:
            signified_set.add(sign_lord_house)

    nak_dependents = _planets_in_nakshatra_of(planet, raw.get("planets", {}))
    for dep in nak_dependents:
        dep_house = essentials.get("planets", {}).get(dep, {}).get("house")
        if dep_house:
            signified_set.add(dep_house)

    return {
        "planet":           planet,
        "occupied_house":   occ_house,
        "nakshatra_lord":   nak_lord,
        "nak_dependents":   nak_dependents,
        "signified_houses": sorted(signified_set),
    }


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT HANDLERS
# ════════════════════════════════════════════════════════════════════════

def handle_sub_lord_for_longitude(longitude: float) -> Dict[str, Any]:
    if not isinstance(longitude, (int, float)):
        return {"error": "longitude must be a number between 0 and 360"}
    if longitude < 0 or longitude >= 360:
        longitude = longitude % 360
    result = _compute_sub_lord(longitude)
    return {
        **result,
        "method":   "Vimshottari proportions within nakshatra (13°20' span).",
        "citation": CLASSICAL_CITATIONS["sub_lord"],
    }


def handle_planet_sub_lords(birth: Dict[str, Any]) -> Dict[str, Any]:
    raw, e = _build(birth)
    planets_data = raw.get("planets", {})

    results: Dict[str, Dict[str, Any]] = {}
    for planet in ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]:
        pd = planets_data.get(planet, {})
        lon = _planet_to_longitude(pd)
        if lon is None:
            continue
        sub_info = _compute_sub_lord(lon)
        results[planet] = {
            "sign":         pd.get("sign"),
            "degree":       pd.get("degree"),
            "longitude":    round(lon, 4),
            "house":        pd.get("house"),
            "nakshatra":    sub_info["nakshatra"],
            "star_lord":    sub_info["star_lord"],
            "sub_lord":     sub_info["sub_lord"],
            "sub_sub_lord": sub_info["sub_sub_lord"],
        }

    return {
        "planet_sub_lords": results,
        "planet_count":     len(results),
        "method":           "Each planet's star-lord/sub-lord/sub-sub-lord from its precise longitude.",
        "citation":         CLASSICAL_CITATIONS["sub_lord"],
    }


def handle_lagna_sub_lord(birth: Dict[str, Any]) -> Dict[str, Any]:
    raw, e = _build(birth)
    lagna_lon = _lagna_longitude(raw)
    if lagna_lon is None:
        return {"error": "Lagna longitude not resolvable"}
    sub_info = _compute_sub_lord(lagna_lon)
    return {
        "lagna_longitude":    round(lagna_lon, 4),
        "lagna_sign":         raw.get("lagna", {}).get("sign"),
        "lagna_degree":       raw.get("lagna", {}).get("degree"),
        "lagna_nakshatra":    sub_info["nakshatra"],
        "lagna_star_lord":    sub_info["star_lord"],
        "lagna_sub_lord":     sub_info["sub_lord"],
        "lagna_sub_sub_lord": sub_info["sub_sub_lord"],
        "note":               "Lagna sub-lord is the SINGLE most important KP indicator.",
        "citation":           CLASSICAL_CITATIONS["sub_lord"],
    }


def handle_cuspal_sub_lords(birth: Dict[str, Any]) -> Dict[str, Any]:
    """
    V2: Now uses real Placidus cusps from Swiss Ephemeris.
    KP-lite caveat removed.
    """
    cusps = _placidus_cusps(birth)
    cuspal_data: List[Dict[str, Any]] = []
    for cusp in cusps:
        sub_info = _compute_sub_lord(cusp["longitude"])
        cuspal_data.append({
            "house":         cusp["house"],
            "cusp_sign":     cusp["sign"],
            "cusp_degree":   cusp["degree"],
            "longitude":     cusp["longitude"],
            "nakshatra":     sub_info["nakshatra"],
            "star_lord":     sub_info["star_lord"],
            "sub_lord":      sub_info["sub_lord"],
            "sub_sub_lord":  sub_info["sub_sub_lord"],
        })

    return {
        "cuspal_sub_lords": cuspal_data,
        "house_system":     "Placidus (full KP-standard)",
        "method":           "Real Placidus cusps computed via Swiss Ephemeris 2.10 with Lahiri ayanamsha. Sub-lords derived from Vimshottari proportions within nakshatras.",
        "citation":         CLASSICAL_CITATIONS["sub_lord"] + "; " + CLASSICAL_CITATIONS["kp"],
    }


def handle_ruling_planets(birth: Optional[Dict[str, Any]] = None,
                          query_moment: Optional[str] = None,
                          query_lat: Optional[float] = None,
                          query_lon: Optional[float] = None,
                          query_timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    result: Dict[str, Any] = {"method": "5 KP Ruling Planets per classical KP doctrine"}

    if birth:
        birth_dt = f"{birth['dob']}T{birth['time']}:00"
        result["birth_ruling_planets"] = _ruling_planets_at_moment(
            birth_dt, birth["lat"], birth["lon"],
            birth.get("timezone", "Asia/Kolkata"),
        )

    if query_moment and query_lat is not None and query_lon is not None:
        result["query_ruling_planets"] = _ruling_planets_at_moment(
            query_moment, query_lat, query_lon, query_timezone,
        )

    if not birth and not query_moment:
        return {"error": "Provide either birth or (query_moment + query_lat + query_lon)"}

    result["rules_applied"] = KP_RULING_PLANETS_RULES
    result["citation"] = CLASSICAL_CITATIONS["ruling_planets"]
    return result


def handle_significators(birth: Dict[str, Any]) -> Dict[str, Any]:
    raw, e = _build(birth)
    significators: Dict[str, Dict[str, Any]] = {}
    for planet in ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]:
        significators[planet] = _planet_signifies_houses(planet, raw, e)
    return {
        "planet_significators": significators,
        "hierarchy":            KP_SIGNIFICATOR_HIERARCHY,
        "method":               "Union of (a) house occupied, (b) nakshatra-lord's house, (c) sign-lord's house, (d) houses of planets whose nak-lord is this planet.",
        "citation":             CLASSICAL_CITATIONS["significator"],
    }


def handle_house_significators(birth: Dict[str, Any], house: int) -> Dict[str, Any]:
    """
    V2: Uses real Placidus cusps for house-sign determination.
    """
    if not isinstance(house, int) or house < 1 or house > 12:
        return {"error": "house must be int between 1 and 12"}

    raw, e = _build(birth)
    planets_data = raw.get("planets", {})

    # V2: Get house sign from real Placidus cusp
    cusps = _placidus_cusps(birth)
    target_cusp = cusps[house - 1]
    house_sign = target_cusp["sign"]
    house_lord = SIGN_TO_LORD.get(house_sign)
    cusp_lon = target_cusp["longitude"]

    occupants = _planets_in_house(e, house)
    level_2 = occupants

    level_4: List[str] = [house_lord] if house_lord else []

    # Level 1: planets whose nakshatra-lord is an occupant of target house
    level_1: List[str] = []
    if occupants:
        for p, pd in planets_data.items():
            if isinstance(pd, dict) and pd.get("nakshatra_lord") in occupants:
                if p not in level_1:
                    level_1.append(p)

    # Level 3: planets in star of house lord
    level_3: List[str] = []
    if house_lord:
        for p, pd in planets_data.items():
            if isinstance(pd, dict) and pd.get("nakshatra_lord") == house_lord:
                if p not in level_3 and p not in level_1:
                    level_3.append(p)

    strongest = level_1 or level_2 or level_3 or level_4

    # Cuspal sub-lord (decides if significators will materialize)
    cusp_sub_info = _compute_sub_lord(cusp_lon)

    return {
        "house":                    house,
        "house_sign":               house_sign,
        "house_lord":               house_lord,
        "cusp_longitude":           cusp_lon,
        "cusp_degree":              target_cusp["degree"],
        "cuspal_star_lord":         cusp_sub_info["star_lord"],
        "cuspal_sub_lord":          cusp_sub_info["sub_lord"],
        "cuspal_sub_sub_lord":      cusp_sub_info["sub_sub_lord"],
        "occupants":                occupants,
        "level_1_strongest":        level_1,
        "level_2_occupants":        level_2,
        "level_3_star_of_lord":     level_3,
        "level_4_house_lord":       level_4,
        "strongest_significators":  strongest,
        "hierarchy":                KP_SIGNIFICATOR_HIERARCHY,
        "house_system":             "Placidus",
        "citation":                 CLASSICAL_CITATIONS["significator"] + "; " + CLASSICAL_CITATIONS["kp"],
    }


def handle_moment_lookup(query_moment: str,
                         query_lat: float,
                         query_lon: float,
                         query_timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    rp = _ruling_planets_at_moment(query_moment, query_lat, query_lon, query_timezone)

    dt = datetime.fromisoformat(query_moment)
    chart = get_chart(
        dob=dt.date().isoformat(), time=dt.strftime("%H:%M"),
        lat=query_lat, lon=query_lon, timezone=query_timezone,
    )
    lagna_lon = _planet_to_longitude(chart.get("lagna", {}))
    lagna_sub_info = _compute_sub_lord(lagna_lon) if lagna_lon is not None else None

    return {
        "query_moment":    query_moment,
        "location":        {"lat": query_lat, "lon": query_lon, "timezone": query_timezone},
        "ruling_planets":  rp,
        "lagna_at_moment": {
            "longitude":    round(lagna_lon, 4) if lagna_lon else None,
            "sign":         chart.get("lagna", {}).get("sign"),
            "degree":       chart.get("lagna", {}).get("degree"),
            "nakshatra":    chart.get("lagna", {}).get("nakshatra"),
            "sub_lord":     lagna_sub_info["sub_lord"] if lagna_sub_info else None,
            "sub_sub_lord": lagna_sub_info["sub_sub_lord"] if lagna_sub_info else None,
        },
        "note":            "Moment-based KP for Prashna (Horary).",
        "citation":        CLASSICAL_CITATIONS["ruling_planets"],
    }


def handle_query_horoscope(birth: Dict[str, Any],
                           query_moment: str,
                           query_lat: float,
                           query_lon: float,
                           question_house: int,
                           query_timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    if not isinstance(question_house, int) or question_house < 1 or question_house > 12:
        return {"error": "question_house must be int 1-12"}

    house_sig = handle_house_significators(birth, question_house)
    if "error" in house_sig:
        return house_sig

    query_rp = _ruling_planets_at_moment(query_moment, query_lat, query_lon, query_timezone)
    rps = set(query_rp["ruling_planets"])

    sig_l1 = set(house_sig["level_1_strongest"])
    sig_l2 = set(house_sig["level_2_occupants"])
    sig_l3 = set(house_sig["level_3_star_of_lord"])
    sig_l4 = set(house_sig["level_4_house_lord"])

    overlap_l1 = sig_l1 & rps
    overlap_l2 = sig_l2 & rps
    overlap_l3 = sig_l3 & rps
    overlap_l4 = sig_l4 & rps

    score = (len(overlap_l1) * 4 + len(overlap_l2) * 3
             + len(overlap_l3) * 2 + len(overlap_l4) * 1)

    if score >= 4:
        verdict = "YES — strong significator-RP confluence"
    elif score >= 2:
        verdict = "LIKELY YES — moderate confluence"
    elif score >= 1:
        verdict = "UNCERTAIN — weak confluence"
    else:
        verdict = "NO — no significator-RP overlap"

    return {
        "verdict":             verdict,
        "score":               score,
        "question_house":      question_house,
        "house_sign":          house_sig["house_sign"],
        "house_lord":          house_sig["house_lord"],
        "cuspal_sub_lord":     house_sig["cuspal_sub_lord"],
        "ruling_planets":      query_rp["ruling_planets"],
        "significators_overlap": {
            "level_1_strongest":   sorted(overlap_l1),
            "level_2_occupants":   sorted(overlap_l2),
            "level_3_star_of_lord":sorted(overlap_l3),
            "level_4_house_lord":  sorted(overlap_l4),
        },
        "all_significators":   {
            "level_1": house_sig["level_1_strongest"],
            "level_2": house_sig["level_2_occupants"],
            "level_3": house_sig["level_3_star_of_lord"],
            "level_4": house_sig["level_4_house_lord"],
        },
        "method":              "Compare natal house significators with query-moment Ruling Planets. Weighted by KP hierarchy (level_1=4x ... level_4=1x). Cuspal sub-lord shown for additional precision.",
        "house_system":        "Placidus",
        "citation":            CLASSICAL_CITATIONS["significator"] + "; " + CLASSICAL_CITATIONS["ruling_planets"],
    }


def handle_profile(birth: Dict[str, Any]) -> Dict[str, Any]:
    lagna_sl = handle_lagna_sub_lord(birth)
    planet_sl = handle_planet_sub_lords(birth)
    rp = handle_ruling_planets(birth=birth)
    significators = handle_significators(birth)
    cusps = handle_cuspal_sub_lords(birth)

    headlines: List[str] = []
    headlines.append(
        f"Lagna sub-lord: {lagna_sl.get('lagna_sub_lord')} "
        f"(star: {lagna_sl.get('lagna_star_lord')}, nakshatra: {lagna_sl.get('lagna_nakshatra')})"
    )
    birth_rp = rp.get("birth_ruling_planets", {})
    if birth_rp:
        headlines.append(
            f"Birth Ruling Planets: {', '.join(birth_rp.get('ruling_planets', []))}"
        )
    if cusps.get("cuspal_sub_lords"):
        seventh = next((c for c in cusps["cuspal_sub_lords"] if c["house"] == 7), None)
        tenth = next((c for c in cusps["cuspal_sub_lords"] if c["house"] == 10), None)
        if seventh:
            headlines.append(f"7th cusp ({seventh['cusp_sign']} {seventh['cusp_degree']}°) sub-lord: {seventh['sub_lord']}")
        if tenth:
            headlines.append(f"10th cusp ({tenth['cusp_sign']} {tenth['cusp_degree']}°) sub-lord: {tenth['sub_lord']}")

    return {
        "headlines":            headlines,
        "lagna_sub_lord":       lagna_sl,
        "planet_sub_lords":     planet_sl,
        "cuspal_sub_lords":     cusps,
        "birth_ruling_planets": birth_rp,
        "significators":        significators,
        "method":               "Full KP via Swiss Ephemeris 2.10. Placidus cusps + Lahiri ayanamsha. Sub-lords from Vimshottari proportions.",
        "citation":             CLASSICAL_CITATIONS["kp"],
        "house_system":         "Placidus",
    }
