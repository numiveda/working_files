"""
tarot_data.py — Full 78-card Rider-Waite-Smith Tarot catalog + spread layouts.

Phase D — Module D2 (Tarot Engine).

Public catalogs:
    MAJOR_ARCANA     — 22 cards with upright/reversed meanings, element, planet, sign
    MINOR_ARCANA     — 56 cards (4 suits × 14): Cups, Wands, Swords, Pentacles
    SUIT_METADATA    — Element, season, theme, ruling planet per suit
    SPREAD_LAYOUTS   — Position meanings for each spread
    CLASSICAL_CITATIONS

Sources: Rider-Waite-Smith deck (1909, public domain in India since 2014).
        Pamela Colman Smith's illustrations and Arthur Edward Waite's
        classical interpretations from "Pictorial Key to the Tarot" (1910).
        Card meanings synthesized from Waite's original text + traditional
        Tarot scholarship.
"""

from typing import Dict, List


# ════════════════════════════════════════════════════════════════════════
# MAJOR ARCANA — 22 cards
# Each entry: number, name, keywords, upright, reversed, element, planet, sign
# ════════════════════════════════════════════════════════════════════════

MAJOR_ARCANA: List[Dict] = [
    {"number": 0,  "name": "The Fool",
     "keywords": ["beginnings", "innocence", "spontaneity", "leap of faith"],
     "upright":  "New beginnings, fresh start, taking a leap of faith, innocence, spontaneity, free spirit. The journey begins.",
     "reversed": "Recklessness, naivety, foolishness, holding back, fear of new beginnings, missed opportunities, taking foolish risks.",
     "element":  "Air", "planet": "Uranus", "sign": None,
     "astro_link": "Air — wind of new directions"},
    {"number": 1,  "name": "The Magician",
     "keywords": ["manifestation", "willpower", "skill", "creation"],
     "upright":  "Manifestation, resourcefulness, power, inspired action, will aligned with intention, masterful use of tools.",
     "reversed": "Manipulation, poor planning, untapped talents, illusion, deceit, scattered focus, will misused.",
     "element":  "Air", "planet": "Mercury", "sign": None,
     "astro_link": "Mercury — communication, skill, intellect channeling will"},
    {"number": 2,  "name": "The High Priestess",
     "keywords": ["intuition", "mystery", "subconscious", "inner wisdom"],
     "upright":  "Intuition, sacred knowledge, divine feminine, subconscious mind, mysteries, inner voice trusted.",
     "reversed": "Secrets, disconnection from intuition, withdrawal, silence as defense, repressed feelings.",
     "element":  "Water", "planet": "Moon", "sign": None,
     "astro_link": "Moon — inner knowing, hidden wisdom"},
    {"number": 3,  "name": "The Empress",
     "keywords": ["abundance", "nurturing", "fertility", "creativity"],
     "upright":  "Fertility, beauty, nature, nurturing, abundance, sensuality, creative flow, motherhood.",
     "reversed": "Creative block, dependence on others, smothering care, loss of self-worth, neglect of self.",
     "element":  "Earth", "planet": "Venus", "sign": "Taurus",
     "astro_link": "Venus — abundant beauty, nurture, fertility"},
    {"number": 4,  "name": "The Emperor",
     "keywords": ["authority", "structure", "leadership", "stability"],
     "upright":  "Authority, structure, leadership, stability, fatherhood, command, established power.",
     "reversed": "Tyranny, rigidity, coldness, lack of self-control, abuse of power, stubbornness.",
     "element":  "Fire", "planet": "Mars", "sign": "Aries",
     "astro_link": "Aries — leadership, initiation, established order"},
    {"number": 5,  "name": "The Hierophant",
     "keywords": ["tradition", "conformity", "morality", "ethics"],
     "upright":  "Spiritual wisdom, religious beliefs, conformity, tradition, institutions, mentorship.",
     "reversed": "Personal beliefs, freedom, challenging the status quo, breaking tradition, rebellion.",
     "element":  "Earth", "planet": "Venus", "sign": "Taurus",
     "astro_link": "Taurus — established tradition, sacred teachings"},
    {"number": 6,  "name": "The Lovers",
     "keywords": ["love", "harmony", "relationships", "choices"],
     "upright":  "Love, harmony, relationships, values alignment, choices, partnerships, conscious union.",
     "reversed": "Self-love, disharmony, imbalance, misalignment of values, broken relationships, indecision.",
     "element":  "Air", "planet": "Mercury", "sign": "Gemini",
     "astro_link": "Gemini — dualities meeting, conscious choice in relationship"},
    {"number": 7,  "name": "The Chariot",
     "keywords": ["control", "willpower", "victory", "determination"],
     "upright":  "Control, willpower, success, action, determination, victory through directed force.",
     "reversed": "Self-discipline, opposition, lack of direction, aggression, losing control, defeat.",
     "element":  "Water", "planet": "Moon", "sign": "Cancer",
     "astro_link": "Cancer — emotional mastery driving forward action"},
    {"number": 8,  "name": "Strength",
     "keywords": ["courage", "compassion", "patience", "inner strength"],
     "upright":  "Inner strength, courage, persuasion, compassion, patience, taming inner beasts.",
     "reversed": "Self-doubt, weakness, raw emotion, lack of self-discipline, inner conflict.",
     "element":  "Fire", "planet": "Sun", "sign": "Leo",
     "astro_link": "Leo — heart-centered courage taming the lion"},
    {"number": 9,  "name": "The Hermit",
     "keywords": ["soul-searching", "introspection", "solitude", "inner guidance"],
     "upright":  "Soul-searching, introspection, being alone, inner guidance, withdrawal, wisdom found in solitude.",
     "reversed": "Isolation, loneliness, withdrawal, paranoia, rejection of help, refusing to come out of isolation.",
     "element":  "Earth", "planet": "Mercury", "sign": "Virgo",
     "astro_link": "Virgo — discriminating solitude, wisdom through analysis"},
    {"number": 10, "name": "Wheel of Fortune",
     "keywords": ["fate", "cycles", "turning points", "destiny"],
     "upright":  "Good luck, karma, life cycles, destiny, turning point, fortune favors, change in fortune.",
     "reversed": "Bad luck, resistance to change, breaking cycles, lack of control, external setbacks.",
     "element":  "Fire", "planet": "Jupiter", "sign": None,
     "astro_link": "Jupiter — fortune, cycles of expansion and contraction"},
    {"number": 11, "name": "Justice",
     "keywords": ["fairness", "truth", "law", "cause and effect"],
     "upright":  "Justice, fairness, truth, cause and effect, law, accountability, balanced judgment.",
     "reversed": "Unfairness, lack of accountability, dishonesty, bias, legal complications, escape from justice.",
     "element":  "Air", "planet": "Venus", "sign": "Libra",
     "astro_link": "Libra — perfect balance, the karmic scales"},
    {"number": 12, "name": "The Hanged Man",
     "keywords": ["suspension", "surrender", "letting go", "new perspective"],
     "upright":  "Suspension, surrender, sacrifice, letting go, new perspective gained through pause, the willing pause.",
     "reversed": "Stalling, indecision, resistance, delays, needless martyrdom, refusing to surrender.",
     "element":  "Water", "planet": "Neptune", "sign": None,
     "astro_link": "Water — surrender, suspension, sacred pause"},
    {"number": 13, "name": "Death",
     "keywords": ["endings", "transformation", "transition", "release"],
     "upright":  "Endings, transformation, transition, change, release of the old, profound metamorphosis.",
     "reversed": "Resistance to change, inability to move on, stagnation, fear of endings, partial change.",
     "element":  "Water", "planet": "Pluto", "sign": "Scorpio",
     "astro_link": "Scorpio — transformation through dissolution"},
    {"number": 14, "name": "Temperance",
     "keywords": ["balance", "moderation", "patience", "purpose"],
     "upright":  "Balance, moderation, patience, harmony, blending opposites, finding the middle way.",
     "reversed": "Imbalance, excess, lack of long-term vision, hasty decisions, impatience, extremes.",
     "element":  "Fire", "planet": "Jupiter", "sign": "Sagittarius",
     "astro_link": "Sagittarius — alchemical blending, the middle path"},
    {"number": 15, "name": "The Devil",
     "keywords": ["bondage", "addiction", "materialism", "shadow"],
     "upright":  "Shadow self, addiction, restriction, materialism, bondage, illusory chains we forge ourselves.",
     "reversed": "Releasing limiting beliefs, detachment, freedom, reclaiming power, breaking chains.",
     "element":  "Earth", "planet": "Saturn", "sign": "Capricorn",
     "astro_link": "Capricorn — material attachment, shadow ambitions"},
    {"number": 16, "name": "The Tower",
     "keywords": ["sudden change", "upheaval", "revelation", "awakening"],
     "upright":  "Sudden upheaval, broken pride, disaster, revelation, awakening through crisis, false structures collapsing.",
     "reversed": "Personal transformation, fear of change, averting disaster, internal upheaval before external, gradual collapse.",
     "element":  "Fire", "planet": "Mars", "sign": None,
     "astro_link": "Mars — sudden disruption, breaking down false structures"},
    {"number": 17, "name": "The Star",
     "keywords": ["hope", "inspiration", "renewal", "spirituality"],
     "upright":  "Hope, faith, purpose, renewal, spirituality, inspired guidance, peace after storm.",
     "reversed": "Lack of faith, despair, disconnection, discouragement, lost hope, faithlessness.",
     "element":  "Air", "planet": "Uranus", "sign": "Aquarius",
     "astro_link": "Aquarius — cosmic hope, renewal through universal love"},
    {"number": 18, "name": "The Moon",
     "keywords": ["illusion", "intuition", "dreams", "subconscious"],
     "upright":  "Illusion, fear, anxiety, subconscious, intuition, dreams, hidden truths surfacing.",
     "reversed": "Release of fear, repressed emotions surfacing, inner confusion, finally seeing through illusion.",
     "element":  "Water", "planet": "Neptune", "sign": "Pisces",
     "astro_link": "Pisces — dreams, subconscious, mystical waters"},
    {"number": 19, "name": "The Sun",
     "keywords": ["joy", "success", "vitality", "positivity"],
     "upright":  "Joy, success, celebration, positivity, vitality, fulfillment, clear sight, child-like delight.",
     "reversed": "Inner child, feeling down, overly optimistic, lack of clarity, temporary setback to joy.",
     "element":  "Fire", "planet": "Sun", "sign": "Leo",
     "astro_link": "Sun — radiant fulfillment, life force expressed"},
    {"number": 20, "name": "Judgement",
     "keywords": ["awakening", "rebirth", "absolution", "calling"],
     "upright":  "Judgement, rebirth, inner calling, awakening, absolution, self-evaluation that liberates.",
     "reversed": "Self-doubt, refusal to listen to calling, harsh self-judgment, ignoring the inner voice.",
     "element":  "Fire", "planet": "Pluto", "sign": None,
     "astro_link": "Fire — purifying judgment, rebirth from ashes"},
    {"number": 21, "name": "The World",
     "keywords": ["completion", "integration", "fulfillment", "wholeness"],
     "upright":  "Completion, integration, accomplishment, travel, wholeness, the cycle complete, mastery.",
     "reversed": "Seeking personal closure, short-cut to success, incomplete cycles, delays in completion.",
     "element":  "Earth", "planet": "Saturn", "sign": None,
     "astro_link": "Earth — embodied completion, the great work fulfilled"},
]


# ════════════════════════════════════════════════════════════════════════
# MINOR ARCANA — 56 cards = 4 suits × 14 (Ace through 10, Page, Knight, Queen, King)
# ════════════════════════════════════════════════════════════════════════

SUITS = ["Cups", "Wands", "Swords", "Pentacles"]
COURTS = ["Page", "Knight", "Queen", "King"]
NUMBERS = ["Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten"]

# Suit-level baselines applied to all cards within that suit
SUIT_METADATA: Dict[str, Dict] = {
    "Cups":      {"element": "Water", "domain": "Emotions, relationships, intuition, love",
                  "planet_ruler": "Moon/Venus", "season": "Summer",
                  "vedic_kosha": "Manomaya Kosha (mental/emotional sheath)"},
    "Wands":     {"element": "Fire",  "domain": "Passion, creativity, action, inspiration",
                  "planet_ruler": "Sun/Mars", "season": "Spring",
                  "vedic_kosha": "Pranamaya Kosha (vital/energy sheath)"},
    "Swords":    {"element": "Air",   "domain": "Intellect, decisions, conflict, communication",
                  "planet_ruler": "Mercury/Saturn", "season": "Autumn",
                  "vedic_kosha": "Vijnanamaya Kosha (intellect sheath)"},
    "Pentacles": {"element": "Earth", "domain": "Material world, work, body, finances",
                  "planet_ruler": "Saturn/Venus", "season": "Winter",
                  "vedic_kosha": "Annamaya Kosha (physical sheath)"},
}


# Pip card meanings (Aces through 10s) — synthesized from Waite's Pictorial Key
PIP_MEANINGS: Dict[str, Dict[str, Dict[str, str]]] = {
    "Cups": {
        "Ace":   {"upright": "New emotional beginnings, love, spiritual gifts, intuitive opening",
                  "reversed": "Emotional blockage, repressed feelings, missed connection"},
        "Two":   {"upright": "Partnership, mutual attraction, harmonious union, soul connection",
                  "reversed": "Imbalanced relationship, disharmony, misunderstanding"},
        "Three": {"upright": "Celebration, friendship, community joy, social happiness",
                  "reversed": "Gossip, overindulgence, social isolation, friendship strain"},
        "Four":  {"upright": "Apathy, contemplation, reevaluating offers, emotional withdrawal",
                  "reversed": "Awareness returning, new motivation, accepting an offer"},
        "Five":  {"upright": "Loss, grief, disappointment, regret over what's gone",
                  "reversed": "Acceptance, moving on, finding peace, recovering hope"},
        "Six":   {"upright": "Nostalgia, childhood memories, innocence, reunion with past",
                  "reversed": "Stuck in past, refusing to grow, idealizing memories"},
        "Seven": {"upright": "Choices, fantasy, illusion, scattered options, daydreaming",
                  "reversed": "Clarity emerging, hard truths, choosing wisely"},
        "Eight": {"upright": "Walking away, abandonment of what no longer serves, seeking deeper meaning",
                  "reversed": "Indecision about leaving, returning to old patterns, fear of departure"},
        "Nine":  {"upright": "Emotional fulfillment, wishes granted, contentment, gratitude",
                  "reversed": "Smug satisfaction, materialism over heart, unfulfilled wishes"},
        "Ten":   {"upright": "Domestic harmony, family joy, emotional fulfillment in relationships",
                  "reversed": "Family discord, broken home, disconnected from loved ones"},
    },
    "Wands": {
        "Ace":   {"upright": "Inspiration, new creative spark, passion, the seed of action",
                  "reversed": "Lack of inspiration, delayed creativity, false starts"},
        "Two":   {"upright": "Planning, future vision, partnership in venture, broader horizons",
                  "reversed": "Indecision, playing safe, fear of expansion"},
        "Three": {"upright": "Expansion, vision realized, looking ahead, fruits of foresight",
                  "reversed": "Delays, lack of foresight, obstacles to expansion"},
        "Four":  {"upright": "Celebration, homecoming, foundations laid, joyful milestone",
                  "reversed": "Transition, instability, less celebrated success"},
        "Five":  {"upright": "Conflict, competition, disagreement, productive tension",
                  "reversed": "Resolution, avoiding conflict, internal struggle externalized"},
        "Six":   {"upright": "Victory, public recognition, success, leadership acknowledged",
                  "reversed": "Private victory, fall from grace, success undermined"},
        "Seven": {"upright": "Defending position, perseverance under challenge, holding ground",
                  "reversed": "Overwhelmed, giving up, yielding to pressure"},
        "Eight": {"upright": "Swift action, rapid progress, momentum, message arriving",
                  "reversed": "Delays, frustration, slowed momentum"},
        "Nine":  {"upright": "Resilience, last stand, courage despite weariness, almost there",
                  "reversed": "Exhausted resistance, paranoia, defensive stance broken"},
        "Ten":   {"upright": "Burden, responsibility, hard work toward goal, carrying too much",
                  "reversed": "Releasing burden, delegating, breakthrough from overload"},
    },
    "Swords": {
        "Ace":   {"upright": "Breakthrough, mental clarity, truth cutting through, new ideas",
                  "reversed": "Confusion, brutal truth misused, mental cloudiness"},
        "Two":   {"upright": "Stalemate, difficult choice, balanced opposing forces, denial",
                  "reversed": "Indecision resolved, information revealed, breaking deadlock"},
        "Three": {"upright": "Heartbreak, painful truth, grief, painful clarity",
                  "reversed": "Healing from pain, releasing grief, recovery"},
        "Four":  {"upright": "Rest, recovery, contemplation, sanctuary from struggle",
                  "reversed": "Restlessness, burnout, refusing rest, return to action"},
        "Five":  {"upright": "Conflict, hollow victory, defeat, win-at-all-costs",
                  "reversed": "Reconciliation, learning from loss, ending the fight"},
        "Six":   {"upright": "Transition, leaving difficulty behind, journey to better shore",
                  "reversed": "Resisting transition, returning to trouble, baggage carried"},
        "Seven": {"upright": "Deception, strategy, working alone, taking what's not yours",
                  "reversed": "Confession, honesty, return of what was taken"},
        "Eight": {"upright": "Self-imposed restriction, victim mentality, perceived trap",
                  "reversed": "Liberation, seeing one's freedom, releasing constraints"},
        "Nine":  {"upright": "Anxiety, fear, mental anguish, nightmares of worry",
                  "reversed": "Hope, fears subsiding, recovery from anxiety"},
        "Ten":   {"upright": "Painful endings, defeat, betrayal, rock bottom",
                  "reversed": "Recovery, only way is up, lessons from collapse"},
    },
    "Pentacles": {
        "Ace":   {"upright": "Material opportunity, new prosperity, abundance offered, gift of resources",
                  "reversed": "Missed opportunity, scarcity mindset, financial delay"},
        "Two":   {"upright": "Balance, juggling priorities, adaptability with resources",
                  "reversed": "Imbalance, overwhelm, financial juggling becoming chaos"},
        "Three": {"upright": "Teamwork, craftsmanship, building together, recognition of skill",
                  "reversed": "Working alone, lack of teamwork, mediocre work"},
        "Four":  {"upright": "Saving, security, possessiveness, holding tight to wealth",
                  "reversed": "Generosity, releasing materialism, financial flow restored"},
        "Five":  {"upright": "Financial loss, poverty, isolation, material/spiritual want",
                  "reversed": "Recovery, finding help, end of hardship, spiritual wealth"},
        "Six":   {"upright": "Generosity, sharing wealth, balanced giving and receiving",
                  "reversed": "Selfishness, debt, strings-attached giving, imbalanced exchange"},
        "Seven": {"upright": "Patience, long-term investment, assessing progress",
                  "reversed": "Impatience, lack of long-term planning, premature judgment"},
        "Eight": {"upright": "Apprenticeship, mastery of skill, dedicated work, craftsmanship",
                  "reversed": "Lack of focus, sloppy work, not learning from mistakes"},
        "Nine":  {"upright": "Self-sufficiency, luxury, success enjoyed alone, prosperity solo",
                  "reversed": "Over-dependence on others, false luxury, financial setback"},
        "Ten":   {"upright": "Legacy, generational wealth, family fortune, established prosperity",
                  "reversed": "Family financial conflict, loss of legacy, inheritance disputes"},
    },
}


# Court card meanings — synthesized from Waite
COURT_MEANINGS: Dict[str, Dict[str, Dict[str, str]]] = {
    "Cups": {
        "Page":   {"upright": "Emotional message, creative inspiration, intuitive child energy",
                   "reversed": "Emotional immaturity, blocked creativity, sulking"},
        "Knight": {"upright": "Romantic pursuit, idealism, emotional quest, charm",
                   "reversed": "Moodiness, unrealistic romance, broken promises"},
        "Queen": {"upright": "Compassion, emotional security, intuitive nurturer, empathy",
                  "reversed": "Emotional dependency, smothering, martyrdom"},
        "King":  {"upright": "Emotional mastery, diplomatic, wise counselor, compassionate authority",
                  "reversed": "Emotional manipulation, moodiness in power, repressed feelings"},
    },
    "Wands": {
        "Page":   {"upright": "Enthusiastic messenger, creative beginnings, bold curiosity",
                   "reversed": "Procrastination, lack of follow-through, scattered enthusiasm"},
        "Knight": {"upright": "Bold action, adventurous spirit, fiery pursuit, charisma in motion",
                   "reversed": "Impulsiveness, recklessness, anger, hot-headed action"},
        "Queen": {"upright": "Confident, charismatic, independent, warm leader",
                  "reversed": "Jealousy, vengeful, demanding, insecure dominance"},
        "King":  {"upright": "Visionary leader, entrepreneur, bold authority, inspiring command",
                  "reversed": "Tyrannical, impulsive leadership, ego-driven, ruthless"},
    },
    "Swords": {
        "Page":   {"upright": "Curious, sharp mind, vigilant, ready to learn truths",
                   "reversed": "Gossip, scattered thoughts, paranoia, lying"},
        "Knight": {"upright": "Action-oriented, ambitious, direct, mental warrior",
                   "reversed": "Rushed, aggressive, blunt to the point of harm"},
        "Queen": {"upright": "Independent, perceptive, clear-thinking, unbiased judgment",
                  "reversed": "Cold, harsh, bitter, cutting communication"},
        "King":  {"upright": "Intellectual authority, fair judge, truth-speaker, strategic mind",
                  "reversed": "Cruel intellect, manipulation, abuse of mental power"},
    },
    "Pentacles": {
        "Page":   {"upright": "Studious, ambitious, manifesting goals, practical learner",
                   "reversed": "Lack of progress, distracted from goals, immature ambition"},
        "Knight": {"upright": "Reliable, methodical, persistent, slow but sure progress",
                   "reversed": "Stuck in routine, boring, dull, resistant to change"},
        "Queen": {"upright": "Nurturing, practical, financial security, grounded woman",
                  "reversed": "Imbalanced work-life, smothering practicality, materialism"},
        "King":  {"upright": "Wealthy, business-savvy, secure authority, generous patron",
                  "reversed": "Greed, materialism, corrupt power, financial obsession"},
    },
}


# ════════════════════════════════════════════════════════════════════════
# COMPILE FULL 78-CARD DECK
# ════════════════════════════════════════════════════════════════════════

def _build_full_deck() -> List[Dict]:
    """Assemble all 78 cards."""
    deck: List[Dict] = []

    # 22 Major Arcana
    for card in MAJOR_ARCANA:
        deck.append({**card, "arcana": "Major", "suit": None})

    # 56 Minor Arcana
    for suit in SUITS:
        suit_meta = SUIT_METADATA[suit]
        # Pip cards (Ace through 10)
        for num in NUMBERS:
            meaning = PIP_MEANINGS[suit][num]
            deck.append({
                "number": None, "name": f"{num} of {suit}",
                "arcana": "Minor", "suit": suit,
                "keywords": [],
                "upright": meaning["upright"], "reversed": meaning["reversed"],
                "element": suit_meta["element"],
                "planet": suit_meta["planet_ruler"], "sign": None,
                "astro_link": f"{suit_meta['element']} suit — {suit_meta['domain']}",
            })
        # Court cards
        for court in COURTS:
            meaning = COURT_MEANINGS[suit][court]
            deck.append({
                "number": None, "name": f"{court} of {suit}",
                "arcana": "Minor", "suit": suit,
                "keywords": [],
                "upright": meaning["upright"], "reversed": meaning["reversed"],
                "element": suit_meta["element"],
                "planet": suit_meta["planet_ruler"], "sign": None,
                "astro_link": f"{court} of {suit} — {suit_meta['domain']}",
            })

    return deck


FULL_DECK: List[Dict] = _build_full_deck()
assert len(FULL_DECK) == 78, f"Deck count error: {len(FULL_DECK)}"


# ════════════════════════════════════════════════════════════════════════
# SPREAD LAYOUTS
# ════════════════════════════════════════════════════════════════════════

SPREAD_LAYOUTS: Dict[str, Dict] = {
    "daily_card": {
        "card_count": 1,
        "positions": [
            {"index": 1, "name": "Today's Energy", "question": "What is the energy guiding today?"},
        ],
    },
    "three_card": {
        "card_count": 3,
        "positions": [
            {"index": 1, "name": "Past",    "question": "What past influences are shaping the present?"},
            {"index": 2, "name": "Present", "question": "What is the current situation?"},
            {"index": 3, "name": "Future",  "question": "What is the likely outcome if course unchanged?"},
        ],
    },
    "celtic_cross": {
        "card_count": 10,
        "positions": [
            {"index": 1,  "name": "Significator",       "question": "What is at the heart of the matter?"},
            {"index": 2,  "name": "Crossing Card",      "question": "What crosses or challenges you?"},
            {"index": 3,  "name": "Root / Foundation",  "question": "What is the foundation beneath this?"},
            {"index": 4,  "name": "Recent Past",        "question": "What has just passed?"},
            {"index": 5,  "name": "Conscious Goal",     "question": "What do you consciously aim for?"},
            {"index": 6,  "name": "Near Future",        "question": "What is coming next?"},
            {"index": 7,  "name": "Self-Perception",    "question": "How do you see yourself in this?"},
            {"index": 8,  "name": "External Influence", "question": "What is the environment's role?"},
            {"index": 9,  "name": "Hopes and Fears",    "question": "What do you hope for / fear?"},
            {"index": 10, "name": "Final Outcome",      "question": "What is the ultimate outcome?"},
        ],
    },
    "year_ahead": {
        "card_count": 12,
        "positions": [
            {"index": i, "name": f"Month {i}", "question": f"What energy guides month {i}?"}
            for i in range(1, 13)
        ],
    },
    "decision": {
        "card_count": 5,
        "positions": [
            {"index": 1, "name": "The Situation",       "question": "What is the situation requiring decision?"},
            {"index": 2, "name": "Path A",              "question": "What happens if you choose path A?"},
            {"index": 3, "name": "Path B",              "question": "What happens if you choose path B?"},
            {"index": 4, "name": "What You Need",       "question": "What do you need to know to decide?"},
            {"index": 5, "name": "Recommendation",      "question": "What does the cosmos recommend?"},
        ],
    },
    "question_focused": {
        "card_count": 3,
        "positions": [
            {"index": 1, "name": "The Question's Heart", "question": "What is at the heart of your question?"},
            {"index": 2, "name": "Hidden Influence",     "question": "What hidden factor is in play?"},
            {"index": 3, "name": "Path Forward",         "question": "What path forward is shown?"},
        ],
    },
}


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "tarot":     "Rider-Waite-Smith deck (Pamela Colman Smith + Arthur Edward Waite, 1909) — public domain. Arthur Edward Waite's 'Pictorial Key to the Tarot' (1910) — public domain.",
    "spreads":   "Traditional Celtic Cross spread (~late 19th c.); Three-Card Past-Present-Future spread (traditional); Year-Ahead spread (modern traditional); Decision spread (modern Tarot scholarship).",
    "suit_element":"Hermetic Order of the Golden Dawn (1888-1903) elemental attributions: Cups=Water, Wands=Fire, Swords=Air, Pentacles=Earth.",
    "vedic_link":"Cross-reference with Pancha Kosha (five-sheaths) model from Taittiriya Upanishad. Engine provides this link for synthesis; not a classical Tarot teaching.",
}
