"""
varshaphala.py — numiVeda Kaaliyo Astro Engine — Module C2 (Varshaphala / Annual Chart)

10 endpoints for Tajik annual prediction.

Public API:
    handle_profile               — Master synthesis
    handle_cast_chart            — Solar return chart for target year
    handle_muntha                — Muntha point + lord + house result
    handle_year_lord             — Varshesha selection (5 candidates → strongest)
    handle_tajik_aspects         — Ithasala / Eesharafa / Mutthasila yogas
    handle_sahams                — 20 classical Sahams (Lots) computed
    handle_monthly_predictions   — 12-month breakdown
    handle_dasha_for_year        — Mudda dasha (annual Vimshottari subset)
    handle_event_timing          — Key event windows in upcoming year
    handle_year_remedies         — Year-specific classical remedies

Solar Return Search Algorithm (classical):
    Cast chart for natal birthday at target year as anchor.
    Compare transit Sun longitude to natal Sun longitude.
    Iteratively shift by hours until match within 0.05° tolerance.
    The exact return moment is the Varshaphala chart's "birth".
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta

from astro_helpers import (
    extract_chart_essentials,
    get_chart,
    compute_house_lords,
    SIGNS_ORDER,
    SIGN_TO_LORD,
    HOUSE_TO_LIFE_AREA,
)

from varshaphala_data import (
    SAHAMS,
    TAJIK_ASPECTS_ORBS,
    TAJIK_YOGAS,
    YEAR_LORD_CANDIDATES,
    PANCHA_VARGIYA_WEIGHTS,
    WEEKDAY_PLANET,
    MUNTHA_HOUSE_RESULTS,
    MUDDA_VIMSHOTTARI_YEARS,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# LONGITUDE UTILITIES
# ════════════════════════════════════════════════════════════════════════

def _sign_index(sign: Optional[str]) -> Optional[int]:
    if not sign or sign not in SIGNS_ORDER:
        return None
    return SIGNS_ORDER.index(sign)


def _absolute_longitude(sign: str, degree: float) -> float:
    """Convert sign+degree to 0-360° longitude."""
    idx = _sign_index(sign)
    if idx is None:
        return 0.0
    return idx * 30.0 + float(degree)


def _longitude_to_sign_degree(longitude: float) -> Tuple[str, float]:
    """Convert 0-360° back to (sign, degree-within-sign)."""
    longitude = longitude % 360.0
    sign_idx = int(longitude // 30)
    deg = longitude - sign_idx * 30
    return SIGNS_ORDER[sign_idx], round(deg, 4)


def _angular_distance(lon1: float, lon2: float) -> float:
    """Smallest angular distance between two longitudes (0-180)."""
    d = abs((lon1 - lon2) % 360)
    return min(d, 360 - d)


# ════════════════════════════════════════════════════════════════════════
# SOLAR RETURN CHART — Iterative Sun-longitude convergence
# ════════════════════════════════════════════════════════════════════════

def _find_solar_return_moment(birth: Dict[str, Any], target_year: int,
                              natal_sun_longitude: float) -> Dict[str, Any]:
    """
    Iteratively find moment when transit Sun matches natal Sun longitude.
    Sun moves ~0.9856°/day = ~0.0411°/hour.
    Convergence target: |diff| < 0.05° (~73 minutes of clock time error).
    Max 8 iterations (covers wide span via halving).
    """
    # Start at birthday in target year, same clock time
    natal_dob = birth["dob"]  # "YYYY-MM-DD"
    natal_time = birth["time"]  # "HH:MM"
    month_day = natal_dob[5:]  # "MM-DD"
    current_dt = datetime.fromisoformat(f"{target_year}-{month_day}T{natal_time}:00")

    iterations: List[Dict[str, Any]] = []
    tolerance = 0.05  # degrees

    for i in range(8):
        date_str = current_dt.date().isoformat()
        time_str = current_dt.strftime("%H:%M")
        try:
            chart = get_chart(
                dob=date_str, time=time_str,
                lat=birth["lat"], lon=birth["lon"],
                timezone=birth.get("timezone", "Asia/Kolkata"),
            )
        except Exception as e:
            return {"success": False, "error": f"Chart cast failed: {e}",
                    "iterations": iterations}

        sun = chart.get("planets", {}).get("Sun", {})
        sun_lon = _absolute_longitude(sun.get("sign", "Aries"), sun.get("degree", 0))
        diff = sun_lon - natal_sun_longitude
        # Wrap to -180..+180
        if diff > 180:
            diff -= 360
        elif diff < -180:
            diff += 360

        iterations.append({
            "iter":         i + 1,
            "datetime":     current_dt.isoformat(),
            "sun_sign":     sun.get("sign"),
            "sun_degree":   round(sun.get("degree", 0), 4),
            "sun_longitude":round(sun_lon, 4),
            "diff_degrees": round(diff, 4),
        })

        if abs(diff) < tolerance:
            return {
                "success":      True,
                "return_dt":    current_dt.isoformat(),
                "return_chart": chart,
                "iterations":   iterations,
                "final_diff":   round(diff, 4),
            }

        # Sun moves ~0.04108°/hour; shift back by (diff / 0.04108) hours
        # Positive diff = transit Sun is AHEAD of natal Sun → go BACK in time
        hours_to_shift = -diff / 0.04108
        # Cap shift magnitude per iteration to avoid wild swings
        hours_to_shift = max(-72, min(72, hours_to_shift))
        current_dt = current_dt + timedelta(hours=hours_to_shift)

    return {
        "success":     False,
        "error":       "Convergence not reached after 8 iterations",
        "iterations":  iterations,
        "best_dt":     current_dt.isoformat(),
    }


# ════════════════════════════════════════════════════════════════════════
# CORE HELPERS — Native chart + solar return
# ════════════════════════════════════════════════════════════════════════

def _build_native_and_sr(birth: Dict[str, Any],
                         target_year: int) -> Dict[str, Any]:
    """Return both natal essentials and solar return chart for target year."""
    natal_raw = get_chart(
        dob=birth["dob"], time=birth["time"],
        lat=birth["lat"], lon=birth["lon"],
        timezone=birth.get("timezone", "Asia/Kolkata"),
    )
    natal_e = extract_chart_essentials(natal_raw)

    natal_sun = natal_raw.get("planets", {}).get("Sun", {})
    natal_sun_lon = _absolute_longitude(natal_sun.get("sign", "Aries"),
                                        natal_sun.get("degree", 0))

    sr_result = _find_solar_return_moment(birth, target_year, natal_sun_lon)

    if sr_result["success"]:
        sr_raw = sr_result["return_chart"]
        sr_e = extract_chart_essentials(sr_raw)
        return {
            "natal_raw":         natal_raw,
            "natal_essentials":  natal_e,
            "natal_sun_lon":     natal_sun_lon,
            "sr_raw":            sr_raw,
            "sr_essentials":     sr_e,
            "sr_moment":         sr_result["return_dt"],
            "sr_iterations":     sr_result["iterations"],
            "sr_success":        True,
            "sr_final_diff":     sr_result["final_diff"],
        }
    else:
        return {
            "natal_raw":         natal_raw,
            "natal_essentials":  natal_e,
            "natal_sun_lon":     natal_sun_lon,
            "sr_success":        False,
            "sr_error":          sr_result.get("error"),
            "sr_iterations":     sr_result.get("iterations", []),
        }


# ════════════════════════════════════════════════════════════════════════
# AGE CALCULATION (for Muntha)
# ════════════════════════════════════════════════════════════════════════

def _completed_years(birth_dob: str, target_year: int) -> int:
    """Years completed at start of target year's solar return."""
    birth_year = int(birth_dob[:4])
    return target_year - birth_year


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT HANDLERS
# ════════════════════════════════════════════════════════════════════════

def handle_cast_chart(birth: Dict[str, Any], year: int) -> Dict[str, Any]:
    """Endpoint 2: Solar return chart for target year."""
    bundle = _build_native_and_sr(birth, year)

    if not bundle["sr_success"]:
        return {
            "success":    False,
            "error":      bundle.get("sr_error"),
            "iterations": bundle["sr_iterations"],
            "citation":   CLASSICAL_CITATIONS["solar_return"],
        }

    sr_e = bundle["sr_essentials"]
    return {
        "success":          True,
        "target_year":      year,
        "sr_moment":        bundle["sr_moment"],
        "convergence_diff": bundle["sr_final_diff"],
        "sr_lagna":         sr_e.get("lagna_sign"),
        "sr_lagna_degree":  sr_e.get("lagna_degree"),
        "sr_moon":          {"sign": sr_e.get("moon_sign"),
                              "house": sr_e.get("moon_house"),
                              "nakshatra": sr_e.get("moon_nakshatra")},
        "sr_sun":           {"sign": sr_e.get("sun_sign"),
                              "house": sr_e.get("sun_house")},
        "sr_planets":       sr_e.get("planets"),
        "method":           "Iterative solar return search — transit Sun matched to natal Sun longitude within 0.05° at native's birthplace",
        "iterations_taken": len(bundle["sr_iterations"]),
        "citation":         CLASSICAL_CITATIONS["solar_return"],
    }


def handle_muntha(birth: Dict[str, Any], year: int) -> Dict[str, Any]:
    """Endpoint 3: Muntha point + lord + house result."""
    bundle = _build_native_and_sr(birth, year)
    if not bundle["sr_success"]:
        return {"success": False, "error": "Solar return failed",
                "citation": CLASSICAL_CITATIONS["muntha"]}

    natal_lagna_sign = bundle["natal_essentials"].get("lagna_sign")
    if not natal_lagna_sign:
        return {"success": False, "error": "Natal Lagna not resolvable",
                "citation": CLASSICAL_CITATIONS["muntha"]}

    age = _completed_years(birth["dob"], year)
    lagna_idx = _sign_index(natal_lagna_sign)
    muntha_idx = (lagna_idx + age) % 12
    muntha_sign = SIGNS_ORDER[muntha_idx]
    muntha_lord = SIGN_TO_LORD.get(muntha_sign)

    # Muntha house in solar return chart
    sr_lagna_sign = bundle["sr_essentials"].get("lagna_sign")
    sr_lagna_idx = _sign_index(sr_lagna_sign)
    muntha_house = ((muntha_idx - sr_lagna_idx) % 12) + 1 if sr_lagna_idx is not None else None

    house_meaning = MUNTHA_HOUSE_RESULTS.get(muntha_house or 0, {})

    return {
        "success":           True,
        "target_year":       year,
        "age_completed":     age,
        "natal_lagna":       natal_lagna_sign,
        "muntha_sign":       muntha_sign,
        "muntha_lord":       muntha_lord,
        "sr_lagna":          sr_lagna_sign,
        "muntha_house_in_sr":muntha_house,
        "house_meaning":     house_meaning,
        "note":              f"Muntha at age {age} = natal Lagna sign + {age} signs",
        "citation":          CLASSICAL_CITATIONS["muntha"],
    }


def _planet_strength_score(planet: str, essentials: Dict[str, Any]) -> int:
    """
    Simplified Pancha-Vargiya Bala approximation.
    Uses dignity + house placement + retrogradation + combustion.
    """
    pdata = essentials.get("planets", {}).get(planet, {})
    if not pdata:
        return 0
    score = 0
    dignity = pdata.get("dignity", "")
    if dignity == "exalted":          score += 5
    elif dignity == "moolatrikona":   score += 4
    elif dignity == "own":            score += 4
    elif dignity == "great_friend":   score += 3
    elif dignity == "friend":         score += 2
    elif dignity == "neutral":        score += 1
    elif dignity == "enemy":          score -= 1
    elif dignity == "great_enemy":    score -= 2
    elif dignity == "debilitated":    score -= 3

    if pdata.get("house") in (1, 4, 5, 7, 9, 10):  # kendra/trikona
        score += 2
    elif pdata.get("house") in (6, 8, 12):
        score -= 1

    if pdata.get("is_retrograde"):
        # Retrograde adds strength classically (cheshta bala for non-luminaries)
        if planet not in ("Sun", "Moon"):
            score += 1

    if pdata.get("is_combust"):
        score -= 2

    return score


def handle_year_lord(birth: Dict[str, Any], year: int) -> Dict[str, Any]:
    """Endpoint 4: Varshesha (Year Lord) selection via Pancha-Vargiya Bala approximation."""
    bundle = _build_native_and_sr(birth, year)
    if not bundle["sr_success"]:
        return {"success": False, "error": "Solar return failed",
                "citation": CLASSICAL_CITATIONS["year_lord"]}

    sr_e = bundle["sr_essentials"]

    # 5 candidates per classical Tajik
    muntha_data = handle_muntha(birth, year)
    muntha_lord = muntha_data.get("muntha_lord") if muntha_data.get("success") else None
    sr_lagna_lord = SIGN_TO_LORD.get(sr_e.get("lagna_sign", ""))
    sr_sun_sign = sr_e.get("planets", {}).get("Sun", {}).get("sign")
    sr_sun_lord = SIGN_TO_LORD.get(sr_sun_sign) if sr_sun_sign else None
    sr_moon_lord = SIGN_TO_LORD.get(sr_e.get("moon_sign", ""))
    sr_dt = datetime.fromisoformat(bundle["sr_moment"])
    day_lord = WEEKDAY_PLANET.get(sr_dt.weekday())

    candidates_strength: List[Dict[str, Any]] = []
    for label, planet in [("muntha_lord", muntha_lord),
                          ("sr_lagna_lord", sr_lagna_lord),
                          ("sr_sun_lord", sr_sun_lord),
                          ("sr_moon_lord", sr_moon_lord),
                          ("day_lord", day_lord)]:
        if not planet:
            continue
        strength = _planet_strength_score(planet, sr_e)
        candidates_strength.append({
            "candidate_type": label,
            "planet":         planet,
            "strength_score": strength,
        })

    # Highest strength wins; ties broken by candidate priority order
    candidates_strength.sort(key=lambda x: -x["strength_score"])
    varshesha = candidates_strength[0] if candidates_strength else None

    return {
        "success":          True,
        "target_year":      year,
        "sr_moment":        bundle["sr_moment"],
        "candidates":       candidates_strength,
        "varshesha":        varshesha,
        "verdict":          (f"{varshesha['planet']} (as {varshesha['candidate_type']}) "
                              f"wins with strength score {varshesha['strength_score']}") if varshesha else "No candidate",
        "method":           "Simplified Pancha-Vargiya Bala: dignity + house + retrogradation + combustion. Real classical computation requires Egyptian bounds, decanates, drekkana, hadda — engine approximates.",
        "citation":         CLASSICAL_CITATIONS["year_lord"],
    }


def handle_tajik_aspects(birth: Dict[str, Any], year: int) -> Dict[str, Any]:
    """Endpoint 5: Ithasala / Eesharafa / Mutthasila yoga detection in solar return chart."""
    bundle = _build_native_and_sr(birth, year)
    if not bundle["sr_success"]:
        return {"success": False, "error": "Solar return failed",
                "citation": CLASSICAL_CITATIONS["tajik_aspects"]}

    sr_raw = bundle["sr_raw"]
    planets = sr_raw.get("planets", {})

    # Build longitude list with retrograde status
    planet_lons: Dict[str, Dict[str, Any]] = {}
    for name in ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]:
        p = planets.get(name, {})
        if isinstance(p, dict) and p.get("sign"):
            planet_lons[name] = {
                "longitude":     _absolute_longitude(p["sign"], p.get("degree", 0)),
                "is_retrograde": p.get("is_retrograde", False),
                "sign":          p["sign"],
                "degree":        p.get("degree"),
            }

    # Mean daily motion (degrees/day) for "faster" determination — classical
    DAILY_MOTION: Dict[str, float] = {
        "Moon": 13.18, "Mercury": 1.38, "Venus": 1.20, "Sun": 0.986,
        "Mars": 0.524, "Jupiter": 0.083, "Saturn": 0.033,
    }

    detected: List[Dict[str, Any]] = []
    planet_names = list(planet_lons.keys())
    for i in range(len(planet_names)):
        for j in range(i + 1, len(planet_names)):
            p1, p2 = planet_names[i], planet_names[j]
            lon1, lon2 = planet_lons[p1]["longitude"], planet_lons[p2]["longitude"]
            dist = _angular_distance(lon1, lon2)

            for asp_name, asp_data in TAJIK_ASPECTS_ORBS.items():
                if abs(dist - asp_data["angle"]) <= asp_data["orb"]:
                    # Determine applying vs separating
                    m1 = DAILY_MOTION.get(p1, 0) * (-1 if planet_lons[p1]["is_retrograde"] else 1)
                    m2 = DAILY_MOTION.get(p2, 0) * (-1 if planet_lons[p2]["is_retrograde"] else 1)
                    faster = p1 if abs(m1) > abs(m2) else p2
                    slower = p2 if faster == p1 else p1
                    # Applying: faster is approaching exact aspect with slower
                    delta = dist - asp_data["angle"]
                    applying = delta < 0  # simplified
                    yoga_type = "Ithasala" if applying else "Eesharafa"

                    detected.append({
                        "planet1":      p1,
                        "planet2":      p2,
                        "aspect":       asp_name,
                        "exact_angle":  asp_data["angle"],
                        "actual_dist":  round(dist, 2),
                        "orb_used":     asp_data["orb"],
                        "yoga":         yoga_type,
                        "yoga_meaning": TAJIK_YOGAS[yoga_type]["domain"],
                        "favorable":    TAJIK_YOGAS[yoga_type]["favorable"],
                        "faster_planet":faster,
                        "slower_planet":slower,
                    })

    return {
        "success":          True,
        "target_year":      year,
        "sr_moment":        bundle["sr_moment"],
        "aspect_orbs_used": {k: v["orb"] for k, v in TAJIK_ASPECTS_ORBS.items()},
        "tajik_yogas_detected": detected,
        "yoga_count":       len(detected),
        "yoga_reference":   TAJIK_YOGAS,
        "citation":         CLASSICAL_CITATIONS["tajik_aspects"],
    }


def handle_sahams(birth: Dict[str, Any], year: int) -> Dict[str, Any]:
    """Endpoint 6: 20 Sahams (Hellenistic-Tajik Lots) for solar return year."""
    bundle = _build_native_and_sr(birth, year)
    if not bundle["sr_success"]:
        return {"success": False, "error": "Solar return failed",
                "citation": CLASSICAL_CITATIONS["sahams"]}

    sr_raw = bundle["sr_raw"]
    sr_e = bundle["sr_essentials"]
    planets = sr_raw.get("planets", {})

    # Build longitude lookup
    def lon(name: str) -> float:
        if name == "Lagna":
            return _absolute_longitude(sr_e.get("lagna_sign", "Aries"),
                                       sr_e.get("lagna_degree", 0))
        if name == "lord_of_lagna":
            lord = SIGN_TO_LORD.get(sr_e.get("lagna_sign", ""))
            if not lord:
                return 0.0
            p = planets.get(lord, {})
            return _absolute_longitude(p.get("sign", "Aries"), p.get("degree", 0))
        p = planets.get(name, {})
        return _absolute_longitude(p.get("sign", "Aries"), p.get("degree", 0))

    # Determine day/night birth: Sun above horizon = day; here we approximate
    # using Sun's house — houses 7-12 (above horizon) = day, 1-6 = night
    sun_house = sr_e.get("planets", {}).get("Sun", {}).get("house", 1)
    is_day = sun_house in (7, 8, 9, 10, 11, 12)
    day_or_night = "day" if is_day else "night"

    saham_results: List[Dict[str, Any]] = []
    for name, data in SAHAMS.items():
        formula_str = data["formula_day"] if is_day else data["formula_night"]
        # Parse formula: "A + B - C"
        try:
            parts = formula_str.replace("-", "+ -").split("+")
            parts = [p.strip() for p in parts if p.strip()]
            total = 0.0
            for part in parts:
                if part.startswith("-"):
                    total -= lon(part[1:].strip())
                else:
                    total += lon(part)
            total = total % 360
            if total < 0:
                total += 360
            sign, deg = _longitude_to_sign_degree(total)
            # House of saham in SR chart
            sr_lagna_idx = _sign_index(sr_e.get("lagna_sign"))
            sign_idx = _sign_index(sign)
            house = ((sign_idx - sr_lagna_idx) % 12) + 1 if (sr_lagna_idx is not None and sign_idx is not None) else None
            saham_results.append({
                "saham":     name,
                "domain":    data["domain"],
                "formula":   formula_str,
                "longitude": round(total, 2),
                "sign":      sign,
                "degree":    deg,
                "house":     house,
                "life_area": HOUSE_TO_LIFE_AREA.get(house, "") if house else "",
            })
        except Exception as e:
            saham_results.append({
                "saham": name,
                "error": str(e),
            })

    return {
        "success":      True,
        "target_year":  year,
        "sr_moment":    bundle["sr_moment"],
        "day_or_night": day_or_night,
        "sahams":       saham_results,
        "saham_count":  len(saham_results),
        "note":         "Formulas vary day vs night birth per classical convention. Sun above horizon (houses 7-12) = day chart.",
        "citation":     CLASSICAL_CITATIONS["sahams"],
    }


def handle_monthly_predictions(birth: Dict[str, Any], year: int) -> Dict[str, Any]:
    """
    Endpoint 7: 12-month breakdown.
    Each month corresponds to one Muntha-house transit and one Mudda dasha segment.
    """
    bundle = _build_native_and_sr(birth, year)
    if not bundle["sr_success"]:
        return {"success": False, "error": "Solar return failed",
                "citation": CLASSICAL_CITATIONS["monthly"]}

    sr_dt = datetime.fromisoformat(bundle["sr_moment"])
    natal_lagna_idx = _sign_index(bundle["natal_essentials"].get("lagna_sign"))
    age = _completed_years(birth["dob"], year)
    base_muntha_idx = (natal_lagna_idx + age) % 12 if natal_lagna_idx is not None else 0

    months: List[Dict[str, Any]] = []
    for m in range(12):
        month_start = sr_dt + timedelta(days=m * 30.4375)  # ~365.25/12
        month_end = sr_dt + timedelta(days=(m + 1) * 30.4375)
        muntha_sign = SIGNS_ORDER[(base_muntha_idx + m) % 12]
        muntha_lord = SIGN_TO_LORD.get(muntha_sign)
        sr_lagna_idx = _sign_index(bundle["sr_essentials"].get("lagna_sign"))
        muntha_house_in_sr = ((base_muntha_idx + m - sr_lagna_idx) % 12) + 1 if sr_lagna_idx is not None else None
        house_meaning = MUNTHA_HOUSE_RESULTS.get(muntha_house_in_sr or 0, {})
        months.append({
            "month_number":          m + 1,
            "start_date":            month_start.date().isoformat(),
            "end_date":              month_end.date().isoformat(),
            "muntha_sign_this_month":muntha_sign,
            "muntha_lord":           muntha_lord,
            "muntha_house_in_sr":    muntha_house_in_sr,
            "themes":                house_meaning.get("themes", ""),
            "favorable":             house_meaning.get("favorable", ""),
            "caution":               house_meaning.get("caution", ""),
        })

    return {
        "success":     True,
        "target_year": year,
        "sr_moment":   bundle["sr_moment"],
        "months":      months,
        "note":        "Each month, Muntha shifts to next sign through solar return chart's house wheel.",
        "citation":    CLASSICAL_CITATIONS["monthly"],
    }


def handle_dasha_for_year(birth: Dict[str, Any], year: int) -> Dict[str, Any]:
    """Endpoint 8: Mudda dasha (annual Vimshottari subset)."""
    bundle = _build_native_and_sr(birth, year)
    if not bundle["sr_success"]:
        return {"success": False, "error": "Solar return failed",
                "citation": CLASSICAL_CITATIONS["mudda_dasha"]}

    # Mudda starts from natal Moon nakshatra lord
    natal_moon_nak_lord = bundle["natal_essentials"].get("moon_nakshatra_lord")
    if not natal_moon_nak_lord:
        return {"success": False, "error": "Natal Moon nakshatra lord not resolvable"}

    # Build cycle starting from that lord
    order = ["Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury"]
    start_idx = order.index(natal_moon_nak_lord) if natal_moon_nak_lord in order else 0
    sequence = [order[(start_idx + i) % 9] for i in range(9)]

    total_year_days = 365.25
    total_vims = sum(MUDDA_VIMSHOTTARI_YEARS.values())  # 120

    sr_dt = datetime.fromisoformat(bundle["sr_moment"])
    mudda: List[Dict[str, Any]] = []
    current_dt = sr_dt
    for p in sequence:
        days = (MUDDA_VIMSHOTTARI_YEARS[p] / total_vims) * total_year_days
        end_dt = current_dt + timedelta(days=days)
        mudda.append({
            "planet":     p,
            "start_date": current_dt.date().isoformat(),
            "end_date":   end_dt.date().isoformat(),
            "days":       round(days, 1),
        })
        current_dt = end_dt

    return {
        "success":           True,
        "target_year":       year,
        "sr_moment":         bundle["sr_moment"],
        "natal_moon_nak_lord":natal_moon_nak_lord,
        "starting_planet":   natal_moon_nak_lord,
        "mudda_sequence":    mudda,
        "note":              "Mudda dasha = Vimshottari ratios applied to solar return year (365.25 days). Same planetary sequence as natal Vimshottari but compressed to 1 year.",
        "citation":          CLASSICAL_CITATIONS["mudda_dasha"],
    }


def handle_event_timing(birth: Dict[str, Any], year: int) -> Dict[str, Any]:
    """Endpoint 9: Key event windows in upcoming year."""
    bundle = _build_native_and_sr(birth, year)
    if not bundle["sr_success"]:
        return {"success": False, "error": "Solar return failed",
                "citation": CLASSICAL_CITATIONS["monthly"]}

    # Cross-reference Muntha house meaning + Year Lord period within Mudda + key Sahams
    muntha = handle_muntha(birth, year)
    year_lord = handle_year_lord(birth, year)
    mudda = handle_dasha_for_year(birth, year)
    sahams = handle_sahams(birth, year)

    events: List[Dict[str, Any]] = []
    # Look for Sahams in favorable houses
    if sahams.get("success"):
        for s in sahams.get("sahams", []):
            if s.get("house") in (1, 5, 9, 10, 11):
                events.append({
                    "event_type":    "auspicious_saham",
                    "saham_name":    s["saham"],
                    "domain":        s["domain"],
                    "house_in_sr":   s["house"],
                    "significance":  f"Saham {s['saham']} ({s['domain']}) falls in beneficial house {s['house']} — supportive theme for {s['domain']}",
                })

    # Muntha house verdict
    if muntha.get("success"):
        h = muntha.get("muntha_house_in_sr")
        if h in (1, 5, 9, 10, 11):
            events.append({
                "event_type":    "muntha_strong",
                "muntha_house":  h,
                "significance":  f"Muntha in house {h} ({muntha.get('house_meaning', {}).get('domain', '')}) — beneficial year emphasis",
            })
        elif h in (6, 8, 12):
            events.append({
                "event_type":    "muntha_challenging",
                "muntha_house":  h,
                "significance":  f"Muntha in house {h} ({muntha.get('house_meaning', {}).get('domain', '')}) — caution year emphasis",
            })

    # Year lord verdict
    if year_lord.get("success") and year_lord.get("varshesha"):
        v = year_lord["varshesha"]
        if v["strength_score"] >= 4:
            events.append({
                "event_type":    "strong_varshesha",
                "planet":        v["planet"],
                "strength":      v["strength_score"],
                "significance":  f"Year Lord {v['planet']} is strong (score {v['strength_score']}) — favorable year overall",
            })
        elif v["strength_score"] < 0:
            events.append({
                "event_type":    "weak_varshesha",
                "planet":        v["planet"],
                "strength":      v["strength_score"],
                "significance":  f"Year Lord {v['planet']} is weak (score {v['strength_score']}) — extra care needed",
            })

    return {
        "success":         True,
        "target_year":     year,
        "sr_moment":       bundle["sr_moment"],
        "events_detected": events,
        "event_count":     len(events),
        "method":          "Synthesizes Muntha house, Year Lord strength, beneficial Saham placements",
        "citation":        CLASSICAL_CITATIONS["monthly"],
    }


def handle_year_remedies(birth: Dict[str, Any], year: int) -> Dict[str, Any]:
    """Endpoint 10: Year-specific classical remedies."""
    year_lord_data = handle_year_lord(birth, year)
    muntha = handle_muntha(birth, year)

    remedies: List[Dict[str, Any]] = []

    # Remedies based on year lord
    if year_lord_data.get("success") and year_lord_data.get("varshesha"):
        v = year_lord_data["varshesha"]
        planet = v["planet"]
        strength = v["strength_score"]

        # If strong, strengthen the year lord
        if strength >= 2:
            remedies.append({
                "category":     "Strengthen Year Lord",
                "planet":       planet,
                "recommendation":f"Honor {planet} via classical mantra, donation, fasting on {planet}'s day to deepen the supportive year-lord influence",
            })
        else:
            remedies.append({
                "category":     "Propitiate Year Lord",
                "planet":       planet,
                "recommendation":f"Strengthen weak {planet} via daily {planet} mantra (108x), {planet}-specific donation on relevant weekday, classical {planet} rituals",
            })

    # Remedies based on Muntha house
    if muntha.get("success"):
        h = muntha.get("muntha_house_in_sr")
        if h in (6, 8, 12):
            remedies.append({
                "category":     "Muntha in Dushthana",
                "muntha_house": h,
                "recommendation":f"Muntha in house {h} requires year-long mitigation: regular Mahamrityunjaya Mantra, charity, avoid major new ventures in this domain — focus on inner work.",
            })
        elif h in (1, 5, 9):
            remedies.append({
                "category":     "Muntha in Trikona/Lagna",
                "muntha_house": h,
                "recommendation":f"Muntha in house {h} — leverage with mantra/yantra of relevant lord; year favors initiatives in {MUNTHA_HOUSE_RESULTS.get(h, {}).get('domain', '')}",
            })

    return {
        "success":      True,
        "target_year":  year,
        "remedies":     remedies,
        "general_advice": [
            "On solar return day: ritual bath, donate to Brahmins/needy, recite Aditya Hridaya Stotram (Sun-honoring stotra)",
            "Throughout the year: Sun-honoring Sundays — Surya Arghya at sunrise",
            "Avoid risky initiations during Mudda dasha of malefic year lord",
            "Wear/avoid gemstones per natal chart's gem safety rules (see remedies/vedic/gemstones endpoint)",
        ],
        "citation":     CLASSICAL_CITATIONS["year_remedies"],
    }


def handle_profile(birth: Dict[str, Any], year: int) -> Dict[str, Any]:
    """Endpoint 1 (MASTER): Master Varshaphala synthesis."""
    bundle = _build_native_and_sr(birth, year)
    if not bundle["sr_success"]:
        return {
            "success":   False,
            "error":     "Solar return convergence failed",
            "iterations":bundle.get("sr_iterations"),
            "citation":  CLASSICAL_CITATIONS["solar_return"],
        }

    cast = handle_cast_chart(birth, year)
    muntha = handle_muntha(birth, year)
    year_lord = handle_year_lord(birth, year)
    aspects = handle_tajik_aspects(birth, year)
    sahams = handle_sahams(birth, year)
    events = handle_event_timing(birth, year)
    remedies = handle_year_remedies(birth, year)

    headlines: List[str] = []
    if muntha.get("success"):
        h = muntha.get("muntha_house_in_sr")
        headlines.append(
            f"Muntha at age {muntha.get('age_completed')}: {muntha.get('muntha_sign')} → SR house {h}"
        )
    if year_lord.get("success") and year_lord.get("varshesha"):
        v = year_lord["varshesha"]
        headlines.append(
            f"Year Lord (Varshesha): {v['planet']} (strength {v['strength_score']})"
        )
    if aspects.get("yoga_count", 0) > 0:
        headlines.append(
            f"Tajik yogas detected: {aspects['yoga_count']} (Ithasala/Eesharafa patterns active)"
        )
    if events.get("event_count", 0) > 0:
        headlines.append(
            f"Key events flagged: {events['event_count']}"
        )

    return {
        "success":       True,
        "target_year":   year,
        "sr_moment":     bundle["sr_moment"],
        "headlines":     headlines,
        "solar_return_chart": cast,
        "muntha":        muntha,
        "year_lord":     year_lord,
        "tajik_aspects": aspects,
        "sahams":        sahams,
        "event_timing":  events,
        "year_remedies": remedies,
        "method":        "Full Tajik Varshaphala synthesis — Solar Return + Muntha + Varshesha + Tajik yogas + Sahams + Mudda dasha + classical remedies",
        "citations": {
            "primary":     CLASSICAL_CITATIONS["solar_return"],
            "muntha":      CLASSICAL_CITATIONS["muntha"],
            "year_lord":   CLASSICAL_CITATIONS["year_lord"],
            "aspects":     CLASSICAL_CITATIONS["tajik_aspects"],
            "sahams":      CLASSICAL_CITATIONS["sahams"],
            "dasha":       CLASSICAL_CITATIONS["mudda_dasha"],
        },
    }
