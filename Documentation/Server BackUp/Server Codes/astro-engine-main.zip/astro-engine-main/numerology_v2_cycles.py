"""
numerology_v2_cycles.py — Time-based numerology cycles.

This is the numerology equivalent of Vedic dasha/transit/timeline. Functions:
  - personal_year(dob, target_year)         → current year's energy
  - personal_month(dob, target_year, month) → month sub-cycle
  - personal_day(dob, target_date)          → daily forecast
  - pinnacles(dob)                           → 4 life-stage periods (~28 years each)
  - challenges(dob)                          → 4 sub-pinnacle struggles
  - life_arc(dob, horizon_years=15)          → year-by-year forecast for N years

Each result is structured for AI interpretation.
"""

from typing import Dict, Any, List
from datetime import datetime, date
from numerology_v2 import _reduce_to_single, _digit_sum, NUMBER_RULER


# ─────────────────────────────────────────────────────────────────────────────
# Universal-year baseline (used as base for personal-year math)
# ─────────────────────────────────────────────────────────────────────────────

def universal_year(year: int) -> int:
    """Universal Year = the year itself reduced. 2026 → 2+0+2+6 = 10 → 1."""
    return _reduce_to_single(_digit_sum(year), preserve_masters=False)


# ─────────────────────────────────────────────────────────────────────────────
# 1. PERSONAL YEAR
# ─────────────────────────────────────────────────────────────────────────────

PERSONAL_YEAR_THEMES = {
    1: "Beginnings, independence, planting seeds. Year of new starts.",
    2: "Cooperation, patience, relationship-building. Year of waiting.",
    3: "Creative expression, joy, social expansion. Year of communication.",
    4: "Hard work, foundation-building, structure. Year of discipline.",
    5: "Change, freedom, travel, experimentation. Year of movement.",
    6: "Responsibility, family, home, service. Year of love & duty.",
    7: "Introspection, spiritual study, retreat. Year of inner work.",
    8: "Power, recognition, material harvest. Year of achievement.",
    9: "Completion, release, transformation. Year of endings.",
    11: "Spiritual awakening, intuitive breakthrough. Master year of vision.",
    22: "Master building, large-scale manifestation. Master year of construction.",
    33: "Master teaching, selfless service. Master year of healing.",
}


def personal_year(dob: str, target_year: int = None) -> Dict[str, Any]:
    """Personal Year = (birth month + birth day + target year) reduced.
    The dominant energy theme for that year of your life."""
    if target_year is None:
        target_year = datetime.now().year

    y, m, d = dob.split("-")
    month = int(m)
    day = int(d)

    raw = month + day + target_year
    py = _reduce_to_single(raw, preserve_masters=True)

    return {
        "year": target_year,
        "value": py,
        "raw_sum": raw,
        "components": {"birth_month": month, "birth_day": day, "year": target_year},
        "planet": NUMBER_RULER.get(py, {}).get("planet"),
        "theme": PERSONAL_YEAR_THEMES.get(py, ""),
        "universal_year": universal_year(target_year),
        "interpretation_note": "The dominant numerological energy of this calendar year for you",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 2. PERSONAL MONTH
# ─────────────────────────────────────────────────────────────────────────────

def personal_month(dob: str, target_year: int = None, target_month: int = None) -> Dict[str, Any]:
    """Personal Month = Personal Year + current calendar month, reduced."""
    if target_year is None:  target_year = datetime.now().year
    if target_month is None: target_month = datetime.now().month

    py = personal_year(dob, target_year)["value"]
    raw = py + target_month
    pm = _reduce_to_single(raw, preserve_masters=True)

    return {
        "year": target_year,
        "month": target_month,
        "value": pm,
        "raw_sum": raw,
        "components": {"personal_year": py, "month": target_month},
        "planet": NUMBER_RULER.get(pm, {}).get("planet"),
        "theme": PERSONAL_YEAR_THEMES.get(pm, ""),
        "interpretation_note": "Sub-cycle energy for this month within the personal year",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 3. PERSONAL DAY
# ─────────────────────────────────────────────────────────────────────────────

def personal_day(dob: str, target_date: str = None) -> Dict[str, Any]:
    """Personal Day = Personal Month + day-of-month, reduced. Daily energy."""
    if target_date is None:
        target_date = datetime.now().strftime("%Y-%m-%d")
    ty, tm, td = target_date.split("-")
    target_year, target_month, target_day = int(ty), int(tm), int(td)

    pm = personal_month(dob, target_year, target_month)["value"]
    raw = pm + target_day
    pd_val = _reduce_to_single(raw, preserve_masters=True)

    return {
        "date": target_date,
        "value": pd_val,
        "raw_sum": raw,
        "components": {"personal_month": pm, "day": target_day},
        "planet": NUMBER_RULER.get(pd_val, {}).get("planet"),
        "theme": PERSONAL_YEAR_THEMES.get(pd_val, ""),
        "interpretation_note": "The dominant energy for THIS day in your life",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 4. PINNACLES (Life-stage periods)
# ─────────────────────────────────────────────────────────────────────────────

PINNACLE_MEANINGS = {
    1: "Independence, new beginnings, self-discovery — strong sense of self",
    2: "Partnerships, patience, learning to receive — sensitivity heightened",
    3: "Creative expression, joy, communication — social expansion",
    4: "Foundation-building, hard work, structure — practical achievement",
    5: "Freedom, change, adventure — many transitions, travel, learning by doing",
    6: "Family, responsibility, love and service — domestic / caregiving themes",
    7: "Introspection, spiritual study, solitude — inner journey years",
    8: "Power, money, recognition — material peak, leadership demands",
    9: "Completion, humanitarian work, letting go — transformative endings",
    11: "Master Pinnacle of spiritual illumination — intuitive teaching",
    22: "Master Pinnacle of building — large-scale practical visions",
    33: "Master Pinnacle of service — devoted teaching/healing",
}


def pinnacles(dob: str) -> Dict[str, Any]:
    """Four Pinnacles = 4 life-stage periods.
    
    1st Pinnacle: birth → (36 - life_path), reduced birth_month + birth_day
    2nd Pinnacle: next 9 years, birth_day + birth_year (reduced)
    3rd Pinnacle: next 9 years, 1st + 2nd pinnacle (reduced)
    4th Pinnacle: remaining life, birth_month + birth_year (reduced)
    """
    y, m, d = dob.split("-")
    year, month, day = int(y), int(m), int(d)

    # Life Path number (to anchor stage transitions)
    from numerology_v2 import pythagorean_bhagyank
    lp = pythagorean_bhagyank(dob)["value"]
    
    # Stage 1 ends at age (36 - life_path)
    stage1_end_age = 36 - lp
    if stage1_end_age < 27: stage1_end_age = 27  # minimum threshold

    p1 = _reduce_to_single(_digit_sum(month) + _digit_sum(day), preserve_masters=True)
    p2 = _reduce_to_single(_digit_sum(day) + _digit_sum(year), preserve_masters=True)
    p3 = _reduce_to_single(p1 + p2, preserve_masters=True)
    p4 = _reduce_to_single(_digit_sum(month) + _digit_sum(year), preserve_masters=True)

    today_age = datetime.now().year - year

    pinns = [
        {
            "pinnacle": 1,
            "value": p1,
            "age_range": [0, stage1_end_age],
            "is_current": today_age <= stage1_end_age,
            "planet": NUMBER_RULER.get(p1, {}).get("planet"),
            "theme": PINNACLE_MEANINGS.get(p1, ""),
        },
        {
            "pinnacle": 2,
            "value": p2,
            "age_range": [stage1_end_age + 1, stage1_end_age + 9],
            "is_current": stage1_end_age < today_age <= stage1_end_age + 9,
            "planet": NUMBER_RULER.get(p2, {}).get("planet"),
            "theme": PINNACLE_MEANINGS.get(p2, ""),
        },
        {
            "pinnacle": 3,
            "value": p3,
            "age_range": [stage1_end_age + 10, stage1_end_age + 18],
            "is_current": stage1_end_age + 9 < today_age <= stage1_end_age + 18,
            "planet": NUMBER_RULER.get(p3, {}).get("planet"),
            "theme": PINNACLE_MEANINGS.get(p3, ""),
        },
        {
            "pinnacle": 4,
            "value": p4,
            "age_range": [stage1_end_age + 19, 120],  # remaining life
            "is_current": today_age > stage1_end_age + 18,
            "planet": NUMBER_RULER.get(p4, {}).get("planet"),
            "theme": PINNACLE_MEANINGS.get(p4, ""),
        },
    ]

    current = next((p for p in pinns if p["is_current"]), None)

    return {
        "pinnacles": pinns,
        "current_pinnacle": current,
        "current_age": today_age,
        "life_path": lp,
        "interpretation_note": "Each pinnacle is a major life-chapter with distinct themes — like Vedic mahadasha",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 5. CHALLENGES (Sub-pinnacle struggles)
# ─────────────────────────────────────────────────────────────────────────────

CHALLENGE_MEANINGS = {
    0: "No specific challenge — abundance of options can paradoxically be the challenge",
    1: "Challenge: asserting yourself; learning to stand alone",
    2: "Challenge: oversensitivity, dependency; learning self-reliance",
    3: "Challenge: scattered energy; learning focus in creativity",
    4: "Challenge: rigidity, overwork; learning flexibility within structure",
    5: "Challenge: restlessness, addiction tendencies; learning constructive freedom",
    6: "Challenge: over-responsibility, martyr complex; learning self-care",
    7: "Challenge: isolation, doubt; learning faith and trust",
    8: "Challenge: misuse of power, materialism; learning ethical authority",
}


def challenges(dob: str) -> Dict[str, Any]:
    """Four Challenges = sub-themes within each pinnacle. 
    Always reduced WITHOUT master numbers; can be 0."""
    y, m, d = dob.split("-")
    year, month, day = int(y), int(m), int(d)

    def reduce_no_master(n):
        while n > 9:
            n = sum(int(d) for d in str(abs(n)))
        return n

    m_r = reduce_no_master(_digit_sum(month))
    d_r = reduce_no_master(_digit_sum(day))
    y_r = reduce_no_master(_digit_sum(year))

    c1 = abs(m_r - d_r)
    c2 = abs(d_r - y_r)
    c3 = abs(c1 - c2)  # main challenge — runs entire life
    c4 = abs(m_r - y_r)

    return {
        "challenges": [
            {"number": 1, "value": c1, "meaning": CHALLENGE_MEANINGS.get(c1, "")},
            {"number": 2, "value": c2, "meaning": CHALLENGE_MEANINGS.get(c2, "")},
            {"number": 3, "value": c3, "meaning": CHALLENGE_MEANINGS.get(c3, ""), "lifelong": True},
            {"number": 4, "value": c4, "meaning": CHALLENGE_MEANINGS.get(c4, "")},
        ],
        "main_challenge": c3,  # the one that runs the whole life
        "interpretation_note": "Challenges are sub-pinnacle struggles you must overcome; main challenge runs lifelong",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 6. LIFE ARC — year-by-year forecast for N years (for the Annual Compass)
# ─────────────────────────────────────────────────────────────────────────────

def life_arc(dob: str, horizon_years: int = 15) -> Dict[str, Any]:
    """
    Year-by-year numerological forecast.
    Returns an array of {year, age, personal_year, theme, pinnacle, challenge}
    for the next N years.
    """
    y, m, d = dob.split("-")
    birth_year = int(y)
    current_year = datetime.now().year

    # Pre-compute pinnacles and challenges once
    pn = pinnacles(dob)
    ch = challenges(dob)

    arc = []
    for offset in range(horizon_years):
        target_year = current_year + offset
        age = target_year - birth_year
        py = personal_year(dob, target_year)
        # Find which pinnacle covers this age
        active_pinn = next((p for p in pn["pinnacles"] if p["age_range"][0] <= age <= p["age_range"][1]), None)
        arc.append({
            "year":                  target_year,
            "age":                    age,
            "personal_year":            py["value"],
            "personal_year_planet":      py.get("planet"),
            "theme":                       py["theme"],
            "active_pinnacle_number":        active_pinn["pinnacle"] if active_pinn else None,
            "active_pinnacle_value":           active_pinn["value"] if active_pinn else None,
            "active_pinnacle_theme":             active_pinn["theme"] if active_pinn else None,
            "main_challenge":                      ch["main_challenge"],
        })

    return {
        "start_year": current_year,
        "end_year": current_year + horizon_years - 1,
        "horizon_years": horizon_years,
        "arc": arc,
        "interpretation_note": "Year-by-year numerological forecast combining Personal Year + Pinnacle + Challenge",
    }
