"""
kp_data.py — Krishnamurti Paddhati (KP) reference data.

Phase D — Module D4 (KP Pro).

Public catalogs:
    NAKSHATRA_SEQUENCE     — 27 nakshatras in zodiacal order (Ashwini→Revati)
    NAKSHATRA_LORD         — Vimshottari ruling planet for each nakshatra
    VIMSHOTTARI_YEARS      — Years per planet (Ketu=7, Venus=20, ..., Mercury=17)
    VIMSHOTTARI_ORDER      — Sequence within a nakshatra for sub-lord division
    PLANET_HOUSE_SIGNIFICATIONS — KP planet → houses signified (via star-lord chain)
    KP_RULING_PLANETS_RULES — How to identify ruling planets at any moment
    CLASSICAL_CITATIONS

Sources: K.S. Krishnamurti, "Krishnamurti Paddhati" (1971) — principles
         public-domain in India since 2021 (50-year copyright + author death 1972).
         Original Vimshottari mathematics traces to BPHS (~6th c. CE).
         Hindi/Tamil/English KP literature traditions.
All sources public domain.
"""

from typing import Dict, List


# ════════════════════════════════════════════════════════════════════════
# NAKSHATRA SEQUENCE (zodiacal order, Aries 0° → Pisces 30°)
# Each nakshatra spans 13°20' (800') of zodiac
# ════════════════════════════════════════════════════════════════════════

NAKSHATRA_SEQUENCE: List[str] = [
    "Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashira", "Ardra",
    "Punarvasu", "Pushya", "Ashlesha", "Magha", "Purva Phalguni",
    "Uttara Phalguni", "Hasta", "Chitra", "Swati", "Vishakha", "Anuradha",
    "Jyeshtha", "Mula", "Purva Ashadha", "Uttara Ashadha", "Shravana",
    "Dhanishta", "Shatabhisha", "Purva Bhadrapada", "Uttara Bhadrapada",
    "Revati",
]

# Nakshatra → Vimshottari ruling planet (the Star-Lord in KP terminology)
NAKSHATRA_LORD: Dict[str, str] = {
    "Ashwini": "Ketu",          "Bharani": "Venus",       "Krittika": "Sun",
    "Rohini": "Moon",           "Mrigashira": "Mars",     "Ardra": "Rahu",
    "Punarvasu": "Jupiter",     "Pushya": "Saturn",       "Ashlesha": "Mercury",
    "Magha": "Ketu",            "Purva Phalguni": "Venus","Uttara Phalguni": "Sun",
    "Hasta": "Moon",            "Chitra": "Mars",         "Swati": "Rahu",
    "Vishakha": "Jupiter",      "Anuradha": "Saturn",     "Jyeshtha": "Mercury",
    "Mula": "Ketu",             "Purva Ashadha": "Venus", "Uttara Ashadha": "Sun",
    "Shravana": "Moon",         "Dhanishta": "Mars",      "Shatabhisha": "Rahu",
    "Purva Bhadrapada": "Jupiter","Uttara Bhadrapada": "Saturn","Revati": "Mercury",
}


# ════════════════════════════════════════════════════════════════════════
# VIMSHOTTARI DASHA — Total cycle = 120 years
# ════════════════════════════════════════════════════════════════════════

VIMSHOTTARI_YEARS: Dict[str, int] = {
    "Ketu":    7,
    "Venus":   20,
    "Sun":     6,
    "Moon":    10,
    "Mars":    7,
    "Rahu":    18,
    "Jupiter": 16,
    "Saturn":  19,
    "Mercury": 17,
}  # Total = 120 years

# Sequence used for sub-lord division within a nakshatra:
# Starts with the nakshatra's lord, then Vimshottari order from there
VIMSHOTTARI_ORDER: List[str] = [
    "Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury",
]


# ════════════════════════════════════════════════════════════════════════
# KP HOUSE SIGNIFICATIONS — Each planet's natural-karaka houses
# Used to determine "signified houses" via the star-lord chain
# Source: KP classical doctrine
# ════════════════════════════════════════════════════════════════════════

PLANET_NATURAL_KARAKAS: Dict[str, List[int]] = {
    "Sun":     [1, 5, 9, 10],          # Self, intelligence, dharma, profession
    "Moon":    [4, 11],                # Home, gains
    "Mars":    [3, 6, 11],             # Effort, conflicts, gains
    "Mercury": [2, 4, 5, 9, 10, 11],   # Speech, comforts, intellect, dharma, profession, gains
    "Jupiter": [2, 5, 9, 11],          # Wealth, children, dharma, gains
    "Venus":   [7],                    # Spouse, partnerships
    "Saturn":  [6, 8, 10, 12],         # Work, longevity, profession, expenses
    "Rahu":    [],                     # Acts via host nakshatra
    "Ketu":    [],                     # Acts via host nakshatra
}


# ════════════════════════════════════════════════════════════════════════
# KP RULING PLANETS (RP) — At any moment, 5 planets identified:
#   1. Lagna sign-lord
#   2. Lagna star-lord (nakshatra lord)
#   3. Moon sign-lord
#   4. Moon star-lord
#   5. Day-lord (weekday ruler)
# RP at moment of question/event is highly meaningful in KP
# ════════════════════════════════════════════════════════════════════════

KP_RULING_PLANETS_RULES: List[str] = [
    "Lagna sign-lord (Rashi-pati of ascending sign at moment)",
    "Lagna star-lord (nakshatra lord of ascending degree at moment)",
    "Moon sign-lord (Rashi-pati of Moon's sign at moment)",
    "Moon star-lord (nakshatra lord of Moon at moment)",
    "Day-lord (weekday ruler: Sun=Sunday, Moon=Monday, Mars=Tuesday, etc.)",
]


WEEKDAY_PLANET: Dict[int, str] = {
    0: "Moon", 1: "Mars", 2: "Mercury", 3: "Jupiter",
    4: "Venus", 5: "Saturn", 6: "Sun",
}


# ════════════════════════════════════════════════════════════════════════
# KP SIGNIFICATOR HIERARCHY
# ════════════════════════════════════════════════════════════════════════

KP_SIGNIFICATOR_HIERARCHY: Dict[str, str] = {
    "level_1_strongest": "Planet occupying the star (nakshatra) of a planet placed in target house",
    "level_2":            "Planet occupying the target house itself",
    "level_3":            "Planet occupying the star of the target house's lord",
    "level_4_weakest":   "Lord of the target house",
    "note":              "KP rule: Star-lord > Sub-lord > Sub-sub-lord in precision. Strongest significator combines star-lord pointing at house with sub-lord NOT denying it.",
}


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "kp":               "K.S. Krishnamurti, 'Krishnamurti Paddhati' (1971) — principles public-domain in India. Original Vimshottari math from BPHS (~6th c. CE).",
    "sub_lord":         "KP sub-lord algorithm: Vimshottari-year proportions applied within each nakshatra's 13°20' span. 9 sub-divisions per nakshatra → 243 sub-lord zones.",
    "ruling_planets":   "KP Ruling Planets doctrine: 5 RPs identify cosmic 'green light' at any moment for events to fruit.",
    "significator":     "KP significator hierarchy: Star-lord > Sub-lord > Sub-sub-lord. Star-lord 'points', sub-lord 'decides yes/no'.",
    "kp_lite_caveat":   "This engine implements KP-lite using Lahiri ayanamsha (engine default) and equal-house cusps from Lagna degree. Full KP uses Krishnamurti ayanamsha (~0.26° offset) and Placidus cusps. Boundary cases may differ ~5% from full KP software.",
}
