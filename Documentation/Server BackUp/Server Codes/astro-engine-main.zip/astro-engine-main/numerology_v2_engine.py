"""
numerology_v2_engine.py — Master aggregator for Numerology v2.

Public API:
    full_reading(name, dob, gender)              → everything in one call
    static_numbers(name, dob, gender)            → just static identity numbers
    time_cycles(dob, target_year, target_date)   → year/month/day/pinnacle/challenge
    karmic_layer(name, dob)                      → karmic debt + lessons + hidden passion
    compatibility(name_a, dob_a, name_b, dob_b)  → two-person match
"""

from typing import Dict, Any
from datetime import datetime

from numerology_v2 import (
    pythagorean_moolank, pythagorean_bhagyank, pythagorean_destiny,
    pythagorean_soul_urge, pythagorean_personality, pythagorean_birthday,
    pythagorean_maturity, pythagorean_cornerstone, pythagorean_capstone,
    pythagorean_first_vowel, chaldean_name,
    karmic_debt, karmic_lessons, hidden_passion,
    lo_shu_grid, kua_number,
)
from numerology_v2_cycles import (
    universal_year, personal_year, personal_month, personal_day,
    pinnacles, challenges, life_arc,
)
from numerology_v2_compatibility import numerology_compatibility


def static_numbers(name: str, dob: str, gender: str = "male") -> Dict[str, Any]:
    """All static identity numbers — Pythagorean + Chaldean + Lo Shu + Kua."""
    return {
        "pythagorean": {
            "moolank":       pythagorean_moolank(dob),
            "bhagyank":      pythagorean_bhagyank(dob),
            "destiny":       pythagorean_destiny(name),
            "soul_urge":     pythagorean_soul_urge(name),
            "personality":   pythagorean_personality(name),
            "birth_day":     pythagorean_birthday(dob),
            "maturity":      pythagorean_maturity(name, dob),
            "cornerstone":   pythagorean_cornerstone(name),
            "capstone":      pythagorean_capstone(name),
            "first_vowel":   pythagorean_first_vowel(name),
        },
        "chaldean": chaldean_name(name),
        "lo_shu":   lo_shu_grid(dob),
        "kua":      kua_number(dob, gender),
    }


def karmic_layer(name: str, dob: str) -> Dict[str, Any]:
    """All karmic indicators."""
    return {
        "karmic_debt":      karmic_debt(dob, name),
        "karmic_lessons":   karmic_lessons(name),
        "hidden_passion":   hidden_passion(name),
    }


def time_cycles(dob: str, target_year: int = None,
                target_month: int = None, target_date: str = None) -> Dict[str, Any]:
    """All time-cycle numbers + pinnacles + challenges + 15-year life arc."""
    if target_year is None:  target_year = datetime.now().year
    if target_month is None: target_month = datetime.now().month
    if target_date is None:  target_date = datetime.now().strftime("%Y-%m-%d")

    return {
        "universal_year":  {"year": target_year, "value": universal_year(target_year)},
        "personal_year":   personal_year(dob, target_year),
        "personal_month":  personal_month(dob, target_year, target_month),
        "personal_day":    personal_day(dob, target_date),
        "pinnacles":       pinnacles(dob),
        "challenges":      challenges(dob),
        "life_arc_15yr":   life_arc(dob, horizon_years=15),
    }


def full_reading(name: str, dob: str, gender: str = "male") -> Dict[str, Any]:
    """The complete Numerology v2 reading in one structured payload."""
    return {
        "metadata": {
            "name": name,
            "dob": dob,
            "gender": gender,
            "generated_at": datetime.now().isoformat(),
            "module_version": "numerology_v2",
        },
        "static_numbers": static_numbers(name, dob, gender),
        "karmic_layer":   karmic_layer(name, dob),
        "time_cycles":    time_cycles(dob),
    }


def compatibility(name_a: str, dob_a: str, name_b: str, dob_b: str) -> Dict[str, Any]:
    """Two-person numerological compatibility."""
    return numerology_compatibility(name_a, dob_a, name_b, dob_b)
