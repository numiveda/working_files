"""
vastu.py — Astro Vastu Computation Engine (v3 — refactored)

v3 CHANGES (from v2):
- Imports _extract_chart_essentials, _compute_house_lords, _afflicted_planets,
  _is_planet_safe_for_gemstone, _weakest_planet, get_chart from astro_helpers
- Imports PLANET_TO_DIRECTION, PLANET_TO_DEITY, HOUSE_TO_LIFE_AREA from astro_helpers
  (these constants are no longer imported from vastu_data — single source of truth)
- All output structures IDENTICAL to v2 — zero behavior change

Architecture:
- Accepts BirthInput (same schema as all other endpoints)
- Internally casts Vedic chart via dashaflow.cast_chart()
- Then applies Vastu rules personalized to native's chart

Sources cited per endpoint:
- Manasara Shilpa Shastra (~5th-7th c. CE)
- Mayamatam (~9th-12th c. CE)
- Brihat Samhita Ch. 52-57 (Varahamihira, ~550 CE)
- Vishvakarma Prakash (~10th c. CE)
- Vastu Purusha Mandala tradition
"""

from typing import Optional, Dict, List, Any

from astro_helpers import (
    extract_chart_essentials as _extract_chart_essentials,
    get_chart as _get_chart,
    PLANET_TO_DIRECTION,
    PLANET_TO_DEITY,
    HOUSE_TO_LIFE_AREA,
)

from vastu_data import (
    DIRECTIONS,
    VASTU_PURUSHA_MANDALA_81,
    MARMA_POINTS,
    ROOM_PLACEMENT,
    VASTU_DOSHAS,
    PLOT_SHAPES,
    SLOPE_ANALYSIS,
    ROAD_FRONTAGE,
    CONSTRUCTION_MUHURTA,
    BUSINESS_VASTU,
    VASTU_REMEDIES,
)


# ════════════════════════════════════════════════════════════════════════
# 1. MASTER PROFILE
# ════════════════════════════════════════════════════════════════════════

def full_vastu_profile(dob: str, time: str, lat: float, lon: float,
                       timezone: str = "Asia/Kolkata",
                       gender: str = "male") -> Dict[str, Any]:
    chart = _get_chart(dob, time, lat, lon, timezone)
    ch = _extract_chart_essentials(chart)

    return {
        "input": {"dob": dob, "time": time, "lat": lat, "lon": lon, "gender": gender},
        "chart_summary": {
            "lagna":           ch["lagna_sign"],
            "lagna_nakshatra": ch["lagna_nakshatra"],
            "moon_sign":       ch["moon_sign"],
            "moon_house":      ch["moon_house"],
            "atmakaraka":      ch["atmakaraka"],
            "amatyakaraka":    ch["amatyakaraka"],
            "current_md":      ch["current_md"],
            "current_ad":      ch["current_ad"],
        },
        "personal_directions":    personal_directions(ch),
        "room_placement_guide":   full_room_placement(ch),
        "vastu_purusha_mandala":  vastu_purusha_mandala_overview(),
        "marma_points":           list(MARMA_POINTS.items()),
        "applicable_doshas":      list(VASTU_DOSHAS.keys()),
        "remedies_catalog":       VASTU_REMEDIES,
        "construction_muhurta":   CONSTRUCTION_MUHURTA,
        "personal_focus_zones":   _personal_focus_zones(ch),
        "yantra_directions":      _personal_yantras(ch),
        "classical_sources": [
            "Manasara Shilpa Shastra",
            "Mayamatam",
            "Brihat Samhita Ch. 52-57",
            "Vishvakarma Prakash",
            "Vastu Purusha Mandala tradition",
        ],
    }


# ════════════════════════════════════════════════════════════════════════
# 2. PERSONAL DIRECTIONS
# ════════════════════════════════════════════════════════════════════════

def personal_directions(chart_essentials: Dict) -> Dict[str, Any]:
    out = {"directions": [], "classical_source": "Brihat Samhita Ch. 52 + Vastu-Jyotish synthesis"}

    for dir_name, dir_data in DIRECTIONS.items():
        if dir_name == "center":
            continue

        ruling_planet = dir_data.get("planet")
        planet_data = chart_essentials["planets"].get(ruling_planet, {}) if ruling_planet else {}

        entry = {
            "direction":         dir_name,
            "sanskrit":          dir_data["sanskrit"],
            "iast":              dir_data["iast"],
            "presiding_deity":   dir_data["deity"],
            "ruling_planet":     ruling_planet,
            "element":           dir_data["element"],
            "general_domain":    dir_data["domain"],
            "planet_in_house":   planet_data.get("house"),
            "planet_sign":       planet_data.get("sign"),
            "planet_dignity":    planet_data.get("dignity"),
            "planet_retrograde": planet_data.get("is_retrograde"),
            "planet_combust":    planet_data.get("is_combust"),
            "personal_emphasis": _personal_emphasis(chart_essentials, ruling_planet, planet_data),
        }
        out["directions"].append(entry)

    ak = chart_essentials.get("atmakaraka")
    if ak:
        out["atmakaraka_direction"] = PLANET_TO_DIRECTION.get(ak, "north")
        out["atmakaraka_note"] = f"Atmakaraka ({ak}) emphasizes the {out['atmakaraka_direction']} direction — primary soul-zone of the home"

    md = chart_essentials.get("current_md")
    if md:
        out["current_dasha_direction"] = PLANET_TO_DIRECTION.get(md)
        out["current_dasha_note"] = f"Current MD ({md}) emphasizes the {out['current_dasha_direction']} direction for this dasha period"

    return out


def _personal_emphasis(chart_essentials: Dict, planet: Optional[str], planet_data: Dict) -> str:
    if not planet:
        return "general direction — not chart-linked"
    house = planet_data.get("house")
    if not house:
        return f"{planet} placement not found in chart"

    life_area = HOUSE_TO_LIFE_AREA.get(house, "unknown")
    dignity = planet_data.get("dignity", "")
    note = f"{planet} in house {house} ({life_area})"
    if dignity:
        note += f", dignity: {dignity}"
    note += f" — governs this direction's expression"

    if planet_data.get("is_retrograde"):
        note += " | Retrograde — direction expression is internalized/delayed"
    if planet_data.get("is_combust"):
        note += " | Combust — direction expression is burnt/obscured"
    if house in (6, 8, 12):
        note += " | Dushthana placement — requires remediation"
    if dignity in ("debilitated", "great_enemy", "enemy"):
        note += f" | Weak dignity ({dignity}) — strengthen this direction"
    elif dignity in ("exalted", "own_sign", "moolatrikona", "great_friend"):
        note += f" | Strong dignity ({dignity}) — natural strength here"

    return note


# ════════════════════════════════════════════════════════════════════════
# 3. PLOT ANALYSIS
# ════════════════════════════════════════════════════════════════════════

def plot_analysis(shape: str, slope: str, road_facing: str, water_body: Optional[str] = None) -> Dict[str, Any]:
    shape_eval = PLOT_SHAPES.get(shape.lower().replace("-","_"), {"rating": "unknown", "score": 50, "note": "Provide standard shape descriptor"})
    slope_eval = SLOPE_ANALYSIS.get(slope.lower(), {"rating": "unknown", "score": 50, "effect": "Provide standard direction"})
    road_eval = ROAD_FRONTAGE.get(road_facing.lower().replace("-","_"), {"rating": "unknown", "score": 50, "effect": "Provide standard direction"})

    composite = (shape_eval["score"] + slope_eval["score"] + road_eval["score"]) / 3

    water_analysis = None
    if water_body:
        wb = water_body.lower()
        if wb in ("northeast", "north", "east"):
            water_analysis = {"placement": wb, "rating": "excellent", "note": "Water in NE/N/E sectors is highly auspicious — Varuna and Indra"}
        elif wb in ("southwest", "south"):
            water_analysis = {"placement": wb, "rating": "very_poor", "note": "Water in SW/S — strong dosha, drains household energy"}
        else:
            water_analysis = {"placement": wb, "rating": "acceptable", "note": "Acceptable but not ideal"}

    return {
        "input":               {"shape": shape, "slope": slope, "road_facing": road_facing, "water_body": water_body},
        "shape_analysis":      shape_eval,
        "slope_analysis":      slope_eval,
        "road_frontage":       road_eval,
        "water_body_analysis": water_analysis,
        "composite_score":     round(composite, 1),
        "composite_band":      _band(composite),
        "classical_source":    "Brihat Samhita Ch. 53 + Manasara Ch. 8 + Mayamatam 9",
    }


def _band(score: float) -> str:
    if score >= 85: return "excellent"
    if score >= 70: return "very_good"
    if score >= 55: return "acceptable"
    if score >= 40: return "needs_remediation"
    if score >= 25: return "poor"
    return "very_poor"


# ════════════════════════════════════════════════════════════════════════
# 4. ROOM PLACEMENT
# ════════════════════════════════════════════════════════════════════════

def full_room_placement(chart_essentials: Optional[Dict] = None) -> Dict[str, Any]:
    return {
        "room_matrix":      ROOM_PLACEMENT,
        "directions_legend":DIRECTIONS,
        "classical_source": "Manasara Ch. 33-37 + Mayamatam Ch. 9 + Vishvakarma Prakash Ch. 6-8",
    }


def room_placement_query(room: str) -> Dict[str, Any]:
    if room not in ROOM_PLACEMENT:
        return {"error": f"Unknown room: {room}", "available_rooms": list(ROOM_PLACEMENT.keys())}
    return {"room": room, **ROOM_PLACEMENT[room]}


# ════════════════════════════════════════════════════════════════════════
# 5. DOSHA DETECTION
# ════════════════════════════════════════════════════════════════════════

def detect_doshas(observations: List[str]) -> Dict[str, Any]:
    detected = []
    obs_lower = [o.lower().replace(" ","_").replace("-","_") for o in observations]

    dosha_triggers = {
        "ishana_dosha":  ["toilet_in_ne", "toilet_in_northeast", "kitchen_in_ne", "kitchen_in_northeast", "septic_in_ne", "heavy_storage_ne", "staircase_in_ne"],
        "agni_dosha":    ["toilet_in_se", "toilet_in_southeast", "water_tank_se", "master_bedroom_se", "underground_water_se"],
        "yama_dosha":    ["main_entrance_south", "main_entrance_in_south", "pooja_in_south", "bedroom_of_head_south"],
        "nairutya_dosha":["entrance_sw", "entrance_southwest", "no_weight_sw", "lightweight_sw", "open_sw_corner"],
        "varuna_dosha":  ["toilet_west_unbalanced", "septic_in_west_inappropriate"],
        "vayu_dosha":    ["nw_blocked", "no_window_nw", "heavy_locked_storage_nw"],
        "brahma_dosha":  ["staircase_at_center", "pillar_at_center", "toilet_at_center", "heavy_furniture_center", "kitchen_at_center"],
        "plot_shape_dosha":["triangular_plot", "irregular_plot", "ne_cut_plot"],
        "road_thrust_dosha":["road_dead_ending_at_plot", "t_junction_facing_entrance", "vithi_shoola"],
    }

    for dosha_key, triggers in dosha_triggers.items():
        if any(t in obs_lower for t in triggers):
            dosha = VASTU_DOSHAS[dosha_key].copy()
            dosha["dosha_key"] = dosha_key
            detected.append(dosha)

    return {
        "input_observations": observations,
        "detected_count":     len(detected),
        "doshas":             detected,
        "all_known_doshas":   list(VASTU_DOSHAS.keys()),
        "classical_source":   "Composite — see individual dosha entries",
    }


# ════════════════════════════════════════════════════════════════════════
# 6. REMEDIES
# ════════════════════════════════════════════════════════════════════════

def remedies_catalog(for_dosha: Optional[str] = None) -> Dict[str, Any]:
    if for_dosha and for_dosha in VASTU_DOSHAS:
        return {
            "for_dosha":         for_dosha,
            "dosha_details":     VASTU_DOSHAS[for_dosha],
            "general_remedies":  VASTU_REMEDIES,
            "classical_source":  "Composite Vastu remedial tradition",
        }
    return {
        "all_remedies":      VASTU_REMEDIES,
        "all_doshas":        VASTU_DOSHAS,
        "classical_source":  "Composite Vastu remedial tradition",
    }


# ════════════════════════════════════════════════════════════════════════
# 7. MARMA POINTS + MANDALA
# ════════════════════════════════════════════════════════════════════════

def vastu_purusha_mandala_overview() -> Dict[str, Any]:
    return {
        "mandala_grid_81":   VASTU_PURUSHA_MANDALA_81,
        "marma_points":      MARMA_POINTS,
        "interpretation":    {
            "head":         "Northeast — sacred, most subtle energy",
            "feet":         "Southwest — heaviest, anchoring energy",
            "right_hand":   "Southeast — fire, transformation",
            "left_hand":    "Northwest — air, movement",
            "navel":        "Center (Brahmasthana) — most sacred, must stay open",
        },
        "classical_source":  "Manasara Ch. 7-9 + Vastu Purusha tradition",
    }


# ════════════════════════════════════════════════════════════════════════
# 8. CONSTRUCTION MUHURTA
# ════════════════════════════════════════════════════════════════════════

def construction_muhurta(chart_essentials: Optional[Dict] = None) -> Dict[str, Any]:
    out = {
        "favorable_months":       CONSTRUCTION_MUHURTA["favorable_months"],
        "unfavorable_months":     CONSTRUCTION_MUHURTA["unfavorable_months"],
        "favorable_nakshatras":   CONSTRUCTION_MUHURTA["favorable_nakshatras"],
        "favorable_weekdays":     CONSTRUCTION_MUHURTA["favorable_weekdays"],
        "unfavorable_weekdays":   CONSTRUCTION_MUHURTA["unfavorable_weekdays"],
        "favorable_tithis":       CONSTRUCTION_MUHURTA["favorable_tithis"],
        "unfavorable_tithis":     CONSTRUCTION_MUHURTA["unfavorable_tithis"],
        "ceremonies":             CONSTRUCTION_MUHURTA["key_ceremonies"],
        "classical_source":       CONSTRUCTION_MUHURTA["source"],
    }
    if chart_essentials:
        md = chart_essentials.get("current_md")
        if md:
            out["personal_note"] = f"Current MD is {md}. Avoid construction muhurta when {md} is afflicted by transit."
    return out


# ════════════════════════════════════════════════════════════════════════
# 9. BUSINESS VASTU
# ════════════════════════════════════════════════════════════════════════

def business_vastu(business_type: str = "office_corporate") -> Dict[str, Any]:
    if business_type not in BUSINESS_VASTU:
        return {
            "error":             f"Unknown business type: {business_type}",
            "available_types":   list(BUSINESS_VASTU.keys()),
        }
    return {
        "business_type":     business_type,
        "configuration":     BUSINESS_VASTU[business_type],
        "general_doshas":    {k: v for k, v in VASTU_DOSHAS.items() if v["severity"] in ("high", "very_high")},
        "classical_source":  BUSINESS_VASTU[business_type]["source"],
    }


# ════════════════════════════════════════════════════════════════════════
# 10. YANTRA / DEITY PLACEMENT
# ════════════════════════════════════════════════════════════════════════

def _personal_yantras(chart_essentials: Dict) -> Dict[str, Any]:
    afflicted = []
    for planet_name, planet_data in chart_essentials.get("planets", {}).items():
        house = planet_data.get("house")
        retro = planet_data.get("is_retrograde", False)
        combust = planet_data.get("is_combust", False)
        dignity = planet_data.get("dignity", "")
        is_afflicted = (
            house in (6, 8, 12)
            or retro
            or combust
            or dignity in ("debilitated", "great_enemy", "enemy")
        )
        if is_afflicted:
            direction = PLANET_TO_DIRECTION.get(planet_name)
            deity = PLANET_TO_DEITY.get(planet_name)
            reasons = []
            if house in (6, 8, 12):
                reasons.append(f"dushthana house {house}")
            if retro:
                reasons.append("retrograde")
            if combust:
                reasons.append("combust")
            if dignity in ("debilitated", "great_enemy", "enemy"):
                reasons.append(f"{dignity} dignity")
            afflicted.append({
                "planet":      planet_name,
                "house":       house,
                "dignity":     dignity,
                "retrograde":  retro,
                "combust":     combust,
                "direction":   direction,
                "deity":       deity,
                "yantra":      f"{planet_name} Yantra in {direction} direction",
                "afflictions": reasons,
                "remedy_note": f"{planet_name} is afflicted ({', '.join(reasons)}). Strengthen {direction} direction with {planet_name} yantra and {deity} worship.",
            })

    ak = chart_essentials.get("atmakaraka")
    ak_direction = PLANET_TO_DIRECTION.get(ak) if ak else None

    return {
        "atmakaraka":              ak,
        "atmakaraka_direction":    ak_direction,
        "atmakaraka_yantra_note":  f"Atmakaraka ({ak}) — place {ak} yantra in {ak_direction} direction; soul's primary remedy" if ak else None,
        "afflicted_planet_yantras":afflicted,
        "general_yantras":         VASTU_REMEDIES["yantras"],
        "classical_source":        "Vastu-Jyotish synthesis (Brihat Samhita + Lal Kitab cross-reference)",
    }


def yantra_directions(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = _get_chart(dob, time, lat, lon, timezone)
    ch = _extract_chart_essentials(chart)
    return _personal_yantras(ch)


# ════════════════════════════════════════════════════════════════════════
# 11. PERSONAL FOCUS ZONES
# ════════════════════════════════════════════════════════════════════════

def _personal_focus_zones(chart_essentials: Dict) -> Dict[str, Any]:
    ak = chart_essentials.get("atmakaraka")
    md = chart_essentials.get("current_md")

    zones = []
    seen_directions = set()

    if ak:
        ak_dir = PLANET_TO_DIRECTION.get(ak, "northeast")
        zones.append({
            "rank":      1,
            "direction": ak_dir,
            "reason":    f"Atmakaraka ({ak}) — soul-zone for entire incarnation",
        })
        seen_directions.add(ak_dir)

    if md:
        md_dir = PLANET_TO_DIRECTION.get(md)
        if md_dir and md_dir not in seen_directions:
            zones.append({
                "rank":      len(zones) + 1,
                "direction": md_dir,
                "reason":    f"Current MD ({md}) — emphasis for this dasha period",
            })
            seen_directions.add(md_dir)

    if "northeast" not in seen_directions:
        zones.append({
            "rank":      len(zones) + 1,
            "direction": "northeast",
            "reason":    "Ishana — universal sacred direction; always reinforce",
        })

    return {
        "primary_focus_zones":  zones,
        "classical_source":     "Synthesis of Vastu + Jaimini Atmakaraka + Vimshottari Dasha lord direction",
    }


# ════════════════════════════════════════════════════════════════════════
# 12. CHART-INTEGRATED WRAPPERS (called by FastAPI endpoints)
# ════════════════════════════════════════════════════════════════════════

def personal_directions_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = _get_chart(dob, time, lat, lon, timezone)
    ch = _extract_chart_essentials(chart)
    return personal_directions(ch)


def room_placement_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = _get_chart(dob, time, lat, lon, timezone)
    ch = _extract_chart_essentials(chart)
    return full_room_placement(ch)


def doshas_endpoint(observations: List[str]) -> Dict[str, Any]:
    return detect_doshas(observations)


def remedies_endpoint(for_dosha: Optional[str] = None) -> Dict[str, Any]:
    return remedies_catalog(for_dosha)


def marma_points_endpoint() -> Dict[str, Any]:
    return vastu_purusha_mandala_overview()


def auspicious_construction_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    chart = _get_chart(dob, time, lat, lon, timezone)
    ch = _extract_chart_essentials(chart)
    return construction_muhurta(ch)


def business_vastu_endpoint(business_type: str = "office_corporate") -> Dict[str, Any]:
    return business_vastu(business_type)
