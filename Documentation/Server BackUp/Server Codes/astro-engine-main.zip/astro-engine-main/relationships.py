"""
relationships.py — numiVeda Kaaliyo Astro Engine — Module F1a (Non-Marriage Relationships)

Three endpoints for two-chart compatibility OUTSIDE marriage frame:
    handle_friendship    — Emotional + intellectual rapport (3H, 11H; Mercury/Moon/Venus)
    handle_mentor        — Guru-shishya bond (5H/9H; Jupiter, Atmakaraka resonance)
    handle_family        — Parent/sibling/child compat (4H/9H/3H/5H; subtype-aware)

Design principles (per HANDOVER_v4 carry-forward):
    P1 — Swiss Ephemeris is the only astronomy source. F1a does ZERO astronomy;
         all values read from cast_chart() pre-computation.
    P2 — Reuse existing endpoints. Koot scorers are imported from compatibility.py;
         no duplication.
    P3 — Single source of truth. RELATIONSHIP_KARAKAS is read from compatibility_data
         and extended LOCALLY (no mutation of the source module's dict).
    P6 — Cross-validation. Tara/Yoni/Gana/Graha Maitri subscores must equal those
         returned by /astro/compatibility for the same pair (same private fns).

Public API (mounted by main.py via aliased import):
    handle_friendship(person1, person2, role1=None, role2=None) -> dict
    handle_mentor(person1, person2, role1=None, role2=None) -> dict
    handle_family(person1, person2, role1=None, role2=None, subtype=None) -> dict

Author: Claude (F1a, 2026-05-17)
"""

from typing import Dict, List, Optional, Any, Tuple
from copy import deepcopy

# ════════════════════════════════════════════════════════════════════════
# IMPORT-TIME SANITY: load all required helpers from compatibility.py
# If any is missing, fail LOUDLY at module import (not at request time).
# ════════════════════════════════════════════════════════════════════════

try:
    from compatibility import (
        _build_person,
        _sign_index,
        _house_from_sign,
        _planet_relation,
        _tara_kuta,
        _yoni_kuta,
        _graha_maitri_kuta,
        _gana_kuta,
    )
except ImportError as e:
    raise ImportError(
        f"F1a (relationships.py) cannot load required helpers from compatibility.py: {e}. "
        f"compatibility.py may have been refactored; F1a needs the underscored koot "
        f"scorers (_tara_kuta, _yoni_kuta, _gana_kuta, _graha_maitri_kuta) and core "
        f"chart builders (_build_person, _sign_index, _house_from_sign, _planet_relation)."
    )

from compatibility_data import (
    RELATIONSHIP_KARAKAS as _SRC_RELATIONSHIP_KARAKAS,
    CLASSICAL_CITATIONS,
)

from astro_helpers import SIGN_TO_LORD, SIGNS_ORDER


# ════════════════════════════════════════════════════════════════════════
# LOCAL EXTENDED KARAKA DICT (does NOT mutate source module's dict)
# ════════════════════════════════════════════════════════════════════════

RELATIONSHIP_KARAKAS = deepcopy(_SRC_RELATIONSHIP_KARAKAS)
RELATIONSHIP_KARAKAS["mentor"] = {
    "primary_house": "5th (disciple from guru's lagna) / 9th (guru from disciple's lagna)",
    "primary_karaka": "Jupiter (Guru karaka)",
    "secondary_karaka": "Atmakaraka (soul-resonance)",
    "secondary_house": "10th (dharmic vocation)",
}
RELATIONSHIP_KARAKAS["family"] = {
    "primary_house": "4th (mother), 9th/10th (father), 3rd (siblings), 5th (children)",
    "primary_karakas_by_subtype": {
        "parent-child": "Matrikaraka (mother), Pitrukaraka (father), Putrakaraka (child)",
        "sibling": "Bhratrikaraka (siblings)",
        "extended": "All Jaimini karakas considered",
    },
    "secondary_house": "8th (joint karma, inheritance), 12th (ancestral roots)",
}


# ════════════════════════════════════════════════════════════════════════
# F1a-LOCAL CLASSICAL CITATIONS
# Subset existing + add F1a-specific
# ════════════════════════════════════════════════════════════════════════

F1A_CITATIONS = {
    "friendship": [
        CLASSICAL_CITATIONS.get("ashtakoot", "Traditional 8-fold Kuta system"),
        "BPHS Ch. 7 — 3rd and 11th house significations (peers, gains, intellectual exchange)",
        "Jataka Parijata Ch. 7 — Mercury-Moon harmony for rapport",
        "Saravali Ch. 30 — house lords cross-aspect for social bonds",
    ],
    "mentor": [
        CLASSICAL_CITATIONS.get("navamsha", "BPHS Ch. 8 (Vargas)"),
        "Brihat Jataka Ch. 4 — Atmakaraka as soul-significator; AK cross-resonance indicates karmic recognition",
        "BPHS Ch. 19 — Raja Yogas via 5th/9th house lords; 9H is dharma, 5H is purva-punya",
        "Phaladeepika Ch. 9 — 9th house and Jupiter for Guru / Dharma",
        "Jataka Parijata Ch. 4 — D9 (Navamsha) as the dharmic-purpose chart",
    ],
    "family": [
        "Saravali Ch. 30 — sibling, parent, and progeny significations",
        "BPHS Ch. 7 — 4th (mother), 9th-10th (father), 3rd (siblings), 5th (children)",
        "Brihat Jataka Ch. 11 — Jaimini karakas for family relations (Matri/Pitri/Bhratri/Putra)",
        "Phaladeepika Ch. 4 — house-lord placement for familial harmony",
    ],
}


# ════════════════════════════════════════════════════════════════════════
# CORE HELPERS
# ════════════════════════════════════════════════════════════════════════

def _composite_verdict(score: float, max_score: float = 100.0) -> str:
    """
    Normalize score to 0-100 if needed and return verdict label.
    Thresholds chosen to match classical Ashtakoot interpretation bands:
      36 pts (max) = excellent; 24+ very good; 18+ acceptable; <18 challenging.
    Scaled to /100: 80+ EXCELLENT, 65+ STRONG, 50+ MIXED, 35+ CHALLENGING, else DIFFICULT.
    """
    pct = (score / max_score) * 100 if max_score else 0.0
    if pct >= 80:
        return "EXCELLENT"
    if pct >= 65:
        return "STRONG"
    if pct >= 50:
        return "MIXED"
    if pct >= 35:
        return "CHALLENGING"
    return "DIFFICULT"


def _safe_essentials_summary(essentials: Dict[str, Any]) -> Dict[str, Any]:
    """Compact public summary of person essentials for response."""
    return {
        "lagna_sign":       essentials.get("lagna_sign"),
        "moon_sign":        essentials.get("moon_sign"),
        "moon_nakshatra":   essentials.get("moon_nakshatra"),
        "moon_nakshatra_lord": essentials.get("moon_nakshatra_lord"),
        "sun_sign":         essentials.get("sun_sign"),
        "lagna_lord":      essentials.get("lagna_lord"),  # ── U10 fix-2: lagna_lord rename ──
    }


def _planet_house_in_other_chart(p_chart: Dict[str, Any],
                                   other_chart: Dict[str, Any],
                                   planet: str) -> Optional[int]:
    """
    Where does `planet` from p_chart sit (by sign) in other_chart? Return house number 1-12.
    Used for cross-aspect analysis ("p1's Jupiter falls in p2's 5th house").
    """
    try:
        planet_sign = p_chart["planets"][planet]["sign"]
        other_lagna = other_chart["lagna"]["sign"]
        return _house_from_sign(planet_sign, other_lagna)
    except (KeyError, TypeError):
        return None


def _score_house_placement(house: Optional[int]) -> float:
    """
    Score 0-2 for a house placement based on classical interpretation:
      1, 5, 9 (trines) and 10, 11 → 2.0 (auspicious)
      3, 4, 7   → 1.0 (mixed/active)
      2         → 0.5 (neutral)
      6, 8, 12  → 0.0 (challenging)
    """
    if house is None:
        return 0.0
    if house in (1, 5, 9, 10, 11):
        return 2.0
    if house in (3, 4, 7):
        return 1.0
    if house == 2:
        return 0.5
    return 0.0


# ════════════════════════════════════════════════════════════════════════
# FRIENDSHIP
# ════════════════════════════════════════════════════════════════════════

def _friendship_moon_synastry(e1: Dict[str, Any], e2: Dict[str, Any]) -> Dict[str, Any]:
    """
    Moon-sign relation + moon-nakshatra-lord planetary friendship.
    Max 10 points: 5 for moon-sign relation, 5 for nakshatra-lord relation.
    """
    p1_moon = e1.get("moon_sign")
    p2_moon = e2.get("moon_sign")
    p1_nl = e1.get("moon_nakshatra_lord")
    p2_nl = e2.get("moon_nakshatra_lord")

    # Moon-sign relation: same sign = strong; trine = strong; 2-12 axis = supportive;
    # 6-8 axis = friction; opposite = polarizing-but-bonding
    same = (p1_moon == p2_moon)
    sign_distance = None
    try:
        i1 = SIGNS_ORDER.index(p1_moon)
        i2 = SIGNS_ORDER.index(p2_moon)
        sign_distance = ((i2 - i1) % 12) + 1  # 1 = same, 7 = opposite
    except (ValueError, TypeError):
        sign_distance = None

    if same:
        sign_score = 5.0
        sign_note = "Same Moon sign — deep emotional rapport"
    elif sign_distance in (5, 9):
        sign_score = 4.5
        sign_note = "Trinal Moon-sign relation — natural emotional harmony"
    elif sign_distance in (3, 11):
        sign_score = 3.5
        sign_note = "Supportive 3-11 Moon-sign axis — mutual stimulation"
    elif sign_distance == 7:
        sign_score = 3.0
        sign_note = "Opposite Moon signs — polarizing but bonding"
    elif sign_distance in (6, 8):
        sign_score = 1.5
        sign_note = "6-8 Moon-sign axis — emotional friction likely"
    elif sign_distance is None:
        sign_score = 0.0
        sign_note = "Moon-sign data incomplete"
    else:
        sign_score = 2.5
        sign_note = "Neutral Moon-sign relation"

    # Nakshatra-lord planetary friendship
    if p1_nl and p2_nl:
        rel = _planet_relation(p1_nl, p2_nl)
        if rel == "friend":
            nl_score = 5.0
            nl_note = f"Nakshatra lords ({p1_nl} ↔ {p2_nl}) are mutual friends — shared instincts"
        elif rel == "neutral":
            nl_score = 2.5
            nl_note = f"Nakshatra lords ({p1_nl} ↔ {p2_nl}) are neutral — workable"
        else:
            nl_score = 0.5
            nl_note = f"Nakshatra lords ({p1_nl} ↔ {p2_nl}) are enemies — instinctual friction"
    else:
        nl_score = 0.0
        nl_note = "Nakshatra lord data incomplete"

    return {
        "moon_sign_distance":  sign_distance,
        "moon_sign_score":     sign_score,
        "moon_sign_note":      sign_note,
        "nakshatra_lord_score": nl_score,
        "nakshatra_lord_note":  nl_note,
        "subtotal":            sign_score + nl_score,
        "max":                 10.0,
    }


def _friendship_house_overlay(p1_chart, p2_chart) -> Dict[str, Any]:
    """
    For each direction, locate the 3rd-lord and 11th-lord of one chart in the other.
    Max 10 points: 4 placements scored 0-2 each + small bonus = capped at 10.
    """
    def lord_of_house_n(chart, n):
        try:
            lagna = chart["lagna"]["sign"]
            idx = (_sign_index(lagna) + (n - 1)) % 12
            sign = SIGNS_ORDER[idx]
            return SIGN_TO_LORD.get(sign), sign
        except (KeyError, TypeError):
            return None, None

    p1_3lord, p1_3sign = lord_of_house_n(p1_chart, 3)
    p1_11lord, p1_11sign = lord_of_house_n(p1_chart, 11)
    p2_3lord, p2_3sign = lord_of_house_n(p2_chart, 3)
    p2_11lord, p2_11sign = lord_of_house_n(p2_chart, 11)

    placements = []

    if p1_3lord:
        h = _planet_house_in_other_chart(p1_chart, p2_chart, p1_3lord)
        placements.append(("p1_3lord_in_p2", p1_3lord, h, _score_house_placement(h)))
    if p1_11lord:
        h = _planet_house_in_other_chart(p1_chart, p2_chart, p1_11lord)
        placements.append(("p1_11lord_in_p2", p1_11lord, h, _score_house_placement(h)))
    if p2_3lord:
        h = _planet_house_in_other_chart(p2_chart, p1_chart, p2_3lord)
        placements.append(("p2_3lord_in_p1", p2_3lord, h, _score_house_placement(h)))
    if p2_11lord:
        h = _planet_house_in_other_chart(p2_chart, p1_chart, p2_11lord)
        placements.append(("p2_11lord_in_p1", p2_11lord, h, _score_house_placement(h)))

    raw_sum = sum(p[3] for p in placements)
    # 4 placements × 2 pts max = 8; allow 2-pt headroom for bonuses
    placement_details = [
        {"direction": d, "planet": pl, "lands_in_house": h, "score": s}
        for (d, pl, h, s) in placements
    ]

    bonus = 0.0
    bonus_notes = []
    # Bonus: if p1's Moon falls in p2's 11th house OR vice versa
    p1_moon_in_p2 = _planet_house_in_other_chart(p1_chart, p2_chart, "Moon")
    p2_moon_in_p1 = _planet_house_in_other_chart(p2_chart, p1_chart, "Moon")
    if p1_moon_in_p2 == 11:
        bonus += 1.0
        bonus_notes.append("p1's Moon falls in p2's 11th house — classical friend signature")
    if p2_moon_in_p1 == 11:
        bonus += 1.0
        bonus_notes.append("p2's Moon falls in p1's 11th house — classical friend signature")

    total = min(raw_sum + bonus, 10.0)

    return {
        "placements":     placement_details,
        "p1_3rd_lord":    p1_3lord,
        "p1_11th_lord":   p1_11lord,
        "p2_3rd_lord":    p2_3lord,
        "p2_11th_lord":   p2_11lord,
        "bonus":          bonus,
        "bonus_notes":    bonus_notes,
        "subtotal":       round(total, 2),
        "max":            10.0,
    }


def _friendship_mercury_moon_cross(p1_chart, p2_chart) -> Dict[str, Any]:
    """
    Where do p2's Mercury (intellect) and Moon (emotion) land in p1's chart, and vice versa.
    Max 10 points: 4 placements × ~2 each, capped at 10.
    """
    placements = []
    for planet in ("Mercury", "Moon"):
        h_a = _planet_house_in_other_chart(p1_chart, p2_chart, planet)
        h_b = _planet_house_in_other_chart(p2_chart, p1_chart, planet)
        placements.append({
            "planet": planet,
            "p1's_planet_in_p2_house": h_a,
            "p1_score": _score_house_placement(h_a),
            "p2's_planet_in_p1_house": h_b,
            "p2_score": _score_house_placement(h_b),
        })

    subtotal = sum(p["p1_score"] + p["p2_score"] for p in placements)
    subtotal = min(subtotal, 10.0)
    return {
        "details":  placements,
        "subtotal": round(subtotal, 2),
        "max":      10.0,
    }


def handle_friendship(person1: Dict[str, Any],
                      person2: Dict[str, Any],
                      role1: Optional[str] = None,
                      role2: Optional[str] = None) -> Dict[str, Any]:
    """
    F1a Endpoint: Friendship compatibility — emotional + intellectual rapport.

    Frame: 3H (peers, courage, communication) + 11H (gains, friends).
    Karakas: Mercury (intellect), Moon (emotion), Venus (affection).

    Streams: koot_scores (Tara/Yoni/Gana/Graha Maitri, max 18, w=0.40)
             moon_synastry (max 10, w=0.20)
             house_overlay (3H/11H lords cross-placement, max 10, w=0.25)
             mercury_moon_cross (max 10, w=0.15)

    Composite normalized to 0-100.
    """
    c1, e1 = _build_person(person1)
    c2, e2 = _build_person(person2)

    p1_nak = e1.get("moon_nakshatra")
    p2_nak = e2.get("moon_nakshatra")
    p1_moon = e1.get("moon_sign")
    p2_moon = e2.get("moon_sign")

    if not (p1_nak and p2_nak and p1_moon and p2_moon):
        return {
            "error": "Could not extract Moon nakshatra/sign for both natives",
            "citations": F1A_CITATIONS["friendship"],
        }

    # ─── Stream 1: Koot scores (subset: tara, yoni, gana, graha_maitri) ───
    tara  = _tara_kuta(p1_nak, p2_nak)
    yoni  = _yoni_kuta(p1_nak, p2_nak)
    gana  = _gana_kuta(p1_nak, p2_nak)
    gmait = _graha_maitri_kuta(p1_moon, p2_moon)

    koot_subtotal = (
        float(tara.get("score", 0))
        + float(yoni.get("score", 0))
        + float(gana.get("score", 0))
        + float(gmait.get("score", 0))
    )
    koot_max = 18.0  # 3 + 4 + 6 + 5

    # ─── Stream 2: Moon synastry ───
    moon_syn = _friendship_moon_synastry(e1, e2)

    # ─── Stream 3: House overlay (3H/11H lords) ───
    overlay = _friendship_house_overlay(c1, c2)

    # ─── Stream 4: Mercury+Moon cross ───
    mer_moon = _friendship_mercury_moon_cross(c1, c2)

    # ─── Composite (weighted) ───
    composite_score = (
        (koot_subtotal  / koot_max)            * 0.40 * 100
        + (moon_syn["subtotal"] / 10.0)        * 0.20 * 100
        + (overlay["subtotal"]  / 10.0)        * 0.25 * 100
        + (mer_moon["subtotal"] / 10.0)        * 0.15 * 100
    )
    verdict = _composite_verdict(composite_score, 100.0)

    # ─── Headlines ───
    strengths = []
    frictions = []
    if koot_subtotal / koot_max >= 0.7:
        strengths.append(f"Strong koot fit — {koot_subtotal:.1f}/{koot_max} on temperament/instinct/intellect dimensions")
    elif koot_subtotal / koot_max < 0.4:
        frictions.append(f"Weak koot fit — {koot_subtotal:.1f}/{koot_max}; temperamental differences may surface")
    if moon_syn["subtotal"] >= 7.5:
        strengths.append(moon_syn["moon_sign_note"])
    elif moon_syn["subtotal"] < 4:
        frictions.append(moon_syn["moon_sign_note"])
    if overlay["bonus"] > 0:
        strengths.extend(overlay["bonus_notes"])

    deeper = (
        f"This friendship reads as {verdict.lower()}: koot-level "
        f"{'harmony' if koot_subtotal/koot_max >= 0.55 else 'tension'} combined with "
        f"{'supportive' if overlay['subtotal'] >= 5 else 'mixed'} house-lord exchange. "
        f"Mercury-Moon cross-placement contributed {mer_moon['subtotal']:.1f}/10."
    )

    return {
        "success":             True,
        "relationship_type":   "friendship",
        "person1_role":        role1,
        "person2_role":        role2,
        "person1_essentials":  _safe_essentials_summary(e1),
        "person2_essentials":  _safe_essentials_summary(e2),
        "evidence_streams": {
            "koot_scores": {
                "tara":         tara,
                "yoni":         yoni,
                "gana":         gana,
                "graha_maitri": gmait,
                "subtotal":     round(koot_subtotal, 2),
                "max":          koot_max,
                "note":         "Varna/Vashya/Bhakoot/Nadi intentionally excluded — marriage-specific"
            },
            "moon_synastry":       moon_syn,
            "house_overlay":       overlay,
            "mercury_moon_cross":  mer_moon,
        },
        "composite": {
            "score":               round(composite_score, 1),
            "max":                 100.0,
            "verdict":             verdict,
            "key_strengths":       strengths,
            "key_friction_points": frictions,
            "deeper_pattern":      deeper,
        },
        "classical_sources": F1A_CITATIONS["friendship"],
        "karakas_consulted": RELATIONSHIP_KARAKAS["friendship"],
    }


# ════════════════════════════════════════════════════════════════════════
# MENTOR
# ════════════════════════════════════════════════════════════════════════

def _mentor_jupiter_cross(c1, c2) -> Dict[str, Any]:
    """
    Where does each person's Jupiter fall in the other's chart.
    Max 10 points: 2 placements × 5 each (5H/9H/10H = 5; 1H/11H = 4; others scaled).
    """
    def score_jup(h):
        if h is None:
            return 0.0
        if h in (5, 9, 10):
            return 5.0
        if h in (1, 11):
            return 4.0
        if h in (4, 7):
            return 2.5
        if h in (2, 3):
            return 1.5
        return 0.5  # 6, 8, 12

    p1_jup_in_p2 = _planet_house_in_other_chart(c1, c2, "Jupiter")
    p2_jup_in_p1 = _planet_house_in_other_chart(c2, c1, "Jupiter")
    s1 = score_jup(p1_jup_in_p2)
    s2 = score_jup(p2_jup_in_p1)

    notes = []
    if p1_jup_in_p2 in (5, 9):
        notes.append(f"p1's Jupiter in p2's {p1_jup_in_p2}H — classical guru-shishya signature (p1 elevates p2)")
    if p2_jup_in_p1 in (5, 9):
        notes.append(f"p2's Jupiter in p1's {p2_jup_in_p1}H — classical guru-shishya signature (p2 elevates p1)")

    return {
        "p1_jupiter_in_p2_house": p1_jup_in_p2,
        "p1_jupiter_score":        s1,
        "p2_jupiter_in_p1_house":  p2_jup_in_p1,
        "p2_jupiter_score":        s2,
        "notes":                   notes,
        "subtotal":                round(min(s1 + s2, 10.0), 2),
        "max":                     10.0,
    }


def _mentor_karaka_resonance(c1, c2) -> Dict[str, Any]:
    """
    Atmakaraka and Amatyakaraka cross-placement.
    Max 10 points: AK cross (max 6) + AmK cross (max 4).
    AK in 1/5/9 of other chart = soul-recognition signature (top score).
    """
    def get_karaka_planet(chart, name):
        try:
            return chart["jaimini_karakas"][name]["planet"]
        except (KeyError, TypeError):
            return None

    p1_ak  = get_karaka_planet(c1, "Atmakaraka")
    p2_ak  = get_karaka_planet(c2, "Atmakaraka")
    p1_amk = get_karaka_planet(c1, "Amatyakaraka")
    p2_amk = get_karaka_planet(c2, "Amatyakaraka")

    def score_ak(h):
        if h is None: return 0.0
        if h in (1, 5, 9):  return 3.0
        if h in (10, 11):   return 2.0
        if h in (4, 7):     return 1.0
        return 0.5

    def score_amk(h):
        if h is None: return 0.0
        if h in (10, 11):  return 2.0
        if h in (1, 5, 9): return 2.0
        if h in (2, 6):    return 1.0
        return 0.5

    p1_ak_in_p2  = _planet_house_in_other_chart(c1, c2, p1_ak) if p1_ak else None
    p2_ak_in_p1  = _planet_house_in_other_chart(c2, c1, p2_ak) if p2_ak else None
    p1_amk_in_p2 = _planet_house_in_other_chart(c1, c2, p1_amk) if p1_amk else None
    p2_amk_in_p1 = _planet_house_in_other_chart(c2, c1, p2_amk) if p2_amk else None

    s_ak  = score_ak(p1_ak_in_p2) + score_ak(p2_ak_in_p1)
    s_amk = score_amk(p1_amk_in_p2) + score_amk(p2_amk_in_p1)

    notes = []
    if p1_ak_in_p2 in (1, 5, 9):
        notes.append(f"p1's Atmakaraka ({p1_ak}) in p2's {p1_ak_in_p2}H — karmic soul-recognition")
    if p2_ak_in_p1 in (1, 5, 9):
        notes.append(f"p2's Atmakaraka ({p2_ak}) in p1's {p2_ak_in_p1}H — karmic soul-recognition")
    same_ak = (p1_ak == p2_ak) if (p1_ak and p2_ak) else False
    if same_ak:
        notes.append(f"Both natives share Atmakaraka ({p1_ak}) — same soul-mission archetype")

    total = min(s_ak + s_amk, 10.0)

    return {
        "p1_atmakaraka":              p1_ak,
        "p1_atmakaraka_in_p2_house":  p1_ak_in_p2,
        "p2_atmakaraka":              p2_ak,
        "p2_atmakaraka_in_p1_house":  p2_ak_in_p1,
        "p1_amatyakaraka":            p1_amk,
        "p1_amatyakaraka_in_p2_house": p1_amk_in_p2,
        "p2_amatyakaraka":            p2_amk,
        "p2_amatyakaraka_in_p1_house": p2_amk_in_p1,
        "shared_atmakaraka":          same_ak,
        "notes":                      notes,
        "ak_subscore":                round(s_ak, 2),
        "amk_subscore":               round(s_amk, 2),
        "subtotal":                   round(total, 2),
        "max":                        10.0,
    }


def _mentor_dharma_overlay(c1, c2) -> Dict[str, Any]:
    """
    5th-lord and 9th-lord cross-placement + D9 (Navamsha) lagna match.
    Max 10 points: 4 placements × 2 + D9 bonus.
    """
    def lord_of_house_n(chart, n):
        try:
            lagna = chart["lagna"]["sign"]
            idx = (_sign_index(lagna) + (n - 1)) % 12
            sign = SIGNS_ORDER[idx]
            return SIGN_TO_LORD.get(sign)
        except (KeyError, TypeError):
            return None

    p1_5l = lord_of_house_n(c1, 5)
    p1_9l = lord_of_house_n(c1, 9)
    p2_5l = lord_of_house_n(c2, 5)
    p2_9l = lord_of_house_n(c2, 9)

    placements = []
    for label, planet, chart_from, chart_in in [
        ("p1_5lord_in_p2", p1_5l, c1, c2),
        ("p1_9lord_in_p2", p1_9l, c1, c2),
        ("p2_5lord_in_p1", p2_5l, c2, c1),
        ("p2_9lord_in_p1", p2_9l, c2, c1),
    ]:
        h = _planet_house_in_other_chart(chart_from, chart_in, planet) if planet else None
        placements.append({
            "direction":       label,
            "planet":          planet,
            "lands_in_house":  h,
            "score":           _score_house_placement(h),
        })

    sum_pl = sum(p["score"] for p in placements)

    # D9 lagna match
    p1_d9 = c1.get("lagna", {}).get("d9_sign")
    p2_d9 = c2.get("lagna", {}).get("d9_sign")
    d9_match = (p1_d9 == p2_d9) if (p1_d9 and p2_d9) else False
    d9_bonus = 2.0 if d9_match else 0.0
    d9_note = (f"Both share Navamsha lagna ({p1_d9}) — deep dharmic alignment"
               if d9_match else f"D9 lagnas differ: p1={p1_d9}, p2={p2_d9}")

    total = min(sum_pl + d9_bonus, 10.0)

    return {
        "placements":     placements,
        "p1_5th_lord":    p1_5l,
        "p1_9th_lord":    p1_9l,
        "p2_5th_lord":    p2_5l,
        "p2_9th_lord":    p2_9l,
        "d9_lagna_match": d9_match,
        "d9_note":        d9_note,
        "d9_bonus":       d9_bonus,
        "subtotal":       round(total, 2),
        "max":            10.0,
    }


def handle_mentor(person1: Dict[str, Any],
                  person2: Dict[str, Any],
                  role1: Optional[str] = None,
                  role2: Optional[str] = None) -> Dict[str, Any]:
    """
    F1a Endpoint: Mentor / Guru-Shishya compatibility.

    Frame: 5H (disciple from guru) / 9H (guru from disciple). Jupiter is the
    Guru karaka. Atmakaraka cross-placement reveals karmic recognition.

    Roles (optional): role1/role2 ∈ {"mentor", "mentee"}. If absent, response
    includes both directional readings.

    Streams: koot_scores (Tara + Graha Maitri only; max 8, w=0.20)
             jupiter_cross (max 10, w=0.30)
             karaka_resonance (max 10, w=0.30)
             dharma_overlay (5H/9H lords + D9; max 10, w=0.20)
    """
    c1, e1 = _build_person(person1)
    c2, e2 = _build_person(person2)

    p1_nak  = e1.get("moon_nakshatra")
    p2_nak  = e2.get("moon_nakshatra")
    p1_moon = e1.get("moon_sign")
    p2_moon = e2.get("moon_sign")

    if not (p1_nak and p2_nak and p1_moon and p2_moon):
        return {
            "error": "Could not extract Moon nakshatra/sign for both natives",
            "citations": F1A_CITATIONS["mentor"],
        }

    # ─── Stream 1: Koots (Tara + Graha Maitri) ───
    tara  = _tara_kuta(p1_nak, p2_nak)
    gmait = _graha_maitri_kuta(p1_moon, p2_moon)
    koot_subtotal = float(tara.get("score", 0)) + float(gmait.get("score", 0))
    koot_max = 8.0  # 3 + 5

    # ─── Stream 2: Jupiter cross ───
    jup = _mentor_jupiter_cross(c1, c2)

    # ─── Stream 3: Karaka resonance ───
    karaka = _mentor_karaka_resonance(c1, c2)

    # ─── Stream 4: Dharma overlay ───
    dharma = _mentor_dharma_overlay(c1, c2)

    composite_score = (
        (koot_subtotal      / koot_max) * 0.20 * 100
        + (jup["subtotal"]    / 10.0)   * 0.30 * 100
        + (karaka["subtotal"] / 10.0)   * 0.30 * 100
        + (dharma["subtotal"] / 10.0)   * 0.20 * 100
    )
    verdict = _composite_verdict(composite_score, 100.0)

    strengths, frictions = [], []
    if jup["notes"]:
        strengths.extend(jup["notes"])
    if karaka["notes"]:
        strengths.extend(karaka["notes"])
    if dharma["d9_lagna_match"]:
        strengths.append(dharma["d9_note"])
    if koot_subtotal / koot_max < 0.4:
        frictions.append(f"Weak Tara/Graha-Maitri base ({koot_subtotal:.1f}/{koot_max}) — guidance may feel uphill")
    if jup["subtotal"] < 4:
        frictions.append(f"Weak Jupiter cross ({jup['subtotal']:.1f}/10) — knowledge transmission may not flow naturally")

    # Role-aware framing
    role_note = ""
    if role1 == "mentor" and role2 == "mentee":
        role_note = (f"Person1 as mentor → consult p1's Jupiter in p2's chart "
                     f"(h{jup['p1_jupiter_in_p2_house']}) as primary signal.")
    elif role2 == "mentor" and role1 == "mentee":
        role_note = (f"Person2 as mentor → consult p2's Jupiter in p1's chart "
                     f"(h{jup['p2_jupiter_in_p1_house']}) as primary signal.")
    else:
        role_note = "Roles unspecified — both directional readings provided; either can serve as mentor."

    deeper = (
        f"This mentor bond reads as {verdict.lower()}. {role_note} "
        f"Atmakaraka resonance scored {karaka['ak_subscore']:.1f}/6, "
        f"dharma-house overlay {dharma['subtotal']:.1f}/10."
    )

    return {
        "success":             True,
        "relationship_type":   "mentor",
        "person1_role":        role1,
        "person2_role":        role2,
        "role_note":           role_note,
        "person1_essentials":  _safe_essentials_summary(e1),
        "person2_essentials":  _safe_essentials_summary(e2),
        "evidence_streams": {
            "koot_scores": {
                "tara":         tara,
                "graha_maitri": gmait,
                "subtotal":     round(koot_subtotal, 2),
                "max":          koot_max,
                "note":         "Tara + Graha Maitri selected: classical guidance-bond koots; others excluded as marriage-specific"
            },
            "jupiter_cross":      jup,
            "karaka_resonance":   karaka,
            "dharma_overlay":     dharma,
        },
        "composite": {
            "score":               round(composite_score, 1),
            "max":                 100.0,
            "verdict":             verdict,
            "key_strengths":       strengths,
            "key_friction_points": frictions,
            "deeper_pattern":      deeper,
        },
        "classical_sources": F1A_CITATIONS["mentor"],
        "karakas_consulted": RELATIONSHIP_KARAKAS["mentor"],
    }


# ════════════════════════════════════════════════════════════════════════
# FAMILY
# ════════════════════════════════════════════════════════════════════════

_VALID_FAMILY_SUBTYPES = {"parent-child", "sibling", "extended"}


def _family_karma_house_overlay(c1, c2, subtype: str) -> Dict[str, Any]:
    """
    Subtype-specific house overlay.
    Max 10 points.
    """
    def lord_of_house_n(chart, n):
        try:
            lagna = chart["lagna"]["sign"]
            idx = (_sign_index(lagna) + (n - 1)) % 12
            sign = SIGNS_ORDER[idx]
            return SIGN_TO_LORD.get(sign)
        except (KeyError, TypeError):
            return None

    if subtype == "parent-child":
        houses = [4, 9, 10, 5]
    elif subtype == "sibling":
        houses = [3, 11]
    else:  # extended
        houses = [3, 4, 5, 9, 11]

    placements = []
    for n in houses:
        for from_chart, to_chart, label in [(c1, c2, f"p1_{n}lord_in_p2"),
                                              (c2, c1, f"p2_{n}lord_in_p1")]:
            lord = lord_of_house_n(from_chart, n)
            h = _planet_house_in_other_chart(from_chart, to_chart, lord) if lord else None
            placements.append({
                "direction":       label,
                "house_of_origin": n,
                "lord":            lord,
                "lands_in_house":  h,
                "score":           _score_house_placement(h),
            })

    raw_sum = sum(p["score"] for p in placements)
    n_placements = len(placements) if placements else 1
    # Normalize to /10 scale
    normalized = (raw_sum / (n_placements * 2.0)) * 10.0
    total = min(normalized, 10.0)

    return {
        "subtype":      subtype,
        "houses_used":  houses,
        "placements":   placements,
        "raw_sum":      round(raw_sum, 2),
        "subtotal":     round(total, 2),
        "max":          10.0,
    }


def _family_karaka_cross(c1, c2, subtype: str) -> Dict[str, Any]:
    """
    Subtype-specific Jaimini karaka cross-placement.
    Max 10 points.
    """
    def get_karaka(chart, name):
        try:
            return chart["jaimini_karakas"][name]["planet"]
        except (KeyError, TypeError):
            return None

    if subtype == "parent-child":
        karakas = ["Matrikaraka", "Pitrukaraka", "Putrakaraka"]
    elif subtype == "sibling":
        karakas = ["Bhratrikaraka"]
    else:
        karakas = ["Matrikaraka", "Pitrukaraka", "Bhratrikaraka", "Putrakaraka"]

    placements = []
    for kname in karakas:
        p1_k = get_karaka(c1, kname)
        p2_k = get_karaka(c2, kname)
        if p1_k:
            h = _planet_house_in_other_chart(c1, c2, p1_k)
            placements.append({
                "direction":      f"p1_{kname.lower()}_in_p2",
                "karaka":         kname,
                "planet":         p1_k,
                "lands_in_house": h,
                "score":          _score_house_placement(h),
            })
        if p2_k:
            h = _planet_house_in_other_chart(c2, c1, p2_k)
            placements.append({
                "direction":      f"p2_{kname.lower()}_in_p1",
                "karaka":         kname,
                "planet":         p2_k,
                "lands_in_house": h,
                "score":          _score_house_placement(h),
            })

    raw_sum = sum(p["score"] for p in placements)
    n = len(placements) if placements else 1
    normalized = (raw_sum / (n * 2.0)) * 10.0
    total = min(normalized, 10.0)

    return {
        "subtype":      subtype,
        "karakas_used": karakas,
        "placements":   placements,
        "raw_sum":      round(raw_sum, 2),
        "subtotal":     round(total, 2),
        "max":          10.0,
    }


def _family_gnatikaraka_warning(c1, c2) -> Dict[str, Any]:
    """
    If both share the same Gnatikaraka (planet of inherited conflict),
    that's a classical signature of generational friction between them.
    Max 5 points (no shared = full points; shared = 0).
    """
    def get_gk(chart):
        try:
            return chart["jaimini_karakas"]["Gnatikaraka"]["planet"]
        except (KeyError, TypeError):
            return None

    gk1 = get_gk(c1)
    gk2 = get_gk(c2)
    shared = (gk1 == gk2) if (gk1 and gk2) else False

    return {
        "p1_gnatikaraka": gk1,
        "p2_gnatikaraka": gk2,
        "shared":         shared,
        "subtotal":       0.0 if shared else 5.0,
        "max":            5.0,
        "note":           (f"Both share Gnatikaraka ({gk1}) — classical signature of "
                          "inherited friction/karmic obstacles between these natives. "
                          "Not fatal; remedy via the Gnatikaraka's dasha awareness.")
                          if shared else
                          "Distinct Gnatikarakas — no inherited friction signature.",
    }


def handle_family(person1: Dict[str, Any],
                  person2: Dict[str, Any],
                  role1: Optional[str] = None,
                  role2: Optional[str] = None,
                  subtype: Optional[str] = None) -> Dict[str, Any]:
    """
    F1a Endpoint: Family compatibility — parent/sibling/child/extended.

    Subtype (optional, defaults to "extended"):
        "parent-child" → houses 4, 9, 10, 5; karakas Matri/Pitri/Putra
        "sibling"      → houses 3, 11;       karaka Bhratrikaraka
        "extended"     → all family houses + all four family karakas (broad reading)

    Roles (optional): free-text labels (e.g. "mother", "elder_sibling"); not used
    in scoring but echoed in response for context.

    Streams: koot_scores (Gana + Tara + Yoni; max 13, w=0.30)
             karma_house_overlay (subtype-specific; max 10, w=0.30)
             karaka_cross (subtype-specific; max 10, w=0.30)
             gnatikaraka_warning (max 5, w=0.10)
    """
    # Normalize subtype
    if subtype is None:
        subtype = "extended"
    subtype = subtype.lower().strip()
    if subtype not in _VALID_FAMILY_SUBTYPES:
        return {
            "error": (f"Invalid subtype '{subtype}'. "
                      f"Must be one of: {sorted(_VALID_FAMILY_SUBTYPES)}"),
            "citations": F1A_CITATIONS["family"],
        }

    c1, e1 = _build_person(person1)
    c2, e2 = _build_person(person2)

    p1_nak  = e1.get("moon_nakshatra")
    p2_nak  = e2.get("moon_nakshatra")
    p1_moon = e1.get("moon_sign")
    p2_moon = e2.get("moon_sign")

    if not (p1_nak and p2_nak and p1_moon and p2_moon):
        return {
            "error": "Could not extract Moon nakshatra/sign for both natives",
            "citations": F1A_CITATIONS["family"],
        }

    # ─── Stream 1: Koots (Gana + Tara + Yoni) ───
    gana = _gana_kuta(p1_nak, p2_nak)
    tara = _tara_kuta(p1_nak, p2_nak)
    yoni = _yoni_kuta(p1_nak, p2_nak)
    koot_subtotal = (
        float(gana.get("score", 0))
        + float(tara.get("score", 0))
        + float(yoni.get("score", 0))
    )
    koot_max = 13.0  # 6 + 3 + 4

    # ─── Stream 2: Karma house overlay ───
    overlay = _family_karma_house_overlay(c1, c2, subtype)

    # ─── Stream 3: Karaka cross ───
    karaka_cross = _family_karaka_cross(c1, c2, subtype)

    # ─── Stream 4: Gnatikaraka warning ───
    gnati = _family_gnatikaraka_warning(c1, c2)

    composite_score = (
        (koot_subtotal           / koot_max) * 0.30 * 100
        + (overlay["subtotal"]     / 10.0)   * 0.30 * 100
        + (karaka_cross["subtotal"] / 10.0)  * 0.30 * 100
        + (gnati["subtotal"]       / 5.0)    * 0.10 * 100
    )
    verdict = _composite_verdict(composite_score, 100.0)

    strengths, frictions = [], []
    if koot_subtotal / koot_max >= 0.7:
        strengths.append(f"Strong shared temperament — Gana/Tara/Yoni {koot_subtotal:.1f}/{koot_max}")
    elif koot_subtotal / koot_max < 0.4:
        frictions.append(f"Temperamental mismatch — Gana/Tara/Yoni {koot_subtotal:.1f}/{koot_max}")
    if gnati["shared"]:
        frictions.append(gnati["note"])
    else:
        strengths.append("No shared Gnatikaraka — clean of inherited-friction signature")
    if overlay["subtotal"] >= 7:
        strengths.append(f"{subtype.title()} house lords land supportively across charts")
    elif overlay["subtotal"] < 4:
        frictions.append(f"{subtype.title()} house lords fall in difficult houses across charts")

    deeper = (
        f"This family bond ({subtype}) reads as {verdict.lower()}. "
        f"Koot temperament fit {koot_subtotal:.1f}/{koot_max}, "
        f"house-overlay {overlay['subtotal']:.1f}/10, "
        f"karaka cross-placement {karaka_cross['subtotal']:.1f}/10, "
        f"gnatikaraka {'SHARED (friction)' if gnati['shared'] else 'distinct (clean)'}."
    )

    return {
        "success":             True,
        "relationship_type":   "family",
        "subtype":             subtype,
        "person1_role":        role1,
        "person2_role":        role2,
        "person1_essentials":  _safe_essentials_summary(e1),
        "person2_essentials":  _safe_essentials_summary(e2),
        "evidence_streams": {
            "koot_scores": {
                "gana":     gana,
                "tara":     tara,
                "yoni":     yoni,
                "subtotal": round(koot_subtotal, 2),
                "max":      koot_max,
                "note":     "Gana + Tara + Yoni selected — temperament/instinct/support koots for family"
            },
            "karma_house_overlay":  overlay,
            "karaka_cross":         karaka_cross,
            "gnatikaraka_warning":  gnati,
        },
        "composite": {
            "score":               round(composite_score, 1),
            "max":                 100.0,
            "verdict":             verdict,
            "key_strengths":       strengths,
            "key_friction_points": frictions,
            "deeper_pattern":      deeper,
        },
        "classical_sources": F1A_CITATIONS["family"],
        "karakas_consulted": RELATIONSHIP_KARAKAS["family"],
    }


# ════════════════════════════════════════════════════════════════════════
# ════════════════════════════════════════════════════════════════════════
# ──── F1b SECTION (2026-05-17) ────
# Business Partner + Colleague + Compatibility Matrix
#
# F1b extends F1a's pattern to professional contexts and adds a meta
# endpoint that ranks N candidates against one native.
#
# Reuses ALL of F1a's primitives:
#   _safe_essentials_summary, _composite_verdict, _score_house_placement,
#   _planet_house_in_other_chart, RELATIONSHIP_KARAKAS, F1A_CITATIONS
#   (locally extended)
#
# New helpers added below:
#   _d10_chart_overlay     — leverages U7's per-planet d10_sign
#   _business_amk_resonance — AmK cross-placement (key signal for partnership)
#   _saturn_mars_synastry  — workplace conflict signature
#
# Author: Claude (F1b, 2026-05-17)
# ════════════════════════════════════════════════════════════════════════

# Extend RELATIONSHIP_KARAKAS with colleague (business already seeded by F1a)
RELATIONSHIP_KARAKAS["colleague"] = {
    "primary_house": "6th (service, daily work, conflicts), 10th (work/reputation)",
    "primary_karaka": "Saturn (service-discipline)",
    "secondary_karaka": "Mars (drive, conflict, action)",
    "secondary_house": "3rd (peers/teammates), 11th (collective gains)",
}

# F1b-specific citation subsets
F1A_CITATIONS["business_partner"] = [
    "BPHS Ch. 7 — 7th house (partnership), 10th house (karma/profession), 11th house (labha/gains)",
    "Brihat Jataka Ch. 11 — Amatyakaraka as career-significator; AmK cross-placement reveals professional alignment",
    "Jataka Parijata Ch. 4 — D10 (Dashamsha) as the karma chart for joint professional dharma",
    "Phaladeepika Ch. 9 — 10H lord and Mercury for commercial-professional analysis",
    "Saravali Ch. 28 — partnership through Venus-Jupiter and 7H lord cross-aspects",
]
F1A_CITATIONS["colleague"] = [
    "BPHS Ch. 7 — 6th house (service, daily routine, conflicts), 10th house (work hierarchy)",
    "Phaladeepika Ch. 6 — Saturn as karma-karaka, governs service relationships",
    "Saravali Ch. 28 — Mars-Saturn cross-aspects produce workplace friction signatures",
    "Jataka Parijata Ch. 7 — 3rd house (peers, courage) for collegial dynamics",
]
F1A_CITATIONS["compatibility_matrix"] = [
    "Composite scoring across pairwise classical analyses per relationship type",
    "See per-type citations above for source material",
]


# ════════════════════════════════════════════════════════════════════════
# F1b HELPERS
# ════════════════════════════════════════════════════════════════════════

def _build_d10_chart(chart: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build a D10-shaped chart dict from cast_chart output's pre-computed
    d10_sign fields. Output mirrors the D1 chart shape enough that
    _planet_house_in_other_chart can be called against it directly.

    Returns:
      {
        "lagna": {"sign": <d10_lagna_sign>},
        "planets": {planet_name: {"sign": <d10_sign>}, ...}
      }
    """
    out = {
        "lagna": {"sign": chart.get("lagna", {}).get("d10_sign")},
        "planets": {},
    }
    for pname, pdata in chart.get("planets", {}).items():
        d10 = pdata.get("d10_sign")
        if d10:
            out["planets"][pname] = {"sign": d10}
    return out


def _planet_d10_house_in_other_d10(p_d10, other_d10, planet: str) -> Optional[int]:
    """
    Like _planet_house_in_other_chart but for D10 charts.
    Returns 1-12 house of <planet>'s D10 sign relative to other_d10's lagna.
    """
    try:
        psign = p_d10["planets"][planet]["sign"]
        other_lagna = other_d10["lagna"]["sign"]
        return _house_from_sign(psign, other_lagna)
    except (KeyError, TypeError):
        return None


def _business_d10_overlay(c1, c2) -> Dict[str, Any]:
    """
    Build both D10 charts and locate each native's AmK + 10H-lord in the
    other's D10.

    Max 10 points:
      AmK cross in 1/10/11 = 3 pts each (max 6 for AmK both ways)
      10H lord cross in 1/5/9/10/11 = 2 pts each (max 4 for 10L both ways)
    """
    d10_1 = _build_d10_chart(c1)
    d10_2 = _build_d10_chart(c2)

    def amk_planet(chart):
        try:
            return chart["jaimini_karakas"]["Amatyakaraka"]["planet"]
        except (KeyError, TypeError):
            return None

    def d10_tenth_lord(chart):
        """10H lord in D10 = sign 10 houses from D10 lagna, then its ruler."""
        try:
            d10_lagna = chart["lagna"]["d10_sign"]
            idx = (_sign_index(d10_lagna) + 9) % 12  # 10th from lagna = index +9
            tenth_sign = SIGNS_ORDER[idx]
            return SIGN_TO_LORD.get(tenth_sign), tenth_sign
        except (KeyError, TypeError, AttributeError):
            return None, None

    p1_amk = amk_planet(c1)
    p2_amk = amk_planet(c2)
    p1_10l, p1_10s = d10_tenth_lord(c1)
    p2_10l, p2_10s = d10_tenth_lord(c2)

    def score_amk(h):
        if h is None: return 0.0
        if h in (1, 10, 11):  return 3.0
        if h in (5, 9):       return 2.0
        if h in (2, 3, 7):    return 1.0
        return 0.5

    def score_10l(h):
        if h is None: return 0.0
        if h in (1, 10):           return 2.0
        if h in (5, 9, 11):        return 2.0
        if h in (2, 3, 7):         return 1.0
        return 0.5

    p1_amk_in_p2_d10 = _planet_d10_house_in_other_d10(d10_1, d10_2, p1_amk) if p1_amk else None
    p2_amk_in_p1_d10 = _planet_d10_house_in_other_d10(d10_2, d10_1, p2_amk) if p2_amk else None
    p1_10l_in_p2_d10 = _planet_d10_house_in_other_d10(d10_1, d10_2, p1_10l) if p1_10l else None
    p2_10l_in_p1_d10 = _planet_d10_house_in_other_d10(d10_2, d10_1, p2_10l) if p2_10l else None

    s_amk = score_amk(p1_amk_in_p2_d10) + score_amk(p2_amk_in_p1_d10)
    s_10l = score_10l(p1_10l_in_p2_d10) + score_10l(p2_10l_in_p1_d10)

    notes = []
    if p1_amk_in_p2_d10 in (1, 10, 11):
        notes.append(f"p1's AmK ({p1_amk}) in p2's D10 {p1_amk_in_p2_d10}H — strong career-purpose bridging from p1 to p2")
    if p2_amk_in_p1_d10 in (1, 10, 11):
        notes.append(f"p2's AmK ({p2_amk}) in p1's D10 {p2_amk_in_p1_d10}H — strong career-purpose bridging from p2 to p1")

    # D10 lagna match — shared professional dharma
    d10_lagna_match = (d10_1["lagna"]["sign"] == d10_2["lagna"]["sign"]
                       if d10_1["lagna"]["sign"] and d10_2["lagna"]["sign"] else False)
    bonus = 0.0
    if d10_lagna_match:
        bonus = 1.5
        notes.append(f"Both share D10 lagna ({d10_1['lagna']['sign']}) — shared professional dharma signature")

    total = min(s_amk + s_10l + bonus, 10.0)

    return {
        "p1_d10_lagna":               d10_1["lagna"]["sign"],
        "p2_d10_lagna":               d10_2["lagna"]["sign"],
        "d10_lagna_match":            d10_lagna_match,
        "p1_amk":                     p1_amk,
        "p1_amk_in_p2_d10_house":     p1_amk_in_p2_d10,
        "p2_amk":                     p2_amk,
        "p2_amk_in_p1_d10_house":     p2_amk_in_p1_d10,
        "p1_d10_10th_lord":           p1_10l,
        "p2_d10_10th_lord":           p2_10l,
        "p1_10l_in_p2_d10_house":     p1_10l_in_p2_d10,
        "p2_10l_in_p1_d10_house":     p2_10l_in_p1_d10,
        "amk_subscore":               round(s_amk, 2),
        "tenth_lord_subscore":        round(s_10l, 2),
        "d10_lagna_match_bonus":      bonus,
        "notes":                      notes,
        "subtotal":                   round(total, 2),
        "max":                        10.0,
    }


def _business_house_overlay(c1, c2) -> Dict[str, Any]:
    """
    7H/10H/11H lord cross-placement in D1 (the standard business houses).
    Max 10 points.
    """
    def lord_of_house_n(chart, n):
        try:
            lagna = chart["lagna"]["sign"]
            idx = (_sign_index(lagna) + (n - 1)) % 12
            sign = SIGNS_ORDER[idx]
            return SIGN_TO_LORD.get(sign)
        except (KeyError, TypeError):
            return None

    placements = []
    for n in [7, 10, 11]:
        for from_chart, to_chart, label in [(c1, c2, f"p1_{n}lord_in_p2"),
                                              (c2, c1, f"p2_{n}lord_in_p1")]:
            lord = lord_of_house_n(from_chart, n)
            h = _planet_house_in_other_chart(from_chart, to_chart, lord) if lord else None
            placements.append({
                "direction":       label,
                "house_of_origin": n,
                "lord":            lord,
                "lands_in_house":  h,
                "score":           _score_house_placement(h),
            })

    raw = sum(p["score"] for p in placements)
    # 6 placements × 2 = 12 max raw → normalize to /10
    normalized = (raw / 12.0) * 10.0
    total = min(normalized, 10.0)

    return {
        "placements": placements,
        "raw_sum":    round(raw, 2),
        "subtotal":   round(total, 2),
        "max":        10.0,
    }


def _saturn_mars_synastry(c1, c2) -> Dict[str, Any]:
    """
    Workplace conflict signature. Mars-Saturn cross-aspects (especially
    falling in 6H — the conflict house) signal friction.

    Score 0-10: HIGHER score = LESS friction (positive framing).
      Each Mars/Saturn placement in other's 6H/8H/12H = -2 (subtract from base 10)
      Both planets harmless (3H/11H) = +0
    """
    def planet_in_other_house(p_chart, o_chart, planet):
        return _planet_house_in_other_chart(p_chart, o_chart, planet)

    p1_mars_in_p2 = planet_in_other_house(c1, c2, "Mars")
    p1_sat_in_p2  = planet_in_other_house(c1, c2, "Saturn")
    p2_mars_in_p1 = planet_in_other_house(c2, c1, "Mars")
    p2_sat_in_p1  = planet_in_other_house(c2, c1, "Saturn")

    base = 10.0
    notes = []
    for label, h, planet, owner_to_target in [
        ("p1_mars_in_p2", p1_mars_in_p2, "Mars",   "p1→p2"),
        ("p1_saturn_in_p2", p1_sat_in_p2, "Saturn", "p1→p2"),
        ("p2_mars_in_p1", p2_mars_in_p1, "Mars",   "p2→p1"),
        ("p2_saturn_in_p1", p2_sat_in_p1, "Saturn", "p2→p1"),
    ]:
        if h in (6, 8, 12):
            base -= 2.0
            notes.append(f"{owner_to_target}: {planet} falls in {h}H — friction signature")
        elif h in (3, 11):
            notes.append(f"{owner_to_target}: {planet} falls in {h}H — supportive workplace energy")

    score = max(0.0, min(base, 10.0))

    return {
        "p1_mars_in_p2_house":   p1_mars_in_p2,
        "p1_saturn_in_p2_house": p1_sat_in_p2,
        "p2_mars_in_p1_house":   p2_mars_in_p1,
        "p2_saturn_in_p1_house": p2_sat_in_p1,
        "interpretation":        "Higher score = less conflict signature (10 = clean; 0 = high friction)",
        "notes":                 notes,
        "subtotal":              round(score, 2),
        "max":                   10.0,
    }


def _colleague_house_overlay(c1, c2) -> Dict[str, Any]:
    """
    6H + 10H + 3H lord cross-placement.
    Max 10 points.

    Note: 6H is the 'shashtha bhava' — service, daily routine, AND conflicts.
    The 6H lord falling in trinal/supportive houses = good service relationship.
    """
    def lord_of_house_n(chart, n):
        try:
            lagna = chart["lagna"]["sign"]
            idx = (_sign_index(lagna) + (n - 1)) % 12
            sign = SIGNS_ORDER[idx]
            return SIGN_TO_LORD.get(sign)
        except (KeyError, TypeError):
            return None

    placements = []
    for n in [6, 10, 3]:
        for from_chart, to_chart, label in [(c1, c2, f"p1_{n}lord_in_p2"),
                                              (c2, c1, f"p2_{n}lord_in_p1")]:
            lord = lord_of_house_n(from_chart, n)
            h = _planet_house_in_other_chart(from_chart, to_chart, lord) if lord else None
            placements.append({
                "direction":       label,
                "house_of_origin": n,
                "lord":            lord,
                "lands_in_house":  h,
                "score":           _score_house_placement(h),
            })

    raw = sum(p["score"] for p in placements)
    normalized = (raw / 12.0) * 10.0
    total = min(normalized, 10.0)

    return {
        "placements": placements,
        "raw_sum":    round(raw, 2),
        "subtotal":   round(total, 2),
        "max":        10.0,
    }


# ════════════════════════════════════════════════════════════════════════
# BUSINESS PARTNER
# ════════════════════════════════════════════════════════════════════════

def handle_business_partner(person1: Dict[str, Any],
                             person2: Dict[str, Any],
                             role1: Optional[str] = None,
                             role2: Optional[str] = None) -> Dict[str, Any]:
    """
    F1b Endpoint: Business Partner / Co-founder compatibility.

    Frame: 7H (partnership), 10H (joint work), 11H (gains); karakas
    Mercury (commerce), Jupiter (ethics), Amatyakaraka (career-purpose).

    Streams: koot_scores (Tara + Graha Maitri only; max 8, w=0.15)
             d10_overlay (AmK cross + D10 lagna; max 10, w=0.35)
             house_overlay (7H/10H/11H lords; max 10, w=0.30)
             ethics_signal (Jupiter cross-placement; max 10, w=0.20)
    """
    c1, e1 = _build_person(person1)
    c2, e2 = _build_person(person2)

    p1_nak  = e1.get("moon_nakshatra")
    p2_nak  = e2.get("moon_nakshatra")
    p1_moon = e1.get("moon_sign")
    p2_moon = e2.get("moon_sign")

    if not (p1_nak and p2_nak and p1_moon and p2_moon):
        return {
            "error": "Could not extract Moon nakshatra/sign for both natives",
            "citations": F1A_CITATIONS["business_partner"],
        }

    # Stream 1: Koots
    tara  = _tara_kuta(p1_nak, p2_nak)
    gmait = _graha_maitri_kuta(p1_moon, p2_moon)
    koot_subtotal = float(tara.get("score", 0)) + float(gmait.get("score", 0))
    koot_max = 8.0

    # Stream 2: D10 overlay (AmK cross + 10L cross + D10 lagna match)
    d10_overlay = _business_d10_overlay(c1, c2)

    # Stream 3: 7H/10H/11H lords cross-placement in D1
    house_ov = _business_house_overlay(c1, c2)

    # Stream 4: Jupiter cross — proxy for ethics/dharmic-fit
    def jup_house(p_from, p_to):
        return _planet_house_in_other_chart(p_from, p_to, "Jupiter")
    p1_jup = jup_house(c1, c2)
    p2_jup = jup_house(c2, c1)
    def score_jup(h):
        if h is None: return 0.0
        if h in (1, 5, 9, 10, 11): return 5.0
        if h in (2, 4, 7):         return 3.0
        if h in (3,):              return 2.0
        return 0.5
    ethics_subtotal = min(score_jup(p1_jup) + score_jup(p2_jup), 10.0)
    ethics_notes = []
    if p1_jup in (10, 11):
        ethics_notes.append(f"p1's Jupiter in p2's {p1_jup}H — ethical/dharmic uplift in joint work")
    if p2_jup in (10, 11):
        ethics_notes.append(f"p2's Jupiter in p1's {p2_jup}H — ethical/dharmic uplift in joint work")
    ethics_stream = {
        "p1_jupiter_in_p2_house": p1_jup,
        "p2_jupiter_in_p1_house": p2_jup,
        "notes":                  ethics_notes,
        "subtotal":               round(ethics_subtotal, 2),
        "max":                    10.0,
    }

    composite_score = (
        (koot_subtotal / koot_max)            * 0.15 * 100
        + (d10_overlay["subtotal"] / 10.0)    * 0.35 * 100
        + (house_ov["subtotal"]    / 10.0)    * 0.30 * 100
        + (ethics_subtotal         / 10.0)    * 0.20 * 100
    )
    verdict = _composite_verdict(composite_score, 100.0)

    strengths, frictions = [], []
    if d10_overlay["notes"]:
        strengths.extend(d10_overlay["notes"])
    if d10_overlay["subtotal"] >= 7:
        strengths.append(f"Strong D10 (career-chart) overlay — {d10_overlay['subtotal']:.1f}/10")
    if ethics_notes:
        strengths.extend(ethics_notes)
    if house_ov["subtotal"] < 4:
        frictions.append(f"Business-house lords in difficult positions ({house_ov['subtotal']:.1f}/10) — 7H/10H/11H cross-overlay weak")
    if ethics_subtotal < 3:
        frictions.append("Jupiter cross-placements weak — dharmic/ethics alignment may need explicit cultivation")
    if koot_subtotal / koot_max < 0.4:
        frictions.append(f"Weak Tara/Graha-Maitri base ({koot_subtotal:.1f}/{koot_max})")

    deeper = (
        f"This business partnership reads as {verdict.lower()}. "
        f"D10 (career-chart) overlay scored {d10_overlay['subtotal']:.1f}/10, "
        f"D1 partnership-house overlay {house_ov['subtotal']:.1f}/10, "
        f"ethics/Jupiter cross {ethics_subtotal:.1f}/10."
    )

    return {
        "success":             True,
        "relationship_type":   "business_partner",
        "person1_role":        role1,
        "person2_role":        role2,
        "person1_essentials":  _safe_essentials_summary(e1),
        "person2_essentials":  _safe_essentials_summary(e2),
        "evidence_streams": {
            "koot_scores": {
                "tara":         tara,
                "graha_maitri": gmait,
                "subtotal":     round(koot_subtotal, 2),
                "max":          koot_max,
                "note":         "Tara + Graha Maitri only — instinctual/temperament koots not relevant for transactional partnership"
            },
            "d10_career_overlay": d10_overlay,
            "house_overlay":      house_ov,
            "ethics_signal":      ethics_stream,
        },
        "composite": {
            "score":               round(composite_score, 1),
            "max":                 100.0,
            "verdict":             verdict,
            "key_strengths":       strengths,
            "key_friction_points": frictions,
            "deeper_pattern":      deeper,
        },
        "classical_sources": F1A_CITATIONS["business_partner"],
        "karakas_consulted": RELATIONSHIP_KARAKAS["business"],
    }


# ════════════════════════════════════════════════════════════════════════
# COLLEAGUE
# ════════════════════════════════════════════════════════════════════════

def handle_colleague(person1: Dict[str, Any],
                     person2: Dict[str, Any],
                     role1: Optional[str] = None,
                     role2: Optional[str] = None) -> Dict[str, Any]:
    """
    F1b Endpoint: Workplace colleague compatibility.

    Frame: 6H (service/conflict), 10H (work), 3H (peers); karakas Saturn
    (service), Mars (drive/conflict), Mercury (communication).

    Streams: koot_scores (Gana + Graha Maitri; max 11, w=0.25)
             house_overlay (6H/10H/3H lords; max 10, w=0.30)
             saturn_mars_synastry (conflict signature inverted; max 10, w=0.30)
             communication (Mercury cross; max 10, w=0.15)
    """
    c1, e1 = _build_person(person1)
    c2, e2 = _build_person(person2)

    p1_nak  = e1.get("moon_nakshatra")
    p2_nak  = e2.get("moon_nakshatra")
    p1_moon = e1.get("moon_sign")
    p2_moon = e2.get("moon_sign")

    if not (p1_nak and p2_nak and p1_moon and p2_moon):
        return {
            "error": "Could not extract Moon nakshatra/sign for both natives",
            "citations": F1A_CITATIONS["colleague"],
        }

    # Stream 1: Gana + Graha Maitri (temperament + planetary friendship)
    gana  = _gana_kuta(p1_nak, p2_nak)
    gmait = _graha_maitri_kuta(p1_moon, p2_moon)
    koot_subtotal = float(gana.get("score", 0)) + float(gmait.get("score", 0))
    koot_max = 11.0  # 6 + 5

    # Stream 2: 6H/10H/3H lords cross
    house_ov = _colleague_house_overlay(c1, c2)

    # Stream 3: Saturn-Mars synastry (inverted; high score = clean)
    sat_mars = _saturn_mars_synastry(c1, c2)

    # Stream 4: Mercury cross-placement
    def mercury_house(p_from, p_to):
        return _planet_house_in_other_chart(p_from, p_to, "Mercury")
    p1_merc = mercury_house(c1, c2)
    p2_merc = mercury_house(c2, c1)
    def score_merc(h):
        if h is None: return 0.0
        if h in (3, 5, 10, 11): return 5.0
        if h in (1, 9):         return 4.0
        if h in (2, 4, 7):      return 2.5
        return 1.0
    comm_subtotal = min(score_merc(p1_merc) + score_merc(p2_merc), 10.0)
    comm_notes = []
    if p1_merc in (3, 10, 11):
        comm_notes.append(f"p1's Mercury in p2's {p1_merc}H — fluent professional communication from p1")
    if p2_merc in (3, 10, 11):
        comm_notes.append(f"p2's Mercury in p1's {p2_merc}H — fluent professional communication from p2")
    comm_stream = {
        "p1_mercury_in_p2_house": p1_merc,
        "p2_mercury_in_p1_house": p2_merc,
        "notes":                  comm_notes,
        "subtotal":               round(comm_subtotal, 2),
        "max":                    10.0,
    }

    composite_score = (
        (koot_subtotal / koot_max)            * 0.25 * 100
        + (house_ov["subtotal"]    / 10.0)    * 0.30 * 100
        + (sat_mars["subtotal"]    / 10.0)    * 0.30 * 100
        + (comm_subtotal           / 10.0)    * 0.15 * 100
    )
    verdict = _composite_verdict(composite_score, 100.0)

    strengths, frictions = [], []
    if koot_subtotal / koot_max >= 0.65:
        strengths.append(f"Strong temperament fit — Gana+Graha Maitri {koot_subtotal:.1f}/{koot_max}")
    elif koot_subtotal / koot_max < 0.4:
        frictions.append(f"Temperament mismatch — Gana+Graha Maitri {koot_subtotal:.1f}/{koot_max}")
    if sat_mars["subtotal"] >= 8:
        strengths.append("Clean Saturn-Mars cross — minimal workplace friction signature")
    elif sat_mars["subtotal"] < 5:
        frictions.append(f"Saturn-Mars friction signatures present — {sat_mars['subtotal']:.1f}/10")
        if sat_mars["notes"]:
            frictions.extend([n for n in sat_mars["notes"] if "friction" in n])
    if comm_notes:
        strengths.extend(comm_notes)

    deeper = (
        f"This workplace bond reads as {verdict.lower()}. "
        f"Saturn-Mars cross (conflict signature inverted) {sat_mars['subtotal']:.1f}/10, "
        f"service-house overlay {house_ov['subtotal']:.1f}/10, "
        f"Mercury communication cross {comm_subtotal:.1f}/10."
    )

    return {
        "success":             True,
        "relationship_type":   "colleague",
        "person1_role":        role1,
        "person2_role":        role2,
        "person1_essentials":  _safe_essentials_summary(e1),
        "person2_essentials":  _safe_essentials_summary(e2),
        "evidence_streams": {
            "koot_scores": {
                "gana":         gana,
                "graha_maitri": gmait,
                "subtotal":     round(koot_subtotal, 2),
                "max":          koot_max,
                "note":         "Gana + Graha Maitri — temperament + planetary friendship for daily-contact bonds"
            },
            "service_house_overlay": house_ov,
            "saturn_mars_synastry":  sat_mars,
            "communication":         comm_stream,
        },
        "composite": {
            "score":               round(composite_score, 1),
            "max":                 100.0,
            "verdict":             verdict,
            "key_strengths":       strengths,
            "key_friction_points": frictions,
            "deeper_pattern":      deeper,
        },
        "classical_sources": F1A_CITATIONS["colleague"],
        "karakas_consulted": RELATIONSHIP_KARAKAS["colleague"],
    }


# ════════════════════════════════════════════════════════════════════════
# COMPATIBILITY MATRIX (multi-person ranking)
# ════════════════════════════════════════════════════════════════════════

_MATRIX_HANDLERS = {
    "friendship":       lambda p1, p2, **kw: handle_friendship(p1, p2,
                                              role1=kw.get("role1"), role2=kw.get("role2")),
    "mentor":           lambda p1, p2, **kw: handle_mentor(p1, p2,
                                              role1=kw.get("role1"), role2=kw.get("role2")),
    "family":           lambda p1, p2, **kw: handle_family(p1, p2,
                                              role1=kw.get("role1"), role2=kw.get("role2"),
                                              subtype=kw.get("subtype")),
    "business_partner": lambda p1, p2, **kw: handle_business_partner(p1, p2,
                                              role1=kw.get("role1"), role2=kw.get("role2")),
    "colleague":        lambda p1, p2, **kw: handle_colleague(p1, p2,
                                              role1=kw.get("role1"), role2=kw.get("role2")),
}

MATRIX_HARD_CEILING = 50  # absolute max regardless of caller's max_others


def handle_compatibility_matrix(native: Dict[str, Any],
                                 others: List[Dict[str, Any]],
                                 relationship_type: str,
                                 subtype: Optional[str] = None,
                                 max_others: int = 20) -> Dict[str, Any]:
    """
    F1b Endpoint: Multi-person compatibility ranking.

    Takes one `native` and N `others`, runs the pairwise handler for the
    specified `relationship_type` against each, and returns the candidates
    ranked by composite score.

    Args:
      native:            BirthInput dict (the "you" person)
      others:            list of BirthInput dicts; each MAY include a "label" key
                         (e.g. {"label": "Sarah", "dob": ..., "time": ...})
      relationship_type: one of friendship|mentor|family|business_partner|colleague
      subtype:           for family only — "parent-child"|"sibling"|"extended"
      max_others:        caller-specified bound; clamped to MATRIX_HARD_CEILING

    Returns:
      ranked list of pairwise results + top-line summary
    """
    rt = (relationship_type or "").lower().strip()
    if rt not in _MATRIX_HANDLERS:
        return {
            "error": (f"Unknown relationship_type '{relationship_type}'. "
                      f"Must be one of: {sorted(_MATRIX_HANDLERS.keys())}"),
            "citations": F1A_CITATIONS["compatibility_matrix"],
        }

    if not isinstance(others, list) or len(others) == 0:
        return {
            "error": "others must be a non-empty list of birth-input dicts",
            "citations": F1A_CITATIONS["compatibility_matrix"],
        }

    # Clamp max_others
    effective_max = min(int(max_others or 20), MATRIX_HARD_CEILING)
    if effective_max < 1:
        effective_max = 1
    truncated = False
    if len(others) > effective_max:
        others_to_use = others[:effective_max]
        truncated = True
    else:
        others_to_use = others

    handler = _MATRIX_HANDLERS[rt]

    results = []
    for idx, other in enumerate(others_to_use):
        # Pull and strip the optional "label" field
        label = other.get("label") if isinstance(other, dict) else None
        # Build pristine birth-input dict (drop label + any extra fields)
        birth_other = {k: other[k] for k in
                       ("dob", "time", "lat", "lon", "timezone")
                       if isinstance(other, dict) and k in other}

        try:
            pairwise = handler(native, birth_other, subtype=subtype)
        except Exception as e:
            results.append({
                "index": idx,
                "label": label or f"candidate_{idx}",
                "error": f"pairwise computation failed: {e}",
                "composite_score": 0.0,
                "verdict": "DIFFICULT",
            })
            continue

        score = pairwise.get("composite", {}).get("score", 0.0)
        verdict = pairwise.get("composite", {}).get("verdict", "UNKNOWN")

        results.append({
            "index":            idx,
            "label":            label or f"candidate_{idx}",
            "composite_score":  score,
            "verdict":          verdict,
            "key_strengths":    pairwise.get("composite", {}).get("key_strengths", []),
            "key_friction_points": pairwise.get("composite", {}).get("key_friction_points", []),
            "deeper_pattern":   pairwise.get("composite", {}).get("deeper_pattern", ""),
            "full_pairwise":    pairwise,
        })

    # Rank by composite_score descending; preserve original index for ties
    ranked = sorted(results,
                    key=lambda r: (-r["composite_score"], r["index"]))

    # Top-line summary
    if ranked:
        top = ranked[0]
        summary = (f"Top match: '{top['label']}' "
                   f"(score {top['composite_score']:.1f}/100, {top['verdict']}). "
                   f"Ranked {len(ranked)} candidates total"
                   f"{' (truncated from larger input)' if truncated else ''}.")
    else:
        summary = "No candidates evaluated."

    return {
        "success":           True,
        "relationship_type": rt,
        "subtype":           subtype if rt == "family" else None,
        "native_dob":        native.get("dob"),
        "candidates_evaluated": len(ranked),
        "candidates_requested": len(others),
        "max_others_effective": effective_max,
        "max_others_ceiling":   MATRIX_HARD_CEILING,
        "truncated":            truncated,
        "summary":              summary,
        "ranked":               ranked,
        "classical_sources":    F1A_CITATIONS["compatibility_matrix"],
    }
