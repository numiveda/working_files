"""
birthday_quick.py — numiVeda Kaaliyo Astro Engine — Module F9 (Birthday Quick)

Two endpoints for daily astrological snapshot:
    handle_birthday_quick    — Full daily snapshot for native on a given date
    handle_birthday_headline — One-sentence summary derived from quick's data

Design (per HANDOVER_v5 carry-forward):
    P1 — All astronomy through cast_chart.
    P2 — Reuse: cast_chart for query_date's panchang + transit positions,
         existing chart["dashas"] structure for active periods. Tara lookup
         done locally rather than calling /astro/nakshatra/tara.
    P5 — Auspicious/inauspicious daily yoga detection built fresh —
         no existing implementation in the codebase per F9 pre-build diagnostic.

Public API:
    handle_birthday_quick(birth, query_date=None) -> dict
    handle_birthday_headline(birth, query_date=None) -> dict

Author: Claude (F9, 2026-05-18)
"""

from typing import Dict, List, Optional, Any
from datetime import date, datetime

try:
    from dashaflow import cast_chart
except ImportError as e:
    raise ImportError(f"F9 birthday_quick requires dashaflow.cast_chart: {e}")

try:
    from astro_helpers import SIGNS_ORDER
except ImportError as e:
    raise ImportError(f"F9 birthday_quick requires astro_helpers: {e}")


# ════════════════════════════════════════════════════════════════════════
# TARA CYCLE (Moon transit nakshatra relative to natal Moon nakshatra)
# ════════════════════════════════════════════════════════════════════════

_NAKSHATRAS_ORDER = [
    "Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashira", "Ardra",
    "Punarvasu", "Pushya", "Ashlesha", "Magha", "Purva Phalguni",
    "Uttara Phalguni", "Hasta", "Chitra", "Swati", "Vishakha", "Anuradha",
    "Jyeshtha", "Mula", "Purva Ashadha", "Uttara Ashadha", "Shravana",
    "Dhanishta", "Shatabhisha", "Purva Bhadrapada", "Uttara Bhadrapada",
    "Revati",
]

# 9 taras in cycle; offset 0 from janma = Janma (1st tara)
_TARA_TABLE = [
    {"idx": 1, "name_en": "Janma",   "nature": "Mixed",        "effect": "Reset, return to origin"},
    {"idx": 2, "name_en": "Sampat",  "nature": "Auspicious",   "effect": "Wealth, prosperity"},
    {"idx": 3, "name_en": "Vipat",   "nature": "Inauspicious", "effect": "Danger, obstacles"},
    {"idx": 4, "name_en": "Kshema",  "nature": "Auspicious",   "effect": "Wellbeing, peace"},
    {"idx": 5, "name_en": "Pratyak", "nature": "Inauspicious", "effect": "Obstacles, hindrances"},
    {"idx": 6, "name_en": "Sadhaka", "nature": "Auspicious",   "effect": "Accomplishment of goals"},
    {"idx": 7, "name_en": "Vadha",   "nature": "Inauspicious", "effect": "Major obstacles, danger"},
    {"idx": 8, "name_en": "Mitra",   "nature": "Auspicious",   "effect": "Friendly support"},
    {"idx": 9, "name_en": "Ati-Mitra","nature": "Auspicious",  "effect": "Strong support, growth"},
]


def _compute_tara(transit_nakshatra: str, natal_nakshatra: str) -> Dict[str, Any]:
    """
    Compute tara state from transit nakshatra (today's Moon) relative to natal nakshatra.

    Formula: tara_index = ((transit_nak_idx - natal_nak_idx) mod 9) + 1
    """
    try:
        t_idx = _NAKSHATRAS_ORDER.index(transit_nakshatra)
        n_idx = _NAKSHATRAS_ORDER.index(natal_nakshatra)
    except ValueError:
        return {
            "error": f"Unknown nakshatra: transit={transit_nakshatra}, natal={natal_nakshatra}",
        }
    offset = (t_idx - n_idx) % 9
    tara = _TARA_TABLE[offset]
    return {
        "transit_nakshatra": transit_nakshatra,
        "natal_nakshatra":   natal_nakshatra,
        "tara_idx":          tara["idx"],
        "tara_name":         tara["name_en"],
        "nature":            tara["nature"],
        "effect":            tara["effect"],
    }


# ════════════════════════════════════════════════════════════════════════
# DAILY AUSPICIOUS / INAUSPICIOUS YOGA TABLES (classical sources)
# ════════════════════════════════════════════════════════════════════════
#
# These are TITHI-VARA-NAKSHATRA combination yogas, not natal yogas.
# Built from classical muhurta literature.
#
# Sources:
#   - Muhurta Chintamani (Rama Daivajna, 16th c.)
#   - Muhurta Martanda
#   - Brihat Samhita
#   - Phaladeepika muhurta chapters
#
# Each yoga: { name, polarity, formation_rule (text), check_fn, source }

# ── Sarvartha Siddhi Yoga (Vara + Nakshatra) ─────────────────────────
# "Universal accomplishment" — beneficial for all undertakings
# Classical pairs from Muhurta Chintamani
_SARVARTHA_SIDDHI_PAIRS = {
    "Sunday":    ["Pushya", "Hasta", "Uttara Phalguni", "Uttara Ashadha", "Uttara Bhadrapada", "Mula", "Ashwini"],
    "Monday":    ["Rohini", "Mrigashira", "Pushya", "Anuradha", "Shravana"],
    "Tuesday":   ["Ashwini", "Krittika", "Ashlesha", "Uttara Bhadrapada"],
    "Wednesday": ["Rohini", "Anuradha", "Hasta", "Krittika", "Mrigashira"],
    "Thursday":  ["Ashwini", "Punarvasu", "Pushya", "Anuradha", "Revati"],
    "Friday":    ["Ashwini", "Punarvasu", "Anuradha", "Shravana", "Revati"],
    "Saturday":  ["Rohini", "Swati", "Shravana"],
}

# ── Amrit Siddhi Yoga (Vara + Nakshatra) ─────────────────────────────
# Specifically auspicious; "amrit" = nectar of immortality
_AMRIT_SIDDHI_PAIRS = {
    "Sunday":    ["Hasta"],
    "Monday":    ["Mrigashira"],
    "Tuesday":   ["Ashwini"],
    "Wednesday": ["Anuradha"],
    "Thursday":  ["Pushya"],   # Especially potent → Guru Pushya
    "Friday":    ["Revati"],
    "Saturday":  ["Rohini"],
}

# ── Vish Yoga (Vara + Tithi) ─────────────────────────────────────────
# "Poison combination" — generally inauspicious
# Tithis listed are KRISHNA paksha unless noted; some sources include Shukla equivalents
# Standard table from Muhurta Chintamani:
_VISH_YOGA_PAIRS = {
    "Sunday":    [4, 12],   # Chaturthi, Dwadashi
    "Monday":    [6, 11],   # Shashthi, Ekadashi
    "Tuesday":   [7, 12],
    "Wednesday": [2, 7],    # Dwitiya, Saptami
    "Thursday":  [8, 13],   # Ashtami, Trayodashi
    "Friday":    [9, 14],   # Navami, Chaturdashi
    "Saturday":  [7, 14],
}
# Note: Tithi numbering: 1-15 Shukla, 16-30 Krishna (where 16=Pratipada Krishna, etc.)
# Our chart's panchang stores tithi["number"] in 1-30 scale.
# For Vish Yoga, we check whether tithi_in_paksha (1-15) matches the pair.

# ── Mrityu Yoga (Vara + Tithi) ──────────────────────────────────────
# "Death yoga" — most inauspicious; avoid major decisions/journeys
_MRITYU_YOGA_PAIRS = {
    "Sunday":    [12],
    "Monday":    [11],
    "Tuesday":   [5, 10],
    "Wednesday": [3, 8],
    "Thursday":  [6],
    "Friday":    [2, 8],
    "Saturday":  [7],
}

# ── Dwipushkar (results 2x) and Tripushkar (results 3x) ─────────────
# Vara + Tithi + Nakshatra triple
# Auspicious — multiplies effects of actions taken
_DWIPUSHKAR_TITHIS = [2, 7, 12, 17, 22, 27]   # Dwitiya, Saptami, Dwadashi (both pakshas)
_DWIPUSHKAR_VARA = ["Sunday", "Tuesday", "Saturday"]
_DWIPUSHKAR_NAKSHATRAS = ["Vishakha", "Krittika", "Uttara Phalguni", "Uttara Ashadha", "Uttara Bhadrapada", "Purva Bhadrapada"]

_TRIPUSHKAR_TITHIS = [2, 7, 12, 17, 22, 27]
_TRIPUSHKAR_VARA = ["Sunday", "Tuesday", "Saturday"]
_TRIPUSHKAR_NAKSHATRAS = ["Punarvasu", "Uttara Phalguni", "Uttara Ashadha", "Uttara Bhadrapada"]

# ── Guru Pushya & Ravi Pushya ────────────────────────────────────────
# Very rare powerful auspicious days
# Thursday + Pushya = Guru Pushya
# Sunday + Pushya = Ravi Pushya


def _detect_daily_yogas(panchang: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    """
    Given today's panchang, return {auspicious: [...], inauspicious: [...]}.
    Each yoga: {name, polarity, formation_rule, source}
    """
    auspicious: List[Dict[str, Any]] = []
    inauspicious: List[Dict[str, Any]] = []

    tithi = panchang.get("tithi", {})
    vara = panchang.get("vara", {})
    nakshatra = panchang.get("nakshatra", {})

    vara_name = vara.get("name") if isinstance(vara, dict) else None
    nak_name = nakshatra.get("name") if isinstance(nakshatra, dict) else None
    tithi_num_full = tithi.get("number") if isinstance(tithi, dict) else None
    tithi_name = tithi.get("name") if isinstance(tithi, dict) else None
    paksha = tithi.get("paksha") if isinstance(tithi, dict) else None

    # Tithi within paksha: 1-15 (regardless of Shukla/Krishna)
    tithi_in_paksha = None
    if tithi_num_full is not None:
        tithi_in_paksha = ((tithi_num_full - 1) % 15) + 1

    # ── Sarvartha Siddhi ──
    if vara_name and nak_name:
        if nak_name in _SARVARTHA_SIDDHI_PAIRS.get(vara_name, []):
            auspicious.append({
                "name":            "Sarvartha Siddhi Yoga",
                "polarity":        "auspicious",
                "formation_rule": f"{vara_name} + {nak_name} (classical sarvartha siddhi pair)",
                "effect":          "Beneficial for all undertakings; success in any activity initiated today",
                "source":          "Muhurta Chintamani Ch. 5",
            })

    # ── Amrit Siddhi ──
    if vara_name and nak_name:
        if nak_name in _AMRIT_SIDDHI_PAIRS.get(vara_name, []):
            auspicious.append({
                "name":            "Amrit Siddhi Yoga",
                "polarity":        "highly_auspicious",
                "formation_rule": f"{vara_name} + {nak_name}",
                "effect":          "Especially potent for spiritual practice, healing, and learning",
                "source":          "Muhurta Chintamani Ch. 5",
            })

    # ── Guru Pushya / Ravi Pushya ──
    if nak_name == "Pushya":
        if vara_name == "Thursday":
            auspicious.append({
                "name":            "Guru Pushya Yoga",
                "polarity":        "highly_auspicious",
                "formation_rule": "Thursday + Pushya nakshatra",
                "effect":          "One of the most auspicious daily yogas; ideal for new ventures, wealth accumulation, learning",
                "source":          "Muhurta Martanda; Brihat Samhita",
            })
        elif vara_name == "Sunday":
            auspicious.append({
                "name":            "Ravi Pushya Yoga",
                "polarity":        "highly_auspicious",
                "formation_rule": "Sunday + Pushya nakshatra",
                "effect":          "Auspicious for gold, royal favors, leadership initiatives",
                "source":          "Muhurta Martanda",
            })

    # ── Dwipushkar / Tripushkar ──
    if (vara_name in _TRIPUSHKAR_VARA and
            tithi_num_full in _TRIPUSHKAR_TITHIS and
            nak_name in _TRIPUSHKAR_NAKSHATRAS):
        auspicious.append({
            "name":            "Tripushkar Yoga",
            "polarity":        "auspicious",
            "formation_rule": f"{vara_name} + {tithi_name} (tithi {tithi_num_full}) + {nak_name}",
            "effect":          "Results of today's actions multiplied threefold — applies to both gains and losses, so caution alongside opportunity",
            "source":          "Muhurta Chintamani Ch. 6",
        })
    elif (vara_name in _DWIPUSHKAR_VARA and
            tithi_num_full in _DWIPUSHKAR_TITHIS and
            nak_name in _DWIPUSHKAR_NAKSHATRAS):
        auspicious.append({
            "name":            "Dwipushkar Yoga",
            "polarity":        "auspicious",
            "formation_rule": f"{vara_name} + {tithi_name} (tithi {tithi_num_full}) + {nak_name}",
            "effect":          "Results of today's actions doubled — both gains and losses amplified",
            "source":          "Muhurta Chintamani Ch. 6",
        })

    # ── Vish Yoga ──
    if vara_name and tithi_in_paksha and tithi_in_paksha in _VISH_YOGA_PAIRS.get(vara_name, []):
        inauspicious.append({
            "name":            "Vish Yoga",
            "polarity":        "inauspicious",
            "formation_rule": f"{vara_name} + tithi {tithi_in_paksha} ({tithi_name})",
            "effect":          "'Poison combination' — avoid initiating important ventures; financial caution",
            "source":          "Muhurta Chintamani Ch. 7",
        })

    # ── Mrityu Yoga ──
    if vara_name and tithi_in_paksha and tithi_in_paksha in _MRITYU_YOGA_PAIRS.get(vara_name, []):
        inauspicious.append({
            "name":            "Mrityu Yoga",
            "polarity":        "highly_inauspicious",
            "formation_rule": f"{vara_name} + tithi {tithi_in_paksha} ({tithi_name})",
            "effect":          "'Death yoga' — strictly avoid travel, surgery, major contracts; classical tradition recommends restraint",
            "source":          "Muhurta Chintamani Ch. 7",
        })

    return {"auspicious": auspicious, "inauspicious": inauspicious}


# ════════════════════════════════════════════════════════════════════════
# TRANSIT HIGHLIGHTS
# ════════════════════════════════════════════════════════════════════════

def _house_from_sign(target_sign: str, reference_sign: str) -> Optional[int]:
    """Return 1-12 house of target_sign relative to reference_sign as lagna."""
    try:
        t_idx = SIGNS_ORDER.index(target_sign)
        r_idx = SIGNS_ORDER.index(reference_sign)
    except ValueError:
        return None
    return ((t_idx - r_idx) % 12) + 1


def _compute_transit_highlights(today_chart: Dict[str, Any],
                                  natal_chart: Dict[str, Any]) -> Dict[str, Any]:
    """
    Where are today's major planets relative to natal lagna/Moon?
    """
    today_planets = today_chart.get("planets", {})
    natal_lagna = natal_chart.get("lagna", {}).get("sign")
    natal_moon = natal_chart.get("planets", {}).get("Moon", {}).get("sign")

    highlights: Dict[str, Any] = {
        "natal_lagna_sign": natal_lagna,
        "natal_moon_sign":  natal_moon,
        "transit_moon": {
            "sign": today_planets.get("Moon", {}).get("sign"),
            "nakshatra": today_planets.get("Moon", {}).get("nakshatra"),
            "house_from_natal_lagna": _house_from_sign(
                today_planets.get("Moon", {}).get("sign", ""), natal_lagna) if natal_lagna else None,
            "house_from_natal_moon": _house_from_sign(
                today_planets.get("Moon", {}).get("sign", ""), natal_moon) if natal_moon else None,
        },
    }

    # Slow-mover transits (most life-relevant)
    for p in ["Saturn", "Jupiter", "Rahu", "Ketu"]:
        p_data = today_planets.get(p, {})
        p_sign = p_data.get("sign")
        if p_sign:
            highlights[f"transit_{p.lower()}"] = {
                "sign": p_sign,
                "is_retrograde": p_data.get("is_retrograde", False),
                "house_from_natal_lagna": _house_from_sign(p_sign, natal_lagna) if natal_lagna else None,
                "house_from_natal_moon":  _house_from_sign(p_sign, natal_moon) if natal_moon else None,
            }

    # Sade Sati zone check (Saturn in 12/1/2 from natal Moon)
    sat_h = highlights.get("transit_saturn", {}).get("house_from_natal_moon")
    highlights["sade_sati_active"] = sat_h in (12, 1, 2) if sat_h else False
    if sat_h:
        if sat_h == 12:
            highlights["sade_sati_phase"] = "Purva (Rising)"
        elif sat_h == 1:
            highlights["sade_sati_phase"] = "Madhya (Peak)"
        elif sat_h == 2:
            highlights["sade_sati_phase"] = "Uttara (Setting)"
        else:
            highlights["sade_sati_phase"] = None

    return highlights


# ════════════════════════════════════════════════════════════════════════
# ACTIVE DASHA EXTRACTION
# ════════════════════════════════════════════════════════════════════════

def _days_until(end_date_str: str, query_date: date) -> Optional[int]:
    """Days between query_date and end_date string."""
    if not end_date_str:
        return None
    try:
        end_d = datetime.strptime(end_date_str, "%Y-%m-%d").date()
        delta = (end_d - query_date).days
        return delta
    except (ValueError, TypeError):
        return None


def _extract_active_dasha(chart: Dict[str, Any], query_date: date) -> Dict[str, Any]:
    """
    Extract the 5 dasha levels (MD/AD/PD/Sukshma/Prana) active on query_date.

    Note: chart["dashas"] reflects dasha state at the moment of cast_chart's
    runtime. For F9 we use them as-is (the engine internally computes them
    relative to "now"). Future enhancement: parameterize cast_chart with
    `transit_date` to get dasha-as-of-query-date for past/future queries.
    """
    dashas = chart.get("dashas", {})
    result = {}
    for level in ("maha", "antar", "pratyantar", "sukshma", "prana"):
        d = dashas.get(level, {})
        if not isinstance(d, dict):
            continue
        planet = d.get("planet")
        if not planet:
            continue
        days_left = _days_until(d.get("end"), query_date)
        result[level] = {
            "planet": planet,
            "start":  d.get("start"),
            "end":    d.get("end"),
            "days_remaining": days_left,
        }
    return result


# ════════════════════════════════════════════════════════════════════════
# MOOD / HEADLINE COMPUTATION
# ════════════════════════════════════════════════════════════════════════

def _compute_overall_mood(tara: Dict[str, Any],
                            yogas: Dict[str, List[Dict[str, Any]]],
                            sade_sati_active: bool) -> str:
    """
    Synthesize a single mood label from the day's signals.
    Returns: highly_auspicious | auspicious | mixed | challenging | inauspicious
    """
    score = 0

    # Tara contribution
    tara_nature = tara.get("nature", "Mixed")
    if tara_nature == "Auspicious":
        score += 2
    elif tara_nature == "Inauspicious":
        score -= 2
    # Mixed = no change

    # Yoga contributions
    for y in yogas.get("auspicious", []):
        if y["polarity"] == "highly_auspicious":
            score += 3
        else:
            score += 1
    for y in yogas.get("inauspicious", []):
        if y["polarity"] == "highly_inauspicious":
            score -= 3
        else:
            score -= 1

    # Sade Sati drag
    if sade_sati_active:
        score -= 1

    # Banding
    if score >= 4:
        return "highly_auspicious"
    if score >= 2:
        return "auspicious"
    if score >= -1:
        return "mixed"
    if score >= -3:
        return "challenging"
    return "inauspicious"


_MOOD_EMOJI = {
    "highly_auspicious": "✨",
    "auspicious":        "🌟",
    "mixed":             "⚖️",
    "challenging":       "🌫️",
    "inauspicious":      "⚠️",
}


def _compute_headline(query_date: str,
                        tara: Dict[str, Any],
                        yogas: Dict[str, List[Dict[str, Any]]],
                        active_md: Optional[str],
                        active_ad: Optional[str],
                        sade_sati_active: bool,
                        mood: str) -> str:
    """
    One-sentence summary derived from the day's signals.
    """
    parts = []

    # Yoga-driven opener (if a major yoga is firing)
    headliner = None
    for y in yogas.get("auspicious", []):
        if y["polarity"] == "highly_auspicious":
            headliner = f"{y['name']} is active today — {y['effect'].split(';')[0].lower()}."
            break
    if not headliner:
        for y in yogas.get("inauspicious", []):
            if y["polarity"] == "highly_inauspicious":
                headliner = f"{y['name']} is active today — {y['effect'].split(';')[0].lower()}."
                break

    if not headliner:
        # Tara-driven opener
        tara_name = tara.get("tara_name", "Mixed")
        tara_effect = tara.get("effect", "")
        if tara.get("nature") == "Auspicious":
            headliner = f"{tara_name} tara today — {tara_effect.lower()}."
        elif tara.get("nature") == "Inauspicious":
            headliner = f"{tara_name} tara today — {tara_effect.lower()}."
        else:
            headliner = f"{tara_name} tara today — mixed energy day."

    parts.append(headliner)

    # Dasha context (one short note)
    if active_md and active_ad:
        parts.append(f"You're in {active_md} MD / {active_ad} AD.")

    # Sade Sati flag (only if active)
    if sade_sati_active:
        parts.append("Sade Sati phase active.")

    return " ".join(parts)


# ════════════════════════════════════════════════════════════════════════
# PUBLIC API
# ════════════════════════════════════════════════════════════════════════

def handle_birthday_quick(birth: Dict[str, Any],
                            query_date: Optional[str] = None) -> Dict[str, Any]:
    """
    F9 Endpoint: Full daily snapshot for native on query_date.
    """
    # Parse query date
    if query_date:
        try:
            q_date = datetime.strptime(query_date, "%Y-%m-%d").date()
        except ValueError as e:
            return {"error": f"Invalid query_date '{query_date}': {e}",
                     "citations": F9_CITATIONS["quick"]}
    else:
        q_date = date.today()

    # Natal chart (for dashas, lagna, natal moon)
    try:
        natal_chart = cast_chart(
            dob=birth["dob"], time=birth["time"],
            lat=birth["lat"], lon=birth["lon"],
            timezone=birth.get("timezone", "Asia/Kolkata"),
        )
    except Exception as e:
        return {"error": f"Natal chart cast failed: {e}",
                 "citations": F9_CITATIONS["quick"]}

    # Today/query_date chart (for panchang + transit positions)
    try:
        today_chart = cast_chart(
            dob=str(q_date), time="12:00",   # noon for the panchang/transit reference
            lat=birth["lat"], lon=birth["lon"],
            timezone=birth.get("timezone", "Asia/Kolkata"),
        )
    except Exception as e:
        return {"error": f"Query-date chart cast failed: {e}",
                 "citations": F9_CITATIONS["quick"]}

    today_panchang = today_chart.get("panchang", {})
    natal_moon_nak = natal_chart.get("planets", {}).get("Moon", {}).get("nakshatra")
    today_moon_nak = today_panchang.get("nakshatra", {}).get("name") if isinstance(today_panchang.get("nakshatra"), dict) else None

    # Tara state
    tara = (_compute_tara(today_moon_nak, natal_moon_nak)
             if today_moon_nak and natal_moon_nak
             else {"error": "Could not compute tara — missing nakshatra"})

    # Daily yoga detection
    yogas = _detect_daily_yogas(today_panchang)

    # Transit highlights
    transit_h = _compute_transit_highlights(today_chart, natal_chart)
    sade_sati_active = transit_h.get("sade_sati_active", False)

    # Active dasha
    active_dasha = _extract_active_dasha(natal_chart, q_date)

    # Mood + headline
    mood = _compute_overall_mood(tara, yogas, sade_sati_active)
    md_planet = active_dasha.get("maha", {}).get("planet")
    ad_planet = active_dasha.get("antar", {}).get("planet")
    headline = _compute_headline(str(q_date), tara, yogas, md_planet,
                                    ad_planet, sade_sati_active, mood)

    return {
        "success":         True,
        "query_date":      str(q_date),
        "natal_summary": {
            "lagna_sign":      natal_chart.get("lagna", {}).get("sign"),
            "moon_sign":       natal_chart.get("planets", {}).get("Moon", {}).get("sign"),
            "moon_nakshatra":  natal_moon_nak,
        },
        "today_panchang":   today_panchang,
        "active_dasha":     active_dasha,
        "tara_today":       tara,
        "transit_highlights": transit_h,
        "auspicious_yogas_today":   yogas.get("auspicious", []),
        "inauspicious_yogas_today": yogas.get("inauspicious", []),
        "mood":             mood,
        "mood_emoji":       _MOOD_EMOJI.get(mood, "🌟"),
        "headline":         headline,
        "classical_sources": F9_CITATIONS["quick"],
    }


def handle_birthday_headline(birth: Dict[str, Any],
                                query_date: Optional[str] = None) -> Dict[str, Any]:
    """
    F9 Endpoint: One-sentence summary for the day. Trimmed for WhatsApp/push.
    """
    full = handle_birthday_quick(birth, query_date)
    if not full.get("success"):
        return full

    # Compact response
    key_signal = None
    if full.get("auspicious_yogas_today"):
        key_signal = full["auspicious_yogas_today"][0]["name"]
    elif full.get("inauspicious_yogas_today"):
        key_signal = full["inauspicious_yogas_today"][0]["name"]
    elif full.get("tara_today", {}).get("tara_name"):
        key_signal = f"{full['tara_today']['tara_name']} tara"

    return {
        "success":      True,
        "query_date":   full["query_date"],
        "headline":     full["headline"],
        "mood":         full["mood"],
        "mood_emoji":   full["mood_emoji"],
        "key_signal":   key_signal,
    }


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

F9_CITATIONS = {
    "quick": [
        "Brihat Samhita Ch. 99 — Panchanga (five limbs of the day)",
        "Muhurta Chintamani Ch. 5-7 (Rama Daivajna) — Daily auspicious/inauspicious yoga classifications",
        "Muhurta Martanda — Guru Pushya, Ravi Pushya, Sarvartha Siddhi pairs",
        "Phaladeepika Ch. 26 — Saturn 7.5-year cycle context (Sade Sati zones)",
        "BPHS Ch. 46 — Dasha period effects on daily life",
        "Hora Sara — Tara cycle from natal Moon (9-fold tara state)",
    ],
    "headline": [
        "Composite of quick endpoint's classical sources, presented as one-sentence summary",
    ],
}
