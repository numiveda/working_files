"""
timeline_dasha_walker.py — Computes Vimshottari dasha state at any given date.

Vimshottari is the standard 120-year cycle:
  Ketu:    7 yrs
  Venus:   20 yrs
  Sun:     6 yrs
  Moon:    10 yrs
  Mars:    7 yrs
  Rahu:    18 yrs
  Jupiter: 16 yrs
  Saturn:  19 yrs
  Mercury: 17 yrs
  Total:   120 yrs

The cycle starts at birth based on the Moon's natal nakshatra lord.
At any future date, we walk forward to determine which planet is MD/AD/PD.
"""

from typing import Dict, Any, Tuple, Optional
from datetime import datetime, timedelta, date


# Vimshottari dasha sequence and years
DASHA_SEQUENCE = ["Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury"]
DASHA_YEARS = {
    "Ketu": 7, "Venus": 20, "Sun": 6, "Moon": 10, "Mars": 7,
    "Rahu": 18, "Jupiter": 16, "Saturn": 19, "Mercury": 17,
}
TOTAL_CYCLE_YEARS = 120

# Nakshatra-to-MD-lord mapping (each nakshatra has a ruling planet that starts the dasha)
# Repeats every 9 nakshatras: Ketu, Venus, Sun, Moon, Mars, Rahu, Jupiter, Saturn, Mercury
NAKSHATRA_LORDS_BY_INDEX = {
    1: "Ketu",    2: "Venus",   3: "Sun",
    4: "Moon",    5: "Mars",    6: "Rahu",
    7: "Jupiter", 8: "Saturn",  9: "Mercury",
    10: "Ketu",   11: "Venus",  12: "Sun",
    13: "Moon",   14: "Mars",   15: "Rahu",
    16: "Jupiter",17: "Saturn", 18: "Mercury",
    19: "Ketu",   20: "Venus",  21: "Sun",
    22: "Moon",   23: "Mars",   24: "Rahu",
    25: "Jupiter",26: "Saturn", 27: "Mercury",
}

# Each nakshatra is 13°20' = 13.333° wide; Moon's progress within nakshatra determines
# how much of the first MD is already "consumed" at birth
NAKSHATRA_DEG = 13.333333


def _years_to_days(years: float) -> float:
    """Convert decimal years to days (standard 365.25)."""
    return years * 365.25


def _date_to_julian_days_since_birth(d: datetime, birth: datetime) -> float:
    """Days between two dates."""
    delta = d - birth
    return delta.total_seconds() / 86400.0


def compute_dasha_start_offset(moon_longitude: float) -> Tuple[str, float]:
    """
    Given Moon's sidereal longitude at birth, return:
      (starting_md_lord, days_already_consumed_in_that_md_at_birth)
    """
    nakshatra_idx = int(moon_longitude / NAKSHATRA_DEG) + 1
    nakshatra_idx = max(1, min(27, nakshatra_idx))
    md_lord = NAKSHATRA_LORDS_BY_INDEX[nakshatra_idx]

    # Position within nakshatra (0 - 13.333°)
    within_nak = moon_longitude - (nakshatra_idx - 1) * NAKSHATRA_DEG
    # Fraction already consumed
    fraction_consumed = within_nak / NAKSHATRA_DEG
    md_years = DASHA_YEARS[md_lord]
    days_already_consumed = _years_to_days(md_years * fraction_consumed)

    return md_lord, days_already_consumed


def _walk_md_sequence(start_md: str):
    """Yield (md_lord, md_years) starting from start_md, cycling forward."""
    start_idx = DASHA_SEQUENCE.index(start_md)
    for offset in range(len(DASHA_SEQUENCE) * 3):  # cover 3 cycles = 360 years
        idx = (start_idx + offset) % len(DASHA_SEQUENCE)
        lord = DASHA_SEQUENCE[idx]
        yield lord, DASHA_YEARS[lord]


def _md_at_offset_days(start_md: str, days_consumed_at_birth: float, target_days_from_birth: float):
    """
    Walk MDs forward from birth. Return (current_md_lord, days_into_current_md, days_remaining_in_current_md).
    """
    # Effective days from start of the *natal MD* (which started before birth)
    days_from_start_of_md = days_consumed_at_birth + target_days_from_birth

    elapsed = 0.0
    for lord, years in _walk_md_sequence(start_md):
        md_days = _years_to_days(years)
        if elapsed + md_days > days_from_start_of_md:
            days_into = days_from_start_of_md - elapsed
            return lord, days_into, md_days - days_into
        elapsed += md_days
    # Should never reach here within 360 years
    return start_md, 0.0, 0.0


def _ad_at_offset_within_md(md_lord: str, days_into_md: float):
    """
    Within the given MD, find current AD.
    AD durations within an MD are proportional: AD_X = MD_years * (years_of_X / 120).
    Sub-period sequence starts with the MD's own lord.
    """
    md_years = DASHA_YEARS[md_lord]
    md_total_days = _years_to_days(md_years)
    start_idx = DASHA_SEQUENCE.index(md_lord)

    elapsed = 0.0
    for offset in range(len(DASHA_SEQUENCE)):
        ad_lord = DASHA_SEQUENCE[(start_idx + offset) % len(DASHA_SEQUENCE)]
        ad_years_in_md = (md_years * DASHA_YEARS[ad_lord]) / TOTAL_CYCLE_YEARS
        ad_days = _years_to_days(ad_years_in_md)
        if elapsed + ad_days > days_into_md:
            days_into_ad = days_into_md - elapsed
            return ad_lord, days_into_ad, ad_days - days_into_ad
        elapsed += ad_days
    return md_lord, 0.0, 0.0


def _pd_at_offset_within_ad(md_lord: str, ad_lord: str, days_into_ad: float):
    """Pratyantardasha within AD."""
    md_years = DASHA_YEARS[md_lord]
    ad_years_in_md = (md_years * DASHA_YEARS[ad_lord]) / TOTAL_CYCLE_YEARS
    ad_total_days = _years_to_days(ad_years_in_md)

    start_idx = DASHA_SEQUENCE.index(ad_lord)
    elapsed = 0.0
    for offset in range(len(DASHA_SEQUENCE)):
        pd_lord = DASHA_SEQUENCE[(start_idx + offset) % len(DASHA_SEQUENCE)]
        pd_years_in_ad = (ad_years_in_md * DASHA_YEARS[pd_lord]) / TOTAL_CYCLE_YEARS
        pd_days = _years_to_days(pd_years_in_ad)
        if elapsed + pd_days > days_into_ad:
            return pd_lord
        elapsed += pd_days
    return ad_lord


def get_dasha_state(moon_longitude: float, birth_date: datetime, target_date: datetime) -> Dict[str, str]:
    """
    Main entry: return {md, ad, pd} for a given target_date.
    """
    md_lord, days_already_consumed = compute_dasha_start_offset(moon_longitude)
    delta_days = (target_date - birth_date).total_seconds() / 86400.0

    md, days_into_md, _ = _md_at_offset_days(md_lord, days_already_consumed, delta_days)
    ad, days_into_ad, _ = _ad_at_offset_within_md(md, days_into_md)
    pd = _pd_at_offset_within_ad(md, ad, days_into_ad)

    return {"md": md, "ad": ad, "pd": pd}


def get_dasha_state_simple(natal_chart: dict, target_date: datetime) -> Dict[str, str]:
    """
    Wrapper that reads Moon longitude from natal_chart.
    Assumes natal_chart has 'birth_datetime' and Moon longitude available.
    """
    moon_lon = natal_chart.get("planets", {}).get("Moon", {}).get("longitude", 0.0)
    birth_str = natal_chart.get("birth_datetime")
    if birth_str:
        try:
            birth = datetime.fromisoformat(birth_str)
        except (ValueError, TypeError):
            birth = datetime.now()
    else:
        birth = datetime.now()
    return get_dasha_state(moon_lon, birth, target_date)
