"""
muhurta_pro.py — numiVeda Kaaliyo Astro Engine — Module C3 (Muhurta Pro)

8 endpoints for classical Vedic electional astrology — finding/scoring
auspicious moments for major undertakings.

Endpoints:
    handle_profile             — Master analysis for any moment + purpose
    handle_check_moment        — Is THIS moment good for X? (yes/no/qualified)
    handle_find_window         — Find next favorable window for X
    handle_marriage_muhurta    — Marriage-specific scoring
    handle_business_muhurta    — Business inception scoring
    handle_travel_muhurta      — Travel/yatra scoring
    handle_property_muhurta    — Property/griha pravesh scoring
    handle_medical_muhurta     — Medical procedure/treatment scoring

Approach (classical Muhurta Chintamani):
    Cast chart for the candidate moment at the location.
    Score against 6 components: weekday, tithi, nakshatra, lagna,
    moon_strength, avoidance_clear. Weights per purpose. Output 0-100.
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta

from astro_helpers import (
    extract_chart_essentials,
    get_chart,
    SIGNS_ORDER,
    SIGN_TO_LORD,
)

from muhurta_data import (
    PURPOSE_RULES,
    WEEKDAY_SUITABILITY, DAY_TO_PLANET, DAY_NAMES,
    TITHI_CLASS, TITHI_CLASS_SUITABILITY,
    TITHI_AVOID_FOR_PURPOSE,
    AMAVASYA_TITHI, PURNIMA_TITHI,
    NAKSHATRA_SUITABILITY,
    LAGNA_SUITABILITY,
    AVOID_YOGAS_DEFINITIONS,
    SCORE_INTERPRETATION,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# MOMENT CHART CASTING
# ════════════════════════════════════════════════════════════════════════

def _cast_moment_chart(check_datetime: str, lat: float, lon: float,
                       timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Cast a chart for a candidate moment (datetime in ISO format)."""
    dt = datetime.fromisoformat(check_datetime)
    return get_chart(
        dob=dt.date().isoformat(),
        time=dt.strftime("%H:%M"),
        lat=lat, lon=lon, timezone=timezone,
    )


def _absolute_longitude(sign: str, degree: float) -> float:
    if sign not in SIGNS_ORDER:
        return 0.0
    return SIGNS_ORDER.index(sign) * 30.0 + float(degree)


# ════════════════════════════════════════════════════════════════════════
# TITHI COMPUTATION — from Sun and Moon longitudes
# Tithi = floor((Moon_lon - Sun_lon) mod 360 / 12) + 1, range 1-30
# ════════════════════════════════════════════════════════════════════════

def _compute_tithi(chart_raw: Dict[str, Any]) -> int:
    """Return tithi number 1-30 from chart."""
    planets = chart_raw.get("planets", {})
    sun = planets.get("Sun", {})
    moon = planets.get("Moon", {})
    if not (sun and moon):
        return 0
    sun_lon = _absolute_longitude(sun.get("sign", "Aries"), sun.get("degree", 0))
    moon_lon = _absolute_longitude(moon.get("sign", "Aries"), moon.get("degree", 0))
    delta = (moon_lon - sun_lon) % 360
    tithi = int(delta // 12) + 1
    return max(1, min(30, tithi))


def _tithi_name(tithi: int) -> str:
    """Return classical tithi name (Shukla/Krishna + number)."""
    if tithi <= 15:
        return f"Shukla {tithi}" + (" (Purnima)" if tithi == 15 else "")
    else:
        krishna_num = tithi - 15
        return f"Krishna {krishna_num}" + (" (Amavasya)" if tithi == 30 else "")


# ════════════════════════════════════════════════════════════════════════
# SCORING COMPONENTS
# ════════════════════════════════════════════════════════════════════════

def _score_weekday(dt: datetime, purpose: str) -> Dict[str, Any]:
    weekday = dt.weekday()
    score = WEEKDAY_SUITABILITY.get(purpose, WEEKDAY_SUITABILITY["general"]).get(weekday, 50)
    return {
        "day_number":  weekday,
        "day_name":    DAY_NAMES[weekday],
        "day_planet":  DAY_TO_PLANET[weekday],
        "score":       score,
    }


def _score_tithi(tithi: int, purpose: str) -> Dict[str, Any]:
    tclass = TITHI_CLASS.get(tithi, "Nanda")
    base_score = TITHI_CLASS_SUITABILITY.get(purpose,
                    TITHI_CLASS_SUITABILITY["general"]).get(tclass, 50)
    # Apply specific avoid list
    if tithi in TITHI_AVOID_FOR_PURPOSE.get(purpose, []):
        base_score = min(base_score, 30)
    return {
        "tithi":       tithi,
        "tithi_name":  _tithi_name(tithi),
        "tithi_class": tclass,
        "score":       base_score,
        "in_avoid_list": tithi in TITHI_AVOID_FOR_PURPOSE.get(purpose, []),
    }


def _score_nakshatra(moon_nakshatra: str, purpose: str) -> Dict[str, Any]:
    score = NAKSHATRA_SUITABILITY.get(purpose,
                NAKSHATRA_SUITABILITY["general"]).get(moon_nakshatra, 50)
    return {
        "moon_nakshatra": moon_nakshatra,
        "score":          score,
    }


def _score_lagna(lagna_sign: str, purpose: str) -> Dict[str, Any]:
    score = LAGNA_SUITABILITY.get(purpose,
                LAGNA_SUITABILITY["general"]).get(lagna_sign, 50)
    return {
        "lagna_sign":  lagna_sign,
        "score":       score,
    }


def _score_moon_strength(essentials: Dict[str, Any]) -> Dict[str, Any]:
    """
    Moon strength = dignity + house placement + not-combust + pakshabala.
    Returns 0-100 score.
    """
    moon = essentials.get("planets", {}).get("Moon", {})
    if not moon:
        return {"score": 50, "reason": "Moon data not available"}

    score = 50
    factors: List[str] = []

    dignity = moon.get("dignity", "")
    if dignity == "exalted":
        score += 25; factors.append("Moon exalted (+25)")
    elif dignity in ("own", "moolatrikona"):
        score += 20; factors.append(f"Moon in {dignity} sign (+20)")
    elif dignity == "friend":
        score += 10; factors.append("Moon in friend's sign (+10)")
    elif dignity == "neutral":
        factors.append("Moon in neutral sign (no change)")
    elif dignity in ("enemy", "great_enemy"):
        score -= 10; factors.append(f"Moon in {dignity} sign (-10)")
    elif dignity == "debilitated":
        score -= 20; factors.append("Moon debilitated (-20)")

    house = moon.get("house")
    if house in (1, 4, 7, 10):  # kendra
        score += 10; factors.append("Moon in kendra (+10)")
    elif house in (5, 9):  # trikona
        score += 10; factors.append("Moon in trikona (+10)")
    elif house in (6, 8, 12):
        score -= 15; factors.append(f"Moon in dushthana H{house} (-15)")

    if moon.get("is_combust"):
        score -= 20; factors.append("Moon combust (-20)")

    # Pakshabala: waxing strong, waning weak
    # Approx via tithi already computed elsewhere; we don't have it here
    # We approximate via degree from Sun if Sun data present
    sun = essentials.get("planets", {}).get("Sun", {})
    if isinstance(sun, dict) and sun.get("sign") and moon.get("sign"):
        sun_lon = _absolute_longitude(sun["sign"], sun.get("degree", 0))
        moon_lon = _absolute_longitude(moon["sign"], moon.get("degree", 0))
        delta = (moon_lon - sun_lon) % 360
        if 0 < delta <= 180:
            score += 5; factors.append("Moon waxing (+5)")
        else:
            score -= 5; factors.append("Moon waning (-5)")

    score = max(0, min(100, score))
    return {
        "score":   score,
        "moon_sign": moon.get("sign"),
        "moon_house": house,
        "moon_dignity": dignity,
        "factors": factors,
    }


def _score_avoidance_clear(tithi: int, purpose: str, dt: datetime) -> Dict[str, Any]:
    """Returns high score if NO classical avoidances are present."""
    flags: List[str] = []
    if tithi == AMAVASYA_TITHI and purpose != "spiritual":
        flags.append("Amavasya (new moon)")
    if tithi in (4, 9, 14, 19, 24, 29):
        flags.append("Rikta tithi")
    # Bhadra detection: simplified — 2nd half of 4th, 8th, 11th, 15th tithi
    # Full Bhadra requires karana computation; engine flags conservatively
    if tithi in TITHI_AVOID_FOR_PURPOSE.get(purpose, []):
        flags.append(f"Tithi {tithi} in purpose-specific avoid list")

    score = 100 - (25 * len(flags))
    score = max(0, score)
    return {
        "score":          score,
        "flags":          flags,
        "flag_count":     len(flags),
        "avoid_definitions": AVOID_YOGAS_DEFINITIONS,
    }


# ════════════════════════════════════════════════════════════════════════
# COMPOSITE SCORING
# ════════════════════════════════════════════════════════════════════════

def _composite_score(scores: Dict[str, Any], purpose: str) -> Dict[str, Any]:
    """Apply purpose weights to component scores, returns 0-100."""
    weights = PURPOSE_RULES.get(purpose, PURPOSE_RULES["general"])
    total_weight = sum(weights.values())  # ~100
    weighted_sum = 0.0
    breakdown: List[Dict[str, Any]] = []
    for component, weight in weights.items():
        comp_score = scores.get(component, {}).get("score", 50)
        contribution = (comp_score * weight) / 100  # weighted out of 'weight'
        weighted_sum += contribution
        breakdown.append({
            "component":   component,
            "weight":      weight,
            "score":       comp_score,
            "contribution": round(contribution, 2),
        })
    final = (weighted_sum / total_weight) * 100  # normalize to 0-100
    return {
        "final_score": round(final, 1),
        "breakdown":   breakdown,
        "weight_used": weights,
    }


def _interpret_score(score: float) -> Dict[str, str]:
    if score >= 85:    label = "excellent"
    elif score >= 70:  label = "good"
    elif score >= 55:  label = "acceptable"
    elif score >= 40:  label = "marginal"
    else:              label = "avoid"
    return {
        "label":          label,
        "interpretation": SCORE_INTERPRETATION[label],
    }


# ════════════════════════════════════════════════════════════════════════
# CORE SCORING — Unified entry per purpose
# ════════════════════════════════════════════════════════════════════════

def _score_moment_for_purpose(check_datetime: str, lat: float, lon: float,
                              timezone: str, purpose: str) -> Dict[str, Any]:
    """Run all component scores for a given moment + purpose."""
    chart_raw = _cast_moment_chart(check_datetime, lat, lon, timezone)
    essentials = extract_chart_essentials(chart_raw)
    dt = datetime.fromisoformat(check_datetime)
    tithi = _compute_tithi(chart_raw)

    scores = {
        "weekday":         _score_weekday(dt, purpose),
        "tithi":           _score_tithi(tithi, purpose),
        "nakshatra":       _score_nakshatra(essentials.get("moon_nakshatra", ""), purpose),
        "lagna":           _score_lagna(essentials.get("lagna_sign", ""), purpose),
        "moon_strength":   _score_moon_strength(essentials),
        "avoidance_clear": _score_avoidance_clear(tithi, purpose, dt),
    }
    composite = _composite_score(scores, purpose)
    interp = _interpret_score(composite["final_score"])

    return {
        "check_datetime": check_datetime,
        "purpose":        purpose,
        "lagna":          essentials.get("lagna_sign"),
        "moon":           {"sign": essentials.get("moon_sign"),
                            "nakshatra": essentials.get("moon_nakshatra"),
                            "house": essentials.get("moon_house")},
        "tithi":          tithi,
        "tithi_name":     _tithi_name(tithi),
        "component_scores": scores,
        "composite":      composite,
        "verdict":        interp["label"],
        "interpretation": interp["interpretation"],
    }


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT HANDLERS
# ════════════════════════════════════════════════════════════════════════

def handle_check_moment(check_datetime: str, lat: float, lon: float,
                        timezone: str = "Asia/Kolkata",
                        purpose: str = "general") -> Dict[str, Any]:
    """Endpoint 2: Score this moment for the stated purpose."""
    if purpose not in PURPOSE_RULES:
        purpose = "general"
    result = _score_moment_for_purpose(check_datetime, lat, lon, timezone, purpose)
    result["citation"] = CLASSICAL_CITATIONS["muhurta"]
    return result


def handle_find_window(check_datetime: str, lat: float, lon: float,
                       timezone: str = "Asia/Kolkata",
                       purpose: str = "general",
                       search_days: int = 30,
                       min_score: float = 70.0) -> Dict[str, Any]:
    """
    Endpoint 3: Search forward up to `search_days` days for first window
    scoring >= `min_score`. Samples at 6-hour intervals (4 per day).
    """
    if purpose not in PURPOSE_RULES:
        purpose = "general"
    if search_days > 60:
        search_days = 60  # cap
    start_dt = datetime.fromisoformat(check_datetime)
    candidates: List[Dict[str, Any]] = []
    best_so_far: Optional[Dict[str, Any]] = None

    # Sample at 6-hour intervals
    sample_count = search_days * 4
    for i in range(sample_count):
        candidate_dt = start_dt + timedelta(hours=i * 6)
        candidate_iso = candidate_dt.isoformat()
        try:
            score_result = _score_moment_for_purpose(
                candidate_iso, lat, lon, timezone, purpose)
        except Exception as e:
            continue

        final = score_result["composite"]["final_score"]
        compact = {
            "datetime":   candidate_iso,
            "score":      final,
            "verdict":    score_result["verdict"],
            "lagna":      score_result["lagna"],
            "nakshatra":  score_result["moon"]["nakshatra"],
            "tithi":      score_result["tithi"],
        }
        if best_so_far is None or final > best_so_far["score"]:
            best_so_far = compact
        if final >= min_score:
            candidates.append(compact)
            if len(candidates) >= 5:  # cap on returned hits
                break

    return {
        "search_start":    check_datetime,
        "search_days":     search_days,
        "min_score":       min_score,
        "purpose":         purpose,
        "samples_checked": min(sample_count, len(candidates) * 24 + 24),  # approx
        "candidates_found":candidates,
        "best_overall":    best_so_far,
        "interpretation": (
            f"Found {len(candidates)} windows scoring >= {min_score} in next {search_days} days"
            if candidates else
            f"No moments meet threshold {min_score}. Best window: {best_so_far['datetime']} (score {best_so_far['score']})"
            if best_so_far else
            "No moments evaluable"
        ),
        "citation":        CLASSICAL_CITATIONS["muhurta"],
    }


def handle_marriage_muhurta(check_datetime: str, lat: float, lon: float,
                            timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Endpoint 4: Marriage-specific scoring."""
    r = _score_moment_for_purpose(check_datetime, lat, lon, timezone, "marriage")
    r["citation"] = CLASSICAL_CITATIONS["marriage"]
    r["additional_classical_rules"] = [
        "Avoid Mala-masa, Kshaya-masa, Adhika-masa",
        "Bride's 7th lord and groom's 7th lord both strong",
        "Avoid eclipse periods (15 days before/after)",
        "Moon strong and well-placed at muhurta moment",
        "Venus (groom's karaka) and Jupiter (bride's karaka) not afflicted",
        "Avoid Bhadra Karana, Vyatipata Yoga, Vaidhriti Yoga",
        "Favor Friday, Wednesday, Thursday (Venus, Mercury, Jupiter days)",
    ]
    return r


def handle_business_muhurta(check_datetime: str, lat: float, lon: float,
                            timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Endpoint 5: Business inception scoring."""
    r = _score_moment_for_purpose(check_datetime, lat, lon, timezone, "business")
    r["citation"] = CLASSICAL_CITATIONS["business"]
    r["additional_classical_rules"] = [
        "Mercury strong and well-placed for trade",
        "Jupiter favorable for ethical/long-term business",
        "2nd house (wealth), 10th house (karma/profession) strong",
        "Avoid Saturn aspects unless aiming for slow, long-term commitment",
        "Favor Wednesday, Thursday (Mercury, Jupiter days)",
        "Avoid Bhadra karana",
    ]
    return r


def handle_travel_muhurta(check_datetime: str, lat: float, lon: float,
                          timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Endpoint 6: Travel/yatra scoring."""
    r = _score_moment_for_purpose(check_datetime, lat, lon, timezone, "travel")
    r["citation"] = CLASSICAL_CITATIONS["travel"]
    r["additional_classical_rules"] = [
        "Movable signs (Aries/Cancer/Libra/Capricorn) favored for departure",
        "Moon strong and in friendly sign",
        "Mercury and Venus strong (for safe transit)",
        "Avoid Mars in 7th or 8th (accident risk)",
        "Favor Monday, Wednesday, Sunday (Moon, Mercury, Sun)",
        "Avoid Tuesday and Saturday for journeys",
        "Direction-specific: avoid Disha-Shoola for that day",
    ]
    return r


def handle_property_muhurta(check_datetime: str, lat: float, lon: float,
                            timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Endpoint 7: Property/Griha Pravesh scoring."""
    r = _score_moment_for_purpose(check_datetime, lat, lon, timezone, "property")
    r["citation"] = CLASSICAL_CITATIONS["property"]
    r["additional_classical_rules"] = [
        "4th house (home), 11th house (gains) strong",
        "Jupiter aspecting Lagna or 4th = blessings on home",
        "Mars in 4th = avoid (unless own/exalted)",
        "Venus strong for property comfort",
        "Favor Thursday, Friday, Monday",
        "Fixed signs favored for property stability",
    ]
    return r


def handle_medical_muhurta(check_datetime: str, lat: float, lon: float,
                           timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Endpoint 8: Medical procedure/treatment scoring."""
    r = _score_moment_for_purpose(check_datetime, lat, lon, timezone, "medical")
    r["citation"] = CLASSICAL_CITATIONS["medical"]
    r["additional_classical_rules"] = [
        "Lagna and Moon NOT in the sign ruling body part to be operated",
        "Moon strong (Ojas = vitality)",
        "Mars-Saturn-Rahu away from Lagna",
        "Shatabhisha nakshatra particularly favorable for healing (Varuna)",
        "Avoid Sandhi (junction) of nakshatras",
        "Favor Monday, Wednesday, Thursday for treatments",
        "Surgery: avoid Saturday and waning moon",
    ]
    return r


def handle_profile(check_datetime: str, lat: float, lon: float,
                   timezone: str = "Asia/Kolkata",
                   purpose: str = "general") -> Dict[str, Any]:
    """
    Endpoint 1 (MASTER): Full moment analysis.
    Returns the score for the requested purpose + comparison across all 6 purposes.
    """
    if purpose not in PURPOSE_RULES:
        purpose = "general"
    primary = _score_moment_for_purpose(check_datetime, lat, lon, timezone, purpose)

    # Score across all purposes for comparison
    all_purposes: Dict[str, Any] = {}
    for p in PURPOSE_RULES.keys():
        try:
            r = _score_moment_for_purpose(check_datetime, lat, lon, timezone, p)
            all_purposes[p] = {
                "score":   r["composite"]["final_score"],
                "verdict": r["verdict"],
            }
        except Exception as e:
            all_purposes[p] = {"error": str(e)}

    # Headlines
    headlines: List[str] = []
    headlines.append(
        f"Primary purpose [{purpose}]: {primary['composite']['final_score']}/100 ({primary['verdict']})"
    )
    headlines.append(
        f"Lagna: {primary['lagna']}, Moon: {primary['moon']['sign']} ({primary['moon']['nakshatra']}), Tithi: {primary['tithi_name']}"
    )
    avoid_flags = primary['component_scores']['avoidance_clear']['flags']
    if avoid_flags:
        headlines.append(f"⚠️ Avoidance flags active: {', '.join(avoid_flags)}")

    return {
        "check_datetime":       check_datetime,
        "location":             {"lat": lat, "lon": lon, "timezone": timezone},
        "headlines":            headlines,
        "primary_analysis":     primary,
        "all_purposes_summary": all_purposes,
        "method":               "Composite weighted scoring across weekday, tithi, nakshatra, lagna, moon strength, avoidance flags — weights per purpose per Muhurta Chintamani",
        "citation":             CLASSICAL_CITATIONS["muhurta"],
    }
