"""
varshaphala_data.py — Tajik (Persian-Indian) Varshaphala reference data.

Phase C — Module C2 (Varshaphala / Annual Chart).

Public catalogs:
    SAHAMS                       — 20 most-used Sahams (Hellenistic-Tajik Lots)
    TAJIK_ASPECTS_ORBS           — Orb tolerances for Ithasala/Eesharafa/Mutthasila
    YEAR_LORD_CANDIDATES         — 5 classical candidates for Varshesha
    MUNTHA_HOUSE_RESULTS         — Muntha through 12 houses of solar return
    MUDDA_DASHA_ORDER            — Vimshottari-style order within solar year
    MUDDA_DASHA_DURATIONS        — Year-fractions per planet for mudda
    PANCHA_VARGIYA_WEIGHTS       — Year-lord strength components
    CLASSICAL_CITATIONS

Primary sources: Tajik Neelakanthi (~16th c.), Varshaphala Paddhati,
Phaladeepika Ch. 8, classical Sahams tradition (Greek-Persian-Indian synthesis).
All public domain.
"""

from typing import Dict, List


# ════════════════════════════════════════════════════════════════════════
# SAHAMS — Hellenistic-Tajik Lots (50 catalogued; engine uses top 20-ish)
# Each saham has a formula: typically (A + B - C)
# A, B, C are planetary longitudes or chart angles
# When formula yields negative, add 360. When > 360, subtract 360.
# Source: Tajik Neelakanthi (canonical), Varshaphala Paddhati
# ════════════════════════════════════════════════════════════════════════

# Formula reference: planetary longitudes used as A/B/C
# Special token: "Lagna" = ascendant longitude
# Each saham: name, formula_day (day birth), formula_night (night birth), domain
SAHAMS: Dict[str, Dict[str, str]] = {
    "Punya": {
        "formula_day":   "Moon + Lagna - Sun",
        "formula_night": "Sun + Lagna - Moon",
        "domain":        "merit, virtue, religious actions, dharmic gains",
    },
    "Vidya": {
        "formula_day":   "Saturn + Lagna - Mars",
        "formula_night": "Mars + Lagna - Saturn",
        "domain":        "education, learning, scholarship, intellectual mastery",
    },
    "Yashas": {
        "formula_day":   "Jupiter + Lagna - Sun",
        "formula_night": "Sun + Lagna - Jupiter",
        "domain":        "fame, reputation, glory, public recognition",
    },
    "Mitra": {
        "formula_day":   "Saturn + Jupiter - Lagna",
        "formula_night": "Jupiter + Saturn - Lagna",
        "domain":        "friends, allies, supportive networks",
    },
    "Mahatmya": {
        "formula_day":   "Jupiter + Mars - Saturn",
        "formula_night": "Mars + Jupiter - Saturn",
        "domain":        "greatness, dignity, elevated status",
    },
    "Asha": {
        "formula_day":   "Mercury + Lagna - Saturn",
        "formula_night": "Saturn + Lagna - Mercury",
        "domain":        "hope, aspirations, future plans",
    },
    "Samartha": {
        "formula_day":   "Lagna + Mars - lord_of_lagna",
        "formula_night": "Lagna + Mars - lord_of_lagna",
        "domain":        "strength, capability, prowess",
    },
    "Bhratru": {
        "formula_day":   "Jupiter + Saturn - Mars",
        "formula_night": "Mars + Saturn - Jupiter",
        "domain":        "siblings, brothers, courage",
    },
    "Gaurava": {
        "formula_day":   "Jupiter + Moon - Sun",
        "formula_night": "Sun + Moon - Jupiter",
        "domain":        "dignity, honor, paternal lineage prestige",
    },
    "Pitru": {
        "formula_day":   "Saturn + Sun - Lagna",
        "formula_night": "Sun + Saturn - Lagna",
        "domain":        "father, paternal karma, ancestors",
    },
    "Rajya": {
        "formula_day":   "Saturn + Mercury - Mars",
        "formula_night": "Mars + Mercury - Saturn",
        "domain":        "kingdom, authority, governance, power",
    },
    "Matru": {
        "formula_day":   "Moon + Venus - Saturn",
        "formula_night": "Venus + Moon - Saturn",
        "domain":        "mother, maternal blessings, nurture",
    },
    "Putra": {
        "formula_day":   "Jupiter + Saturn - Moon",
        "formula_night": "Moon + Saturn - Jupiter",
        "domain":        "children, progeny, creative offspring",
    },
    "Jeeva": {
        "formula_day":   "Saturn + Jupiter - Mars",
        "formula_night": "Mars + Jupiter - Saturn",
        "domain":        "life force, vitality, longevity",
    },
    "Karma": {
        "formula_day":   "Mars + Mercury - Sun",
        "formula_night": "Sun + Mercury - Mars",
        "domain":        "work, profession, action in the world",
    },
    "Roga": {
        "formula_day":   "Lagna + Mercury - Sun",
        "formula_night": "Sun + Mercury - Lagna",
        "domain":        "disease, illness, health weakness points",
    },
    "Kali": {
        "formula_day":   "Jupiter + Mars - Lagna",
        "formula_night": "Mars + Jupiter - Lagna",
        "domain":        "discord, strife, periods of difficulty",
    },
    "Sastra": {
        "formula_day":   "Jupiter + Saturn - Mercury",
        "formula_night": "Mercury + Saturn - Jupiter",
        "domain":        "scriptures, sacred knowledge, philosophical mastery",
    },
    "Vivaha": {
        "formula_day":   "Venus + Lagna - Saturn",
        "formula_night": "Saturn + Lagna - Venus",
        "domain":        "marriage, partnership, marital harmony",
    },
    "Vanik": {
        "formula_day":   "Mercury + Jupiter - Mars",
        "formula_night": "Mars + Jupiter - Mercury",
        "domain":        "trade, commerce, business success",
    },
}


# ════════════════════════════════════════════════════════════════════════
# TAJIK ASPECTS — Orb tolerances (in degrees)
# Different from Vedic aspects: Tajik uses Western-style orbs
# Source: Tajik Neelakanthi Ch. on Yogas
# ════════════════════════════════════════════════════════════════════════

TAJIK_ASPECTS_ORBS: Dict[str, Dict[str, float]] = {
    "conjunction": {"angle": 0.0,   "orb": 7.0,  "domain": "merging of significations"},
    "sextile":     {"angle": 60.0,  "orb": 5.0,  "domain": "supportive harmony"},
    "square":      {"angle": 90.0,  "orb": 6.0,  "domain": "tension, action"},
    "trine":       {"angle": 120.0, "orb": 6.0,  "domain": "flow, ease"},
    "opposition":  {"angle": 180.0, "orb": 7.0,  "domain": "polarization, balance through tension"},
}

# Tajik specialty yogas based on applying/separating motion
TAJIK_YOGAS: Dict[str, Dict[str, str]] = {
    "Ithasala": {
        "type":     "applying conjunction/aspect",
        "rule":     "Slower planet at lower degree, faster planet approaching it",
        "domain":   "yoga is FORMING — future fruition, matter will manifest",
        "favorable":"YES — outcome will materialize",
    },
    "Eesharafa": {
        "type":     "separating conjunction/aspect",
        "rule":     "Faster planet has already passed the slower; separation in progress",
        "domain":   "yoga is SEPARATING — past influence, matter already partly played out",
        "favorable":"PARTIAL — completed/past matters; not for new initiatives",
    },
    "Mutthasila": {
        "type":     "mutual signification (similar to Parashari parivartana but degree-based)",
        "rule":     "Two planets in mutual aspect/sign exchange within orb",
        "domain":   "deeply connected significations — natives' lives intertwined with these matters",
        "favorable":"YES — strong yoga of mutual support",
    },
    "Naktha": {
        "type":     "intermediary planet aspect transfer",
        "rule":     "A third planet aspects both yoga participants, transferring influence",
        "domain":   "the third planet acts as intermediary/messenger",
        "favorable":"DEPENDS — based on third planet's nature",
    },
    "Yamaya": {
        "type":     "frustrated yoga",
        "rule":     "Two planets approaching aspect but a third intervenes by aspect before completion",
        "domain":   "yoga FRUSTRATED — third party disrupts the intended outcome",
        "favorable":"NO — outcome blocked",
    },
}


# ════════════════════════════════════════════════════════════════════════
# YEAR LORD (VARSHESHA) — 5 classical candidates
# The strongest by Pancha-Vargiya Bala becomes Varshesha
# Source: Tajik Neelakanthi Ch. 12
# ════════════════════════════════════════════════════════════════════════

YEAR_LORD_CANDIDATES: List[str] = [
    "muntha_lord",           # Lord of the sign Muntha occupies
    "solar_return_lagna_lord",  # Lord of solar return Lagna
    "solar_return_sun_lord",    # Lord of solar return Sun sign
    "solar_return_moon_lord",   # Lord of solar return Moon sign
    "day_lord",              # Weekday lord on solar return day
]

# Pancha-Vargiya Bala components (simplified for engine)
PANCHA_VARGIYA_WEIGHTS: Dict[str, int] = {
    "kshetra":   5,   # own sign / exalted = 5, friend = 4, neutral = 3, enemy = 2, debilitated = 1
    "uchchabala":5,   # exaltation strength
    "hadda":     5,   # Egyptian bound rulership
    "drekkana":  5,   # decanate rulership
    "navamsha":  5,   # D9 dignity
}


# Weekday lords (used for day_lord candidate)
WEEKDAY_LORDS: Dict[int, str] = {
    0: "Monday-Moon",
    1: "Tuesday-Mars",
    2: "Wednesday-Mercury",
    3: "Thursday-Jupiter",
    4: "Friday-Venus",
    5: "Saturday-Saturn",
    6: "Sunday-Sun",
}

# Map Python datetime.weekday() (Mon=0..Sun=6) to ruling planet
WEEKDAY_PLANET: Dict[int, str] = {
    0: "Moon",
    1: "Mars",
    2: "Mercury",
    3: "Jupiter",
    4: "Venus",
    5: "Saturn",
    6: "Sun",
}


# ════════════════════════════════════════════════════════════════════════
# MUNTHA — Annual progressing point
# Muntha = (natal Lagna sign + age) mod 12
# Moves 1 sign per completed year of life
# ════════════════════════════════════════════════════════════════════════

MUNTHA_HOUSE_RESULTS: Dict[int, Dict[str, str]] = {
    1: {
        "domain":  "self, body, identity",
        "themes":  "personality emergence, physical health emphasis, self-projection year",
        "favorable":"general well-being, leadership opportunities",
        "caution": "ego-driven decisions, body strain",
    },
    2: {
        "domain":  "wealth, family, speech",
        "themes":  "financial focus, family dynamics, voice/speech matters",
        "favorable":"income gain, family expansion",
        "caution": "speech-related disputes, family expenses",
    },
    3: {
        "domain":  "siblings, courage, communication",
        "themes":  "active effort, sibling matters, short journeys",
        "favorable":"new ventures, writing, sibling success",
        "caution": "scattered energy, sibling friction",
    },
    4: {
        "domain":  "home, mother, vehicles, comforts",
        "themes":  "domestic focus, property, mother's affairs",
        "favorable":"real estate gain, domestic peace",
        "caution": "mother's health, vehicle issues",
    },
    5: {
        "domain":  "children, intelligence, creativity",
        "themes":  "creative output, children matters, education, romance",
        "favorable":"conception, creative success, mantra practice",
        "caution": "ego, romance disturbance, gambling losses",
    },
    6: {
        "domain":  "enemies, disease, debts, service",
        "themes":  "challenges with enemies, illness, debts, service work",
        "favorable":"victory over disputes, debt clearance, health treatment success",
        "caution": "new illness, legal entanglements",
    },
    7: {
        "domain":  "spouse, partnerships, business",
        "themes":  "marriage emphasis, business partnerships, travel",
        "favorable":"marriage, partnership formation, foreign travel",
        "caution": "spouse health, partnership disputes",
    },
    8: {
        "domain":  "longevity, hidden matters, transformation",
        "themes":  "transformation year, occult interests, sudden changes",
        "favorable":"inheritance, deep psychological work, research",
        "caution": "accidents, surgeries, sudden setbacks",
    },
    9: {
        "domain":  "father, fortune, dharma, higher learning",
        "themes":  "dharmic focus, father's role, philosophical growth",
        "favorable":"fortune, pilgrimage, guru's blessing, ethical advancement",
        "caution": "father's health, doctrinal conflicts",
    },
    10: {
        "domain":  "career, fame, status",
        "themes":  "career advancement, public recognition",
        "favorable":"promotion, status rise, public honors",
        "caution": "career stress, public criticism",
    },
    11: {
        "domain":  "gains, income, networks",
        "themes":  "income expansion, network building, wish fulfillment",
        "favorable":"financial gains, social rise, elder sibling success",
        "caution": "over-extension, false friends",
    },
    12: {
        "domain":  "expenses, foreign, liberation, sleep",
        "themes":  "spiritual focus, foreign matters, expenditure, isolation",
        "favorable":"spiritual practice, foreign opportunities, charity",
        "caution": "expenses, isolation, sleep issues, hidden enemies",
    },
}


# ════════════════════════════════════════════════════════════════════════
# MUDDA DASHA — Vimshottari-style dasha WITHIN the solar return year
# Total year (365.25 days) distributed across 9 planets in Vimshottari ratio
# ════════════════════════════════════════════════════════════════════════

MUDDA_VIMSHOTTARI_YEARS: Dict[str, int] = {
    "Ketu":    7,
    "Venus":   20,
    "Sun":     6,
    "Moon":    10,
    "Mars":    7,
    "Rahu":    18,
    "Jupiter": 16,
    "Saturn":  19,
    "Mercury": 17,
}  # Total = 120 years; for Mudda each gets (years/120 * 365.25) days

# Mudda dasha sequence starts from natal Moon nakshatra lord (same as Vimshottari)
# but proportionally distributed within the solar year


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "solar_return":   "Tajik Neelakanthi (Neelakantha, ~16th c.); Varshaphala Paddhati; Persian-Greek-Indian synthesis tradition",
    "muntha":         "Tajik Neelakanthi Ch. 4 (Muntha); Varshaphala Paddhati",
    "year_lord":      "Tajik Neelakanthi Ch. 12 (Varshesha selection via Pancha-Vargiya Bala)",
    "tajik_aspects":  "Tajik Neelakanthi (Ithasala, Eesharafa, Mutthasila); classical Tajik yoga tradition",
    "sahams":         "Tajik Neelakanthi (extensive Saham chapters); Hellenistic Lots tradition adapted into Indian astrology",
    "mudda_dasha":    "Tajik Neelakanthi; Varshaphala Paddhati on annual dasha distribution",
    "monthly":        "Tajik Neelakanthi (monthly transit through Muntha houses)",
    "year_remedies":  "Tajik Neelakanthi; classical remedy tradition adapted for annual cycle",
}
