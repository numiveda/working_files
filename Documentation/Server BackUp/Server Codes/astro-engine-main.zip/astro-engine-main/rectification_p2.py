"""
rectification_p2.py — Birth Time Rectification (F10-P2)

Approach A: Event Correlation (Parashari)
Approach B: Tattva (Element/Pulse) Method

Both reuse:
  - dashaflow.cast_chart                       (~2ms per call)
  - rectification._build_candidate_times       (P1 helper, HH:MM output)
  - rectification.SUPPORTED_EVENT_TYPES        (P1 event taxonomy, shared)
  - rectification.MAX_SCAN_WINDOW_MINUTES etc. (P1 limits)

Endpoints:
  POST /astro/rectification/event_based   (Approach A)
  POST /astro/rectification/tattva        (Approach B)

Approach A scoring (Parashari, distinct from P1's KP scoring):
  For each event at event_date:
    - Get the MD/AD lord active at that date for this candidate's chart
    - Score +PRIMARY for each primary house whose LORD or KARAKA
      matches the MD or AD lord
    - Score +SUPPORTING / +NEGATING similarly on supporting/negating houses
  Source: BPHS Ch. 46-52 (Vimshottari dasha-event correspondences);
          Phaladeepika Ch. 26.

Approach B (Tattva):
  Each rasi (sign) maps to one of 5 tattvas (Earth/Water/Fire/Air/Ether).
  User specifies which tattva was active at birth (mother's first
  body-part touched at labor onset, or father's active nostril at
  conception). The lagna's tattva must match. Filter ±120 candidates
  to those satisfying the constraint.
  Source: Sage Bhrigu tradition; Krishnamurthy KP tattva sub-system.

Author: F10-P2 build session
Date:   2026-05-18
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

# ============================================================================
# Imports from existing engine + P1
# ============================================================================

from dashaflow import cast_chart  # type: ignore

# Reuse from P1: candidate-time builder, parser, limits, event taxonomy.
import rectification as _p1  # type: ignore


# ============================================================================
# Approach A — Parashari classical house-lord + karaka tables
# ============================================================================

# Sign-to-lord (Parashari). This is canonical and doesn't change.
SIGN_LORDS: Dict[str, str] = {
    "Aries":       "Mars",
    "Taurus":      "Venus",
    "Gemini":      "Mercury",
    "Cancer":      "Moon",
    "Leo":         "Sun",
    "Virgo":       "Mercury",
    "Libra":       "Venus",
    "Scorpio":     "Mars",
    "Sagittarius": "Jupiter",
    "Capricorn":   "Saturn",
    "Aquarius":    "Saturn",
    "Pisces":      "Jupiter",
}

# Bhava (house) karakas per BPHS Ch. 32. Used in addition to house-lord
# matching for Approach A scoring. A planet that is karaka for a house
# is associated with the matter of that house.
HOUSE_KARAKAS: Dict[int, List[str]] = {
    1:  ["Sun"],
    2:  ["Jupiter"],
    3:  ["Mars"],
    4:  ["Moon", "Venus"],
    5:  ["Jupiter"],
    6:  ["Saturn", "Mars"],
    7:  ["Venus"],
    8:  ["Saturn"],
    9:  ["Jupiter", "Sun"],
    10: ["Sun", "Mercury", "Jupiter", "Saturn"],
    11: ["Jupiter"],
    12: ["Saturn", "Ketu"],
}

# Parashari scoring weights (deliberately different from P1's KP weights —
# karaka-match is weaker classical evidence than house-lord-match)
SCORE_A_PRIMARY_LORD     = 10.0
SCORE_A_PRIMARY_KARAKA   =  5.0
SCORE_A_SUPPORTING_LORD  =  4.0
SCORE_A_SUPPORTING_KARAKA = 2.0
SCORE_A_NEGATING_LORD    = -6.0
SCORE_A_DASHA_MATCH_BONUS = 3.0  # if MD lord is also the matching planet


def _lords_of_houses_for_chart(chart: Dict[str, Any]) -> Dict[int, str]:
    """
    Compute which planet rules each of the 12 houses in this chart.

    Whole-sign houses (Parashari default): house N is the sign N-1 from
    lagna sign. Returns {house: lord_planet}.
    """
    lagna_sign = chart.get("lagna", {}).get("sign")
    if not lagna_sign or lagna_sign not in SIGN_LORDS:
        return {}

    sign_order = list(SIGN_LORDS.keys())  # zodiacal order
    try:
        lagna_idx = sign_order.index(lagna_sign)
    except ValueError:
        return {}

    result: Dict[int, str] = {}
    for h in range(1, 13):
        sign_idx = (lagna_idx + h - 1) % 12
        sign_name = sign_order[sign_idx]
        result[h] = SIGN_LORDS[sign_name]
    return result


def _score_a_candidate(
    chart_at_candidate: Dict[str, Any],
    dasha_lords_per_event: List[Dict[str, Optional[str]]],
    events: List[Any],  # _p1.Event but we use duck typing
) -> Tuple[float, List[Dict[str, Any]]]:
    """
    Parashari scoring for Approach A.

    For each event:
      - Get MD/AD lord active at event date (from dasha_lords_per_event[i])
      - For each primary house: +PRIMARY_LORD if house lord matches MD or AD;
                                +PRIMARY_KARAKA if a house karaka matches
      - For each supporting house: +SUPPORTING_LORD / +SUPPORTING_KARAKA
      - For each negating house: -NEGATING_LORD if its lord matches MD/AD
      - +DASHA_BONUS once per event if any primary-house match is the MD lord
    """
    house_lords = _lords_of_houses_for_chart(chart_at_candidate)
    if not house_lords:
        return 0.0, []

    total = 0.0
    breakdown: List[Dict[str, Any]] = []

    for i, event in enumerate(events):
        rules = _p1.EVENT_HOUSE_RULES.get(event.event_type)
        if rules is None:
            breakdown.append({
                "event": event.event_type, "date": event.event_date,
                "score": 0.0, "note": "unsupported_event_type",
            })
            continue

        lords = dasha_lords_per_event[i] if i < len(dasha_lords_per_event) else {}
        md_lord = lords.get("maha")
        ad_lord = lords.get("antar")
        active_lords = {l for l in (md_lord, ad_lord) if l}

        event_score = 0.0
        details: Dict[str, Any] = {
            "primary_lord_hits":     [],
            "primary_karaka_hits":   [],
            "supporting_lord_hits":  [],
            "supporting_karaka_hits":[],
            "negating_lord_hits":    [],
            "dasha_bonus":           False,
        }
        primary_match_includes_md = False

        for h in rules["primary"]:
            lord = house_lords.get(h)
            if lord and lord in active_lords:
                event_score += SCORE_A_PRIMARY_LORD
                details["primary_lord_hits"].append({"house": h, "lord": lord})
                if lord == md_lord:
                    primary_match_includes_md = True
            for karaka in HOUSE_KARAKAS.get(h, []):
                if karaka in active_lords:
                    event_score += SCORE_A_PRIMARY_KARAKA
                    details["primary_karaka_hits"].append({"house": h, "karaka": karaka})
                    if karaka == md_lord:
                        primary_match_includes_md = True

        for h in rules["supporting"]:
            lord = house_lords.get(h)
            if lord and lord in active_lords:
                event_score += SCORE_A_SUPPORTING_LORD
                details["supporting_lord_hits"].append({"house": h, "lord": lord})
            for karaka in HOUSE_KARAKAS.get(h, []):
                if karaka in active_lords:
                    event_score += SCORE_A_SUPPORTING_KARAKA
                    details["supporting_karaka_hits"].append({"house": h, "karaka": karaka})

        for h in rules["negating"]:
            lord = house_lords.get(h)
            if lord and lord in active_lords:
                event_score += SCORE_A_NEGATING_LORD
                details["negating_lord_hits"].append({"house": h, "lord": lord})

        if primary_match_includes_md:
            event_score += SCORE_A_DASHA_MATCH_BONUS
            details["dasha_bonus"] = True

        weighted = event_score * event.weight
        total += weighted

        breakdown.append({
            "event":            event.event_type,
            "date":             event.event_date,
            "raw_score":        event_score,
            "weight":           event.weight,
            "weighted_score":   weighted,
            "md_lord_at_event": md_lord,
            "ad_lord_at_event": ad_lord,
            "details":          details,
        })

    return total, breakdown


def handle_event_based_rectification(
    dob: str,
    time: str,
    lat: float,
    lon: float,
    timezone: str,
    events: List[Dict[str, Any]],
    scan_window_minutes: int = _p1.DEFAULT_SCAN_WINDOW_MINUTES,
    scan_granularity_minutes: int = _p1.DEFAULT_SCAN_GRANULARITY_MINUTES,
    top_n: int = _p1.DEFAULT_TOP_N,
) -> Dict[str, Any]:
    """
    Approach A — Parashari event correlation BTR.

    Same inputs as P1's KP-based, but scores using house-lord + karaka
    rules instead of cuspal sub-lords. Use this when classical Parashari
    framework is preferred or when KP isn't accepted by the consumer.
    """
    # Input hygiene — reuses P1's validation logic by going through Event dataclass
    if not events:
        raise ValueError("At least one event is required for event-based rectification")
    if len(events) > _p1.MAX_EVENTS_PER_REQUEST:
        raise ValueError(
            f"Too many events: {len(events)} > {_p1.MAX_EVENTS_PER_REQUEST}"
        )
    if scan_window_minutes > _p1.MAX_SCAN_WINDOW_MINUTES:
        raise ValueError(
            f"scan_window_minutes={scan_window_minutes} exceeds "
            f"MAX_SCAN_WINDOW_MINUTES={_p1.MAX_SCAN_WINDOW_MINUTES}"
        )
    if scan_granularity_minutes < _p1.MIN_SCAN_GRANULARITY_MINUTES:
        raise ValueError(
            f"scan_granularity_minutes={scan_granularity_minutes} below "
            f"MIN_SCAN_GRANULARITY_MINUTES={_p1.MIN_SCAN_GRANULARITY_MINUTES}"
        )

    parsed_events: List[Any] = []
    for ev in events:
        et = ev.get("event_type")
        ed = ev.get("event_date")
        if et not in _p1.EVENT_HOUSE_RULES:
            raise ValueError(
                f"Unsupported event_type {et!r}; "
                f"supported: {_p1.SUPPORTED_EVENT_TYPES}"
            )
        if not ed:
            raise ValueError(f"event_date required for event {et!r}")
        try:
            datetime.strptime(ed, "%Y-%m-%d")
        except ValueError:
            raise ValueError(f"event_date {ed!r} must be YYYY-MM-DD")
        weight = float(ev.get("weight", 1.0))
        parsed_events.append(_p1.Event(event_type=et, event_date=ed, weight=weight))

    candidates = _p1._build_candidate_times(time, scan_window_minutes, scan_granularity_minutes)

    # Scan
    scored: List[Dict[str, Any]] = []
    for candidate_time in candidates:
        try:
            chart = cast_chart(dob, candidate_time, lat, lon, timezone)
        except Exception:
            continue
        if not chart or not chart.get("lagna"):
            continue

        # Get dasha lords at each event date (best-effort — reuses P1's helper)
        dasha_lords_per_event: List[Dict[str, Optional[str]]] = []
        for ev in parsed_events:
            lords = _p1._get_dasha_lords_at_event(
                dob, candidate_time, lat, lon, timezone, ev.event_date
            )
            dasha_lords_per_event.append(lords)

        total, breakdown = _score_a_candidate(chart, dasha_lords_per_event, parsed_events)

        scored.append({
            "candidate_time":      candidate_time,
            "total_score":         total,
            "per_event_breakdown": breakdown,
            "lagna_sign":          chart["lagna"].get("sign", ""),
            "lagna_degree":        float(chart["lagna"].get("degree", 0.0)),
            "house_lords":         _lords_of_houses_for_chart(chart),
        })

    if not scored:
        return {
            "status": "no_valid_candidates",
            "approach": "event_based_parashari",
            "reported_time": time,
            "rectified_time": None,
            "rectified_lagna": None,
            "confidence_pct": 0.0,
            "scan_parameters": {
                "window_minutes": scan_window_minutes,
                "granularity_minutes": scan_granularity_minutes,
                "candidates_scanned": len(candidates),
                "candidates_valid": 0,
            },
            "top_candidates": [],
            "winner_chart": None,
            "supported_event_types": _p1.SUPPORTED_EVENT_TYPES,
        }

    scored.sort(key=lambda c: c["total_score"], reverse=True)
    top = scored[:top_n]

    # Re-cast winning chart
    winner = top[0]
    try:
        winner_chart = cast_chart(dob, winner["candidate_time"], lat, lon, timezone)
    except Exception as exc:
        winner_chart = {"error": f"winner re-cast failed: {exc}"}

    # Confidence: score-gap based, same formula structure as P1
    if len(scored) >= 2:
        score_gap = top[0]["total_score"] - top[1]["total_score"]
        max_possible = sum(
            (SCORE_A_PRIMARY_LORD + SCORE_A_PRIMARY_KARAKA) *
            len(_p1.EVENT_HOUSE_RULES[e.event_type]["primary"]) * e.weight
            for e in parsed_events
        )
        confidence_pct = (
            min(100.0, (score_gap / max(max_possible, 1.0)) * 100.0)
            if max_possible > 0 else 0.0
        )
    else:
        confidence_pct = 0.0

    return {
        "status":          "ok",
        "approach":        "event_based_parashari",
        "reported_time":   time,
        "rectified_time":  winner["candidate_time"],
        "rectified_lagna": {
            "sign":   winner["lagna_sign"],
            "degree": winner["lagna_degree"],
        },
        "confidence_pct":  round(confidence_pct, 1),
        "scan_parameters": {
            "window_minutes":      scan_window_minutes,
            "granularity_minutes": scan_granularity_minutes,
            "candidates_scanned":  len(candidates),
            "candidates_valid":    len(scored),
        },
        "top_candidates": [
            {
                "rank":                i + 1,
                "candidate_time":      c["candidate_time"],
                "total_score":         round(c["total_score"], 2),
                "lagna_sign":          c["lagna_sign"],
                "lagna_degree":        round(c["lagna_degree"], 4),
                "house_lords":         c["house_lords"],
                "per_event_breakdown": c["per_event_breakdown"],
            }
            for i, c in enumerate(top)
        ],
        "winner_chart": winner_chart,
        "classical_reference": (
            "BPHS Ch. 32 (Bhava karakas), Ch. 46-52 (Vimshottari "
            "dasha-event correspondences); Phaladeepika Ch. 26."
        ),
    }


# ============================================================================
# Approach B — Tattva (Element) Method
# ============================================================================

# Each rasi maps to one classical mahabhuta (element). Source:
# Brihat Parashara Hora Shastra Ch. 4 (rasi-tattva correspondences).
SIGN_TATTVAS: Dict[str, str] = {
    "Aries":       "fire",
    "Leo":         "fire",
    "Sagittarius": "fire",
    "Taurus":      "earth",
    "Virgo":       "earth",
    "Capricorn":   "earth",
    "Gemini":      "air",
    "Libra":       "air",
    "Aquarius":    "air",
    "Cancer":      "water",
    "Scorpio":     "water",
    "Pisces":      "water",
    # Ether (akasha) is not associated with any single rasi; it manifests
    # through nakshatra (specifically Pushya/Punarvasu/Visakha + transitions).
    # When user reports "ether" tattva, we use the special handler below.
}

SUPPORTED_TATTVAS: List[str] = ["fire", "earth", "air", "water", "ether"]

# Ether-bearing nakshatras (junction/sandhi points; classical akasha-tattva)
ETHER_NAKSHATRAS: List[str] = [
    "Pushya", "Punarvasu", "Visakha", "Anuradha", "Ardra"
]


def handle_tattva_rectification(
    dob: str,
    time: str,
    lat: float,
    lon: float,
    timezone: str,
    observed_tattva: str,
    scan_window_minutes: int = _p1.DEFAULT_SCAN_WINDOW_MINUTES,
    scan_granularity_minutes: int = _p1.DEFAULT_SCAN_GRANULARITY_MINUTES,
) -> Dict[str, Any]:
    """
    Approach B — Tattva BTR.

    User reports the active tattva at the moment of birth (mother's first
    body-part touched at labor onset, or father's active nostril, per
    classical Bhrigu/KP tradition). The lagna's elemental nature at birth
    must match the observed tattva.

    This is a FILTER, not a scorer: we return ALL candidates in the scan
    window whose lagna matches the reported tattva. With ±120 min ranges,
    typically 30-60% of candidates will match (since each of the 4
    elements occupies ~25% of the zodiac), and the result acts as a
    narrowing prior for further methods (KP, event-correlation, nadi-amsha).

    For ether tattva: we filter to candidates whose Moon-nakshatra at
    birth is in ETHER_NAKSHATRAS, since no rasi carries akasha directly.
    """
    if observed_tattva not in SUPPORTED_TATTVAS:
        raise ValueError(
            f"Unsupported tattva {observed_tattva!r}; "
            f"supported: {SUPPORTED_TATTVAS}"
        )
    if scan_window_minutes > _p1.MAX_SCAN_WINDOW_MINUTES:
        raise ValueError(
            f"scan_window_minutes={scan_window_minutes} exceeds "
            f"MAX_SCAN_WINDOW_MINUTES={_p1.MAX_SCAN_WINDOW_MINUTES}"
        )
    if scan_granularity_minutes < _p1.MIN_SCAN_GRANULARITY_MINUTES:
        raise ValueError(
            f"scan_granularity_minutes={scan_granularity_minutes} below "
            f"MIN_SCAN_GRANULARITY_MINUTES={_p1.MIN_SCAN_GRANULARITY_MINUTES}"
        )

    candidates = _p1._build_candidate_times(time, scan_window_minutes, scan_granularity_minutes)

    matches: List[Dict[str, Any]] = []

    for candidate_time in candidates:
        try:
            chart = cast_chart(dob, candidate_time, lat, lon, timezone)
        except Exception:
            continue

        lagna = chart.get("lagna") or {}
        lagna_sign = lagna.get("sign")
        if not lagna_sign:
            continue

        if observed_tattva == "ether":
            # Special handling: check Moon nakshatra
            moon_nak = (chart.get("panchang") or {}).get("nakshatra", {}).get("name")
            if moon_nak in ETHER_NAKSHATRAS:
                matches.append({
                    "candidate_time": candidate_time,
                    "lagna_sign":     lagna_sign,
                    "lagna_degree":   round(float(lagna.get("degree", 0.0)), 4),
                    "lagna_tattva":   SIGN_TATTVAS.get(lagna_sign, "unknown"),
                    "moon_nakshatra": moon_nak,
                    "match_reason":   f"Moon in ether-bearing nakshatra {moon_nak}",
                })
        else:
            lagna_tattva = SIGN_TATTVAS.get(lagna_sign)
            if lagna_tattva == observed_tattva:
                matches.append({
                    "candidate_time": candidate_time,
                    "lagna_sign":     lagna_sign,
                    "lagna_degree":   round(float(lagna.get("degree", 0.0)), 4),
                    "lagna_tattva":   lagna_tattva,
                    "match_reason":   f"Lagna {lagna_sign} has tattva={lagna_tattva}",
                })

    # The midpoint of the matching run is the most defensible single
    # rectified time. If the run is contiguous, midpoint is the average;
    # if there are multiple disjoint runs, we report the longest run's
    # midpoint as primary and others as alternatives.
    primary: Optional[Dict[str, Any]] = None
    alt_runs: List[Dict[str, Any]] = []

    if matches:
        runs = _split_contiguous_runs(matches)
        runs.sort(key=len, reverse=True)  # longest first
        longest = runs[0]
        mid_idx = len(longest) // 2
        primary = longest[mid_idx]
        if len(runs) > 1:
            for r in runs[1:]:
                alt_runs.append({
                    "run_length": len(r),
                    "start_time": r[0]["candidate_time"],
                    "end_time":   r[-1]["candidate_time"],
                    "midpoint":   r[len(r) // 2]["candidate_time"],
                })

    if not primary:
        return {
            "status":               "no_match_for_tattva",
            "approach":             "tattva",
            "reported_time":        time,
            "observed_tattva":      observed_tattva,
            "rectified_time":       None,
            "rectified_lagna":      None,
            "scan_parameters": {
                "window_minutes":      scan_window_minutes,
                "granularity_minutes": scan_granularity_minutes,
                "candidates_scanned":  len(candidates),
                "candidates_matching": 0,
            },
            "matches": [],
            "alternative_runs": [],
            "winner_chart": None,
        }

    # Re-cast winning chart
    try:
        winner_chart = cast_chart(dob, primary["candidate_time"], lat, lon, timezone)
    except Exception as exc:
        winner_chart = {"error": f"winner re-cast failed: {exc}"}

    return {
        "status":          "ok",
        "approach":        "tattva",
        "reported_time":   time,
        "observed_tattva": observed_tattva,
        "rectified_time":  primary["candidate_time"],
        "rectified_lagna": {
            "sign":   primary["lagna_sign"],
            "degree": primary["lagna_degree"],
            "tattva": primary["lagna_tattva"],
        },
        "scan_parameters": {
            "window_minutes":      scan_window_minutes,
            "granularity_minutes": scan_granularity_minutes,
            "candidates_scanned":  len(candidates),
            "candidates_matching": len(matches),
        },
        "matches":          matches,
        "alternative_runs": alt_runs,
        "winner_chart":     winner_chart,
        "classical_reference": (
            "BPHS Ch. 4 (rasi-tattva correspondences); "
            "Sage Bhrigu tradition for tattva-of-birth observation; "
            "Krishnamurthy KP tattva sub-system."
        ),
    }


def _split_contiguous_runs(matches: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
    """
    Split a sorted list of matching candidates into contiguous runs.
    Two candidates are 'contiguous' if their times are 1 minute apart.
    """
    if not matches:
        return []
    runs: List[List[Dict[str, Any]]] = []
    current: List[Dict[str, Any]] = [matches[0]]
    for prev, curr in zip(matches, matches[1:]):
        # Parse HH:MM strings
        ph, pm = map(int, prev["candidate_time"].split(":"))
        ch, cm = map(int, curr["candidate_time"].split(":"))
        prev_min = ph * 60 + pm
        curr_min = ch * 60 + cm
        if curr_min - prev_min == 1:
            current.append(curr)
        else:
            runs.append(current)
            current = [curr]
    runs.append(current)
    return runs


def handle_supported_tattvas() -> Dict[str, Any]:
    """Return the supported tattvas and which signs map to each."""
    by_tattva: Dict[str, List[str]] = {t: [] for t in SUPPORTED_TATTVAS}
    for sign, tattva in SIGN_TATTVAS.items():
        by_tattva.setdefault(tattva, []).append(sign)
    by_tattva["ether"] = []  # ether has no rasi; nakshatra-based
    return {
        "supported_tattvas":   SUPPORTED_TATTVAS,
        "signs_by_tattva":     by_tattva,
        "ether_nakshatras":    ETHER_NAKSHATRAS,
        "note": (
            "Each tattva corresponds to one of the four classical "
            "elements (fire, earth, air, water) plus akasha (ether). "
            "Ether is identified via Moon-nakshatra rather than lagna-rasi "
            "since no rasi directly carries akasha. The observed_tattva "
            "input should reflect the active tattva at the moment of "
            "birth — classically determined by the mother's first "
            "body-part touched at labor onset (Bhrigu) or the father's "
            "active nostril at conception (KP)."
        ),
    }
