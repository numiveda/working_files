"""
nakshatra_padas.py — The 108-Pada classical reference table.

Each of the 27 nakshatras has 4 padas (quarters), totaling 108 padas.
Each pada corresponds to a sign in the Navamsa (D9) — and through that
inherits the sign's lord, element, and modality. The pada also has its
own distinct life-theme nuance.

Convention: pada keys are tuples (nakshatra_index, pada_number).
e.g. (1, 1) = Ashwini pada 1, (27, 4) = Revati pada 4.

The Navamsa sub-sign sequence: padas of Aries-sign nakshatras (1-2,
half of 3) start from Aries Navamsa. Each pada = 3°20' = 1 Navamsa sign.
"""

from typing import Dict, Any, List, Tuple

# ─────────────────────────────────────────────────────────────────────────────
# NAVAMSA SIGN MAPPING — by Rashi
# ─────────────────────────────────────────────────────────────────────────────

NAVAMSA_LORDS = {
    "Aries": "Mars",        "Taurus": "Venus",   "Gemini": "Mercury",
    "Cancer": "Moon",       "Leo": "Sun",        "Virgo": "Mercury",
    "Libra": "Venus",       "Scorpio": "Mars",   "Sagittarius": "Jupiter",
    "Capricorn": "Saturn",  "Aquarius": "Saturn", "Pisces": "Jupiter",
}

NAVAMSA_ELEMENTS = {
    "Aries": "Fire",        "Taurus": "Earth",   "Gemini": "Air",
    "Cancer": "Water",      "Leo": "Fire",       "Virgo": "Earth",
    "Libra": "Air",         "Scorpio": "Water",  "Sagittarius": "Fire",
    "Capricorn": "Earth",   "Aquarius": "Air",   "Pisces": "Water",
}

NAVAMSA_MODALITY = {
    "Aries": "Chara",       "Taurus": "Sthira",  "Gemini": "Dvi-svabhava",
    "Cancer": "Chara",      "Leo": "Sthira",     "Virgo": "Dvi-svabhava",
    "Libra": "Chara",       "Scorpio": "Sthira", "Sagittarius": "Dvi-svabhava",
    "Capricorn": "Chara",   "Aquarius": "Sthira","Pisces": "Dvi-svabhava",
}


# ─────────────────────────────────────────────────────────────────────────────
# 108 PADAS WITH ATTRIBUTES
# ─────────────────────────────────────────────────────────────────────────────
#
# Schema per pada (the 9 sub-attributes):
#   navamsa_sign     — D9 sign for this pada
#   sub_lord         — lord of that navamsa sign
#   element_pada     — refined element at pada level (from navamsa)
#   modality_pada    — chara/sthira/dvi at pada level
#   akshara          — Sanskrit syllable for this pada (from Brihat Parashara)
#   body_part_pada   — refined body part (Kalapurusha extended)
#   career_nuance    — pada-specific career emphasis
#   relationship_pattern — pada-level relationship style
#   spiritual_lesson_pada — pada-specific lesson
#
# ─────────────────────────────────────────────────────────────────────────────

PADAS: Dict[Tuple[int, int], Dict[str, Any]] = {

    # ─── 1. Ashwini (Aries 0°–13°20') — padas in Aries-Taurus-Gemini-Cancer Navamsa ───
    (1, 1): {
        "navamsa_sign": "Aries", "sub_lord": "Mars",
        "akshara": "Chu", "akshara_sa": "चु",
        "body_part_pada": "Head, top of skull",
        "career_nuance": "Fire-based pioneering — emergency response, sports, entrepreneurship",
        "relationship_pattern": "Initiates relationships impulsively, loses interest if chase removed",
        "spiritual_lesson_pada": "Channel raw fire into sustained pioneering — burn long, not just bright",
    },
    (1, 2): {
        "navamsa_sign": "Taurus", "sub_lord": "Venus",
        "akshara": "Che", "akshara_sa": "चे",
        "body_part_pada": "Eyes, face",
        "career_nuance": "Earthy healing — Ayurveda, agriculture, dairy, body-centered medicine",
        "relationship_pattern": "Sensual, loyal once chosen, slow to commit but stays",
        "spiritual_lesson_pada": "Beauty serves healing — the body is sacred ground",
    },
    (1, 3): {
        "navamsa_sign": "Gemini", "sub_lord": "Mercury",
        "akshara": "Cho", "akshara_sa": "चो",
        "body_part_pada": "Cheeks, ears",
        "career_nuance": "Communication-based — medical journalism, education in health, sales",
        "relationship_pattern": "Witty, conversational, intellectually flirtatious",
        "spiritual_lesson_pada": "Speak with the speed of intention — words heal or wound",
    },
    (1, 4): {
        "navamsa_sign": "Cancer", "sub_lord": "Moon",
        "akshara": "La", "akshara_sa": "ला",
        "body_part_pada": "Chest, lungs",
        "career_nuance": "Caring professions — nursing, family medicine, mother-child specialty",
        "relationship_pattern": "Emotional, nurturing partner, sometimes moody",
        "spiritual_lesson_pada": "Healing flows from the heart — emotion is the medicine",
    },

    # ─── 2. Bharani (Aries 13°20'–26°40') — Leo-Virgo-Libra-Scorpio Navamsa ───
    (2, 1): {
        "navamsa_sign": "Leo", "sub_lord": "Sun",
        "akshara": "Li", "akshara_sa": "ली",
        "body_part_pada": "Head sides, face",
        "career_nuance": "Authoritative bearing — leadership in transformative fields",
        "relationship_pattern": "Dramatic in love, magnetic and proud",
        "spiritual_lesson_pada": "Pride must serve dharma — power without humility burns the holder",
    },
    (2, 2): {
        "navamsa_sign": "Virgo", "sub_lord": "Mercury",
        "akshara": "Lu", "akshara_sa": "लू",
        "body_part_pada": "Stomach, intestines",
        "career_nuance": "Precise transformation work — surgery, forensics, detailed restraint",
        "relationship_pattern": "Critical of partners, perfectionist in love, slow trust",
        "spiritual_lesson_pada": "Discrimination serves transformation — refine, don't reject",
    },
    (2, 3): {
        "navamsa_sign": "Libra", "sub_lord": "Venus",
        "akshara": "Le", "akshara_sa": "ले",
        "body_part_pada": "Hips, kidneys",
        "career_nuance": "Balance-based judgment — law, mediation, justice with grace",
        "relationship_pattern": "Romantic, partnership-oriented, seeks balance in intensity",
        "spiritual_lesson_pada": "Justice tempered with grace; the scales of dharma require both",
    },
    (2, 4): {
        "navamsa_sign": "Scorpio", "sub_lord": "Mars",
        "akshara": "Lo", "akshara_sa": "लो",
        "body_part_pada": "Pelvis, reproductive organs",
        "career_nuance": "Deep transformation — Tantra, depth psychology, occult investigation",
        "relationship_pattern": "Intense, possessive, transformative through union",
        "spiritual_lesson_pada": "Death and rebirth in every embrace — go deep, surface clean",
    },

    # ─── 3. Krittika (Aries 26°40'–Taurus 10°00') — Sagittarius-Capricorn-Aquarius-Pisces ───
    (3, 1): {
        "navamsa_sign": "Sagittarius", "sub_lord": "Jupiter",
        "akshara": "A", "akshara_sa": "अ",
        "body_part_pada": "Top of head, brain",
        "career_nuance": "Philosophical fire — teaching of sharp truths, dharmic critique",
        "relationship_pattern": "Direct, opinionated, partner must hold their own",
        "spiritual_lesson_pada": "Discrimination serves wisdom — the sword cuts to free, not destroy",
    },
    (3, 2): {
        "navamsa_sign": "Capricorn", "sub_lord": "Saturn",
        "akshara": "I", "akshara_sa": "इ",
        "body_part_pada": "Throat, neck (Taurus zone)",
        "career_nuance": "Disciplined refinement — military, structured criticism, quality control",
        "relationship_pattern": "Slow, careful, builds enduring bonds through patience",
        "spiritual_lesson_pada": "Refinement is a long discipline — the sword must be hammered, not just sharpened",
    },
    (3, 3): {
        "navamsa_sign": "Aquarius", "sub_lord": "Saturn",
        "akshara": "U", "akshara_sa": "उ",
        "body_part_pada": "Shoulders, throat",
        "career_nuance": "Unconventional critique — science journalism, original research",
        "relationship_pattern": "Detached friendship-first style, slow emotional opening",
        "spiritual_lesson_pada": "Stand apart to see clearly — but return to serve",
    },
    (3, 4): {
        "navamsa_sign": "Pisces", "sub_lord": "Jupiter",
        "akshara": "E", "akshara_sa": "ए",
        "body_part_pada": "Throat lower, upper chest",
        "career_nuance": "Compassionate cutting — therapy, soft sharp truth-telling",
        "relationship_pattern": "Idealistic in love, softens the Krittika edge",
        "spiritual_lesson_pada": "The fire of discrimination must finally serve compassion",
    },

    # ─── 4. Rohini (Taurus 10°00'–23°20') — Aries-Taurus-Gemini-Cancer ───
    (4, 1): {
        "navamsa_sign": "Aries", "sub_lord": "Mars",
        "akshara": "O", "akshara_sa": "ओ",
        "body_part_pada": "Mouth, lips",
        "career_nuance": "Initiative in wealth-building — entrepreneurship in beauty/luxury",
        "relationship_pattern": "Quickly attracted, magnetic energy, takes lead in pursuit",
        "spiritual_lesson_pada": "Abundance starts with bold seed — plant first, refine later",
    },
    (4, 2): {
        "navamsa_sign": "Taurus", "sub_lord": "Venus",
        "akshara": "Va", "akshara_sa": "व",
        "body_part_pada": "Cheeks, throat",
        "career_nuance": "Sensual abundance — luxury, fine arts, gourmet, jewelry",
        "relationship_pattern": "Deeply sensual, loyal, possessive of beauty",
        "spiritual_lesson_pada": "Beauty held without grasping is the highest aesthetic",
    },
    (4, 3): {
        "navamsa_sign": "Gemini", "sub_lord": "Mercury",
        "akshara": "Vi", "akshara_sa": "वि",
        "body_part_pada": "Voice, vocal cords",
        "career_nuance": "Wealth through communication — media in luxury, arts journalism, copywriting",
        "relationship_pattern": "Charming communicator, flirtatious, witty in romance",
        "spiritual_lesson_pada": "Speak abundance into being — but listen for what others need",
    },
    (4, 4): {
        "navamsa_sign": "Cancer", "sub_lord": "Moon",
        "akshara": "Vu", "akshara_sa": "वु",
        "body_part_pada": "Chest, mother-zone",
        "career_nuance": "Nurturing abundance — hospitality, food, mother-child wealth",
        "relationship_pattern": "Deeply emotional, family-oriented, motherly even when not parent",
        "spiritual_lesson_pada": "Wealth that doesn't nourish others is just hoarding",
    },

    # ─── 5. Mrigashira (Taurus 23°20'–Gemini 6°40') — Leo-Virgo-Libra-Scorpio ───
    (5, 1): {
        "navamsa_sign": "Leo", "sub_lord": "Sun",
        "akshara": "Ve", "akshara_sa": "वे",
        "body_part_pada": "Throat upper, larynx",
        "career_nuance": "Bold seeking — leadership in exploration, brand quests",
        "relationship_pattern": "Magnetic seeker, falls in love with potential",
        "spiritual_lesson_pada": "Seek with confidence, but bow when you find",
    },
    (5, 2): {
        "navamsa_sign": "Virgo", "sub_lord": "Mercury",
        "akshara": "Vo", "akshara_sa": "वो",
        "body_part_pada": "Shoulders, upper arms",
        "career_nuance": "Detailed research — scholarly investigation, fine analytical work",
        "relationship_pattern": "Methodical in dating, picky, intellectual partners",
        "spiritual_lesson_pada": "The search refined is wisdom; the search obsessed is anxiety",
    },
    (5, 3): {
        "navamsa_sign": "Libra", "sub_lord": "Venus",
        "akshara": "Ka", "akshara_sa": "क",
        "body_part_pada": "Arms, hands",
        "career_nuance": "Balanced inquiry — diplomacy, design exploration, music",
        "relationship_pattern": "Romantic searcher, falls in love often, seeks the perfect partner",
        "spiritual_lesson_pada": "Beauty answers the seeker's question if they pause to receive",
    },
    (5, 4): {
        "navamsa_sign": "Scorpio", "sub_lord": "Mars",
        "akshara": "Ki", "akshara_sa": "कि",
        "body_part_pada": "Lower arms, hands",
        "career_nuance": "Deep secret-seeking — investigation, occult research, hidden inquiry",
        "relationship_pattern": "Intense seeker, transformative bonds, mysterious",
        "spiritual_lesson_pada": "What you seek in the depths transforms you — return changed",
    },

    # ─── 6. Ardra (Gemini 6°40'–20°00') — Sagittarius-Capricorn-Aquarius-Pisces ───
    (6, 1): {
        "navamsa_sign": "Sagittarius", "sub_lord": "Jupiter",
        "akshara": "Ku", "akshara_sa": "कु",
        "body_part_pada": "Lower arms, fingers",
        "career_nuance": "Philosophical storm — paradigm-breaking teaching, religious revolution",
        "relationship_pattern": "Idealistic in storm, partner must believe in the cause",
        "spiritual_lesson_pada": "Wisdom is born when the philosophical winds clear the fog",
    },
    (6, 2): {
        "navamsa_sign": "Capricorn", "sub_lord": "Saturn",
        "akshara": "Gha", "akshara_sa": "घ",
        "body_part_pada": "Hands, fingers",
        "career_nuance": "Structured transformation — corporate restructuring, hard reform work",
        "relationship_pattern": "Slow trust, intense once given, partnerships forged in crisis",
        "spiritual_lesson_pada": "Storms reveal what was built well — survive and rebuild stronger",
    },
    (6, 3): {
        "navamsa_sign": "Aquarius", "sub_lord": "Saturn",
        "akshara": "Ng", "akshara_sa": "ङ",
        "body_part_pada": "Shoulders, upper back",
        "career_nuance": "Innovative breaking — disruptive tech, social revolution, activism",
        "relationship_pattern": "Detached during storms, unconventional partnerships",
        "spiritual_lesson_pada": "Cleared ground is where the new tribe gathers",
    },
    (6, 4): {
        "navamsa_sign": "Pisces", "sub_lord": "Jupiter",
        "akshara": "Chha", "akshara_sa": "छ",
        "body_part_pada": "Wrists, knuckles",
        "career_nuance": "Compassionate clearing — trauma therapy, addiction recovery, mystical healing",
        "relationship_pattern": "Empathic in storm, soft heart under intensity",
        "spiritual_lesson_pada": "After the storm, tears water the new growth",
    },

    # ─── 7. Punarvasu (Gemini 20°00'–Cancer 3°20') — Aries-Taurus-Gemini-Cancer ───
    (7, 1): {
        "navamsa_sign": "Aries", "sub_lord": "Mars",
        "akshara": "Ke", "akshara_sa": "के",
        "body_part_pada": "Fingers, fingertips",
        "career_nuance": "Pioneering return — startup founder rebuilding, second-time-around ventures",
        "relationship_pattern": "Strong initiative in reconciliation, returns to old loves",
        "spiritual_lesson_pada": "Begin again — every fresh start carries the light of return",
    },
    (7, 2): {
        "navamsa_sign": "Taurus", "sub_lord": "Venus",
        "akshara": "Ko", "akshara_sa": "को",
        "body_part_pada": "Forearm, palm",
        "career_nuance": "Stable return — heritage businesses, ancestral wealth recovery",
        "relationship_pattern": "Restores broken bonds with patience and beauty",
        "spiritual_lesson_pada": "What was lost is rebuilt slowly, sensually, in beauty",
    },
    (7, 3): {
        "navamsa_sign": "Gemini", "sub_lord": "Mercury",
        "akshara": "Ha", "akshara_sa": "ह",
        "body_part_pada": "Hands, communication zone",
        "career_nuance": "Communicative return — writing memoirs, teaching from experience",
        "relationship_pattern": "Stays in touch, returns through conversation, witty reconnection",
        "spiritual_lesson_pada": "Stories of return carry wisdom for those just beginning",
    },
    (7, 4): {
        "navamsa_sign": "Cancer", "sub_lord": "Moon",
        "akshara": "Hi", "akshara_sa": "हि",
        "body_part_pada": "Chest, heart-mother zone",
        "career_nuance": "Emotional homecoming — family therapy, ancestral healing, home design",
        "relationship_pattern": "Returns to first love themes, deeply emotional reunions",
        "spiritual_lesson_pada": "Home is where the heart remembers itself",
    },

    # ─── 8. Pushya (Cancer 3°20'–16°40') — Leo-Virgo-Libra-Scorpio ───
    (8, 1): {
        "navamsa_sign": "Leo", "sub_lord": "Sun",
        "akshara": "Hu", "akshara_sa": "हु",
        "body_part_pada": "Chest, lungs",
        "career_nuance": "Authoritative nourishment — leadership in education/wisdom, royal advisor",
        "relationship_pattern": "Protective, traditional, leads partnership with care",
        "spiritual_lesson_pada": "Nourish from a place of strength, not lack",
    },
    (8, 2): {
        "navamsa_sign": "Virgo", "sub_lord": "Mercury",
        "akshara": "He", "akshara_sa": "हे",
        "body_part_pada": "Lungs, ribs",
        "career_nuance": "Methodical nurturing — health science, careful planning, structured care",
        "relationship_pattern": "Detail-oriented partner, attentive but reserved",
        "spiritual_lesson_pada": "Nourishment refined is medicine, not just food",
    },
    (8, 3): {
        "navamsa_sign": "Libra", "sub_lord": "Venus",
        "akshara": "Ho", "akshara_sa": "हो",
        "body_part_pada": "Breasts, upper abdomen",
        "career_nuance": "Aesthetic nurturing — diplomatic care, beauty industry leadership",
        "relationship_pattern": "Charming, hospitable, builds harmonious home",
        "spiritual_lesson_pada": "Care expressed as beauty heals everyone in the room",
    },
    (8, 4): {
        "navamsa_sign": "Scorpio", "sub_lord": "Mars",
        "akshara": "Da", "akshara_sa": "ड",
        "body_part_pada": "Stomach, digestive organs",
        "career_nuance": "Transformative nourishment — therapy, trauma recovery, crisis care",
        "relationship_pattern": "Deep emotional bonds, transformative care of partner",
        "spiritual_lesson_pada": "True care goes to the painful places others avoid",
    },

    # ─── 9. Ashlesha (Cancer 16°40'–30°00') — Sagittarius-Capricorn-Aquarius-Pisces ───
    (9, 1): {
        "navamsa_sign": "Sagittarius", "sub_lord": "Jupiter",
        "akshara": "Di", "akshara_sa": "डि",
        "body_part_pada": "Belly, lower stomach",
        "career_nuance": "Hypnotic teaching — esoteric philosophy, persuasive spiritual instruction",
        "relationship_pattern": "Magnetic philosophical seducer, intense convictions",
        "spiritual_lesson_pada": "Wisdom hypnotizes — use the gift to liberate, not capture",
    },
    (9, 2): {
        "navamsa_sign": "Capricorn", "sub_lord": "Saturn",
        "akshara": "Du", "akshara_sa": "डु",
        "body_part_pada": "Bowels, lower digestive",
        "career_nuance": "Strategic stealth — corporate intelligence, hidden ambition, slow rise",
        "relationship_pattern": "Strategic in love, calculating, plays long games",
        "spiritual_lesson_pada": "Ambition wrapped in patience becomes mastery; in haste, becomes manipulation",
    },
    (9, 3): {
        "navamsa_sign": "Aquarius", "sub_lord": "Saturn",
        "akshara": "De", "akshara_sa": "डे",
        "body_part_pada": "Anus, base of spine",
        "career_nuance": "Unconventional occult — psychology, kundalini work, deep tech research",
        "relationship_pattern": "Detached fascination, unconventional bonds, hard to read",
        "spiritual_lesson_pada": "The mystic stands apart to see — but must return to share",
    },
    (9, 4): {
        "navamsa_sign": "Pisces", "sub_lord": "Jupiter",
        "akshara": "Do", "akshara_sa": "डो",
        "body_part_pada": "Joints, knees",
        "career_nuance": "Mystical healing — energy work, channeling, intuitive medicine",
        "relationship_pattern": "Dreamy mystical bonds, karmic partnerships, soul recognition",
        "spiritual_lesson_pada": "The deepest serpent wisdom dissolves into oceanic compassion",
    },

    # ─── 10. Magha (Leo 0°–13°20') — Aries-Taurus-Gemini-Cancer ───
    (10, 1): {
        "navamsa_sign": "Aries", "sub_lord": "Mars",
        "akshara": "Ma", "akshara_sa": "म",
        "body_part_pada": "Nose, upper jaw",
        "career_nuance": "Inherited leadership — taking over family business, royal initiative",
        "relationship_pattern": "Proud, leads pursuit, traditional courtship",
        "spiritual_lesson_pada": "Inherited power must be re-earned in your own time",
    },
    (10, 2): {
        "navamsa_sign": "Taurus", "sub_lord": "Venus",
        "akshara": "Mi", "akshara_sa": "मि",
        "body_part_pada": "Lips, chin",
        "career_nuance": "Inherited wealth — managing family fortune, luxury heritage",
        "relationship_pattern": "Sensual, traditional, marries within social class",
        "spiritual_lesson_pada": "Inheritance preserved is dharma; inheritance squandered is curse",
    },
    (10, 3): {
        "navamsa_sign": "Gemini", "sub_lord": "Mercury",
        "akshara": "Mu", "akshara_sa": "मु",
        "body_part_pada": "Lower jaw, mouth",
        "career_nuance": "Heritage communication — family business in media, genealogy, archives",
        "relationship_pattern": "Witty, well-spoken, courts through clever conversation",
        "spiritual_lesson_pada": "Tell the family's stories — keep the lineage alive in words",
    },
    (10, 4): {
        "navamsa_sign": "Cancer", "sub_lord": "Moon",
        "akshara": "Me", "akshara_sa": "मे",
        "body_part_pada": "Tongue, palate",
        "career_nuance": "Emotional inheritance — ancestral healing, family-pattern therapy",
        "relationship_pattern": "Deep emotional bonds, protective of family, mother-revering",
        "spiritual_lesson_pada": "Inherited wounds heal when the lineage is finally seen with love",
    },

    # ─── 11. Purva Phalguni (Leo 13°20'–26°40') — Leo-Virgo-Libra-Scorpio ───
    (11, 1): {
        "navamsa_sign": "Leo", "sub_lord": "Sun",
        "akshara": "Mo", "akshara_sa": "मो",
        "body_part_pada": "Lips, chin",
        "career_nuance": "Performance royalty — stage, film, public-facing leadership",
        "relationship_pattern": "Dramatic, generous, proud lover",
        "spiritual_lesson_pada": "Performance is play — don't get trapped in your own spotlight",
    },
    (11, 2): {
        "navamsa_sign": "Virgo", "sub_lord": "Mercury",
        "akshara": "Ta", "akshara_sa": "ट",
        "body_part_pada": "Genitals, lower abdomen",
        "career_nuance": "Refined pleasure — luxury service industry, beauty technicians, high-end hospitality",
        "relationship_pattern": "Particular about partners, refined romantic tastes",
        "spiritual_lesson_pada": "Pleasure refined is artistry — gross pleasure is mere indulgence",
    },
    (11, 3): {
        "navamsa_sign": "Libra", "sub_lord": "Venus",
        "akshara": "Ti", "akshara_sa": "टि",
        "body_part_pada": "Right hand, right thigh",
        "career_nuance": "Aesthetic celebration — wedding planning, romantic arts, partnership coaching",
        "relationship_pattern": "Pure romance, partnership-oriented, charming",
        "spiritual_lesson_pada": "Love beautified is sacred play — keep it pure of motive",
    },
    (11, 4): {
        "navamsa_sign": "Scorpio", "sub_lord": "Mars",
        "akshara": "Tu", "akshara_sa": "टु",
        "body_part_pada": "Genitals, hips",
        "career_nuance": "Intense pleasure work — Tantra, sensual healing, transformational arts",
        "relationship_pattern": "Magnetically erotic, transformational sex, intense bonds",
        "spiritual_lesson_pada": "Eros is fire — use it to cook the heart, not burn the house",
    },

    # ─── 12. Uttara Phalguni (Leo 26°40'–Virgo 10°00') — Sagittarius-Capricorn-Aquarius-Pisces ───
    (12, 1): {
        "navamsa_sign": "Sagittarius", "sub_lord": "Jupiter",
        "akshara": "Te", "akshara_sa": "टे",
        "body_part_pada": "Left hand, left thigh",
        "career_nuance": "Dharmic patronage — religious philanthropy, spiritual partnership",
        "relationship_pattern": "Idealistic, partnership-as-dharma, marriage as spiritual path",
        "spiritual_lesson_pada": "Vows are sacred — let them carry you, not bind you",
    },
    (12, 2): {
        "navamsa_sign": "Capricorn", "sub_lord": "Saturn",
        "akshara": "To", "akshara_sa": "टो",
        "body_part_pada": "Sexual organs",
        "career_nuance": "Long-term contract work — civil service, administrative law, structured charity",
        "relationship_pattern": "Slow trust, enduring marriage, builds estate together",
        "spiritual_lesson_pada": "Reliability is the highest gift — be the partner you'd want",
    },
    (12, 3): {
        "navamsa_sign": "Aquarius", "sub_lord": "Saturn",
        "akshara": "Pa", "akshara_sa": "प",
        "body_part_pada": "Joints (Virgo zone)",
        "career_nuance": "Group contracts — NGO leadership, cooperative ventures, collective patronage",
        "relationship_pattern": "Friendship-first marriages, unconventional bonds, equality-based",
        "spiritual_lesson_pada": "Brotherhood/sisterhood — the family of choice is also dharma",
    },
    (12, 4): {
        "navamsa_sign": "Pisces", "sub_lord": "Jupiter",
        "akshara": "Pi", "akshara_sa": "पि",
        "body_part_pada": "Knees, ankles",
        "career_nuance": "Compassionate patronage — silent philanthropy, foundation work, monastic giving",
        "relationship_pattern": "Devotional, sacrificial love, spiritual marriages",
        "spiritual_lesson_pada": "True patronage flows like a river — unseen, watering everything",
    },

    # ─── 13. Hasta (Virgo 10°00'–23°20') — Aries-Taurus-Gemini-Cancer ───
    (13, 1): {
        "navamsa_sign": "Aries", "sub_lord": "Mars",
        "akshara": "Pu", "akshara_sa": "पु",
        "body_part_pada": "Hands, fingers",
        "career_nuance": "Bold craft — surgery, sports requiring hands, pioneering manual work",
        "relationship_pattern": "Active, hands-on partner, takes initiative physically",
        "spiritual_lesson_pada": "Action through the hands — every gesture is sacred",
    },
    (13, 2): {
        "navamsa_sign": "Taurus", "sub_lord": "Venus",
        "akshara": "Sha", "akshara_sa": "ष",
        "body_part_pada": "Palms, fingertips",
        "career_nuance": "Sensual craft — pottery, sculpture, massage, sensual arts",
        "relationship_pattern": "Tactile lover, touch-language, slow patient bonding",
        "spiritual_lesson_pada": "The hand that creates beauty is itself a prayer",
    },
    (13, 3): {
        "navamsa_sign": "Gemini", "sub_lord": "Mercury",
        "akshara": "Na", "akshara_sa": "ण",
        "body_part_pada": "Hands (fine motor)",
        "career_nuance": "Skilled communication — writing, sign language, magic, sleight",
        "relationship_pattern": "Witty, quick-handed lover, playful and clever",
        "spiritual_lesson_pada": "The hand teaches what the mouth cannot — use it well",
    },
    (13, 4): {
        "navamsa_sign": "Cancer", "sub_lord": "Moon",
        "akshara": "Tha", "akshara_sa": "थ",
        "body_part_pada": "Hands (emotional/healing)",
        "career_nuance": "Healing hands — Reiki, energy healing, mother's touch professions",
        "relationship_pattern": "Nurturing through touch, emotional hands, comforter",
        "spiritual_lesson_pada": "Touch carries presence — let your hands speak love",
    },

    # ─── 14. Chitra (Virgo 23°20'–Libra 6°40') — Leo-Virgo-Libra-Scorpio ───
    (14, 1): {
        "navamsa_sign": "Leo", "sub_lord": "Sun",
        "akshara": "Pe", "akshara_sa": "पे",
        "body_part_pada": "Neck, forehead",
        "career_nuance": "Bold design — architecture of impressive structures, royal commissions",
        "relationship_pattern": "Magnetic, attracts attention, partner enjoys the spotlight",
        "spiritual_lesson_pada": "Brilliance shines best when used to illuminate others",
    },
    (14, 2): {
        "navamsa_sign": "Virgo", "sub_lord": "Mercury",
        "akshara": "Po", "akshara_sa": "पो",
        "body_part_pada": "Neck base, throat",
        "career_nuance": "Detailed design — graphic design, fine craft, precision engineering",
        "relationship_pattern": "Picky, refined tastes, methodical romance",
        "spiritual_lesson_pada": "Detail is devotion — every line drawn with care",
    },
    (14, 3): {
        "navamsa_sign": "Libra", "sub_lord": "Venus",
        "akshara": "Ra", "akshara_sa": "र",
        "body_part_pada": "Lower neck, collarbones",
        "career_nuance": "Aesthetic design — fashion, beauty industry leadership, interior design",
        "relationship_pattern": "Romantic, partnership focused, balanced and beautiful unions",
        "spiritual_lesson_pada": "Beauty in service of harmony — design for relationship",
    },
    (14, 4): {
        "navamsa_sign": "Scorpio", "sub_lord": "Mars",
        "akshara": "Ri", "akshara_sa": "रि",
        "body_part_pada": "Upper chest, breast",
        "career_nuance": "Transformative design — body modification, deep aesthetic transformation",
        "relationship_pattern": "Magnetic, intense, transformative bonds",
        "spiritual_lesson_pada": "The most beautiful designs reveal the soul beneath",
    },

    # ─── 15. Swati (Libra 6°40'–20°00') — Sagittarius-Capricorn-Aquarius-Pisces ───
    (15, 1): {
        "navamsa_sign": "Sagittarius", "sub_lord": "Jupiter",
        "akshara": "Ru", "akshara_sa": "रु",
        "body_part_pada": "Chest, heart",
        "career_nuance": "Free philosophy — independent teaching, traveling sage, free-spirited wisdom",
        "relationship_pattern": "Independent bonds, partner must respect freedom, philosophical love",
        "spiritual_lesson_pada": "Wisdom flowers in solitude — return to share, not to attach",
    },
    (15, 2): {
        "navamsa_sign": "Capricorn", "sub_lord": "Saturn",
        "akshara": "Re", "akshara_sa": "रे",
        "body_part_pada": "Stomach, upper belly",
        "career_nuance": "Disciplined freedom — independent contractors, free agents, lone wolves",
        "relationship_pattern": "Slow trust, structured independence, partnership with strong agreements",
        "spiritual_lesson_pada": "Discipline serves freedom — without it, freedom dissolves",
    },
    (15, 3): {
        "navamsa_sign": "Aquarius", "sub_lord": "Saturn",
        "akshara": "Ro", "akshara_sa": "रो",
        "body_part_pada": "Sides of body, ribs",
        "career_nuance": "Group freedom — independent tech founders, innovation labs, freelance communities",
        "relationship_pattern": "Unconventional bonds, friendship-first marriages, equal partnerships",
        "spiritual_lesson_pada": "Real community is independent souls choosing each other again",
    },
    (15, 4): {
        "navamsa_sign": "Pisces", "sub_lord": "Jupiter",
        "akshara": "Ta", "akshara_sa": "ता",
        "body_part_pada": "Abdomen, intestines",
        "career_nuance": "Mystical wanderer — spiritual seeker, monk, healing nomad",
        "relationship_pattern": "Dreamy mystical bonds, soul-connection, spiritual partnerships",
        "spiritual_lesson_pada": "Freedom dissolves into surrender — finally home in the wind",
    },

    # ─── 16. Vishakha (Libra 20°00'–Scorpio 3°20') — Aries-Taurus-Gemini-Cancer ───
    (16, 1): {
        "navamsa_sign": "Aries", "sub_lord": "Mars",
        "akshara": "Ti", "akshara_sa": "ती",
        "body_part_pada": "Sides of body",
        "career_nuance": "Aggressive ambition — startup founder, sales champion, athletic goals",
        "relationship_pattern": "Pursues with intensity, competitive in love, goal-oriented bonds",
        "spiritual_lesson_pada": "Ambition focused becomes excellence — scattered, becomes obsession",
    },
    (16, 2): {
        "navamsa_sign": "Taurus", "sub_lord": "Venus",
        "akshara": "Tu", "akshara_sa": "तू",
        "body_part_pada": "Abdomen, navel",
        "career_nuance": "Wealth ambition — luxury sales, banking, slow steady wealth-building",
        "relationship_pattern": "Patient long pursuit, marries for stability and beauty",
        "spiritual_lesson_pada": "Slow patient gains compound — the goal is the journey's destination",
    },
    (16, 3): {
        "navamsa_sign": "Gemini", "sub_lord": "Mercury",
        "akshara": "Te", "akshara_sa": "ते",
        "body_part_pada": "Hands, sides",
        "career_nuance": "Communicative ambition — strategic communications, sales leadership, multi-channel goals",
        "relationship_pattern": "Multiple romantic threads, witty pursuit, intellectual goals",
        "spiritual_lesson_pada": "Articulate your goals; speaking them makes them real",
    },
    (16, 4): {
        "navamsa_sign": "Cancer", "sub_lord": "Moon",
        "akshara": "To", "akshara_sa": "तो",
        "body_part_pada": "Belly, womb",
        "career_nuance": "Emotional ambition — building family legacy, nurturing-as-empire",
        "relationship_pattern": "Strong attachment to chosen partner, deeply emotional bonds in pursuit",
        "spiritual_lesson_pada": "The goal is the home you build for those you love",
    },

    # ─── 17. Anuradha (Scorpio 3°20'–16°40') — Leo-Virgo-Libra-Scorpio ───
    (17, 1): {
        "navamsa_sign": "Leo", "sub_lord": "Sun",
        "akshara": "Na", "akshara_sa": "ना",
        "body_part_pada": "Stomach, sides",
        "career_nuance": "Authoritative devotion — leadership in spiritual community, devotional performance",
        "relationship_pattern": "Dramatic devotion, magnetic loyalty, generous love",
        "spiritual_lesson_pada": "Devotion to a worthy cause makes the heart royal",
    },
    (17, 2): {
        "navamsa_sign": "Virgo", "sub_lord": "Mercury",
        "akshara": "Ni", "akshara_sa": "नि",
        "body_part_pada": "Abdomen, intestines",
        "career_nuance": "Service devotion — health workers, careful service, NGO operations",
        "relationship_pattern": "Methodical devotion, attentive partner, builds trust through small acts",
        "spiritual_lesson_pada": "Daily small devotions build temples of trust",
    },
    (17, 3): {
        "navamsa_sign": "Libra", "sub_lord": "Venus",
        "akshara": "Nu", "akshara_sa": "नु",
        "body_part_pada": "Lower abdomen",
        "career_nuance": "Diplomatic devotion — international relations, partnership coaching, dialogue work",
        "relationship_pattern": "Devoted to harmony, partnership-as-meditation, beautiful bonds",
        "spiritual_lesson_pada": "Devotion shows up as harmony — the lover's hands smooth all roughness",
    },
    (17, 4): {
        "navamsa_sign": "Scorpio", "sub_lord": "Mars",
        "akshara": "Ne", "akshara_sa": "ने",
        "body_part_pada": "Pelvis, reproductive zone",
        "career_nuance": "Transformative devotion — tantra, depth psychology, devotional crisis work",
        "relationship_pattern": "Intense devotion, soul-merging bonds, transformative love",
        "spiritual_lesson_pada": "The deepest devotion transforms both lover and beloved",
    },

    # ─── 18. Jyeshtha (Scorpio 16°40'–30°00') — Sagittarius-Capricorn-Aquarius-Pisces ───
    (18, 1): {
        "navamsa_sign": "Sagittarius", "sub_lord": "Jupiter",
        "akshara": "No", "akshara_sa": "नो",
        "body_part_pada": "Right side of trunk",
        "career_nuance": "Philosophical eldership — wisdom teacher, religious authority, dharmic CEO",
        "relationship_pattern": "Idealistic eldership, principled marriage, philosophical bond",
        "spiritual_lesson_pada": "Wisdom is the only authority worth wielding",
    },
    (18, 2): {
        "navamsa_sign": "Capricorn", "sub_lord": "Saturn",
        "akshara": "Ya", "akshara_sa": "य",
        "body_part_pada": "Right side, hip",
        "career_nuance": "Structured eldership — corporate seniority, government leadership, slow climb to top",
        "relationship_pattern": "Slow committed bond, partner becomes ally in long career",
        "spiritual_lesson_pada": "The eldest must carry the weight without complaint",
    },
    (18, 3): {
        "navamsa_sign": "Aquarius", "sub_lord": "Saturn",
        "akshara": "Yi", "akshara_sa": "यि",
        "body_part_pada": "Right thigh",
        "career_nuance": "Revolutionary eldership — leading reform from within, senior activism",
        "relationship_pattern": "Unconventional senior bonds, friendship-based marriage in maturity",
        "spiritual_lesson_pada": "The elder who keeps growing leads the tribe forward",
    },
    (18, 4): {
        "navamsa_sign": "Pisces", "sub_lord": "Jupiter",
        "akshara": "Yu", "akshara_sa": "यु",
        "body_part_pada": "Right knee",
        "career_nuance": "Compassionate eldership — chaplaincy, hospice leadership, monastic abbothood",
        "relationship_pattern": "Devotional bonds in elder years, spiritual partnership, soul recognition",
        "spiritual_lesson_pada": "True elders dissolve their own importance into universal love",
    },

    # ─── 19. Mula (Sagittarius 0°–13°20') — Aries-Taurus-Gemini-Cancer ───
    (19, 1): {
        "navamsa_sign": "Aries", "sub_lord": "Mars",
        "akshara": "Ye", "akshara_sa": "ये",
        "body_part_pada": "Right knee",
        "career_nuance": "Aggressive uprooting — disruption, demolition, breakthrough research",
        "relationship_pattern": "Fierce break-aways, intense root-finding in love, no patience for surface",
        "spiritual_lesson_pada": "What you uproot violently grows back the same — uproot gently",
    },
    (19, 2): {
        "navamsa_sign": "Taurus", "sub_lord": "Venus",
        "akshara": "Yo", "akshara_sa": "यो",
        "body_part_pada": "Lower legs, calves",
        "career_nuance": "Material root-finding — geology, agriculture, ancestral wealth recovery",
        "relationship_pattern": "Slow uprooting, sensual depth-seeking, patient transformation",
        "spiritual_lesson_pada": "Roots in the earth must be honored as you pull them up",
    },
    (19, 3): {
        "navamsa_sign": "Gemini", "sub_lord": "Mercury",
        "akshara": "Bha", "akshara_sa": "भ",
        "body_part_pada": "Knees, lower legs",
        "career_nuance": "Communicative root-cause — investigative journalism, deep research writing",
        "relationship_pattern": "Verbal depth-seeker, asks too many questions, breaks superficial bonds",
        "spiritual_lesson_pada": "Inquiry serves understanding; obsessive inquiry serves anxiety",
    },
    (19, 4): {
        "navamsa_sign": "Cancer", "sub_lord": "Moon",
        "akshara": "Bhi", "akshara_sa": "भि",
        "body_part_pada": "Knees, ankles",
        "career_nuance": "Emotional root-work — ancestral healing, family-system therapy, depth psychology",
        "relationship_pattern": "Goes to emotional roots, transformative attachments, mother-pattern work",
        "spiritual_lesson_pada": "The deepest root is love — uproot the false to reveal it",
    },

    # ─── 20. Purva Ashadha (Sagittarius 13°20'–26°40') — Leo-Virgo-Libra-Scorpio ───
    (20, 1): {
        "navamsa_sign": "Leo", "sub_lord": "Sun",
        "akshara": "Bhu", "akshara_sa": "भु",
        "body_part_pada": "Back, spine",
        "career_nuance": "Bold persuasion — political leadership, evangelism, public campaigning",
        "relationship_pattern": "Dramatic persuasive love, magnetic, leads partnership boldly",
        "spiritual_lesson_pada": "Lead with conviction, but listen with humility",
    },
    (20, 2): {
        "navamsa_sign": "Virgo", "sub_lord": "Mercury",
        "akshara": "Dha", "akshara_sa": "ध",
        "body_part_pada": "Back, lower back",
        "career_nuance": "Detailed argument — legal pleading, technical writing, methodical persuasion",
        "relationship_pattern": "Argumentative, methodical persuader, precise in romantic communication",
        "spiritual_lesson_pada": "Detail your case clearly; ambiguity is enemy of conviction",
    },
    (20, 3): {
        "navamsa_sign": "Libra", "sub_lord": "Venus",
        "akshara": "Pha", "akshara_sa": "फ",
        "body_part_pada": "Lower back, hips",
        "career_nuance": "Diplomatic argument — international negotiation, balanced advocacy, art critique",
        "relationship_pattern": "Charming persuader, partnership built on shared values, beauty as bond",
        "spiritual_lesson_pada": "Persuade with grace — the most convincing argument is also the most beautiful",
    },
    (20, 4): {
        "navamsa_sign": "Scorpio", "sub_lord": "Mars",
        "akshara": "Dhha", "akshara_sa": "ढ",
        "body_part_pada": "Hips, pelvis",
        "career_nuance": "Intense conviction — revolutionary leadership, deep cause activism, fierce advocacy",
        "relationship_pattern": "Magnetic intense persuasion, transformative bonds through belief",
        "spiritual_lesson_pada": "Conviction with shadow becomes fanaticism — keep the heart open",
    },

    # ─── 21. Uttara Ashadha (Sagittarius 26°40'–Capricorn 10°00') — Sagittarius-Capricorn-Aquarius-Pisces ───
    (21, 1): {
        "navamsa_sign": "Sagittarius", "sub_lord": "Jupiter",
        "akshara": "Bhe", "akshara_sa": "भे",
        "body_part_pada": "Thighs",
        "career_nuance": "Wise victory — philosophical leadership, dharmic CEO, principled judge",
        "relationship_pattern": "Idealistic principled bond, marriage as dharma path",
        "spiritual_lesson_pada": "Wisdom that endures becomes lineage — teach what you've lived",
    },
    (21, 2): {
        "navamsa_sign": "Capricorn", "sub_lord": "Saturn",
        "akshara": "Bho", "akshara_sa": "भो",
        "body_part_pada": "Knees (Capricorn zone)",
        "career_nuance": "Structured permanence — institutional leadership, slow legacy-building, judicial seniority",
        "relationship_pattern": "Slow committed lifelong bond, partner as co-builder of structure",
        "spiritual_lesson_pada": "Structure is dharma made physical — build slowly, build for centuries",
    },
    (21, 3): {
        "navamsa_sign": "Aquarius", "sub_lord": "Saturn",
        "akshara": "Ja", "akshara_sa": "ज",
        "body_part_pada": "Calves, shins",
        "career_nuance": "Reformist permanence — long-game social reform, institutional revolution",
        "relationship_pattern": "Equal partnership, shared mission, unconventional but lasting",
        "spiritual_lesson_pada": "The reform that endures is the one built carefully — patience reforms forever",
    },
    (21, 4): {
        "navamsa_sign": "Pisces", "sub_lord": "Jupiter",
        "akshara": "Ji", "akshara_sa": "जि",
        "body_part_pada": "Ankles, feet",
        "career_nuance": "Compassionate legacy — silent generational philanthropy, spiritual foundation work",
        "relationship_pattern": "Devotional lifelong bonds, soul recognition partnerships",
        "spiritual_lesson_pada": "The permanent victory is dissolution into universal benefit",
    },

    # ─── 22. Shravana (Capricorn 10°00'–23°20') — Aries-Taurus-Gemini-Cancer ───
    (22, 1): {
        "navamsa_sign": "Aries", "sub_lord": "Mars",
        "akshara": "Khi/Ju", "akshara_sa": "खि/जु",
        "body_part_pada": "Ankles",
        "career_nuance": "Bold listening — investigative journalism, active research, pioneering teaching",
        "relationship_pattern": "Listens intensely, pursues actively after hearing",
        "spiritual_lesson_pada": "Listen first, then act — but act decisively",
    },
    (22, 2): {
        "navamsa_sign": "Taurus", "sub_lord": "Venus",
        "akshara": "Khu/Je", "akshara_sa": "खु/जे",
        "body_part_pada": "Feet, ankles",
        "career_nuance": "Sensual listening — music, voice work, sound therapy, audio production",
        "relationship_pattern": "Patient attentive listener, sensual bonds through hearing",
        "spiritual_lesson_pada": "The voice held in trust is the most beautiful gift",
    },
    (22, 3): {
        "navamsa_sign": "Gemini", "sub_lord": "Mercury",
        "akshara": "Khe/Jo", "akshara_sa": "खे/जो",
        "body_part_pada": "Feet, soles",
        "career_nuance": "Communicative listening — translation, transcription, communication therapy",
        "relationship_pattern": "Quick listener, witty responder, intellectual communication-based bonds",
        "spiritual_lesson_pada": "Speak only after fully understanding — words mean what their context allows",
    },
    (22, 4): {
        "navamsa_sign": "Cancer", "sub_lord": "Moon",
        "akshara": "Kho/Gha", "akshara_sa": "खो/घ",
        "body_part_pada": "Feet, toes",
        "career_nuance": "Emotional listening — therapy, counseling, devotional music",
        "relationship_pattern": "Deeply attentive emotional bonds, mother-quality listening",
        "spiritual_lesson_pada": "To listen with the heart is the highest form of presence",
    },

    # ─── 23. Dhanishta (Capricorn 23°20'–Aquarius 6°40') — Leo-Virgo-Libra-Scorpio ───
    (23, 1): {
        "navamsa_sign": "Leo", "sub_lord": "Sun",
        "akshara": "Ga", "akshara_sa": "ग",
        "body_part_pada": "Back, soles",
        "career_nuance": "Royal wealth — luxury industry leadership, performance royalty, rhythm-based fame",
        "relationship_pattern": "Generous magnetic partner, leads social bonds",
        "spiritual_lesson_pada": "Abundance shared is the rhythm of generosity",
    },
    (23, 2): {
        "navamsa_sign": "Virgo", "sub_lord": "Mercury",
        "akshara": "Gi", "akshara_sa": "गि",
        "body_part_pada": "Soles, ankles",
        "career_nuance": "Skilled wealth — precision in finance, technical music, careful resource management",
        "relationship_pattern": "Detail-oriented partnerships, methodical investments in love",
        "spiritual_lesson_pada": "Wealth refined by skill is more than wealth — it is service",
    },
    (23, 3): {
        "navamsa_sign": "Libra", "sub_lord": "Venus",
        "akshara": "Gu", "akshara_sa": "गु",
        "body_part_pada": "Ankles, soles",
        "career_nuance": "Aesthetic wealth — luxury arts, fashion finance, beauty industry",
        "relationship_pattern": "Beautiful balanced partnerships, harmonious wealth-building",
        "spiritual_lesson_pada": "Beauty and abundance dance together — invite both consciously",
    },
    (23, 4): {
        "navamsa_sign": "Scorpio", "sub_lord": "Mars",
        "akshara": "Ge", "akshara_sa": "गे",
        "body_part_pada": "Sides of feet",
        "career_nuance": "Transformative wealth — turnaround financiers, crisis fund management, deep music",
        "relationship_pattern": "Intense bonds, transformative through shared resources",
        "spiritual_lesson_pada": "Wealth used to transform suffering is sacred currency",
    },

    # ─── 24. Shatabhisha (Aquarius 6°40'–20°00') — Sagittarius-Capricorn-Aquarius-Pisces ───
    (24, 1): {
        "navamsa_sign": "Sagittarius", "sub_lord": "Jupiter",
        "akshara": "Go", "akshara_sa": "गो",
        "body_part_pada": "Jaw, right thigh",
        "career_nuance": "Philosophical healing — esoteric teaching, spiritual research, mystical philosophy",
        "relationship_pattern": "Independent philosophical bonds, partner must respect mystical solitude",
        "spiritual_lesson_pada": "The healer who reads the deep waters need not explain to all",
    },
    (24, 2): {
        "navamsa_sign": "Capricorn", "sub_lord": "Saturn",
        "akshara": "Sa", "akshara_sa": "सा",
        "body_part_pada": "Jaw, right knee",
        "career_nuance": "Structured healing — medical research, chronic care, long-term mystical practice",
        "relationship_pattern": "Slow patient bonds, partners learn over years to access depth",
        "spiritual_lesson_pada": "Some wisdom requires decades — be patient with the depth",
    },
    (24, 3): {
        "navamsa_sign": "Aquarius", "sub_lord": "Saturn",
        "akshara": "Si", "akshara_sa": "सि",
        "body_part_pada": "Knees, calves",
        "career_nuance": "Innovative healing — tech-based medicine, breakthrough therapeutics, scientific occult",
        "relationship_pattern": "Unconventional eccentric bonds, fellow-traveler partnerships",
        "spiritual_lesson_pada": "Innovation is the future of healing — but ancient wisdom guides it",
    },
    (24, 4): {
        "navamsa_sign": "Pisces", "sub_lord": "Jupiter",
        "akshara": "Su", "akshara_sa": "सु",
        "body_part_pada": "Feet, ankles",
        "career_nuance": "Oceanic healing — energy work, dissolved-self mysticism, profound silence",
        "relationship_pattern": "Mystical soul recognition, partnerships that transcend ordinary bonds",
        "spiritual_lesson_pada": "Final healing is dissolution into the ocean from which all medicines come",
    },

    # ─── 25. Purva Bhadrapada (Aquarius 20°00'–Pisces 3°20') — Aries-Taurus-Gemini-Cancer ───
    (25, 1): {
        "navamsa_sign": "Aries", "sub_lord": "Mars",
        "akshara": "Se", "akshara_sa": "से",
        "body_part_pada": "Sides of body",
        "career_nuance": "Bold transformation — pioneering deep work, revolutionary mystical activism",
        "relationship_pattern": "Intense ignitions, transformative encounters, fast-burning bonds",
        "spiritual_lesson_pada": "Vertical fire must be channeled or it consumes the channeler",
    },
    (25, 2): {
        "navamsa_sign": "Taurus", "sub_lord": "Venus",
        "akshara": "So", "akshara_sa": "सो",
        "body_part_pada": "Feet, soles",
        "career_nuance": "Material transformation — funeral industry, body-disposal arts, transformative crafts",
        "relationship_pattern": "Sensual intense bonds, transformative through physical depth",
        "spiritual_lesson_pada": "Even fire must touch earth to do its sacred work",
    },
    (25, 3): {
        "navamsa_sign": "Gemini", "sub_lord": "Mercury",
        "akshara": "Da", "akshara_sa": "दा",
        "body_part_pada": "Feet",
        "career_nuance": "Communicative intensity — exposé writing, transformative communication, edge-of-knowledge teaching",
        "relationship_pattern": "Verbal intensity, communication through crisis, philosophical fire",
        "spiritual_lesson_pada": "Words carry fire — choose them with reverence",
    },
    (25, 4): {
        "navamsa_sign": "Cancer", "sub_lord": "Moon",
        "akshara": "Di", "akshara_sa": "दि",
        "body_part_pada": "Feet, soles",
        "career_nuance": "Emotional transformation — grief work, ancestral fire-ceremonies, mother-line healing",
        "relationship_pattern": "Deep emotional intensity, family-pattern transformation bonds",
        "spiritual_lesson_pada": "The fire of grief illuminates love that was always there",
    },

    # ─── 26. Uttara Bhadrapada (Pisces 3°20'–16°40') — Leo-Virgo-Libra-Scorpio ───
    (26, 1): {
        "navamsa_sign": "Leo", "sub_lord": "Sun",
        "akshara": "Du", "akshara_sa": "दु",
        "body_part_pada": "Sides of body",
        "career_nuance": "Authoritative depth — senior wisdom-keeper, dharmic leader of deep work",
        "relationship_pattern": "Magnetic deep bonds, partner enjoys the dignity",
        "spiritual_lesson_pada": "Depth without humility becomes pride — depth with humility becomes lineage",
    },
    (26, 2): {
        "navamsa_sign": "Virgo", "sub_lord": "Mercury",
        "akshara": "Tha", "akshara_sa": "थ",
        "body_part_pada": "Sides of trunk, ribs",
        "career_nuance": "Skilled depth — depth psychology, careful mystical research, methodical wisdom-writing",
        "relationship_pattern": "Methodical deep bonds, careful intimacy, slow trust",
        "spiritual_lesson_pada": "Detail in mystical work prevents grandiosity",
    },
    (26, 3): {
        "navamsa_sign": "Libra", "sub_lord": "Venus",
        "akshara": "Jha", "akshara_sa": "झ",
        "body_part_pada": "Lower trunk, shins",
        "career_nuance": "Aesthetic depth — mystical art, contemplative design, deep beauty work",
        "relationship_pattern": "Beautiful soul bonds, partnership through deep aesthetic resonance",
        "spiritual_lesson_pada": "Beauty at depth is what makes mysticism touchable",
    },
    (26, 4): {
        "navamsa_sign": "Scorpio", "sub_lord": "Mars",
        "akshara": "Da/Tra", "akshara_sa": "द/त्र",
        "body_part_pada": "Shins, calves",
        "career_nuance": "Transformative depth — deep crisis counseling, transformative mystical practice, soul-level work",
        "relationship_pattern": "Intense soul-bonds, transformative through depth-encounter",
        "spiritual_lesson_pada": "The serpent of the depths transforms whoever swims with it consciously",
    },

    # ─── 27. Revati (Pisces 16°40'–30°00') — Sagittarius-Capricorn-Aquarius-Pisces ───
    (27, 1): {
        "navamsa_sign": "Sagittarius", "sub_lord": "Jupiter",
        "akshara": "De", "akshara_sa": "दे",
        "body_part_pada": "Ankles",
        "career_nuance": "Philosophical gentleness — wise teaching of compassion, dharmic animal/children work",
        "relationship_pattern": "Idealistic gentle bonds, partnership as dharmic completion",
        "spiritual_lesson_pada": "Wisdom completed is gentleness perfected",
    },
    (27, 2): {
        "navamsa_sign": "Capricorn", "sub_lord": "Saturn",
        "akshara": "Do", "akshara_sa": "दो",
        "body_part_pada": "Feet, soles",
        "career_nuance": "Structured completion — institutional veterinary, organized children's care, formal endings",
        "relationship_pattern": "Slow patient gentle bonds, partnerships in mature completion",
        "spiritual_lesson_pada": "Structure serves the gentle completion of all cycles",
    },
    (27, 3): {
        "navamsa_sign": "Aquarius", "sub_lord": "Saturn",
        "akshara": "Cha", "akshara_sa": "च",
        "body_part_pada": "Soles, toes",
        "career_nuance": "Innovative gentleness — community animal welfare, group teaching of compassion",
        "relationship_pattern": "Unconventional gentle bonds, community-based partnerships",
        "spiritual_lesson_pada": "Gentle innovation makes the future kind",
    },
    (27, 4): {
        "navamsa_sign": "Pisces", "sub_lord": "Jupiter",
        "akshara": "Chi", "akshara_sa": "चि",
        "body_part_pada": "Toes (final body part of the Kalapurusha)",
        "career_nuance": "Final dissolution — hospice masters, end-of-life music, mystical completion arts",
        "relationship_pattern": "Soul-recognition gentle bonds, dissolved-self partnerships",
        "spiritual_lesson_pada": "The final pada — return all you've received, dissolve into love",
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# UTILITY: get pada from longitude (in degrees, 0-360)
# ─────────────────────────────────────────────────────────────────────────────

def get_nakshatra_and_pada(longitude_deg: float) -> Tuple[int, int]:
    """
    Given a longitude 0-360°, returns (nakshatra_index, pada_number).
    Each nakshatra spans 13°20' = 13.333°. Each pada spans 3°20' = 3.333°.
    """
    longitude_deg = longitude_deg % 360
    nakshatra_idx = int(longitude_deg / 13.333333) + 1  # 1-27
    within_nak = longitude_deg - (nakshatra_idx - 1) * 13.333333
    pada = int(within_nak / 3.333333) + 1  # 1-4
    pada = max(1, min(4, pada))
    nakshatra_idx = max(1, min(27, nakshatra_idx))
    return nakshatra_idx, pada
