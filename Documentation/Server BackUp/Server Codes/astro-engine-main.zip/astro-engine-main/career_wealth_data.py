"""
career_wealth_data.py — Classical career + wealth data

Sources (all public domain):
- Brihat Parashara Hora Shastra (BPHS) Ch. 35-40
- Phaladeepika (Mantreshwar) Ch. 6, 12
- Jataka Parijata Ch. 12-13
- Saravali (Kalyana Varma) Ch. 25-26
- Sarvartha Chintamani (Venkatesh) Ch. 12-13
- Jaimini Sutras Ch. 1-2
"""

# ════════════════════════════════════════════════════════════════════════
# 1. CAREER FIELDS BY PLANET
# Source: Phaladeepika Ch. 6 + Saravali Ch. 25 + Jataka Parijata
# ════════════════════════════════════════════════════════════════════════

CAREER_FIELDS_BY_PLANET = {
    "Sun": {
        "core_archetype": "leader, sovereign, authority figure",
        "fields": [
            "government service, political office", "administration, IAS/IPS",
            "medicine (especially cardiology, ophthalmology)", "leadership roles in any industry",
            "law (judiciary, constitutional)", "father-related occupations",
            "father's profession", "gold and jewelry industry", "vitamins/wellness leadership",
        ],
        "roles":            ["CEO", "Director", "Magistrate", "Surgeon", "Father", "King-figure"],
        "industries":       ["Government", "Healthcare", "Politics", "Law", "Pharma", "Leadership"],
        "natural_skills":   ["decisive leadership", "command presence", "vision casting", "authority"],
        "key_houses":       [1, 9, 10],
        "weakened_when":    "Saturn squares or aspects severely, debilitated in Libra",
    },
    "Moon": {
        "core_archetype": "nurturer, public-facing, fluid-related",
        "fields": [
            "hospitality, hotels, restaurants", "F&B industry", "dairy + milk business",
            "fishery, marine industries", "shipping, navigation", "maternal-care (pediatrics, OBGYN, midwifery)",
            "psychology, counseling, therapy", "real estate (especially residential)", "agriculture, crops",
            "mass media (TV, social media — public-facing)", "fashion, hospitality, comfort goods",
        ],
        "roles":            ["Hotelier", "Therapist", "Mother", "Public Spokesperson", "Counselor", "Chef"],
        "industries":       ["Hospitality", "Mental Health", "Real Estate", "F&B", "Media", "Agriculture"],
        "natural_skills":   ["empathy", "emotional intelligence", "nurturing", "public connection"],
        "key_houses":       [4, 7, 11],
        "weakened_when":    "in Scorpio (debilitated), waning phase (Krishna paksha) with malefics",
    },
    "Mars": {
        "core_archetype": "warrior, surgeon, real estate, engineer",
        "fields": [
            "military, defense, police", "surgery (especially trauma, orthopedic)",
            "real estate, construction, civil engineering", "athletics, sports",
            "mechanical engineering, automotive", "fire-related (firefighting, metallurgy)",
            "weapons/security industry", "land/property dealing", "physical fitness/martial arts coaching",
            "competitive industries", "sales (aggressive)", "litigation lawyering",
        ],
        "roles":            ["Surgeon", "Engineer", "Athlete", "Soldier", "Realtor", "Trial Lawyer"],
        "industries":       ["Defense", "Real Estate", "Engineering", "Sports", "Surgery", "Construction"],
        "natural_skills":   ["physical courage", "decisive action", "competitive drive", "spatial reasoning"],
        "key_houses":       [3, 6, 10],
        "weakened_when":    "debilitated in Cancer, with Saturn (causing delays in action)",
    },
    "Mercury": {
        "core_archetype": "communicator, intellectual, trader, professional",
        "fields": [
            "writing, journalism, publishing", "education, teaching, tutoring",
            "accounting, finance, banking", "business (especially trade, retail)",
            "law (corporate, contracts)", "communication (sales, PR, marketing)",
            "translation, languages, linguistics", "data science, analytics, statistics",
            "programming, software engineering", "advisory, consulting",
            "stockbroking, commerce", "intellectual property law", "publishing house, editing",
        ],
        "roles":            ["Writer", "Lawyer", "Accountant", "Programmer", "Teacher", "Trader"],
        "industries":       ["Education", "Finance", "Technology", "Media", "Law", "Consulting"],
        "natural_skills":   ["communication", "analytical thinking", "rapid learning", "networking"],
        "key_houses":       [2, 3, 5, 10],
        "weakened_when":    "combust (close to Sun within 14 degrees), debilitated in Pisces",
    },
    "Jupiter": {
        "core_archetype": "teacher, guru, advisor, expander",
        "fields": [
            "teaching (especially higher education, philosophy)", "religion, priestly duties",
            "law (especially philosophy of law, constitutional)", "finance (especially banking, advisory)",
            "publishing, especially philosophical/spiritual books", "philanthropy, NGO leadership",
            "judiciary", "wealth management, financial advising", "yoga teaching, spiritual instruction",
            "Ayurveda, traditional medicine", "diplomacy, embassy work", "academia (PhD level, professor)",
        ],
        "roles":            ["Professor", "Guru", "Banker", "Judge", "Priest", "Philanthropist"],
        "industries":       ["Education", "Religion", "Banking", "Philosophy", "Diplomacy", "Wealth Management"],
        "natural_skills":   ["wisdom", "moral guidance", "expansion thinking", "blessing-bestowing"],
        "key_houses":       [5, 9, 11],
        "weakened_when":    "debilitated in Capricorn, retrograde in dushthana houses",
    },
    "Venus": {
        "core_archetype": "creator, artist, lover, luxury",
        "fields": [
            "music, performing arts", "visual arts (painting, photography, design)",
            "film industry, entertainment", "fashion, beauty, cosmetics", "jewelry, gem industry",
            "luxury goods, hospitality (high-end)", "wine, perfumery", "marriage counseling",
            "interior design, architecture (aesthetic side)", "wedding industry", "feminine product industries",
            "automotive (luxury vehicles)", "art dealing, gallery curation",
        ],
        "roles":            ["Artist", "Designer", "Actor", "Musician", "Jeweler", "Aesthetician"],
        "industries":       ["Arts", "Fashion", "Film", "Luxury Goods", "Jewelry", "Hospitality"],
        "natural_skills":   ["creative aesthetics", "charisma", "diplomacy", "harmonizing"],
        "key_houses":       [2, 4, 5, 7],
        "weakened_when":    "combust, debilitated in Virgo, with Mars/Saturn (relationship issues)",
    },
    "Saturn": {
        "core_archetype": "disciplinarian, laborer, organizer, longevity worker",
        "fields": [
            "mining, oil/gas industry", "agriculture (especially long-duration crops)",
            "construction (heavy infrastructure)", "manufacturing, factory work",
            "transportation (especially shipping, logistics)", "law enforcement, prison administration",
            "civil service (long-tenure)", "elder care, gerontology", "labor management, HR (industrial)",
            "research (long-term, PhD-level)", "monastic life, ascetic professions",
            "history, archaeology, ancient studies", "machinery/equipment industry",
            "wholesale/B2B (long-cycle)", "rental/leasing industries",
        ],
        "roles":            ["Engineer (industrial)", "Lawyer (long-cases)", "Researcher", "Administrator", "Monk"],
        "industries":       ["Mining", "Oil & Gas", "Heavy Manufacturing", "Logistics", "Construction"],
        "natural_skills":   ["patience", "discipline", "long-term planning", "endurance"],
        "key_houses":       [3, 6, 10, 11],
        "weakened_when":    "debilitated in Aries, in 4th from natal position",
    },
    "Rahu": {
        "core_archetype": "outsider, innovator, foreign-related, disruptor",
        "fields": [
            "technology, especially cutting-edge (AI, crypto, biotech)", "internet/digital business",
            "foreign trade, international relations", "diplomacy, foreign affairs",
            "research in mysterious/hidden subjects", "occult sciences (astrology, tarot, etc.)",
            "innovative startup founder", "drugs and chemicals (pharmaceutical too)",
            "outsourcing (BPO/KPO)", "manipulation arts (PR, psychology)",
            "unconventional careers", "investigative journalism", "espionage/security",
            "addictions therapy (caution if practitioner has Rahu afflictions)",
        ],
        "roles":            ["Founder", "Researcher", "Diplomat", "Innovator", "Disruptor", "Mystic"],
        "industries":       ["Tech", "Crypto/Blockchain", "Foreign Trade", "Occult", "Pharma", "Startups"],
        "natural_skills":   ["unconventional thinking", "boldness", "mystery", "global vision"],
        "key_houses":       [3, 6, 10, 11],
        "weakened_when":    "in 6/8/12 with severe afflictions; addiction risk",
    },
    "Ketu": {
        "core_archetype": "ascetic, researcher, healer, moksha-seeker",
        "fields": [
            "meditation, spirituality (teaching)", "yoga (especially Hatha, Ashtanga teaching)",
            "research (deep, long-cycle)", "healing arts (especially energy healing, Reiki)",
            "metaphysics, philosophy", "monastic professions", "ascetic lifestyles",
            "computer programming (deep abstract code)", "mathematics, theoretical physics",
            "alternative medicine", "veterinary medicine (animal healing)", "intuitive consulting",
            "ancient languages (Sanskrit, Pali)", "tantric or esoteric practices",
        ],
        "roles":            ["Healer", "Researcher", "Teacher (spiritual)", "Programmer", "Yogi", "Mystic"],
        "industries":       ["Spirituality", "Research", "Healing", "Programming", "Academia"],
        "natural_skills":   ["detachment", "deep focus", "intuition", "mystical insight"],
        "key_houses":       [9, 12],
        "weakened_when":    "in 1/7/10 (causing isolation in worldly endeavors)",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 2. HOUSE-BASED CAREER INDICATORS
# Source: BPHS Ch. 11 (Karma Bhava) + Phaladeepika Ch. 6
# ════════════════════════════════════════════════════════════════════════

CAREER_HOUSES = {
    1:  "self-employment, personal brand-driven careers, leadership of one's own enterprise",
    2:  "wealth-accumulating careers, family business, food-related, speech-based",
    3:  "communication, siblings-business, journalism, courageous initiatives, short trips",
    4:  "real estate, mother-related, home-based, agricultural, vehicle industries",
    5:  "creativity, intelligence-driven, education, children, financial markets (speculative)",
    6:  "service careers, healthcare, legal (defending), competitive professions, military",
    7:  "partnerships, public-facing, business with others, marriage-related",
    8:  "research, investigation, occult, insurance, surgery, transformation industries",
    9:  "long-distance, foreign work, teaching, publishing, dharmic professions",
    10: "primary career karma — peak status, government, public reputation",
    11: "gains, network-based, social income, sponsorships, large groups",
    12: "foreign service, hidden careers (spy, monk), hospital work, sleep research, charity",
}


# ════════════════════════════════════════════════════════════════════════
# 3. DHANA YOGAS (WEALTH-BESTOWING COMBINATIONS)
# Source: BPHS Ch. 40 + Phaladeepika Ch. 12 + Jataka Parijata
# ════════════════════════════════════════════════════════════════════════

DHANA_YOGAS = {
    "_description": "Dhana yogas are combinations that bestow wealth. Strongest involve 2nd, 5th, 9th, 11th lords (Dhana-Dhana karaka).",
    "yogas": {
        "lakshmi_yoga": {
            "name":        "Lakshmi Yoga",
            "rule":        "9th lord in own/exalted sign + Lagna lord strong",
            "effect":      "Wealth, beauty, multiple sources of income, fame, attractive spouse",
            "rare":        False,
            "source":      "BPHS Ch. 40",
        },
        "kuber_yoga": {
            "name":        "Kuber Yoga",
            "rule":        "2nd lord and 11th lord conjoin in a kendra (1,4,7,10)",
            "effect":      "Accumulation of wealth, treasures, gains through investments",
            "rare":        False,
            "source":      "Phaladeepika Ch. 12",
        },
        "dhana_yoga_general": {
            "name":        "Dhana Yoga (General)",
            "rule":        "Connection (conjunction/exchange/aspect) between lords of 2, 5, 9, 11",
            "effect":      "Generic wealth indicator — strength varies by which lords combine",
            "rare":        False,
            "source":      "BPHS Ch. 40.1-15",
        },
        "vipreet_raja_yoga": {
            "name":        "Vipreet Raja Yoga",
            "rule":        "Lords of 6, 8, 12 exchange or mutually aspect WITHOUT connection to good houses",
            "effect":      "Wealth through unconventional means — defeating obstacles, sudden gains",
            "rare":        False,
            "source":      "Mantreshwar — Phaladeepika",
        },
        "chandra_mangala_yoga": {
            "name":        "Chandra-Mangala Yoga",
            "rule":        "Moon + Mars conjunction (any house)",
            "effect":      "Wealth through trade, business, real estate (often through hard work)",
            "rare":        False,
            "source":      "Saravali Ch. 38",
        },
        "guru_mangala_yoga": {
            "name":        "Guru-Mangala Yoga",
            "rule":        "Jupiter + Mars conjunction or mutual aspect",
            "effect":      "Wealth through enterprise, land, property, expansion",
            "rare":        False,
            "source":      "Phaladeepika",
        },
        "shukra_guru_yoga": {
            "name":        "Shukra-Guru Yoga (Lakshmi-Narayana)",
            "rule":        "Venus + Jupiter conjunction or exchange",
            "effect":      "Greatest wealth-bestowing combination — combines luxury (Venus) with wisdom (Jupiter)",
            "rare":        False,
            "source":      "BPHS",
        },
        "neecha_bhanga_raja_yoga": {
            "name":        "Neecha Bhanga Raja Yoga",
            "rule":        "Debilitated planet's debilitation gets cancelled — through specific conditions",
            "effect":      "Unexpected great rise from humble beginnings (rags to riches)",
            "rare":        True,
            "source":      "BPHS Ch. 35.55",
        },
        "kahala_yoga": {
            "name":        "Kahala Yoga",
            "rule":        "4th and 9th lords conjoin in kendra, with Lagna lord strong",
            "effect":      "Wealth, possessions, vehicles, fame, leadership of a region",
            "rare":        False,
            "source":      "Phaladeepika",
        },
        "shree_yoga": {
            "name":        "Shree Yoga (variant of Lakshmi)",
            "rule":        "Strong 2nd house + Jupiter in 5th or 9th",
            "effect":      "Income flows steadily, family prosperity",
            "rare":        False,
            "source":      "Saravali",
        },
    },
}


# ════════════════════════════════════════════════════════════════════════
# 4. RAJA YOGAS (POWER-BESTOWING COMBINATIONS)
# Source: BPHS Ch. 35-37 + Phaladeepika Ch. 6
# ════════════════════════════════════════════════════════════════════════

RAJA_YOGAS = {
    "_description": "Raja yogas bestow status, authority, success. Strongest formed by kendra (1,4,7,10) + trikona (1,5,9) lord combinations.",
    "yogas": {
        "classical_raja_yoga": {
            "name":   "Raja Yoga (Classical)",
            "rule":   "Kendra lord + trikona lord in conjunction, aspect, or exchange (parivartana)",
            "effect": "Authority, status, leadership in chosen field",
            "source": "BPHS Ch. 35",
        },
        "panch_mahapurusha_ruchaka": {
            "name":   "Ruchaka Yoga (Mars Mahapurusha)",
            "rule":   "Mars in own/exalted sign in kendra (1, 4, 7, or 10)",
            "effect": "Military/athletic/surgical excellence, fame, courage, fierce reputation",
            "source": "BPHS Ch. 36",
        },
        "panch_mahapurusha_bhadra": {
            "name":   "Bhadra Yoga (Mercury Mahapurusha)",
            "rule":   "Mercury in own/exalted sign in kendra",
            "effect": "Intellectual excellence, business success, eloquence, longevity",
            "source": "BPHS Ch. 36",
        },
        "panch_mahapurusha_hamsa": {
            "name":   "Hamsa Yoga (Jupiter Mahapurusha)",
            "rule":   "Jupiter in own/exalted sign in kendra",
            "effect": "Wisdom, teacher status, religious leadership, blessed life",
            "source": "BPHS Ch. 36",
        },
        "panch_mahapurusha_malavya": {
            "name":   "Malavya Yoga (Venus Mahapurusha)",
            "rule":   "Venus in own/exalted sign in kendra",
            "effect": "Luxury, artistic fame, beauty, charisma, comfortable life",
            "source": "BPHS Ch. 36",
        },
        "panch_mahapurusha_sasha": {
            "name":   "Sasha Yoga (Saturn Mahapurusha)",
            "rule":   "Saturn in own/exalted sign in kendra",
            "effect": "Authority through hard work, longevity, leadership of masses",
            "source": "BPHS Ch. 36",
        },
        "gaja_kesari_yoga": {
            "name":   "Gaja-Kesari Yoga",
            "rule":   "Jupiter in kendra from Moon (1, 4, 7, 10 from Moon)",
            "effect": "Fame, intelligence, wealth, eloquence — 'elephant + lion' strength",
            "source": "BPHS Ch. 37",
        },
        "budha_aditya_yoga": {
            "name":   "Budha-Aditya Yoga",
            "rule":   "Sun + Mercury conjunction (without combustion ideally)",
            "effect": "Intellectual brilliance, governmental favor, education-based success",
            "source": "Saravali Ch. 38",
        },
    },
}


# ════════════════════════════════════════════════════════════════════════
# 5. INCOME SOURCES BY 11TH HOUSE
# Source: BPHS Ch. 38
# ════════════════════════════════════════════════════════════════════════

INCOME_SOURCES_BY_11TH_LORD = {
    "Sun":     "government salary, leadership pay, paternal inheritance, gold-related",
    "Moon":    "public-related income, women clients, fluids/F&B, real estate, mother",
    "Mars":    "real estate, athletics, military pay, technical/engineering, blood-related industries",
    "Mercury": "business income, commissions, writing, education fees, intermediary work",
    "Jupiter": "advisory fees, teaching, philanthropic returns, financial advisory, banking",
    "Venus":   "art, luxury, partnerships, women-related, music, beauty industry",
    "Saturn":  "service salary, long-term contracts, agriculture, mining, labor-intensive",
    "Rahu":    "foreign income, technology, online income, multiple unconventional sources",
    "Ketu":    "spiritual gifts, healing fees, hidden sources, intuitive income",
}


# ════════════════════════════════════════════════════════════════════════
# 6. WEALTH RISK INDICATORS
# Source: BPHS Ch. 40 + Mantreshwar
# ════════════════════════════════════════════════════════════════════════

WEALTH_RISK_INDICATORS = {
    "12th_house_focus": {
        "description": "12th house = vyaya bhava (expense/loss). Strong malefics here = leakage.",
        "by_planet_in_12": {
            "Sun":     "expenses through authority disputes, government issues",
            "Moon":    "emotional/comfort spending, foreign expenses, mother-related",
            "Mars":    "expenses on litigation, accidents, sudden losses",
            "Mercury": "expenses on travel, intellectual ventures, communication",
            "Jupiter": "expenses on spirituality, philanthropy (positive form)",
            "Venus":   "expenses on luxury, women, art, beauty",
            "Saturn":  "delays in income, chronic losses, foreign-land losses",
            "Rahu":    "addictions, foreign losses, technology-related drains",
            "Ketu":    "hidden losses, expenses on spiritual pursuits, donations",
        },
    },
    "8th_house_wealth_loss": {
        "description": "Lord of 2 (wealth) or 11 (gains) in 8th = sudden wealth changes",
        "rule":        "If 2nd or 11th lord is afflicted in 8th, wealth may come and go unexpectedly",
    },
    "debilitated_benefics": {
        "description": "Benefic planets (Jup, Ven, Mer, Moon) in debilitation weaken wealth indicators",
    },
    "kemadruma_yoga": {
        "description": "Moon alone, no planets in 2nd or 12th from Moon = wealth/recognition challenges",
        "rule":        "Empty 2nd and 12th from Moon (without planets) — classical poverty yoga",
        "cancellation":"If Moon in kendra from Lagna or any planet aspects Moon, yoga cancels",
    },
    "daridra_yoga": {
        "description": "Lord of 11th in 6, 8, or 12 = challenges in gains",
        "source":      "BPHS Ch. 40",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 7. INCOME TIMING WINDOWS BY DASHA
# Source: BPHS Vimshottari Dasha analysis
# ════════════════════════════════════════════════════════════════════════

INCOME_TIMING_BY_DASHA = {
    "_description": "Favorable income periods identified by dasha lord's relationship to 2nd, 11th, 9th houses.",
    "wealth_dasha_principles": [
        "MD/AD of 2nd lord = wealth accumulation period",
        "MD/AD of 11th lord = gains, income peaks",
        "MD/AD of 9th lord = luck-based gains, fortune",
        "MD/AD of 5th lord = speculative gains (lottery, stock market — high risk)",
        "MD/AD of dhana yoga participating planet = enhanced effect",
        "Jupiter MD/AD (when Jupiter is strong) = generally wealth-positive",
        "Saturn MD/AD = slow accumulation; high impact when Saturn is yogakaraka (Libra/Taurus lagna)",
        "Avoid major investments during MD of 8th or 12th lord unless connected to gains",
    ],
}


# ════════════════════════════════════════════════════════════════════════
# 8. WEALTH REMEDIES — SPECIFIC TO WEALTH ENHANCEMENT
# Source: Composite Lal Kitab + classical
# ════════════════════════════════════════════════════════════════════════

WEALTH_REMEDIES = {
    "deities": {
        "primary":    "Mahalakshmi (Shukla paksha Friday)",
        "secondary":  ["Kubera (north direction worship)", "Ganesha (obstacle removal for wealth)", "Saraswati (intelligent income)"],
        "stotras":    ["Sri Suktam", "Lakshmi Ashtottara", "Mahalakshmi Ashtakam", "Kanakadhara Stotram"],
    },
    "yantras": {
        "primary":   "Sri Yantra (NE direction)",
        "secondary": ["Kuber Yantra (north)", "Mahalakshmi Yantra (NE pooja)", "Vyapar Vridhi Yantra (south of office)"],
    },
    "mantras": {
        "lakshmi":      "Om Shreem Hreem Shreem Kamale Kamalalaye Praseeda Praseeda Shreem Hreem Shreem Mahalakshmyai Namaha",
        "kubera":       "Om Shreem Hreem Kleem Vitteshvaraya Kuberaya Dhana Dhanya Adhipataye Namaha",
        "ganesh_wealth":"Om Ganesh Rinharta Rinanrupavarjite Akinchanya Shubha Karaya Namaha",
        "saraswati":    "Om Aim Saraswatyai Namaha",
        "repetitions":  "108 daily for 40 days minimum; 1008 for special manifestation",
        "best_time":    "Brahma Muhurta (before sunrise) for most; Friday morning for Lakshmi",
    },
    "behavioral_remedies": [
        "Light a ghee diya at home entrance every evening (Lakshmi welcomes light)",
        "Keep north and northeast corners clean and bright",
        "Place mirrors to face inside (multiplying wealth metaphor)",
        "Feed birds and animals daily — increases income through grace",
        "Donate on Fridays — silver, white items, sweets to women",
        "Never count money at night (classical rule, Lal Kitab)",
        "Place a money plant (Pothos) in north direction",
        "Avoid clutter in 2nd and 11th areas of home (calculated using Vastu)",
    ],
    "auspicious_days_for_wealth_actions": {
        "monday":    "buy silver, start savings",
        "tuesday":   "real estate or competitive investments",
        "wednesday": "intellectual investments, learning, education fees",
        "thursday":  "wealth advisory, banking, gold purchase",
        "friday":    "Lakshmi puja day — most auspicious for wealth ceremonies",
        "saturday":  "long-term investments, real estate (if Saturn is yogakaraka)",
    },
    "investment_principles_by_chart": [
        "Strong 5th house → can take calculated speculative risks",
        "Strong 11th house → networking-based income works best",
        "Strong 9th house → long-distance/foreign investments favored",
        "Weak Moon → avoid emotional/impulsive financial decisions",
        "Strong Saturn yogakaraka → long-term, slow-growth investments",
    ],
}


# ════════════════════════════════════════════════════════════════════════
# 9. PROFESSIONAL ARCHETYPES (D10 + KARAKA SYNTHESIS)
# Source: Phaladeepika Ch. 6 + practitioner tradition
# ════════════════════════════════════════════════════════════════════════

D10_ANALYSIS_PRINCIPLES = {
    "_description": "Dashamsha (D10) shows career direction. Read alongside D1 for complete picture.",
    "rules": [
        "D10 Lagna lord's house (in D10) = primary career field",
        "10th house of D10 = peak career status",
        "Sun in D10 → leadership orientation",
        "Saturn in D10 → service-orientation, structured work",
        "AmK (Amatyakaraka) in D10 → minister/profession karaka — strongest career indicator in Jaimini system",
        "D10 Lagna's planetary placements indicate work nature",
    ],
}
