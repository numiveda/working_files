"""
yogas_catalog_1.py — First catalog file: the high-value classical yogas.

Families covered here:
  1. Pancha Mahapurusha (5)         — BPHS Ch 36
  2. Raja Yogas (~40)               — BPHS Ch 39, Phaladeepika Ch 6
  3. Dhana Yogas (~30)              — BPHS Ch 41
  4. Vipreet Raja (3)               — Harsha, Sarala, Vimala
  5. Neecha Bhanga (general rules)  — Mantreshwara
  6. Parivartana Yogas (12)         — sign exchange

Each yoga is a dict:
  {
    "yoga_id":          unique snake_case ID,
    "name_en":          English name,
    "name_sa":          Sanskrit (Devanagari),
    "family":           family code,
    "polarity":         "positive" | "negative" | "neutral",
    "source":           classical citation,
    "formation_rule":   short English description of the rule,
    "detect":           callable(chart) -> bool,
    "strength_fn":      optional callable(chart) -> 0-100,
    "domains":          list of life areas affected,
    "general_effect":   plain English on what it does,
    "remedy_hooks":     suggested remedy categories (for LLM to expand),
  }
"""

from yogas_helpers import (
    SIGNS, SIGN_INDEX, SIGN_LORDS, EXALTATION, DEBILITATION, OWN_SIGNS, MOOLTRIKONA,
    NATURAL_FRIENDS, KENDRA_HOUSES, TRIKONA_HOUSES, DUSTHANA_HOUSES, ALL_PLANETS,
    asc_sign, asc_index, planet, planet_house, planet_sign, planet_lon,
    planet_degree_in_sign, is_retrograde, is_combust, is_exalted, is_debilitated,
    is_own_sign, is_mooltrikona, dignity, sign_in_house, house_of_sign,
    lord_of_house, planets_in_house, planets_in_sign, is_in_kendra, is_in_trikona,
    is_in_dusthana, aspects_house, aspects_planet, conjunct, mutual_reception,
)


# ═════════════════════════════════════════════════════════════════════════════
# 1. PANCHA MAHAPURUSHA YOGAS (BPHS 36.1-5)
# Five "great person" yogas — one of 5 planets (Mars, Mercury, Jupiter, Venus,
# Saturn) in own/exalted sign AND in a kendra house.
# ═════════════════════════════════════════════════════════════════════════════

def _make_mahapurusha(planet_name: str, name_en: str, name_sa: str, body_trait: str):
    """Factory for one Mahapurusha yoga."""
    def detect(chart):
        h = planet_house(chart, planet_name)
        if h not in KENDRA_HOUSES: return False
        return is_exalted(chart, planet_name) or is_own_sign(chart, planet_name)
    def strength(chart):
        h = planet_house(chart, planet_name)
        if h not in KENDRA_HOUSES: return 0
        s = 50
        if is_exalted(chart, planet_name):    s += 30
        if is_own_sign(chart, planet_name):   s += 20
        if h == 1:                            s += 15   # 1st house strongest
        elif h == 10:                         s += 10
        if is_retrograde(chart, planet_name): s -= 10
        if is_combust(chart, planet_name):    s -= 20
        return max(0, min(100, s))
    return {
        "yoga_id":        f"mahapurusha_{planet_name.lower()}",
        "name_en":        name_en,
        "name_sa":        name_sa,
        "family":         "pancha_mahapurusha",
        "polarity":       "positive",
        "source":         "BPHS Ch 36",
        "formation_rule": f"{planet_name} in own sign or exaltation, placed in a kendra (1/4/7/10).",
        "detect":         detect,
        "strength_fn":    strength,
        "domains":        [body_trait, "career", "reputation", "status"],
        "general_effect": f"Bestows {body_trait}-related excellence, royal/elite recognition, and Mahapurusha qualities of the {planet_name}.",
        "remedy_hooks":   [f"strengthen_{planet_name.lower()}"],
    }

PANCHA_MAHAPURUSHA = [
    _make_mahapurusha("Mars",    "Ruchaka Yoga",  "रुचक",  "warrior physique and command"),
    _make_mahapurusha("Mercury", "Bhadra Yoga",   "भद्र",   "intellectual brilliance and youth"),
    _make_mahapurusha("Jupiter", "Hamsa Yoga",    "हंस",   "wisdom and dharmic presence"),
    _make_mahapurusha("Venus",   "Malavya Yoga",  "मालव्य", "beauty, sensual pleasures, vehicles"),
    _make_mahapurusha("Saturn",  "Sasa Yoga",     "शश",    "authority over the masses, longevity"),
]


# ═════════════════════════════════════════════════════════════════════════════
# 2. RAJA YOGAS — combinations of kendra+trikona lords (royal/success yogas)
# ═════════════════════════════════════════════════════════════════════════════

def _detect_kendra_trikona_combination(chart, kendra_h, trikona_h):
    """Lords of kendra & trikona in mutual relationship (conjunction/exchange/aspect)."""
    kl = lord_of_house(chart, kendra_h)
    tl = lord_of_house(chart, trikona_h)
    if not kl or not tl or kl == tl: return False
    return (conjunct(chart, kl, tl) or
            mutual_reception(chart, kl, tl) or
            aspects_planet(chart, kl, tl) or
            aspects_planet(chart, tl, kl))


def _detect_gajakesari(chart):
    """Jupiter in kendra from Moon."""
    j_house = planet_house(chart, "Jupiter")
    m_house = planet_house(chart, "Moon")
    if j_house is None or m_house is None: return False
    diff = ((j_house - m_house) % 12) + 1
    return diff in (1, 4, 7, 10)


def _detect_neecha_bhanga_generic(chart, planet_name):
    """Generic neecha bhanga rule for a debilitated planet."""
    if not is_debilitated(chart, planet_name): return False
    deb_sign = DEBILITATION[planet_name]
    exalt_planet_for_sign = None
    for p, s in EXALTATION.items():
        if s == deb_sign:
            exalt_planet_for_sign = p
            break
    deb_lord = SIGN_LORDS.get(deb_sign)
    # Rule 1: The lord of the debilitation sign is in a kendra from Moon or Lagna
    if deb_lord:
        dl_house = planet_house(chart, deb_lord)
        m_house = planet_house(chart, "Moon")
        if dl_house in KENDRA_HOUSES: return True
        if m_house and dl_house:
            diff = ((dl_house - m_house) % 12) + 1
            if diff in (1, 4, 7, 10): return True
    # Rule 2: The planet exalted in the same sign is in a kendra from lagna/Moon
    if exalt_planet_for_sign:
        ep_house = planet_house(chart, exalt_planet_for_sign)
        if ep_house in KENDRA_HOUSES: return True
    # Rule 3: Debilitated planet is aspected by its own sign-lord
    if deb_lord and aspects_planet(chart, deb_lord, planet_name): return True
    return False


RAJA_YOGAS = [
    # ──── Classical kendra-trikona combinations (BPHS 39) ────
    {
        "yoga_id":        "raja_yoga_1_5",
        "name_en":        "Raja Yoga (Lagna-5th)",
        "name_sa":        "राजयोग (१-५)",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 39, Phaladeepika 6.13",
        "formation_rule": "Lords of 1st and 5th houses in conjunction, exchange, or mutual aspect.",
        "detect":         lambda c: _detect_kendra_trikona_combination(c, 1, 5),
        "domains":        ["power", "intelligence", "children", "creativity"],
        "general_effect": "Combines self with intelligence and progeny — confers leadership through wisdom.",
        "remedy_hooks":   ["strengthen_1st_lord", "strengthen_5th_lord"],
    },
    {
        "yoga_id":        "raja_yoga_1_9",
        "name_en":        "Dharma-Karmadhipati Yoga (Lagna-9th)",
        "name_sa":        "धर्मकर्माधिपति (१-९)",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 39, Phaladeepika 6.16",
        "formation_rule": "Lords of 1st and 9th houses in conjunction, exchange, or mutual aspect.",
        "detect":         lambda c: _detect_kendra_trikona_combination(c, 1, 9),
        "domains":        ["power", "dharma", "fortune", "father", "spirituality"],
        "general_effect": "Self combined with dharma and fortune — a dharmic king or righteous leader.",
        "remedy_hooks":   ["strengthen_1st_lord", "strengthen_9th_lord"],
    },
    {
        "yoga_id":        "raja_yoga_4_5",
        "name_en":        "Raja Yoga (4th-5th)",
        "name_sa":        "राजयोग (४-५)",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 39",
        "formation_rule": "Lords of 4th and 5th houses in conjunction, exchange, or mutual aspect.",
        "detect":         lambda c: _detect_kendra_trikona_combination(c, 4, 5),
        "domains":        ["home", "education", "children", "vehicles"],
        "general_effect": "Auspicious for home, education, and children — settled royal life.",
        "remedy_hooks":   ["strengthen_4th_lord", "strengthen_5th_lord"],
    },
    {
        "yoga_id":        "raja_yoga_4_9",
        "name_en":        "Raja Yoga (4th-9th)",
        "name_sa":        "राजयोग (४-९)",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 39",
        "formation_rule": "Lords of 4th and 9th houses in conjunction, exchange, or mutual aspect.",
        "detect":         lambda c: _detect_kendra_trikona_combination(c, 4, 9),
        "domains":        ["home", "fortune", "land", "father", "happiness"],
        "general_effect": "Ancestral fortune combined with personal happiness — inherited prosperity.",
        "remedy_hooks":   ["strengthen_4th_lord", "strengthen_9th_lord"],
    },
    {
        "yoga_id":        "raja_yoga_7_5",
        "name_en":        "Raja Yoga (7th-5th)",
        "name_sa":        "राजयोग (७-५)",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 39",
        "formation_rule": "Lords of 7th and 5th houses in conjunction, exchange, or mutual aspect.",
        "detect":         lambda c: _detect_kendra_trikona_combination(c, 7, 5),
        "domains":        ["partnership", "creativity", "children", "business"],
        "general_effect": "Partnership combined with creative intelligence — royal marriage or business glory.",
        "remedy_hooks":   ["strengthen_7th_lord", "strengthen_5th_lord"],
    },
    {
        "yoga_id":        "raja_yoga_7_9",
        "name_en":        "Raja Yoga (7th-9th)",
        "name_sa":        "राजयोग (७-९)",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 39",
        "formation_rule": "Lords of 7th and 9th houses in conjunction, exchange, or mutual aspect.",
        "detect":         lambda c: _detect_kendra_trikona_combination(c, 7, 9),
        "domains":        ["partnership", "dharma", "fortune", "father-in-law"],
        "general_effect": "Spouse's family brings fortune; partnerships bring dharmic gains.",
        "remedy_hooks":   ["strengthen_7th_lord", "strengthen_9th_lord"],
    },
    {
        "yoga_id":        "raja_yoga_10_5",
        "name_en":        "Raja Yoga (10th-5th)",
        "name_sa":        "राजयोग (१०-५)",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 39",
        "formation_rule": "Lords of 10th and 5th houses in conjunction, exchange, or mutual aspect.",
        "detect":         lambda c: _detect_kendra_trikona_combination(c, 10, 5),
        "domains":        ["career", "creativity", "children", "fame"],
        "general_effect": "Career combined with intelligence and creativity — fame through creative work.",
        "remedy_hooks":   ["strengthen_10th_lord", "strengthen_5th_lord"],
    },
    {
        "yoga_id":        "raja_yoga_10_9",
        "name_en":        "Raja Yoga (10th-9th)",
        "name_sa":        "राजयोग (१०-९)",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 39 — the strongest Raja Yoga",
        "formation_rule": "Lords of 10th and 9th houses in conjunction, exchange, or mutual aspect.",
        "detect":         lambda c: _detect_kendra_trikona_combination(c, 10, 9),
        "domains":        ["career", "dharma", "fortune", "fame", "authority"],
        "general_effect": "The supreme Raja Yoga — dharma and karma combine — bestows kingly authority and dharmic fame.",
        "remedy_hooks":   ["strengthen_10th_lord", "strengthen_9th_lord"],
    },

    # ──── Named classical Raja Yogas ────
    {
        "yoga_id":        "gaja_kesari_yoga",
        "name_en":        "Gaja Kesari Yoga",
        "name_sa":        "गजकेसरी",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "Brihat Jataka Ch 13; Phaladeepika 6.4",
        "formation_rule": "Jupiter is in a kendra (1/4/7/10) from the Moon.",
        "detect":         _detect_gajakesari,
        "domains":        ["wisdom", "wealth", "reputation", "stability"],
        "general_effect": "Confers wisdom of the elephant and royalty of the lion; lasting prosperity and respect.",
        "remedy_hooks":   ["strengthen_jupiter", "strengthen_moon"],
    },
    {
        "yoga_id":        "amala_yoga",
        "name_en":        "Amala Yoga",
        "name_sa":        "अमल",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.34",
        "formation_rule": "A pure benefic planet (Jupiter, Venus, well-placed Mercury, waxing Moon) in the 10th house from Moon or Lagna.",
        "detect":         lambda c: any(
            planet_house(c, p) == 10 or
            (planet_house(c, "Moon") and ((planet_house(c, p) - planet_house(c, "Moon")) % 12) == 9)
            for p in ("Jupiter", "Venus") if planet_sign(c, p)
        ),
        "domains":        ["reputation", "career", "fame", "ethics"],
        "general_effect": "Confers pure, unblemished fame; ethical reputation lasting through generations.",
        "remedy_hooks":   ["strengthen_jupiter", "strengthen_venus"],
    },
    {
        "yoga_id":        "kahala_yoga",
        "name_en":        "Kahala Yoga",
        "name_sa":        "कहल",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.36",
        "formation_rule": "Lords of 4th and 9th in mutual kendra and lord of lagna is strong.",
        "detect":         lambda c: (
            _detect_kendra_trikona_combination(c, 4, 9) and
            dignity(c, lord_of_house(c, 1)) in ("exalted", "own", "mooltrikona", "friend")
        ),
        "domains":        ["leadership", "command", "courage", "armed_forces"],
        "general_effect": "Commander qualities — leads armies or large organizations with valor.",
        "remedy_hooks":   ["strengthen_4th_lord", "strengthen_9th_lord", "strengthen_1st_lord"],
    },
    {
        "yoga_id":        "vasi_yoga",
        "name_en":        "Vasi Yoga",
        "name_sa":        "वसि",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.10",
        "formation_rule": "A planet (other than Moon) in the 12th house from the Sun.",
        "detect":         lambda c: any(
            planet_house(c, p) is not None and planet_house(c, "Sun") is not None and
            ((planet_house(c, "Sun") - planet_house(c, p)) % 12) == 1
            for p in ("Mars", "Mercury", "Jupiter", "Venus", "Saturn")
        ),
        "domains":        ["leadership", "influence", "command"],
        "general_effect": "Power to attract followers; influential and leading character.",
        "remedy_hooks":   ["strengthen_sun"],
    },
    {
        "yoga_id":        "vesi_yoga",
        "name_en":        "Vesi Yoga",
        "name_sa":        "वेसि",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.9",
        "formation_rule": "A planet (other than Moon) in the 2nd house from the Sun.",
        "detect":         lambda c: any(
            planet_house(c, p) is not None and planet_house(c, "Sun") is not None and
            ((planet_house(c, p) - planet_house(c, "Sun")) % 12) == 1
            for p in ("Mars", "Mercury", "Jupiter", "Venus", "Saturn")
        ),
        "domains":        ["truthfulness", "wealth", "speech", "moderation"],
        "general_effect": "Truthful, wealthy, virtuous and lazy by nature; moderate enjoyments.",
        "remedy_hooks":   ["strengthen_sun"],
    },
    {
        "yoga_id":        "ubhayachari_yoga",
        "name_en":        "Ubhayachari Yoga",
        "name_sa":        "उभयचरी",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.11",
        "formation_rule": "Planets (other than Moon) in both 2nd and 12th from the Sun.",
        "detect":         lambda c: (
            any(planet_house(c, p) is not None and planet_house(c, "Sun") is not None and
                ((planet_house(c, p) - planet_house(c, "Sun")) % 12) == 1
                for p in ("Mars","Mercury","Jupiter","Venus","Saturn")) and
            any(planet_house(c, p) is not None and planet_house(c, "Sun") is not None and
                ((planet_house(c, "Sun") - planet_house(c, p)) % 12) == 1
                for p in ("Mars","Mercury","Jupiter","Venus","Saturn"))
        ),
        "domains":        ["all-round prosperity", "leadership", "wealth"],
        "general_effect": "Combined Vasi and Vesi — fully empowered Sun, royal in all spheres.",
        "remedy_hooks":   ["strengthen_sun"],
    },
    {
        "yoga_id":        "sunapha_yoga",
        "name_en":        "Sunapha Yoga",
        "name_sa":        "सुनफा",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "Brihat Jataka Ch 13.1, Phaladeepika 6.6",
        "formation_rule": "A planet (other than Sun) is in the 2nd house from the Moon.",
        "detect":         lambda c: any(
            planet_house(c, p) is not None and planet_house(c, "Moon") is not None and
            ((planet_house(c, p) - planet_house(c, "Moon")) % 12) == 1
            for p in ("Mars","Mercury","Jupiter","Venus","Saturn")
        ),
        "domains":        ["wealth", "self-earned prosperity", "intelligence"],
        "general_effect": "Self-earned wealth, learned, healthy, virtuous — strong personal achievement.",
        "remedy_hooks":   ["strengthen_moon"],
    },
    {
        "yoga_id":        "anapha_yoga",
        "name_en":        "Anapha Yoga",
        "name_sa":        "अनफा",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "Brihat Jataka Ch 13.1, Phaladeepika 6.7",
        "formation_rule": "A planet (other than Sun) is in the 12th house from the Moon.",
        "detect":         lambda c: any(
            planet_house(c, p) is not None and planet_house(c, "Moon") is not None and
            ((planet_house(c, "Moon") - planet_house(c, p)) % 12) == 1
            for p in ("Mars","Mercury","Jupiter","Venus","Saturn")
        ),
        "domains":        ["status", "ease", "comforts", "physical_beauty"],
        "general_effect": "Famous, well-mannered, healthy and well-spoken; lives at ease.",
        "remedy_hooks":   ["strengthen_moon"],
    },
    {
        "yoga_id":        "duradhara_yoga",
        "name_en":        "Duradhara Yoga",
        "name_sa":        "दुरुधरा",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "Brihat Jataka Ch 13.1, Phaladeepika 6.8",
        "formation_rule": "Planets (other than Sun) in both 2nd and 12th from the Moon.",
        "detect":         lambda c: (
            any(planet_house(c, p) is not None and planet_house(c, "Moon") is not None and
                ((planet_house(c, p) - planet_house(c, "Moon")) % 12) == 1
                for p in ("Mars","Mercury","Jupiter","Venus","Saturn")) and
            any(planet_house(c, p) is not None and planet_house(c, "Moon") is not None and
                ((planet_house(c, "Moon") - planet_house(c, p)) % 12) == 1
                for p in ("Mars","Mercury","Jupiter","Venus","Saturn"))
        ),
        "domains":        ["wealth", "servants", "vehicles", "all-round fortune"],
        "general_effect": "Combined Sunapha and Anapha — wealth, comforts, retinue and full enjoyment.",
        "remedy_hooks":   ["strengthen_moon"],
    },
    {
        "yoga_id":        "kemadruma_yoga_negative",
        "name_en":        "Kemadruma Yoga (Negative)",
        "name_sa":        "केमद्रुम",
        "family":         "raja_yoga",  # filed here as antithesis
        "polarity":       "negative",
        "source":         "Brihat Jataka Ch 13.4, Phaladeepika 6.5",
        "formation_rule": "No planet (other than Sun, Rahu, Ketu) in 2nd, 12th, or same house as Moon.",
        "detect":         lambda c: (
            planet_house(c, "Moon") is not None and
            not any(
                planet_house(c, p) is not None and planet_house(c, "Moon") is not None and
                ((planet_house(c, p) - planet_house(c, "Moon")) % 12) in (0, 1, 11)
                for p in ("Mars","Mercury","Jupiter","Venus","Saturn")
            )
        ),
        "domains":        ["poverty", "loneliness", "obstacles", "mental_distress"],
        "general_effect": "Brings periods of struggle, loneliness, financial difficulty and mental restlessness.",
        "remedy_hooks":   ["strengthen_moon", "moon_mantras", "white_offerings"],
    },
    {
        "yoga_id":        "chandra_mangala_yoga",
        "name_en":        "Chandra-Mangala Yoga",
        "name_sa":        "चन्द्र-मंगल",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "Saravali Ch 35",
        "formation_rule": "Moon and Mars in conjunction or mutual aspect.",
        "detect":         lambda c: conjunct(c, "Moon", "Mars") or aspects_planet(c, "Moon", "Mars") or aspects_planet(c, "Mars", "Moon"),
        "domains":        ["wealth", "business", "real_estate", "trade"],
        "general_effect": "Excellent for self-made wealth, especially through trade and property.",
        "remedy_hooks":   ["strengthen_moon", "strengthen_mars"],
    },
    {
        "yoga_id":        "neecha_bhanga_raja_yoga",
        "name_en":        "Neecha Bhanga Raja Yoga",
        "name_sa":        "नीचभङ्ग राजयोग",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "Mantreshwara, Phaladeepika 6.30",
        "formation_rule": "A debilitated planet has its debilitation cancelled (Neecha Bhanga) — typically rising to great heights.",
        "detect":         lambda c: any(_detect_neecha_bhanga_generic(c, p) for p in ALL_PLANETS),
        "domains":        ["dramatic_rise", "late_success", "phoenix_like"],
        "general_effect": "Marked by initial obstacles or low status, followed by dramatic rise to power and wealth.",
        "remedy_hooks":   ["patience", "long_term_planning"],
    },
    {
        "yoga_id":        "viparita_kendra",
        "name_en":        "Viparita Kendra Yoga",
        "name_sa":        "विपरीतकेन्द्र",
        "family":         "raja_yoga",
        "polarity":       "positive",
        "source":         "Jataka Parijata 6",
        "formation_rule": "Strong lord of an angle (kendra) — confers steady power.",
        "detect":         lambda c: any(
            dignity(c, lord_of_house(c, h)) in ("exalted", "own", "mooltrikona")
            for h in KENDRA_HOUSES
        ),
        "domains":        ["stability", "command", "long_career"],
        "general_effect": "Stable career success and unshakeable authority.",
        "remedy_hooks":   ["maintain_kendra_lord_strength"],
    },
]


# ═════════════════════════════════════════════════════════════════════════════
# 3. DHANA YOGAS (Wealth Yogas) — BPHS Ch 41
# Combinations of 2nd/5th/9th/11th lords; conjunction with 2nd or 11th lord;
# placement of specific planets in wealth houses.
# ═════════════════════════════════════════════════════════════════════════════

DHANA_YOGAS = [
    {
        "yoga_id":        "dhana_yoga_2_11",
        "name_en":        "Dhana Yoga (2nd-11th)",
        "name_sa":        "धनयोग (२-११)",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 41",
        "formation_rule": "Lords of 2nd (wealth/family) and 11th (gains) in mutual connection.",
        "detect":         lambda c: _detect_kendra_trikona_combination(c, 2, 11),
        "domains":        ["accumulated_wealth", "income", "gains"],
        "general_effect": "Steady wealth accumulation; gains feed into savings consistently.",
        "remedy_hooks":   ["strengthen_2nd_lord", "strengthen_11th_lord"],
    },
    {
        "yoga_id":        "dhana_yoga_5_11",
        "name_en":        "Dhana Yoga (5th-11th)",
        "name_sa":        "धनयोग (५-११)",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 41",
        "formation_rule": "Lords of 5th (creativity/intelligence) and 11th (gains) in mutual connection.",
        "detect":         lambda c: _detect_kendra_trikona_combination(c, 5, 11),
        "domains":        ["speculation_gains", "creative_income", "stock_market"],
        "general_effect": "Wealth through creative ventures, speculation, and investments.",
        "remedy_hooks":   ["strengthen_5th_lord", "strengthen_11th_lord"],
    },
    {
        "yoga_id":        "dhana_yoga_9_11",
        "name_en":        "Dhana Yoga (9th-11th)",
        "name_sa":        "धनयोग (९-११)",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 41",
        "formation_rule": "Lords of 9th (fortune) and 11th (gains) in mutual connection.",
        "detect":         lambda c: _detect_kendra_trikona_combination(c, 9, 11),
        "domains":        ["inherited_wealth", "fortune", "international_gains"],
        "general_effect": "Inherited fortune and dharmic gains; wealth comes through aligned action.",
        "remedy_hooks":   ["strengthen_9th_lord", "strengthen_11th_lord"],
    },
    {
        "yoga_id":        "dhana_yoga_2_5",
        "name_en":        "Dhana Yoga (2nd-5th)",
        "name_sa":        "धनयोग (२-५)",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 41",
        "formation_rule": "Lords of 2nd (wealth) and 5th (intelligence/creativity) in mutual connection.",
        "detect":         lambda c: _detect_kendra_trikona_combination(c, 2, 5),
        "domains":        ["intellectual_wealth", "speech_wealth", "education_wealth"],
        "general_effect": "Wealth through intelligence, education, and skilled speech.",
        "remedy_hooks":   ["strengthen_2nd_lord", "strengthen_5th_lord"],
    },
    {
        "yoga_id":        "dhana_yoga_2_9",
        "name_en":        "Dhana Yoga (2nd-9th)",
        "name_sa":        "धनयोग (२-९)",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 41",
        "formation_rule": "Lords of 2nd (wealth) and 9th (fortune) in mutual connection.",
        "detect":         lambda c: _detect_kendra_trikona_combination(c, 2, 9),
        "domains":        ["dharmic_wealth", "blessed_wealth", "father_wealth"],
        "general_effect": "Wealth flows through dharmic alignment and family fortune.",
        "remedy_hooks":   ["strengthen_2nd_lord", "strengthen_9th_lord"],
    },
    {
        "yoga_id":        "lakshmi_yoga",
        "name_en":        "Lakshmi Yoga",
        "name_sa":        "लक्ष्मी",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "Mantreshwara, Phaladeepika 6.32",
        "formation_rule": "Lord of 9th in own/exaltation in a kendra, and lord of lagna is strong.",
        "detect":         lambda c: (
            dignity(c, lord_of_house(c, 9)) in ("exalted", "own", "mooltrikona") and
            planet_house(c, lord_of_house(c, 9)) in KENDRA_HOUSES and
            dignity(c, lord_of_house(c, 1)) in ("exalted", "own", "mooltrikona", "friend")
        ),
        "domains":        ["abundance", "blessings", "feminine_grace", "lasting_wealth"],
        "general_effect": "Blessings of goddess Lakshmi — abundant lasting wealth with grace.",
        "remedy_hooks":   ["worship_lakshmi", "strengthen_9th_lord"],
    },
    {
        "yoga_id":        "kubera_yoga",
        "name_en":        "Kubera Yoga",
        "name_sa":        "कुबेर",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "Jataka Parijata",
        "formation_rule": "Lords of 2nd and 11th conjunct in the 2nd, 5th, 9th, or 11th house.",
        "detect":         lambda c: (
            conjunct(c, lord_of_house(c, 2), lord_of_house(c, 11)) and
            planet_house(c, lord_of_house(c, 2)) in (2, 5, 9, 11)
        ),
        "domains":        ["treasury", "vaults", "saved_wealth", "real_estate"],
        "general_effect": "Treasurer-like accumulation — wealth held in vaults and assets.",
        "remedy_hooks":   ["strengthen_2nd_lord", "strengthen_11th_lord"],
    },
    {
        "yoga_id":        "kalpadruma_yoga",
        "name_en":        "Kalpadruma Yoga",
        "name_sa":        "कल्पद्रुम",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "Jataka Parijata 7",
        "formation_rule": "Strong lagna lord, in own/exalted sign, in a kendra/trikona, aspected by benefics.",
        "detect":         lambda c: (
            dignity(c, lord_of_house(c, 1)) in ("exalted", "own", "mooltrikona") and
            planet_house(c, lord_of_house(c, 1)) in (KENDRA_HOUSES | TRIKONA_HOUSES) and
            any(aspects_planet(c, ben, lord_of_house(c, 1)) for ben in ("Jupiter", "Venus"))
        ),
        "domains":        ["wish_fulfillment", "abundance", "complete_prosperity"],
        "general_effect": "Wish-fulfilling-tree — supplies all desires; complete prosperity.",
        "remedy_hooks":   ["maintain_lagna_lord_strength"],
    },
    {
        "yoga_id":        "guru_mangala_yoga",
        "name_en":        "Guru-Mangala Yoga",
        "name_sa":        "गुरु-मंगल",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "Phaladeepika",
        "formation_rule": "Jupiter and Mars in conjunction or mutual aspect.",
        "detect":         lambda c: conjunct(c, "Jupiter", "Mars") or aspects_planet(c, "Jupiter", "Mars") or aspects_planet(c, "Mars", "Jupiter"),
        "domains":        ["business_growth", "real_estate_wealth", "entrepreneurship"],
        "general_effect": "Strong drive combined with wisdom — excellent for business and property wealth.",
        "remedy_hooks":   ["strengthen_jupiter", "strengthen_mars"],
    },
    {
        "yoga_id":        "saraswati_yoga",
        "name_en":        "Saraswati Yoga",
        "name_sa":        "सरस्वती",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.31",
        "formation_rule": "Jupiter, Venus and Mercury in kendras, trikonas, or 2nd house, with Jupiter strong.",
        "detect":         lambda c: (
            planet_house(c, "Jupiter") in (KENDRA_HOUSES | TRIKONA_HOUSES | {2}) and
            planet_house(c, "Venus") in (KENDRA_HOUSES | TRIKONA_HOUSES | {2}) and
            planet_house(c, "Mercury") in (KENDRA_HOUSES | TRIKONA_HOUSES | {2}) and
            dignity(c, "Jupiter") in ("exalted", "own", "mooltrikona", "friend")
        ),
        "domains":        ["knowledge", "wisdom", "education", "artistic_wealth", "scholarship"],
        "general_effect": "Blessings of Saraswati — wealth through knowledge, arts, and scholarship.",
        "remedy_hooks":   ["worship_saraswati", "strengthen_jupiter", "strengthen_venus", "strengthen_mercury"],
    },
    {
        "yoga_id":        "kalanidhi_yoga",
        "name_en":        "Kalanidhi Yoga",
        "name_sa":        "कलानिधि",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.33",
        "formation_rule": "Jupiter in 2nd or 5th, in/aspected by Mercury and Venus.",
        "detect":         lambda c: (
            planet_house(c, "Jupiter") in (2, 5) and (
                conjunct(c, "Jupiter", "Mercury") or aspects_planet(c, "Mercury", "Jupiter") or
                conjunct(c, "Jupiter", "Venus")  or aspects_planet(c, "Venus", "Jupiter")
            )
        ),
        "domains":        ["arts_wealth", "music_wealth", "cultural_riches"],
        "general_effect": "Treasure of arts — wealth and recognition through cultural and artistic pursuits.",
        "remedy_hooks":   ["strengthen_jupiter", "strengthen_venus", "strengthen_mercury"],
    },
    {
        "yoga_id":        "dhanesha_in_dhana",
        "name_en":        "Wealth Lord in Wealth House",
        "name_sa":        "धनेश-धन",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 41",
        "formation_rule": "Lord of 2nd house is in the 2nd house (own).",
        "detect":         lambda c: planet_house(c, lord_of_house(c, 2)) == 2,
        "domains":        ["family_wealth", "accumulated_wealth", "savings"],
        "general_effect": "Native is naturally wealthy; family wealth is preserved and grows.",
        "remedy_hooks":   ["maintain_2nd_lord"],
    },
    {
        "yoga_id":        "labhesha_in_labha",
        "name_en":        "Gains Lord in Gains House",
        "name_sa":        "लाभेश-लाभ",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 41",
        "formation_rule": "Lord of 11th house is in the 11th house (own).",
        "detect":         lambda c: planet_house(c, lord_of_house(c, 11)) == 11,
        "domains":        ["income", "gains", "fulfillment_of_desires"],
        "general_effect": "Consistent and unbroken stream of gains and fulfillment of desires.",
        "remedy_hooks":   ["maintain_11th_lord"],
    },
    {
        "yoga_id":        "jupiter_in_2nd",
        "name_en":        "Jupiter in 2nd House",
        "name_sa":        "गुरु-धन",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 41 (planetary placements in 2nd)",
        "formation_rule": "Jupiter placed in the 2nd house of wealth, well-dignified.",
        "detect":         lambda c: planet_house(c, "Jupiter") == 2 and dignity(c, "Jupiter") not in ("debilitated", "enemy"),
        "domains":        ["wisdom_wealth", "preserved_wealth", "wealth_through_education"],
        "general_effect": "Wealth grows through wisdom; speech is valuable; family wealth respected.",
        "remedy_hooks":   ["strengthen_jupiter"],
    },
    {
        "yoga_id":        "venus_in_2nd",
        "name_en":        "Venus in 2nd House",
        "name_sa":        "शुक्र-धन",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 41",
        "formation_rule": "Venus placed in the 2nd house, well-dignified.",
        "detect":         lambda c: planet_house(c, "Venus") == 2 and dignity(c, "Venus") not in ("debilitated", "enemy"),
        "domains":        ["luxury_wealth", "sensual_wealth", "wealth_through_beauty_arts"],
        "general_effect": "Wealth through arts, luxury, beauty and entertainment industries.",
        "remedy_hooks":   ["strengthen_venus"],
    },
    {
        "yoga_id":        "moon_in_11th",
        "name_en":        "Moon in 11th House",
        "name_sa":        "चन्द्र-लाभ",
        "family":         "dhana_yoga",
        "polarity":       "positive",
        "source":         "BPHS",
        "formation_rule": "Moon placed in the 11th house, well-dignified.",
        "detect":         lambda c: planet_house(c, "Moon") == 11 and dignity(c, "Moon") not in ("debilitated", "enemy"),
        "domains":        ["income_through_masses", "public_gains", "social_wealth"],
        "general_effect": "Income grows through public/mass connection; popular gains.",
        "remedy_hooks":   ["strengthen_moon"],
    },
]


# ═════════════════════════════════════════════════════════════════════════════
# 4. VIPREET RAJA YOGAS — when dusthana lords (6, 8, 12) are themselves in dusthanas,
#    they paradoxically create royal yogas. The "reversed" Raja yoga.
# ═════════════════════════════════════════════════════════════════════════════

VIPREET_RAJA = [
    {
        "yoga_id":        "harsha_yoga",
        "name_en":        "Harsha Yoga (6th-lord in dusthana)",
        "name_sa":        "हर्ष",
        "family":         "vipreet_raja",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.41",
        "formation_rule": "Lord of 6th house placed in 6th, 8th, or 12th house.",
        "detect":         lambda c: planet_house(c, lord_of_house(c, 6)) in DUSTHANA_HOUSES,
        "domains":        ["victory_over_enemies", "health", "service", "victory_through_struggle"],
        "general_effect": "Victory over enemies, debts, and disease; gains through service or competitive fields.",
        "remedy_hooks":   ["strengthen_6th_lord"],
    },
    {
        "yoga_id":        "sarala_yoga",
        "name_en":        "Sarala Yoga (8th-lord in dusthana)",
        "name_sa":        "सरल",
        "family":         "vipreet_raja",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.42",
        "formation_rule": "Lord of 8th house placed in 6th, 8th, or 12th house.",
        "detect":         lambda c: planet_house(c, lord_of_house(c, 8)) in DUSTHANA_HOUSES,
        "domains":        ["longevity", "hidden_wealth", "occult_success", "research_breakthroughs"],
        "general_effect": "Long life; mystic or research success; hidden wealth and transformation.",
        "remedy_hooks":   ["strengthen_8th_lord"],
    },
    {
        "yoga_id":        "vimala_yoga",
        "name_en":        "Vimala Yoga (12th-lord in dusthana)",
        "name_sa":        "विमल",
        "family":         "vipreet_raja",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.43",
        "formation_rule": "Lord of 12th house placed in 6th, 8th, or 12th house.",
        "detect":         lambda c: planet_house(c, lord_of_house(c, 12)) in DUSTHANA_HOUSES,
        "domains":        ["foreign_gains", "spiritual_liberation", "controlled_expenses"],
        "general_effect": "Controlled expenses; gains from foreign sources; spiritual liberation possible.",
        "remedy_hooks":   ["strengthen_12th_lord"],
    },
]


# ═════════════════════════════════════════════════════════════════════════════
# 5. PARIVARTANA YOGAS — sign exchange between two house lords
# Three types: Maha (kendra-trikona), Khala (with 3/6/11), Dainya (with 6/8/12)
# ═════════════════════════════════════════════════════════════════════════════

def _detect_parivartana(chart, h1: int, h2: int) -> bool:
    """Lord of h1 in h2's sign AND lord of h2 in h1's sign."""
    l1 = lord_of_house(chart, h1)
    l2 = lord_of_house(chart, h2)
    if not l1 or not l2 or l1 == l2: return False
    return mutual_reception(chart, l1, l2)


PARIVARTANA_YOGAS = [
    {
        "yoga_id":        f"parivartana_{h1}_{h2}",
        "name_en":        f"Parivartana Yoga ({h1}th-{h2}th)",
        "name_sa":        f"परिवर्तन ({h1}-{h2})",
        "family":         "parivartana",
        "polarity":       (
            "positive" if h1 in (1, 2, 4, 5, 7, 9, 10, 11) and h2 in (1, 2, 4, 5, 7, 9, 10, 11)
            else "negative" if h1 in (6, 8, 12) or h2 in (6, 8, 12)
            else "neutral"
        ),
        "source":         "BPHS Ch 40, Mantreshwara",
        "formation_rule": f"Lord of {h1}th in {h2}th sign AND lord of {h2}th in {h1}th sign.",
        "detect":         (lambda h1=h1, h2=h2: lambda c: _detect_parivartana(c, h1, h2))(),
        "domains":        [f"house_{h1}_themes", f"house_{h2}_themes"],
        "general_effect": (
            f"Strong mutual link between {h1}th and {h2}th house themes — they reinforce each other across life."
        ),
        "remedy_hooks":   [f"strengthen_{h1}_themes", f"strengthen_{h2}_themes"],
    }
    for h1, h2 in [
        (1, 2), (1, 4), (1, 5), (1, 7), (1, 9), (1, 10), (1, 11),
        (2, 11), (5, 9), (5, 11), (9, 10), (9, 11), (10, 11),
    ]
]


# ═════════════════════════════════════════════════════════════════════════════
# EXPORT
# ═════════════════════════════════════════════════════════════════════════════

CATALOG_1 = (
    PANCHA_MAHAPURUSHA +
    RAJA_YOGAS +
    DHANA_YOGAS +
    VIPREET_RAJA +
    PARIVARTANA_YOGAS
)
