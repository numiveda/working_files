

# ════════════════════════════════════════════════════════════════════════
# ════════════════════════════════════════════════════════════════════════
# ──── F1b SECTION (2026-05-17) ────
# Business Partner + Colleague + Compatibility Matrix
#
# F1b extends F1a's pattern to professional contexts and adds a meta
# endpoint that ranks N candidates against one native.
#
# Reuses ALL of F1a's primitives:
#   _safe_essentials_summary, _composite_verdict, _score_house_placement,
#   _planet_house_in_other_chart, RELATIONSHIP_KARAKAS, F1A_CITATIONS
#   (locally extended)
#
# New helpers added below:
#   _d10_chart_overlay     — leverages U7's per-planet d10_sign
#   _business_amk_resonance — AmK cross-placement (key signal for partnership)
#   _saturn_mars_synastry  — workplace conflict signature
#
# Author: Claude (F1b, 2026-05-17)
# ════════════════════════════════════════════════════════════════════════

# Extend RELATIONSHIP_KARAKAS with colleague (business already seeded by F1a)
RELATIONSHIP_KARAKAS["colleague"] = {
    "primary_house": "6th (service, daily work, conflicts), 10th (work/reputation)",
    "primary_karaka": "Saturn (service-discipline)",
    "secondary_karaka": "Mars (drive, conflict, action)",
    "secondary_house": "3rd (peers/teammates), 11th (collective gains)",
}

# F1b-specific citation subsets
F1A_CITATIONS["business_partner"] = [
    "BPHS Ch. 7 — 7th house (partnership), 10th house (karma/profession), 11th house (labha/gains)",
    "Brihat Jataka Ch. 11 — Amatyakaraka as career-significator; AmK cross-placement reveals professional alignment",
    "Jataka Parijata Ch. 4 — D10 (Dashamsha) as the karma chart for joint professional dharma",
    "Phaladeepika Ch. 9 — 10H lord and Mercury for commercial-professional analysis",
    "Saravali Ch. 28 — partnership through Venus-Jupiter and 7H lord cross-aspects",
]
F1A_CITATIONS["colleague"] = [
    "BPHS Ch. 7 — 6th house (service, daily routine, conflicts), 10th house (work hierarchy)",
    "Phaladeepika Ch. 6 — Saturn as karma-karaka, governs service relationships",
    "Saravali Ch. 28 — Mars-Saturn cross-aspects produce workplace friction signatures",
    "Jataka Parijata Ch. 7 — 3rd house (peers, courage) for collegial dynamics",
]
F1A_CITATIONS["compatibility_matrix"] = [
    "Composite scoring across pairwise classical analyses per relationship type",
    "See per-type citations above for source material",
]


# ════════════════════════════════════════════════════════════════════════
# F1b HELPERS
# ════════════════════════════════════════════════════════════════════════

def _build_d10_chart(chart: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build a D10-shaped chart dict from cast_chart output's pre-computed
    d10_sign fields. Output mirrors the D1 chart shape enough that
    _planet_house_in_other_chart can be called against it directly.

    Returns:
      {
        "lagna": {"sign": <d10_lagna_sign>},
        "planets": {planet_name: {"sign": <d10_sign>}, ...}
      }
    """
    out = {
        "lagna": {"sign": chart.get("lagna", {}).get("d10_sign")},
        "planets": {},
    }
    for pname, pdata in chart.get("planets", {}).items():
        d10 = pdata.get("d10_sign")
        if d10:
            out["planets"][pname] = {"sign": d10}
    return out


def _planet_d10_house_in_other_d10(p_d10, other_d10, planet: str) -> Optional[int]:
    """
    Like _planet_house_in_other_chart but for D10 charts.
    Returns 1-12 house of <planet>'s D10 sign relative to other_d10's lagna.
    """
    try:
        psign = p_d10["planets"][planet]["sign"]
        other_lagna = other_d10["lagna"]["sign"]
        return _house_from_sign(psign, other_lagna)
    except (KeyError, TypeError):
        return None


def _business_d10_overlay(c1, c2) -> Dict[str, Any]:
    """
    Build both D10 charts and locate each native's AmK + 10H-lord in the
    other's D10.

    Max 10 points:
      AmK cross in 1/10/11 = 3 pts each (max 6 for AmK both ways)
      10H lord cross in 1/5/9/10/11 = 2 pts each (max 4 for 10L both ways)
    """
    d10_1 = _build_d10_chart(c1)
    d10_2 = _build_d10_chart(c2)

    def amk_planet(chart):
        try:
            return chart["jaimini_karakas"]["Amatyakaraka"]["planet"]
        except (KeyError, TypeError):
            return None

    def d10_tenth_lord(chart):
        """10H lord in D10 = sign 10 houses from D10 lagna, then its ruler."""
        try:
            d10_lagna = chart["lagna"]["d10_sign"]
            idx = (_sign_index(d10_lagna) + 9) % 12  # 10th from lagna = index +9
            tenth_sign = SIGNS_ORDER[idx]
            return SIGN_TO_LORD.get(tenth_sign), tenth_sign
        except (KeyError, TypeError, AttributeError):
            return None, None

    p1_amk = amk_planet(c1)
    p2_amk = amk_planet(c2)
    p1_10l, p1_10s = d10_tenth_lord(c1)
    p2_10l, p2_10s = d10_tenth_lord(c2)

    def score_amk(h):
        if h is None: return 0.0
        if h in (1, 10, 11):  return 3.0
        if h in (5, 9):       return 2.0
        if h in (2, 3, 7):    return 1.0
        return 0.5

    def score_10l(h):
        if h is None: return 0.0
        if h in (1, 10):           return 2.0
        if h in (5, 9, 11):        return 2.0
        if h in (2, 3, 7):         return 1.0
        return 0.5

    p1_amk_in_p2_d10 = _planet_d10_house_in_other_d10(d10_1, d10_2, p1_amk) if p1_amk else None
    p2_amk_in_p1_d10 = _planet_d10_house_in_other_d10(d10_2, d10_1, p2_amk) if p2_amk else None
    p1_10l_in_p2_d10 = _planet_d10_house_in_other_d10(d10_1, d10_2, p1_10l) if p1_10l else None
    p2_10l_in_p1_d10 = _planet_d10_house_in_other_d10(d10_2, d10_1, p2_10l) if p2_10l else None

    s_amk = score_amk(p1_amk_in_p2_d10) + score_amk(p2_amk_in_p1_d10)
    s_10l = score_10l(p1_10l_in_p2_d10) + score_10l(p2_10l_in_p1_d10)

    notes = []
    if p1_amk_in_p2_d10 in (1, 10, 11):
        notes.append(f"p1's AmK ({p1_amk}) in p2's D10 {p1_amk_in_p2_d10}H — strong career-purpose bridging from p1 to p2")
    if p2_amk_in_p1_d10 in (1, 10, 11):
        notes.append(f"p2's AmK ({p2_amk}) in p1's D10 {p2_amk_in_p1_d10}H — strong career-purpose bridging from p2 to p1")

    # D10 lagna match — shared professional dharma
    d10_lagna_match = (d10_1["lagna"]["sign"] == d10_2["lagna"]["sign"]
                       if d10_1["lagna"]["sign"] and d10_2["lagna"]["sign"] else False)
    bonus = 0.0
    if d10_lagna_match:
        bonus = 1.5
        notes.append(f"Both share D10 lagna ({d10_1['lagna']['sign']}) — shared professional dharma signature")

    total = min(s_amk + s_10l + bonus, 10.0)

    return {
        "p1_d10_lagna":               d10_1["lagna"]["sign"],
        "p2_d10_lagna":               d10_2["lagna"]["sign"],
        "d10_lagna_match":            d10_lagna_match,
        "p1_amk":                     p1_amk,
        "p1_amk_in_p2_d10_house":     p1_amk_in_p2_d10,
        "p2_amk":                     p2_amk,
        "p2_amk_in_p1_d10_house":     p2_amk_in_p1_d10,
        "p1_d10_10th_lord":           p1_10l,
        "p2_d10_10th_lord":           p2_10l,
        "p1_10l_in_p2_d10_house":     p1_10l_in_p2_d10,
        "p2_10l_in_p1_d10_house":     p2_10l_in_p1_d10,
        "amk_subscore":               round(s_amk, 2),
        "tenth_lord_subscore":        round(s_10l, 2),
        "d10_lagna_match_bonus":      bonus,
        "notes":                      notes,
        "subtotal":                   round(total, 2),
        "max":                        10.0,
    }


def _business_house_overlay(c1, c2) -> Dict[str, Any]:
    """
    7H/10H/11H lord cross-placement in D1 (the standard business houses).
    Max 10 points.
    """
    def lord_of_house_n(chart, n):
        try:
            lagna = chart["lagna"]["sign"]
            idx = (_sign_index(lagna) + (n - 1)) % 12
            sign = SIGNS_ORDER[idx]
            return SIGN_TO_LORD.get(sign)
        except (KeyError, TypeError):
            return None

    placements = []
    for n in [7, 10, 11]:
        for from_chart, to_chart, label in [(c1, c2, f"p1_{n}lord_in_p2"),
                                              (c2, c1, f"p2_{n}lord_in_p1")]:
            lord = lord_of_house_n(from_chart, n)
            h = _planet_house_in_other_chart(from_chart, to_chart, lord) if lord else None
            placements.append({
                "direction":       label,
                "house_of_origin": n,
                "lord":            lord,
                "lands_in_house":  h,
                "score":           _score_house_placement(h),
            })

    raw = sum(p["score"] for p in placements)
    # 6 placements × 2 = 12 max raw → normalize to /10
    normalized = (raw / 12.0) * 10.0
    total = min(normalized, 10.0)

    return {
        "placements": placements,
        "raw_sum":    round(raw, 2),
        "subtotal":   round(total, 2),
        "max":        10.0,
    }


def _saturn_mars_synastry(c1, c2) -> Dict[str, Any]:
    """
    Workplace conflict signature. Mars-Saturn cross-aspects (especially
    falling in 6H — the conflict house) signal friction.

    Score 0-10: HIGHER score = LESS friction (positive framing).
      Each Mars/Saturn placement in other's 6H/8H/12H = -2 (subtract from base 10)
      Both planets harmless (3H/11H) = +0
    """
    def planet_in_other_house(p_chart, o_chart, planet):
        return _planet_house_in_other_chart(p_chart, o_chart, planet)

    p1_mars_in_p2 = planet_in_other_house(c1, c2, "Mars")
    p1_sat_in_p2  = planet_in_other_house(c1, c2, "Saturn")
    p2_mars_in_p1 = planet_in_other_house(c2, c1, "Mars")
    p2_sat_in_p1  = planet_in_other_house(c2, c1, "Saturn")

    base = 10.0
    notes = []
    for label, h, planet, owner_to_target in [
        ("p1_mars_in_p2", p1_mars_in_p2, "Mars",   "p1→p2"),
        ("p1_saturn_in_p2", p1_sat_in_p2, "Saturn", "p1→p2"),
        ("p2_mars_in_p1", p2_mars_in_p1, "Mars",   "p2→p1"),
        ("p2_saturn_in_p1", p2_sat_in_p1, "Saturn", "p2→p1"),
    ]:
        if h in (6, 8, 12):
            base -= 2.0
            notes.append(f"{owner_to_target}: {planet} falls in {h}H — friction signature")
        elif h in (3, 11):
            notes.append(f"{owner_to_target}: {planet} falls in {h}H — supportive workplace energy")

    score = max(0.0, min(base, 10.0))

    return {
        "p1_mars_in_p2_house":   p1_mars_in_p2,
        "p1_saturn_in_p2_house": p1_sat_in_p2,
        "p2_mars_in_p1_house":   p2_mars_in_p1,
        "p2_saturn_in_p1_house": p2_sat_in_p1,
        "interpretation":        "Higher score = less conflict signature (10 = clean; 0 = high friction)",
        "notes":                 notes,
        "subtotal":              round(score, 2),
        "max":                   10.0,
    }


def _colleague_house_overlay(c1, c2) -> Dict[str, Any]:
    """
    6H + 10H + 3H lord cross-placement.
    Max 10 points.

    Note: 6H is the 'shashtha bhava' — service, daily routine, AND conflicts.
    The 6H lord falling in trinal/supportive houses = good service relationship.
    """
    def lord_of_house_n(chart, n):
        try:
            lagna = chart["lagna"]["sign"]
            idx = (_sign_index(lagna) + (n - 1)) % 12
            sign = SIGNS_ORDER[idx]
            return SIGN_TO_LORD.get(sign)
        except (KeyError, TypeError):
            return None

    placements = []
    for n in [6, 10, 3]:
        for from_chart, to_chart, label in [(c1, c2, f"p1_{n}lord_in_p2"),
                                              (c2, c1, f"p2_{n}lord_in_p1")]:
            lord = lord_of_house_n(from_chart, n)
            h = _planet_house_in_other_chart(from_chart, to_chart, lord) if lord else None
            placements.append({
                "direction":       label,
                "house_of_origin": n,
                "lord":            lord,
                "lands_in_house":  h,
                "score":           _score_house_placement(h),
            })

    raw = sum(p["score"] for p in placements)
    normalized = (raw / 12.0) * 10.0
    total = min(normalized, 10.0)

    return {
        "placements": placements,
        "raw_sum":    round(raw, 2),
        "subtotal":   round(total, 2),
        "max":        10.0,
    }


# ════════════════════════════════════════════════════════════════════════
# BUSINESS PARTNER
# ════════════════════════════════════════════════════════════════════════

def handle_business_partner(person1: Dict[str, Any],
                             person2: Dict[str, Any],
                             role1: Optional[str] = None,
                             role2: Optional[str] = None) -> Dict[str, Any]:
    """
    F1b Endpoint: Business Partner / Co-founder compatibility.

    Frame: 7H (partnership), 10H (joint work), 11H (gains); karakas
    Mercury (commerce), Jupiter (ethics), Amatyakaraka (career-purpose).

    Streams: koot_scores (Tara + Graha Maitri only; max 8, w=0.15)
             d10_overlay (AmK cross + D10 lagna; max 10, w=0.35)
             house_overlay (7H/10H/11H lords; max 10, w=0.30)
             ethics_signal (Jupiter cross-placement; max 10, w=0.20)
    """
    c1, e1 = _build_person(person1)
    c2, e2 = _build_person(person2)

    p1_nak  = e1.get("moon_nakshatra")
    p2_nak  = e2.get("moon_nakshatra")
    p1_moon = e1.get("moon_sign")
    p2_moon = e2.get("moon_sign")

    if not (p1_nak and p2_nak and p1_moon and p2_moon):
        return {
            "error": "Could not extract Moon nakshatra/sign for both natives",
            "citations": F1A_CITATIONS["business_partner"],
        }

    # Stream 1: Koots
    tara  = _tara_kuta(p1_nak, p2_nak)
    gmait = _graha_maitri_kuta(p1_moon, p2_moon)
    koot_subtotal = float(tara.get("score", 0)) + float(gmait.get("score", 0))
    koot_max = 8.0

    # Stream 2: D10 overlay (AmK cross + 10L cross + D10 lagna match)
    d10_overlay = _business_d10_overlay(c1, c2)

    # Stream 3: 7H/10H/11H lords cross-placement in D1
    house_ov = _business_house_overlay(c1, c2)

    # Stream 4: Jupiter cross — proxy for ethics/dharmic-fit
    def jup_house(p_from, p_to):
        return _planet_house_in_other_chart(p_from, p_to, "Jupiter")
    p1_jup = jup_house(c1, c2)
    p2_jup = jup_house(c2, c1)
    def score_jup(h):
        if h is None: return 0.0
        if h in (1, 5, 9, 10, 11): return 5.0
        if h in (2, 4, 7):         return 3.0
        if h in (3,):              return 2.0
        return 0.5
    ethics_subtotal = min(score_jup(p1_jup) + score_jup(p2_jup), 10.0)
    ethics_notes = []
    if p1_jup in (10, 11):
        ethics_notes.append(f"p1's Jupiter in p2's {p1_jup}H — ethical/dharmic uplift in joint work")
    if p2_jup in (10, 11):
        ethics_notes.append(f"p2's Jupiter in p1's {p2_jup}H — ethical/dharmic uplift in joint work")
    ethics_stream = {
        "p1_jupiter_in_p2_house": p1_jup,
        "p2_jupiter_in_p1_house": p2_jup,
        "notes":                  ethics_notes,
        "subtotal":               round(ethics_subtotal, 2),
        "max":                    10.0,
    }

    composite_score = (
        (koot_subtotal / koot_max)            * 0.15 * 100
        + (d10_overlay["subtotal"] / 10.0)    * 0.35 * 100
        + (house_ov["subtotal"]    / 10.0)    * 0.30 * 100
        + (ethics_subtotal         / 10.0)    * 0.20 * 100
    )
    verdict = _composite_verdict(composite_score, 100.0)

    strengths, frictions = [], []
    if d10_overlay["notes"]:
        strengths.extend(d10_overlay["notes"])
    if d10_overlay["subtotal"] >= 7:
        strengths.append(f"Strong D10 (career-chart) overlay — {d10_overlay['subtotal']:.1f}/10")
    if ethics_notes:
        strengths.extend(ethics_notes)
    if house_ov["subtotal"] < 4:
        frictions.append(f"Business-house lords in difficult positions ({house_ov['subtotal']:.1f}/10) — 7H/10H/11H cross-overlay weak")
    if ethics_subtotal < 3:
        frictions.append("Jupiter cross-placements weak — dharmic/ethics alignment may need explicit cultivation")
    if koot_subtotal / koot_max < 0.4:
        frictions.append(f"Weak Tara/Graha-Maitri base ({koot_subtotal:.1f}/{koot_max})")

    deeper = (
        f"This business partnership reads as {verdict.lower()}. "
        f"D10 (career-chart) overlay scored {d10_overlay['subtotal']:.1f}/10, "
        f"D1 partnership-house overlay {house_ov['subtotal']:.1f}/10, "
        f"ethics/Jupiter cross {ethics_subtotal:.1f}/10."
    )

    return {
        "success":             True,
        "relationship_type":   "business_partner",
        "person1_role":        role1,
        "person2_role":        role2,
        "person1_essentials":  _safe_essentials_summary(e1),
        "person2_essentials":  _safe_essentials_summary(e2),
        "evidence_streams": {
            "koot_scores": {
                "tara":         tara,
                "graha_maitri": gmait,
                "subtotal":     round(koot_subtotal, 2),
                "max":          koot_max,
                "note":         "Tara + Graha Maitri only — instinctual/temperament koots not relevant for transactional partnership"
            },
            "d10_career_overlay": d10_overlay,
            "house_overlay":      house_ov,
            "ethics_signal":      ethics_stream,
        },
        "composite": {
            "score":               round(composite_score, 1),
            "max":                 100.0,
            "verdict":             verdict,
            "key_strengths":       strengths,
            "key_friction_points": frictions,
            "deeper_pattern":      deeper,
        },
        "classical_sources": F1A_CITATIONS["business_partner"],
        "karakas_consulted": RELATIONSHIP_KARAKAS["business"],
    }


# ════════════════════════════════════════════════════════════════════════
# COLLEAGUE
# ════════════════════════════════════════════════════════════════════════

def handle_colleague(person1: Dict[str, Any],
                     person2: Dict[str, Any],
                     role1: Optional[str] = None,
                     role2: Optional[str] = None) -> Dict[str, Any]:
    """
    F1b Endpoint: Workplace colleague compatibility.

    Frame: 6H (service/conflict), 10H (work), 3H (peers); karakas Saturn
    (service), Mars (drive/conflict), Mercury (communication).

    Streams: koot_scores (Gana + Graha Maitri; max 11, w=0.25)
             house_overlay (6H/10H/3H lords; max 10, w=0.30)
             saturn_mars_synastry (conflict signature inverted; max 10, w=0.30)
             communication (Mercury cross; max 10, w=0.15)
    """
    c1, e1 = _build_person(person1)
    c2, e2 = _build_person(person2)

    p1_nak  = e1.get("moon_nakshatra")
    p2_nak  = e2.get("moon_nakshatra")
    p1_moon = e1.get("moon_sign")
    p2_moon = e2.get("moon_sign")

    if not (p1_nak and p2_nak and p1_moon and p2_moon):
        return {
            "error": "Could not extract Moon nakshatra/sign for both natives",
            "citations": F1A_CITATIONS["colleague"],
        }

    # Stream 1: Gana + Graha Maitri (temperament + planetary friendship)
    gana  = _gana_kuta(p1_nak, p2_nak)
    gmait = _graha_maitri_kuta(p1_moon, p2_moon)
    koot_subtotal = float(gana.get("score", 0)) + float(gmait.get("score", 0))
    koot_max = 11.0  # 6 + 5

    # Stream 2: 6H/10H/3H lords cross
    house_ov = _colleague_house_overlay(c1, c2)

    # Stream 3: Saturn-Mars synastry (inverted; high score = clean)
    sat_mars = _saturn_mars_synastry(c1, c2)

    # Stream 4: Mercury cross-placement
    def mercury_house(p_from, p_to):
        return _planet_house_in_other_chart(p_from, p_to, "Mercury")
    p1_merc = mercury_house(c1, c2)
    p2_merc = mercury_house(c2, c1)
    def score_merc(h):
        if h is None: return 0.0
        if h in (3, 5, 10, 11): return 5.0
        if h in (1, 9):         return 4.0
        if h in (2, 4, 7):      return 2.5
        return 1.0
    comm_subtotal = min(score_merc(p1_merc) + score_merc(p2_merc), 10.0)
    comm_notes = []
    if p1_merc in (3, 10, 11):
        comm_notes.append(f"p1's Mercury in p2's {p1_merc}H — fluent professional communication from p1")
    if p2_merc in (3, 10, 11):
        comm_notes.append(f"p2's Mercury in p1's {p2_merc}H — fluent professional communication from p2")
    comm_stream = {
        "p1_mercury_in_p2_house": p1_merc,
        "p2_mercury_in_p1_house": p2_merc,
        "notes":                  comm_notes,
        "subtotal":               round(comm_subtotal, 2),
        "max":                    10.0,
    }

    composite_score = (
        (koot_subtotal / koot_max)            * 0.25 * 100
        + (house_ov["subtotal"]    / 10.0)    * 0.30 * 100
        + (sat_mars["subtotal"]    / 10.0)    * 0.30 * 100
        + (comm_subtotal           / 10.0)    * 0.15 * 100
    )
    verdict = _composite_verdict(composite_score, 100.0)

    strengths, frictions = [], []
    if koot_subtotal / koot_max >= 0.65:
        strengths.append(f"Strong temperament fit — Gana+Graha Maitri {koot_subtotal:.1f}/{koot_max}")
    elif koot_subtotal / koot_max < 0.4:
        frictions.append(f"Temperament mismatch — Gana+Graha Maitri {koot_subtotal:.1f}/{koot_max}")
    if sat_mars["subtotal"] >= 8:
        strengths.append("Clean Saturn-Mars cross — minimal workplace friction signature")
    elif sat_mars["subtotal"] < 5:
        frictions.append(f"Saturn-Mars friction signatures present — {sat_mars['subtotal']:.1f}/10")
        if sat_mars["notes"]:
            frictions.extend([n for n in sat_mars["notes"] if "friction" in n])
    if comm_notes:
        strengths.extend(comm_notes)

    deeper = (
        f"This workplace bond reads as {verdict.lower()}. "
        f"Saturn-Mars cross (conflict signature inverted) {sat_mars['subtotal']:.1f}/10, "
        f"service-house overlay {house_ov['subtotal']:.1f}/10, "
        f"Mercury communication cross {comm_subtotal:.1f}/10."
    )

    return {
        "success":             True,
        "relationship_type":   "colleague",
        "person1_role":        role1,
        "person2_role":        role2,
        "person1_essentials":  _safe_essentials_summary(e1),
        "person2_essentials":  _safe_essentials_summary(e2),
        "evidence_streams": {
            "koot_scores": {
                "gana":         gana,
                "graha_maitri": gmait,
                "subtotal":     round(koot_subtotal, 2),
                "max":          koot_max,
                "note":         "Gana + Graha Maitri — temperament + planetary friendship for daily-contact bonds"
            },
            "service_house_overlay": house_ov,
            "saturn_mars_synastry":  sat_mars,
            "communication":         comm_stream,
        },
        "composite": {
            "score":               round(composite_score, 1),
            "max":                 100.0,
            "verdict":             verdict,
            "key_strengths":       strengths,
            "key_friction_points": frictions,
            "deeper_pattern":      deeper,
        },
        "classical_sources": F1A_CITATIONS["colleague"],
        "karakas_consulted": RELATIONSHIP_KARAKAS["colleague"],
    }


# ════════════════════════════════════════════════════════════════════════
# COMPATIBILITY MATRIX (multi-person ranking)
# ════════════════════════════════════════════════════════════════════════

_MATRIX_HANDLERS = {
    "friendship":       lambda p1, p2, **kw: handle_friendship(p1, p2,
                                              role1=kw.get("role1"), role2=kw.get("role2")),
    "mentor":           lambda p1, p2, **kw: handle_mentor(p1, p2,
                                              role1=kw.get("role1"), role2=kw.get("role2")),
    "family":           lambda p1, p2, **kw: handle_family(p1, p2,
                                              role1=kw.get("role1"), role2=kw.get("role2"),
                                              subtype=kw.get("subtype")),
    "business_partner": lambda p1, p2, **kw: handle_business_partner(p1, p2,
                                              role1=kw.get("role1"), role2=kw.get("role2")),
    "colleague":        lambda p1, p2, **kw: handle_colleague(p1, p2,
                                              role1=kw.get("role1"), role2=kw.get("role2")),
}

MATRIX_HARD_CEILING = 50  # absolute max regardless of caller's max_others


def handle_compatibility_matrix(native: Dict[str, Any],
                                 others: List[Dict[str, Any]],
                                 relationship_type: str,
                                 subtype: Optional[str] = None,
                                 max_others: int = 20) -> Dict[str, Any]:
    """
    F1b Endpoint: Multi-person compatibility ranking.

    Takes one `native` and N `others`, runs the pairwise handler for the
    specified `relationship_type` against each, and returns the candidates
    ranked by composite score.

    Args:
      native:            BirthInput dict (the "you" person)
      others:            list of BirthInput dicts; each MAY include a "label" key
                         (e.g. {"label": "Sarah", "dob": ..., "time": ...})
      relationship_type: one of friendship|mentor|family|business_partner|colleague
      subtype:           for family only — "parent-child"|"sibling"|"extended"
      max_others:        caller-specified bound; clamped to MATRIX_HARD_CEILING

    Returns:
      ranked list of pairwise results + top-line summary
    """
    rt = (relationship_type or "").lower().strip()
    if rt not in _MATRIX_HANDLERS:
        return {
            "error": (f"Unknown relationship_type '{relationship_type}'. "
                      f"Must be one of: {sorted(_MATRIX_HANDLERS.keys())}"),
            "citations": F1A_CITATIONS["compatibility_matrix"],
        }

    if not isinstance(others, list) or len(others) == 0:
        return {
            "error": "others must be a non-empty list of birth-input dicts",
            "citations": F1A_CITATIONS["compatibility_matrix"],
        }

    # Clamp max_others
    effective_max = min(int(max_others or 20), MATRIX_HARD_CEILING)
    if effective_max < 1:
        effective_max = 1
    truncated = False
    if len(others) > effective_max:
        others_to_use = others[:effective_max]
        truncated = True
    else:
        others_to_use = others

    handler = _MATRIX_HANDLERS[rt]

    results = []
    for idx, other in enumerate(others_to_use):
        # Pull and strip the optional "label" field
        label = other.get("label") if isinstance(other, dict) else None
        # Build pristine birth-input dict (drop label + any extra fields)
        birth_other = {k: other[k] for k in
                       ("dob", "time", "lat", "lon", "timezone")
                       if isinstance(other, dict) and k in other}

        try:
            pairwise = handler(native, birth_other, subtype=subtype)
        except Exception as e:
            results.append({
                "index": idx,
                "label": label or f"candidate_{idx}",
                "error": f"pairwise computation failed: {e}",
                "composite_score": 0.0,
                "verdict": "DIFFICULT",
            })
            continue

        score = pairwise.get("composite", {}).get("score", 0.0)
        verdict = pairwise.get("composite", {}).get("verdict", "UNKNOWN")

        results.append({
            "index":            idx,
            "label":            label or f"candidate_{idx}",
            "composite_score":  score,
            "verdict":          verdict,
            "key_strengths":    pairwise.get("composite", {}).get("key_strengths", []),
            "key_friction_points": pairwise.get("composite", {}).get("key_friction_points", []),
            "deeper_pattern":   pairwise.get("composite", {}).get("deeper_pattern", ""),
            "full_pairwise":    pairwise,
        })

    # Rank by composite_score descending; preserve original index for ties
    ranked = sorted(results,
                    key=lambda r: (-r["composite_score"], r["index"]))

    # Top-line summary
    if ranked:
        top = ranked[0]
        summary = (f"Top match: '{top['label']}' "
                   f"(score {top['composite_score']:.1f}/100, {top['verdict']}). "
                   f"Ranked {len(ranked)} candidates total"
                   f"{' (truncated from larger input)' if truncated else ''}.")
    else:
        summary = "No candidates evaluated."

    return {
        "success":           True,
        "relationship_type": rt,
        "subtype":           subtype if rt == "family" else None,
        "native_dob":        native.get("dob"),
        "candidates_evaluated": len(ranked),
        "candidates_requested": len(others),
        "max_others_effective": effective_max,
        "max_others_ceiling":   MATRIX_HARD_CEILING,
        "truncated":            truncated,
        "summary":              summary,
        "ranked":               ranked,
        "classical_sources":    F1A_CITATIONS["compatibility_matrix"],
    }
