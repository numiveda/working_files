"""
astrocartography.py — numiVeda Kaaliyo Astro Engine — Module D6 (v2).

V2 FIX: Relocation now correctly uses direct Swiss Ephemeris computation
instead of round-tripping through dashaflow.get_chart() with new timezone.

The bug: passing new timezone to get_chart() reinterprets birth time locally
in the new timezone — wrong. Relocation fixes UT and changes only lat/lon.

The fix: cast birth chart ONCE for planet longitudes (sidereal). Then for
each location, recompute house cusps at new lat/lon (same jd_ut) and
reassign each planet's house based on which cusp range it falls in.

Endpoints (unchanged signatures):
    handle_profile             — Master synthesis (lines + parans)
    handle_planetary_lines     — All 36 MC/IC/AC/DC lines
    handle_relocate_chart      — Recast houses; compare to birth
    handle_local_space         — Directional azimuths to ~70 cities
    handle_location_compare    — Angular planets across N locations
    handle_optimal_locations   — Best cities for a life theme
"""

import math
import swisseph as swe
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from zoneinfo import ZoneInfo

from astro_helpers import (
    SIGNS_ORDER,
    SIGN_TO_LORD,
    extract_chart_essentials,
    get_chart,
)

from relocation_data import (
    MAJOR_CITIES,
    THEME_TO_PLANETS,
    ANGULAR_HOUSES,
    HOUSE_THEMES,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# SWISS EPH PLANET CONSTANTS
# ════════════════════════════════════════════════════════════════════════

PLANET_SWE_IDS: Dict[str, int] = {
    "Sun":     swe.SUN,
    "Moon":    swe.MOON,
    "Mars":    swe.MARS,
    "Mercury": swe.MERCURY,
    "Jupiter": swe.JUPITER,
    "Venus":   swe.VENUS,
    "Saturn":  swe.SATURN,
    "Rahu":    swe.MEAN_NODE,
}

ALL_PLANETS = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]


# ════════════════════════════════════════════════════════════════════════
# TIME / COORDINATE CONVERSION
# ════════════════════════════════════════════════════════════════════════

def _birth_to_jd_ut(birth: Dict[str, Any]) -> float:
    """Convert birth dob/time/timezone → Julian Day in UT (absolute moment)."""
    dob = birth["dob"]
    time_str = birth["time"]
    tz_str = birth.get("timezone", "Asia/Kolkata")
    year, month, day = map(int, dob.split("-"))
    hour, minute = map(int, time_str.split(":"))
    tz = ZoneInfo(tz_str)
    local_dt = datetime(year, month, day, hour, minute, tzinfo=tz)
    ut_dt = local_dt.astimezone(ZoneInfo("UTC"))
    return swe.julday(
        ut_dt.year, ut_dt.month, ut_dt.day,
        ut_dt.hour + ut_dt.minute / 60.0 + ut_dt.second / 3600.0,
    )


def _planet_ra_dec(jd_ut: float, planet_name: str) -> Tuple[float, float]:
    """Return (RA, declination) in degrees for a planet at JD UT."""
    if planet_name == "Ketu":
        r, _ = swe.calc_ut(jd_ut, swe.MEAN_NODE, swe.FLG_EQUATORIAL)
        return (r[0] + 180.0) % 360.0, -r[1]
    swe_id = PLANET_SWE_IDS.get(planet_name)
    if swe_id is None:
        return 0.0, 0.0
    r, _ = swe.calc_ut(jd_ut, swe_id, swe.FLG_EQUATORIAL)
    return r[0] % 360.0, r[1]


def _planet_sidereal_longitude(jd_ut: float, planet_name: str,
                                ayanamsha_deg: float = 23.5917) -> float:
    """Return sidereal (Lahiri-adjusted) ecliptic longitude in degrees."""
    if planet_name == "Ketu":
        r, _ = swe.calc_ut(jd_ut, swe.MEAN_NODE)
        lon_tropical = (r[0] + 180.0) % 360.0
    else:
        swe_id = PLANET_SWE_IDS.get(planet_name)
        if swe_id is None:
            return 0.0
        r, _ = swe.calc_ut(jd_ut, swe_id)
        lon_tropical = r[0]
    return (lon_tropical - ayanamsha_deg) % 360.0


def _gmst_degrees(jd_ut: float) -> float:
    return (swe.sidtime(jd_ut) * 15.0) % 360.0


def _normalize_longitude(lon: float) -> float:
    return ((lon + 180.0) % 360.0) - 180.0


def _lon_to_sign_deg(lon: float) -> Tuple[str, float]:
    lon = lon % 360.0
    sign_idx = int(lon // 30)
    return SIGNS_ORDER[sign_idx], round(lon - sign_idx * 30, 4)


def _get_lahiri_ayanamsha(jd_ut: float) -> float:
    """Get exact Lahiri ayanamsha for the birth moment."""
    swe.set_sid_mode(swe.SIDM_LAHIRI)
    return swe.get_ayanamsa_ut(jd_ut)


# ════════════════════════════════════════════════════════════════════════
# CORRECT RELOCATION — Cusps recomputed at new location; planets reassigned
# ════════════════════════════════════════════════════════════════════════

def _compute_sidereal_cusps(jd_ut: float, lat: float, lon: float,
                            ayanamsha_deg: float) -> Dict[str, Any]:
    """
    Compute house cusps at given lat/lon for fixed jd_ut.
    Returns cusps as 12-element list of sidereal longitudes (0-360).
    """
    cusps_tropical, ascmc = swe.houses_ex(jd_ut, lat, lon, b'P')
    cusps_sidereal = [(c - ayanamsha_deg) % 360.0 for c in cusps_tropical[:12]]
    asc_sidereal = (ascmc[0] - ayanamsha_deg) % 360.0
    mc_sidereal = (ascmc[1] - ayanamsha_deg) % 360.0
    return {
        "cusps":     cusps_sidereal,
        "ascendant": asc_sidereal,
        "mc":        mc_sidereal,
        "armc":      ascmc[2],
    }


def _planet_house_from_cusps(planet_longitude: float, cusps: List[float]) -> int:
    """
    Determine which house (1-12) a planet falls into given the 12 cusps.
    Each house spans from cusp[N] to cusp[N+1] (wrap at 12 → 1).
    """
    for i in range(12):
        start = cusps[i]
        end = cusps[(i + 1) % 12]
        # Handle wrap-around (e.g. cusp from 350° to 30°)
        if start <= end:
            if start <= planet_longitude < end:
                return i + 1
        else:
            if planet_longitude >= start or planet_longitude < end:
                return i + 1
    return 1  # fallback


def _relocate_birth_chart(birth: Dict[str, Any],
                          new_lat: float, new_lon: float) -> Dict[str, Any]:
    """
    CORE FIX: Compute relocated chart using direct Swiss Eph.
    Birth moment (jd_ut) is fixed. Only lat/lon change.
    Returns: relocated lagna, mc, cusps, and planets-in-new-houses.
    """
    jd_ut = _birth_to_jd_ut(birth)
    ayanamsha_deg = _get_lahiri_ayanamsha(jd_ut)

    new_cusps_data = _compute_sidereal_cusps(jd_ut, new_lat, new_lon, ayanamsha_deg)
    cusps = new_cusps_data["cusps"]

    # Compute planet longitudes (these are SAME regardless of location)
    relocated_planets: Dict[str, Dict[str, Any]] = {}
    for planet in ALL_PLANETS:
        lon_sid = _planet_sidereal_longitude(jd_ut, planet, ayanamsha_deg)
        sign, deg = _lon_to_sign_deg(lon_sid)
        house = _planet_house_from_cusps(lon_sid, cusps)
        relocated_planets[planet] = {
            "longitude": round(lon_sid, 4),
            "sign":      sign,
            "degree":    deg,
            "house":     house,
        }

    asc_sign, asc_deg = _lon_to_sign_deg(new_cusps_data["ascendant"])
    mc_sign, mc_deg = _lon_to_sign_deg(new_cusps_data["mc"])

    return {
        "jd_ut":         jd_ut,
        "ayanamsha_deg": round(ayanamsha_deg, 4),
        "ascendant":     {"longitude": round(new_cusps_data["ascendant"], 4),
                          "sign": asc_sign, "degree": asc_deg},
        "mc":            {"longitude": round(new_cusps_data["mc"], 4),
                          "sign": mc_sign, "degree": mc_deg},
        "armc":          round(new_cusps_data["armc"], 4),
        "cusps":         [{"house": i + 1, "longitude": round(c, 4),
                            "sign": _lon_to_sign_deg(c)[0],
                            "degree": _lon_to_sign_deg(c)[1]}
                          for i, c in enumerate(cusps)],
        "planets":       relocated_planets,
    }


# ════════════════════════════════════════════════════════════════════════
# PLANETARY LINE COMPUTATION (Lewis-style; unchanged from v1)
# ════════════════════════════════════════════════════════════════════════

def _mc_line_longitude(planet_ra: float, gmst_deg: float) -> float:
    return _normalize_longitude(planet_ra - gmst_deg)


def _ic_line_longitude(planet_ra: float, gmst_deg: float) -> float:
    return _normalize_longitude(planet_ra - gmst_deg + 180.0)


def _ac_dc_lines_at_latitude(planet_ra: float, planet_dec: float,
                              gmst_deg: float, latitude: float) -> Optional[Dict[str, float]]:
    try:
        lat_rad = math.radians(latitude)
        dec_rad = math.radians(planet_dec)
        cos_H = -math.tan(lat_rad) * math.tan(dec_rad)
        if cos_H < -1.0 or cos_H > 1.0:
            return None
        H_deg = math.degrees(math.acos(cos_H))
        return {
            "AC_longitude": _normalize_longitude(planet_ra - gmst_deg - H_deg),
            "DC_longitude": _normalize_longitude(planet_ra - gmst_deg + H_deg),
        }
    except (ValueError, ZeroDivisionError):
        return None


def _compute_all_lines(jd_ut: float,
                       sample_latitudes: Optional[List[float]] = None) -> Dict[str, Any]:
    if sample_latitudes is None:
        sample_latitudes = list(range(-70, 71, 10))
    gmst_deg = _gmst_degrees(jd_ut)
    all_lines: Dict[str, Dict[str, Any]] = {}
    for planet in ALL_PLANETS:
        ra, dec = _planet_ra_dec(jd_ut, planet)
        mc_lon = _mc_line_longitude(ra, gmst_deg)
        ic_lon = _ic_line_longitude(ra, gmst_deg)
        ac_curve: List[Dict[str, float]] = []
        dc_curve: List[Dict[str, float]] = []
        for lat in sample_latitudes:
            result = _ac_dc_lines_at_latitude(ra, dec, gmst_deg, lat)
            if result is not None:
                ac_curve.append({"latitude": lat, "longitude": result["AC_longitude"]})
                dc_curve.append({"latitude": lat, "longitude": result["DC_longitude"]})
        all_lines[planet] = {
            "RA":              round(ra, 4),
            "declination":     round(dec, 4),
            "MC_line":         {"longitude": round(mc_lon, 4),
                                "type": "meridian", "interpretation": f"{planet} on MC — public-life/career-recognition zone"},
            "IC_line":         {"longitude": round(ic_lon, 4),
                                "type": "meridian", "interpretation": f"{planet} on IC — private-life/foundations zone"},
            "AC_curve":        ac_curve,
            "DC_curve":        dc_curve,
            "ac_curve_points": len(ac_curve),
            "dc_curve_points": len(dc_curve),
        }
    return {
        "gmst_at_birth":   round(gmst_deg, 4),
        "planetary_lines": all_lines,
    }


def _compute_parans(lines_data: Dict[str, Any],
                    longitude_tolerance: float = 1.0) -> List[Dict[str, Any]]:
    parans: List[Dict[str, Any]] = []
    planet_list = list(lines_data["planetary_lines"].keys())
    for i in range(len(planet_list)):
        for j in range(i + 1, len(planet_list)):
            p1 = planet_list[i]
            p2 = planet_list[j]
            p1_data = lines_data["planetary_lines"][p1]
            p2_data = lines_data["planetary_lines"][p2]
            p1_lines = {
                "MC": [{"latitude": None, "longitude": p1_data["MC_line"]["longitude"]}],
                "IC": [{"latitude": None, "longitude": p1_data["IC_line"]["longitude"]}],
                "AC": p1_data["AC_curve"],
                "DC": p1_data["DC_curve"],
            }
            p2_lines = {
                "MC": [{"latitude": None, "longitude": p2_data["MC_line"]["longitude"]}],
                "IC": [{"latitude": None, "longitude": p2_data["IC_line"]["longitude"]}],
                "AC": p2_data["AC_curve"],
                "DC": p2_data["DC_curve"],
            }
            for l1_type, l1_pts in p1_lines.items():
                for l2_type, l2_pts in p2_lines.items():
                    for pt1 in l1_pts:
                        for pt2 in l2_pts:
                            lat1, lon1 = pt1.get("latitude"), pt1["longitude"]
                            lat2, lon2 = pt2.get("latitude"), pt2["longitude"]
                            if abs(lon1 - lon2) > longitude_tolerance:
                                continue
                            if lat1 is None and lat2 is None:
                                continue
                            crossing_lat = lat1 if lat1 is not None else lat2
                            if lat1 is not None and lat2 is not None and abs(lat1 - lat2) > 5:
                                continue
                            parans.append({
                                "planet_1":      p1,
                                "line_1":        l1_type,
                                "planet_2":      p2,
                                "line_2":        l2_type,
                                "crossing_lat":  crossing_lat,
                                "crossing_lon":  round((lon1 + lon2) / 2, 4),
                                "intensity":     "high" if l1_type in ("MC", "IC") and l2_type in ("MC", "IC") else "moderate",
                            })
    return parans[:50]


# ════════════════════════════════════════════════════════════════════════
# LOCAL SPACE
# ════════════════════════════════════════════════════════════════════════

def _great_circle_azimuth(lat1: float, lon1: float,
                          lat2: float, lon2: float) -> float:
    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    delta_lon = math.radians(lon2 - lon1)
    x = math.sin(delta_lon) * math.cos(lat2_rad)
    y = (math.cos(lat1_rad) * math.sin(lat2_rad)
         - math.sin(lat1_rad) * math.cos(lat2_rad) * math.cos(delta_lon))
    return (math.degrees(math.atan2(x, y)) + 360) % 360


def _great_circle_distance_km(lat1: float, lon1: float,
                              lat2: float, lon2: float) -> float:
    R = 6371.0
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)
    a = (math.sin(delta_phi/2)**2
         + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda/2)**2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return R * c


# ════════════════════════════════════════════════════════════════════════
# THEME SCORING (uses fixed _relocate_birth_chart)
# ════════════════════════════════════════════════════════════════════════

def _score_location_for_theme(birth: Dict[str, Any],
                              loc: Dict[str, Any],
                              theme: str) -> Dict[str, Any]:
    theme_data = THEME_TO_PLANETS.get(theme, {})
    desirable = set(theme_data.get("desirable_in_angular", []))
    favorable_houses = set(theme_data.get("favorable_houses", []))

    reloc = _relocate_birth_chart(birth, loc["lat"], loc["lon"])
    score = 0
    matches: List[str] = []
    angular_houses_set = {1, 4, 7, 10}

    for p, pd in reloc["planets"].items():
        house = pd["house"]
        if p in desirable and house in angular_houses_set:
            score += 10
            matches.append(f"{p} angular (H{house})")
        elif p in desirable and house in favorable_houses:
            score += 5
            matches.append(f"{p} in H{house}")

    return {
        "score":             min(score, 100),
        "theme_matches":     matches,
        "relocated_planets": {p: pd["house"] for p, pd in reloc["planets"].items()},
        "relocated_lagna":   reloc["ascendant"]["sign"],
    }


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT HANDLERS
# ════════════════════════════════════════════════════════════════════════

def handle_planetary_lines(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 2: All 36 planetary lines (unchanged from v1)."""
    jd_ut = _birth_to_jd_ut(birth)
    lines_data = _compute_all_lines(jd_ut)
    return {
        "birth":         birth,
        "julian_day_ut": round(jd_ut, 4),
        **lines_data,
        "method":        "Lewis-style astrocartography via Swiss Ephemeris 2.10. MC/IC = meridians; AC/DC = latitude-dependent curves.",
        "citation":      CLASSICAL_CITATIONS["astrocartography"],
    }


def handle_relocate_chart(birth: Dict[str, Any],
                          new_lat: float, new_lon: float,
                          new_timezone: Optional[str] = None,
                          location_name: Optional[str] = None) -> Dict[str, Any]:
    """Endpoint 3: Chart recast at new location. FIXED in v2 to use direct Swiss Eph."""
    # Birth chart (sidereal house assignments at birth lat/lon)
    birth_reloc = _relocate_birth_chart(birth, birth["lat"], birth["lon"])
    # Relocated chart
    new_reloc = _relocate_birth_chart(birth, new_lat, new_lon)

    house_shifts: List[Dict[str, Any]] = []
    for p in ALL_PLANETS:
        b = birth_reloc["planets"].get(p, {})
        r = new_reloc["planets"].get(p, {})
        b_house = b.get("house")
        r_house = r.get("house")
        if b_house != r_house:
            house_shifts.append({
                "planet":           p,
                "birth_house":      b_house,
                "relocated_house":  r_house,
                "theme_change":     f"{HOUSE_THEMES.get(b_house, '?')} → {HOUSE_THEMES.get(r_house, '?')}",
            })

    return {
        "birth_location":     {"lat": birth["lat"], "lon": birth["lon"]},
        "relocated_to":       {"name": location_name, "lat": new_lat, "lon": new_lon,
                               "timezone": new_timezone},
        "birth_lagna":        birth_reloc["ascendant"]["sign"],
        "birth_mc":           birth_reloc["mc"]["sign"],
        "relocated_lagna":    new_reloc["ascendant"]["sign"],
        "relocated_mc":       new_reloc["mc"]["sign"],
        "house_shifts":       house_shifts,
        "total_shifts":       len(house_shifts),
        "relocated_chart":    {
            "lagna":   new_reloc["ascendant"],
            "mc":      new_reloc["mc"],
            "armc":    new_reloc["armc"],
            "planets": new_reloc["planets"],
        },
        "method":             "v2 fix: cast birth chart in absolute UT; recompute house cusps at new lat/lon via swe.houses_ex; reassign planets to new houses. Planet ecliptic positions unchanged (planets don't move with you).",
        "citation":           CLASSICAL_CITATIONS["relocation"],
    }


def handle_local_space(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 4: Azimuths to ~70 cities (unchanged from v1)."""
    b_lat = birth["lat"]
    b_lon = birth["lon"]
    directions: List[Dict[str, Any]] = []
    for city in MAJOR_CITIES:
        az = _great_circle_azimuth(b_lat, b_lon, city["lat"], city["lon"])
        dist = _great_circle_distance_km(b_lat, b_lon, city["lat"], city["lon"])
        compass_idx = int(((az + 11.25) % 360) / 22.5)
        compass_dirs = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
                       "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]
        directions.append({
            "city":       city["name"],
            "country":    city["country"],
            "lat":        city["lat"],
            "lon":        city["lon"],
            "azimuth":    round(az, 2),
            "compass":    compass_dirs[compass_idx],
            "distance_km":round(dist, 1),
        })
    directions.sort(key=lambda d: d["distance_km"])
    return {
        "birth_location": {"lat": b_lat, "lon": b_lon},
        "destinations":   directions,
        "city_count":     len(directions),
        "citation":       CLASSICAL_CITATIONS["relocation"],
    }


def handle_location_compare(birth: Dict[str, Any],
                            locations: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Endpoint 5: Angular planets across locations. FIXED in v2."""
    if not locations:
        return {"error": "Provide at least one location"}

    comparisons: List[Dict[str, Any]] = []
    angular_houses_set = {1, 4, 7, 10}

    for loc in locations:
        if "lat" not in loc or "lon" not in loc:
            continue
        reloc = _relocate_birth_chart(birth, loc["lat"], loc["lon"])
        angular: List[Dict[str, Any]] = []
        for p, pd in reloc["planets"].items():
            if pd["house"] in angular_houses_set:
                angular.append({
                    "planet":      p,
                    "house":       pd["house"],
                    "house_theme": ANGULAR_HOUSES[pd["house"]]["theme"],
                    "sign":        pd["sign"],
                })
        comparisons.append({
            "location":         loc.get("name", f"{loc['lat']},{loc['lon']}"),
            "lat":              loc["lat"],
            "lon":              loc["lon"],
            "relocated_lagna":  reloc["ascendant"]["sign"],
            "relocated_mc":     reloc["mc"]["sign"],
            "angular_planets":  angular,
            "angular_count":    len(angular),
        })

    return {
        "comparisons":  comparisons,
        "method":       "v2 fix: each location's chart recomputed via direct Swiss Eph (jd_ut fixed, only lat/lon vary).",
        "citation":     CLASSICAL_CITATIONS["relocation"],
    }


def handle_optimal_locations(birth: Dict[str, Any],
                             theme: str,
                             top_n: int = 10,
                             region: Optional[str] = None) -> Dict[str, Any]:
    """Endpoint 6: Best cities for a theme. FIXED in v2."""
    if theme not in THEME_TO_PLANETS:
        return {
            "error":        f"Theme '{theme}' not recognized",
            "valid_themes": list(THEME_TO_PLANETS.keys()),
        }
    candidates = MAJOR_CITIES
    if region:
        candidates = [c for c in MAJOR_CITIES if c.get("country", "").lower() == region.lower()]
        if not candidates:
            return {"error": f"No cities found for region '{region}'"}

    scored: List[Dict[str, Any]] = []
    for city in candidates:
        score_data = _score_location_for_theme(birth, city, theme)
        scored.append({
            "city":    city["name"],
            "country": city["country"],
            "lat":     city["lat"],
            "lon":     city["lon"],
            **score_data,
        })
    scored.sort(key=lambda d: d["score"], reverse=True)
    return {
        "theme":            theme,
        "theme_definition": THEME_TO_PLANETS[theme],
        "region_filter":    region,
        "top_locations":    scored[:top_n],
        "total_evaluated":  len(scored),
        "citation":         CLASSICAL_CITATIONS["themes"],
    }


def handle_profile(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 1 (MASTER): Lines + parans synthesis."""
    jd_ut = _birth_to_jd_ut(birth)
    lines = _compute_all_lines(jd_ut)
    parans = _compute_parans(lines)

    headlines: List[str] = []
    for p in ["Sun", "Jupiter", "Venus", "Saturn"]:
        pd = lines["planetary_lines"].get(p, {})
        if pd:
            mc_lon = pd["MC_line"]["longitude"]
            headlines.append(f"{p} MC line at geographic longitude {mc_lon}°"
                            f" (public-life amplifier zone)")
    if parans:
        for paran in parans[:3]:
            headlines.append(
                f"Paran: {paran['planet_1']}/{paran['line_1']} crosses "
                f"{paran['planet_2']}/{paran['line_2']} at ~lat {paran['crossing_lat']}°, "
                f"lon {paran['crossing_lon']}° ({paran['intensity']} intensity)"
            )

    return {
        "headlines":       headlines,
        "gmst_at_birth":   lines["gmst_at_birth"],
        "planetary_lines": lines["planetary_lines"],
        "parans":          parans,
        "paran_count":     len(parans),
        "method":          "Lewis-style astrocartography (Swiss Ephemeris 2.10). MC/IC = meridians; AC/DC = latitude-curves; parans = where any two lines cross.",
        "citations":       CLASSICAL_CITATIONS,
    }
