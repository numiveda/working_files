"""
transit_aspects.py — numiVeda Kaaliyo Astro Engine — Upgrade 3 (Transit Aspects).

2 new handlers leveraging Swiss Ephemeris speed data:
    handle_applying_aspects_to_natal — Currently-active aspects with applying/separating flag
    handle_upcoming_exact_aspects   — Forward-step to find exact aspects in next N days

Architecture:
    - Uses swisseph directly for planet speed and forward-stepping.
    - Detects WESTERN aspects (5 major + quincunx) AND VEDIC aspects (Mars 4/7/8,
      Jupiter 5/7/9, Saturn 3/7/10, others 7th).
    - Birth chart fetched once for natal positions; transits forward-stepped
      from current moment (or specified moment).
"""

import math
import swisseph as swe
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from zoneinfo import ZoneInfo

from astro_helpers import (
    SIGNS_ORDER,
    SIGN_TO_LORD,
    extract_chart_essentials,
    get_chart,
)

from transit_aspects_data import (
    WESTERN_ASPECTS,
    VEDIC_PLANET_ASPECTS,
    ORB_BY_PLANET,
    APPLICATION_RULES,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# SWISS EPH CONSTANTS
# ════════════════════════════════════════════════════════════════════════

PLANET_SWE_IDS: Dict[str, int] = {
    "Sun":     swe.SUN,
    "Moon":    swe.MOON,
    "Mars":    swe.MARS,
    "Mercury": swe.MERCURY,
    "Jupiter": swe.JUPITER,
    "Venus":   swe.VENUS,
    "Saturn":  swe.SATURN,
    "Rahu":    swe.MEAN_NODE,
}

ALL_PLANETS = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]


# ════════════════════════════════════════════════════════════════════════
# TIME / POSITION HELPERS
# ════════════════════════════════════════════════════════════════════════

def _birth_to_jd_ut(birth: Dict[str, Any]) -> float:
    dob = birth["dob"]
    time_str = birth["time"]
    tz_str = birth.get("timezone", "Asia/Kolkata")
    year, month, day = map(int, dob.split("-"))
    hour, minute = map(int, time_str.split(":"))
    tz = ZoneInfo(tz_str)
    local_dt = datetime(year, month, day, hour, minute, tzinfo=tz)
    ut_dt = local_dt.astimezone(ZoneInfo("UTC"))
    return swe.julday(
        ut_dt.year, ut_dt.month, ut_dt.day,
        ut_dt.hour + ut_dt.minute / 60.0 + ut_dt.second / 3600.0,
    )


def _moment_to_jd_ut(moment_iso: Optional[str] = None) -> float:
    """Convert an ISO datetime (or 'now' UTC default) to JD UT."""
    if moment_iso is None:
        dt = datetime.utcnow()
    else:
        try:
            dt = datetime.fromisoformat(moment_iso)
            if dt.tzinfo is not None:
                dt = dt.astimezone(ZoneInfo("UTC")).replace(tzinfo=None)
        except ValueError:
            dt = datetime.utcnow()
    return swe.julday(
        dt.year, dt.month, dt.day,
        dt.hour + dt.minute / 60.0 + dt.second / 3600.0,
    )


def _jd_ut_to_iso(jd_ut: float, tz_str: str = "Asia/Kolkata") -> str:
    """Convert JD UT to ISO datetime string in the given timezone."""
    year, month, day, hour_frac = swe.revjul(jd_ut)
    hour = int(hour_frac)
    minute = int((hour_frac - hour) * 60)
    second = int((((hour_frac - hour) * 60) - minute) * 60)
    dt_ut = datetime(int(year), int(month), int(day), hour, minute, second,
                     tzinfo=ZoneInfo("UTC"))
    dt_local = dt_ut.astimezone(ZoneInfo(tz_str))
    return dt_local.isoformat()


def _planet_lon_speed_sidereal(jd_ut: float, planet_name: str,
                                ayanamsha_deg: float) -> Tuple[float, float]:
    """
    Return (sidereal_longitude, speed_deg_per_day) for a planet.
    Speed in tropical reference = speed in sidereal (ayanamsha shifts uniformly).
    """
    if planet_name == "Ketu":
        r, _ = swe.calc_ut(jd_ut, swe.MEAN_NODE, swe.FLG_SPEED)
        lon_tropical = (r[0] + 180.0) % 360.0
        speed = -r[3]  # Ketu moves opposite to Rahu
        return (lon_tropical - ayanamsha_deg) % 360.0, speed
    swe_id = PLANET_SWE_IDS.get(planet_name)
    if swe_id is None:
        return 0.0, 0.0
    r, _ = swe.calc_ut(jd_ut, swe_id, swe.FLG_SPEED)
    lon_tropical = r[0]
    speed = r[3]
    return (lon_tropical - ayanamsha_deg) % 360.0, speed


def _get_lahiri_ayanamsha(jd_ut: float) -> float:
    swe.set_sid_mode(swe.SIDM_LAHIRI)
    return swe.get_ayanamsa_ut(jd_ut)


def _angular_separation(lon1: float, lon2: float) -> float:
    """Minimum angle between two longitudes (0-180)."""
    diff = abs(lon1 - lon2) % 360
    return diff if diff <= 180 else 360 - diff


def _signed_angle(transit_lon: float, natal_lon: float) -> float:
    """Signed angle from natal to transit (-180 to +180); positive = transit ahead of natal."""
    diff = (transit_lon - natal_lon + 540) % 360 - 180
    return diff


# ════════════════════════════════════════════════════════════════════════
# ASPECT DETECTION
# ════════════════════════════════════════════════════════════════════════

def _detect_aspect(transit_lon: float, natal_lon: float,
                   transit_speed: float,
                   transit_planet: str,
                   tradition: str = "western") -> Optional[Dict[str, Any]]:
    """
    Check if transit-to-natal forms an aspect. Returns aspect info or None.

    For Western: check 5 major aspects + quincunx.
    For Vedic: check special aspects (4/7/8 for Mars, 5/7/9 for Jupiter, etc.).
    """
    candidates = []

    if tradition == "western":
        for aspect_name, info in WESTERN_ASPECTS.items():
            target = info["angle"]
            orb_max = info["orb_default"]
            # Compute current orb from exact aspect
            sep = _angular_separation(transit_lon, natal_lon)
            orb_from_exact = abs(sep - target)
            if orb_from_exact <= orb_max:
                candidates.append({
                    "name":            aspect_name,
                    "target_angle":    target,
                    "orb_from_exact":  orb_from_exact,
                    "nature":          info["nature"],
                    "interpretation":  info["interpretation"],
                })

    elif tradition == "vedic":
        # Vedic aspects are direction-specific (e.g., Mars aspects the 4th from itself,
        # not the 4th house in either direction). We use signed angle.
        vedic_aspects = VEDIC_PLANET_ASPECTS.get(transit_planet, [])
        signed = _signed_angle(natal_lon, transit_lon)  # natal relative to transit
        if signed < 0:
            signed += 360  # ensure 0-360
        # Vedic orb generally 5° for full aspect
        vedic_orb = 5.0
        for asp in vedic_aspects:
            target_angle = asp["angle"]
            orb_from_exact = abs(signed - target_angle)
            if orb_from_exact > 180:
                orb_from_exact = 360 - orb_from_exact
            if orb_from_exact <= vedic_orb:
                candidates.append({
                    "name":            f"vedic_{asp['name']}",
                    "target_angle":    target_angle,
                    "orb_from_exact":  orb_from_exact,
                    "nature":          "tradition_specific",
                    "interpretation":  f"{transit_planet}'s {asp['name']} drishti — full strength Vedic aspect",
                })

    if not candidates:
        return None

    # Closest aspect wins
    best = min(candidates, key=lambda a: a["orb_from_exact"])

    # Determine applying vs separating
    # For Western: check if transit speed brings transit_lon toward exact aspect
    # If transit's signed distance to natal is decreasing (moving toward target angle), it's applying.
    # We approximate by computing where transit will be in +0.1 day and seeing if orb decreases.
    delta_days = 0.1
    transit_future = (transit_lon + transit_speed * delta_days) % 360
    sep_now = _angular_separation(transit_lon, natal_lon)
    sep_future = _angular_separation(transit_future, natal_lon)
    target = best["target_angle"]
    orb_future = abs(sep_future - target)

    if best["orb_from_exact"] < 0.5:
        application = "exact"
    elif orb_future < best["orb_from_exact"]:
        application = "applying"
    elif orb_future > best["orb_from_exact"]:
        application = "separating"
    else:
        application = "stationary"

    # Estimate days to/from exact
    if abs(transit_speed) < 0.001:
        days_estimate = None  # planet is stationary, can't estimate
    else:
        days_estimate = best["orb_from_exact"] / abs(transit_speed)
        days_estimate = round(days_estimate, 2)

    return {
        "aspect":          best["name"],
        "target_angle":    best["target_angle"],
        "current_orb":     round(best["orb_from_exact"], 4),
        "nature":          best["nature"],
        "interpretation":  best["interpretation"],
        "application":     application,
        "days_to_exact_estimate": days_estimate if application == "applying" else None,
        "days_since_exact_estimate": days_estimate if application == "separating" else None,
        "transit_speed_deg_per_day": round(transit_speed, 4),
    }


def _natal_positions_sidereal(birth: Dict[str, Any]) -> Dict[str, float]:
    """Compute sidereal longitudes of natal planets via Swiss Eph."""
    jd_birth = _birth_to_jd_ut(birth)
    ayanamsha_deg = _get_lahiri_ayanamsha(jd_birth)
    natal: Dict[str, float] = {}
    for p in ALL_PLANETS:
        lon, _ = _planet_lon_speed_sidereal(jd_birth, p, ayanamsha_deg)
        natal[p] = lon
    return natal


def _transit_positions_sidereal(jd_ut: float) -> Dict[str, Tuple[float, float]]:
    """Compute sidereal (lon, speed) of all transit planets at jd_ut."""
    ayanamsha_deg = _get_lahiri_ayanamsha(jd_ut)
    transits: Dict[str, Tuple[float, float]] = {}
    for p in ALL_PLANETS:
        lon, speed = _planet_lon_speed_sidereal(jd_ut, p, ayanamsha_deg)
        transits[p] = (lon, speed)
    return transits


def _lon_to_sign_deg(lon: float) -> Tuple[str, float]:
    lon = lon % 360.0
    sign_idx = int(lon // 30)
    return SIGNS_ORDER[sign_idx], round(lon - sign_idx * 30, 4)


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT 1: handle_applying_aspects_to_natal
# ════════════════════════════════════════════════════════════════════════

def handle_applying_aspects_to_natal(
    birth: Dict[str, Any],
    moment: Optional[str] = None,
    tradition: str = "both",
    min_orb: float = 0.0,
    max_orb: float = 8.0,
) -> Dict[str, Any]:
    """
    Detect all currently-active transit aspects to natal planets.

    Parameters:
        birth     — natal chart birth info
        moment    — ISO datetime (UTC if no tz); defaults to now (UTC)
        tradition — "western", "vedic", or "both" (default)
        min_orb   — filter aspects tighter than this (0.0 to include exact)
        max_orb   — filter aspects wider than this
    """
    jd_now = _moment_to_jd_ut(moment)
    natal = _natal_positions_sidereal(birth)
    transits = _transit_positions_sidereal(jd_now)

    applying: List[Dict[str, Any]] = []
    separating: List[Dict[str, Any]] = []
    exact: List[Dict[str, Any]] = []

    traditions_to_check = ["western", "vedic"] if tradition == "both" else [tradition]

    for tp_name, (tp_lon, tp_speed) in transits.items():
        for np_name, np_lon in natal.items():
            for trad in traditions_to_check:
                aspect = _detect_aspect(tp_lon, np_lon, tp_speed, tp_name, trad)
                if aspect is None:
                    continue
                if not (min_orb <= aspect["current_orb"] <= max_orb):
                    continue
                t_sign, t_deg = _lon_to_sign_deg(tp_lon)
                n_sign, n_deg = _lon_to_sign_deg(np_lon)
                entry = {
                    "transit_planet":     tp_name,
                    "transit_sign":       t_sign,
                    "transit_degree":     t_deg,
                    "natal_planet":       np_name,
                    "natal_sign":         n_sign,
                    "natal_degree":       n_deg,
                    "tradition":          trad,
                    **aspect,
                }
                if aspect["application"] == "applying":
                    applying.append(entry)
                elif aspect["application"] == "separating":
                    separating.append(entry)
                elif aspect["application"] == "exact":
                    exact.append(entry)

    applying.sort(key=lambda x: x["current_orb"])
    separating.sort(key=lambda x: x["current_orb"])
    exact.sort(key=lambda x: x["current_orb"])

    return {
        "moment":           moment or "now_utc",
        "jd_ut":            round(jd_now, 4),
        "tradition_filter": tradition,
        "orb_range":        {"min": min_orb, "max": max_orb},
        "exact_aspects":    exact,
        "applying":         applying,
        "separating":       separating,
        "summary": {
            "exact_count":      len(exact),
            "applying_count":   len(applying),
            "separating_count": len(separating),
        },
        "method":           "Direct Swiss Ephemeris computation: transit positions + speeds (FLG_SPEED) at moment. Applying/separating determined by future orb (jd+0.1 day).",
        "citation":         CLASSICAL_CITATIONS["western_aspects"] + "; " + CLASSICAL_CITATIONS["vedic_drishti"] + "; " + CLASSICAL_CITATIONS["applying"],
    }


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT 2: handle_upcoming_exact_aspects
# ════════════════════════════════════════════════════════════════════════

def handle_upcoming_exact_aspects(
    birth: Dict[str, Any],
    days_ahead: int = 30,
    moment_start: Optional[str] = None,
    tradition: str = "western",
    step_hours: float = 6.0,
) -> Dict[str, Any]:
    """
    Forward-step Swiss Ephemeris to find when each currently-applying aspect
    becomes exact. Returns timing calendar.

    Parameters:
        birth        — natal chart
        days_ahead   — search window (default 30, max 365)
        moment_start — ISO datetime; defaults to now
        tradition    — "western" (default) or "vedic"
        step_hours   — granularity of forward-stepping (default 6h)
    """
    days_ahead = max(1, min(days_ahead, 365))
    step_days = step_hours / 24.0

    jd_start = _moment_to_jd_ut(moment_start)
    jd_end = jd_start + days_ahead

    natal = _natal_positions_sidereal(birth)

    # Track each (transit_planet, natal_planet, aspect_name) seen as applying
    # Walk forward; when the aspect's orb crosses zero (sign change in signed angle distance to target),
    # log the exact moment.

    # Strategy: at each step, compute every transit-to-natal aspect orb. Compare to previous step.
    # If sign of (orb - target) flipped → exact aspect occurred between previous and current step.

    upcoming: List[Dict[str, Any]] = []

    # Get initial state
    prev_state: Dict[Tuple[str, str, str], float] = {}  # (tp, np, aspect_name) -> signed orb
    ayanamsha_now = _get_lahiri_ayanamsha(jd_start)
    for tp in ALL_PLANETS:
        tp_lon, _ = _planet_lon_speed_sidereal(jd_start, tp, ayanamsha_now)
        for np_name, np_lon in natal.items():
            sep = _angular_separation(tp_lon, np_lon)
            if tradition == "western":
                for aspect_name, info in WESTERN_ASPECTS.items():
                    target = info["angle"]
                    signed_orb = sep - target
                    prev_state[(tp, np_name, aspect_name)] = signed_orb

    jd_curr = jd_start
    step_count = 0
    max_steps = int(days_ahead / step_days)

    while jd_curr < jd_end and step_count < max_steps:
        jd_curr += step_days
        step_count += 1
        ayanamsha_curr = _get_lahiri_ayanamsha(jd_curr)

        for tp in ALL_PLANETS:
            tp_lon, tp_speed = _planet_lon_speed_sidereal(jd_curr, tp, ayanamsha_curr)
            for np_name, np_lon in natal.items():
                sep = _angular_separation(tp_lon, np_lon)
                if tradition == "western":
                    for aspect_name, info in WESTERN_ASPECTS.items():
                        target = info["angle"]
                        signed_orb_curr = sep - target
                        key = (tp, np_name, aspect_name)
                        signed_orb_prev = prev_state.get(key, signed_orb_curr)
                        # Detect zero-crossing (sign change in signed_orb)
                        if signed_orb_prev * signed_orb_curr < 0:
                            # Linear interpolation for exact moment
                            jd_prev = jd_curr - step_days
                            frac = abs(signed_orb_prev) / (abs(signed_orb_prev) + abs(signed_orb_curr))
                            jd_exact = jd_prev + frac * step_days
                            # Filter: skip stationary-near-zero artifacts
                            if abs(tp_speed) > 0.001:
                                t_sign, t_deg = _lon_to_sign_deg(tp_lon)
                                n_sign, n_deg = _lon_to_sign_deg(np_lon)
                                upcoming.append({
                                    "transit_planet":  tp,
                                    "transit_sign":    t_sign,
                                    "natal_planet":    np_name,
                                    "natal_sign":      n_sign,
                                    "aspect":          aspect_name,
                                    "target_angle":    target,
                                    "nature":          info["nature"],
                                    "interpretation":  info["interpretation"],
                                    "exact_moment_utc":_jd_ut_to_iso(jd_exact, "UTC"),
                                    "exact_moment_ist":_jd_ut_to_iso(jd_exact, "Asia/Kolkata"),
                                    "jd_exact":        round(jd_exact, 4),
                                    "days_from_now":   round(jd_exact - jd_start, 2),
                                    "transit_speed_deg_per_day": round(tp_speed, 4),
                                })
                        prev_state[key] = signed_orb_curr

    # Sort by chronological time
    upcoming.sort(key=lambda x: x["jd_exact"])

    return {
        "search_window_start":    moment_start or "now_utc",
        "search_window_days":     days_ahead,
        "step_hours":             step_hours,
        "tradition":              tradition,
        "exact_aspects_found":    upcoming,
        "count":                  len(upcoming),
        "method":                 f"Swiss Ephemeris forward-stepping at {step_hours}h intervals. Zero-crossing detection on signed aspect-orb identifies exact moments. Linear interpolation refines timing.",
        "citation":               CLASSICAL_CITATIONS["western_aspects"] + "; " + CLASSICAL_CITATIONS["swiss_eph"],
    }
