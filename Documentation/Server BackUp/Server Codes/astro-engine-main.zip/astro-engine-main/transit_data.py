"""
transit_data.py — Classical Vedic transit reference tables.

Phase C0 — Module C0 (Transit Engine).

Public catalogs:
    GOCHARA_PHALA              — Classical transit results by planet × house-from-Moon
    VEDHA_RULES                — Transit blockage rules (BPHS Ch. 41)
    SADE_SATI_PHASES           — Saturn's 7.5-year cycle structure
    JUPITER_TRANSIT_RESULTS    — House-by-house Jupiter transit per native
    SATURN_TRANSIT_RESULTS     — House-by-house Saturn transit per native
    RAHU_KETU_TRANSIT_RESULTS  — Nodal axis transit per native house
    ECLIPSE_IMPACT_ORBS        — Degrees of orb for eclipse-natal proximity
    RETROGRADE_IMPACTS         — Personal effects of retrograde periods by planet
    ASHTAKA_VARGA_BINDU_RULES  — Parashari bindu contribution tables (BPHS Ch. 67)
    BENEFIC_BINDU_THRESHOLD    — Threshold for "good" transit by AV strength

All content sourced from public-domain Sanskrit classical texts.
No copyrighted modern interpretations included.
"""

from typing import Dict, List

# ════════════════════════════════════════════════════════════════════════
# GOCHARA PHALA — Classical results by planet × house-from-natal-Moon
# Source: Phaladeepika Ch. 26, BPHS Ch. 41, Saravali Ch. 39
# Index: house number from natal Moon (1-12)
# ════════════════════════════════════════════════════════════════════════

GOCHARA_PHALA: Dict[str, Dict[int, str]] = {
    "Sun": {
        1:  "physical discomfort, restlessness, conflict with authority",
        2:  "expenses on family, harsh speech, financial pressure",
        3:  "gains through effort, success over enemies, courage",
        4:  "domestic disturbance, separation from mother-figures",
        5:  "worry about children, mental stress, ego conflicts",
        6:  "victory over enemies, recovery from illness, debts cleared",
        7:  "travel, marital friction, journeys with hardship",
        8:  "health concerns, sudden expenses, accidents possible",
        9:  "obstacles in dharma, conflict with father/guru",
        10: "professional recognition, rise in status, authority gained",
        11: "income gains, fulfillment of desires, social rise",
        12: "expenses, losses, spiritual inclination, sleep issues",
    },
    "Moon": {
        1:  "comfort, happiness, sensual pleasures, good food",
        2:  "loss of wealth, family disputes, harsh words",
        3:  "wealth gain, sibling support, courage",
        4:  "domestic happiness, comforts, vehicles, properties",
        5:  "joy from children, creative success, romance",
        6:  "minor health issues, debts may increase",
        7:  "marital joy, journeys for pleasure, partnership benefits",
        8:  "mental anxiety, fear, health issues",
        9:  "religious activities, fortunate journeys, dharmic acts",
        10: "professional honors, work recognition",
        11: "income flows, social gains, fulfillment of wishes",
        12: "expenses, indulgences, foreign travel",
    },
    "Mars": {
        1:  "injuries possible, fever, conflict, aggression",
        2:  "financial loss, harsh speech, food quality issues",
        3:  "victory, valor, courage, success over enemies",
        4:  "domestic accidents, property disputes, fire hazard",
        5:  "conflict with children, gambling losses, ego clashes",
        6:  "enemies defeated, illness recovery, lawsuits won",
        7:  "marital strife, business disputes, travel mishaps",
        8:  "accidents, surgeries, sudden setbacks, health crisis",
        9:  "religious disputes, conflict with father/guru",
        10: "career advancement through effort, leadership",
        11: "gains via effort, fulfillment through action",
        12: "expenses on conflicts, secret enemies, hidden injuries",
    },
    "Mercury": {
        1:  "intellectual stimulation, learning, communication active",
        2:  "speech-related gains, family discussions, financial talks",
        3:  "writing, short journeys, sibling matters",
        4:  "educational pursuits, real-estate documents, home learning",
        5:  "creative thinking, exams, education for children",
        6:  "service work, contracts, debt management improved",
        7:  "partnerships, business deals, contracts signed",
        8:  "research, investigation, hidden knowledge",
        9:  "publishing, higher education, philosophical study",
        10: "professional networking, status through intellect",
        11: "gains from communications, fulfilled discussions",
        12: "writing projects in seclusion, expenses on learning",
    },
    "Jupiter": {
        1:  "expansion of self, weight gain, opportunities, blessings",
        2:  "wealth gain, family expansion, knowledge of finance",
        3:  "valor with wisdom, supportive siblings, courage",
        4:  "domestic happiness, property, vehicles, mother's blessing",
        5:  "children, education success, creative blessings",
        6:  "victory in disputes, health recovery, debt clearance",
        7:  "marriage, partnerships flourish, ethical business",
        8:  "inheritance possible, transformation, deep learning",
        9:  "dharmic rise, guru's blessings, fortune, pilgrimages",
        10: "career honors, ethical advancement, recognition",
        11: "abundant gains, fulfillment of wishes, social rise",
        12: "spiritual practices, charity, foreign blessings",
    },
    "Venus": {
        1:  "physical beauty, comforts, sensual joys",
        2:  "wealth, sweet speech, family harmony, luxuries",
        3:  "creative arts, joyful expressions, sibling bonds",
        4:  "domestic luxury, vehicles, properties, mother's joy",
        5:  "romance, children, creative arts, entertainment",
        6:  "service through arts, minor health beauty issues",
        7:  "marriage joy, business in beauty/arts, partnerships",
        8:  "secret pleasures, hidden assets, occult attractions",
        9:  "fortunate marriage timing, dharmic luxury, blessings",
        10: "career in arts/luxury, fame, social honors",
        11: "abundant gains via arts/relationships, social pleasure",
        12: "expenses on luxuries, romantic indulgences, foreign",
    },
    "Saturn": {
        1:  "burden of self, slowness, depression, identity crisis",
        2:  "financial restriction, family hardship, harsh speech",
        3:  "rewards through hard effort, sibling responsibilities",
        4:  "domestic struggles, distance from mother, property work",
        5:  "delay in children, education strain, creative blocks",
        6:  "victory through perseverance, health recovery slow",
        7:  "marital responsibilities, business slowdown, separation",
        8:  "chronic illness, long delays, transformation, suffering",
        9:  "fortune delayed, dharmic discipline tested",
        10: "career rise via persistent work, hard-earned recognition",
        11: "delayed gains arriving, social position consolidates",
        12: "expenses on long obligations, monastic tendency, exile",
    },
    "Rahu": {
        1:  "identity shifts, unconventional choices, sudden change",
        2:  "speech issues, family confusion, financial gambles",
        3:  "bold initiatives, unusual siblings/communication",
        4:  "domestic unrest, mother's health, real-estate gambles",
        5:  "unusual romances, speculation gains/losses, children issues",
        6:  "unusual victories, foreign service, hidden diseases",
        7:  "unconventional partnerships, foreign spouse, business risks",
        8:  "obsessions, sudden events, occult, transformation",
        9:  "religious unconventional path, foreign teachers",
        10: "unconventional career, foreign work, sudden rise/fall",
        11: "sudden gains, foreign income, large networks",
        12: "foreign travel, hidden expenses, spiritual quest",
    },
    "Ketu": {
        1:  "detachment, identity dissolution, spiritual urges",
        2:  "indifference to wealth, speech becomes terse",
        3:  "intuitive insights, withdrawn from siblings",
        4:  "detachment from home, mother distant",
        5:  "detached from children/creativity, past-life karma",
        6:  "occult victories, mysterious illness, debts cleared",
        7:  "relationship disillusionment, business endings",
        8:  "deep occult, surgeries, hidden transformation",
        9:  "moksha urges, abandonment of conventional dharma",
        10: "career detachment, withdrawal from public life",
        11: "fewer but deeper gains, network shifts",
        12: "moksha, foreign isolation, spiritual liberation",
    },
}


# ════════════════════════════════════════════════════════════════════════
# VEDHA RULES — Transit blockage (BPHS Ch. 41)
# When a malefic occupies the "vedha" house, the benefic transit is BLOCKED.
# Format: {planet: {good_house: vedha_house_that_blocks_it}}
# Source: BPHS Ch. 41 Vedha Adhyaya, Phaladeepika Ch. 26
# ════════════════════════════════════════════════════════════════════════

VEDHA_RULES: Dict[str, Dict[int, int]] = {
    "Sun": {3: 9, 6: 12, 10: 4, 11: 5},
    "Moon": {1: 5, 3: 9, 6: 12, 7: 2, 10: 4, 11: 8},
    "Mars": {3: 12, 6: 9, 10: 4, 11: 5},
    "Mercury": {2: 5, 4: 3, 6: 9, 8: 1, 10: 8, 11: 12},
    "Jupiter": {2: 12, 5: 4, 7: 3, 9: 10, 11: 8},
    "Venus": {1: 8, 2: 7, 3: 1, 4: 10, 5: 9, 8: 5, 9: 11, 11: 6, 12: 3},
    "Saturn": {3: 12, 6: 9, 11: 5},
    "Rahu": {3: 9, 6: 12, 10: 4, 11: 5},
    "Ketu": {3: 9, 6: 12, 10: 4, 11: 5},
}


# ════════════════════════════════════════════════════════════════════════
# SADE SATI — Saturn's 7.5-year cycle through 12th, 1st, 2nd from natal Moon
# Each phase ~2.5 years (Saturn takes 2.5 years per sign on average)
# Source: Traditional Vedic literature, Phaladeepika Ch. 26
# ════════════════════════════════════════════════════════════════════════

SADE_SATI_PHASES: Dict[str, Dict[str, str]] = {
    "pre_phase": {
        "name":        "Purva Sade Sati (Rising Phase)",
        "moon_house":  "12th from natal Moon",
        "duration":    "~2.5 years",
        "domain":      "expenses, losses, foreign travel, isolation, sleep disturbance, hidden enemies",
        "psychology":  "anticipatory anxiety, fear of unknown, withdrawal from public life",
        "remediation": "Hanuman Chalisa daily, Saturn mantra (Om Shanaiscaraya Namah 108x), Saturday fasting, donate black sesame and iron",
        "do_not":      "do not initiate major new ventures, avoid risky speculation, postpone major purchases",
    },
    "peak_phase": {
        "name":        "Janma Sade Sati (Peak Phase)",
        "moon_house":  "1st (over natal Moon)",
        "duration":    "~2.5 years",
        "domain":      "physical health, mental health, identity crisis, body weakness, depression, public reputation challenges",
        "psychology":  "core identity tested, depressive episodes, slowdown of all activities, sense of burden",
        "remediation": "Mahamrityunjaya mantra, Shani temple visits on Saturdays, donations to elderly/laborers, deep meditation practice, Neelam (blue sapphire) ONLY if Saturn is yogakaraka",
        "do_not":      "do not abandon hope; this phase produces the deepest transformation; suicide ideation must be addressed clinically",
    },
    "post_phase": {
        "name":        "Uttara Sade Sati (Setting Phase)",
        "moon_house":  "2nd from natal Moon",
        "duration":    "~2.5 years",
        "domain":      "finances strained, family disputes, speech-related issues, food quality issues, eye problems possible",
        "psychology":  "exhaustion, recovery in progress, financial discipline learned, family bonds tested",
        "remediation": "donate food on Saturdays, Hanuman Chalisa, Mahalakshmi mantra for finance, control of speech, regular eye check-ups",
        "do_not":      "do not over-extend financially during recovery, do not break family bonds permanently",
    },
}


# ════════════════════════════════════════════════════════════════════════
# JUPITER TRANSIT — House-by-house results for the native
# Source: BPHS Ch. 41, Phaladeepika Ch. 26, Saravali Ch. 39
# Index: house from natal LAGNA (not Moon — more comprehensive analysis)
# ════════════════════════════════════════════════════════════════════════

JUPITER_TRANSIT_RESULTS: Dict[int, Dict[str, str]] = {
    1: {
        "house_from_lagna": "1st (Tanu Bhava)",
        "duration":         "~12 months",
        "favorable":        "weight gain, optimism, opportunities approach, blessings of teachers",
        "challenges":       "complacency, weight-related health, over-confidence",
        "best_for":         "new ventures, spiritual practice, study, teaching, marriage",
    },
    2: {
        "house_from_lagna": "2nd (Dhana Bhava)",
        "duration":         "~12 months",
        "favorable":        "wealth gain, family expansion, sweet speech, knowledge of scriptures",
        "challenges":       "over-indulgence in food, dental issues possible",
        "best_for":         "investments, family planning, learning sacred texts, voice training",
    },
    3: {
        "house_from_lagna": "3rd (Sahaja Bhava)",
        "duration":         "~12 months",
        "favorable":        "courage, supportive siblings, short journeys, writing",
        "challenges":       "scattered energy, excess effort for results",
        "best_for":         "writing projects, sibling bonding, music practice",
    },
    4: {
        "house_from_lagna": "4th (Sukha Bhava)",
        "duration":         "~12 months",
        "favorable":        "domestic peace, property acquisition, mother's wellbeing, vehicles",
        "challenges":       "expenses on home, attachment increases",
        "best_for":         "real estate, home improvements, mother-related rituals",
    },
    5: {
        "house_from_lagna": "5th (Putra Bhava)",
        "duration":         "~12 months",
        "favorable":        "children, education success, mantra practice fruitful, creative expansion",
        "challenges":       "ego inflation, attachment to creations",
        "best_for":         "education, mantra initiation, creative launches, conception",
    },
    6: {
        "house_from_lagna": "6th (Ari Bhava)",
        "duration":         "~12 months",
        "favorable":        "victory over enemies, recovery from illness, debt clearance",
        "challenges":       "may incur new debts, service-related burdens",
        "best_for":         "legal cases (winning), debt restructure, health treatments",
    },
    7: {
        "house_from_lagna": "7th (Yuvati Bhava)",
        "duration":         "~12 months",
        "favorable":        "marriage, partnership opportunities, ethical business, travels",
        "challenges":       "partner's demands increase, weight gain in marriage",
        "best_for":         "marriage, business partnerships, contracts, travel",
    },
    8: {
        "house_from_lagna": "8th (Ayur Bhava) — generally cautious",
        "duration":         "~12 months",
        "favorable":        "inheritance, occult learning, transformation, longevity studies",
        "challenges":       "hidden expenses, surgical interventions possible, chronic issues surface",
        "best_for":         "occult study, inheritance settlements, psychological work",
    },
    9: {
        "house_from_lagna": "9th (Dharma Bhava) — own house, very strong",
        "duration":         "~12 months",
        "favorable":        "fortune rises, guru's blessings, pilgrimages, dharmic learning, father's prosperity",
        "challenges":       "moral testing, philosophical conflicts",
        "best_for":         "pilgrimages, higher education, guru-seeking, ethical decisions",
    },
    10: {
        "house_from_lagna": "10th (Karma Bhava)",
        "duration":         "~12 months",
        "favorable":        "career advancement through ethics, public recognition, status rise",
        "challenges":       "responsibilities expand, ethical compromises tested",
        "best_for":         "promotion seeking, status moves, ethical leadership opportunities",
    },
    11: {
        "house_from_lagna": "11th (Labha Bhava) — most beneficial",
        "duration":         "~12 months",
        "favorable":        "abundant gains, wish fulfillment, social rise, elder siblings benefit",
        "challenges":       "over-optimism in plans",
        "best_for":         "income expansion, network building, joint ventures",
    },
    12: {
        "house_from_lagna": "12th (Vyaya Bhava)",
        "duration":         "~12 months",
        "favorable":        "spiritual progress, charity, foreign opportunities, monastic practice",
        "challenges":       "expenses balloon, sleep patterns change, isolation",
        "best_for":         "spiritual retreats, foreign settlement, charity work, moksha practices",
    },
}


# ════════════════════════════════════════════════════════════════════════
# SATURN TRANSIT — House-by-house results for the native
# Index: house from natal LAGNA
# Source: BPHS Ch. 41, Phaladeepika Ch. 26
# ════════════════════════════════════════════════════════════════════════

SATURN_TRANSIT_RESULTS: Dict[int, Dict[str, str]] = {
    1: {
        "house_from_lagna": "1st — body and identity tested",
        "duration":         "~2.5 years",
        "favorable":        "discipline strengthens, leadership earned, body endurance",
        "challenges":       "depression, weight loss, fatigue, identity reconstruction",
        "best_for":         "discipline practices, fasting (with guidance), serious meditation",
    },
    2: {
        "house_from_lagna": "2nd — finances and family disciplined",
        "duration":         "~2.5 years",
        "favorable":        "financial discipline, family obligations met, careful speech",
        "challenges":       "financial constraints, family hardship, dental work, harsh speech consequences",
        "best_for":         "financial restructuring, debt clearance, speaking less",
    },
    3: {
        "house_from_lagna": "3rd — strong, generally favorable",
        "duration":         "~2.5 years",
        "favorable":        "valor through hard work, sibling responsibilities, communication skills mature",
        "challenges":       "siblings strain, short journeys delayed",
        "best_for":         "writing, skill mastery, sibling duties, effort-based projects",
    },
    4: {
        "house_from_lagna": "4th — domestic stress, mother concerns",
        "duration":         "~2.5 years",
        "favorable":        "domestic discipline, property work, mother's care provides growth",
        "challenges":       "domestic peace lost, mother's health, property disputes, vehicle issues",
        "best_for":         "home repairs, mother care, property organization (not new purchase)",
    },
    5: {
        "house_from_lagna": "5th — children, creativity strained",
        "duration":         "~2.5 years",
        "favorable":        "discipline in creativity, mature children, serious learning",
        "challenges":       "delays in children, creative blocks, education strains, romantic delays",
        "best_for":         "structured education, mantra perseverance, child discipline",
    },
    6: {
        "house_from_lagna": "6th — strong, very favorable",
        "duration":         "~2.5 years",
        "favorable":        "victory through endurance, enemies defeated, health work pays off, debt clearance",
        "challenges":       "service burdens, chronic conditions surface",
        "best_for":         "fitness regimens, debt clearance, conflict resolution by patience",
    },
    7: {
        "house_from_lagna": "7th — marriage and partnerships tested",
        "duration":         "~2.5 years",
        "favorable":        "mature marriage, business through discipline, ethical partnerships",
        "challenges":       "separations, divorce risk, business slowdown, partner illness",
        "best_for":         "marriage repair work, partnership audit, contract review",
    },
    8: {
        "house_from_lagna": "8th — most challenging position, deep transformation",
        "duration":         "~2.5 years",
        "favorable":        "occult mastery, inheritance after struggle, longevity studies",
        "challenges":       "chronic illness, long suffering, sudden setbacks, mortality awareness",
        "best_for":         "deep psychological work, mortality acceptance, occult study",
    },
    9: {
        "house_from_lagna": "9th — dharma tested, father strain",
        "duration":         "~2.5 years",
        "favorable":        "dharmic maturity, father's lessons absorbed, philosophical depth",
        "challenges":       "father's health, fortune delayed, philosophical doubts",
        "best_for":         "spiritual discipline, ethical re-grounding, father-care",
    },
    10: {
        "house_from_lagna": "10th — own/exalted aspect, career maturation",
        "duration":         "~2.5 years",
        "favorable":        "professional rise via hard work, public responsibility, lasting reputation",
        "challenges":       "overwork, public criticism, career responsibilities multiply",
        "best_for":         "long-term career commitments, public service, leadership",
    },
    11: {
        "house_from_lagna": "11th — strong, delayed but solid gains",
        "duration":         "~2.5 years",
        "favorable":        "delayed gains materialize, elder siblings benefit, networks consolidate",
        "challenges":       "elder sibling health, over-extended commitments",
        "best_for":         "long-term investments, network consolidation, elder care",
    },
    12: {
        "house_from_lagna": "12th — expenses, isolation, spiritual",
        "duration":         "~2.5 years",
        "favorable":        "spiritual retreats, foreign work, monastic discipline, moksha urges",
        "challenges":       "expenses, isolation, sleep disturbance, foreign isolation",
        "best_for":         "spiritual retreat, foreign settlement (with planning), withdrawal from public life",
    },
}


# ════════════════════════════════════════════════════════════════════════
# RAHU-KETU TRANSIT — Nodal axis effects by Rahu's natal house
# Source: BPHS Ch. 41, Phaladeepika Ch. 26
# Note: Ketu is always 180° opposite Rahu, so we index by Rahu's house
# ════════════════════════════════════════════════════════════════════════

RAHU_KETU_TRANSIT_RESULTS: Dict[int, Dict[str, str]] = {
    1: {
        "rahu_in":     "1st (Tanu)",
        "ketu_in":     "7th (Yuvati)",
        "duration":    "~18 months",
        "rahu_effect": "identity shifts, unconventional self-expression, foreign attractions, body changes",
        "ketu_effect": "marriage indifference, partnership endings, business detachment",
        "guidance":    "embrace identity evolution; release stale partnerships; do not force marriage decisions",
    },
    2: {
        "rahu_in":     "2nd (Dhana)",
        "ketu_in":     "8th (Ayur)",
        "duration":    "~18 months",
        "rahu_effect": "unconventional income sources, foreign money, family confusion, speech issues",
        "ketu_effect": "occult insights, sudden transformations, inherited karma surfacing",
        "guidance":    "watch financial gambles; deep psychological work pays; speech carefully",
    },
    3: {
        "rahu_in":     "3rd (Sahaja)",
        "ketu_in":     "9th (Dharma)",
        "duration":    "~18 months",
        "rahu_effect": "bold ventures, unconventional siblings, communication breakthrough",
        "ketu_effect": "dharma questioned, father's health, traditional path abandoned",
        "guidance":    "trust unconventional efforts; release dogmatic beliefs; honor father",
    },
    4: {
        "rahu_in":     "4th (Sukha)",
        "ketu_in":     "10th (Karma)",
        "duration":    "~18 months",
        "rahu_effect": "foreign properties, unusual home arrangements, mother's transformation",
        "ketu_effect": "career detachment, public withdrawal, status indifference",
        "guidance":    "domestic stability is rebuilding; release career attachment temporarily",
    },
    5: {
        "rahu_in":     "5th (Putra)",
        "ketu_in":     "11th (Labha)",
        "duration":    "~18 months",
        "rahu_effect": "unusual romances, speculation gains/losses, foreign children influences",
        "ketu_effect": "income detachment, social network shrinks but deepens",
        "guidance":    "watch speculation; selectively engage networks; depth over breadth",
    },
    6: {
        "rahu_in":     "6th (Ari) — strong placement",
        "ketu_in":     "12th (Vyaya) — strong placement",
        "duration":    "~18 months",
        "rahu_effect": "victories over enemies, foreign service work, debts paid unconventionally",
        "ketu_effect": "spiritual liberation work, foreign isolation, expenses on moksha-pursuits",
        "guidance":    "this is the strongest Rahu-Ketu axis; victories ahead with karmic clarity",
    },
    7: {
        "rahu_in":     "7th (Yuvati)",
        "ketu_in":     "1st (Tanu)",
        "duration":    "~18 months",
        "rahu_effect": "unconventional partnerships, foreign spouse, business with foreigners",
        "ketu_effect": "identity dissolution, body indifference, spiritual urges in self",
        "guidance":    "partnerships transform self; allow inner detachment without dissociation",
    },
    8: {
        "rahu_in":     "8th (Ayur)",
        "ketu_in":     "2nd (Dhana)",
        "duration":    "~18 months",
        "rahu_effect": "sudden transformations, occult mastery, inheritance turbulence",
        "ketu_effect": "indifference to wealth, family detachment, terse speech",
        "guidance":    "deep transformation underway; do not force wealth accumulation now",
    },
    9: {
        "rahu_in":     "9th (Dharma)",
        "ketu_in":     "3rd (Sahaja)",
        "duration":    "~18 months",
        "rahu_effect": "foreign teachers, unconventional dharma, philosophical breakthrough",
        "ketu_effect": "withdrawn from siblings, communication terse, intuitive over rational",
        "guidance":    "embrace foreign/unconventional teachings; intuition over logic now",
    },
    10: {
        "rahu_in":     "10th (Karma)",
        "ketu_in":     "4th (Sukha)",
        "duration":    "~18 months",
        "rahu_effect": "unconventional career rise, foreign work, sudden status shifts",
        "ketu_effect": "domestic detachment, mother distance, home indifference",
        "guidance":    "career transformation; home base may shift; embrace the move",
    },
    11: {
        "rahu_in":     "11th (Labha) — strong placement",
        "ketu_in":     "5th (Putra)",
        "duration":    "~18 months",
        "rahu_effect": "sudden gains, foreign income, large unconventional networks",
        "ketu_effect": "creative detachment, children matters distant, romance indifference",
        "guidance":    "abundant gains likely; do not force creative output or romantic engagement",
    },
    12: {
        "rahu_in":     "12th (Vyaya)",
        "ketu_in":     "6th (Ari)",
        "duration":    "~18 months",
        "rahu_effect": "foreign settlement, hidden expenses, spiritual quest, sleep issues",
        "ketu_effect": "service detachment, enemies dissolve, illness surfacing for clearing",
        "guidance":    "spiritual quest deepens; allow enemies and illnesses to clear naturally",
    },
}


# ════════════════════════════════════════════════════════════════════════
# ECLIPSE IMPACT ORBS — degrees of orb for considering eclipse proximity
# An eclipse "hits" a natal point if eclipse degree is within these orbs
# Source: classical eclipse astrology, Brihat Samhita Ch. 5
# ════════════════════════════════════════════════════════════════════════

ECLIPSE_IMPACT_ORBS: Dict[str, float] = {
    "exact":      1.0,   # within 1 degree = direct hit
    "strong":     3.0,   # within 3 degrees = strong impact
    "moderate":   5.0,   # within 5 degrees = moderate impact
    "weak":      10.0,   # within 10 degrees = mild impact (whole-sign approach)
}


# ════════════════════════════════════════════════════════════════════════
# RETROGRADE PERSONAL IMPACTS — by planet, classical
# Source: Phaladeepika, Saravali, BPHS Ch. 41
# ════════════════════════════════════════════════════════════════════════

RETROGRADE_IMPACTS: Dict[str, Dict[str, str]] = {
    "Mercury": {
        "duration":  "~3 weeks, 3 times per year",
        "domain":    "communication, contracts, travel, technology, siblings",
        "favorable": "review and revise existing projects, re-connect with old contacts, edit and refine",
        "challenges":"miscommunications, contract disputes, technology failures, travel delays",
        "guidance":  "re-, re-, re- (revise, review, reconnect); avoid initiating new contracts or major purchases",
    },
    "Venus": {
        "duration":  "~40 days, every 18 months",
        "domain":    "relationships, finances, art, beauty, comfort",
        "favorable": "reassess relationships, revisit creative work, financial review",
        "challenges":"old lovers return, value reassessment, financial reversal possible",
        "guidance":  "review relationships and finances; avoid major beauty procedures or new partnerships",
    },
    "Mars": {
        "duration":  "~80 days, every 2 years",
        "domain":    "energy, action, conflict, surgery, drive",
        "favorable": "reconsider conflicts, finish old projects, internal courage building",
        "challenges":"frustration, accidents possible, energy depletion, surgery complications",
        "guidance":  "do not initiate conflicts or major surgeries; channel energy inward",
    },
    "Jupiter": {
        "duration":  "~4 months, annually",
        "domain":    "wisdom, growth, optimism, dharma",
        "favorable": "deepen study, re-examine beliefs, spiritual retreat, internal expansion",
        "challenges":"over-optimism corrected, philosophical doubts, expansion stalls",
        "guidance":  "deepen inward; avoid taking on new commitments unconsciously",
    },
    "Saturn": {
        "duration":  "~4.5 months, annually",
        "domain":    "discipline, structure, responsibility, karma",
        "favorable": "internal discipline, karmic review, structural reconsideration",
        "challenges":"old karmic burdens revisit, structures questioned, depression possible",
        "guidance":  "internal discipline strengthens; avoid quitting major responsibilities reactively",
    },
}


# ════════════════════════════════════════════════════════════════════════
# ASHTAKA VARGA BINDU RULES — Parashari classical
# For each "reference point" (7 planets + Lagna), each "transiting planet"
# gets a bindu (1 point) when it occupies the listed signs-from-reference.
# Source: BPHS Ch. 67 (Ashtakavarga Adhyaya), Phaladeepika Ch. 27
#
# Format: { transit_planet: { reference_point: [list of houses-from-reference] } }
# Each transit planet has 8 reference points → max 8 bindus per sign
# ════════════════════════════════════════════════════════════════════════

ASHTAKA_VARGA_BINDU_RULES: Dict[str, Dict[str, List[int]]] = {
    "Sun": {
        "Sun":     [1, 2, 4, 7, 8, 9, 10, 11],
        "Moon":    [3, 6, 10, 11],
        "Mars":    [1, 2, 4, 7, 8, 9, 10, 11],
        "Mercury": [3, 5, 6, 9, 10, 11, 12],
        "Jupiter": [5, 6, 9, 11],
        "Venus":   [6, 7, 12],
        "Saturn":  [1, 2, 4, 7, 8, 9, 10, 11],
        "Lagna":   [3, 4, 6, 10, 11, 12],
    },
    "Moon": {
        "Sun":     [3, 6, 7, 8, 10, 11],
        "Moon":    [1, 3, 6, 7, 10, 11],
        "Mars":    [2, 3, 5, 6, 9, 10, 11],
        "Mercury": [1, 3, 4, 5, 7, 8, 10, 11],
        "Jupiter": [1, 4, 7, 8, 10, 11, 12],
        "Venus":   [3, 4, 5, 7, 9, 10, 11],
        "Saturn":  [3, 5, 6, 11],
        "Lagna":   [3, 6, 10, 11],
    },
    "Mars": {
        "Sun":     [3, 5, 6, 10, 11],
        "Moon":    [3, 6, 11],
        "Mars":    [1, 2, 4, 7, 8, 10, 11],
        "Mercury": [3, 5, 6, 11],
        "Jupiter": [6, 10, 11, 12],
        "Venus":   [6, 8, 11, 12],
        "Saturn":  [1, 4, 7, 8, 9, 10, 11],
        "Lagna":   [1, 3, 6, 10, 11],
    },
    "Mercury": {
        "Sun":     [5, 6, 9, 11, 12],
        "Moon":    [2, 4, 6, 8, 10, 11],
        "Mars":    [1, 2, 4, 7, 8, 9, 10, 11],
        "Mercury": [1, 3, 5, 6, 9, 10, 11, 12],
        "Jupiter": [6, 8, 11, 12],
        "Venus":   [1, 2, 3, 4, 5, 8, 9, 11],
        "Saturn":  [1, 2, 4, 7, 8, 9, 10, 11],
        "Lagna":   [1, 2, 4, 6, 8, 10, 11],
    },
    "Jupiter": {
        "Sun":     [1, 2, 3, 4, 7, 8, 9, 10, 11],
        "Moon":    [2, 5, 7, 9, 11],
        "Mars":    [1, 2, 4, 7, 8, 10, 11],
        "Mercury": [1, 2, 4, 5, 6, 9, 10, 11],
        "Jupiter": [1, 2, 3, 4, 7, 8, 10, 11],
        "Venus":   [2, 5, 6, 9, 10, 11],
        "Saturn":  [3, 5, 6, 12],
        "Lagna":   [1, 2, 4, 5, 6, 7, 9, 10, 11],
    },
    "Venus": {
        "Sun":     [8, 11, 12],
        "Moon":    [1, 2, 3, 4, 5, 8, 9, 11, 12],
        "Mars":    [3, 5, 6, 9, 11, 12],
        "Mercury": [3, 5, 6, 9, 11],
        "Jupiter": [5, 8, 9, 10, 11],
        "Venus":   [1, 2, 3, 4, 5, 8, 9, 10, 11],
        "Saturn":  [3, 4, 5, 8, 9, 10, 11],
        "Lagna":   [1, 2, 3, 4, 5, 8, 9, 11],
    },
    "Saturn": {
        "Sun":     [1, 2, 4, 7, 8, 10, 11],
        "Moon":    [3, 6, 11],
        "Mars":    [3, 5, 6, 10, 11, 12],
        "Mercury": [6, 8, 9, 10, 11, 12],
        "Jupiter": [5, 6, 11, 12],
        "Venus":   [6, 11, 12],
        "Saturn":  [3, 5, 6, 11],
        "Lagna":   [1, 3, 4, 6, 10, 11],
    },
}


# Bindu thresholds (Parashari standard)
BENEFIC_BINDU_THRESHOLD: int = 4   # >= 4 bindus = beneficial transit
STRONG_BINDU_THRESHOLD: int = 6    # >= 6 bindus = strong beneficial transit
WEAK_BINDU_THRESHOLD: int = 2      # <= 2 bindus = transit lacks supportive strength


# ════════════════════════════════════════════════════════════════════════
# MAJOR TRANSIT EVENT WINDOWS — for 12-month forecast
# Average sign-change cadence per planet (classical)
# ════════════════════════════════════════════════════════════════════════

PLANET_SIGN_CHANGE_CADENCE: Dict[str, str] = {
    "Sun":     "~30 days per sign",
    "Moon":    "~2.25 days per sign",
    "Mars":    "~45 days per sign (longer when retrograde)",
    "Mercury": "~25 days per sign (variable with retrograde)",
    "Jupiter": "~12 months per sign",
    "Venus":   "~25 days per sign (variable with retrograde)",
    "Saturn":  "~2.5 years per sign",
    "Rahu":    "~18 months per sign (always retrograde)",
    "Ketu":    "~18 months per sign (always retrograde)",
}


# Major event categories used by transit/major_alerts_12months endpoint
MAJOR_EVENT_TYPES: List[str] = [
    "jupiter_sign_change",
    "saturn_sign_change",
    "rahu_ketu_axis_change",
    "sade_sati_phase_transition",
    "eclipse_near_natal",
    "retrograde_period_start",
    "major_transit_through_lagna",
]


# ════════════════════════════════════════════════════════════════════════
# CITATIONS — for output transparency
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "gochara_phala":     "Phaladeepika Ch. 26 (Gochara Phala); BPHS Ch. 41 (Gochara Adhyaya); Saravali Ch. 39",
    "vedha_rules":       "BPHS Ch. 41 (Vedha Adhyaya); Phaladeepika Ch. 26",
    "sade_sati":         "Traditional Vedic literature on Saturn's 7.5-year cycle; Phaladeepika Ch. 26",
    "jupiter_transit":   "BPHS Ch. 41; Phaladeepika Ch. 26; Saravali Ch. 39",
    "saturn_transit":    "BPHS Ch. 41; Phaladeepika Ch. 26; Saravali Ch. 39",
    "rahu_ketu_transit": "BPHS Ch. 41; Phaladeepika Ch. 26",
    "eclipses":          "Brihat Samhita Ch. 5 (eclipse chapters); classical eclipse astrology",
    "ashtaka_varga":     "BPHS Ch. 67 (Ashtakavarga Adhyaya); Phaladeepika Ch. 27",
    "retrogrades":       "Phaladeepika; Saravali; BPHS Ch. 41",
}
