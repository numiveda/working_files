"""
family_karma.py — numiVeda Kaaliyo Astro Engine — Module F7 (Family Tree Karma)

Five endpoints for multi-generational karmic synthesis. F7 is a synthesis
layer on top of existing single-chart modules (pitra_dosha, karmic,
children_education) — it does NOT re-implement single-chart astrology
already present in the engine.

    handle_family_patterns       — Cross-chart pattern detection: shared
                                   afflictions, transmitted/broken yogas
    handle_ancestral_strengths   — 4th (mother) / 9th (father) / 12th
                                   (ancestral karma) deep dive with optional
                                   cross-chart overlay
    handle_lineage_yogas         — Classical multi-generation yoga catalog:
                                   Pitri Doshatma combinations, Matri Dosha,
                                   inherited Putra-Pitri yogas
    handle_karaka_inheritance    — Jaimini karaka comparison across charts:
                                   what continued vs. shifted (AK, AmK, MK,
                                   PiK, PuK across self + parents)
    handle_dasha_lineage         — Cross-chart dasha overlap analysis: when
                                   inherited karma activates in self's
                                   timeline relative to parents' periods

Design (reuse-first per HANDOVER_v7 Section 8.1 + S3 user instruction):
    P1 — All astronomy through cast_chart (dashaflow).
    P2 — Reuse: F7 imports and calls:
         * pitra_dosha.handle_pitra_dosha_intensity   (signature counting)
         * pitra_dosha.handle_pitra_dosha_profile     (single-chart profile)
         * karmic.handle_ketu_past_life               (past-life karma)
         * karmic.handle_rahu_forward_karma           (forward karma)
         * karmic.handle_twelfth_house_moksha         (12th house karma)
         * karmic.handle_atmakaraka_journey           (soul path)
         * karmic.extract_chart_essentials            (helper)
         * children_education.handle_putra_dosha      (children-line)
         * children_education.handle_5th_house_analysis
         * chart["jaimini_karakas"], chart["dashas"], chart["yogas"]
    P5 — F7 has its own KARAKA_INHERITANCE_INTERPRETATIONS, LINEAGE_YOGA_CATALOG,
         DASHA_OVERLAP_THRESHOLDS, F7_CITATIONS. Combinator logic only.

Input convention:
    Multi-chart endpoints accept `self_birth` (required) +
    optional `mother_birth`, `father_birth`, `paternal_grandfather_birth`,
    `maternal_grandfather_birth`. Each is a {dob, time, lat, lon, timezone}
    dict (HTTP-layer uses StrictBirthInput; module just expects dicts).

    Missing optional charts simply reduce the depth of the synthesis;
    the endpoint never errors on missing ancestors, it just notes "data
    not provided" in the relevant analysis section.

Public API:
    handle_family_patterns(self_birth, mother_birth=None, father_birth=None,
                           paternal_grandfather_birth=None,
                           maternal_grandfather_birth=None) -> dict
    handle_ancestral_strengths(self_birth, mother_birth=None,
                               father_birth=None) -> dict
    handle_lineage_yogas(self_birth, mother_birth=None,
                         father_birth=None) -> dict
    handle_karaka_inheritance(self_birth, mother_birth=None,
                              father_birth=None,
                              paternal_grandfather_birth=None,
                              maternal_grandfather_birth=None) -> dict
    handle_dasha_lineage(self_birth, mother_birth=None,
                         father_birth=None, lookahead_years=20) -> dict

Author: Claude (F7, 2026-05-18)
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import date, datetime, timedelta


# Foundation imports (guarded — Principle 1) ─────────────────────────────────
try:
    from dashaflow import cast_chart
except ImportError as e:
    raise ImportError(f"F7 family_karma requires dashaflow.cast_chart: {e}")

try:
    from astro_helpers import SIGNS_ORDER, SIGN_TO_LORD
except ImportError as e:
    raise ImportError(f"F7 family_karma requires astro_helpers: {e}")


# Reuse-first imports — pitra_dosha (F2b), karmic, children_education
# Soft-imported so F7 degrades gracefully if any source module changes.
try:
    from pitra_dosha import (
        handle_pitra_dosha_intensity   as _pd_intensity,
        handle_pitra_dosha_profile     as _pd_profile,
    )
    _PD_AVAILABLE = True
except ImportError:
    _pd_intensity = _pd_profile = None
    _PD_AVAILABLE = False

try:
    from karmic import (
        handle_ketu_past_life          as _km_ketu_past,
        handle_rahu_forward_karma      as _km_rahu_forward,
        handle_twelfth_house_moksha    as _km_12th_moksha,
        handle_atmakaraka_journey      as _km_ak_journey,
        handle_kaal_sarpa              as _km_kaal_sarpa,
    )
    _KARMIC_AVAILABLE = True
except ImportError:
    _km_ketu_past = _km_rahu_forward = _km_12th_moksha = None
    _km_ak_journey = _km_kaal_sarpa = None
    _KARMIC_AVAILABLE = False

try:
    from children_education import (
        handle_putra_dosha             as _ce_putra_dosha,
        handle_5th_house_analysis      as _ce_5th_house,
    )
    _CE_AVAILABLE = True
except ImportError:
    _ce_putra_dosha = _ce_5th_house = None
    _CE_AVAILABLE = False


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL TABLES
# ════════════════════════════════════════════════════════════════════════

# Karaka → role mapping for cross-chart inheritance analysis.
# Source: Jaimini Sutras Ch. 2; Maharishi Parashara BPHS Ch. 32 (karakas).
KARAKA_ROLES: Dict[str, str] = {
    "Atmakaraka":    "Soul / supreme life purpose",
    "Amatyakaraka":  "Career / minister / livelihood",
    "Bhratrikaraka": "Siblings / courage / initiative",
    "Matrikaraka":   "Mother / formal education / emotional comfort",
    "Putrakaraka":   "Children / intelligence / past-life merit (purva punya)",
    "Gnatikaraka":   "Enemies / obstacles / chronic patterns",
    "Darakaraka":    "Spouse / partnership",
}

# When the SAME karaka planet appears across generations, classical
# interpretation: that life-domain karma "continues" or "is transmitted".
# When DIFFERENT, the soul work has shifted.
KARAKA_INHERITANCE_INTERPRETATIONS: Dict[str, str] = {
    "continued":   ("Karaka planet matches between generations — the soul "
                    "work in this domain continues / transmits across lineage. "
                    "Classical interpretation: shared karmic theme to refine."),
    "shifted":     ("Karaka planet differs — the soul work in this domain "
                    "has redirected. Classical interpretation: new karmic "
                    "territory introduced in the younger chart."),
    "intensified": ("Same karaka with higher degree in younger chart — "
                    "classical interpretation: the karma has intensified "
                    "for resolution in this generation."),
    "released":    ("Same karaka with significantly lower degree in younger "
                    "chart — classical interpretation: the karma has eased; "
                    "the parent generation carried the harder portion."),
}


# Lineage-specific yoga catalog. These are multi-chart-meaningful yogas
# beyond what chart["yogas"] catalogs (which are single-chart).
# Sources: BPHS Ch. 32 (karaka yogas), Phaladeepika Ch. 13 (santana yogas),
# Jataka Parijata Ch. 5 (parents), Saravali Ch. 23 (lineage).
LINEAGE_YOGA_CATALOG: Dict[str, Dict[str, Any]] = {
    "pitri_continuity": {
        "name": "Pitri Continuity Yoga",
        "trigger": "Father's AK and child's 9th lord are same planet",
        "classical_source": "Jaimini Upadesha Sutras Ch. 2; BPHS Ch. 32",
        "interpretation": "The father's soul-work continues through the "
                          "child's dharmic line. Strong classical indicator "
                          "of ancestral blessings flowing forward.",
    },
    "matri_continuity": {
        "name": "Matri Continuity Yoga",
        "trigger": "Mother's AK or 4th lord and child's Moon are same planet",
        "classical_source": "BPHS Ch. 32; Phaladeepika Ch. 13",
        "interpretation": "The mother's emotional/foundational karma flows "
                          "to the child. Strong nurturing line indicator.",
    },
    "pitri_rupture": {
        "name": "Pitri Rupture Yoga",
        "trigger": "Parent has strong Pitra Dosha AND child's 9th lord "
                   "in dusthana (6/8/12)",
        "classical_source": "BPHS Ch. 32; Brihat Samhita Ch. 49",
        "interpretation": "Inherited ancestral affliction unresolved in "
                          "parent's lifetime. Classical Garuda Purana "
                          "shanti practices strongly indicated.",
    },
    "matri_rupture": {
        "name": "Matri Rupture Yoga",
        "trigger": "Mother's Moon afflicted (combust/debilitated/in dusthana) "
                   "AND child's 4th lord similarly afflicted",
        "classical_source": "Phaladeepika Ch. 13; Jataka Parijata Ch. 5",
        "interpretation": "Maternal lineage emotional karma transmitted "
                          "incompletely. Classical Devi/Lakshmi worship "
                          "by the daughter or son indicated.",
    },
    "putra_pitri_inherited": {
        "name": "Inherited Putra-Pitri Yoga",
        "trigger": "Child has Putra Dosha AND parent had/has Pitra Dosha",
        "classical_source": "Phaladeepika Ch. 13; Garuda Purana",
        "interpretation": "Children-line and ancestors-line afflictions "
                          "coexist across two generations. Multi-generation "
                          "Garbha Shanti + Pitra Shanti both classically "
                          "advised.",
    },
    "kuladevi_activation": {
        "name": "Kuladevi Activation Yoga",
        "trigger": "Child's 9th lord in own/exalted AND parent's 4th lord "
                   "in own/exalted",
        "classical_source": "Brahma Vaivarta Purana; family-deity tradition",
        "interpretation": "Lineage's family deity (Kuladevi/Kuladeva) "
                          "actively supporting both generations. Classical "
                          "family-tradition rituals carry full benefit.",
    },
    "rahu_lineage_shift": {
        "name": "Rahu Lineage Shift Yoga",
        "trigger": "Child's Rahu in 4th/9th/10th AND parent's Rahu in "
                   "different house",
        "classical_source": "Saravali Ch. 23; modern Vedic interpretation",
        "interpretation": "Family karmic trajectory is shifting in the "
                          "child's generation — outgrowing lineage patterns "
                          "or migrating geographically/culturally.",
    },
    "ketu_ancestral_release": {
        "name": "Ketu Ancestral Release Yoga",
        "trigger": "Child's Ketu in 9th house AND parent had Ketu in "
                   "dusthana",
        "classical_source": "Saravali Ch. 23; Jaimini Sutras",
        "interpretation": "The child's chart is classically releasing the "
                          "ancestral karma that the parent could not. "
                          "Strong moksha line indicator.",
    },
}

# Significant dasha overlap thresholds for endpoint 5
DASHA_OVERLAP_THRESHOLDS: Dict[str, Any] = {
    "min_overlap_days":  90,        # minimum overlap to flag as significant
    "lookahead_years":   20,        # default forward window from today
    "lookback_years":    50,        # for parent's past relevant periods
    "significant_planets": ["Sun", "Moon", "Mars", "Mercury",
                            "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"],
}


# ════════════════════════════════════════════════════════════════════════
# CITATIONS + DISCLAIMERS
# ════════════════════════════════════════════════════════════════════════

F7_CITATIONS: Dict[str, List[str]] = {
    "family_patterns": [
        "Parashara, BPHS, Ch. 32 (Karaka chapter — multi-chart application)",
        "Jaimini Upadesha Sutras, Ch. 2 (karaka inheritance)",
        "Phaladeepika, Ch. 13 (parents and lineage)",
        "B.V. Raman, Astrology in Predicting Weather and Earthquakes, "
        "applied principles for family analysis (1992)",
    ],
    "ancestral_strengths": [
        "Parashara, BPHS, Ch. 24 (Pitra Bhava — 9th house)",
        "BPHS, Ch. 22 (Matr Bhava — 4th house)",
        "BPHS, Ch. 27 (Vyaya Bhava — 12th house, ancestral karma)",
        "Garuda Purana (Pretakhanda — ancestral karma transmission)",
    ],
    "lineage_yogas": [
        "Jaimini Upadesha Sutras (Ch. 2, karaka yogas)",
        "Phaladeepika, Ch. 13 (parents and progeny yogas)",
        "Saravali, Ch. 23 (lineage yogas)",
        "Brahma Vaivarta Purana, Kula tradition sections",
    ],
    "karaka_inheritance": [
        "Jaimini Upadesha Sutras, Ch. 2 (sapta karakas)",
        "Parashara, BPHS, Ch. 32 (karaka assignments and meaning)",
        "Sanjay Rath, Crux of Vedic Astrology (modern karaka-lineage "
        "interpretation, 2002)",
    ],
    "dasha_lineage": [
        "Parashara, BPHS, Ch. 46-52 (Vimshottari dasha framework)",
        "Phaladeepika, Ch. 26 (dasha applications)",
        "Classical principle: 'Dasha activates karma; lineage karma "
        "activates when the lord of inherited yoga is in dasha.'",
    ],
}


F7_DISCLAIMER = (
    "Classical Vedic family-karma analysis per Parashara/Jaimini lineage "
    "principles. This is a scholarly/contemplative output describing "
    "classical karmic patterns, NOT a medical, psychological, or family-"
    "counseling tool. Output is most useful for understanding inherited "
    "spiritual patterns and choosing classical remedies; it should not be "
    "used to attribute family difficulties to specific individuals or "
    "events. Always continue any prescribed professional care."
)


# ════════════════════════════════════════════════════════════════════════
# INTERNAL HELPERS
# ════════════════════════════════════════════════════════════════════════

def _cast_or_error(birth: Optional[Dict[str, Any]],
                   context: str) -> Optional[Dict[str, Any]]:
    """Cast a chart or return None if input is None; error dict on failure."""
    if birth is None:
        return None
    try:
        return cast_chart(
            dob=birth["dob"], time=birth["time"],
            lat=birth["lat"], lon=birth["lon"],
            timezone=birth.get("timezone", "Asia/Kolkata"),
        )
    except Exception as e:
        return {"_error": f"Chart cast failed ({context}): {e}"}


def _safe_call(handler: Optional[Any], birth: Optional[Dict[str, Any]],
               handler_name: str) -> Dict[str, Any]:
    """
    Safely invoke a reused single-chart handler. Returns:
        {"available": False, "reason": ...} if handler unavailable or no birth
        {"available": True, "data": <handler output>} on success
        {"available": True, "error": ...} on exception
    """
    if handler is None:
        return {"available": False,
                "reason": f"{handler_name} module not importable"}
    if birth is None:
        return {"available": False,
                "reason": "birth data not provided"}
    try:
        return {"available": True, "data": handler(birth)}
    except Exception as e:
        return {"available": True, "error": str(e),
                "handler": handler_name}


def _house_lord(house_num: int, chart: Dict[str, Any]) -> Optional[str]:
    """Lord of the sign occupying house N from lagna."""
    if not chart or "_error" in chart:
        return None
    lagna_sign = chart.get("lagna", {}).get("sign")
    if not lagna_sign or lagna_sign not in SIGNS_ORDER:
        return None
    idx = SIGNS_ORDER.index(lagna_sign)
    return SIGN_TO_LORD.get(SIGNS_ORDER[(idx + house_num - 1) % 12])


def _planet_in_dusthana(planet: str, chart: Dict[str, Any]) -> bool:
    if not chart or "_error" in chart:
        return False
    return chart.get("planets", {}).get(planet, {}).get("house") in (6, 8, 12)


def _planet_dignified(planet: str, chart: Dict[str, Any]) -> bool:
    if not chart or "_error" in chart:
        return False
    d = (chart.get("planets", {}).get(planet, {}).get("dignity") or "").lower()
    return d in {"exalted", "mooltrikona", "own_sign", "great_friend"}


def _planet_afflicted(planet: str, chart: Dict[str, Any]) -> bool:
    if not chart or "_error" in chart:
        return False
    p = chart.get("planets", {}).get(planet, {})
    d = (p.get("dignity") or "").lower()
    if d in {"debilitated", "great_enemy"}:
        return True
    if d == "enemy" and p.get("is_combust"):
        return True
    return False


def _karaka_planet(chart: Dict[str, Any], karaka_name: str) -> Optional[str]:
    """Read the planet for a given karaka from chart["jaimini_karakas"]."""
    if not chart or "_error" in chart:
        return None
    k = chart.get("jaimini_karakas", {}).get(karaka_name, {})
    if isinstance(k, dict):
        return k.get("planet")
    return None


def _karaka_data(chart: Dict[str, Any], karaka_name: str) -> Optional[Dict[str, Any]]:
    if not chart or "_error" in chart:
        return None
    k = chart.get("jaimini_karakas", {}).get(karaka_name)
    return k if isinstance(k, dict) else None


def _classify_karaka_inheritance(self_data: Optional[Dict[str, Any]],
                                 parent_data: Optional[Dict[str, Any]]
                                 ) -> Tuple[str, str]:
    """Returns (classification, reason_string)."""
    if not self_data or not parent_data:
        return ("incomplete", "parent or self karaka data missing")
    self_planet = self_data.get("planet")
    parent_planet = parent_data.get("planet")
    if self_planet == parent_planet:
        # Same karaka — check degree shift
        self_deg = self_data.get("degree", 0)
        parent_deg = parent_data.get("degree", 0)
        if isinstance(self_deg, (int, float)) and isinstance(parent_deg, (int, float)):
            diff = self_deg - parent_deg
            if diff > 5:
                return ("intensified",
                        f"Same karaka {self_planet}; child's degree "
                        f"{self_deg:.2f}° vs parent's {parent_deg:.2f}° "
                        "(intensified)")
            if diff < -5:
                return ("released",
                        f"Same karaka {self_planet}; child's degree "
                        f"{self_deg:.2f}° vs parent's {parent_deg:.2f}° "
                        "(released)")
        return ("continued",
                f"Same karaka planet {self_planet} across generations")
    return ("shifted",
            f"Child's karaka {self_planet}, parent's was {parent_planet}")


def _filter_mundane_yogas(chart: Dict[str, Any],
                          relevant: set) -> List[Dict[str, Any]]:
    """Filter chart['yogas'] (a list) for those in `relevant` set."""
    if not chart or "_error" in chart:
        return []
    out: List[Dict[str, Any]] = []
    for y in chart.get("yogas", []) or []:
        if isinstance(y, dict) and y.get("name") in relevant:
            out.append(y)
    return out


def _current_dasha(chart: Dict[str, Any]) -> Dict[str, Any]:
    if not chart or "_error" in chart:
        return {}
    d = chart.get("dashas", {}) or {}
    return {
        "mahadasha":   d.get("maha"),
        "antardasha":  d.get("antar"),
        "pratyantar":  d.get("pratyantar"),
    }


def _dasha_periods(chart: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract MD periods from chart dashas for cross-chart timing analysis.
    Returns list of {planet, from, to} dicts at the maha level.
    Note: cast_chart returns the CURRENT MD/AD/PD; for full period list
    we read from dashas dict at runtime — if multiple periods present.
    """
    if not chart or "_error" in chart:
        return []
    d = chart.get("dashas", {}) or {}
    # cast_chart returns one current period per level. To get the full series,
    # we'd need to recompute from chart["dashas"]["all_maha"] if exposed.
    # Conservative: return what we have, single current period.
    out: List[Dict[str, Any]] = []
    maha = d.get("maha")
    if isinstance(maha, dict):
        out.append({
            "level":  "maha",
            "planet": maha.get("planet"),
            "from":   maha.get("from"),
            "to":     maha.get("to"),
        })
    # If we have "all_maha" or similar list, use it
    for key in ("all_maha", "maha_periods", "mahadashas"):
        all_md = d.get(key)
        if isinstance(all_md, list):
            for m in all_md:
                if isinstance(m, dict):
                    out.append({
                        "level":  "maha",
                        "planet": m.get("planet") or m.get("lord"),
                        "from":   m.get("from") or m.get("start"),
                        "to":     m.get("to") or m.get("end"),
                    })
            break
    return out


def _parse_iso(d: Optional[str]) -> Optional[date]:
    if not d:
        return None
    try:
        return datetime.strptime(str(d)[:10], "%Y-%m-%d").date()
    except Exception:
        return None


def _periods_overlap(p1_from: Optional[date], p1_to: Optional[date],
                     p2_from: Optional[date], p2_to: Optional[date]
                     ) -> Optional[Dict[str, Any]]:
    """Return overlap descriptor or None if no overlap / data missing."""
    if not all((p1_from, p1_to, p2_from, p2_to)):
        return None
    start = max(p1_from, p2_from)
    end = min(p1_to, p2_to)
    if start > end:
        return None
    return {
        "start":      start.isoformat(),
        "end":        end.isoformat(),
        "days":       (end - start).days,
    }


# ════════════════════════════════════════════════════════════════════════
# PUBLIC API — 5 ENDPOINTS
# ════════════════════════════════════════════════════════════════════════

def handle_family_patterns(self_birth: Dict[str, Any],
                           mother_birth: Optional[Dict[str, Any]] = None,
                           father_birth: Optional[Dict[str, Any]] = None,
                           paternal_grandfather_birth: Optional[Dict[str, Any]] = None,
                           maternal_grandfather_birth: Optional[Dict[str, Any]] = None
                           ) -> Dict[str, Any]:
    """
    F7 Endpoint 1: Multi-chart pattern detection.

    Calls existing pitra_dosha + karmic + children_education handlers on each
    provided chart, then surfaces:
        - Shared affliction signatures (Pitra Dosha across generations)
        - Putra-Pitri inherited combinations
        - 12th house ancestral karma transmission patterns
        - Ketu past-life themes that recur across generations
    """
    self_chart = _cast_or_error(self_birth, "self")
    if self_chart and "_error" in self_chart:
        return {"error": self_chart["_error"],
                "classical_sources": F7_CITATIONS["family_patterns"],
                "disclaimer": F7_DISCLAIMER}

    # Per-chart results using REUSED handlers (no recomputation)
    self_pitra_intensity = _safe_call(_pd_intensity, self_birth, "pitra_dosha.intensity")
    self_putra_dosha     = _safe_call(_ce_putra_dosha, self_birth, "children_education.putra_dosha")
    self_ketu_past       = _safe_call(_km_ketu_past, self_birth, "karmic.ketu_past_life")
    self_12th_moksha     = _safe_call(_km_12th_moksha, self_birth, "karmic.twelfth_house_moksha")

    parents_analysis: Dict[str, Any] = {}
    for label, birth in [("mother", mother_birth), ("father", father_birth),
                         ("paternal_grandfather", paternal_grandfather_birth),
                         ("maternal_grandfather", maternal_grandfather_birth)]:
        if birth is None:
            parents_analysis[label] = {"provided": False}
            continue
        parents_analysis[label] = {
            "provided":         True,
            "pitra_intensity":  _safe_call(_pd_intensity, birth, "pitra_dosha.intensity"),
            "putra_dosha":      _safe_call(_ce_putra_dosha, birth, "children_education.putra_dosha"),
            "ketu_past_life":   _safe_call(_km_ketu_past, birth, "karmic.ketu_past_life"),
        }

    # Cross-chart pattern synthesis
    patterns_detected: List[Dict[str, Any]] = []

    # Pattern A: Pitra Dosha signature count shared across generations
    def _signature_count(intensity_result: Dict[str, Any]) -> Optional[int]:
        if not intensity_result.get("available"):
            return None
        d = intensity_result.get("data") or {}
        # Per U13 refactor, intensity returns signatures_present_count
        return d.get("signatures_present_count")

    self_pitra_count = _signature_count(self_pitra_intensity)
    if self_pitra_count is not None and self_pitra_count >= 2:
        for label in ("mother", "father", "paternal_grandfather", "maternal_grandfather"):
            p = parents_analysis.get(label, {})
            if p.get("provided"):
                parent_count = _signature_count(p.get("pitra_intensity") or {})
                if parent_count is not None and parent_count >= 2:
                    patterns_detected.append({
                        "pattern":     "transmitted_pitra_affliction",
                        "lineage":     label,
                        "self_count":  self_pitra_count,
                        "parent_count": parent_count,
                        "interpretation": (f"Pitra Dosha signatures present in "
                                           f"both self ({self_pitra_count}) and "
                                           f"{label} ({parent_count}) — classical "
                                           "transmission pattern. Garuda Purana "
                                           "Shanti practices indicated."),
                    })

    # Pattern B: Inherited Putra-Pitri yoga
    def _has_putra_affliction(putra_result: Dict[str, Any]) -> bool:
        if not putra_result.get("available"):
            return False
        d = putra_result.get("data") or {}
        # putra_dosha endpoint returns verdict; afflicted if not "no_putra_dosha"
        v = d.get("verdict", "")
        if isinstance(v, str) and v and "no" not in v.lower():
            return True
        # Or check for a count/score
        return bool(d.get("dosha_present"))

    self_has_putra = _has_putra_affliction(self_putra_dosha)
    if self_has_putra:
        for label in ("mother", "father"):
            p = parents_analysis.get(label, {})
            if p.get("provided"):
                parent_pitra_count = _signature_count(p.get("pitra_intensity") or {})
                if parent_pitra_count is not None and parent_pitra_count >= 2:
                    patterns_detected.append({
                        "pattern":     "putra_pitri_inherited",
                        "lineage":     label,
                        "interpretation": (
                            f"Self has Putra Dosha indicators AND {label} carries "
                            "Pitra Dosha — classical Putra-Pitri inherited yoga. "
                            "Multi-generation Garbha Shanti + Pitra Shanti both "
                            "classically advised."),
                        "classical_source": LINEAGE_YOGA_CATALOG["putra_pitri_inherited"]["classical_source"],
                    })

    return {
        "self_analysis": {
            "lagna":            self_chart.get("lagna") if self_chart else None,
            "pitra_intensity":  self_pitra_intensity,
            "putra_dosha":      self_putra_dosha,
            "ketu_past_life":   self_ketu_past,
            "twelfth_moksha":   self_12th_moksha,
        },
        "parents_analysis":     parents_analysis,
        "cross_generation_patterns": patterns_detected,
        "patterns_count":       len(patterns_detected),
        "modules_status": {
            "pitra_dosha":         _PD_AVAILABLE,
            "karmic":              _KARMIC_AVAILABLE,
            "children_education":  _CE_AVAILABLE,
        },
        "classical_sources":    F7_CITATIONS["family_patterns"],
        "disclaimer":           F7_DISCLAIMER,
    }


def handle_ancestral_strengths(self_birth: Dict[str, Any],
                               mother_birth: Optional[Dict[str, Any]] = None,
                               father_birth: Optional[Dict[str, Any]] = None
                               ) -> Dict[str, Any]:
    """
    F7 Endpoint 2: Deep dive on 4th (mother lineage), 9th (father lineage),
    12th (ancestral karma) for self chart, with optional cross-chart overlay
    from parent charts.

    Reuses karmic.handle_twelfth_house_moksha and pitra_dosha.profile.
    """
    self_chart = _cast_or_error(self_birth, "self")
    if self_chart and "_error" in self_chart:
        return {"error": self_chart["_error"],
                "classical_sources": F7_CITATIONS["ancestral_strengths"],
                "disclaimer": F7_DISCLAIMER}

    fourth_lord = _house_lord(4, self_chart) if self_chart else None
    ninth_lord  = _house_lord(9, self_chart) if self_chart else None

    fourth_lord_state = None
    ninth_lord_state = None
    if self_chart and fourth_lord:
        p = self_chart.get("planets", {}).get(fourth_lord, {})
        fourth_lord_state = {
            "planet":        fourth_lord,
            "sign":          p.get("sign"),
            "house":         p.get("house"),
            "dignity":       p.get("dignity"),
            "in_dusthana":   _planet_in_dusthana(fourth_lord, self_chart),
            "dignified":     _planet_dignified(fourth_lord, self_chart),
            "afflicted":     _planet_afflicted(fourth_lord, self_chart),
        }
    if self_chart and ninth_lord:
        p = self_chart.get("planets", {}).get(ninth_lord, {})
        ninth_lord_state = {
            "planet":        ninth_lord,
            "sign":          p.get("sign"),
            "house":         p.get("house"),
            "dignity":       p.get("dignity"),
            "in_dusthana":   _planet_in_dusthana(ninth_lord, self_chart),
            "dignified":     _planet_dignified(ninth_lord, self_chart),
            "afflicted":     _planet_afflicted(ninth_lord, self_chart),
        }

    # Reused single-chart deep analyses
    self_12th_analysis = _safe_call(_km_12th_moksha, self_birth, "karmic.twelfth_house_moksha")
    self_pitra_profile = _safe_call(_pd_profile, self_birth, "pitra_dosha.profile")

    # Cross-chart overlay
    mother_overlay = None
    if mother_birth:
        mother_chart = _cast_or_error(mother_birth, "mother")
        if mother_chart and "_error" not in mother_chart:
            mother_moon_house = mother_chart.get("planets", {}).get("Moon", {}).get("house")
            mother_4th_lord = _house_lord(4, mother_chart)
            mother_overlay = {
                "mother_moon_house":   mother_moon_house,
                "mother_4th_lord":     mother_4th_lord,
                "mother_4th_lord_afflicted": (
                    _planet_afflicted(mother_4th_lord, mother_chart)
                    if mother_4th_lord else None
                ),
                "transmission_note":   (
                    "Mother's 4th lord state classically transmits to child's "
                    "4th house karma. Both afflicted = matri-rupture pattern; "
                    "both dignified = matri-continuity."
                ),
            }

    father_overlay = None
    if father_birth:
        father_chart = _cast_or_error(father_birth, "father")
        if father_chart and "_error" not in father_chart:
            father_sun_house = father_chart.get("planets", {}).get("Sun", {}).get("house")
            father_9th_lord = _house_lord(9, father_chart)
            father_pitra = _safe_call(_pd_intensity, father_birth, "pitra_dosha.intensity")
            father_overlay = {
                "father_sun_house":    father_sun_house,
                "father_9th_lord":     father_9th_lord,
                "father_9th_lord_afflicted": (
                    _planet_afflicted(father_9th_lord, father_chart)
                    if father_9th_lord else None
                ),
                "father_pitra_signatures": father_pitra,
                "transmission_note":   (
                    "Father's 9th lord state and Pitra signatures classically "
                    "transmit to child's dharma/lineage karma. Father afflicted "
                    "+ child afflicted = pitri-rupture; both dignified = "
                    "pitri-continuity."
                ),
            }

    return {
        "self_lagna":              self_chart.get("lagna") if self_chart else None,
        "fourth_house_mother":     {
            "lord":  fourth_lord,
            "state": fourth_lord_state,
        },
        "ninth_house_father":      {
            "lord":  ninth_lord,
            "state": ninth_lord_state,
        },
        "twelfth_house_ancestral_karma": self_12th_analysis,
        "self_pitra_profile":      self_pitra_profile,
        "mother_chart_overlay":    mother_overlay,
        "father_chart_overlay":    father_overlay,
        "classical_sources":       F7_CITATIONS["ancestral_strengths"],
        "disclaimer":              F7_DISCLAIMER,
    }


def handle_lineage_yogas(self_birth: Dict[str, Any],
                         mother_birth: Optional[Dict[str, Any]] = None,
                         father_birth: Optional[Dict[str, Any]] = None
                         ) -> Dict[str, Any]:
    """
    F7 Endpoint 3: Detect classical lineage-specific yogas across charts.
    """
    self_chart = _cast_or_error(self_birth, "self")
    if self_chart and "_error" in self_chart:
        return {"error": self_chart["_error"],
                "classical_sources": F7_CITATIONS["lineage_yogas"],
                "disclaimer": F7_DISCLAIMER}

    mother_chart = _cast_or_error(mother_birth, "mother") if mother_birth else None
    father_chart = _cast_or_error(father_birth, "father") if father_birth else None

    yogas_found: List[Dict[str, Any]] = []

    # Pitri Continuity: father's AK == child's 9th lord
    if father_chart and "_error" not in father_chart:
        father_ak = _karaka_planet(father_chart, "Atmakaraka")
        child_9th_lord = _house_lord(9, self_chart)
        if father_ak and child_9th_lord and father_ak == child_9th_lord:
            yogas_found.append({
                **LINEAGE_YOGA_CATALOG["pitri_continuity"],
                "details": f"Father's AK = {father_ak} = child's 9th lord",
            })

    # Matri Continuity: mother's AK or 4th lord == child's Moon
    if mother_chart and "_error" not in mother_chart:
        mother_ak = _karaka_planet(mother_chart, "Atmakaraka")
        mother_4th_lord = _house_lord(4, mother_chart)
        child_moon = "Moon"  # child's Moon planet itself
        # Classical reading: mother's AK = Moon (literal) OR mother's 4th lord = Moon
        if mother_ak == "Moon" or mother_4th_lord == "Moon":
            yogas_found.append({
                **LINEAGE_YOGA_CATALOG["matri_continuity"],
                "details": (f"Mother's AK={mother_ak}, 4th lord="
                            f"{mother_4th_lord}; Moon connection present"),
            })

    # Pitri Rupture: parent has Pitra Dosha AND child 9th lord in dusthana
    child_9th_lord = _house_lord(9, self_chart)
    child_9th_in_dusthana = (_planet_in_dusthana(child_9th_lord, self_chart)
                              if child_9th_lord else False)
    if child_9th_in_dusthana and father_birth:
        father_pitra = _safe_call(_pd_intensity, father_birth,
                                   "pitra_dosha.intensity")
        if father_pitra.get("available"):
            count = (father_pitra.get("data") or {}).get("signatures_present_count", 0)
            if isinstance(count, int) and count >= 2:
                yogas_found.append({
                    **LINEAGE_YOGA_CATALOG["pitri_rupture"],
                    "details": (f"Father's Pitra signatures: {count}; "
                                f"child's 9th lord {child_9th_lord} in dusthana"),
                })

    # Matri Rupture: mother's Moon afflicted AND child's 4th lord afflicted
    if mother_chart and "_error" not in mother_chart:
        mother_moon_afflicted = _planet_afflicted("Moon", mother_chart)
        child_4th_lord = _house_lord(4, self_chart)
        child_4th_afflicted = (_planet_afflicted(child_4th_lord, self_chart)
                                if child_4th_lord else False)
        if mother_moon_afflicted and child_4th_afflicted:
            yogas_found.append({
                **LINEAGE_YOGA_CATALOG["matri_rupture"],
                "details": (f"Mother's Moon afflicted; child's 4th lord "
                            f"{child_4th_lord} afflicted"),
            })

    # Putra-Pitri inherited
    if father_birth:
        self_putra_aff = _safe_call(_ce_putra_dosha, self_birth,
                                     "children_education.putra_dosha")
        father_pitra = _safe_call(_pd_intensity, father_birth,
                                   "pitra_dosha.intensity")
        if (self_putra_aff.get("available") and father_pitra.get("available")):
            s_d = self_putra_aff.get("data") or {}
            f_d = father_pitra.get("data") or {}
            s_verdict = (s_d.get("verdict") or "").lower()
            f_count = f_d.get("signatures_present_count") or 0
            if ("no" not in s_verdict and s_verdict and
                isinstance(f_count, int) and f_count >= 2):
                yogas_found.append({
                    **LINEAGE_YOGA_CATALOG["putra_pitri_inherited"],
                    "details": (f"Self Putra verdict: {s_verdict}; "
                                f"father Pitra signatures: {f_count}"),
                })

    # Kuladevi activation: child 9th lord dignified AND parent 4th lord dignified
    child_9th_dignified = (_planet_dignified(child_9th_lord, self_chart)
                            if child_9th_lord else False)
    for plabel, pchart in [("mother", mother_chart), ("father", father_chart)]:
        if pchart and "_error" not in pchart:
            p_4th_lord = _house_lord(4, pchart)
            if p_4th_lord and _planet_dignified(p_4th_lord, pchart) and child_9th_dignified:
                yogas_found.append({
                    **LINEAGE_YOGA_CATALOG["kuladevi_activation"],
                    "details": (f"{plabel}'s 4th lord {p_4th_lord} dignified; "
                                f"child's 9th lord {child_9th_lord} dignified"),
                })

    # Rahu lineage shift: child's Rahu in 4/9/10 AND parent's Rahu in different house
    child_rahu_house = self_chart.get("planets", {}).get("Rahu", {}).get("house")
    if child_rahu_house in (4, 9, 10):
        for plabel, pchart in [("mother", mother_chart), ("father", father_chart)]:
            if pchart and "_error" not in pchart:
                p_rahu_house = pchart.get("planets", {}).get("Rahu", {}).get("house")
                if p_rahu_house and p_rahu_house != child_rahu_house:
                    yogas_found.append({
                        **LINEAGE_YOGA_CATALOG["rahu_lineage_shift"],
                        "details": (f"Child Rahu in {child_rahu_house}, "
                                    f"{plabel}'s Rahu in {p_rahu_house}"),
                    })
                    break  # one parent suffices

    # Ketu ancestral release
    child_ketu_house = self_chart.get("planets", {}).get("Ketu", {}).get("house")
    if child_ketu_house == 9:
        for plabel, pchart in [("mother", mother_chart), ("father", father_chart)]:
            if pchart and "_error" not in pchart:
                p_ketu_house = pchart.get("planets", {}).get("Ketu", {}).get("house")
                if p_ketu_house in (6, 8, 12):
                    yogas_found.append({
                        **LINEAGE_YOGA_CATALOG["ketu_ancestral_release"],
                        "details": (f"Child Ketu in 9th (release); "
                                    f"{plabel}'s Ketu in {p_ketu_house} (dusthana)"),
                    })
                    break

    return {
        "self_lagna":           self_chart.get("lagna") if self_chart else None,
        "lineage_yogas_found":  yogas_found,
        "yogas_count":          len(yogas_found),
        "mother_chart_provided": mother_birth is not None,
        "father_chart_provided": father_birth is not None,
        "yoga_catalog_evaluated": list(LINEAGE_YOGA_CATALOG.keys()),
        "classical_sources":    F7_CITATIONS["lineage_yogas"],
        "disclaimer":           F7_DISCLAIMER,
    }


def handle_karaka_inheritance(self_birth: Dict[str, Any],
                              mother_birth: Optional[Dict[str, Any]] = None,
                              father_birth: Optional[Dict[str, Any]] = None,
                              paternal_grandfather_birth: Optional[Dict[str, Any]] = None,
                              maternal_grandfather_birth: Optional[Dict[str, Any]] = None
                              ) -> Dict[str, Any]:
    """
    F7 Endpoint 4: Jaimini karaka comparison across generations.

    For each of the 7 karakas, compare self vs. each provided ancestor:
    same planet (continued/intensified/released) or different (shifted).
    """
    self_chart = _cast_or_error(self_birth, "self")
    if self_chart and "_error" in self_chart:
        return {"error": self_chart["_error"],
                "classical_sources": F7_CITATIONS["karaka_inheritance"],
                "disclaimer": F7_DISCLAIMER}

    parent_charts: Dict[str, Optional[Dict[str, Any]]] = {}
    for label, birth in [("mother", mother_birth), ("father", father_birth),
                         ("paternal_grandfather", paternal_grandfather_birth),
                         ("maternal_grandfather", maternal_grandfather_birth)]:
        c = _cast_or_error(birth, label) if birth else None
        if c and "_error" in c:
            c = None  # quietly drop a parent that failed to cast
        parent_charts[label] = c

    # Self karakas
    self_karakas = {k: _karaka_data(self_chart, k) for k in KARAKA_ROLES.keys()}

    # Cross-chart comparisons
    inheritance_map: Dict[str, Dict[str, Any]] = {}
    for karaka_name, karaka_role in KARAKA_ROLES.items():
        self_k = self_karakas.get(karaka_name)
        per_ancestor: Dict[str, Any] = {}
        for label, pchart in parent_charts.items():
            if pchart is None:
                per_ancestor[label] = {"provided": False}
                continue
            parent_k = _karaka_data(pchart, karaka_name)
            classification, reason = _classify_karaka_inheritance(self_k, parent_k)
            per_ancestor[label] = {
                "provided":           True,
                "parent_karaka":      parent_k,
                "classification":     classification,
                "reason":             reason,
                "interpretation":     KARAKA_INHERITANCE_INTERPRETATIONS.get(
                    classification, "incomplete data"
                ),
            }
        inheritance_map[karaka_name] = {
            "role":          karaka_role,
            "self_karaka":   self_k,
            "across_ancestors": per_ancestor,
        }

    # Summary: which karakas continued vs shifted across the most ancestors
    summary: Dict[str, int] = {"continued": 0, "shifted": 0,
                               "intensified": 0, "released": 0,
                               "incomplete": 0}
    for karaka_name, data in inheritance_map.items():
        for label, info in data["across_ancestors"].items():
            cls = info.get("classification")
            if cls in summary:
                summary[cls] += 1

    return {
        "self_lagna":            self_chart.get("lagna") if self_chart else None,
        "karaka_inheritance_map": inheritance_map,
        "classifications_summary": summary,
        "ancestors_evaluated":   [k for k, v in parent_charts.items() if v is not None],
        "classical_sources":     F7_CITATIONS["karaka_inheritance"],
        "disclaimer":            F7_DISCLAIMER,
    }


def handle_dasha_lineage(self_birth: Dict[str, Any],
                         mother_birth: Optional[Dict[str, Any]] = None,
                         father_birth: Optional[Dict[str, Any]] = None,
                         lookahead_years: int = 20) -> Dict[str, Any]:
    """
    F7 Endpoint 5: Cross-chart dasha overlap analysis.

    Looks at self's current/upcoming MDs and parents' running MDs to find
    significant overlaps where inherited karma classically activates.

    NOTE: cast_chart returns the CURRENT MD at the time of the cast. Full
    dasha-period series may or may not be exposed; F7 reads what's available.
    """
    if not isinstance(lookahead_years, int) or lookahead_years < 1 or lookahead_years > 50:
        lookahead_years = DASHA_OVERLAP_THRESHOLDS["lookahead_years"]

    self_chart = _cast_or_error(self_birth, "self")
    if self_chart and "_error" in self_chart:
        return {"error": self_chart["_error"],
                "classical_sources": F7_CITATIONS["dasha_lineage"],
                "disclaimer": F7_DISCLAIMER}

    self_current = _current_dasha(self_chart)
    self_periods = _dasha_periods(self_chart)

    overlaps: List[Dict[str, Any]] = []

    for plabel, pbirth in [("mother", mother_birth), ("father", father_birth)]:
        if pbirth is None:
            continue
        pchart = _cast_or_error(pbirth, plabel)
        if not pchart or "_error" in pchart:
            continue
        parent_current = _current_dasha(pchart)
        parent_periods = _dasha_periods(pchart)

        # Same-planet MD overlap: a strong classical activator of inherited karma
        for sp in self_periods:
            for pp in parent_periods:
                if sp.get("planet") and sp.get("planet") == pp.get("planet"):
                    s_from = _parse_iso(sp.get("from"))
                    s_to   = _parse_iso(sp.get("to"))
                    p_from = _parse_iso(pp.get("from"))
                    p_to   = _parse_iso(pp.get("to"))
                    ov = _periods_overlap(s_from, s_to, p_from, p_to)
                    if ov and ov["days"] >= DASHA_OVERLAP_THRESHOLDS["min_overlap_days"]:
                        overlaps.append({
                            "type":      "same_planet_md_overlap",
                            "lineage":   plabel,
                            "planet":    sp.get("planet"),
                            "self_md":   {"from": sp.get("from"), "to": sp.get("to")},
                            "parent_md": {"from": pp.get("from"), "to": pp.get("to")},
                            "overlap":   ov,
                            "interpretation": (
                                f"Both you and your {plabel} share/shared "
                                f"{sp.get('planet')} Mahadasha during this period "
                                f"({ov['days']} days). Classical activation "
                                "window for inherited karma in this planet's domain."
                            ),
                        })

    # Truncate to top 10 most-significant overlaps if many
    overlaps_sorted = sorted(overlaps, key=lambda o: o["overlap"]["days"], reverse=True)[:10]

    return {
        "self_current_dasha":    self_current,
        "self_periods_available": len(self_periods),
        "cross_generation_overlaps": overlaps_sorted,
        "overlaps_count":        len(overlaps_sorted),
        "lookahead_years":       lookahead_years,
        "note":                  (
            "cast_chart returns the current dasha period at the time of cast. "
            "Full historical/future MD list may not be available for all charts; "
            "F7 surfaces what's accessible. For comprehensive timing analysis, "
            "call /astro/dasha or /astro/varshaphala/dasha_for_year separately."
        ),
        "classical_sources":     F7_CITATIONS["dasha_lineage"],
        "disclaimer":            F7_DISCLAIMER,
    }


# ════════════════════════════════════════════════════════════════════════
# F7 module marker — used by patch installer for idempotency check
# ════════════════════════════════════════════════════════════════════════
F7_MODULE_VERSION = "1.0.0"
F7_MODULE_MARKER  = "F7_FAMILY_KARMA_2026_05_18"
