"""
panchang_data.py — Vedic Panchang (calendar) reference tables.

Phase C — Module C4 (Daily Panchang).

Public catalogs:
    RAHU_KALAM_SEGMENT          — Which of 8 day-segments contains Rahu kalam, per weekday
    YAMA_GANDAM_SEGMENT         — Which segment contains Yama Gandam, per weekday
    GULIKA_KALAM_SEGMENT        — Which segment contains Gulika kalam, per weekday
    NAKSHATRA_LORDS             — 27 nakshatras → ruling planet
    YOGA_NAMES                  — 27 yogas in classical order
    YOGA_FAVORABILITY           — auspicious/inauspicious per yoga
    KARANA_NAMES                — 11 karanas (7 movable + 4 fixed)
    KARANA_FAVORABILITY
    TITHI_NAMES                 — 30 tithi names (Shukla + Krishna paksha)
    CLASSICAL_CITATIONS

Sources: BPHS Ch. 99 (Panchang Adhyaya), classical Panchang construction
tradition (universal Vedic), Brihat Samhita.
All public domain.
"""

from typing import Dict, List


# ════════════════════════════════════════════════════════════════════════
# RAHU KALAM / YAMA GANDAM / GULIKA KALAM
# Day from sunrise to sunset is divided into 8 equal parts.
# Each weekday has Rahu/Yama/Gulika sitting in specific 1-of-8 segment.
# Source: classical Panchang tradition; Muhurta Chintamani.
# Index: Python weekday (Monday=0..Sunday=6); value: 0-based segment (0=first 1/8)
# ════════════════════════════════════════════════════════════════════════

RAHU_KALAM_SEGMENT: Dict[int, int] = {
    0: 1,  # Monday    — 2nd segment (7:30-9:00 AM if sunrise 6am)
    1: 6,  # Tuesday   — 7th segment
    2: 3,  # Wednesday — 4th segment
    3: 4,  # Thursday  — 5th segment
    4: 2,  # Friday    — 3rd segment
    5: 0,  # Saturday  — 1st segment (right after sunrise — most strict)
    6: 7,  # Sunday    — 8th segment
}

YAMA_GANDAM_SEGMENT: Dict[int, int] = {
    0: 3,  # Monday    — 4th segment
    1: 2,  # Tuesday   — 3rd segment
    2: 1,  # Wednesday — 2nd segment
    3: 0,  # Thursday  — 1st segment
    4: 6,  # Friday    — 7th segment
    5: 5,  # Saturday  — 6th segment
    6: 4,  # Sunday    — 5th segment
}

GULIKA_KALAM_SEGMENT: Dict[int, int] = {
    0: 5,  # Monday    — 6th segment
    1: 4,  # Tuesday   — 5th segment
    2: 3,  # Wednesday — 4th segment
    3: 2,  # Thursday  — 3rd segment
    4: 1,  # Friday    — 2nd segment
    5: 0,  # Saturday  — 1st segment
    6: 6,  # Sunday    — 7th segment
}

DAY_NAMES: Dict[int, str] = {
    0: "Monday", 1: "Tuesday", 2: "Wednesday", 3: "Thursday",
    4: "Friday", 5: "Saturday", 6: "Sunday",
}

DAY_PLANET: Dict[int, str] = {
    0: "Moon", 1: "Mars", 2: "Mercury", 3: "Jupiter",
    4: "Venus", 5: "Saturn", 6: "Sun",
}


# ════════════════════════════════════════════════════════════════════════
# NAKSHATRA LORDS — 27 nakshatras + ruling planet (Vimshottari order)
# ════════════════════════════════════════════════════════════════════════

NAKSHATRA_LORDS: Dict[str, str] = {
    "Ashwini": "Ketu",          "Bharani": "Venus",       "Krittika": "Sun",
    "Rohini": "Moon",           "Mrigashira": "Mars",     "Ardra": "Rahu",
    "Punarvasu": "Jupiter",     "Pushya": "Saturn",       "Ashlesha": "Mercury",
    "Magha": "Ketu",            "Purva Phalguni": "Venus","Uttara Phalguni": "Sun",
    "Hasta": "Moon",            "Chitra": "Mars",         "Swati": "Rahu",
    "Vishakha": "Jupiter",      "Anuradha": "Saturn",     "Jyeshtha": "Mercury",
    "Mula": "Ketu",             "Purva Ashadha": "Venus", "Uttara Ashadha": "Sun",
    "Shravana": "Moon",         "Dhanishta": "Mars",      "Shatabhisha": "Rahu",
    "Purva Bhadrapada": "Jupiter","Uttara Bhadrapada": "Saturn","Revati": "Mercury",
}


# ════════════════════════════════════════════════════════════════════════
# YOGA NAMES — 27 yogas (each 13°20' of Sun+Moon longitude sum)
# Source: Classical Panchang
# ════════════════════════════════════════════════════════════════════════

YOGA_NAMES: List[str] = [
    "Vishkambha", "Priti", "Ayushman", "Saubhagya", "Shobhana",
    "Atiganda", "Sukarma", "Dhriti", "Shoola", "Ganda",
    "Vriddhi", "Dhruva", "Vyaghata", "Harshana", "Vajra",
    "Siddhi", "Vyatipata", "Variyana", "Parigha", "Shiva",
    "Siddha", "Sadhya", "Shubha", "Shukla", "Brahma",
    "Indra", "Vaidhriti",
]

# Auspiciousness scoring (classical) — 27 yogas
# Inauspicious: Vishkambha, Atiganda, Shoola, Ganda, Vyaghata, Vajra,
#               Vyatipata, Parigha, Vaidhriti
YOGA_FAVORABILITY: Dict[str, str] = {
    "Vishkambha": "inauspicious",  "Priti": "auspicious",     "Ayushman": "auspicious",
    "Saubhagya": "auspicious",     "Shobhana": "auspicious",  "Atiganda": "inauspicious",
    "Sukarma": "auspicious",       "Dhriti": "auspicious",    "Shoola": "inauspicious",
    "Ganda": "inauspicious",       "Vriddhi": "auspicious",   "Dhruva": "auspicious",
    "Vyaghata": "inauspicious",    "Harshana": "auspicious",  "Vajra": "inauspicious",
    "Siddhi": "auspicious",        "Vyatipata": "inauspicious","Variyana": "auspicious",
    "Parigha": "inauspicious",     "Shiva": "auspicious",     "Siddha": "auspicious",
    "Sadhya": "auspicious",        "Shubha": "auspicious",    "Shukla": "auspicious",
    "Brahma": "auspicious",        "Indra": "auspicious",     "Vaidhriti": "inauspicious",
}


# ════════════════════════════════════════════════════════════════════════
# KARANA NAMES — 11 karanas (7 movable cycle through, 4 fixed)
# Source: Classical Panchang
# ════════════════════════════════════════════════════════════════════════

KARANA_MOVABLE: List[str] = [
    "Bava", "Balava", "Kaulava", "Taitila",
    "Gara", "Vanija", "Vishti",  # Vishti = Bhadra (avoid!)
]

KARANA_FIXED: List[str] = [
    "Shakuni",       # 30th half-tithi (2nd half of Krishna Chaturdashi)
    "Chatushpada",   # 30th-2nd half (Amavasya 1st half)
    "Naga",          # Amavasya 2nd half
    "Kintughna",     # Shukla Pratipada 1st half
]

KARANA_FAVORABILITY: Dict[str, str] = {
    "Bava":     "auspicious",  "Balava":   "auspicious",
    "Kaulava":  "auspicious",  "Taitila":  "auspicious",
    "Gara":     "auspicious",  "Vanija":   "auspicious",
    "Vishti":   "inauspicious_bhadra",  # Bhadra Karana — avoid for new ventures
    "Shakuni":  "neutral",     "Chatushpada":"neutral",
    "Naga":     "neutral",     "Kintughna":"auspicious",
}


# ════════════════════════════════════════════════════════════════════════
# TITHI NAMES — 30 tithis
# ════════════════════════════════════════════════════════════════════════

TITHI_NAMES: Dict[int, str] = {
    1:  "Shukla Pratipada", 2:  "Shukla Dwitiya",   3:  "Shukla Tritiya",
    4:  "Shukla Chaturthi", 5:  "Shukla Panchami",  6:  "Shukla Shashthi",
    7:  "Shukla Saptami",   8:  "Shukla Ashtami",   9:  "Shukla Navami",
    10: "Shukla Dashami",   11: "Shukla Ekadashi",  12: "Shukla Dwadashi",
    13: "Shukla Trayodashi",14: "Shukla Chaturdashi",15:"Purnima",
    16: "Krishna Pratipada",17: "Krishna Dwitiya",  18: "Krishna Tritiya",
    19: "Krishna Chaturthi",20: "Krishna Panchami", 21: "Krishna Shashthi",
    22: "Krishna Saptami",  23: "Krishna Ashtami",  24: "Krishna Navami",
    25: "Krishna Dashami",  26: "Krishna Ekadashi", 27: "Krishna Dwadashi",
    28: "Krishna Trayodashi",29:"Krishna Chaturdashi",30:"Amavasya",
}


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "panchang":      "BPHS Ch. 99 (Panchang Adhyaya); classical Vedic calendar tradition",
    "tithi":         "BPHS; Surya Siddhanta on lunar phases",
    "nakshatra":     "BPHS Ch. 28; Krishnamurti Paddhati on nakshatra lords",
    "yoga":          "Classical Panchang; Muhurta Chintamani",
    "karana":        "Classical Panchang construction; BPHS",
    "rahu_kalam":    "Classical Panchang time-band tradition; Muhurta Chintamani",
    "sunrise_calc":  "NOAA solar position algorithm (public domain); accurate to ~1 minute",
}
