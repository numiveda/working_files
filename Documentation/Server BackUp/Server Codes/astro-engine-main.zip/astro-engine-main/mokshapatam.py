"""
mokshapatam.py — numiVeda Kaaliyo Astro Engine — Module E2.

Moksha Patam analysis engine. Receives a completed journey from the client
and returns deterministic karmic analysis. Pure function.

Architecture: client owns game loop (dice rolls, animation, age tracking).
Engine owns the math (chakra analysis, cumulative pattern, narrative, chart data).

9 endpoints:
    handle_profile             — MASTER: all analysis + narrative + chart + prompt context
    handle_board_catalog       — All 72 houses with attributes
    handle_chakra_catalog      — 8 chakras with themes
    handle_past_life_weight    — Phase 1 roll count → karma label
    handle_chakra_analysis     — Per-chakra time/virtue/vice breakdown
    handle_cumulative_pattern  — Dominant snake/ladder, trajectory, karmic label
    handle_journey_narrative   — Text narrative for AI consumption
    handle_chart_data          — 3 visualization panels
    handle_validate_journey    — Verify journey is structurally valid

Journey input shape (from client):
    {
      "phase1_roll_count": int,
      "end_condition": "house_68" | "age_80",
      "final_house": int,
      "final_age": int,
      "total_rolls": int,
      "journey": [
        {
          "roll_number": int,
          "dice": int (1-6),
          "age_before": int,
          "age_after": int,
          "house_after": int,
          "snake_hit": bool,
          "snake_from": int | None,
          "snake_to": int | None,
          "ladder_hit": bool,
          "ladder_from": int | None,
          "ladder_to": int | None,
        }, ...
      ]
    }
"""

from typing import Dict, List, Optional, Any

from mokshapatam_data import (
    BOARD,
    CHAKRA_ROWS,
    CHAKRA_ORDER,
    CHAKRA_SHORT,
    PAST_LIFE_WEIGHT_RULES,
    END_CONDITIONS,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# PAST LIFE WEIGHT LOOKUP
# ════════════════════════════════════════════════════════════════════════

def _get_past_life_weight(count: int) -> Dict[str, str]:
    """Phase 1 roll count → karma label per classical thresholds."""
    for rule in PAST_LIFE_WEIGHT_RULES:
        if rule["min_count"] <= count <= rule["max_count"]:
            return {"label": rule["label"], "text": rule["text"]}
    # Fallback (should never reach due to max_count=999 on last rule)
    return {"label": "heavy", "text": PAST_LIFE_WEIGHT_RULES[-1]["text"]}


# ════════════════════════════════════════════════════════════════════════
# CHAKRA ANALYSIS — Per-chakra breakdown of journey
# ════════════════════════════════════════════════════════════════════════

def _compute_chakra_analysis(journey: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """
    For each chakra, compute:
      - years_spent, rolls in that chakra
      - virtue/vice/neutral roll counts and percentages
      - entry_age (first arrival in chakra), exit_age (last roll there)
      - snakes_hit (snakes landed in that chakra)
      - ladders_climbed (ladders landed in that chakra)
      - dominant_quality (virtue / vice / balanced)
      - board_virtue_pct / board_vice_pct (theoretical from catalog)
    """
    analysis: Dict[str, Dict[str, Any]] = {}
    for chakra in CHAKRA_ORDER:
        cr = CHAKRA_ROWS[chakra]
        analysis[chakra] = {
            "name":              cr["name"],
            "plane":             cr["plane"],
            "years_spent":       0,
            "rolls":             0,
            "virtue_rolls":      0,
            "vice_rolls":        0,
            "neutral_rolls":     0,
            "virtue_pct":        0,
            "vice_pct":          0,
            "neutral_pct":       0,
            "dominant_quality":  None,
            "snakes_hit":        [],
            "ladders_climbed":   [],
            "entry_age":         None,
            "exit_age":          None,
            "board_virtue_pct":  round(cr["virtue_count"]  / 9 * 100),
            "board_vice_pct":    round(cr["vice_count"]    / 9 * 100),
            "board_neutral_pct": round(cr["neutral_count"] / 9 * 100),
        }

    for roll in journey:
        house_after = roll.get("house_after")
        if not house_after or house_after not in BOARD:
            continue
        house = BOARD[house_after]
        chakra = house["chakra"]
        c = analysis[chakra]
        years = roll.get("age_after", 0) - roll.get("age_before", 0)

        c["years_spent"] += years
        c["rolls"] += 1
        if c["entry_age"] is None:
            c["entry_age"] = roll.get("age_before")
        c["exit_age"] = roll.get("age_after")

        if house["type"] == "virtue":
            c["virtue_rolls"] += 1
        elif house["type"] == "vice":
            c["vice_rolls"] += 1
        elif house["type"] == "neutral":
            c["neutral_rolls"] += 1

        if roll.get("snake_hit"):
            from_h = roll.get("snake_from")
            to_h = roll.get("snake_to")
            c["snakes_hit"].append({
                "from":      from_h,
                "to":        to_h,
                "from_name": BOARD.get(from_h, {}).get("name") if from_h else None,
                "to_name":   BOARD.get(to_h, {}).get("name") if to_h else None,
                "age":       roll.get("age_after"),
            })

        if roll.get("ladder_hit"):
            from_h = roll.get("ladder_from")
            to_h = roll.get("ladder_to")
            c["ladders_climbed"].append({
                "from":      from_h,
                "to":        to_h,
                "from_name": BOARD.get(from_h, {}).get("name") if from_h else None,
                "to_name":   BOARD.get(to_h, {}).get("name") if to_h else None,
                "age":       roll.get("age_after"),
            })

    # Compute percentages and dominant quality
    for chakra in CHAKRA_ORDER:
        c = analysis[chakra]
        if c["rolls"] > 0:
            c["virtue_pct"]  = round(c["virtue_rolls"]  / c["rolls"] * 100)
            c["vice_pct"]    = round(c["vice_rolls"]    / c["rolls"] * 100)
            c["neutral_pct"] = round(c["neutral_rolls"] / c["rolls"] * 100)
        if c["virtue_pct"] > c["vice_pct"] + 10:
            c["dominant_quality"] = "virtue"
        elif c["vice_pct"] > c["virtue_pct"] + 10:
            c["dominant_quality"] = "vice"
        else:
            c["dominant_quality"] = "balanced"

    return analysis


# ════════════════════════════════════════════════════════════════════════
# CUMULATIVE PATTERN — Dominant patterns, trajectory, karmic label
# ════════════════════════════════════════════════════════════════════════

def _compute_cumulative_pattern(
    journey: List[Dict[str, Any]],
    phase1_roll_count: int,
    end_condition: str,
    final_house: int,
) -> Dict[str, Any]:
    """
    Compute dominant recurring vice (most-hit snake), dominant recurring virtue
    (most-climbed ladder), net trajectory, chakra of most time, and the
    classical karmic label string.
    """
    snake_counts: Dict[str, Dict[str, Any]] = {}
    ladder_counts: Dict[str, Dict[str, Any]] = {}

    for roll in journey:
        if roll.get("snake_hit"):
            from_h = roll.get("snake_from")
            to_h = roll.get("snake_to")
            key = f"{from_h}→{to_h}"
            if key not in snake_counts:
                snake_counts[key] = {
                    "count":     0,
                    "ages":      [],
                    "from":      from_h,
                    "to":        to_h,
                    "from_name": BOARD.get(from_h, {}).get("name") if from_h else None,
                    "to_name":   BOARD.get(to_h, {}).get("name") if to_h else None,
                }
            snake_counts[key]["count"] += 1
            snake_counts[key]["ages"].append(roll.get("age_after"))

        if roll.get("ladder_hit"):
            from_h = roll.get("ladder_from")
            to_h = roll.get("ladder_to")
            key = f"{from_h}→{to_h}"
            if key not in ladder_counts:
                ladder_counts[key] = {
                    "count":     0,
                    "ages":      [],
                    "from":      from_h,
                    "to":        to_h,
                    "from_name": BOARD.get(from_h, {}).get("name") if from_h else None,
                    "to_name":   BOARD.get(to_h, {}).get("name") if to_h else None,
                }
            ladder_counts[key]["count"] += 1
            ladder_counts[key]["ages"].append(roll.get("age_after"))

    snake_list = sorted(snake_counts.values(), key=lambda s: s["count"], reverse=True)
    ladder_list = sorted(ladder_counts.values(), key=lambda l: l["count"], reverse=True)

    dominant_snake = snake_list[0] if snake_list else None
    dominant_ladder = ladder_list[0] if ladder_list else None

    total_snakes = sum(v["count"] for v in snake_counts.values())
    total_ladders = sum(v["count"] for v in ladder_counts.values())

    # Chakra time aggregation
    chakra_years: Dict[str, int] = {}
    for roll in journey:
        house_after = roll.get("house_after")
        if house_after and house_after in BOARD:
            chakra = BOARD[house_after]["chakra"]
            years = roll.get("age_after", 0) - roll.get("age_before", 0)
            chakra_years[chakra] = chakra_years.get(chakra, 0) + years

    if chakra_years:
        chakra_most_time = max(chakra_years.items(), key=lambda kv: kv[1])[0]
    else:
        chakra_most_time = "muladhara"

    # Net trajectory
    first_house = journey[0]["house_after"] if journey else 1
    if final_house > first_house + 10:
        net_trajectory = "ascending"
    elif final_house < first_house - 10:
        net_trajectory = "descending"
    elif total_snakes > total_ladders:
        net_trajectory = "circular"
    else:
        net_trajectory = "mixed"

    # Karmic label (classical narrative)
    chakra_most_name = CHAKRA_ROWS[chakra_most_time]["name"]
    if dominant_snake and dominant_ladder:
        karmic_label = (f"A soul repeatedly tested by {dominant_snake['from_name']} as the "
                       f"recurring karmic lesson, with {dominant_ladder['from_name']} as the "
                       f"emerging virtue — spending the majority of this life's karma in the "
                       f"{chakra_most_name} plane.")
    elif dominant_snake:
        karmic_label = (f"A soul working through the recurring pattern of {dominant_snake['from_name']}, "
                       f"spending the majority of this life's karma in the {chakra_most_name} plane.")
    elif dominant_ladder:
        karmic_label = (f"A soul with consistent strength in {dominant_ladder['from_name']}, "
                       f"moving with relative virtue through the {chakra_most_name} plane.")
    else:
        karmic_label = (f"A soul moving through the {chakra_most_name} plane, "
                       f"navigating the karmas of this level without dominant recurring patterns.")

    return {
        "dominant_snake":    dominant_snake,
        "dominant_ladder":   dominant_ladder,
        "all_snakes":        snake_list,
        "all_ladders":       ladder_list,
        "total_snakes":      total_snakes,
        "total_ladders":     total_ladders,
        "net_trajectory":    net_trajectory,
        "chakra_most_time":  chakra_most_time,
        "chakra_years":      chakra_years,
        "karmic_label":      karmic_label,
        "past_life_weight":  _get_past_life_weight(phase1_roll_count),
        "end_condition":     end_condition,
        "end_condition_label": END_CONDITIONS.get(end_condition, {}).get("label", end_condition),
    }


# ════════════════════════════════════════════════════════════════════════
# JOURNEY NARRATIVE — Text format for AI consumption
# ════════════════════════════════════════════════════════════════════════

def _build_journey_narrative(journey: List[Dict[str, Any]], phase1_roll_count: int) -> str:
    """
    Build a structured text narrative of the entire journey.
    Format matches the JS buildJourneyNarrative output for prompt compatibility.
    """
    lines: List[str] = []
    lines.append("PHASE 1 — TAKING BIRTH")
    weight = _get_past_life_weight(phase1_roll_count)
    lines.append(f"Rolls before birth: {phase1_roll_count} ({weight['text']})")
    lines.append("")
    lines.append("PHASE 2 — LIFE JOURNEY (each roll = one age bracket)")

    for roll in journey:
        house_after = roll.get("house_after")
        house = BOARD.get(house_after, {}) if house_after else {}
        chakra_key = house.get("chakra")
        chakra = CHAKRA_ROWS.get(chakra_key, {}) if chakra_key else {}

        roll_no = roll.get("roll_number", "?")
        dice = roll.get("dice", "?")
        age_before = roll.get("age_before", "?")
        age_after = roll.get("age_after", "?")

        line = f"Roll {roll_no}: Dice {dice} | Age {age_before}–{age_after} | "

        if roll.get("snake_hit"):
            from_h = roll.get("snake_from")
            from_house = BOARD.get(from_h, {}) if from_h else {}
            line += (f"Landed on {from_house.get('name', '?')} ({from_h}) → SNAKE → "
                    f"fell to {house.get('name', '?')} ({house_after}) "
                    f"[{chakra.get('name', '?')}] [VICE]")
        elif roll.get("ladder_hit"):
            from_h = roll.get("ladder_from")
            from_house = BOARD.get(from_h, {}) if from_h else {}
            line += (f"Landed on {from_house.get('name', '?')} ({from_h}) → LADDER → "
                    f"climbed to {house.get('name', '?')} ({house_after}) "
                    f"[{chakra.get('name', '?')}] [VIRTUE]")
        else:
            line += (f"{house.get('name', '?')} ({house_after}) "
                    f"[{chakra.get('name', '?')}] [{house.get('type', '?').upper()}]")

        lines.append(line)

    return "\n".join(lines)


# ════════════════════════════════════════════════════════════════════════
# CHART DATA — 3 visualization panels for client UI
# ════════════════════════════════════════════════════════════════════════

def _build_chart_data(
    chakra_analysis: Dict[str, Dict[str, Any]],
    journey: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Build 3 chart panels for client UI:
      1. chakra_time   — per-chakra years + virtue/vice/neutral percentages
      2. virtue_vs_vice — player vs board theoretical baseline per chakra
      3. journey_arc   — list of (age, house, event) for trajectory plot
    """
    # chakra_time
    chakra_time: List[Dict[str, Any]] = []
    for k in CHAKRA_ORDER:
        c = chakra_analysis.get(k, {})
        if c.get("rolls", 0) > 0:
            chakra_time.append({
                "chakra":            CHAKRA_SHORT[k],
                "years":             c.get("years_spent", 0),
                "virtue_pct":        c.get("virtue_pct", 0),
                "vice_pct":          c.get("vice_pct", 0),
                "neutral_pct":       c.get("neutral_pct", 0),
                "board_virtue_pct":  c.get("board_virtue_pct", 0),
                "board_vice_pct":    c.get("board_vice_pct", 0),
            })

    # virtue_vs_vice (player vs theoretical board baseline)
    virtue_vs_vice: List[Dict[str, Any]] = []
    for d in chakra_time:
        virtue_vs_vice.append({
            "chakra":          d["chakra"],
            "player_virtue":   d["virtue_pct"],
            "player_neutral":  d["neutral_pct"],
            "player_vice":     d["vice_pct"],
            "board_virtue":    d["board_virtue_pct"],
            "board_vice":      d["board_vice_pct"],
        })

    # journey_arc
    journey_arc: List[Dict[str, Any]] = []
    for r in journey:
        event = "snake" if r.get("snake_hit") else ("ladder" if r.get("ladder_hit") else "normal")
        from_h = None
        to_h = None
        if event == "snake":
            from_h = r.get("snake_from")
            to_h = r.get("snake_to")
        elif event == "ladder":
            from_h = r.get("ladder_from")
            to_h = r.get("ladder_to")
        journey_arc.append({
            "age":   r.get("age_after"),
            "house": r.get("house_after"),
            "event": event,
            "from":  from_h,
            "to":    to_h,
        })

    return {
        "chakra_time":    chakra_time,
        "virtue_vs_vice": virtue_vs_vice,
        "journey_arc":    journey_arc,
    }


# ════════════════════════════════════════════════════════════════════════
# JOURNEY VALIDATION — Structural consistency check
# ════════════════════════════════════════════════════════════════════════

def _validate_journey(journey_input: Dict[str, Any]) -> Dict[str, Any]:
    """
    Verify that the journey is structurally valid:
      - all houses referenced exist (1-72)
      - snake/ladder transitions match the board catalog
      - ages monotonically increase
      - end condition consistent with final_house and final_age
    Returns issues list (empty if valid).
    """
    issues: List[str] = []

    phase1 = journey_input.get("phase1_roll_count", 0)
    if not isinstance(phase1, int) or phase1 < 0:
        issues.append(f"phase1_roll_count must be non-negative int (got {phase1})")

    end_cond = journey_input.get("end_condition")
    if end_cond not in END_CONDITIONS:
        issues.append(f"end_condition must be 'house_68' or 'age_80' (got {end_cond})")

    journey = journey_input.get("journey", [])
    if not isinstance(journey, list) or len(journey) == 0:
        issues.append("journey must be a non-empty list of rolls")
        return {"valid": False, "issues": issues, "rolls_checked": 0}

    final_house = journey_input.get("final_house")
    final_age = journey_input.get("final_age")
    total_rolls = journey_input.get("total_rolls")

    if final_house and final_house not in BOARD:
        issues.append(f"final_house {final_house} not in 1-72")

    if total_rolls is not None and total_rolls != len(journey):
        issues.append(f"total_rolls ({total_rolls}) != actual journey length ({len(journey)})")

    prev_age_after = None
    for idx, roll in enumerate(journey):
        rn = idx + 1
        house_after = roll.get("house_after")
        age_before = roll.get("age_before")
        age_after = roll.get("age_after")

        if not house_after or house_after not in BOARD:
            issues.append(f"Roll {rn}: house_after {house_after} invalid")
            continue

        if age_before is None or age_after is None:
            issues.append(f"Roll {rn}: missing age_before or age_after")
            continue

        if age_after < age_before:
            issues.append(f"Roll {rn}: age_after ({age_after}) < age_before ({age_before})")

        if prev_age_after is not None and age_before < prev_age_after:
            issues.append(f"Roll {rn}: age_before ({age_before}) < previous age_after ({prev_age_after})")
        prev_age_after = age_after

        # Snake/ladder consistency
        if roll.get("snake_hit"):
            from_h = roll.get("snake_from")
            to_h = roll.get("snake_to")
            if from_h not in BOARD or to_h not in BOARD:
                issues.append(f"Roll {rn}: snake from/to invalid ({from_h}→{to_h})")
            else:
                catalog_snake_to = BOARD[from_h].get("snake_to")
                if catalog_snake_to != to_h:
                    issues.append(f"Roll {rn}: snake mismatch — board says {from_h}→{catalog_snake_to}, journey says {from_h}→{to_h}")
                if house_after != to_h:
                    issues.append(f"Roll {rn}: snake destination ({to_h}) != house_after ({house_after})")

        if roll.get("ladder_hit"):
            from_h = roll.get("ladder_from")
            to_h = roll.get("ladder_to")
            if from_h not in BOARD or to_h not in BOARD:
                issues.append(f"Roll {rn}: ladder from/to invalid ({from_h}→{to_h})")
            else:
                catalog_ladder_to = BOARD[from_h].get("ladder_to")
                if catalog_ladder_to != to_h:
                    issues.append(f"Roll {rn}: ladder mismatch — board says {from_h}→{catalog_ladder_to}, journey says {from_h}→{to_h}")
                if house_after != to_h:
                    issues.append(f"Roll {rn}: ladder destination ({to_h}) != house_after ({house_after})")

    # End-condition consistency
    if end_cond == "house_68":
        last_roll = journey[-1]
        if last_roll.get("house_after") != 68 and final_house != 68:
            issues.append("end_condition is 'house_68' but neither final roll nor final_house equals 68")
    if end_cond == "age_80":
        if final_age is not None and final_age < 75:
            issues.append(f"end_condition is 'age_80' but final_age is only {final_age}")

    return {
        "valid":         len(issues) == 0,
        "issues":        issues,
        "rolls_checked": len(journey),
    }


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT HANDLERS
# ════════════════════════════════════════════════════════════════════════

def handle_board_catalog() -> Dict[str, Any]:
    """Return all 72 houses with attributes."""
    return {
        "houses":       BOARD,
        "house_count":  len(BOARD),
        "snake_count":  sum(1 for h in BOARD.values() if h["snake_to"] is not None),
        "ladder_count": sum(1 for h in BOARD.values() if h["ladder_to"] is not None),
        "type_counts": {
            "virtue":  sum(1 for h in BOARD.values() if h["type"] == "virtue"),
            "vice":    sum(1 for h in BOARD.values() if h["type"] == "vice"),
            "neutral": sum(1 for h in BOARD.values() if h["type"] == "neutral"),
        },
        "citation":     CLASSICAL_CITATIONS["moksha_patam"],
    }


def handle_chakra_catalog() -> Dict[str, Any]:
    """Return all 8 chakras with themes + house assignments."""
    return {
        "chakras":        CHAKRA_ROWS,
        "chakra_order":   CHAKRA_ORDER,
        "chakra_short":   CHAKRA_SHORT,
        "chakra_count":   len(CHAKRA_ROWS),
        "citation":       CLASSICAL_CITATIONS["chakras"],
    }


def handle_past_life_weight(phase1_roll_count: int) -> Dict[str, Any]:
    """Phase 1 roll count → karma label per classical thresholds."""
    if not isinstance(phase1_roll_count, int) or phase1_roll_count < 0:
        return {"error": "phase1_roll_count must be a non-negative integer"}
    weight = _get_past_life_weight(phase1_roll_count)
    return {
        "phase1_roll_count": phase1_roll_count,
        **weight,
        "all_rules":         PAST_LIFE_WEIGHT_RULES,
        "citation":          CLASSICAL_CITATIONS["karma_doctrine"],
    }


def handle_chakra_analysis(journey: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Per-chakra time/virtue/vice breakdown of a completed journey."""
    if not isinstance(journey, list):
        return {"error": "journey must be a list of roll dicts"}
    analysis = _compute_chakra_analysis(journey)
    return {
        "chakra_analysis": analysis,
        "chakra_order":    CHAKRA_ORDER,
        "method":          "For each chakra, aggregate rolls, years, virtue/vice/neutral counts. Dominant quality determined by 10-pp margin.",
        "citation":        CLASSICAL_CITATIONS["chakras"],
    }


def handle_cumulative_pattern(
    journey: List[Dict[str, Any]],
    phase1_roll_count: int,
    end_condition: str,
    final_house: int,
) -> Dict[str, Any]:
    """Dominant snake, dominant ladder, trajectory, karmic label."""
    if not isinstance(journey, list) or not journey:
        return {"error": "journey must be a non-empty list"}
    if end_condition not in END_CONDITIONS:
        return {"error": f"end_condition must be one of {list(END_CONDITIONS.keys())}"}
    pattern = _compute_cumulative_pattern(journey, phase1_roll_count, end_condition, final_house)
    return {
        **pattern,
        "method":   "Aggregate snake/ladder hits, find recurring patterns, compute chakra-time distribution, derive net trajectory and karmic label.",
        "citation": CLASSICAL_CITATIONS["karma_doctrine"] + "; " + CLASSICAL_CITATIONS["snakes_ladders"],
    }


def handle_journey_narrative(journey: List[Dict[str, Any]], phase1_roll_count: int = 0) -> Dict[str, Any]:
    """Text narrative for AI prompt consumption."""
    if not isinstance(journey, list):
        return {"error": "journey must be a list of roll dicts"}
    narrative = _build_journey_narrative(journey, phase1_roll_count)
    return {
        "narrative":         narrative,
        "phase1_roll_count": phase1_roll_count,
        "journey_length":    len(journey),
        "method":            "Structured text format: Phase 1 (pre-birth) + Phase 2 (life journey with per-roll detail).",
        "citation":          CLASSICAL_CITATIONS["karma_doctrine"],
    }


def handle_chart_data(journey: List[Dict[str, Any]]) -> Dict[str, Any]:
    """3 visualization panels: chakra_time, virtue_vs_vice, journey_arc."""
    if not isinstance(journey, list):
        return {"error": "journey must be a list of roll dicts"}
    analysis = _compute_chakra_analysis(journey)
    chart = _build_chart_data(analysis, journey)
    return {
        "chart_data": chart,
        "method":     "3-panel layout: time spent per chakra, player virtue/vice vs board baseline, journey arc plot.",
        "citation":   CLASSICAL_CITATIONS["chakras"],
    }


def handle_validate_journey(journey_input: Dict[str, Any]) -> Dict[str, Any]:
    """Validate journey structure for consistency."""
    if not isinstance(journey_input, dict):
        return {"error": "journey_input must be a dict"}
    return _validate_journey(journey_input)


def handle_profile(
    journey: List[Dict[str, Any]],
    phase1_roll_count: int,
    end_condition: str,
    final_house: int,
    final_age: int,
    total_rolls: Optional[int] = None,
) -> Dict[str, Any]:
    """
    MASTER endpoint: all analysis bundled.
    Validation + chakra analysis + cumulative pattern + narrative + chart data + AI prompt context.
    """
    if not isinstance(journey, list) or not journey:
        return {"error": "journey must be a non-empty list of roll dicts"}
    if end_condition not in END_CONDITIONS:
        return {"error": f"end_condition must be one of {list(END_CONDITIONS.keys())}"}

    journey_input = {
        "phase1_roll_count": phase1_roll_count,
        "end_condition":     end_condition,
        "final_house":       final_house,
        "final_age":         final_age,
        "total_rolls":       total_rolls if total_rolls is not None else len(journey),
        "journey":           journey,
    }
    validation = _validate_journey(journey_input)
    chakra_analysis = _compute_chakra_analysis(journey)
    cumulative = _compute_cumulative_pattern(journey, phase1_roll_count, end_condition, final_house)
    narrative = _build_journey_narrative(journey, phase1_roll_count)
    chart_data = _build_chart_data(chakra_analysis, journey)

    final_house_name = BOARD.get(final_house, {}).get("name", "")

    # Headlines
    headlines: List[str] = []
    headlines.append(f"Final position: H{final_house} {final_house_name} at age {final_age}")
    headlines.append(f"End condition: {cumulative['end_condition_label']}")
    headlines.append(f"Past life weight: {cumulative['past_life_weight']['label']}")
    headlines.append(f"Chakra of most time: {CHAKRA_ROWS[cumulative['chakra_most_time']]['name']}")
    headlines.append(f"Net trajectory: {cumulative['net_trajectory']}")
    headlines.append(f"Snakes: {cumulative['total_snakes']} | Ladders: {cumulative['total_ladders']}")
    if cumulative.get("dominant_snake"):
        headlines.append(f"Dominant lesson: {cumulative['dominant_snake']['from_name']} (×{cumulative['dominant_snake']['count']})")
    if cumulative.get("dominant_ladder"):
        headlines.append(f"Dominant virtue: {cumulative['dominant_ladder']['from_name']} (×{cumulative['dominant_ladder']['count']})")

    return {
        "headlines":         headlines,
        "validation":        validation,
        "final_house":       final_house,
        "final_house_name":  final_house_name,
        "final_age":         final_age,
        "total_rolls":       total_rolls if total_rolls is not None else len(journey),
        "phase1_roll_count": phase1_roll_count,
        "end_condition":     end_condition,
        "end_condition_label": END_CONDITIONS.get(end_condition, {}).get("label"),
        "chakra_analysis":   chakra_analysis,
        "cumulative_pattern":cumulative,
        "journey_narrative": narrative,
        "chart_data":        chart_data,
        "method":            "Master Moksha Patam analysis: all per-chakra metrics, cumulative pattern, narrative, and chart data computed deterministically from completed journey.",
        "citations":         CLASSICAL_CITATIONS,
    }
