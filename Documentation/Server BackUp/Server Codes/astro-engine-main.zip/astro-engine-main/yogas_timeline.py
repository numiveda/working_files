"""
yogas_timeline.py — numiVeda Astro Engine — Yoga Timeline Engine

Generates activation windows for natal yogas across 1/5/10/15 year horizons.

Public API:
    timeline_annual(natal_chart, birth_datetime, lat, lon, timezone, dasha_function, transit_function)
    timeline_5year(...)
    timeline_10year(...)
    timeline_15year(...)
    timeline_for_horizon(natal_chart, ..., horizon_years)  ← generic

The functions take callables for dasha_function (returns MD/AD/PD given date) and
transit_function (returns chart at a given date). These are injected by the caller
to keep this module independent of dashaflow imports — which keeps tests easy.

Returns:
{
  "horizon_years": int,
  "computed_at": ISO timestamp,
  "natal_summary": {...},
  "active_yogas_count": int,
  "transit_yogas_count": int,
  "timelines": [
    {
      "yoga_id": "gaja_kesari_yoga",
      "name_en": "Gaja Kesari Yoga",
      "name_sa": "गजकेसरी",
      "family": "raja_yoga",
      "polarity": "positive",
      "is_natal_active": true,           # if active in birth chart
      "activation_windows": [
        {
          "start": "2026-06-15",
          "end":   "2027-02-08",
          "intensity": "peak",
          "trigger": "Jupiter MD + Moon AD + Transit Jupiter in kendra from natal Moon",
          "duration_days": 238,
        },
        ...
      ],
      "total_active_days": int,
      "peak_days": int,
      "moderate_days": int,
      "domains": [...],
    },
    ...
  ]
}
"""

from typing import Dict, Any, List, Tuple, Callable, Optional
from datetime import datetime, timedelta
from yogas import YOGA_CATALOG, detect_all
from timeline_activation_rules import get_activation_state


# ─────────────────────────────────────────────────────────────────────────────
# CORE TIMELINE COMPUTATION
# ─────────────────────────────────────────────────────────────────────────────

def _monthly_sample_dates(start: datetime, horizon_years: int) -> List[datetime]:
    """Generate one date per month for the horizon."""
    dates = []
    current = start
    end = start.replace(year=start.year + horizon_years)
    while current < end:
        dates.append(current)
        # Move to first of next month
        if current.month == 12:
            current = current.replace(year=current.year + 1, month=1, day=1)
        else:
            current = current.replace(month=current.month + 1, day=1)
    return dates


def _merge_consecutive_states(samples: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Given monthly samples of [{date, intensity, trigger}, ...],
    merge consecutive same-intensity runs into windows.
    """
    if not samples:
        return []

    windows = []
    current_start = samples[0]["date"]
    current_intensity = samples[0]["intensity"]
    current_trigger = samples[0]["trigger"]

    for i in range(1, len(samples)):
        sample = samples[i]
        if sample["intensity"] == current_intensity and sample["trigger"] == current_trigger:
            continue
        # Close out current window
        prev_date = samples[i - 1]["date"]
        # End of window is the last day of that month
        end_date = (prev_date.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)
        if current_intensity != "background":
            windows.append({
                "start":         current_start.strftime("%Y-%m-%d"),
                "end":           end_date.strftime("%Y-%m-%d"),
                "intensity":     current_intensity,
                "trigger":       current_trigger,
                "duration_days": (end_date - current_start).days + 1,
            })
        current_start = sample["date"]
        current_intensity = sample["intensity"]
        current_trigger = sample["trigger"]

    # Close out final window
    last_date = samples[-1]["date"]
    end_date = (last_date.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)
    if current_intensity != "background":
        windows.append({
            "start":         current_start.strftime("%Y-%m-%d"),
            "end":           end_date.strftime("%Y-%m-%d"),
            "intensity":     current_intensity,
            "trigger":       current_trigger,
            "duration_days": (end_date - current_start).days + 1,
        })

    return windows


def _compute_timeline_for_yoga(
    yoga: Dict[str, Any],
    natal_chart: Dict[str, Any],
    sample_dates: List[datetime],
    dasha_states: List[Dict[str, str]],
    transit_charts: List[Dict[str, Any]],
    is_natal_active: bool,
) -> Dict[str, Any]:
    """
    For one yoga, scan all monthly samples and produce its activation windows.
    """
    samples = []
    for i, date in enumerate(sample_dates):
        intensity, trigger = get_activation_state(
            yoga, natal_chart, transit_charts[i], dasha_states[i]
        )
        samples.append({"date": date, "intensity": intensity, "trigger": trigger})

    windows = _merge_consecutive_states(samples)

    # Statistics
    peak_days = sum(w["duration_days"] for w in windows if w["intensity"] == "peak")
    moderate_days = sum(w["duration_days"] for w in windows if w["intensity"] == "moderate")
    total_days = peak_days + moderate_days

    return {
        "yoga_id":              yoga["yoga_id"],
        "name_en":               yoga["name_en"],
        "name_sa":                yoga["name_sa"],
        "family":                  yoga["family"],
        "polarity":                  yoga["polarity"],
        "is_natal_active":           is_natal_active,
        "activation_windows":         windows,
        "window_count":                len(windows),
        "total_active_days":             total_days,
        "peak_days":                       peak_days,
        "moderate_days":                     moderate_days,
        "domains":                             yoga.get("domains", []),
        "general_effect":                        yoga.get("general_effect", ""),
        "source":                                  yoga.get("source", ""),
    }


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ENGINE
# ─────────────────────────────────────────────────────────────────────────────

def compute_timeline(
    natal_chart: Dict[str, Any],
    birth_datetime: datetime,
    dasha_state_fn: Callable[[datetime], Dict[str, str]],
    transit_chart_fn: Callable[[datetime], Dict[str, Any]],
    horizon_years: int,
    start_date: Optional[datetime] = None,
    include_inactive: bool = True,
) -> Dict[str, Any]:
    """
    Main timeline computation.

    Args:
      natal_chart: chart dict from cast_chart()
      birth_datetime: datetime of birth
      dasha_state_fn: callable(date) -> {"md", "ad", "pd"}
      transit_chart_fn: callable(date) -> chart dict at that moment
      horizon_years: 1, 5, 10, or 15
      start_date: when to start scanning (default = now)
      include_inactive: if True, also scan yogas not natally active for transit-formed windows

    Returns: timeline dict (see module docstring)
    """
    if start_date is None:
        start_date = datetime.now()

    computed_at = datetime.now().isoformat()

    # Step 1: Detect natal-active yogas
    natal_results = detect_all(natal_chart)
    active_ids = {y["yoga_id"] for y in natal_results["yogas"] if y["is_present"]}

    # Step 2: Generate monthly sample dates
    sample_dates = _monthly_sample_dates(start_date, horizon_years)

    # Step 3: Pre-compute dasha state and transit chart for every sample date
    dasha_states = []
    transit_charts = []
    for d in sample_dates:
        try:
            dasha_states.append(dasha_state_fn(d))
        except Exception as e:
            dasha_states.append({"md": "", "ad": "", "pd": "", "_error": str(e)})
        try:
            transit_charts.append(transit_chart_fn(d))
        except Exception as e:
            transit_charts.append({"_error": str(e), "planets": {}, "ascendant": {}})

    # Step 4: For each yoga, compute its timeline
    # Strategy: prioritize natal-active yogas, then scan others for transit-formed activations
    yogas_to_process = []

    # First: all natal-active yogas
    for yoga in YOGA_CATALOG:
        if yoga["yoga_id"] in active_ids:
            yogas_to_process.append((yoga, True))

    # Second: high-value families (raja, dhana, mahapurusha) even if not natally active
    # to catch transit-formed yogas
    if include_inactive:
        high_value_families = {
            "raja_yoga", "dhana_yoga", "pancha_mahapurusha", "special_outcome", "vipreet_raja"
        }
        for yoga in YOGA_CATALOG:
            if yoga["yoga_id"] not in active_ids and yoga["family"] in high_value_families:
                yogas_to_process.append((yoga, False))

    timelines = []
    transit_formed_count = 0
    for yoga, is_natal in yogas_to_process:
        result = _compute_timeline_for_yoga(
            yoga, natal_chart, sample_dates, dasha_states, transit_charts, is_natal,
        )
        # Only include if there's actually some activation window OR it's natally active
        if result["window_count"] > 0 or is_natal:
            timelines.append(result)
            if not is_natal and result["window_count"] > 0:
                transit_formed_count += 1

    # Sort timelines: natally active first, then by total_active_days descending
    timelines.sort(key=lambda t: (not t["is_natal_active"], -t["total_active_days"]))

    return {
        "horizon_years":          horizon_years,
        "computed_at":              computed_at,
        "start_date":                 start_date.strftime("%Y-%m-%d"),
        "end_date":                     sample_dates[-1].strftime("%Y-%m-%d") if sample_dates else "",
        "monthly_samples":                len(sample_dates),
        "natal_active_count":              len(active_ids),
        "transit_formed_count":              transit_formed_count,
        "yogas_with_activations":              len(timelines),
        "timelines":                             timelines,
    }


# ─────────────────────────────────────────────────────────────────────────────
# CONVENIENCE WRAPPERS
# ─────────────────────────────────────────────────────────────────────────────

def timeline_annual(natal_chart, birth_dt, dasha_fn, transit_fn, start_date=None):
    return compute_timeline(natal_chart, birth_dt, dasha_fn, transit_fn,
                             horizon_years=1, start_date=start_date)

def timeline_5year(natal_chart, birth_dt, dasha_fn, transit_fn, start_date=None):
    return compute_timeline(natal_chart, birth_dt, dasha_fn, transit_fn,
                             horizon_years=5, start_date=start_date)

def timeline_10year(natal_chart, birth_dt, dasha_fn, transit_fn, start_date=None):
    return compute_timeline(natal_chart, birth_dt, dasha_fn, transit_fn,
                             horizon_years=10, start_date=start_date)

def timeline_15year(natal_chart, birth_dt, dasha_fn, transit_fn, start_date=None):
    return compute_timeline(natal_chart, birth_dt, dasha_fn, transit_fn,
                             horizon_years=15, start_date=start_date)
