"""
muhurta.py — numiVeda Astro Engine

Choghadiya, Rahu Kaal, Yamaganda, Gulika, Hora and Abhijit Muhurta calculator.

Decision: The PyPI `panchang` package is thin and unmaintained. The math for
Choghadiya and the inauspicious time-slots is purely deterministic — they are
derived from sunrise/sunset, day-of-week, and a fixed planet-sequence rotation.
We compute sunrise/sunset via Swiss Ephemeris (already installed and used by
dashaflow) and apply the classical rules.

Public API:
    choghadiya(date_str, lat, lon, tz) -> dict
    rahu_kaal(date_str, lat, lon, tz) -> dict
    full_muhurta(date_str, lat, lon, tz) -> dict
    hora(date_str, lat, lon, tz) -> dict
"""

from datetime import datetime, timedelta, date as _date
from typing import Dict, List, Any
import swisseph as swe
import pytz


# ─────────────────────────────────────────────────────────────────────────────
# 1. CLASSICAL CHOGHADIYA TABLES
# ─────────────────────────────────────────────────────────────────────────────

# Day Choghadiyas — 8 slots from sunrise to sunset, sequence depends on weekday.
# Each weekday starts with a specific Choghadiya and rotates through:
#   Udveg(Sun) → Char(Venus) → Labh(Mercury) → Amrit(Moon) →
#   Kaal(Saturn) → Shubh(Jupiter) → Rog(Mars)  → and cycles.
# Sunday starts with Udveg; Monday with Amrit; Tuesday with Rog; etc.

CHOGHADIYA_ORDER = ["Udveg", "Char", "Labh", "Amrit", "Kaal", "Shubh", "Rog"]

DAY_START_INDEX = {
    "Sunday":    0,   # Udveg
    "Monday":    3,   # Amrit
    "Tuesday":   6,   # Rog
    "Wednesday": 2,   # Labh
    "Thursday":  5,   # Shubh
    "Friday":    1,   # Char
    "Saturday":  4,   # Kaal
}

# Night Choghadiyas — sunset to next sunrise. Shifted by 4 from day start.
NIGHT_START_INDEX = {
    "Sunday":    4,   # Kaal
    "Monday":    0,   # Udveg
    "Tuesday":   3,   # Amrit
    "Wednesday": 6,   # Rog
    "Thursday":  2,   # Labh
    "Friday":    5,   # Shubh
    "Saturday":  1,   # Char
}

CHOGHADIYA_NATURE = {
    "Udveg":  {"nature": "Inauspicious", "ruler": "Sun",     "use_for": "Government work, dealing with authorities"},
    "Char":   {"nature": "Good",         "ruler": "Venus",   "use_for": "Travel, movement, transport"},
    "Labh":   {"nature": "Most Good",    "ruler": "Mercury", "use_for": "Business, profit, starting ventures"},
    "Amrit":  {"nature": "Most Good",    "ruler": "Moon",    "use_for": "All auspicious work, beginning anything"},
    "Kaal":   {"nature": "Inauspicious", "ruler": "Saturn",  "use_for": "Avoid important work"},
    "Shubh":  {"nature": "Good",         "ruler": "Jupiter", "use_for": "Marriage, religious work, education"},
    "Rog":    {"nature": "Inauspicious", "ruler": "Mars",    "use_for": "Avoid health/medicine starts; OK for confrontation"},
}

# Rahu Kaal — 1/8 of daylight, slot depends on weekday
# Slot numbering: 0 = first 1/8 of day starting at sunrise
RAHU_KAAL_SLOT = {
    "Sunday": 8, "Monday": 2, "Tuesday": 7, "Wednesday": 5,
    "Thursday": 6, "Friday": 4, "Saturday": 3,
}
# Yamaganda Kaal slot
YAMAGANDA_SLOT = {
    "Sunday": 4, "Monday": 3, "Tuesday": 2, "Wednesday": 1,
    "Thursday": 7, "Friday": 6, "Saturday": 5,
}
# Gulika Kaal slot
GULIKA_SLOT = {
    "Sunday": 7, "Monday": 6, "Tuesday": 5, "Wednesday": 4,
    "Thursday": 3, "Friday": 2, "Saturday": 1,
}

# Hora order — 24 hours, 1 per hour, in this fixed planetary sequence,
# starting with the planet ruling that weekday at sunrise.
HORA_ORDER = ["Sun", "Venus", "Mercury", "Moon", "Saturn", "Jupiter", "Mars"]
WEEKDAY_HORA_START = {
    "Sunday":    "Sun",
    "Monday":    "Moon",
    "Tuesday":   "Mars",
    "Wednesday": "Mercury",
    "Thursday":  "Jupiter",
    "Friday":    "Venus",
    "Saturday":  "Saturn",
}
HORA_EFFECT = {
    "Sun":     "Authority, government, leadership work",
    "Moon":    "Travel, emotional matters, peaceful work",
    "Mars":    "Confrontation, surgery, sports, energetic action",
    "Mercury": "Business, communication, study, signing contracts",
    "Jupiter": "Religion, education, marriage, auspicious starts",
    "Venus":   "Art, romance, beauty, luxury, music",
    "Saturn":  "Discipline, long-term work, real estate, manual labor",
}


# ─────────────────────────────────────────────────────────────────────────────
# 2. SUNRISE / SUNSET via Swiss Ephemeris
# ─────────────────────────────────────────────────────────────────────────────

def _sun_rise_set(d: _date, lat: float, lon: float, tz: str):
    """Calculate sunrise and sunset (timezone-aware datetimes)."""
    tzinfo = pytz.timezone(tz)
    # Swiss Ephemeris works in UT/UTC. Build a JD for local midnight (UT).
    local_mid = tzinfo.localize(datetime(d.year, d.month, d.day, 0, 0, 0))
    utc_mid = local_mid.astimezone(pytz.UTC)
    jd_ut = swe.julday(utc_mid.year, utc_mid.month, utc_mid.day,
                       utc_mid.hour + utc_mid.minute / 60.0)

    # rsmi flags: SE_CALC_RISE / SE_CALC_SET
    geopos = (lon, lat, 0.0)

    res_rise = swe.rise_trans(jd_ut, swe.SUN, swe.CALC_RISE,
                              geopos=geopos, atpress=1013.25, attemp=15)
    res_set  = swe.rise_trans(jd_ut, swe.SUN, swe.CALC_SET,
                              geopos=geopos, atpress=1013.25, attemp=15)

    # rise_trans returns (retflag, (jd,)) in newer pyswisseph
    rise_jd = res_rise[1][0]
    set_jd  = res_set[1][0]

    def _jd_to_local(jd: float) -> datetime:
        y, m, dd, h_frac = swe.revjul(jd)
        hour = int(h_frac)
        minute = int((h_frac - hour) * 60)
        sec = int(((h_frac - hour) * 60 - minute) * 60)
        utc_dt = pytz.UTC.localize(datetime(int(y), int(m), int(dd), hour, minute, sec))
        return utc_dt.astimezone(tzinfo)

    return _jd_to_local(rise_jd), _jd_to_local(set_jd)


# ─────────────────────────────────────────────────────────────────────────────
# 3. CHOGHADIYA
# ─────────────────────────────────────────────────────────────────────────────

def choghadiya(date_str: str, lat: float, lon: float, tz: str = "Asia/Kolkata") -> Dict[str, Any]:
    """
    Returns the 8 day + 8 night Choghadiya slots for a date and location.
    date_str format: YYYY-MM-DD
    """
    d = _date.fromisoformat(date_str)
    sunrise, sunset = _sun_rise_set(d, lat, lon, tz)
    # Next sunrise for night-end
    next_sunrise, _ = _sun_rise_set(d + timedelta(days=1), lat, lon, tz)

    weekday = sunrise.strftime("%A")

    day_dur = (sunset - sunrise) / 8
    night_dur = (next_sunrise - sunset) / 8

    # Build day choghadiyas
    day_start_idx = DAY_START_INDEX[weekday]
    day_slots: List[Dict[str, Any]] = []
    for i in range(8):
        name = CHOGHADIYA_ORDER[(day_start_idx + i) % 7]
        slot_start = sunrise + day_dur * i
        slot_end = sunrise + day_dur * (i + 1)
        day_slots.append({
            "slot":  i + 1,
            "name":  name,
            "start": slot_start.strftime("%H:%M:%S"),
            "end":   slot_end.strftime("%H:%M:%S"),
            **CHOGHADIYA_NATURE[name],
        })

    night_start_idx = NIGHT_START_INDEX[weekday]
    night_slots: List[Dict[str, Any]] = []
    for i in range(8):
        name = CHOGHADIYA_ORDER[(night_start_idx + i) % 7]
        slot_start = sunset + night_dur * i
        slot_end = sunset + night_dur * (i + 1)
        night_slots.append({
            "slot":  i + 1,
            "name":  name,
            "start": slot_start.strftime("%H:%M:%S"),
            "end":   slot_end.strftime("%H:%M:%S"),
            **CHOGHADIYA_NATURE[name],
        })

    return {
        "date":     date_str,
        "weekday":  weekday,
        "sunrise":  sunrise.strftime("%H:%M:%S"),
        "sunset":   sunset.strftime("%H:%M:%S"),
        "day_choghadiyas":   day_slots,
        "night_choghadiyas": night_slots,
    }


# ─────────────────────────────────────────────────────────────────────────────
# 4. RAHU KAAL / YAMAGANDA / GULIKA
# ─────────────────────────────────────────────────────────────────────────────

def _slot_window(sunrise: datetime, sunset: datetime, slot: int) -> Dict[str, str]:
    """Each weekday's day is divided into 8 equal slots; slot 1 = first slot."""
    dur = (sunset - sunrise) / 8
    start = sunrise + dur * (slot - 1)
    end = sunrise + dur * slot
    return {"start": start.strftime("%H:%M:%S"), "end": end.strftime("%H:%M:%S")}


def rahu_kaal(date_str: str, lat: float, lon: float, tz: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Returns Rahu Kaal, Yamaganda, and Gulika Kaal for the date."""
    d = _date.fromisoformat(date_str)
    sunrise, sunset = _sun_rise_set(d, lat, lon, tz)
    weekday = sunrise.strftime("%A")

    return {
        "date":    date_str,
        "weekday": weekday,
        "sunrise": sunrise.strftime("%H:%M:%S"),
        "sunset":  sunset.strftime("%H:%M:%S"),
        "rahu_kaal": {
            **_slot_window(sunrise, sunset, RAHU_KAAL_SLOT[weekday]),
            "nature": "Highly inauspicious — avoid new starts, signing, travel",
        },
        "yamaganda_kaal": {
            **_slot_window(sunrise, sunset, YAMAGANDA_SLOT[weekday]),
            "nature": "Inauspicious — avoid important work",
        },
        "gulika_kaal": {
            **_slot_window(sunrise, sunset, GULIKA_SLOT[weekday]),
            "nature": "Inauspicious — Saturn's son; avoid auspicious starts",
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# 5. ABHIJIT MUHURTA
# ─────────────────────────────────────────────────────────────────────────────

def abhijit_muhurta(date_str: str, lat: float, lon: float, tz: str = "Asia/Kolkata") -> Dict[str, Any]:
    """
    Abhijit = the 8th muhurta of the day (out of 15), centered on solar noon.
    Roughly 48 minutes around local noon. The most auspicious muhurta of the day,
    EXCEPT on Wednesdays when it is considered void.
    """
    d = _date.fromisoformat(date_str)
    sunrise, sunset = _sun_rise_set(d, lat, lon, tz)
    weekday = sunrise.strftime("%A")
    day_dur = sunset - sunrise
    muhurta_dur = day_dur / 15
    abhijit_start = sunrise + muhurta_dur * 7
    abhijit_end = sunrise + muhurta_dur * 8

    return {
        "date":    date_str,
        "weekday": weekday,
        "abhijit_start": abhijit_start.strftime("%H:%M:%S"),
        "abhijit_end":   abhijit_end.strftime("%H:%M:%S"),
        "is_voided":     weekday == "Wednesday",
        "note": (
            "Abhijit Muhurta is voided on Wednesdays."
            if weekday == "Wednesday" else
            "Most auspicious moment of the day — suitable for any beginning."
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
# 6. HORA (Planetary Hour)
# ─────────────────────────────────────────────────────────────────────────────

def hora(date_str: str, lat: float, lon: float, tz: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Returns the 24 hora (planetary hours) of the day."""
    d = _date.fromisoformat(date_str)
    sunrise, sunset = _sun_rise_set(d, lat, lon, tz)
    next_sunrise, _ = _sun_rise_set(d + timedelta(days=1), lat, lon, tz)
    weekday = sunrise.strftime("%A")

    # Day = 12 hora (variable), Night = 12 hora (variable)
    day_dur = (sunset - sunrise) / 12
    night_dur = (next_sunrise - sunset) / 12

    start_planet = WEEKDAY_HORA_START[weekday]
    start_idx = HORA_ORDER.index(start_planet)

    horas: List[Dict[str, Any]] = []
    for i in range(24):
        if i < 12:
            slot_start = sunrise + day_dur * i
            slot_end = sunrise + day_dur * (i + 1)
            day_or_night = "day"
        else:
            slot_start = sunset + night_dur * (i - 12)
            slot_end = sunset + night_dur * (i - 12 + 1)
            day_or_night = "night"

        planet = HORA_ORDER[(start_idx + i) % 7]
        horas.append({
            "hora":   i + 1,
            "phase":  day_or_night,
            "planet": planet,
            "start":  slot_start.strftime("%H:%M:%S"),
            "end":    slot_end.strftime("%H:%M:%S"),
            "good_for": HORA_EFFECT[planet],
        })

    return {
        "date":    date_str,
        "weekday": weekday,
        "sunrise": sunrise.strftime("%H:%M:%S"),
        "sunset":  sunset.strftime("%H:%M:%S"),
        "horas":   horas,
    }


# ─────────────────────────────────────────────────────────────────────────────
# 7. FULL MUHURTA BUNDLE
# ─────────────────────────────────────────────────────────────────────────────

def full_muhurta(date_str: str, lat: float, lon: float, tz: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Combine all muhurta data into one envelope."""
    return {
        "choghadiya":  choghadiya(date_str, lat, lon, tz),
        "rahu_kaal":   rahu_kaal(date_str, lat, lon, tz),
        "abhijit":     abhijit_muhurta(date_str, lat, lon, tz),
        # Hora is large — caller can request separately if needed
    }
