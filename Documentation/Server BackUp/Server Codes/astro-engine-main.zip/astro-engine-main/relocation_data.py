"""
relocation_data.py — Relocation Astrology / Astrocartography reference data.

Phase D — Module D6 (Relocation/Astrocartography).

Public catalogs:
    MAJOR_CITIES         — ~80 globally significant cities with lat/lon/timezone
    THEME_TO_PLANETS     — Astrological theme → planets to bring to angular houses
    ANGULAR_HOUSES       — H1/4/7/10 with angular weight (KP-classic)
    HOUSE_THEMES         — Each house's primary life-area
    CLASSICAL_CITATIONS

Sources: Jim Lewis "Astro*Carto*Graphy" (1976 — modern astrology tradition).
         Lewis's framework popularized planetary lines but the core
         relocation concept dates to classical Greek-Hellenistic astrology
         (Vettius Valens, Hephaestio of Thebes). Modern Vedic relocation
         per K.N. Rao tradition.
"""

from typing import Dict, List


# ════════════════════════════════════════════════════════════════════════
# MAJOR WORLD CITIES — Globally significant for astrocartography
# ════════════════════════════════════════════════════════════════════════

MAJOR_CITIES: List[Dict] = [
    # India (primary market)
    {"name": "New Delhi",    "country": "India",        "lat": 28.6139, "lon": 77.2090, "timezone": "Asia/Kolkata"},
    {"name": "Mumbai",       "country": "India",        "lat": 19.0760, "lon": 72.8777, "timezone": "Asia/Kolkata"},
    {"name": "Bengaluru",    "country": "India",        "lat": 12.9716, "lon": 77.5946, "timezone": "Asia/Kolkata"},
    {"name": "Chennai",      "country": "India",        "lat": 13.0827, "lon": 80.2707, "timezone": "Asia/Kolkata"},
    {"name": "Kolkata",      "country": "India",        "lat": 22.5726, "lon": 88.3639, "timezone": "Asia/Kolkata"},
    {"name": "Hyderabad",    "country": "India",        "lat": 17.3850, "lon": 78.4867, "timezone": "Asia/Kolkata"},
    {"name": "Pune",         "country": "India",        "lat": 18.5204, "lon": 73.8567, "timezone": "Asia/Kolkata"},
    {"name": "Ahmedabad",    "country": "India",        "lat": 23.0225, "lon": 72.5714, "timezone": "Asia/Kolkata"},
    {"name": "Jaipur",       "country": "India",        "lat": 26.9124, "lon": 75.7873, "timezone": "Asia/Kolkata"},
    {"name": "Faridabad",    "country": "India",        "lat": 28.4089, "lon": 77.3178, "timezone": "Asia/Kolkata"},
    {"name": "Varanasi",     "country": "India",        "lat": 25.3176, "lon": 82.9739, "timezone": "Asia/Kolkata"},
    {"name": "Rishikesh",    "country": "India",        "lat": 30.0869, "lon": 78.2676, "timezone": "Asia/Kolkata"},
    {"name": "Guwahati",     "country": "India",        "lat": 26.1445, "lon": 91.7362, "timezone": "Asia/Kolkata"},
    # USA
    {"name": "New York",     "country": "USA",          "lat": 40.7128, "lon": -74.0060, "timezone": "America/New_York"},
    {"name": "Los Angeles",  "country": "USA",          "lat": 34.0522, "lon": -118.2437, "timezone": "America/Los_Angeles"},
    {"name": "Chicago",      "country": "USA",          "lat": 41.8781, "lon": -87.6298, "timezone": "America/Chicago"},
    {"name": "San Francisco","country": "USA",          "lat": 37.7749, "lon": -122.4194, "timezone": "America/Los_Angeles"},
    {"name": "Seattle",      "country": "USA",          "lat": 47.6062, "lon": -122.3321, "timezone": "America/Los_Angeles"},
    {"name": "Austin",       "country": "USA",          "lat": 30.2672, "lon": -97.7431, "timezone": "America/Chicago"},
    {"name": "Boston",       "country": "USA",          "lat": 42.3601, "lon": -71.0589, "timezone": "America/New_York"},
    {"name": "Miami",        "country": "USA",          "lat": 25.7617, "lon": -80.1918, "timezone": "America/New_York"},
    {"name": "Denver",       "country": "USA",          "lat": 39.7392, "lon": -104.9903, "timezone": "America/Denver"},
    {"name": "Sedona",       "country": "USA",          "lat": 34.8697, "lon": -111.7610, "timezone": "America/Phoenix"},
    # UK / Europe
    {"name": "London",       "country": "UK",           "lat": 51.5074, "lon": -0.1278, "timezone": "Europe/London"},
    {"name": "Edinburgh",    "country": "UK",           "lat": 55.9533, "lon": -3.1883, "timezone": "Europe/London"},
    {"name": "Paris",        "country": "France",       "lat": 48.8566, "lon": 2.3522, "timezone": "Europe/Paris"},
    {"name": "Berlin",       "country": "Germany",      "lat": 52.5200, "lon": 13.4050, "timezone": "Europe/Berlin"},
    {"name": "Amsterdam",    "country": "Netherlands",  "lat": 52.3676, "lon": 4.9041, "timezone": "Europe/Amsterdam"},
    {"name": "Zurich",       "country": "Switzerland",  "lat": 47.3769, "lon": 8.5417, "timezone": "Europe/Zurich"},
    {"name": "Rome",         "country": "Italy",        "lat": 41.9028, "lon": 12.4964, "timezone": "Europe/Rome"},
    {"name": "Barcelona",    "country": "Spain",        "lat": 41.3851, "lon": 2.1734, "timezone": "Europe/Madrid"},
    {"name": "Lisbon",       "country": "Portugal",     "lat": 38.7223, "lon": -9.1393, "timezone": "Europe/Lisbon"},
    {"name": "Athens",       "country": "Greece",       "lat": 37.9838, "lon": 23.7275, "timezone": "Europe/Athens"},
    {"name": "Istanbul",     "country": "Turkey",       "lat": 41.0082, "lon": 28.9784, "timezone": "Europe/Istanbul"},
    {"name": "Stockholm",    "country": "Sweden",       "lat": 59.3293, "lon": 18.0686, "timezone": "Europe/Stockholm"},
    # Middle East
    {"name": "Dubai",        "country": "UAE",          "lat": 25.2048, "lon": 55.2708, "timezone": "Asia/Dubai"},
    {"name": "Tel Aviv",     "country": "Israel",       "lat": 32.0853, "lon": 34.7818, "timezone": "Asia/Jerusalem"},
    {"name": "Doha",         "country": "Qatar",        "lat": 25.2854, "lon": 51.5310, "timezone": "Asia/Qatar"},
    {"name": "Riyadh",       "country": "Saudi Arabia", "lat": 24.7136, "lon": 46.6753, "timezone": "Asia/Riyadh"},
    # Asia
    {"name": "Singapore",    "country": "Singapore",    "lat": 1.3521, "lon": 103.8198, "timezone": "Asia/Singapore"},
    {"name": "Hong Kong",    "country": "Hong Kong",    "lat": 22.3193, "lon": 114.1694, "timezone": "Asia/Hong_Kong"},
    {"name": "Tokyo",        "country": "Japan",        "lat": 35.6762, "lon": 139.6503, "timezone": "Asia/Tokyo"},
    {"name": "Kyoto",        "country": "Japan",        "lat": 35.0116, "lon": 135.7681, "timezone": "Asia/Tokyo"},
    {"name": "Seoul",        "country": "South Korea",  "lat": 37.5665, "lon": 126.9780, "timezone": "Asia/Seoul"},
    {"name": "Shanghai",     "country": "China",        "lat": 31.2304, "lon": 121.4737, "timezone": "Asia/Shanghai"},
    {"name": "Beijing",      "country": "China",        "lat": 39.9042, "lon": 116.4074, "timezone": "Asia/Shanghai"},
    {"name": "Bangkok",      "country": "Thailand",     "lat": 13.7563, "lon": 100.5018, "timezone": "Asia/Bangkok"},
    {"name": "Bali",         "country": "Indonesia",    "lat": -8.3405, "lon": 115.0920, "timezone": "Asia/Makassar"},
    {"name": "Kathmandu",    "country": "Nepal",        "lat": 27.7172, "lon": 85.3240, "timezone": "Asia/Kathmandu"},
    {"name": "Colombo",      "country": "Sri Lanka",    "lat": 6.9271,  "lon": 79.8612, "timezone": "Asia/Colombo"},
    # Australia / NZ
    {"name": "Sydney",       "country": "Australia",    "lat": -33.8688, "lon": 151.2093, "timezone": "Australia/Sydney"},
    {"name": "Melbourne",    "country": "Australia",    "lat": -37.8136, "lon": 144.9631, "timezone": "Australia/Melbourne"},
    {"name": "Auckland",     "country": "New Zealand",  "lat": -36.8485, "lon": 174.7633, "timezone": "Pacific/Auckland"},
    # Canada
    {"name": "Toronto",      "country": "Canada",       "lat": 43.6532, "lon": -79.3832, "timezone": "America/Toronto"},
    {"name": "Vancouver",    "country": "Canada",       "lat": 49.2827, "lon": -123.1207, "timezone": "America/Vancouver"},
    {"name": "Montreal",     "country": "Canada",       "lat": 45.5017, "lon": -73.5673, "timezone": "America/Toronto"},
    # Latin America
    {"name": "Mexico City",  "country": "Mexico",       "lat": 19.4326, "lon": -99.1332, "timezone": "America/Mexico_City"},
    {"name": "Buenos Aires", "country": "Argentina",    "lat": -34.6037, "lon": -58.3816, "timezone": "America/Argentina/Buenos_Aires"},
    {"name": "Sao Paulo",    "country": "Brazil",       "lat": -23.5505, "lon": -46.6333, "timezone": "America/Sao_Paulo"},
    {"name": "Rio de Janeiro","country": "Brazil",      "lat": -22.9068, "lon": -43.1729, "timezone": "America/Sao_Paulo"},
    # Africa
    {"name": "Cape Town",    "country": "South Africa", "lat": -33.9249, "lon": 18.4241, "timezone": "Africa/Johannesburg"},
    {"name": "Cairo",        "country": "Egypt",        "lat": 30.0444, "lon": 31.2357, "timezone": "Africa/Cairo"},
    {"name": "Nairobi",      "country": "Kenya",        "lat": -1.2921, "lon": 36.8219, "timezone": "Africa/Nairobi"},
    # Special sacred sites
    {"name": "Mecca",        "country": "Saudi Arabia", "lat": 21.3891, "lon": 39.8579, "timezone": "Asia/Riyadh"},
    {"name": "Bodh Gaya",    "country": "India",        "lat": 24.6961, "lon": 84.9890, "timezone": "Asia/Kolkata"},
    {"name": "Tirumala",     "country": "India",        "lat": 13.6831, "lon": 79.3477, "timezone": "Asia/Kolkata"},
    {"name": "Mt. Kailash",  "country": "Tibet",        "lat": 31.0676, "lon": 81.3119, "timezone": "Asia/Shanghai"},
]


# ════════════════════════════════════════════════════════════════════════
# THEME → PLANETS — Which planets to bring to angular houses for theme
# Based on classical karaka doctrine + KP significator logic
# ════════════════════════════════════════════════════════════════════════

THEME_TO_PLANETS: Dict[str, Dict] = {
    "career_success": {
        "desirable_in_angular": ["Sun", "Mercury", "Saturn", "Jupiter"],
        "favorable_houses":      [10, 1, 11],
        "explanation":          "Sun (recognition), Mercury (skill), Saturn (work-discipline), Jupiter (expansion). Bring to H10 (career), H1 (self), H11 (gains).",
    },
    "wealth_finance": {
        "desirable_in_angular": ["Jupiter", "Venus", "Mercury", "Mars"],
        "favorable_houses":      [2, 11, 9, 10],
        "explanation":          "Jupiter (wealth karaka), Venus (luxuries), Mercury (commerce), Mars (energy). Bring to H2 (wealth), H11 (gains), H9 (fortune), H10 (status).",
    },
    "love_relationships": {
        "desirable_in_angular": ["Venus", "Moon", "Jupiter"],
        "favorable_houses":      [7, 5, 11, 4],
        "explanation":          "Venus (spouse karaka), Moon (emotion), Jupiter (blessings). Bring to H7 (marriage), H5 (romance), H11 (friends), H4 (home).",
    },
    "spiritual_growth": {
        "desirable_in_angular": ["Jupiter", "Ketu", "Sun", "Saturn"],
        "favorable_houses":      [9, 12, 1, 5],
        "explanation":          "Jupiter (dharma), Ketu (moksha/detachment), Sun (self-realization), Saturn (discipline). Bring to H9 (dharma), H12 (moksha), H1 (self), H5 (purva-punya).",
    },
    "health_vitality": {
        "desirable_in_angular": ["Sun", "Jupiter", "Mars"],
        "favorable_houses":      [1, 8, 6],
        "explanation":          "Sun (vitality), Jupiter (immunity), Mars (energy). Keep malefics OUT of H1/H8/H6. Sun in H1/H10 is excellent.",
    },
    "creative_expression": {
        "desirable_in_angular": ["Venus", "Mercury", "Moon", "Jupiter"],
        "favorable_houses":      [5, 3, 11],
        "explanation":          "Venus (arts), Mercury (skill/expression), Moon (creativity), Jupiter (wisdom). Bring to H5 (purva-punya/creativity), H3 (skills), H11 (recognition).",
    },
    "family_home": {
        "desirable_in_angular": ["Moon", "Jupiter", "Venus"],
        "favorable_houses":      [4, 2, 7, 11],
        "explanation":          "Moon (mother/home), Jupiter (wisdom/children), Venus (harmony). Bring to H4 (home), H2 (family), H7 (partnership), H11 (gains).",
    },
    "education_learning": {
        "desirable_in_angular": ["Mercury", "Jupiter", "Sun"],
        "favorable_houses":      [4, 5, 9, 2],
        "explanation":          "Mercury (intellect), Jupiter (wisdom), Sun (clarity). Bring to H4 (formal study), H5 (intelligence), H9 (higher learning), H2 (knowledge).",
    },
    "fame_recognition": {
        "desirable_in_angular": ["Sun", "Jupiter", "Mars"],
        "favorable_houses":      [10, 1, 11, 3],
        "explanation":          "Sun (royalty/fame), Jupiter (blessings), Mars (impact). Bring to H10 (status), H1 (self-image), H11 (popularity), H3 (initiative).",
    },
    "travel_adventure": {
        "desirable_in_angular": ["Mars", "Rahu", "Jupiter"],
        "favorable_houses":      [3, 9, 12, 7],
        "explanation":          "Mars (physical action), Rahu (foreign), Jupiter (long journeys). Bring to H3 (short trips), H9 (long trips), H12 (foreign), H7 (relocation).",
    },
}


# ════════════════════════════════════════════════════════════════════════
# ANGULAR HOUSES (H1/4/7/10) + HOUSE THEMES
# ════════════════════════════════════════════════════════════════════════

ANGULAR_HOUSES: Dict[int, Dict] = {
    1:  {"name": "Lagna",         "weight": 1.0, "theme": "Self, identity, physical body"},
    4:  {"name": "IC",            "weight": 0.9, "theme": "Home, mother, foundations, emotional base"},
    7:  {"name": "Descendant",    "weight": 0.9, "theme": "Spouse, partnerships, others"},
    10: {"name": "MC/Midheaven",  "weight": 1.0, "theme": "Career, public role, status"},
}


HOUSE_THEMES: Dict[int, str] = {
    1:  "Self, body, identity, vitality",
    2:  "Wealth, family, speech, food",
    3:  "Siblings, courage, initiative, short journeys",
    4:  "Home, mother, real estate, emotional comfort",
    5:  "Children, intelligence, romance, creativity, purva-punya",
    6:  "Health, enemies, debts, daily work, service",
    7:  "Spouse, partnerships, business associates",
    8:  "Longevity, transformation, occult, inheritance, sudden events",
    9:  "Dharma, father, guru, long-distance travel, higher learning",
    10: "Career, public role, authority, status",
    11: "Gains, friendships, networks, fulfilled wishes",
    12: "Expenses, moksha, foreign lands, isolation, spiritual liberation",
}


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "astrocartography":  "Jim Lewis 'Astro*Carto*Graphy' (1976) — modern astrology innovation. Lewis's planetary-lines framework is widely used in commercial astrology.",
    "relocation":        "Greek-Hellenistic origins: Vettius Valens (~2nd c.); Hephaestio of Thebes (~5th c.). Modern Vedic relocation per K.N. Rao tradition.",
    "engine_limit":      "Pragmatic astrocartography using relocation method (recast chart at new location). Houses shift with location; planet signs/degrees do not. Full Lewis-style MC/IC/AC/DC lines require equatorial coordinates not exposed by base engine.",
    "kp_horary":         "Relocation in KP tradition: house-cusp shift at new location changes significators; valid for time-prashna queries at specific places.",
    "themes":            "Theme-to-planet mapping per classical karaka doctrine (BPHS Ch. 3) + KP significator logic.",
}
