"""
transit.py — numiVeda Kaaliyo Astro Engine — Module C0 (Transit Engine)

12 endpoints providing day-to-day transit analysis for a native chart.
Uses dashaflow.cast_chart() to cast a chart for the transit moment, then
compares transit planet positions against the native's natal chart.

Public API (all 12 handlers):
    handle_profile                      — Master synthesis
    handle_current_positions            — All 9 planets' sidereal positions today
    handle_personal_houses              — Transits through native's natal houses
    handle_sade_sati                    — Saturn's 7.5-year cycle phase + remaining
    handle_jupiter_transit              — Current Jupiter transit + effects
    handle_saturn_transit               — Current Saturn transit + effects
    handle_rahu_ketu_transit            — Nodes axis (changes every 18 months)
    handle_eclipses_impact              — Eclipse proximity to natal points
    handle_gochara_phala                — Classical Gochara per planet from natal Moon
    handle_ashtaka_varga_transit        — AV strength per current transit
    handle_major_alerts_12months        — Forecasted events next 12 months
    handle_retrograde_periods           — Current/upcoming retrograde personal impact

Classical sources cited in every endpoint output for defensibility.
"""

from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta, date

from astro_helpers import (
    extract_chart_essentials,
    get_chart,
    compute_house_lords,
    SIGNS_ORDER,
    SIGN_TO_LORD,
    HOUSE_TO_LIFE_AREA,
)

from transit_data import (
    GOCHARA_PHALA,
    VEDHA_RULES,
    SADE_SATI_PHASES,
    JUPITER_TRANSIT_RESULTS,
    SATURN_TRANSIT_RESULTS,
    RAHU_KETU_TRANSIT_RESULTS,
    ECLIPSE_IMPACT_ORBS,
    RETROGRADE_IMPACTS,
    ASHTAKA_VARGA_BINDU_RULES,
    BENEFIC_BINDU_THRESHOLD,
    STRONG_BINDU_THRESHOLD,
    WEAK_BINDU_THRESHOLD,
    PLANET_SIGN_CHANGE_CADENCE,
    MAJOR_EVENT_TYPES,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# CORE — CASTING THE TRANSIT CHART
# ════════════════════════════════════════════════════════════════════════
# Strategy (verified from astro_helpers + B3 Prashna pattern):
# cast_chart(dob, time, lat, lon, timezone) treats the inputs as a "birth"
# moment. To get TRANSIT planet positions for any date, we cast a chart
# with that date/time as the "birth" — the planet positions returned are
# the transit positions for that moment. We ignore the chart's dashas
# (irrelevant — those belong to the moment, not the native).
# ════════════════════════════════════════════════════════════════════════

PLANET_NAMES = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]


def _resolve_transit_moment(transit_date: Optional[str],
                            transit_time: Optional[str]) -> Dict[str, str]:
    """Default to today midday IST if not provided. Always returns ISO strings."""
    if transit_date:
        d = transit_date
    else:
        d = date.today().isoformat()
    t = transit_time or "12:00"
    return {"date": d, "time": t}


def _cast_transit_chart(transit_date: str, transit_time: str,
                        lat: float, lon: float,
                        timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Cast a chart for the transit moment at the given location."""
    return get_chart(dob=transit_date, time=transit_time,
                     lat=lat, lon=lon, timezone=timezone)


def _sign_index(sign: str) -> Optional[int]:
    """Return 0-11 index of sign in SIGNS_ORDER, or None if invalid."""
    if not sign or sign not in SIGNS_ORDER:
        return None
    return SIGNS_ORDER.index(sign)


def _house_from_sign(transit_sign: str, reference_sign: str) -> Optional[int]:
    """
    Return house number (1-12) of transit_sign counted from reference_sign.
    Reference_sign is house 1 (whole-sign system).

    Example: reference Aquarius (lagna), transit_sign Sagittarius
             → Sagittarius is house 11 from Aquarius.
    """
    t = _sign_index(transit_sign)
    r = _sign_index(reference_sign)
    if t is None or r is None:
        return None
    return ((t - r) % 12) + 1


def _build_native_essentials(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Cast native's natal chart and extract essentials. Raises on failure."""
    chart = get_chart(
        dob=birth["dob"],
        time=birth["time"],
        lat=birth["lat"],
        lon=birth["lon"],
        timezone=birth.get("timezone", "Asia/Kolkata"),
    )
    return extract_chart_essentials(chart)


# ════════════════════════════════════════════════════════════════════════
# ASHTAKA VARGA — Inline Parashari implementation (BPHS Ch. 67)
# ════════════════════════════════════════════════════════════════════════

def _bhinnashtaka_varga_for_planet(transit_planet: str,
                                   native_essentials: Dict[str, Any]) -> Dict[str, int]:
    """
    Compute Bhinnashtaka Varga (BAV) for a single planet.
    Returns: {sign_name: bindu_count_0_to_8}

    For each of 8 reference points (7 planets + Lagna), check which signs-
    from-reference get a bindu per ASHTAKA_VARGA_BINDU_RULES. Sum across
    references gives the BAV for this planet across all 12 signs.
    """
    if transit_planet not in ASHTAKA_VARGA_BINDU_RULES:
        # Rahu and Ketu don't have classical Parashari AV tables; return zeros
        return {s: 0 for s in SIGNS_ORDER}

    rules = ASHTAKA_VARGA_BINDU_RULES[transit_planet]
    natives_planets = native_essentials.get("planets", {})
    lagna_sign = native_essentials.get("lagna_sign")

    # Gather reference sign for each of 8 reference points
    reference_signs: Dict[str, Optional[str]] = {}
    for ref in ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]:
        p = natives_planets.get(ref, {})
        reference_signs[ref] = p.get("sign") if isinstance(p, dict) else None
    reference_signs["Lagna"] = lagna_sign

    # Build bindu count per sign
    bindu_by_sign: Dict[str, int] = {s: 0 for s in SIGNS_ORDER}
    for ref_name, ref_sign in reference_signs.items():
        if not ref_sign or ref_name not in rules:
            continue
        good_houses = rules[ref_name]  # houses-from-reference that earn a bindu
        ref_idx = _sign_index(ref_sign)
        if ref_idx is None:
            continue
        for h in good_houses:
            target_idx = (ref_idx + h - 1) % 12
            bindu_by_sign[SIGNS_ORDER[target_idx]] += 1

    return bindu_by_sign


def _sarvashtaka_varga(native_essentials: Dict[str, Any]) -> Dict[str, int]:
    """
    Sum of all 7 planets' BAV charts. Returns {sign: 0-56 bindus}.
    """
    sav: Dict[str, int] = {s: 0 for s in SIGNS_ORDER}
    for planet in ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]:
        bav = _bhinnashtaka_varga_for_planet(planet, native_essentials)
        for s in SIGNS_ORDER:
            sav[s] += bav[s]
    return sav


def _classify_transit_strength(bindus: int) -> str:
    """Classify a transit's AV strength."""
    if bindus >= STRONG_BINDU_THRESHOLD:
        return "strong_benefic"
    if bindus >= BENEFIC_BINDU_THRESHOLD:
        return "benefic"
    if bindus <= WEAK_BINDU_THRESHOLD:
        return "weak"
    return "neutral"


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT HANDLERS — 12 total
# ════════════════════════════════════════════════════════════════════════

def handle_current_positions(birth: Dict[str, Any],
                             transit_date: Optional[str] = None,
                             transit_time: Optional[str] = None) -> Dict[str, Any]:
    """Endpoint 2: All 9 planets' current sidereal positions."""
    moment = _resolve_transit_moment(transit_date, transit_time)
    transit_chart = _cast_transit_chart(
        moment["date"], moment["time"],
        birth["lat"], birth["lon"],
        birth.get("timezone", "Asia/Kolkata"),
    )

    positions: Dict[str, Dict[str, Any]] = {}
    t_planets = transit_chart.get("planets", {})
    if isinstance(t_planets, dict):
        for name, pdata in t_planets.items():
            if isinstance(pdata, dict):
                positions[name] = {
                    "sign":          pdata.get("sign"),
                    "degree":        pdata.get("degree"),
                    "nakshatra":     pdata.get("nakshatra"),
                    "pada":          pdata.get("pada"),
                    "is_retrograde": pdata.get("is_retrograde", False),
                    "is_combust":    pdata.get("is_combust", False),
                }

    return {
        "transit_moment": moment,
        "location":       {"lat": birth["lat"], "lon": birth["lon"]},
        "positions":      positions,
        "method":         "Sidereal positions via dashaflow.cast_chart for transit moment",
        "citation":       "Standard Vedic siderealism (Lahiri ayanamsa)",
    }


def handle_personal_houses(birth: Dict[str, Any],
                           transit_date: Optional[str] = None,
                           transit_time: Optional[str] = None) -> Dict[str, Any]:
    """Endpoint 3: Where transit planets fall in native's natal houses."""
    moment = _resolve_transit_moment(transit_date, transit_time)
    native = _build_native_essentials(birth)
    transit_chart = _cast_transit_chart(
        moment["date"], moment["time"],
        birth["lat"], birth["lon"],
        birth.get("timezone", "Asia/Kolkata"),
    )

    lagna_sign = native.get("lagna_sign")
    moon_sign = native.get("moon_sign")

    placements: List[Dict[str, Any]] = []
    t_planets = transit_chart.get("planets", {})
    if isinstance(t_planets, dict):
        for name, pdata in t_planets.items():
            if not isinstance(pdata, dict):
                continue
            t_sign = pdata.get("sign")
            placements.append({
                "planet":              name,
                "transit_sign":        t_sign,
                "transit_degree":      pdata.get("degree"),
                "is_retrograde":       pdata.get("is_retrograde", False),
                "house_from_lagna":    _house_from_sign(t_sign, lagna_sign),
                "house_from_moon":     _house_from_sign(t_sign, moon_sign),
                "life_area_lagna":     HOUSE_TO_LIFE_AREA.get(
                    _house_from_sign(t_sign, lagna_sign) or 0, ""),
            })

    return {
        "transit_moment": moment,
        "native_lagna":   lagna_sign,
        "native_moon":    moon_sign,
        "placements":     placements,
        "method":         "Whole-sign house counting from natal Lagna and natal Moon",
        "citation":       "BPHS Ch. 41; standard Vedic transit interpretation",
    }


def handle_sade_sati(birth: Dict[str, Any],
                     transit_date: Optional[str] = None,
                     transit_time: Optional[str] = None) -> Dict[str, Any]:
    """Endpoint 4: Saturn Sade Sati phase + remaining duration estimate."""
    moment = _resolve_transit_moment(transit_date, transit_time)
    native = _build_native_essentials(birth)
    transit_chart = _cast_transit_chart(
        moment["date"], moment["time"],
        birth["lat"], birth["lon"],
        birth.get("timezone", "Asia/Kolkata"),
    )

    moon_sign = native.get("moon_sign")
    t_saturn = transit_chart.get("planets", {}).get("Saturn", {})
    saturn_sign = t_saturn.get("sign") if isinstance(t_saturn, dict) else None

    if not moon_sign or not saturn_sign:
        return {
            "active":   False,
            "reason":   "Could not resolve native Moon sign or transit Saturn sign",
            "citation": CLASSICAL_CITATIONS["sade_sati"],
        }

    saturn_house_from_moon = _house_from_sign(saturn_sign, moon_sign)

    phase = None
    phase_details = None
    if saturn_house_from_moon == 12:
        phase = "pre_phase"
    elif saturn_house_from_moon == 1:
        phase = "peak_phase"
    elif saturn_house_from_moon == 2:
        phase = "post_phase"

    if phase:
        phase_details = SADE_SATI_PHASES[phase]
        return {
            "active":                  True,
            "phase":                   phase,
            "phase_name":              phase_details["name"],
            "saturn_sign":             saturn_sign,
            "moon_sign":               moon_sign,
            "saturn_house_from_moon":  saturn_house_from_moon,
            "saturn_degree":           t_saturn.get("degree"),
            "domain":                  phase_details["domain"],
            "psychology":              phase_details["psychology"],
            "remediation":             phase_details["remediation"],
            "do_not":                  phase_details["do_not"],
            "duration_per_phase":      phase_details["duration"],
            "transit_moment":          moment,
            "citation":                CLASSICAL_CITATIONS["sade_sati"],
        }

    # Not active — give next-phase information
    if moon_sign in SIGNS_ORDER:
        moon_idx = SIGNS_ORDER.index(moon_sign)
        pre_phase_sign = SIGNS_ORDER[(moon_idx - 1) % 12]
        return {
            "active":                 False,
            "reason":                 f"Saturn currently in {saturn_sign} (house {saturn_house_from_moon} from natal Moon in {moon_sign}). Sade Sati requires Saturn in 12th/1st/2nd from Moon.",
            "saturn_sign":            saturn_sign,
            "moon_sign":              moon_sign,
            "saturn_house_from_moon": saturn_house_from_moon,
            "next_phase_begins_when": f"Saturn enters {pre_phase_sign} (12th from Moon)",
            "transit_moment":         moment,
            "citation":               CLASSICAL_CITATIONS["sade_sati"],
        }

    return {
        "active":   False,
        "reason":   "Could not classify",
        "citation": CLASSICAL_CITATIONS["sade_sati"],
    }


def handle_jupiter_transit(birth: Dict[str, Any],
                           transit_date: Optional[str] = None,
                           transit_time: Optional[str] = None) -> Dict[str, Any]:
    """Endpoint 5: Current Jupiter transit + personal effects."""
    moment = _resolve_transit_moment(transit_date, transit_time)
    native = _build_native_essentials(birth)
    transit_chart = _cast_transit_chart(
        moment["date"], moment["time"],
        birth["lat"], birth["lon"],
        birth.get("timezone", "Asia/Kolkata"),
    )

    t_jup = transit_chart.get("planets", {}).get("Jupiter", {})
    jup_sign = t_jup.get("sign") if isinstance(t_jup, dict) else None
    lagna_sign = native.get("lagna_sign")

    house_from_lagna = _house_from_sign(jup_sign, lagna_sign)
    house_from_moon = _house_from_sign(jup_sign, native.get("moon_sign"))
    effects = JUPITER_TRANSIT_RESULTS.get(house_from_lagna or 0, {})

    # AV bindus for this transit
    bav = _bhinnashtaka_varga_for_planet("Jupiter", native)
    bindus = bav.get(jup_sign, 0) if jup_sign else 0

    return {
        "transit_moment":   moment,
        "jupiter_sign":     jup_sign,
        "jupiter_degree":   t_jup.get("degree") if isinstance(t_jup, dict) else None,
        "is_retrograde":    t_jup.get("is_retrograde", False) if isinstance(t_jup, dict) else False,
        "house_from_lagna": house_from_lagna,
        "house_from_moon":  house_from_moon,
        "results":          effects,
        "av_bindus":        bindus,
        "av_strength":      _classify_transit_strength(bindus),
        "av_note":          f"Bhinnashtaka Varga bindus for Jupiter in {jup_sign}: {bindus}/8",
        "citation":         CLASSICAL_CITATIONS["jupiter_transit"],
    }


def handle_saturn_transit(birth: Dict[str, Any],
                          transit_date: Optional[str] = None,
                          transit_time: Optional[str] = None) -> Dict[str, Any]:
    """Endpoint 6: Saturn deep transit analysis."""
    moment = _resolve_transit_moment(transit_date, transit_time)
    native = _build_native_essentials(birth)
    transit_chart = _cast_transit_chart(
        moment["date"], moment["time"],
        birth["lat"], birth["lon"],
        birth.get("timezone", "Asia/Kolkata"),
    )

    t_sat = transit_chart.get("planets", {}).get("Saturn", {})
    sat_sign = t_sat.get("sign") if isinstance(t_sat, dict) else None
    lagna_sign = native.get("lagna_sign")
    moon_sign = native.get("moon_sign")

    house_from_lagna = _house_from_sign(sat_sign, lagna_sign)
    house_from_moon = _house_from_sign(sat_sign, moon_sign)
    effects = SATURN_TRANSIT_RESULTS.get(house_from_lagna or 0, {})

    bav = _bhinnashtaka_varga_for_planet("Saturn", native)
    bindus = bav.get(sat_sign, 0) if sat_sign else 0

    # Cross-reference Sade Sati status
    sade_sati_active = house_from_moon in (12, 1, 2)

    return {
        "transit_moment":   moment,
        "saturn_sign":      sat_sign,
        "saturn_degree":    t_sat.get("degree") if isinstance(t_sat, dict) else None,
        "is_retrograde":    t_sat.get("is_retrograde", False) if isinstance(t_sat, dict) else False,
        "house_from_lagna": house_from_lagna,
        "house_from_moon":  house_from_moon,
        "sade_sati_active": sade_sati_active,
        "results":          effects,
        "av_bindus":        bindus,
        "av_strength":      _classify_transit_strength(bindus),
        "av_note":          f"Bhinnashtaka Varga bindus for Saturn in {sat_sign}: {bindus}/8",
        "citation":         CLASSICAL_CITATIONS["saturn_transit"],
    }


def handle_rahu_ketu_transit(birth: Dict[str, Any],
                             transit_date: Optional[str] = None,
                             transit_time: Optional[str] = None) -> Dict[str, Any]:
    """Endpoint 7: Rahu-Ketu nodal axis transit."""
    moment = _resolve_transit_moment(transit_date, transit_time)
    native = _build_native_essentials(birth)
    transit_chart = _cast_transit_chart(
        moment["date"], moment["time"],
        birth["lat"], birth["lon"],
        birth.get("timezone", "Asia/Kolkata"),
    )

    t_rahu = transit_chart.get("planets", {}).get("Rahu", {})
    t_ketu = transit_chart.get("planets", {}).get("Ketu", {})
    rahu_sign = t_rahu.get("sign") if isinstance(t_rahu, dict) else None
    ketu_sign = t_ketu.get("sign") if isinstance(t_ketu, dict) else None
    lagna_sign = native.get("lagna_sign")

    rahu_house = _house_from_sign(rahu_sign, lagna_sign)
    ketu_house = _house_from_sign(ketu_sign, lagna_sign)
    effects = RAHU_KETU_TRANSIT_RESULTS.get(rahu_house or 0, {})

    return {
        "transit_moment":  moment,
        "rahu_sign":       rahu_sign,
        "ketu_sign":       ketu_sign,
        "rahu_house":      rahu_house,
        "ketu_house":      ketu_house,
        "results":         effects,
        "note":            "Rahu-Ketu always 180° apart; changes signs every ~18 months",
        "citation":        CLASSICAL_CITATIONS["rahu_ketu_transit"],
    }


def handle_eclipses_impact(birth: Dict[str, Any],
                           transit_date: Optional[str] = None,
                           transit_time: Optional[str] = None) -> Dict[str, Any]:
    """
    Endpoint 8: Eclipse proximity to natal points.
    Since the engine doesn't compute eclipse ephemeris directly, we use
    transit Rahu/Ketu degrees as eclipse-axis indicators and check proximity
    to natal Sun/Moon/Lagna. Real eclipse dates come from ephemeris which
    is upstream of this module (see notes).
    """
    moment = _resolve_transit_moment(transit_date, transit_time)
    native = _build_native_essentials(birth)
    transit_chart = _cast_transit_chart(
        moment["date"], moment["time"],
        birth["lat"], birth["lon"],
        birth.get("timezone", "Asia/Kolkata"),
    )

    t_rahu = transit_chart.get("planets", {}).get("Rahu", {})
    t_ketu = transit_chart.get("planets", {}).get("Ketu", {})

    # Natal critical points
    natal_planets = native.get("planets", {})
    natal_points = {
        "Natal Sun":   natal_planets.get("Sun", {}),
        "Natal Moon":  natal_planets.get("Moon", {}),
        "Natal Lagna": {"sign": native.get("lagna_sign"),
                        "degree": native.get("lagna_degree")},
    }

    impacts: List[Dict[str, Any]] = []
    for axis_name, axis_data in [("Rahu (eclipse axis)", t_rahu),
                                  ("Ketu (eclipse axis)", t_ketu)]:
        if not isinstance(axis_data, dict):
            continue
        a_sign = axis_data.get("sign")
        a_deg = axis_data.get("degree")
        for nat_name, nat_data in natal_points.items():
            if not isinstance(nat_data, dict):
                continue
            n_sign = nat_data.get("sign")
            n_deg = nat_data.get("degree")
            if not (a_sign and n_sign and a_deg is not None and n_deg is not None):
                continue
            # Same sign comparison
            if a_sign == n_sign:
                orb = abs(float(a_deg) - float(n_deg))
                impact_level = None
                if orb <= ECLIPSE_IMPACT_ORBS["exact"]:
                    impact_level = "exact"
                elif orb <= ECLIPSE_IMPACT_ORBS["strong"]:
                    impact_level = "strong"
                elif orb <= ECLIPSE_IMPACT_ORBS["moderate"]:
                    impact_level = "moderate"
                elif orb <= ECLIPSE_IMPACT_ORBS["weak"]:
                    impact_level = "weak"
                if impact_level:
                    impacts.append({
                        "eclipse_axis":  axis_name,
                        "natal_point":   nat_name,
                        "sign":          n_sign,
                        "orb_degrees":   round(orb, 2),
                        "impact_level":  impact_level,
                        "note":          f"Eclipse axis within {round(orb, 2)}° of natal point — heightened sensitivity",
                    })

    return {
        "transit_moment":          moment,
        "method":                  "Transit Rahu/Ketu degree proximity to natal Sun/Moon/Lagna",
        "impacts":                 impacts,
        "active_impacts_count":    len(impacts),
        "note":                    "For specific solar/lunar eclipse calendar dates, use ephemeris upstream. This endpoint detects when eclipse axis (Rahu/Ketu) is currently aspecting natal points.",
        "citation":                CLASSICAL_CITATIONS["eclipses"],
    }


def handle_gochara_phala(birth: Dict[str, Any],
                         transit_date: Optional[str] = None,
                         transit_time: Optional[str] = None) -> Dict[str, Any]:
    """Endpoint 9: Classical Gochara per planet from natal Moon, with Vedha check."""
    moment = _resolve_transit_moment(transit_date, transit_time)
    native = _build_native_essentials(birth)
    transit_chart = _cast_transit_chart(
        moment["date"], moment["time"],
        birth["lat"], birth["lon"],
        birth.get("timezone", "Asia/Kolkata"),
    )

    moon_sign = native.get("moon_sign")
    if not moon_sign:
        return {
            "error":    "Could not resolve native Moon sign",
            "citation": CLASSICAL_CITATIONS["gochara_phala"],
        }

    # Collect house-from-Moon for each transit planet
    t_planets = transit_chart.get("planets", {})
    planet_houses_from_moon: Dict[str, Optional[int]] = {}
    for planet in PLANET_NAMES:
        p = t_planets.get(planet, {})
        if isinstance(p, dict):
            planet_houses_from_moon[planet] = _house_from_sign(
                p.get("sign"), moon_sign)
        else:
            planet_houses_from_moon[planet] = None

    # Build gochara results with Vedha check
    gochara: List[Dict[str, Any]] = []
    for planet, house in planet_houses_from_moon.items():
        if not house:
            continue
        classical = GOCHARA_PHALA.get(planet, {}).get(house, "")
        if not classical:
            continue

        # Check Vedha — does a malefic in vedha house block this?
        vedha_blocked = False
        vedha_blocking_planet = None
        if planet in VEDHA_RULES:
            vedha_house = VEDHA_RULES[planet].get(house)
            if vedha_house:
                # Check if a malefic (Sun/Mars/Saturn/Rahu/Ketu) occupies that house
                for blocking_planet in ["Sun", "Mars", "Saturn", "Rahu", "Ketu"]:
                    bp_house = planet_houses_from_moon.get(blocking_planet)
                    if bp_house == vedha_house and blocking_planet != planet:
                        vedha_blocked = True
                        vedha_blocking_planet = blocking_planet
                        break

        gochara.append({
            "planet":                  planet,
            "house_from_moon":         house,
            "transit_sign":            t_planets.get(planet, {}).get("sign"),
            "classical_result":        classical,
            "vedha_blocked":           vedha_blocked,
            "vedha_blocking_planet":   vedha_blocking_planet,
            "effective_result":        ("BLOCKED by Vedha" if vedha_blocked
                                         else "active") + f" — {classical}",
        })

    return {
        "transit_moment":   moment,
        "native_moon_sign": moon_sign,
        "gochara":          gochara,
        "method":           "Classical Gochara Phala — house-from-natal-Moon results with Vedha (transit blockage) check",
        "citation":         CLASSICAL_CITATIONS["gochara_phala"]
                            + "; " + CLASSICAL_CITATIONS["vedha_rules"],
    }


def handle_ashtaka_varga_transit(birth: Dict[str, Any],
                                 transit_date: Optional[str] = None,
                                 transit_time: Optional[str] = None) -> Dict[str, Any]:
    """Endpoint 10: Which current transits have AV strength."""
    moment = _resolve_transit_moment(transit_date, transit_time)
    native = _build_native_essentials(birth)
    transit_chart = _cast_transit_chart(
        moment["date"], moment["time"],
        birth["lat"], birth["lon"],
        birth.get("timezone", "Asia/Kolkata"),
    )

    # Compute SAV
    sav = _sarvashtaka_varga(native)

    # For each transit planet (the 7 Parashari planets only — nodes excluded)
    t_planets = transit_chart.get("planets", {})
    transit_strength: List[Dict[str, Any]] = []
    for planet in ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]:
        p = t_planets.get(planet, {})
        if not isinstance(p, dict):
            continue
        t_sign = p.get("sign")
        if not t_sign:
            continue
        bav = _bhinnashtaka_varga_for_planet(planet, native)
        bindus_bav = bav.get(t_sign, 0)
        bindus_sav = sav.get(t_sign, 0)
        transit_strength.append({
            "planet":              planet,
            "transit_sign":        t_sign,
            "is_retrograde":       p.get("is_retrograde", False),
            "bav_bindus":          bindus_bav,
            "bav_max":             8,
            "sav_bindus":          bindus_sav,
            "sav_max":             56,
            "strength":            _classify_transit_strength(bindus_bav),
            "interpretation":      (
                "strong supportive transit" if bindus_bav >= STRONG_BINDU_THRESHOLD
                else "supportive transit"   if bindus_bav >= BENEFIC_BINDU_THRESHOLD
                else "weak transit, results limited" if bindus_bav <= WEAK_BINDU_THRESHOLD
                else "neutral transit, moderate results"
            ),
        })

    return {
        "transit_moment":          moment,
        "thresholds": {
            "benefic":  f">= {BENEFIC_BINDU_THRESHOLD} bindus",
            "strong":   f">= {STRONG_BINDU_THRESHOLD} bindus",
            "weak":     f"<= {WEAK_BINDU_THRESHOLD} bindus",
        },
        "transit_strengths":       transit_strength,
        "note":                    "Bhinnashtaka Varga (BAV) gives 0-8 bindus per planet per sign. Sarvashtaka Varga (SAV) aggregates all 7 planets, max 56 per sign. Nodes (Rahu/Ketu) excluded per Parashari tradition.",
        "citation":                CLASSICAL_CITATIONS["ashtaka_varga"],
    }


def handle_major_alerts_12months(birth: Dict[str, Any],
                                 transit_date: Optional[str] = None,
                                 transit_time: Optional[str] = None) -> Dict[str, Any]:
    """
    Endpoint 11: Major transit events forecasted for next 12 months.
    Samples chart at quarterly intervals to detect sign changes for slow planets.
    """
    moment = _resolve_transit_moment(transit_date, transit_time)
    native = _build_native_essentials(birth)
    base_date = datetime.fromisoformat(moment["date"])

    # Sample at +0, +3, +6, +9, +12 months
    sample_offsets_months = [0, 3, 6, 9, 12]
    samples: List[Dict[str, Any]] = []
    for off in sample_offsets_months:
        sample_date = (base_date + timedelta(days=off * 30)).date().isoformat()
        sample_chart = _cast_transit_chart(
            sample_date, moment["time"],
            birth["lat"], birth["lon"],
            birth.get("timezone", "Asia/Kolkata"),
        )
        slow_planets: Dict[str, Optional[str]] = {}
        for slow in ["Jupiter", "Saturn", "Rahu", "Ketu"]:
            p = sample_chart.get("planets", {}).get(slow, {})
            slow_planets[slow] = p.get("sign") if isinstance(p, dict) else None
        samples.append({
            "date":         sample_date,
            "slow_planets": slow_planets,
        })

    # Detect sign changes between consecutive samples
    events: List[Dict[str, Any]] = []
    lagna_sign = native.get("lagna_sign")
    moon_sign = native.get("moon_sign")
    for i in range(1, len(samples)):
        prev = samples[i - 1]
        curr = samples[i]
        for planet in ["Jupiter", "Saturn", "Rahu", "Ketu"]:
            ps = prev["slow_planets"].get(planet)
            cs = curr["slow_planets"].get(planet)
            if ps and cs and ps != cs:
                events.append({
                    "event_type":        f"{planet.lower()}_sign_change",
                    "from_sign":         ps,
                    "to_sign":           cs,
                    "between_dates":     f"{prev['date']} → {curr['date']}",
                    "new_house_lagna":   _house_from_sign(cs, lagna_sign),
                    "new_house_moon":    _house_from_sign(cs, moon_sign),
                    "significance":      (
                        f"Major: {planet} transition to new sign affects "
                        f"{HOUSE_TO_LIFE_AREA.get(_house_from_sign(cs, lagna_sign) or 0, 'multiple areas')}"
                    ),
                })

    # Sade Sati phase boundary check (Saturn entering 12th/1st/2nd from Moon)
    if moon_sign:
        moon_idx = SIGNS_ORDER.index(moon_sign)
        sade_sati_signs = {
            SIGNS_ORDER[(moon_idx - 1) % 12]: "pre_phase",
            SIGNS_ORDER[moon_idx]:             "peak_phase",
            SIGNS_ORDER[(moon_idx + 1) % 12]:  "post_phase",
        }
        for i in range(1, len(samples)):
            ps = samples[i - 1]["slow_planets"].get("Saturn")
            cs = samples[i]["slow_planets"].get("Saturn")
            if cs and cs in sade_sati_signs and ps != cs:
                events.append({
                    "event_type":     "sade_sati_phase_transition",
                    "to_sign":        cs,
                    "phase_entered":  sade_sati_signs[cs],
                    "between_dates":  f"{samples[i-1]['date']} → {samples[i]['date']}",
                    "significance":   f"Saturn entering {sade_sati_signs[cs]} of Sade Sati ({SADE_SATI_PHASES[sade_sati_signs[cs]]['name']})",
                })

    return {
        "transit_moment":  moment,
        "forecast_window": "next 12 months from transit moment",
        "sample_method":   "Quarterly chart snapshots (+0, +3, +6, +9, +12 months)",
        "events_detected": events,
        "event_count":     len(events),
        "cadence_notes":   PLANET_SIGN_CHANGE_CADENCE,
        "citation":        CLASSICAL_CITATIONS["gochara_phala"]
                           + "; " + CLASSICAL_CITATIONS["sade_sati"],
    }


def handle_retrograde_periods(birth: Dict[str, Any],
                              transit_date: Optional[str] = None,
                              transit_time: Optional[str] = None) -> Dict[str, Any]:
    """Endpoint 12: Personal impact of current/upcoming retrogrades."""
    moment = _resolve_transit_moment(transit_date, transit_time)
    native = _build_native_essentials(birth)
    transit_chart = _cast_transit_chart(
        moment["date"], moment["time"],
        birth["lat"], birth["lon"],
        birth.get("timezone", "Asia/Kolkata"),
    )

    lagna_sign = native.get("lagna_sign")
    moon_sign = native.get("moon_sign")

    # Active retrogrades right now
    active_retrogrades: List[Dict[str, Any]] = []
    t_planets = transit_chart.get("planets", {})
    for planet in ["Mercury", "Venus", "Mars", "Jupiter", "Saturn"]:
        p = t_planets.get(planet, {})
        if not isinstance(p, dict):
            continue
        if p.get("is_retrograde"):
            t_sign = p.get("sign")
            impact = RETROGRADE_IMPACTS.get(planet, {})
            active_retrogrades.append({
                "planet":              planet,
                "transit_sign":        t_sign,
                "house_from_lagna":    _house_from_sign(t_sign, lagna_sign),
                "house_from_moon":     _house_from_sign(t_sign, moon_sign),
                "classical_duration":  impact.get("duration", ""),
                "domain":              impact.get("domain", ""),
                "favorable_uses":      impact.get("favorable", ""),
                "challenges":          impact.get("challenges", ""),
                "guidance":            impact.get("guidance", ""),
            })

    return {
        "transit_moment":         moment,
        "active_retrogrades":     active_retrogrades,
        "active_count":           len(active_retrogrades),
        "note_rahu_ketu":         "Rahu and Ketu are always retrograde — excluded from this analysis (their effects covered by rahu_ketu_transit endpoint)",
        "citation":               CLASSICAL_CITATIONS["retrogrades"],
    }


def handle_profile(birth: Dict[str, Any],
                   transit_date: Optional[str] = None,
                   transit_time: Optional[str] = None) -> Dict[str, Any]:
    """
    Endpoint 1 (MASTER): Synthesized transit overview.
    Combines the most important transit signals into a single response.
    """
    moment = _resolve_transit_moment(transit_date, transit_time)
    native = _build_native_essentials(birth)

    # Pull from sub-endpoints
    sade_sati = handle_sade_sati(birth, transit_date, transit_time)
    jupiter = handle_jupiter_transit(birth, transit_date, transit_time)
    saturn = handle_saturn_transit(birth, transit_date, transit_time)
    rahu_ketu = handle_rahu_ketu_transit(birth, transit_date, transit_time)
    retrogrades = handle_retrograde_periods(birth, transit_date, transit_time)
    eclipses = handle_eclipses_impact(birth, transit_date, transit_time)

    # Quick AV snapshot — just for the slow movers
    av_snapshot: Dict[str, Any] = {}
    transit_chart = _cast_transit_chart(
        moment["date"], moment["time"],
        birth["lat"], birth["lon"],
        birth.get("timezone", "Asia/Kolkata"),
    )
    t_planets = transit_chart.get("planets", {})
    for planet in ["Jupiter", "Saturn"]:
        p = t_planets.get(planet, {})
        if isinstance(p, dict):
            t_sign = p.get("sign")
            if t_sign:
                bav = _bhinnashtaka_varga_for_planet(planet, native)
                av_snapshot[planet] = {
                    "sign":    t_sign,
                    "bindus":  bav.get(t_sign, 0),
                    "max":     8,
                }

    # Build headline summary
    headlines: List[str] = []
    if sade_sati.get("active"):
        headlines.append(
            f"⚠️ Sade Sati ACTIVE — {sade_sati.get('phase_name')}: {sade_sati.get('domain', '')[:120]}"
        )
    if jupiter.get("av_strength") in ("strong_benefic", "benefic"):
        headlines.append(
            f"✅ Jupiter in {jupiter.get('jupiter_sign')} (house {jupiter.get('house_from_lagna')}) — {jupiter.get('av_strength')}"
        )
    if saturn.get("sade_sati_active"):
        headlines.append(
            f"⚠️ Saturn transit affecting Moon area (house {saturn.get('house_from_moon')} from Moon)"
        )
    if retrogrades.get("active_count", 0) > 0:
        retro_names = [r["planet"] for r in retrogrades.get("active_retrogrades", [])]
        headlines.append(
            f"↩️  Active retrogrades: {', '.join(retro_names)}"
        )
    if eclipses.get("active_impacts_count", 0) > 0:
        headlines.append(
            f"🌑 Eclipse axis impacting natal points ({eclipses['active_impacts_count']} hit(s))"
        )

    return {
        "transit_moment":  moment,
        "native_summary": {
            "lagna":      native.get("lagna_sign"),
            "moon":       native.get("moon_sign"),
            "current_md": native.get("current_md"),
            "current_ad": native.get("current_ad"),
        },
        "headlines":               headlines,
        "sade_sati":               sade_sati,
        "jupiter":                 jupiter,
        "saturn":                  saturn,
        "rahu_ketu":               rahu_ketu,
        "retrogrades":             retrogrades,
        "eclipses":                eclipses,
        "ashtaka_varga_snapshot":  av_snapshot,
        "method": "Master transit synthesis: Sade Sati phase, Jupiter/Saturn house transits, Rahu-Ketu axis, retrogrades, eclipse-axis proximity, Ashtaka Varga strength of slow movers",
        "citations": {
            "primary":         CLASSICAL_CITATIONS["gochara_phala"],
            "ashtaka_varga":   CLASSICAL_CITATIONS["ashtaka_varga"],
            "sade_sati":       CLASSICAL_CITATIONS["sade_sati"],
            "vedha":           CLASSICAL_CITATIONS["vedha_rules"],
        },
    }
