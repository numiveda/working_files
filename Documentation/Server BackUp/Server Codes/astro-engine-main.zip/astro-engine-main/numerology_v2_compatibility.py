"""
numerology_v2_compatibility.py — Two-person numerological matching.
"""

from typing import Dict, Any
from numerology_v2 import (
    pythagorean_bhagyank, pythagorean_destiny, pythagorean_moolank,
    pythagorean_soul_urge, NUMBER_RULER,
)


# Standard numerological compatibility matrix (1-9)
# Scores 0-10: 10 = ideal, 0 = severe friction
COMPATIBILITY_MATRIX = {
    (1,1): 7, (1,2): 8, (1,3): 9, (1,4): 5, (1,5): 7, (1,6): 6, (1,7): 6, (1,8): 4, (1,9): 8,
    (2,2): 6, (2,3): 6, (2,4): 7, (2,5): 5, (2,6): 9, (2,7): 7, (2,8): 8, (2,9): 6,
    (3,3): 7, (3,4): 5, (3,5): 8, (3,6): 9, (3,7): 6, (3,8): 5, (3,9): 9,
    (4,4): 6, (4,5): 4, (4,6): 7, (4,7): 5, (4,8): 9, (4,9): 5,
    (5,5): 6, (5,6): 5, (5,7): 8, (5,8): 6, (5,9): 7,
    (6,6): 8, (6,7): 6, (6,8): 7, (6,9): 9,
    (7,7): 5, (7,8): 5, (7,9): 7,
    (8,8): 7, (8,9): 5,
    (9,9): 7,
}


def _matrix_lookup(a: int, b: int) -> int:
    """Symmetric lookup."""
    a, b = min(a, b), max(a, b)
    if a in (11, 22, 33): a = sum(int(d) for d in str(a))
    if b in (11, 22, 33): b = sum(int(d) for d in str(b))
    a = max(1, min(9, a))
    b = max(1, min(9, b))
    return COMPATIBILITY_MATRIX.get((a, b), 5)


def numerology_compatibility(
    name_a: str, dob_a: str,
    name_b: str, dob_b: str,
) -> Dict[str, Any]:
    """Full numerological compatibility scoring across multiple dimensions."""

    lp_a = pythagorean_bhagyank(dob_a)["value"]
    lp_b = pythagorean_bhagyank(dob_b)["value"]
    de_a = pythagorean_destiny(name_a)["value"]
    de_b = pythagorean_destiny(name_b)["value"]
    su_a = pythagorean_soul_urge(name_a)["value"]
    su_b = pythagorean_soul_urge(name_b)["value"]
    ml_a = pythagorean_moolank(dob_a)["value"]
    ml_b = pythagorean_moolank(dob_b)["value"]

    scores = {
        "life_path":   {"a": lp_a, "b": lp_b, "score": _matrix_lookup(lp_a, lp_b)},
        "destiny":     {"a": de_a, "b": de_b, "score": _matrix_lookup(de_a, de_b)},
        "soul_urge":   {"a": su_a, "b": su_b, "score": _matrix_lookup(su_a, su_b)},
        "moolank":     {"a": ml_a, "b": ml_b, "score": _matrix_lookup(ml_a, ml_b)},
    }
    # Weighted total — life path is most important
    weights = {"life_path": 3, "destiny": 2, "soul_urge": 2, "moolank": 1}
    weighted = sum(scores[k]["score"] * weights[k] for k in weights)
    max_possible = sum(10 * w for w in weights.values())
    overall_pct = round(100 * weighted / max_possible, 1)

    if overall_pct >= 80:
        interpretation = "Excellent match — strong harmony across multiple dimensions"
    elif overall_pct >= 65:
        interpretation = "Good match — workable harmony with mature awareness"
    elif overall_pct >= 50:
        interpretation = "Moderate match — needs conscious effort and communication"
    else:
        interpretation = "Challenging match — significant friction, requires significant adjustment"

    return {
        "person_a": {"name": name_a, "dob": dob_a},
        "person_b": {"name": name_b, "dob": dob_b},
        "scores": scores,
        "weighted_total": weighted,
        "max_possible": max_possible,
        "overall_percent": overall_pct,
        "interpretation": interpretation,
        "interpretation_note": "Numerological compatibility weighed by Life Path > Destiny ≈ Soul Urge > Moolank",
    }
