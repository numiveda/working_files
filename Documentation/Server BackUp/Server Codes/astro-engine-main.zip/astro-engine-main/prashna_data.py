"""
prashna_data.py — Static classical data for Prashna (Horary) module

Sources (all public domain):
- Tajik Neelakanthi (~16th c. CE)
- Prashna Marga (~1649 CE, Kerala tradition)
- Brihat Samhita with Bhattotpala commentary (~10th c. CE)
- Daivagya Vallabha
- Krishnamurti Paddhati methodology (1970s, system principles)
- Hora Sara, Sarvartha Chintamani — Prashna sections
"""

# ════════════════════════════════════════════════════════════════════════
# 1. QUESTION CATEGORIES & PRIMARY HOUSES
# Source: Prashna Marga + classical Tajik categorization
# ════════════════════════════════════════════════════════════════════════

QUESTION_CATEGORIES = {
    "marriage": {
        "description":     "Questions about marriage, partnership, spouse",
        "primary_house":   7,
        "secondary_houses":[2, 8, 11],
        "primary_karaka":  "Venus",
        "secondary_karakas":["Jupiter (for women's marriage)", "Moon (general)"],
        "interpretation_focus": "7th house lord placement; Venus condition; Moon's relation to 7th",
    },
    "career": {
        "description":     "Questions about job, profession, business success",
        "primary_house":   10,
        "secondary_houses":[2, 6, 11],
        "primary_karaka":  "Sun",
        "secondary_karakas":["Saturn (service)", "Mercury (business)", "Jupiter (advisory)"],
        "interpretation_focus": "10th lord strength; AmK position; Sun's dignity",
    },
    "health": {
        "description":     "Questions about illness, recovery, surgery, treatment",
        "primary_house":   1,
        "secondary_houses":[6, 8, 12],
        "primary_karaka":  "Lagna lord + Moon",
        "secondary_karakas":["Sun (vitality)", "Saturn (chronic)", "Mars (acute)"],
        "interpretation_focus": "Lagna affliction; 6th house planets; Moon's strength",
    },
    "travel": {
        "description":     "Questions about journeys, foreign travel, relocation",
        "primary_house":   3,
        "secondary_houses":[9, 12, 7],
        "primary_karaka":  "Moon (movement) + Mercury (travel)",
        "secondary_karakas":["Jupiter (long-distance)", "Rahu (foreign)"],
        "interpretation_focus": "3rd lord (short trips), 9th lord (long), 12th (foreign)",
    },
    "finance": {
        "description":     "Questions about money, investment, gain, loss",
        "primary_house":   2,
        "secondary_houses":[5, 9, 11],
        "primary_karaka":  "Jupiter (wealth) + Venus (luxury)",
        "secondary_karakas":["Mercury (commerce)", "Moon (cash flow)"],
        "interpretation_focus": "2nd and 11th lord conjunction/exchange; dhana yoga presence",
    },
    "missing_item": {
        "description":     "Questions about lost/stolen objects, missing persons",
        "primary_house":   2,  # for objects (also wealth/possession)
        "secondary_houses":[4, 7, 11],
        "primary_karaka":  "Mercury (if object) / Moon (if person)",
        "secondary_karakas":["Rahu (theft/hidden)"],
        "interpretation_focus": "Lagna lord + Moon relation; sign type (movable/fixed/dual) for direction; 7th house for thief if applicable",
    },
    "legal_matter": {
        "description":     "Questions about court cases, disputes, litigation",
        "primary_house":   6,
        "secondary_houses":[7, 8, 9],
        "primary_karaka":  "Mars (litigation) + Jupiter (favorable outcome)",
        "secondary_karakas":["Saturn (delays)", "Mercury (negotiations)"],
        "interpretation_focus": "6th lord vs 7th lord strength; benefic aspects to lagna",
    },
    "general": {
        "description":     "Open question; let chart speak through Lagna + Moon synthesis",
        "primary_house":   1,
        "secondary_houses":[7, 4, 10],
        "primary_karaka":  "Lagna lord + Moon",
        "secondary_karakas":["All four kendra lords"],
        "interpretation_focus": "Lagna strength; Moon's nakshatra and aspects; ruling planet of the moment",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 2. LAGNA-BASED INTERPRETATION RULES
# Source: Prashna Marga Ch. 5
# ════════════════════════════════════════════════════════════════════════

LAGNA_SIGNATURE_INTERPRETATIONS = {
    # Movable signs (Chara): Aries, Cancer, Libra, Capricorn
    "Aries":       {"quality": "movable_fire",    "answer_speed": "fast yes/no; quick resolution", "direction": "east"},
    "Taurus":      {"quality": "fixed_earth",     "answer_speed": "slow; possibly delayed", "direction": "south"},
    "Gemini":      {"quality": "dual_air",        "answer_speed": "variable; depends on Moon", "direction": "west"},
    "Cancer":      {"quality": "movable_water",   "answer_speed": "moderate; with emotional involvement", "direction": "north"},
    "Leo":         {"quality": "fixed_fire",      "answer_speed": "stable; clear yes or no", "direction": "east"},
    "Virgo":       {"quality": "dual_earth",      "answer_speed": "deliberate; analytical", "direction": "south"},
    "Libra":       {"quality": "movable_air",     "answer_speed": "fast but conditional", "direction": "west"},
    "Scorpio":     {"quality": "fixed_water",     "answer_speed": "stable; hidden factors", "direction": "north"},
    "Sagittarius": {"quality": "dual_fire",       "answer_speed": "variable; benefit through patience", "direction": "east"},
    "Capricorn":   {"quality": "movable_earth",   "answer_speed": "slow start, accelerates", "direction": "south"},
    "Aquarius":    {"quality": "fixed_air",       "answer_speed": "stable; unconventional path", "direction": "west"},
    "Pisces":      {"quality": "dual_water",      "answer_speed": "fluctuating; intuition-led", "direction": "north"},
}


# Sign type (movable/fixed/dual) → answer modality
SIGN_TYPE_INTERPRETATION = {
    "movable":  "Quick resolution; outcome will change rapidly; YES probable but watch for fluctuation",
    "fixed":    "Stable outcome; what you see will hold; YES or NO answer is firm",
    "dual":     "Variable; outcome has multiple possibilities; answer depends on conditions",
}


# ════════════════════════════════════════════════════════════════════════
# 3. MOON'S ROLE IN PRASHNA
# Source: Prashna Marga Ch. 3
# ════════════════════════════════════════════════════════════════════════

MOON_PRASHNA_RULES = {
    "moon_in_kendra":     "Moon in 1/4/7/10 from Lagna = stable, clear answer; Moon's nakshatra reveals deeper indication",
    "moon_in_trikona":    "Moon in 1/5/9 = favorable; fortune supports",
    "moon_in_dushthana":  "Moon in 6/8/12 = obstacles; resolution requires patience or remedy",
    "moon_in_3_or_11":    "Moon in 3 or 11 = movement, gains through effort",

    "waxing_moon":        "Shukla paksha — building, growth, YES tendency",
    "waning_moon":        "Krishna paksha — release, completion, NO or 'let go' tendency",
    "full_moon":          "Strong outcome — Purnima brings clarity",
    "new_moon":           "Veiled answer — Amavasya hides outcomes",

    "moon_nakshatra_significance": "The nakshatra of Moon at the moment of question reveals the deeper nature of the answer. Use nakshatra lord as additional significator.",

    "void_of_course": "If Moon makes no major aspect (conjunction/opposition/square/trine) before leaving current sign, the matter will not progress as intended (Western astrology concept).",
}


# ════════════════════════════════════════════════════════════════════════
# 4. KP HORARY SYSTEM
# Source: Krishnamurti Paddhati Vol. 4 (methodology)
# ════════════════════════════════════════════════════════════════════════

KP_HORARY_SYSTEM = {
    "_description": "Krishnamurti Paddhati uses 249 sub-lord divisions of the zodiac. Each degree has Sign lord + Star lord + Sub lord. The Sub-lord determines the actual outcome.",

    "ruling_planets_method": {
        "description": "At the moment of question, identify the Ruling Planets (RPs):",
        "components": [
            "1. Day lord (weekday's ruler)",
            "2. Moon's sign lord (Rashi adhipathi)",
            "3. Moon's star lord (Nakshatra adhipathi)",
            "4. Moon's sub-lord (in 249 system)",
            "5. Lagna's sign lord",
            "6. Lagna's star lord",
            "7. Lagna's sub-lord",
        ],
        "use": "Ruling planets at moment of question MUST be involved in the planets that bring fruition",
    },

    "cuspal_sublord_principle": {
        "description": "The Sub-lord of the relevant house cusp determines the answer.",
        "method": "For question about marriage: check 7th cusp's sub-lord. If sub-lord signifies 2/7/11 — marriage will happen. If 1/6/10 — denial.",
        "houses_for_questions": {
            "marriage":     {"positive": [2, 7, 11], "negative": [1, 6, 10]},
            "career":       {"positive": [2, 6, 10, 11], "negative": [5, 8, 12]},
            "litigation":   {"positive": [1, 6, 10, 11], "negative": [7, 8, 12]},
            "health":       {"positive": [1, 5, 9, 11], "negative": [6, 8, 12]},
            "finance":      {"positive": [2, 6, 10, 11], "negative": [5, 8, 12]},
            "travel":       {"positive": [3, 9, 12], "negative": [4, 5]},
            "purchase":     {"positive": [2, 11, 12], "negative": [5, 6, 10]},
            "sale":         {"positive": [5, 10, 11], "negative": [2, 6, 12]},
        },
    },

    "house_groupings_kp": {
        "1_5_9":   "trine — favorable, blessings",
        "2_6_10":  "growth, professional gain, food",
        "3_7_11":  "communication, relationships, social gain",
        "4_8_12":  "endings, loss, foreign matters, moksha",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 5. AROODHA LAGNA (JAIMINI HORARY TECHNIQUE)
# Source: Jaimini Sutras + Maharishi Parashara's commentary
# ════════════════════════════════════════════════════════════════════════

AROODHA_LAGNA = {
    "_description": "Aroodha Lagna (AL) is calculated by counting from Lagna lord's house, the same number of houses to find the Aroodha. It represents 'how the world sees the matter' or 'the public manifestation'.",

    "calculation_rule": "From Lagna, count houses to Lagna's lord. From Lagna's lord, count the same number of houses forward. That sign = Aroodha Lagna.",

    "exception": "If Aroodha falls in the 1st or 7th house from Lagna, then take the 10th sign from that position (Vighatta rule).",

    "interpretation": {
        "AL_with_benefic": "Public manifestation of the matter is favorable",
        "AL_with_malefic": "Public manifestation is obstructed; people see it negatively",
        "AL_in_movable":   "Public situation will change quickly",
        "AL_in_fixed":     "Public perception is stable",
    },

    "uses_in_prashna": [
        "AL position shows how the question's outcome will be seen publicly",
        "Aspects to AL indicate forces affecting public perception",
        "AL lord's strength = real-world manifestation strength",
    ],
}


# ════════════════════════════════════════════════════════════════════════
# 6. SWARA (BREATH/NOSTRIL) ANALYSIS
# Source: Swara Yoga (Shiva Swarodaya, ~14th c. CE)
# ════════════════════════════════════════════════════════════════════════

SWARA_RULES = {
    "_description": "Swara Yoga teaches that the dominant nostril at the moment of question reveals the answer's nature. Engine returns the rule; downstream practitioner/app captures actual breath state.",

    "ida_nadi_left": {
        "active_nostril": "left",
        "energy":         "lunar, cool, feminine, receptive",
        "favorable_for":  "calm matters, meditation, accumulation, healing, home, asking favors",
        "answer_color":   "YES for receptive matters; NO for action-requiring matters",
    },

    "pingala_nadi_right": {
        "active_nostril": "right",
        "energy":         "solar, hot, masculine, active",
        "favorable_for":  "action, conflict, competition, sales, new beginnings, exiting",
        "answer_color":   "YES for action matters; NO for passive/waiting matters",
    },

    "sushumna_both": {
        "active_nostril": "both equally / shifting",
        "energy":         "central, spiritual",
        "favorable_for":  "spiritual matters only; AVOID worldly decisions",
        "answer_color":   "Neither YES nor NO clearly — defer the question",
    },

    "swara_classical_rule": "At the moment of question, observe which nostril breath flows more strongly. Match the activity type (passive=left, active=right) to the active nostril for affirmative answer.",

    "matching_with_chart": {
        "ascending_signs":  ["Aries", "Gemini", "Leo", "Libra", "Sagittarius", "Aquarius"],
        "descending_signs": ["Taurus", "Cancer", "Virgo", "Scorpio", "Capricorn", "Pisces"],
        "rule": "If Lagna is in ascending sign + right nostril active = YES for action. If Lagna is descending + left nostril active = YES for receptive matters.",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 7. TIMING TECHNIQUES (when will it resolve?)
# Source: Prashna Marga Ch. 12 + classical Tajik
# ════════════════════════════════════════════════════════════════════════

TIMING_TECHNIQUES = {
    "sign_type_timing": {
        "movable":  "fast (hours to days)",
        "fixed":    "slow (months to years)",
        "dual":     "variable (intermediate)",
    },

    "house_timing": {
        "1": "immediate / today",
        "2": "very soon / weeks",
        "3": "soon with effort / 1-3 months",
        "4": "stable timeframe / 3-6 months",
        "5": "moderate / 6 months to 1 year",
        "6": "with obstacles / 1-2 years",
        "7": "partnership-dependent / 1 year",
        "8": "after transformation / 2-3 years or never",
        "9": "blessed timing / 1-2 years",
        "10": "career-dependent / months",
        "11": "with gains / variable",
        "12": "foreign/hidden / 2+ years",
    },

    "lord_aspect_timing": "Time = degrees between question karaka and resolution karaka. 1 degree ≈ 1 month for monthly matters, 1 day for daily matters",

    "moon_to_significator_time": "Count degrees from Moon to next aspect with relevant karaka. Each degree = 2 hours for hourly matters, 1 day for daily.",

    "dasha_indicator": "Major events follow the dasha sequence. Current MD/AD lord's house involvement = high probability of resolution in current period.",
}


# ════════════════════════════════════════════════════════════════════════
# 8. YES/NO ANSWER SYNTHESIS RULES
# Source: Prashna Marga Ch. 4 + practitioner tradition
# ════════════════════════════════════════════════════════════════════════

YES_NO_SYNTHESIS = {
    "_description": "Multiple classical methods exist. Engine returns each method's indication; downstream LLM synthesizes.",

    "method_1_lagna_lord": {
        "rule":         "Lagna lord in kendra/trikona = YES. In dushthana = NO.",
        "yes_houses":   [1, 4, 5, 7, 9, 10],
        "no_houses":    [6, 8, 12],
        "neutral":      [2, 3, 11],
    },

    "method_2_moon_aspect": {
        "rule":         "Moon's relation to question karaka. Trine/conjunction = YES. Square/opposition with malefic = NO.",
    },

    "method_3_benefic_malefic_lagna": {
        "rule":         "Benefics in/aspecting Lagna = YES. Malefics in/aspecting Lagna = NO.",
        "benefics":     ["Jupiter", "Venus", "Mercury (if not afflicted)", "Moon (if waxing)"],
        "malefics":     ["Saturn", "Mars", "Sun (mild)", "Rahu", "Ketu", "Mercury (if afflicted)"],
    },

    "method_4_kp_sublord": {
        "rule":         "Sub-lord of relevant house cusp signifies positive or negative houses. See KP_HORARY_SYSTEM.cuspal_sublord_principle.",
    },

    "method_5_aroodha": {
        "rule":         "Aroodha Lagna placement and lord strength.",
    },

    "synthesis_principle": "If 3+ methods say YES, lean YES. If 3+ say NO, lean NO. Mixed = uncertain, defer or rephrase the question.",
}


# ════════════════════════════════════════════════════════════════════════
# 9. CLASSICAL ADJUSTMENT RULES (Prashna Marga special techniques)
# ════════════════════════════════════════════════════════════════════════

PRASHNA_MARGA_RULES = {
    "rashi_adhipati": "The lord of the ascending sign IS the primary significator of the querent",

    "panchapakshi": {
        "_description": "Five-bird (Panchapakshi) system attributes birds to nakshatra groups. Bird in 'eating' mode = activity-favorable.",
        "birds":        ["Vulture", "Owl", "Crow", "Cock", "Peacock"],
        "modes":        ["Eating", "Walking", "Ruling", "Sleeping", "Dying"],
        "note":         "Engine returns reference only; full Panchapakshi computation requires solar time + nakshatra mapping.",
    },

    "chaitra_aramaka": "Special chart casting where Lagna is the rising sign at SUNRISE of question day, not the moment-of-question. Used for certain political/national questions.",

    "shadbala_check": "Significator karaka should have at least middle shadbala (planetary strength) for affirmative answer",

    "yatra_prashna": "For travel questions specifically: check Moon's nakshatra lord + 3rd from Moon + 9th from Lagna",

    "vivaha_prashna": "For marriage: 7th lord + Venus + Moon's nakshatra lord must combine positively",

    "rogadhipati": "For disease: 6th lord's strength + position. 6th lord in kendra = curable. 6th lord in dushthana with malefics = chronic or grave.",
}
