"""
pregnancy.py — numiVeda Kaaliyo Astro Engine — Module F5 (Pregnancy Astrology)

Six endpoints for classical Vedic pregnancy/santana astrology:

    handle_conception_muhurta       — Day-by-day Garbhadhana muhurta window scan
    handle_santana_yogas            — Couple's combined chart fertility analysis
    handle_prenatal_remedies        — Month-by-month (1-9) Garbha Sanskara remedies
    handle_bala_arishta             — Early childhood affliction yoga screen
    handle_newborn_naming_window    — Namakarana muhurta + akshara letters
    handle_garbha_shanti_remedies   — Remedies for problematic pregnancies

═══════════════════════════════════════════════════════════════════════════
DELIBERATELY OMITTED — Garbha Linga Nirnaya (foetal gender determination)
═══════════════════════════════════════════════════════════════════════════

BPHS Ch. 73 verses 19-24 and Jataka Parijata Ch. 5 contain classical methods
for foetal sex determination from the conception chart, lagna at query time,
or the gestational moon position. These methods are intentionally NOT
implemented in this engine due to compliance with the Pre-Conception and
Pre-Natal Diagnostic Techniques (Prohibition of Sex Selection) Act, 1994
(India), which criminalizes any technique that determines or communicates
foetal sex regardless of method, intent, or framing.

PCPNDT Section 22 prohibits communication of foetal sex "in any manner";
Section 23 prescribes 3-5 years imprisonment + ₹10,000-1,00,000 fine;
Section 28 imposes personal criminal liability on company directors.

The 2008 Bombay HC ruling in re: Voluntary Health Association of Punjab
v. Union of India, and 2011 PCPNDT amendments, explicitly cover astrological
sex prediction. The Supreme Court (2013, SCC) interpreted "technique" to
include the underlying determinative method itself, not just its
consumer-facing presentation.

This omission is deliberate engineering policy, not a knowledge gap.

═══════════════════════════════════════════════════════════════════════════

Design (per HANDOVER_v7 carry-forward, reuse-first):
    P1 — All astronomy through cast_chart (dashaflow).
    P2 — Reuse: chart["yogas"], chart["jaimini_karakas"]["Putrakaraka"],
         chart["dashas"], chart["panchang"], chart["planets"], all
         pre-computed by cast_chart. F5 only interprets with a pregnancy lens.
    P3 — F6b pet_muhurta._compute_abhijit_muhurta, _band_from_score,
         _compute_sunrise_sunset patterns are CONCEPTUALLY borrowed but
         re-implemented in F5 to avoid coupling (F6b is pet-acquisition
         specific). Same window-scan architecture, different scoring.
    P5 — F5 has its own NAKSHATRA_AKSHARAS_F5, GARBHADHANA_FAVORABLE_NAKS,
         BALA_ARISHTA_YOGAS, F5_CITATIONS, F5_DISCLAIMER, PCPNDT_NOTE.
         No coupling to other F-modules.

Liability framing (non-negotiable):
    Every response carries `disclaimer` and `pcpndt_note` fields.
    bala_arishta and garbha_shanti carry an additional
    `sensitive_topic_disclaimer` field. No endpoint accepts or emits
    gender-related fields at any layer.

Public API:
    handle_conception_muhurta(female_chart, male_chart, location,
                              start_date, end_date, max_days) -> dict
    handle_santana_yogas(person1_chart, person2_chart) -> dict
    handle_prenatal_remedies(mother_chart, gestational_month,
                             father_chart=None) -> dict
    handle_bala_arishta(child_chart) -> dict
    handle_newborn_naming_window(child_chart, naming_location) -> dict
    handle_garbha_shanti_remedies(mother_chart, gestational_month=None,
                                  father_chart=None) -> dict

Author: Claude (F5, 2026-05-18)
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import date, datetime, timedelta


# Foundation imports (guarded — Principle 1) ─────────────────────────────────
try:
    from dashaflow import cast_chart
except ImportError as e:
    raise ImportError(f"F5 pregnancy requires dashaflow.cast_chart: {e}")

try:
    from astro_helpers import SIGNS_ORDER, SIGN_TO_LORD
except ImportError as e:
    raise ImportError(f"F5 pregnancy requires astro_helpers: {e}")


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL TABLES
# ════════════════════════════════════════════════════════════════════════

# Akshara (syllable) mapping for newborn naming via Janma Nakshatra pada.
# Sources: Muhurta Chintamani Ch. 6; Brihat Parashara Hora Shastra Ch. 100.
# F5 keeps its own copy to avoid coupling to pet_astro.py.
NAKSHATRA_AKSHARAS_F5: Dict[str, List[str]] = {
    "Ashwini":      ["Chu", "Che", "Cho", "La"],
    "Bharani":      ["Li", "Lu", "Le", "Lo"],
    "Krittika":     ["A", "I", "U", "E"],
    "Rohini":       ["O", "Va", "Vi", "Vu"],
    "Mrigashira":   ["Ve", "Vo", "Ka", "Ki"],
    "Ardra":        ["Ku", "Gha", "Nga", "Chha"],
    "Punarvasu":    ["Ke", "Ko", "Ha", "Hi"],
    "Pushya":       ["Hu", "He", "Ho", "Da"],
    "Ashlesha":     ["Di", "Du", "De", "Do"],
    "Magha":        ["Ma", "Mi", "Mu", "Me"],
    "Purva Phalguni":  ["Mo", "Ta", "Ti", "Tu"],
    "Uttara Phalguni": ["Te", "To", "Pa", "Pi"],
    "Hasta":        ["Pu", "Sha", "Na", "Tha"],
    "Chitra":       ["Pe", "Po", "Ra", "Ri"],
    "Swati":        ["Ru", "Re", "Ro", "Ta"],
    "Vishakha":     ["Ti", "Tu", "Te", "To"],
    "Anuradha":     ["Na", "Ni", "Nu", "Ne"],
    "Jyeshtha":     ["No", "Ya", "Yi", "Yu"],
    "Mula":         ["Ye", "Yo", "Bha", "Bhi"],
    "Purva Ashadha":   ["Bhu", "Dha", "Pha", "Dha"],
    "Uttara Ashadha":  ["Bhe", "Bho", "Ja", "Ji"],
    "Shravana":     ["Khi", "Khu", "Khe", "Kho"],
    "Dhanishta":    ["Ga", "Gi", "Gu", "Ge"],
    "Shatabhisha":  ["Go", "Sa", "Si", "Su"],
    "Purva Bhadrapada":  ["Se", "So", "Da", "Di"],
    "Uttara Bhadrapada": ["Du", "Tha", "Jha", "Da"],
    "Revati":       ["De", "Do", "Cha", "Chi"],
}


# Conception-favorable nakshatras for Garbhadhana muhurta.
# Source: Muhurta Chintamani Ch. 5; Brihat Samhita Ch. 99 verses 1-7.
# Classical text: "Garbhadhane subhe rikshe" — auspicious nakshatras include
# the sattvik and creation-supporting stars.
GARBHADHANA_FAVORABLE_NAKS = {
    "Rohini":         "Highly auspicious — Brahma's nakshatra, creation principle",
    "Mrigashira":     "Auspicious — Soma's nakshatra, lunar/fertile",
    "Pushya":         "Most auspicious — supreme nourishment, Jupiter-ruled",
    "Uttara Phalguni":"Auspicious — fixed, stable conception",
    "Hasta":          "Auspicious — manifestation, skillful creation",
    "Swati":          "Auspicious — independent movement, gentle",
    "Anuradha":       "Auspicious — devotion, harmonious",
    "Uttara Ashadha": "Auspicious — fixed nakshatra, lasting offspring",
    "Shravana":       "Auspicious — Vishnu's nakshatra, divine grace",
    "Uttara Bhadrapada": "Auspicious — wisdom, long-lived progeny",
    "Revati":         "Auspicious — Pushan's nakshatra, nourishment",
}

# Conception-INAUSPICIOUS nakshatras to avoid for Garbhadhana.
# Source: Muhurta Chintamani Ch. 5; classical avoidance lists.
GARBHADHANA_INAUSPICIOUS_NAKS = {
    "Bharani":     "Avoid — Yama's nakshatra, death principle",
    "Krittika":    "Avoid — sharp/cutting, Agni's nakshatra (combustive)",
    "Ardra":       "Avoid — Rudra's nakshatra, destructive principle",
    "Ashlesha":    "Avoid — serpent nakshatra, entangling",
    "Magha":       "Avoid — Pitra (ancestral) nakshatra, conception inauspicious",
    "Purva Phalguni": "Avoid — relaxation, lethargic for conception",
    "Chitra":      "Avoid — variable, illusory",
    "Vishakha":    "Avoid — forked, divided intention",
    "Jyeshtha":    "Avoid — eldest/depleted, classical contraindication",
    "Mula":        "Avoid — root/destruction, severance principle",
    "Purva Ashadha": "Avoid — declaring war, conflict-prone",
    "Purva Bhadrapada": "Avoid — fierce, ascetic-oriented",
    "Shatabhisha": "Avoid — hundred-physician (illness focus)",
    "Dhanishta":   "Avoid — wealth-oriented but classical Garbhadhana exclusion",
}

# Bala-Arishta yogas (early childhood affliction combinations).
# Source: BPHS Ch. 8 (Balarishta); Jataka Tatva; Saravali Ch. 7.
# These yogas, in classical literature, indicate periods of difficulty for
# a child's first 8-12 years. Modern reading: sensitive psycho-spiritual
# windows requiring extra Shanti remedies, NOT medical diagnoses.
BALA_ARISHTA_YOGAS = {
    "moon_with_malefic_no_benefic_aspect": {
        "name":       "Moon afflicted by malefics without benefic aspect",
        "classical":  "BPHS Ch. 8.2; Jataka Tatva 5.14",
        "severity":   "high",
        "interpretation": "Period of emotional sensitivity in early childhood; classical remedy: maternal Shanti practices",
    },
    "moon_in_6_8_12_with_malefic": {
        "name":       "Moon in 6/8/12 with malefic aspect",
        "classical":  "BPHS Ch. 8.4",
        "severity":   "moderate",
        "interpretation": "Indicator for paying close attention to child's health/wellbeing in early years",
    },
    "lagna_lord_combust": {
        "name":       "Lagna lord combust",
        "classical":  "Saravali Ch. 7.18",
        "severity":   "moderate",
        "interpretation": "Vitality consideration for early years; classical remedy: Surya Shanti",
    },
    "lagna_lord_in_6_8_12": {
        "name":       "Lagna lord in dusthana (6/8/12)",
        "classical":  "BPHS Ch. 8.6",
        "severity":   "moderate",
        "interpretation": "Strengthening the lagna lord through classical Shanti supports early-life resilience",
    },
    "saturn_in_lagna_no_benefic": {
        "name":       "Saturn in lagna without benefic aspect",
        "classical":  "Jataka Tatva 5.21",
        "severity":   "moderate",
        "interpretation": "Indicator for patient nurturing in early years; classical remedy: Shani Shanti by parents",
    },
    "all_malefics_in_kendra": {
        "name":       "All major malefics in kendras (1/4/7/10)",
        "classical":  "BPHS Ch. 8.12",
        "severity":   "high",
        "interpretation": "Strong indicator for systematic Bala Shanti practices",
    },
    "moon_paksha_bala_weak": {
        "name":       "Moon with weak paksha bala (near new moon)",
        "classical":  "BPHS Ch. 8.3",
        "severity":   "low",
        "interpretation": "Mild Moon-strengthening practices recommended",
    },
}


# Prenatal remedies by gestational month (1-9).
# Sources: Garbha Upanishad; Sushruta Sharira Sthana Ch. 3-4;
# Charaka Sharira Sthana Ch. 4 (Garbha Sanskara framework).
# Each month corresponds to a planetary lordship + developmental focus.
PRENATAL_MONTH_REMEDIES: Dict[int, Dict[str, Any]] = {
    1: {
        "planet_lord":   "Venus (Sukra)",
        "development":   "Conception consolidation, initial cell formation",
        "garbha_sanskara": "Listen to Vedic chants, especially Sri Suktam; maintain sattvic diet",
        "deity_worship": "Sri Lakshmi for prosperity of the conception",
        "mantras":       ["Om Shree Mahalakshmyai Namah (108x daily)",
                          "Sri Suktam (audio listening)"],
        "charity":       "White rice, white cloth, dairy to Brahmins on Friday",
        "avoidances":    "Travel, intense exertion, fasting, emotional shocks",
    },
    2: {
        "planet_lord":   "Mars (Mangala)",
        "development":   "Formation of basic structure, the 'kalala' to 'budbuda' stage",
        "garbha_sanskara": "Chant Hanuman Chalisa for vital strength",
        "deity_worship": "Hanuman for protection, Subrahmanya for healthy formation",
        "mantras":       ["Om Hanumate Namah (108x daily)",
                          "Maha Mrityunjaya Mantra (for protection)"],
        "charity":       "Red lentils, jaggery, copper items on Tuesday",
        "avoidances":    "Spicy/heating foods, anger, conflict",
    },
    3: {
        "planet_lord":   "Jupiter (Guru)",
        "development":   "Limb formation begins; consciousness anchoring per Garbha Upanishad",
        "garbha_sanskara": "Listen to Bhagavad Gita, Vishnu Sahasranama; cultivate wisdom",
        "deity_worship": "Vishnu, Brihaspati for wisdom transmission",
        "mantras":       ["Om Gurave Namah (108x daily)",
                          "Vishnu Sahasranama (audio listening)"],
        "charity":       "Yellow items — turmeric, yellow cloth, gold to learned Brahmins on Thursday",
        "avoidances":    "Negative speech, ill company, rajasik food in excess",
    },
    4: {
        "planet_lord":   "Sun (Surya)",
        "development":   "Skeletal structure consolidates; soul firmly enters per classical view",
        "garbha_sanskara": "Aditya Hridaya Stotra daily; sunlight exposure (gentle, morning)",
        "deity_worship": "Surya, Vishnu — for vitality and dharma",
        "mantras":       ["Om Suryaya Namah (108x daily)",
                          "Aditya Hridaya Stotra (Sundays especially)"],
        "charity":       "Wheat, jaggery, red cloth, copper on Sunday",
        "avoidances":    "Excessive heat, conflict with father-figures, dark/tamasik environments",
    },
    5: {
        "planet_lord":   "Moon (Chandra)",
        "development":   "Mind (manas) develops fully; emotional patterning begins",
        "garbha_sanskara": "Chant Lalita Sahasranama; maintain peaceful, cool environment",
        "deity_worship": "Devi (Parvati, Lalita) for nurturing emotional foundation",
        "mantras":       ["Om Chandraya Namah (108x daily)",
                          "Lalita Sahasranama (or selected verses)"],
        "charity":       "Milk, white rice, silver, white cloth on Monday",
        "avoidances":    "Emotional disturbance, late nights, excess salt",
    },
    6: {
        "planet_lord":   "Saturn (Shani)",
        "development":   "Hair, nails, fine structures; karmic patterns consolidate",
        "garbha_sanskara": "Hanuman Chalisa (Saturn-pacifying); structured daily routine",
        "deity_worship": "Hanuman (Saturn-protector), Shani for karmic ease",
        "mantras":       ["Om Sham Shanaischaraya Namah (108x daily)",
                          "Hanuman Chalisa (Saturdays especially)"],
        "charity":       "Sesame oil, black sesame, iron, black cloth to elderly/needy on Saturday",
        "avoidances":    "Servants' or laborers' suffering nearby, restless travel, alcohol exposure",
    },
    7: {
        "planet_lord":   "Mercury (Budha)",
        "development":   "Subtle sensory faculties refine; intelligence anchors",
        "garbha_sanskara": "Recite Vishnu Sahasranama; gentle music, classical ragas",
        "deity_worship": "Vishnu, Saraswati for intellect/expression",
        "mantras":       ["Om Budhaya Namah (108x daily)",
                          "Saraswati Stotra"],
        "charity":       "Green moong dal, green cloth, books on Wednesday",
        "avoidances":    "Mental overstimulation, gossip, harsh communication around mother",
    },
    8: {
        "planet_lord":   "Mother's lagna lord (variable per chart)",
        "development":   "Vital energy (prana) consolidation; classical caution period",
        "garbha_sanskara": "Maha Mrityunjaya Mantra daily for vital protection",
        "deity_worship": "Shiva, Vishnu — protective deities",
        "mantras":       ["Maha Mrityunjaya Mantra (108x daily)",
                          "Rudram Chamakam (if accessible)"],
        "charity":       "As prescribed by family priest for the specific lagna lord",
        "avoidances":    "Long travel, surgical interventions unless medically necessary, emotional stress",
    },
    9: {
        "planet_lord":   "Sun + Moon (preparation for emergence)",
        "development":   "Final consolidation; emergence preparation",
        "garbha_sanskara": "Santana Gopal Stotra; Vishnu Sahasranama daily",
        "deity_worship": "Santana Gopala (child Krishna form), Lakshmi-Narayana",
        "mantras":       ["Santana Gopala Mantra (Om Devaki Sutam Govindam...)",
                          "Garbha Raksha Stotra"],
        "charity":       "Generous daana per family means; clothing, food to expectant mothers in need",
        "avoidances":    "Stressful environments, negative news, sleep disruption",
    },
}


# Garbha Shanti remedies for problematic pregnancies (recurrent miscarriage,
# complications, classical Garbha-pida indicators).
# Sources: Brahma Vaivarta Purana; Garuda Purana Acharaka kanda;
# classical Garbha Raksha texts.
GARBHA_SHANTI_REMEDIES = {
    "core_practices": [
        "Daily recitation of Garbha Raksha Stotra (24 verses) by the mother or partner",
        "Santana Gopala Mantra: 'Om Devaki Sutam Govindam Vasudevam Jagatpatim, "
        "Dehi Me Tanayam Krishnam Tvamaham Sharanam Gatah' (108x daily)",
        "Lighting a ghee lamp before a Krishna or Vishnu image, daily morning",
        "Listening to Vishnu Sahasranama daily during pregnancy",
    ],
    "weekly_practices": [
        "Friday: Sri Suktam recitation, white-colored sattvic foods, charity to married women",
        "Saturday: Hanuman Chalisa (protective; Saturn-pacifying)",
        "Tuesday: Hanuman Bahuk for any specific obstacle",
        "Ekadashi: Fasting (gentle, fruit-and-milk; only if medically safe)",
    ],
    "specific_to_recurrent_difficulties": [
        "Putrakameshti Yajna (traditional fire ceremony) — to be performed by qualified priest",
        "Pilgrimage to a Santana Gopala or Garbha Raksha temple "
        "(e.g. Sri Garbharakshambika temple, Thirukkarukavur, Tamil Nadu, "
        "if circumstances permit)",
        "Donation to Anna Daana (food charity) on each Ekadashi",
        "Wearing a consecrated Krishna-themed or Lakshmi-themed pendant by the mother",
    ],
    "lifestyle_alignment": [
        "Sattvic diet — minimize tamasik (heavy, stale) and rajasik (overstimulating) foods",
        "Maintain regular sleep, avoid extreme emotional environments",
        "Surround with peaceful sounds — Vedic chants, classical music, nature",
        "Daily abhyanga (gentle oil massage) by mother, only if comfortable and unless medically contraindicated",
    ],
    "caveats": [
        "These are CLASSICAL SPIRITUAL practices, not medical interventions.",
        "Continue all prescribed medical care; classical practices are supplementary.",
        "Consult family priest for personalized Yajna details if undertaking.",
        "Practices should be discontinued if any cause physical or emotional distress.",
    ],
}


# Santana Yoga combinations — couple's combined-chart analysis.
# Sources: Phaladeepika Ch. 13; Jataka Parijata Ch. 15;
# B.V. Raman, "Hindu Predictive Astrology" Ch. on Santana.
SANTANA_YOGA_INDICATORS = {
    "strong_5th_house_emphasis": {
        "name": "Strong 5th house in both charts",
        "interpretation": "Classical indicator of supportive santana yoga; "
                          "blessings of progeny present in both partners' karma",
    },
    "jupiter_well_placed_both": {
        "name": "Jupiter well-placed in both charts",
        "interpretation": "Putra-karaka strong in both — classical favorable indicator",
    },
    "putrakaraka_strong_both": {
        "name": "Putrakaraka (Jaimini) strong in both",
        "interpretation": "Both partners' karaka for children dignified",
    },
    "fifth_lord_dignified": {
        "name": "5th lord in own/exalted/friend's sign",
        "interpretation": "5th-bhava promise classically supported",
    },
    "fifth_lord_in_dusthana": {
        "name": "5th lord in 6/8/12",
        "interpretation": "Classical indicator of delay or obstacle to santana; "
                          "remedies (Garbha Shanti, Santana Gopala) classically advised",
    },
    "jupiter_in_dusthana": {
        "name": "Jupiter in 6/8/12 in either chart",
        "interpretation": "Reduced putra-karaka strength; Jupiter-strengthening "
                          "remedies classically advised (Thursday fasting, "
                          "Guru mantra, Brihaspati worship)",
    },
    "ketu_in_5th": {
        "name": "Ketu in 5th house in either chart",
        "interpretation": "Classical Putra Dosha indicator; Santana Gopala "
                          "mantra and Vishnu worship classically prescribed",
    },
    "putra_dosha_full": {
        "name": "Multiple afflictions to 5th house and Jupiter",
        "interpretation": "Full Putra Dosha — comprehensive Garbha Shanti "
                          "practices classically prescribed",
    },
}


# ════════════════════════════════════════════════════════════════════════
# CITATIONS + DISCLAIMERS
# ════════════════════════════════════════════════════════════════════════

F5_CITATIONS: Dict[str, List[str]] = {
    "conception_muhurta": [
        "Varahamihira, Brihat Samhita, Ch. 99 verses 1-7 (Garbhadhana naksatras)",
        "Muhurta Chintamani, Ch. 5 (Garbhadhana muhurta)",
        "Parashara, BPHS, Ch. 73 (Niryana Dhyaya — conception principles)",
    ],
    "santana_yogas": [
        "Phaladeepika, Ch. 13 (Putra Bhava analysis)",
        "Jataka Parijata, Ch. 15 (Santana indicators)",
        "BPHS, Ch. 100 (5th house determinations)",
        "B.V. Raman, Hindu Predictive Astrology, Santana chapter",
    ],
    "prenatal_remedies": [
        "Garbha Upanishad (developmental month-by-month framework)",
        "Sushruta Samhita, Sharira Sthana, Ch. 3-4 (gestational stages)",
        "Charaka Samhita, Sharira Sthana, Ch. 4 (Garbha Sanskara)",
    ],
    "bala_arishta": [
        "Parashara, BPHS, Ch. 8 (Balarishta Adhyaya)",
        "Jataka Tatva, Ch. 5 (early-childhood yogas)",
        "Saravali, Ch. 7 (Bala arishta yogas)",
    ],
    "newborn_naming_window": [
        "Muhurta Chintamani, Ch. 6 (Namakarana)",
        "BPHS, Ch. 100 (Janma Nakshatra → akshara mapping)",
        "Smriti Chandrika (10th day Namakarana classical timing)",
    ],
    "garbha_shanti_remedies": [
        "Brahma Vaivarta Purana, Garbha Raksha sections",
        "Garuda Purana, Acharaka Kanda",
        "Santana Gopala texts (Vaishnava tradition)",
    ],
}


F5_DISCLAIMER = (
    "Classical Vedic astrology and ayurvedic-shastra analysis. This is a "
    "scholarly/practice-oriented output, not medical advice. All classical "
    "remedies are supplementary spiritual practices, not substitutes for "
    "medical care. Always continue prescribed medical treatment under "
    "qualified physicians."
)


PCPNDT_NOTE = (
    "Foetal gender determination is NOT supported by this engine. This is a "
    "deliberate policy decision in compliance with the Pre-Conception and "
    "Pre-Natal Diagnostic Techniques (Prohibition of Sex Selection) Act, "
    "1994 (India), which criminalizes any communication of foetal sex. "
    "Requests for gender prediction will not be processed regardless of "
    "framing, jurisdiction, or context."
)


F5_SENSITIVE_TOPIC_DISCLAIMER = (
    "This endpoint addresses a sensitive subject. Classical indicators "
    "describe karmic patterns and traditional shanti practices, NOT medical "
    "or psychological diagnoses. Output should be received in a spirit of "
    "contemplation and devotion, not as prognosis. If experiencing actual "
    "difficulties, consult qualified medical and emotional support resources."
)


# ════════════════════════════════════════════════════════════════════════
# INTERNAL HELPERS
# ════════════════════════════════════════════════════════════════════════

def _cast_or_error(birth: Dict[str, Any], context: str) -> Dict[str, Any]:
    """Cast a chart, returning either chart or error dict."""
    try:
        return cast_chart(
            dob=birth["dob"], time=birth["time"],
            lat=birth["lat"], lon=birth["lon"],
            timezone=birth.get("timezone", "Asia/Kolkata"),
        )
    except Exception as e:
        return {"_error": f"Chart cast failed ({context}): {e}"}


def _check_gender_field_in_input(d: Dict[str, Any]) -> Optional[str]:
    """
    Defense-in-depth guard: scan input dict (recursively, shallow) for any
    field name or string value containing gender-prediction keywords.
    If found, return a rejection reason. Returns None if clean.

    This is a belt-and-suspenders check; Pydantic schemas at the route layer
    are the primary defense (gender fields simply don't exist as inputs).
    """
    forbidden_keys = {
        "gender", "sex", "boy_or_girl", "male_or_female",
        "predict_gender", "predict_sex", "linga", "linga_nirnaya",
        "child_gender", "foetal_sex", "fetus_gender", "fetus_sex",
    }
    if not isinstance(d, dict):
        return None
    for k, v in d.items():
        if isinstance(k, str) and k.lower() in forbidden_keys:
            return f"Input field '{k}' is not permitted under PCPNDT compliance policy."
        if isinstance(v, str):
            vl = v.lower()
            # Only block if it's clearly a gender-prediction request, not
            # incidental mentions (e.g. "Lakshmi Stotra for women" is fine).
            if "predict gender" in vl or "predict sex" in vl or \
               "boy or girl" in vl or "male or female" in vl:
                return f"Input value for '{k}' contains gender-prediction language; rejected per PCPNDT policy."
        if isinstance(v, dict):
            inner = _check_gender_field_in_input(v)
            if inner:
                return inner
    return None


def _house_lord(house_num: int, chart: Dict[str, Any]) -> Optional[str]:
    """Lord of the sign occupying house N from lagna."""
    lagna = chart.get("lagna", {})
    lagna_sign = lagna.get("sign")
    if not lagna_sign or lagna_sign not in SIGNS_ORDER:
        return None
    lagna_idx = SIGNS_ORDER.index(lagna_sign)
    target_sign_idx = (lagna_idx + house_num - 1) % 12
    target_sign = SIGNS_ORDER[target_sign_idx]
    return SIGN_TO_LORD.get(target_sign)


def _planet_state(planet: str, chart: Dict[str, Any]) -> Dict[str, Any]:
    """Compact state summary of a planet."""
    p = chart.get("planets", {}).get(planet, {})
    shadbala = chart.get("shadbala", {}).get(planet, {})
    if isinstance(shadbala, dict):
        rupas = shadbala.get("total_rupas") or shadbala.get("total") or shadbala.get("rupas")
    else:
        rupas = shadbala
    return {
        "planet":         planet,
        "sign":           p.get("sign"),
        "house":          p.get("house"),
        "dignity":        p.get("dignity"),
        "is_combust":     p.get("is_combust", False),
        "is_retrograde":  p.get("is_retrograde", False),
        "shadbala_rupas": rupas,
    }


def _is_planet_in_dusthana(planet: str, chart: Dict[str, Any]) -> bool:
    """Is the planet in 6th, 8th, or 12th house?"""
    h = chart.get("planets", {}).get(planet, {}).get("house")
    return h in (6, 8, 12)


def _is_planet_dignified(planet: str, chart: Dict[str, Any]) -> bool:
    """Planet in exalted / mooltrikona / own_sign / great_friend?"""
    dignity = (chart.get("planets", {}).get(planet, {}).get("dignity") or "").lower()
    return dignity in {"exalted", "mooltrikona", "own_sign", "great_friend"}


def _is_planet_afflicted(planet: str, chart: Dict[str, Any]) -> bool:
    """Planet in debilitated / great_enemy / enemy + combust?"""
    p = chart.get("planets", {}).get(planet, {})
    dignity = (p.get("dignity") or "").lower()
    if dignity in {"debilitated", "great_enemy"}:
        return True
    if dignity == "enemy" and p.get("is_combust"):
        return True
    return False


def _moon_paksha(chart: Dict[str, Any]) -> Optional[str]:
    """Determine Shukla (waxing) vs Krishna (waning) paksha."""
    panchang = chart.get("panchang", {})
    tithi = panchang.get("tithi") if isinstance(panchang, dict) else None
    if isinstance(tithi, dict):
        return tithi.get("paksha")
    # Fallback via sign-distance
    moon = chart.get("planets", {}).get("Moon", {})
    sun = chart.get("planets", {}).get("Sun", {})
    if moon.get("sign") and sun.get("sign") and moon["sign"] in SIGNS_ORDER:
        m_idx = SIGNS_ORDER.index(moon["sign"])
        s_idx = SIGNS_ORDER.index(sun["sign"])
        dist = (m_idx - s_idx) % 12
        return "Shukla" if dist < 6 else "Krishna"
    return None


def _score_garbhadhana_day(query_date: str, location: Dict[str, Any],
                           female_chart: Dict[str, Any]) -> Dict[str, Any]:
    """
    Score a single day for Garbhadhana muhurta suitability.

    Transparent scoring (per HANDOVER_v6 Section 8.5):
    every point added/subtracted has a human-readable label.
    """
    # Cast a query-time chart at midday of query_date for panchang analysis
    query_birth = {
        "dob":      query_date,
        "time":     "12:00",  # midday for stable panchang
        "lat":      location.get("lat", 0.0),
        "lon":      location.get("lon", 0.0),
        "timezone": location.get("timezone", "Asia/Kolkata"),
    }
    day_chart = _cast_or_error(query_birth, f"day_chart {query_date}")
    if "_error" in day_chart:
        return {"date": query_date, "score": 0, "verdict": "error",
                "reasons": [day_chart["_error"]]}

    score = 0
    reasons: List[str] = []

    # Operative nakshatra of the day (Moon's nakshatra)
    moon_nak = day_chart.get("planets", {}).get("Moon", {}).get("nakshatra")
    if moon_nak in GARBHADHANA_FAVORABLE_NAKS:
        score += 4
        reasons.append(f"+4 Moon in {moon_nak} ({GARBHADHANA_FAVORABLE_NAKS[moon_nak]})")
    elif moon_nak in GARBHADHANA_INAUSPICIOUS_NAKS:
        score -= 4
        reasons.append(f"-4 Moon in {moon_nak} ({GARBHADHANA_INAUSPICIOUS_NAKS[moon_nak]})")
    else:
        reasons.append(f"+0 Moon in {moon_nak} (classical neutral)")

    # Paksha — Shukla (waxing) preferred
    paksha = _moon_paksha(day_chart)
    if paksha == "Shukla":
        score += 2
        reasons.append("+2 Shukla Paksha (waxing Moon, classical preference)")
    elif paksha == "Krishna":
        score -= 1
        reasons.append("-1 Krishna Paksha (waning Moon, classical caution)")

    # Vara (weekday) — Monday, Wednesday, Thursday, Friday favored
    panchang = day_chart.get("panchang", {})
    vara = panchang.get("vara", {}) if isinstance(panchang, dict) else {}
    vara_name = vara.get("name", "") if isinstance(vara, dict) else ""
    if vara_name in {"Monday", "Wednesday", "Thursday", "Friday"}:
        score += 2
        reasons.append(f"+2 {vara_name} (auspicious vara for Garbhadhana)")
    elif vara_name in {"Tuesday", "Saturday"}:
        score -= 1
        reasons.append(f"-1 {vara_name} (Mars/Saturn vara, classical caution)")

    # Tithi — even tithis classically favored (some sources); avoid Chaturthi/Navami/Chaturdashi/Amavasya
    tithi = panchang.get("tithi", {}) if isinstance(panchang, dict) else {}
    tithi_num = tithi.get("number") if isinstance(tithi, dict) else None
    tithi_name = tithi.get("name", "") if isinstance(tithi, dict) else ""
    bad_tithis = {"Chaturthi", "Navami", "Chaturdashi", "Amavasya", "Purnima"}
    if tithi_name in bad_tithis:
        score -= 2
        reasons.append(f"-2 {tithi_name} tithi (classical Garbhadhana avoidance)")
    elif tithi_num and tithi_num % 2 == 0:
        score += 1
        reasons.append(f"+1 Even tithi ({tithi_name}, classical preference)")

    # Female chart's running dasha — 5th lord, Jupiter, Moon, Venus as MD/AD favorable
    dashas = female_chart.get("dashas", {})
    maha = dashas.get("maha", {}) if isinstance(dashas, dict) else {}
    antar = dashas.get("antar", {}) if isinstance(dashas, dict) else {}
    md_planet = maha.get("planet") if isinstance(maha, dict) else None
    ad_planet = antar.get("planet") if isinstance(antar, dict) else None
    fifth_lord = _house_lord(5, female_chart)
    fav_planets = {"Jupiter", "Moon", "Venus"}
    if fifth_lord:
        fav_planets.add(fifth_lord)
    if md_planet in fav_planets:
        score += 2
        reasons.append(f"+2 Female chart in {md_planet} Mahadasha (santana-favorable)")
    if ad_planet in fav_planets:
        score += 1
        reasons.append(f"+1 Female chart in {ad_planet} Antardasha (santana-favorable)")
    if md_planet in {"Rahu", "Ketu", "Saturn"} and md_planet != fifth_lord:
        score -= 1
        reasons.append(f"-1 Female chart in {md_planet} Mahadasha (classical caution)")

    # Jupiter strength on the day
    if _is_planet_dignified("Jupiter", day_chart):
        score += 1
        reasons.append("+1 Jupiter dignified on the day")
    if _is_planet_afflicted("Jupiter", day_chart):
        score -= 1
        reasons.append("-1 Jupiter afflicted on the day")

    # Yoga (panchang) — avoid Vyatipata, Vaidhriti
    yoga_data = panchang.get("yoga", {}) if isinstance(panchang, dict) else {}
    yoga_name = yoga_data.get("name", "") if isinstance(yoga_data, dict) else ""
    if yoga_name in {"Vyatipata", "Vaidhriti", "Vajra", "Vyaghata"}:
        score -= 2
        reasons.append(f"-2 {yoga_name} yoga (classical Garbhadhana avoidance)")

    # Verdict band
    if score >= 8:
        verdict = "highly_auspicious"
    elif score >= 5:
        verdict = "auspicious"
    elif score >= 2:
        verdict = "neutral"
    elif score >= -1:
        verdict = "caution"
    else:
        verdict = "avoid"

    return {
        "date":             query_date,
        "score":            score,
        "verdict":          verdict,
        "moon_nakshatra":   moon_nak,
        "paksha":           paksha,
        "vara":             vara_name,
        "tithi":            tithi_name,
        "yoga":             yoga_name,
        "reasons":          reasons,
    }


def _date_range(start_iso: str, end_iso: str, max_days: int = 30) -> List[str]:
    """Generate list of YYYY-MM-DD date strings, capped at max_days."""
    try:
        start = datetime.strptime(start_iso, "%Y-%m-%d").date()
        end = datetime.strptime(end_iso, "%Y-%m-%d").date()
    except Exception:
        return []
    if end < start:
        end = start
    delta = (end - start).days + 1
    if delta > max_days:
        delta = max_days
    return [(start + timedelta(days=i)).isoformat() for i in range(delta)]


def _check_bala_arishta_yogas(child_chart: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Screen for classical Bala-Arishta yogas in a child's chart.
    Returns list of yoga findings with classical citations.
    """
    findings: List[Dict[str, Any]] = []
    planets = child_chart.get("planets", {})

    moon = planets.get("Moon", {})
    moon_house = moon.get("house")
    moon_sign = moon.get("sign")
    moon_aspects = moon.get("aspects", []) if isinstance(moon.get("aspects"), list) else []

    malefics = {"Sun", "Mars", "Saturn", "Rahu", "Ketu"}
    benefics = {"Jupiter", "Venus", "Mercury"}  # Mercury benefic unless with malefic only

    # Check 1: Moon afflicted by malefics without benefic aspect
    moon_aspecting_planets = set()
    for asp in moon_aspects:
        if isinstance(asp, dict):
            p = asp.get("planet") or asp.get("from")
            if p:
                moon_aspecting_planets.add(p)
        elif isinstance(asp, str):
            moon_aspecting_planets.add(asp)
    malefic_aspects_moon = moon_aspecting_planets & malefics
    benefic_aspects_moon = moon_aspecting_planets & benefics
    if malefic_aspects_moon and not benefic_aspects_moon:
        findings.append({
            **BALA_ARISHTA_YOGAS["moon_with_malefic_no_benefic_aspect"],
            "details": f"Moon aspected by malefics ({sorted(malefic_aspects_moon)}) "
                       "without benefic aspect"
        })

    # Check 2: Moon in 6/8/12 with malefic
    if moon_house in (6, 8, 12) and malefic_aspects_moon:
        findings.append({
            **BALA_ARISHTA_YOGAS["moon_in_6_8_12_with_malefic"],
            "details": f"Moon in house {moon_house} with malefic aspect from "
                       f"{sorted(malefic_aspects_moon)}"
        })

    # Check 3: Lagna lord combust
    lagna_lord = _house_lord(1, child_chart)
    if lagna_lord:
        lord_state = planets.get(lagna_lord, {})
        if lord_state.get("is_combust"):
            findings.append({
                **BALA_ARISHTA_YOGAS["lagna_lord_combust"],
                "details": f"Lagna lord {lagna_lord} is combust"
            })
        # Check 4: Lagna lord in dusthana
        if lord_state.get("house") in (6, 8, 12):
            findings.append({
                **BALA_ARISHTA_YOGAS["lagna_lord_in_6_8_12"],
                "details": f"Lagna lord {lagna_lord} in house {lord_state.get('house')}"
            })

    # Check 5: Saturn in lagna without benefic aspect
    saturn = planets.get("Saturn", {})
    if saturn.get("house") == 1:
        saturn_aspects = saturn.get("aspects", []) if isinstance(saturn.get("aspects"), list) else []
        saturn_aspecting = set()
        for asp in saturn_aspects:
            if isinstance(asp, dict):
                p = asp.get("planet") or asp.get("from")
                if p:
                    saturn_aspecting.add(p)
            elif isinstance(asp, str):
                saturn_aspecting.add(asp)
        if not (saturn_aspecting & benefics):
            findings.append({
                **BALA_ARISHTA_YOGAS["saturn_in_lagna_no_benefic"],
                "details": "Saturn in lagna without benefic aspect"
            })

    # Check 6: All major malefics in kendras (1/4/7/10)
    major_malefics = {"Sun", "Mars", "Saturn"}
    kendras = {1, 4, 7, 10}
    in_kendra = [p for p in major_malefics
                 if planets.get(p, {}).get("house") in kendras]
    if len(in_kendra) == len(major_malefics):
        findings.append({
            **BALA_ARISHTA_YOGAS["all_malefics_in_kendra"],
            "details": f"Major malefics {sorted(in_kendra)} all in kendras"
        })

    # Check 7: Moon paksha bala weak (near new moon — within ~30° of Sun)
    moon_long = moon.get("degree")
    sun_long = planets.get("Sun", {}).get("degree")
    if isinstance(moon_long, (int, float)) and isinstance(sun_long, (int, float)):
        # Need absolute longitudes; if only sign+degree, use sign-relative
        moon_sign_v = moon.get("sign")
        sun_sign_v = planets.get("Sun", {}).get("sign")
        if moon_sign_v and sun_sign_v and moon_sign_v in SIGNS_ORDER:
            moon_abs = SIGNS_ORDER.index(moon_sign_v) * 30 + moon_long
            sun_abs = SIGNS_ORDER.index(sun_sign_v) * 30 + sun_long
            elong = abs((moon_abs - sun_abs) % 360)
            if elong > 180:
                elong = 360 - elong
            if elong < 30:
                findings.append({
                    **BALA_ARISHTA_YOGAS["moon_paksha_bala_weak"],
                    "details": f"Moon-Sun elongation {elong:.1f}° (paksha bala weak)"
                })

    return findings


def _check_santana_indicators(chart: Dict[str, Any], label: str) -> Dict[str, Any]:
    """Read santana-relevant indicators from a single chart."""
    fifth_lord = _house_lord(5, chart)
    fifth_lord_state = _planet_state(fifth_lord, chart) if fifth_lord else None
    jupiter_state = _planet_state("Jupiter", chart)
    karakas = chart.get("jaimini_karakas", {})
    putrakaraka = karakas.get("Putrakaraka", {}) if isinstance(karakas, dict) else {}

    indicators: List[str] = []
    flags: List[str] = []

    # 5th lord state
    if fifth_lord_state:
        if _is_planet_dignified(fifth_lord, chart):
            indicators.append(f"5th lord {fifth_lord} dignified — supportive")
        if _is_planet_in_dusthana(fifth_lord, chart):
            flags.append(SANTANA_YOGA_INDICATORS["fifth_lord_in_dusthana"]["interpretation"])
        elif _is_planet_dignified(fifth_lord, chart):
            indicators.append(SANTANA_YOGA_INDICATORS["fifth_lord_dignified"]["interpretation"])

    # Jupiter state
    if _is_planet_in_dusthana("Jupiter", chart):
        flags.append(SANTANA_YOGA_INDICATORS["jupiter_in_dusthana"]["interpretation"])
    elif _is_planet_dignified("Jupiter", chart):
        indicators.append("Jupiter (Putrakaraka) dignified")

    # Ketu in 5th
    ketu_house = chart.get("planets", {}).get("Ketu", {}).get("house")
    if ketu_house == 5:
        flags.append(SANTANA_YOGA_INDICATORS["ketu_in_5th"]["interpretation"])

    return {
        "person":            label,
        "fifth_lord":        fifth_lord,
        "fifth_lord_state":  fifth_lord_state,
        "jupiter_state":     jupiter_state,
        "putrakaraka":       putrakaraka,
        "supportive_indicators": indicators,
        "caution_flags":     flags,
    }


# ════════════════════════════════════════════════════════════════════════
# PUBLIC API
# ════════════════════════════════════════════════════════════════════════

def handle_conception_muhurta(female_chart: Dict[str, Any],
                              male_chart: Optional[Dict[str, Any]],
                              location: Dict[str, Any],
                              start_date: Optional[str] = None,
                              end_date: Optional[str] = None,
                              max_days: int = 30) -> Dict[str, Any]:
    """
    F5 Endpoint: Garbhadhana muhurta — day-by-day scan for auspicious
    conception attempt windows.

    female_chart and male_chart: BirthInput-shaped dicts.
    location: {lat, lon, timezone} where conception is planned.
    start_date/end_date: YYYY-MM-DD; defaults to today + 30 days.
    max_days: cap at 30 days per scan.

    Returns top auspicious days + days to avoid + full ranked list.
    """
    gender_check = (_check_gender_field_in_input(female_chart) or
                    _check_gender_field_in_input(male_chart or {}) or
                    _check_gender_field_in_input(location))
    if gender_check:
        return {"error": gender_check,
                "pcpndt_note": PCPNDT_NOTE,
                "classical_sources": F5_CITATIONS["conception_muhurta"]}

    female = _cast_or_error(female_chart, "female partner chart")
    if "_error" in female:
        return {"error": female["_error"],
                "classical_sources": F5_CITATIONS["conception_muhurta"],
                "disclaimer": F5_DISCLAIMER, "pcpndt_note": PCPNDT_NOTE}

    today = date.today().isoformat()
    if not start_date:
        start_date = today
    if not end_date:
        try:
            sd = datetime.strptime(start_date, "%Y-%m-%d").date()
            end_date = (sd + timedelta(days=14)).isoformat()
        except Exception:
            end_date = start_date

    dates = _date_range(start_date, end_date, max_days=max_days)
    if not dates:
        return {"error": "invalid date range",
                "classical_sources": F5_CITATIONS["conception_muhurta"],
                "disclaimer": F5_DISCLAIMER, "pcpndt_note": PCPNDT_NOTE}

    scored = [_score_garbhadhana_day(d, location, female) for d in dates]
    ranked = sorted(scored, key=lambda x: x["score"], reverse=True)
    top = [d for d in ranked if d["verdict"] in {"highly_auspicious", "auspicious"}][:5]
    avoid = [d for d in ranked if d["verdict"] == "avoid"][:5]

    return {
        "scan_window":          {"start": start_date, "end": end_date,
                                 "days_scanned": len(dates)},
        "location":             location,
        "top_auspicious_days":  top,
        "days_to_avoid":        avoid,
        "full_ranked_scan":     ranked,
        "summary":              (f"Scanned {len(dates)} days; "
                                 f"{len(top)} top-auspicious, "
                                 f"{len(avoid)} to avoid"),
        "classical_sources":    F5_CITATIONS["conception_muhurta"],
        "disclaimer":           F5_DISCLAIMER,
        "pcpndt_note":          PCPNDT_NOTE,
    }


def handle_santana_yogas(person1_chart: Dict[str, Any],
                         person2_chart: Dict[str, Any]) -> Dict[str, Any]:
    """
    F5 Endpoint: Couple's combined santana yoga analysis.

    Reads each partner's 5th lord, Jupiter, Putrakaraka; surfaces
    supportive indicators and caution flags (Putra Dosha, Ketu in 5th, etc.)
    """
    gender_check = (_check_gender_field_in_input(person1_chart) or
                    _check_gender_field_in_input(person2_chart))
    if gender_check:
        return {"error": gender_check, "pcpndt_note": PCPNDT_NOTE,
                "classical_sources": F5_CITATIONS["santana_yogas"]}

    p1 = _cast_or_error(person1_chart, "person1")
    if "_error" in p1:
        return {"error": p1["_error"], "classical_sources": F5_CITATIONS["santana_yogas"],
                "disclaimer": F5_DISCLAIMER, "pcpndt_note": PCPNDT_NOTE}
    p2 = _cast_or_error(person2_chart, "person2")
    if "_error" in p2:
        return {"error": p2["_error"], "classical_sources": F5_CITATIONS["santana_yogas"],
                "disclaimer": F5_DISCLAIMER, "pcpndt_note": PCPNDT_NOTE}

    p1_indicators = _check_santana_indicators(p1, "person1")
    p2_indicators = _check_santana_indicators(p2, "person2")

    combined_supportive = (
        len(p1_indicators["supportive_indicators"]) +
        len(p2_indicators["supportive_indicators"])
    )
    combined_cautions = (
        len(p1_indicators["caution_flags"]) +
        len(p2_indicators["caution_flags"])
    )

    if combined_supportive >= 4 and combined_cautions == 0:
        verdict = "strong_santana_yoga"
    elif combined_supportive >= 2 and combined_cautions <= 1:
        verdict = "supportive"
    elif combined_cautions >= 4:
        verdict = "significant_classical_caution"
    elif combined_cautions >= 2:
        verdict = "moderate_classical_caution"
    else:
        verdict = "neutral_mixed"

    classical_recommendations: List[str] = []
    if combined_cautions > 0:
        classical_recommendations.extend([
            "Daily Santana Gopala Mantra by both partners "
            "(Om Devaki Sutam Govindam Vasudevam Jagatpatim, "
            "Dehi Me Tanayam Krishnam Tvamaham Sharanam Gatah)",
            "Visit a Santana Gopala or Garbha Raksha temple if circumstances permit",
            "Thursday observance — Brihaspati/Jupiter strengthening (yellow items, "
            "Jupiter mantra, Vishnu worship)",
        ])
    if combined_cautions >= 3:
        classical_recommendations.append(
            "Consider Putrakameshti Yajna by qualified priest"
        )

    return {
        "person1_analysis":       p1_indicators,
        "person2_analysis":       p2_indicators,
        "combined_summary":       {
            "supportive_indicators_total": combined_supportive,
            "caution_flags_total":         combined_cautions,
        },
        "verdict":                verdict,
        "classical_recommendations": classical_recommendations,
        "classical_sources":      F5_CITATIONS["santana_yogas"],
        "disclaimer":             F5_DISCLAIMER,
        "pcpndt_note":            PCPNDT_NOTE,
    }


def handle_prenatal_remedies(mother_chart: Dict[str, Any],
                             gestational_month: int,
                             father_chart: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    F5 Endpoint: Month-by-month Garbha Sanskara remedies.

    mother_chart: BirthInput-shaped.
    gestational_month: integer 1-9.
    father_chart: optional.

    Returns the classical remedies for the specified month + mother's
    chart-specific personalization (where Jupiter, Moon, 5th lord stand).
    """
    gender_check = (_check_gender_field_in_input(mother_chart) or
                    _check_gender_field_in_input(father_chart or {}))
    if gender_check:
        return {"error": gender_check, "pcpndt_note": PCPNDT_NOTE,
                "classical_sources": F5_CITATIONS["prenatal_remedies"]}

    if not isinstance(gestational_month, int) or gestational_month < 1 or gestational_month > 9:
        return {"error": "gestational_month must be integer 1-9",
                "pcpndt_note": PCPNDT_NOTE,
                "classical_sources": F5_CITATIONS["prenatal_remedies"],
                "disclaimer": F5_DISCLAIMER}

    mother = _cast_or_error(mother_chart, "mother")
    if "_error" in mother:
        return {"error": mother["_error"], "pcpndt_note": PCPNDT_NOTE,
                "classical_sources": F5_CITATIONS["prenatal_remedies"],
                "disclaimer": F5_DISCLAIMER}

    month_data = PRENATAL_MONTH_REMEDIES.get(gestational_month, {})
    if not month_data:
        return {"error": f"no remedy data for month {gestational_month}",
                "pcpndt_note": PCPNDT_NOTE,
                "classical_sources": F5_CITATIONS["prenatal_remedies"],
                "disclaimer": F5_DISCLAIMER}

    # Mother chart personalization
    jupiter_state = _planet_state("Jupiter", mother)
    moon_state = _planet_state("Moon", mother)
    fifth_lord = _house_lord(5, mother)
    fifth_lord_state = _planet_state(fifth_lord, mother) if fifth_lord else None

    personalization_notes: List[str] = []
    if _is_planet_afflicted("Jupiter", mother):
        personalization_notes.append(
            "Mother's Jupiter (putra-karaka) afflicted — emphasize Thursday observances "
            "and Brihaspati mantra throughout pregnancy, not just per-month"
        )
    if _is_planet_afflicted("Moon", mother):
        personalization_notes.append(
            "Mother's Moon afflicted — emphasize emotional shelter, Lalita stotras, "
            "and protective environment more strongly in months 5 and 9"
        )
    if fifth_lord and _is_planet_in_dusthana(fifth_lord, mother):
        personalization_notes.append(
            f"Mother's 5th lord {fifth_lord} in dusthana — add Garbha Raksha Stotra to daily practice"
        )

    return {
        "gestational_month":     gestational_month,
        "month_remedies":        month_data,
        "mother_chart_personalization": {
            "jupiter_state":     jupiter_state,
            "moon_state":        moon_state,
            "fifth_lord":        fifth_lord,
            "fifth_lord_state":  fifth_lord_state,
            "personalization_notes": personalization_notes,
        },
        "general_pregnancy_guidance": [
            "All practices are supplementary to medical care, never substitutes.",
            "Discontinue any practice that causes physical or emotional discomfort.",
            "Consult family priest for personalized Sanskara details.",
        ],
        "classical_sources":     F5_CITATIONS["prenatal_remedies"],
        "disclaimer":            F5_DISCLAIMER,
        "pcpndt_note":           PCPNDT_NOTE,
    }


def handle_bala_arishta(child_chart: Dict[str, Any]) -> Dict[str, Any]:
    """
    F5 Endpoint: Classical Bala-Arishta yoga screen for a child's chart.

    Reads classical early-childhood-affliction yogas from BPHS Ch. 8 etc.
    Returns yoga findings with classical citations and shanti remedies.

    SENSITIVE: framed as classical karmic patterns + shanti practices,
    NOT medical or psychological diagnosis.
    """
    gender_check = _check_gender_field_in_input(child_chart)
    if gender_check:
        return {"error": gender_check, "pcpndt_note": PCPNDT_NOTE,
                "classical_sources": F5_CITATIONS["bala_arishta"]}

    chart = _cast_or_error(child_chart, "child chart")
    if "_error" in chart:
        return {"error": chart["_error"], "pcpndt_note": PCPNDT_NOTE,
                "classical_sources": F5_CITATIONS["bala_arishta"],
                "disclaimer": F5_DISCLAIMER}

    findings = _check_bala_arishta_yogas(chart)
    severity_counts = {"high": 0, "moderate": 0, "low": 0}
    for f in findings:
        sev = f.get("severity", "low")
        if sev in severity_counts:
            severity_counts[sev] += 1

    if severity_counts["high"] >= 1:
        overall = "comprehensive_shanti_classically_advised"
    elif severity_counts["moderate"] >= 2:
        overall = "moderate_shanti_classically_advised"
    elif sum(severity_counts.values()) >= 1:
        overall = "mild_shanti_supportive"
    else:
        overall = "no_classical_bala_arishta_indicators"

    recommended_shanti: List[str] = []
    if findings:
        recommended_shanti.extend([
            "Maha Mrityunjaya Mantra recited by parents on the child's behalf "
            "(108x daily for the first 1000 days is the classical prescription)",
            "Maintain a peaceful, sattvic home environment for the child's first years",
            "Annual visit to a family deity temple on the child's birth nakshatra day",
        ])
    for f in findings:
        if "Surya" in f.get("interpretation", ""):
            recommended_shanti.append("Aditya Hridaya Stotra weekly")
        if "Shani" in f.get("interpretation", ""):
            recommended_shanti.append(
                "Saturday observance — Hanuman Chalisa, sesame oil charity"
            )
        if "Moon" in f.get("name", ""):
            recommended_shanti.append(
                "Monday Devi worship; protect child from emotional turbulence "
                "in the home"
            )

    return {
        "child_chart_lagna":    chart.get("lagna", {}),
        "findings":             findings,
        "findings_count":       len(findings),
        "severity_counts":      severity_counts,
        "overall_verdict":      overall,
        "recommended_shanti_practices": list(dict.fromkeys(recommended_shanti)),  # dedup
        "classical_sources":    F5_CITATIONS["bala_arishta"],
        "disclaimer":           F5_DISCLAIMER,
        "sensitive_topic_disclaimer": F5_SENSITIVE_TOPIC_DISCLAIMER,
        "pcpndt_note":          PCPNDT_NOTE,
    }


def handle_newborn_naming_window(child_chart: Dict[str, Any],
                                 naming_location: Dict[str, Any]) -> Dict[str, Any]:
    """
    F5 Endpoint: Namakarana (naming ceremony) muhurta + classical aksharas.

    child_chart: BirthInput-shaped chart of the newborn.
    naming_location: {lat, lon, timezone} where naming will occur.

    Returns the classical 10th/11th-day Namakarana window, akshara letters
    derived from janma nakshatra-pada, and example name starting-letter
    suggestions.
    """
    gender_check = (_check_gender_field_in_input(child_chart) or
                    _check_gender_field_in_input(naming_location))
    if gender_check:
        return {"error": gender_check, "pcpndt_note": PCPNDT_NOTE,
                "classical_sources": F5_CITATIONS["newborn_naming_window"]}

    chart = _cast_or_error(child_chart, "child chart")
    if "_error" in chart:
        return {"error": chart["_error"], "pcpndt_note": PCPNDT_NOTE,
                "classical_sources": F5_CITATIONS["newborn_naming_window"],
                "disclaimer": F5_DISCLAIMER}

    janma_nak = chart.get("planets", {}).get("Moon", {}).get("nakshatra")
    janma_pada = chart.get("planets", {}).get("Moon", {}).get("pada")
    akshara_set = NAKSHATRA_AKSHARAS_F5.get(janma_nak, [])
    pada_akshara = (akshara_set[janma_pada - 1]
                    if akshara_set and isinstance(janma_pada, int) and 1 <= janma_pada <= 4
                    else None)

    # Namakarana window: classical 11th day (Hindu tradition) or 10th day
    # (some Smriti texts). Some families do 12th day or first nakshatra-day
    # return after birth.
    try:
        dob = datetime.strptime(child_chart["dob"], "%Y-%m-%d").date()
        day_10 = (dob + timedelta(days=9)).isoformat()
        day_11 = (dob + timedelta(days=10)).isoformat()
        day_12 = (dob + timedelta(days=11)).isoformat()
    except Exception:
        day_10 = day_11 = day_12 = None

    # Score each candidate day with the same muhurta scoring used for Garbhadhana
    # (Namakarana shares classical muhurta preference rules, though softer)
    candidate_dates = [d for d in (day_10, day_11, day_12) if d]
    scored_candidates = [
        _score_garbhadhana_day(d, naming_location, chart)  # reuse scoring
        for d in candidate_dates
    ]
    ranked_candidates = sorted(scored_candidates, key=lambda x: x["score"], reverse=True)

    return {
        "janma_nakshatra":      janma_nak,
        "janma_pada":           janma_pada,
        "pada_akshara":         pada_akshara,
        "all_aksharas_for_nakshatra": akshara_set,
        "akshara_usage_note":   ("The pada-specific akshara is the most classical "
                                 "choice. Any of the 4 aksharas for the nakshatra "
                                 "is acceptable per most traditions."),
        "candidate_namakarana_days": ranked_candidates,
        "classical_namakarana_timing": (
            "Most traditions perform Namakarana on the 11th day after birth. "
            "Some Smriti texts prescribe 10th or 12th day. Choose the highest-"
            "scored candidate day from the muhurta scan above. The actual "
            "muhurta within the day should be selected with a family priest."
        ),
        "classical_sources":    F5_CITATIONS["newborn_naming_window"],
        "disclaimer":           F5_DISCLAIMER,
        "pcpndt_note":          PCPNDT_NOTE,
    }


def handle_garbha_shanti_remedies(mother_chart: Dict[str, Any],
                                  gestational_month: Optional[int] = None,
                                  father_chart: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    F5 Endpoint: Garbha Shanti remedies for problematic pregnancies.

    These are classical spiritual practices ONLY. Not medical advice.
    Sensitive endpoint — heavy disclaimer framing.

    mother_chart: BirthInput-shaped.
    gestational_month: optional (1-9); tailors the month-specific overlay.
    father_chart: optional.
    """
    gender_check = (_check_gender_field_in_input(mother_chart) or
                    _check_gender_field_in_input(father_chart or {}))
    if gender_check:
        return {"error": gender_check, "pcpndt_note": PCPNDT_NOTE,
                "classical_sources": F5_CITATIONS["garbha_shanti_remedies"]}

    mother = _cast_or_error(mother_chart, "mother chart")
    if "_error" in mother:
        return {"error": mother["_error"], "pcpndt_note": PCPNDT_NOTE,
                "classical_sources": F5_CITATIONS["garbha_shanti_remedies"],
                "disclaimer": F5_DISCLAIMER}

    # Mother chart-specific overlay
    chart_specific: List[str] = []
    if _is_planet_afflicted("Jupiter", mother):
        chart_specific.append(
            "Mother's Jupiter afflicted — emphasize Thursday observance, "
            "Brihaspati mantra, Vishnu Sahasranama daily"
        )
    if _is_planet_afflicted("Moon", mother):
        chart_specific.append(
            "Mother's Moon afflicted — emotional shelter critical; "
            "Monday Devi worship; protective home environment"
        )
    fifth_lord = _house_lord(5, mother)
    if fifth_lord and _is_planet_in_dusthana(fifth_lord, mother):
        chart_specific.append(
            f"Mother's 5th lord {fifth_lord} in dusthana — add Garbha Raksha "
            "Stotra to daily practice; weekly visit to Vishnu/Krishna temple"
        )
    ketu_house_mother = mother.get("planets", {}).get("Ketu", {}).get("house")
    if ketu_house_mother == 5:
        chart_specific.append(
            "Ketu in 5th in mother's chart — Santana Gopala mantra "
            "(108x daily) classically prescribed"
        )

    month_overlay: Optional[Dict[str, Any]] = None
    if gestational_month and 1 <= gestational_month <= 9:
        m_data = PRENATAL_MONTH_REMEDIES.get(gestational_month, {})
        month_overlay = {
            "gestational_month": gestational_month,
            "month_planet_lord": m_data.get("planet_lord"),
            "month_mantras":     m_data.get("mantras"),
            "month_deity":       m_data.get("deity_worship"),
        }

    return {
        "core_classical_practices":      GARBHA_SHANTI_REMEDIES["core_practices"],
        "weekly_practices":              GARBHA_SHANTI_REMEDIES["weekly_practices"],
        "for_recurrent_difficulties":    GARBHA_SHANTI_REMEDIES["specific_to_recurrent_difficulties"],
        "lifestyle_alignment":           GARBHA_SHANTI_REMEDIES["lifestyle_alignment"],
        "chart_specific_overlay":        chart_specific,
        "month_specific_overlay":        month_overlay,
        "important_caveats":             GARBHA_SHANTI_REMEDIES["caveats"],
        "classical_sources":             F5_CITATIONS["garbha_shanti_remedies"],
        "disclaimer":                    F5_DISCLAIMER,
        "sensitive_topic_disclaimer":    F5_SENSITIVE_TOPIC_DISCLAIMER,
        "pcpndt_note":                   PCPNDT_NOTE,
    }


# ════════════════════════════════════════════════════════════════════════
# F5 module marker — used by patch installer for idempotency check
# ════════════════════════════════════════════════════════════════════════
F5_MODULE_VERSION = "1.0.0"
F5_MODULE_MARKER  = "F5_PREGNANCY_2026_05_18"
