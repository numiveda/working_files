"""
yogas_catalog_3.py — Final catalog: special-outcome yogas, planet-in-house yogas,
Argala, Bhava strengths, and misc named yogas.

Families:
 13. Special Outcome Yogas
 14. Argala Yogas (Jaimini intervention)
 15. Bhava Yogas (strong house yogas)
 16. Planet-in-house Yogas
 17. Misc named yogas
"""

from yogas_helpers import (
    SIGNS, SIGN_INDEX, SIGN_LORDS, EXALTATION, DEBILITATION, OWN_SIGNS,
    KENDRA_HOUSES, TRIKONA_HOUSES, DUSTHANA_HOUSES, ALL_PLANETS, NON_NODES,
    asc_sign, planet, planet_house, planet_sign, planet_lon,
    is_retrograde, is_combust, is_exalted, is_debilitated, is_own_sign,
    dignity, sign_in_house, house_of_sign, lord_of_house, planets_in_house,
    planets_in_sign, is_in_kendra, is_in_trikona, is_in_dusthana, aspects_house,
    aspects_planet, conjunct, mutual_reception,
)


# ═════════════════════════════════════════════════════════════════════════════
# 13. SPECIAL OUTCOME YOGAS
# ═════════════════════════════════════════════════════════════════════════════

SPECIAL_OUTCOME_YOGAS = [
    {
        "yoga_id":        "bharati_yoga",
        "name_en":        "Bharati Yoga",
        "name_sa":        "भारती",
        "family":         "special_outcome",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.35",
        "formation_rule": "Lords of 2nd, 5th, and 9th in connection, Jupiter strong.",
        "detect":         lambda c: (
            (conjunct(c, lord_of_house(c, 2), lord_of_house(c, 5)) or
             conjunct(c, lord_of_house(c, 5), lord_of_house(c, 9)) or
             conjunct(c, lord_of_house(c, 2), lord_of_house(c, 9))) and
            dignity(c, "Jupiter") in ("exalted", "own", "mooltrikona", "friend")
        ),
        "domains":        ["scholarship", "literary_fame", "education_eminence"],
        "general_effect": "Eminent in scholarship and literary pursuits; voice of wisdom in society.",
        "remedy_hooks":   ["honor_saraswati", "strengthen_jupiter"],
    },
    {
        "yoga_id":        "matsya_yoga",
        "name_en":        "Matsya Yoga",
        "name_sa":        "मत्स्य",
        "family":         "special_outcome",
        "polarity":       "positive",
        "source":         "Saravali",
        "formation_rule": "Benefics in 1st, 5th, 9th houses with at least 2 in trikonas.",
        "detect":         lambda c: (
            sum(1 for b in ("Jupiter", "Venus", "Mercury") if planet_house(c, b) in TRIKONA_HOUSES) >= 2
        ),
        "domains":        ["intelligence", "knowledge", "social_recognition"],
        "general_effect": "Intellectual achievement, recognition through knowledge.",
        "remedy_hooks":   ["strengthen_jupiter", "strengthen_venus"],
    },
    {
        "yoga_id":        "kurma_yoga",
        "name_en":        "Kurma Yoga",
        "name_sa":        "कूर्म",
        "family":         "special_outcome",
        "polarity":       "positive",
        "source":         "Saravali",
        "formation_rule": "Benefics in 5/6/7th houses, malefics in 1/3/11th houses.",
        "detect":         lambda c: (
            sum(1 for b in ("Jupiter", "Venus", "Mercury") if planet_house(c, b) in (5, 6, 7)) >= 2 and
            sum(1 for m in ("Mars", "Saturn", "Sun") if planet_house(c, m) in (1, 3, 11)) >= 2
        ),
        "domains":        ["protection", "patient_endurance", "long_life"],
        "general_effect": "Tortoise-like resilience; survives and prospers despite challenges.",
        "remedy_hooks":   ["cultivate_patience"],
    },
    {
        "yoga_id":        "khadga_yoga",
        "name_en":        "Khadga Yoga (Sword)",
        "name_sa":        "खड्ग",
        "family":         "special_outcome",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.37",
        "formation_rule": "Lord of 2nd in 9th, lord of 9th in 2nd, lord of lagna in kendra.",
        "detect":         lambda c: (
            planet_house(c, lord_of_house(c, 2)) == 9 and
            planet_house(c, lord_of_house(c, 9)) == 2 and
            planet_house(c, lord_of_house(c, 1)) in KENDRA_HOUSES
        ),
        "domains":        ["valour", "command", "warrior_skill"],
        "general_effect": "Sword-like sharpness; warrior or commander qualities.",
        "remedy_hooks":   ["strengthen_2nd_lord", "strengthen_9th_lord"],
    },
    {
        "yoga_id":        "shubh_kartari_lagna",
        "name_en":        "Shubha Kartari Yoga (around Lagna)",
        "name_sa":        "शुभकर्तरि (लग्न)",
        "family":         "special_outcome",
        "polarity":       "positive",
        "source":         "Phaladeepika",
        "formation_rule": "Benefics in 2nd and 12th from Lagna.",
        "detect":         lambda c: (
            any(planet_house(c, b) == 2 for b in ("Jupiter", "Venus", "Mercury")) and
            any(planet_house(c, b) == 12 for b in ("Jupiter", "Venus", "Mercury"))
        ),
        "domains":        ["personal_protection", "well_being"],
        "general_effect": "Personal life shielded by benefics; difficulties pass quickly.",
        "remedy_hooks":   ["honor_benefics"],
    },
    {
        "yoga_id":        "papa_kartari_lagna",
        "name_en":        "Papa Kartari Yoga (around Lagna)",
        "name_sa":        "पापकर्तरि (लग्न)",
        "family":         "special_outcome",
        "polarity":       "negative",
        "source":         "Phaladeepika",
        "formation_rule": "Malefics in 2nd and 12th from Lagna.",
        "detect":         lambda c: (
            any(planet_house(c, m) == 2 for m in ("Mars", "Saturn", "Rahu", "Ketu")) and
            any(planet_house(c, m) == 12 for m in ("Mars", "Saturn", "Rahu", "Ketu"))
        ),
        "domains":        ["personal_constraint", "pressured_life"],
        "general_effect": "Personal life feels squeezed by external pressures.",
        "remedy_hooks":   ["lagna_lord_strengthening", "pacify_malefics"],
    },
    {
        "yoga_id":        "putra_yoga",
        "name_en":        "Putra Yoga (children-bestowing)",
        "name_sa":        "पुत्र",
        "family":         "special_outcome",
        "polarity":       "positive",
        "source":         "BPHS Ch 41",
        "formation_rule": "5th lord strong, in own/exalt or 5th, with Jupiter aspect.",
        "detect":         lambda c: (
            (dignity(c, lord_of_house(c, 5)) in ("exalted", "own", "mooltrikona") or
             planet_house(c, lord_of_house(c, 5)) == 5) and
            aspects_planet(c, "Jupiter", lord_of_house(c, 5))
        ),
        "domains":        ["children_blessing", "creative_progeny"],
        "general_effect": "Blessed with capable children or significant creative offspring.",
        "remedy_hooks":   ["strengthen_5th_lord", "honor_jupiter"],
    },
    {
        "yoga_id":        "kalatra_yoga",
        "name_en":        "Kalatra Yoga (good-spouse)",
        "name_sa":        "कलत्र",
        "family":         "special_outcome",
        "polarity":       "positive",
        "source":         "BPHS Ch 80",
        "formation_rule": "7th lord well-placed, Venus strong, no malefics in 7th.",
        "detect":         lambda c: (
            planet_house(c, lord_of_house(c, 7)) in (KENDRA_HOUSES | TRIKONA_HOUSES | {2}) and
            dignity(c, "Venus") not in ("debilitated", "enemy") and
            not any(planet_house(c, m) == 7 for m in ("Mars", "Saturn", "Rahu", "Ketu"))
        ),
        "domains":        ["happy_marriage", "loving_spouse"],
        "general_effect": "Happy and harmonious marriage; spouse brings fortune.",
        "remedy_hooks":   ["strengthen_venus", "honor_7th_lord"],
    },
    {
        "yoga_id":        "ayushman_yoga",
        "name_en":        "Ayushman Yoga (Long Life)",
        "name_sa":        "आयुष्मान्",
        "family":         "special_outcome",
        "polarity":       "positive",
        "source":         "Phaladeepika",
        "formation_rule": "Strong 8th lord in kendra/trikona, Saturn well-placed.",
        "detect":         lambda c: (
            planet_house(c, lord_of_house(c, 8)) in (KENDRA_HOUSES | TRIKONA_HOUSES) and
            dignity(c, "Saturn") not in ("debilitated", "enemy")
        ),
        "domains":        ["longevity", "robust_health"],
        "general_effect": "Long life and robust health; endurance through challenges.",
        "remedy_hooks":   ["strengthen_saturn"],
    },
    {
        "yoga_id":        "lagnesha_in_kendra",
        "name_en":        "Lagna Lord in Kendra",
        "name_sa":        "लग्नेश-केन्द्र",
        "family":         "special_outcome",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Lord of Lagna in kendra (1/4/7/10), well-dignified.",
        "detect":         lambda c: (
            planet_house(c, lord_of_house(c, 1)) in KENDRA_HOUSES and
            dignity(c, lord_of_house(c, 1)) not in ("debilitated", "enemy")
        ),
        "domains":        ["strong_personality", "leadership"],
        "general_effect": "Strong personality and leadership; self-confident.",
        "remedy_hooks":   ["maintain_lagna_lord"],
    },
    {
        "yoga_id":        "lagnesha_in_trikona",
        "name_en":        "Lagna Lord in Trikona",
        "name_sa":        "लग्नेश-त्रिकोण",
        "family":         "special_outcome",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Lord of Lagna in trikona (1/5/9), well-dignified.",
        "detect":         lambda c: (
            planet_house(c, lord_of_house(c, 1)) in TRIKONA_HOUSES and
            dignity(c, lord_of_house(c, 1)) not in ("debilitated", "enemy")
        ),
        "domains":        ["dharma", "fortune"],
        "general_effect": "Personal life aligned with dharma and fortune.",
        "remedy_hooks":   ["honor_dharma"],
    },
    {
        "yoga_id":        "akhanda_samrajya_yoga",
        "name_en":        "Akhanda Samrajya Yoga",
        "name_sa":        "अखण्ड साम्राज्य",
        "family":         "special_outcome",
        "polarity":       "positive",
        "source":         "Saravali, Mantreshwara",
        "formation_rule": "Lords of 2, 9, 11 well-placed; Jupiter in kendra from Moon.",
        "detect":         lambda c: (
            all(planet_house(c, lord_of_house(c, h)) in (KENDRA_HOUSES | TRIKONA_HOUSES)
                for h in (2, 9, 11)) and
            planet_house(c, "Jupiter") is not None and planet_house(c, "Moon") is not None and
            ((planet_house(c, "Jupiter") - planet_house(c, "Moon")) % 12) in (0, 3, 6, 9)
        ),
        "domains":        ["unbroken_authority", "supreme_position"],
        "general_effect": "Unbroken sovereignty; supreme Raja yoga.",
        "remedy_hooks":   ["maintain_jupiter"],
    },
    {
        "yoga_id":        "shubha_yoga_benefic_lagna",
        "name_en":        "Shubha Yoga (Benefic Lagna)",
        "name_sa":        "शुभ",
        "family":         "special_outcome",
        "polarity":       "positive",
        "source":         "Phaladeepika",
        "formation_rule": "Benefic in lagna without malefic association.",
        "detect":         lambda c: (
            any(planet_house(c, b) == 1 for b in ("Jupiter", "Venus", "Mercury", "Moon")) and
            not any(planet_house(c, m) == 1 for m in ("Mars", "Saturn", "Rahu", "Ketu"))
        ),
        "domains":        ["physical_beauty", "good_character"],
        "general_effect": "Physical beauty, good character, respected presence.",
        "remedy_hooks":   ["honor_benefic_in_lagna"],
    },
    {
        "yoga_id":        "ashubha_yoga_malefic_lagna",
        "name_en":        "Ashubha Yoga (Malefic Lagna)",
        "name_sa":        "अशुभ",
        "family":         "special_outcome",
        "polarity":       "negative",
        "source":         "Phaladeepika",
        "formation_rule": "Malefic in lagna without benefic association.",
        "detect":         lambda c: (
            any(planet_house(c, m) == 1 for m in ("Mars", "Saturn", "Rahu", "Ketu")) and
            not any(planet_house(c, b) == 1 for b in ("Jupiter", "Venus", "Mercury"))
        ),
        "domains":        ["harsh_disposition", "early_struggle"],
        "general_effect": "Difficult personality; early physical or social struggles.",
        "remedy_hooks":   ["pacify_lagna_malefic"],
    },
    {
        "yoga_id":        "saraswati_strict",
        "name_en":        "Saraswati Yoga (Strict)",
        "name_sa":        "सरस्वती (कठोर)",
        "family":         "special_outcome",
        "polarity":       "positive",
        "source":         "Mantreshwara 6.31 strict",
        "formation_rule": "Jupiter, Venus, Mercury all in lagna or 2nd or 4th or 5th or 7th or 9th or 10th, Jupiter exalt/own/friend.",
        "detect":         lambda c: (
            all(planet_house(c, p) in {1, 2, 4, 5, 7, 9, 10} for p in ("Jupiter", "Venus", "Mercury")) and
            dignity(c, "Jupiter") in ("exalted", "own", "mooltrikona", "friend")
        ),
        "domains":        ["scholarship", "arts", "music", "wisdom"],
        "general_effect": "Saraswati's blessings; scholarship in arts, music, learning.",
        "remedy_hooks":   ["worship_saraswati"],
    },
]


# ═════════════════════════════════════════════════════════════════════════════
# 14. ARGALA YOGAS — Jaimini intervention (Sutras 1.1)
# ═════════════════════════════════════════════════════════════════════════════

ARGALA_YOGAS = [
    {
        "yoga_id":        f"argala_h{h}",
        "name_en":        f"Argala on House {h}",
        "name_sa":        f"अर्गल ({h})",
        "family":         "argala",
        "polarity":       "positive",
        "source":         "Jaimini Sutras 1.1",
        "formation_rule": f"Planets in 2nd/4th/5th/11th from house {h} create supportive intervention.",
        "detect":         (lambda h=h: lambda c: any(
            planet_house(c, p) is not None and
            ((planet_house(c, p) - h) % 12) in (1, 3, 4, 10)
            for p in NON_NODES
        ))(),
        "domains":        [f"house_{h}_strengthened"],
        "general_effect": f"Supportive intervention on house {h} themes.",
        "remedy_hooks":   [],
    }
    for h in range(1, 13)
]


# ═════════════════════════════════════════════════════════════════════════════
# 15. BHAVA YOGAS — Strong house formations
# ═════════════════════════════════════════════════════════════════════════════

BHAVA_THEMES = {
    1:  ("self", "Strong personality, vitality, presence"),
    2:  ("wealth_family", "Family resources, voice, possessions"),
    3:  ("courage_siblings", "Courage, communication, sibling bonds"),
    4:  ("home_mother", "Home, mother, vehicles, lands"),
    5:  ("creativity_children", "Creative intelligence, progeny, romance"),
    6:  ("service_health", "Service capability, health, victory over rivals"),
    7:  ("partnership", "Spouse, partnerships, public dealings"),
    8:  ("transformation_longevity", "Longevity, hidden wealth, transformation"),
    9:  ("dharma_fortune", "Dharma, father, higher learning, fortune"),
    10: ("career_authority", "Career, authority, public status"),
    11: ("gains_friends", "Gains, large friend circles, fulfillment"),
    12: ("liberation_loss", "Spiritual liberation, foreign lands"),
}

def _ord_suffix(n: int) -> str:
    if n == 1: return "st"
    if n == 2: return "nd"
    if n == 3: return "rd"
    return "th"

BHAVA_YOGAS = [
    {
        "yoga_id":        f"strong_bhava_{h}",
        "name_en":        f"Strong {h}{_ord_suffix(h)} Bhava",
        "name_sa":        f"बलवान् भाव {h}",
        "family":         "bhava_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 33-43",
        "formation_rule": (
            f"Lord of {h}th in own/exalt OR in kendra/trikona, with benefic aspect on {h}th house."
        ),
        "detect":         (lambda h=h: lambda c: (
            (dignity(c, lord_of_house(c, h)) in ("exalted", "own", "mooltrikona") or
             planet_house(c, lord_of_house(c, h)) in (KENDRA_HOUSES | TRIKONA_HOUSES)) and
            any(aspects_house(c, b, h) for b in ("Jupiter", "Venus"))
        ))(),
        "domains":        [BHAVA_THEMES[h][0]],
        "general_effect": BHAVA_THEMES[h][1] + " — empowered and well-supported.",
        "remedy_hooks":   [f"strengthen_{h}_lord"],
    }
    for h in range(1, 13)
]


# ═════════════════════════════════════════════════════════════════════════════
# 16. PLANET-IN-HOUSE YOGAS
# ═════════════════════════════════════════════════════════════════════════════

PLANET_IN_HOUSE_YOGAS = [
    # Jupiter
    {
        "yoga_id":        "jupiter_in_1st",
        "name_en":        "Jupiter in Lagna",
        "name_sa":        "गुरु-लग्न",
        "family":         "planet_in_house",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Jupiter in 1st house, well-dignified.",
        "detect":         lambda c: planet_house(c, "Jupiter") == 1 and dignity(c, "Jupiter") not in ("debilitated", "enemy"),
        "domains":        ["wisdom", "dharma", "respected_presence"],
        "general_effect": "Naturally wise, respected, dharmic disposition.",
        "remedy_hooks":   ["maintain_jupiter"],
    },
    {
        "yoga_id":        "jupiter_in_5th",
        "name_en":        "Jupiter in 5th",
        "name_sa":        "गुरु-पंचम",
        "family":         "planet_in_house",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Jupiter in 5th house, well-dignified.",
        "detect":         lambda c: planet_house(c, "Jupiter") == 5 and dignity(c, "Jupiter") not in ("debilitated", "enemy"),
        "domains":        ["intelligence", "children_blessing"],
        "general_effect": "Bright intellect; blessed with capable children.",
        "remedy_hooks":   ["honor_jupiter"],
    },
    {
        "yoga_id":        "jupiter_in_9th",
        "name_en":        "Jupiter in 9th",
        "name_sa":        "गुरु-भाग्य",
        "family":         "planet_in_house",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Jupiter in 9th (own karaka house).",
        "detect":         lambda c: planet_house(c, "Jupiter") == 9 and dignity(c, "Jupiter") not in ("debilitated", "enemy"),
        "domains":        ["dharma", "fortune", "father_blessing"],
        "general_effect": "Strong dharmic alignment; father's blessing.",
        "remedy_hooks":   ["maintain_jupiter"],
    },
    {
        "yoga_id":        "jupiter_in_11th",
        "name_en":        "Jupiter in 11th",
        "name_sa":        "गुरु-लाभ",
        "family":         "planet_in_house",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Jupiter in 11th house.",
        "detect":         lambda c: planet_house(c, "Jupiter") == 11 and dignity(c, "Jupiter") not in ("debilitated", "enemy"),
        "domains":        ["wise_friends", "dharmic_gains"],
        "general_effect": "Surrounded by wise friends; gains through dharma.",
        "remedy_hooks":   ["honor_satsang"],
    },
    # Venus
    {
        "yoga_id":        "venus_in_4th",
        "name_en":        "Venus in 4th",
        "name_sa":        "शुक्र-सुख",
        "family":         "planet_in_house",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Venus in 4th house, well-dignified.",
        "detect":         lambda c: planet_house(c, "Venus") == 4 and dignity(c, "Venus") not in ("debilitated", "enemy"),
        "domains":        ["home_luxury", "vehicles", "comforts"],
        "general_effect": "Beautiful home, luxury vehicles, comfortable life.",
        "remedy_hooks":   ["maintain_venus"],
    },
    {
        "yoga_id":        "venus_in_7th",
        "name_en":        "Venus in 7th",
        "name_sa":        "शुक्र-कलत्र",
        "family":         "planet_in_house",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Venus in 7th house (own karaka house).",
        "detect":         lambda c: planet_house(c, "Venus") == 7 and dignity(c, "Venus") not in ("debilitated", "enemy"),
        "domains":        ["beautiful_spouse", "harmonious_partnership"],
        "general_effect": "Beautiful and loving spouse; wealth through partnerships.",
        "remedy_hooks":   ["maintain_venus"],
    },
    # Mercury
    {
        "yoga_id":        "mercury_in_1st",
        "name_en":        "Mercury in Lagna",
        "name_sa":        "बुध-लग्न",
        "family":         "planet_in_house",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Mercury in 1st house, well-dignified.",
        "detect":         lambda c: planet_house(c, "Mercury") == 1 and dignity(c, "Mercury") not in ("debilitated", "enemy"),
        "domains":        ["intelligence", "youthful_appearance", "communication"],
        "general_effect": "Quick intelligence, youthful appearance, excellent communicator.",
        "remedy_hooks":   ["maintain_mercury"],
    },
    {
        "yoga_id":        "mercury_in_10th",
        "name_en":        "Mercury in 10th",
        "name_sa":        "बुध-कर्म",
        "family":         "planet_in_house",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Mercury in 10th house, well-dignified.",
        "detect":         lambda c: planet_house(c, "Mercury") == 10 and dignity(c, "Mercury") not in ("debilitated", "enemy"),
        "domains":        ["intellectual_career", "writing", "tech"],
        "general_effect": "Career through intellect, writing, communication, or tech.",
        "remedy_hooks":   ["strengthen_mercury"],
    },
    # Mars
    {
        "yoga_id":        "mars_in_3rd",
        "name_en":        "Mars in 3rd",
        "name_sa":        "मंगल-पराक्रम",
        "family":         "planet_in_house",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Mars in 3rd house — own upachaya.",
        "detect":         lambda c: planet_house(c, "Mars") == 3 and dignity(c, "Mars") not in ("debilitated", "enemy"),
        "domains":        ["courage", "physical_strength", "siblings"],
        "general_effect": "Strong courage, physical prowess, supportive siblings.",
        "remedy_hooks":   ["channel_mars_energy"],
    },
    {
        "yoga_id":        "mars_in_10th",
        "name_en":        "Mars in 10th",
        "name_sa":        "मंगल-कर्म",
        "family":         "planet_in_house",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Mars in 10th house, well-dignified.",
        "detect":         lambda c: planet_house(c, "Mars") == 10 and dignity(c, "Mars") not in ("debilitated", "enemy"),
        "domains":        ["career_authority", "military", "engineering"],
        "general_effect": "Career in command, military, engineering, or force-fields.",
        "remedy_hooks":   ["channel_mars_career"],
    },
    # Saturn
    {
        "yoga_id":        "saturn_in_3rd",
        "name_en":        "Saturn in 3rd",
        "name_sa":        "शनि-पराक्रम",
        "family":         "planet_in_house",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Saturn in 3rd house — upachaya placement.",
        "detect":         lambda c: planet_house(c, "Saturn") == 3 and dignity(c, "Saturn") not in ("debilitated", "enemy"),
        "domains":        ["disciplined_courage", "long_writing"],
        "general_effect": "Disciplined courage; success through long-term effort.",
        "remedy_hooks":   ["work_with_saturn"],
    },
    {
        "yoga_id":        "saturn_in_10th",
        "name_en":        "Saturn in 10th",
        "name_sa":        "शनि-कर्म",
        "family":         "planet_in_house",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Saturn in 10th house, well-dignified.",
        "detect":         lambda c: planet_house(c, "Saturn") == 10 and dignity(c, "Saturn") not in ("debilitated", "enemy"),
        "domains":        ["long_career", "structured_success"],
        "general_effect": "Long-lasting career; authority grows with age.",
        "remedy_hooks":   ["strengthen_saturn"],
    },
    # Negative placements
    {
        "yoga_id":        "moon_in_8th",
        "name_en":        "Moon in 8th",
        "name_sa":        "चन्द्र-अष्टम",
        "family":         "planet_in_house",
        "polarity":       "negative",
        "source":         "BPHS Ch 33",
        "formation_rule": "Moon in 8th house.",
        "detect":         lambda c: planet_house(c, "Moon") == 8,
        "domains":        ["emotional_transformation", "occult_interest"],
        "general_effect": "Deep emotional currents; occult interest; mother's health concerns possible.",
        "remedy_hooks":   ["moon_strengthening"],
    },
    {
        "yoga_id":        "venus_in_6th",
        "name_en":        "Venus in 6th",
        "name_sa":        "शुक्र-षष्ठ",
        "family":         "planet_in_house",
        "polarity":       "negative",
        "source":         "BPHS Ch 33",
        "formation_rule": "Venus in 6th house.",
        "detect":         lambda c: planet_house(c, "Venus") == 6,
        "domains":        ["relationship_friction"],
        "general_effect": "Tension between pleasure and work/health obligations.",
        "remedy_hooks":   ["venus_strengthening"],
    },
    {
        "yoga_id":        "mercury_in_12th",
        "name_en":        "Mercury in 12th",
        "name_sa":        "बुध-व्यय",
        "family":         "planet_in_house",
        "polarity":       "negative",
        "source":         "BPHS Ch 33",
        "formation_rule": "Mercury in 12th house.",
        "detect":         lambda c: planet_house(c, "Mercury") == 12,
        "domains":        ["unspoken_thoughts", "introspective_intellect"],
        "general_effect": "Thoughts not expressed easily; introspective intellect.",
        "remedy_hooks":   ["mercury_strengthening"],
    },
    {
        "yoga_id":        "jupiter_in_6th",
        "name_en":        "Jupiter in 6th",
        "name_sa":        "गुरु-षष्ठ",
        "family":         "planet_in_house",
        "polarity":       "negative",
        "source":         "BPHS Ch 33",
        "formation_rule": "Jupiter in 6th house — wisdom through service.",
        "detect":         lambda c: planet_house(c, "Jupiter") == 6,
        "domains":        ["wisdom_through_difficulty", "service"],
        "general_effect": "Wisdom comes through health struggles or service.",
        "remedy_hooks":   ["jupiter_remediation"],
    },
]


# ═════════════════════════════════════════════════════════════════════════════
# 17. MISC NAMED YOGAS
# ═════════════════════════════════════════════════════════════════════════════

MISC_YOGAS = [
    {
        "yoga_id":        "jupiter_saturn_conjunction",
        "name_en":        "Jupiter-Saturn Conjunction",
        "name_sa":        "गुरु-शनि",
        "family":         "misc",
        "polarity":       "neutral",
        "source":         "Vedic transit literature",
        "formation_rule": "Jupiter conjunct with Saturn (a 20-year cycle event).",
        "detect":         lambda c: conjunct(c, "Jupiter", "Saturn"),
        "domains":        ["paradigm_shift", "mid_life_transition"],
        "general_effect": "Generational paradigm shift; structured wisdom development.",
        "remedy_hooks":   ["jupiter_saturn_meditation"],
    },
    {
        "yoga_id":        "naga_yoga",
        "name_en":        "Naga Yoga",
        "name_sa":        "नाग",
        "family":         "misc",
        "polarity":       "negative",
        "source":         "Saravali",
        "formation_rule": "Mars, Saturn together with Rahu or Ketu.",
        "detect":         lambda c: (
            conjunct(c, "Mars", "Saturn") and (conjunct(c, "Mars", "Rahu") or conjunct(c, "Mars", "Ketu"))
        ),
        "domains":        ["intense_struggle", "hidden_enemies"],
        "general_effect": "Hidden enemies, intense psychic struggles; spiritual protection needed.",
        "remedy_hooks":   ["multi_planet_remediation"],
    },
    {
        "yoga_id":        "shankh_yoga",
        "name_en":        "Shankh Yoga (Conch)",
        "name_sa":        "शङ्ख",
        "family":         "misc",
        "polarity":       "positive",
        "source":         "Mantreshwara",
        "formation_rule": "Lord of 5th in 6th, Lord of 6th in 5th, Lord of Lagna strong.",
        "detect":         lambda c: (
            planet_house(c, lord_of_house(c, 5)) == 6 and
            planet_house(c, lord_of_house(c, 6)) == 5 and
            dignity(c, lord_of_house(c, 1)) in ("exalted", "own", "mooltrikona", "friend")
        ),
        "domains":        ["long_life", "virtuous_conduct", "famous_works"],
        "general_effect": "Long life, virtuous conduct, fame through good works.",
        "remedy_hooks":   ["maintain_lagna_lord"],
    },
    {
        "yoga_id":        "indra_yoga",
        "name_en":        "Indra Yoga",
        "name_sa":        "इन्द्र",
        "family":         "misc",
        "polarity":       "positive",
        "source":         "Mantreshwara",
        "formation_rule": "Lord of 5th in 11th, Lord of 11th in 5th, Moon in 5th.",
        "detect":         lambda c: (
            planet_house(c, lord_of_house(c, 5)) == 11 and
            planet_house(c, lord_of_house(c, 11)) == 5 and
            planet_house(c, "Moon") == 5
        ),
        "domains":        ["leadership", "elite_status"],
        "general_effect": "King among peers; royal pleasures and command.",
        "remedy_hooks":   ["honor_5th_11th"],
    },
    {
        "yoga_id":        "kahala_strict",
        "name_en":        "Kahala Yoga (strict)",
        "name_sa":        "कहल (कठोर)",
        "family":         "misc",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.36",
        "formation_rule": "Lords of 4th and 9th in mutual kendras, lagna lord strong.",
        "detect":         lambda c: (
            planet_house(c, lord_of_house(c, 4)) is not None and
            planet_house(c, lord_of_house(c, 9)) is not None and
            ((planet_house(c, lord_of_house(c, 4)) - planet_house(c, lord_of_house(c, 9))) % 12) in (0, 3, 6, 9) and
            dignity(c, lord_of_house(c, 1)) in ("exalted", "own", "mooltrikona", "friend")
        ),
        "domains":        ["command", "armies", "valour"],
        "general_effect": "Commander qualities; leads large organizations with courage.",
        "remedy_hooks":   ["strengthen_kendra_lords"],
    },
    {
        "yoga_id":        "parvata_yoga",
        "name_en":        "Parvata Yoga",
        "name_sa":        "पर्वत",
        "family":         "misc",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.39",
        "formation_rule": "Lord of Lagna and 12th in kendras, OR 6th & 8th houses empty/with benefics.",
        "detect":         lambda c: (
            (planet_house(c, lord_of_house(c, 1)) in KENDRA_HOUSES and
             planet_house(c, lord_of_house(c, 12)) in KENDRA_HOUSES) or
            (len(planets_in_house(c, 6)) == 0 and len(planets_in_house(c, 8)) == 0)
        ),
        "domains":        ["fame", "eloquence", "scholarship", "leadership"],
        "general_effect": "Famous, eloquent, scholarly; head of a region or community.",
        "remedy_hooks":   ["maintain_lagna_12th"],
    },
    {
        "yoga_id":        "trilochana_yoga",
        "name_en":        "Trilochana Yoga (Three-Eyed)",
        "name_sa":        "त्रिलोचन",
        "family":         "misc",
        "polarity":       "positive",
        "source":         "Phaladeepika",
        "formation_rule": "Sun, Moon and Mars together in trikona signs (Aries/Leo/Sagittarius).",
        "detect":         lambda c: (
            planet_sign(c, "Sun") in ("Aries", "Leo", "Sagittarius") and
            planet_sign(c, "Moon") in ("Aries", "Leo", "Sagittarius") and
            planet_sign(c, "Mars") in ("Aries", "Leo", "Sagittarius")
        ),
        "domains":        ["insight", "spiritual_vision", "victory"],
        "general_effect": "Three-eyed insight; spiritual vision and worldly victory.",
        "remedy_hooks":   ["meditation_third_eye"],
    },
    {
        "yoga_id":        "lagnadhi_yoga",
        "name_en":        "Lagnadhi Yoga",
        "name_sa":        "लग्नाधि",
        "family":         "misc",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.38",
        "formation_rule": "Benefics in 7th and 8th from Lagna (Mercury, Jupiter, Venus only).",
        "detect":         lambda c: (
            any(planet_house(c, b) == 7 for b in ("Mercury", "Jupiter", "Venus")) and
            any(planet_house(c, b) == 8 for b in ("Mercury", "Jupiter", "Venus"))
        ),
        "domains":        ["prestige", "wealth", "ministerial_role"],
        "general_effect": "Confers minister-like prestige; comforts and respect.",
        "remedy_hooks":   ["honor_benefics"],
    },
    {
        "yoga_id":        "chandradhi_lagna",
        "name_en":        "Chandradhi Yoga (from Lagna)",
        "name_sa":        "चन्द्राधि (लग्न)",
        "family":         "misc",
        "polarity":       "positive",
        "source":         "Phaladeepika",
        "formation_rule": "Benefics in 6th, 7th, 8th from Moon AND no malefics there.",
        "detect":         lambda c: (
            planet_house(c, "Moon") is not None and
            sum(
                1 for b in ("Jupiter", "Venus", "Mercury")
                if planet_house(c, b) is not None and
                ((planet_house(c, b) - planet_house(c, "Moon")) % 12) in (5, 6, 7)
            ) >= 2 and
            not any(
                planet_house(c, m) is not None and planet_house(c, "Moon") is not None and
                ((planet_house(c, m) - planet_house(c, "Moon")) % 12) in (5, 6, 7)
                for m in ("Mars", "Saturn")
            )
        ),
        "domains":        ["protected_authority", "smooth_rise"],
        "general_effect": "Smooth rise to authority; protections shield from rivals.",
        "remedy_hooks":   ["honor_benefics"],
    },
    {
        "yoga_id":        "amruth_yoga",
        "name_en":        "Amruth Siddhi Yoga",
        "name_sa":        "अमृत सिद्धि",
        "family":         "misc",
        "polarity":       "positive",
        "source":         "Muhurta tradition",
        "formation_rule": "Jupiter in own/exalted sign, in lagna or trikona, well-aspected.",
        "detect":         lambda c: (
            dignity(c, "Jupiter") in ("exalted", "own", "mooltrikona") and
            planet_house(c, "Jupiter") in (KENDRA_HOUSES | TRIKONA_HOUSES)
        ),
        "domains":        ["spiritual_fulfillment", "wisdom_realization"],
        "general_effect": "Spiritual fulfillment and wisdom realization in this lifetime.",
        "remedy_hooks":   ["honor_jupiter"],
    },
    {
        "yoga_id":        "go_yoga",
        "name_en":        "Go Yoga (Cattle / Prosperity)",
        "name_sa":        "गो",
        "family":         "misc",
        "polarity":       "positive",
        "source":         "Mantreshwara",
        "formation_rule": "Jupiter in mooltrikona, Lord of 2nd in kendra, Lord of lagna with Jupiter.",
        "detect":         lambda c: (
            is_mooltrikona(c, "Jupiter") and
            planet_house(c, lord_of_house(c, 2)) in KENDRA_HOUSES and
            conjunct(c, "Jupiter", lord_of_house(c, 1))
        ),
        "domains":        ["wealth_in_cattle", "agricultural_wealth", "abundance"],
        "general_effect": "Wealth in lands, cattle, and primary abundance.",
        "remedy_hooks":   ["honor_cows", "agricultural_blessings"],
    },
    {
        "yoga_id":        "vidya_yoga",
        "name_en":        "Vidya Yoga (Education)",
        "name_sa":        "विद्या",
        "family":         "misc",
        "polarity":       "positive",
        "source":         "Phaladeepika",
        "formation_rule": "Mercury, Jupiter in connection with 4th/5th house or their lords.",
        "detect":         lambda c: (
            (planet_house(c, "Mercury") in (4, 5) or planet_house(c, "Jupiter") in (4, 5)) and
            (conjunct(c, "Mercury", lord_of_house(c, 4)) or
             conjunct(c, "Mercury", lord_of_house(c, 5)) or
             conjunct(c, "Jupiter", lord_of_house(c, 4)) or
             conjunct(c, "Jupiter", lord_of_house(c, 5)))
        ),
        "domains":        ["education", "scholarship", "deep_learning"],
        "general_effect": "Excellent education and scholarly achievement.",
        "remedy_hooks":   ["honor_saraswati"],
    },
    {
        "yoga_id":        "yoga_karaka",
        "name_en":        "Yoga Karaka Planet",
        "name_sa":        "योगकारक",
        "family":         "misc",
        "polarity":       "positive",
        "source":         "Mantreshwara",
        "formation_rule": "A single planet is the lord of both a kendra and a trikona for the lagna.",
        "detect":         lambda c: (
            asc_sign(c) in ("Taurus", "Cancer", "Leo", "Scorpio", "Aquarius", "Capricorn")
            # For these ascendants, specific planets become yoga karakas
        ),
        "domains":        ["natural_raja_yoga", "lasting_success"],
        "general_effect": "One planet carries the seed of Raja Yoga for the lagna — lasting auspicious effects.",
        "remedy_hooks":   ["identify_yoga_karaka"],
    },
    {
        "yoga_id":        "ravi_chandra_yoga",
        "name_en":        "Ravi-Chandra Yoga",
        "name_sa":        "रवि-चन्द्र",
        "family":         "misc",
        "polarity":       "positive",
        "source":         "Saravali",
        "formation_rule": "Sun and Moon in mutual kendra (1/4/7/10) and well-dignified.",
        "detect":         lambda c: (
            planet_house(c, "Sun") is not None and planet_house(c, "Moon") is not None and
            ((planet_house(c, "Sun") - planet_house(c, "Moon")) % 12) in (0, 3, 6, 9) and
            dignity(c, "Sun") not in ("debilitated", "enemy") and
            dignity(c, "Moon") not in ("debilitated", "enemy")
        ),
        "domains":        ["balanced_authority", "father_mother_blessing"],
        "general_effect": "Balanced solar/lunar nature; father and mother both bless the native.",
        "remedy_hooks":   ["honor_luminaries"],
    },
    {
        "yoga_id":        "siddha_yoga",
        "name_en":        "Siddha Yoga",
        "name_sa":        "सिद्ध",
        "family":         "misc",
        "polarity":       "positive",
        "source":         "Muhurta tradition + natal application",
        "formation_rule": "Jupiter aspecting lagna lord OR in lagna, with Moon strong.",
        "detect":         lambda c: (
            (aspects_planet(c, "Jupiter", lord_of_house(c, 1)) or planet_house(c, "Jupiter") == 1) and
            dignity(c, "Moon") not in ("debilitated", "enemy")
        ),
        "domains":        ["accomplishment", "spiritual_attainment"],
        "general_effect": "Accomplishment in chosen field; spiritual progress possible.",
        "remedy_hooks":   ["honor_jupiter", "moon_strengthening"],
    },
]


# Helper: imported from helpers if missing
def is_mooltrikona(chart, name):
    from yogas_helpers import is_mooltrikona as _is
    return _is(chart, name)


# ═════════════════════════════════════════════════════════════════════════════
# EXPORT
# ═════════════════════════════════════════════════════════════════════════════

CATALOG_3 = (
    SPECIAL_OUTCOME_YOGAS +
    ARGALA_YOGAS +
    BHAVA_YOGAS +
    PLANET_IN_HOUSE_YOGAS +
    MISC_YOGAS
)
