"""
rectification_p3.py — Birth Time Rectification (F10-P3)

Approach C: Nadi Amshas (sub-pada granularity refinement)
Master Synthesis: weighted combination of all four BTR approaches.

This is the FINAL module in the F10 series. After P3 ships, all four
classical BTR methodologies are live:
  - Approach A (P2): Parashari event correlation
  - Approach B (P2): Tattva (element/pulse)
  - Approach C (P3): Nadi amshas (this module)
  - Approach D (P1): KP-based event correlation
  - Master (P3):     Weighted consensus across all four

Reuse:
  - dashaflow.cast_chart                            (~2ms per call)
  - rectification.handle_kp_rectification           (Approach D, P1)
  - rectification.SUPPORTED_EVENT_TYPES             (P1 event taxonomy)
  - rectification.MAX_SCAN_WINDOW_MINUTES etc.      (P1 limits)
  - rectification._build_candidate_times            (P1 helper, HH:MM)
  - rectification_p2.handle_event_based_rectification (Approach A, P2)
  - rectification_p2.handle_tattva_rectification    (Approach B, P2)
  - rectification_p2.SIGN_TATTVAS                   (P2 tattva mapping)

Endpoints:
  POST /astro/rectification/nadi_amshas       (Approach C)
  POST /astro/rectification/master            (synthesis)
  GET  /astro/rectification/nadi_amshas/info  (static metadata)

Nadi amsha theory (Chandra Kala Nadi tradition):
  Each 30° sign is divided into 150 nadi amshas of 12 arcminutes each.
  Total: 1800 amshas around the zodiac. Each amsha has a ruling planet
  (deterministically assigned via Vimshottari sequence, scaled to amsha
  resolution) and a set of trait keywords (body-type, complexion, voice,
  intelligence, social, health, longevity).

  Birth time refinement at amsha resolution:
    1 nadi amsha = 12 arcminutes of arc
    Lagna moves ~1° every 4 minutes (varies by latitude/sign)
    So 12 arcminutes ≈ 48 seconds of birth time (equator)
                    ≈ 60-90 seconds at mid-latitudes

  Approach C cannot move the user across signs. It refines WITHIN
  the candidate lagna. Use it AFTER A/B/D have determined the right
  minute, to refine to amsha-level (~10-90 second) precision.

Source: Chandra Kala Nadi (also called Devakeralam) attributed to
        Achyuta; Brihat Nadi-amsha tradition.

Author: F10-P3 build session
Date:   2026-05-18
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

# ============================================================================
# Imports from existing engine + P1 + P2
# ============================================================================

from dashaflow import cast_chart  # type: ignore

import rectification as _p1        # type: ignore
import rectification_p2 as _p2     # type: ignore


# ============================================================================
# Nadi amsha core constants
# ============================================================================

# 150 amshas per sign × 12 signs = 1800 total amshas
AMSHAS_PER_SIGN = 150
TOTAL_AMSHAS = 12 * AMSHAS_PER_SIGN  # 1800

# 30° per sign / 150 amshas = 0.2° per amsha = 12 arcminutes
AMSHA_WIDTH_DEG = 30.0 / AMSHAS_PER_SIGN  # 0.2

# Vimshottari sequence (same as KP sub-lord assignment, but at amsha resolution).
# Used to assign ruling planets to each amsha within a sign deterministically.
VIMSHOTTARI_PLANETS: List[str] = [
    "Ketu", "Venus", "Sun", "Moon", "Mars",
    "Rahu", "Jupiter", "Saturn", "Mercury",
]

# Years per planet in Vimshottari cycle (120-year total)
VIMSHOTTARI_YEARS: Dict[str, int] = {
    "Ketu": 7, "Venus": 20, "Sun": 6, "Moon": 10, "Mars": 7,
    "Rahu": 18, "Jupiter": 16, "Saturn": 19, "Mercury": 17,
}
VIMSHOTTARI_TOTAL_YEARS = 120

# Each sign starts the amsha sequence with a fixed starting planet.
# Source: Chandra Kala Nadi opening verses; matches the classical
# nakshatra-rasi correspondence (each sign begins at the start of
# its first nakshatra, which has a Vimshottari lord).
SIGN_AMSHA_START_PLANET: Dict[str, str] = {
    "Aries":       "Ketu",      # starts at Ashwini (Ketu)
    "Taurus":      "Sun",       # starts at Krittika (Sun)
    "Gemini":      "Mars",      # starts at Mrigashira (Mars)
    "Cancer":      "Jupiter",   # starts at Punarvasu (Jupiter)
    "Leo":         "Ketu",      # starts at Magha (Ketu)
    "Virgo":       "Sun",       # starts at Uttara Phalguni (Sun)
    "Libra":       "Mars",      # starts at Chitra (Mars)
    "Scorpio":     "Jupiter",   # starts at Vishakha (Jupiter)
    "Sagittarius": "Ketu",      # starts at Mula (Ketu)
    "Capricorn":   "Sun",       # starts at Uttara Ashadha (Sun)
    "Aquarius":    "Mars",      # starts at Dhanishta (Mars)
    "Pisces":      "Jupiter",   # starts at Purva Bhadrapada (Jupiter)
}


# ============================================================================
# Trait taxonomy (simplified Chandra Kala Nadi categories)
# ============================================================================

# Each trait dimension has a discrete set of values. The full Chandra Kala
# Nadi tradition has prose descriptions per amsha; we collapse to these
# 7 categorical dimensions for engine usability. Empirical match scoring
# computes per-amsha trait fit; the highest-scoring amsha within the
# candidate lagna is the refined time.

TRAIT_DIMENSIONS: Dict[str, List[str]] = {
    "body_type":       ["lean", "medium", "stocky", "tall_lean", "short_stocky"],
    "complexion":      ["fair", "wheatish", "dark", "ruddy", "pale"],
    "voice":           ["soft", "medium", "loud", "melodious", "rough"],
    "intelligence":    ["analytical", "intuitive", "practical", "creative", "scholarly"],
    "social":          ["introvert", "extrovert", "ambivert", "leader", "follower"],
    "health":          ["robust", "average", "delicate", "respiratory_prone", "digestive_prone"],
    "longevity":       ["short", "medium", "long", "very_long"],
}

# Per-planet trait affinity (which trait values each Vimshottari planet
# tends to indicate when ruling the lagna amsha). Source: classical
# planet-significations from BPHS Ch. 3 + Phaladeepika Ch. 2, mapped
# onto the trait dimensions above.
PLANET_TRAIT_AFFINITY: Dict[str, Dict[str, List[str]]] = {
    "Sun":     {"body_type": ["medium", "tall_lean"], "complexion": ["ruddy", "wheatish"],
                "voice": ["loud", "medium"], "intelligence": ["analytical", "scholarly"],
                "social": ["leader", "extrovert"], "health": ["robust"], "longevity": ["medium", "long"]},
    "Moon":    {"body_type": ["medium", "stocky"], "complexion": ["fair", "pale"],
                "voice": ["soft", "melodious"], "intelligence": ["intuitive", "creative"],
                "social": ["ambivert", "follower"], "health": ["delicate", "respiratory_prone"],
                "longevity": ["medium"]},
    "Mars":    {"body_type": ["lean", "medium"], "complexion": ["ruddy", "dark"],
                "voice": ["loud", "rough"], "intelligence": ["practical"],
                "social": ["leader", "extrovert"], "health": ["robust"], "longevity": ["short", "medium"]},
    "Mercury": {"body_type": ["lean", "medium"], "complexion": ["wheatish", "fair"],
                "voice": ["medium", "melodious"], "intelligence": ["analytical", "scholarly", "creative"],
                "social": ["ambivert"], "health": ["average"], "longevity": ["medium", "long"]},
    "Jupiter": {"body_type": ["stocky", "short_stocky"], "complexion": ["fair", "wheatish"],
                "voice": ["medium", "melodious"], "intelligence": ["scholarly", "intuitive"],
                "social": ["extrovert", "leader"], "health": ["robust"], "longevity": ["long", "very_long"]},
    "Venus":   {"body_type": ["medium", "stocky"], "complexion": ["fair", "wheatish"],
                "voice": ["soft", "melodious"], "intelligence": ["creative", "intuitive"],
                "social": ["extrovert", "ambivert"], "health": ["average"], "longevity": ["long"]},
    "Saturn":  {"body_type": ["tall_lean", "lean"], "complexion": ["dark", "pale"],
                "voice": ["rough", "soft"], "intelligence": ["analytical", "practical"],
                "social": ["introvert", "follower"], "health": ["delicate", "digestive_prone"],
                "longevity": ["very_long", "long"]},
    "Rahu":    {"body_type": ["tall_lean", "lean"], "complexion": ["dark"],
                "voice": ["rough"], "intelligence": ["intuitive", "creative"],
                "social": ["introvert"], "health": ["respiratory_prone", "delicate"],
                "longevity": ["medium"]},
    "Ketu":    {"body_type": ["lean", "short_stocky"], "complexion": ["dark", "pale"],
                "voice": ["soft", "rough"], "intelligence": ["intuitive", "scholarly"],
                "social": ["introvert"], "health": ["digestive_prone"], "longevity": ["short", "medium"]},
}


# ============================================================================
# Core amsha computation
# ============================================================================

def _amsha_for_longitude(longitude: float) -> Dict[str, Any]:
    """
    Given an ecliptic longitude (0-360°), compute its nadi amsha details.

    Returns:
      {
        "sign":             str,    # e.g. "Aquarius"
        "sign_degree":      float,  # 0-30 within sign
        "amsha_index":      int,    # 1-150 within sign
        "amsha_lord":       str,    # ruling Vimshottari planet
        "amsha_global_idx": int,    # 1-1800 absolute
        "arcmin_in_amsha":  float,  # 0-12 fine-grained position
      }
    """
    # Normalize longitude to [0, 360)
    longitude = longitude % 360.0

    # Determine sign (each sign = 30°)
    sign_order = list(_p2.SIGN_LORDS.keys())  # zodiacal order
    sign_idx = int(longitude // 30.0)
    sign_name = sign_order[sign_idx]
    sign_degree = longitude - (sign_idx * 30.0)

    # Amsha index within sign (1-150)
    amsha_idx_within = int(sign_degree / AMSHA_WIDTH_DEG) + 1
    if amsha_idx_within > AMSHAS_PER_SIGN:
        amsha_idx_within = AMSHAS_PER_SIGN

    # Position within amsha (0-12 arcminutes)
    amsha_start_deg = (amsha_idx_within - 1) * AMSHA_WIDTH_DEG
    pos_in_amsha_deg = sign_degree - amsha_start_deg
    arcmin_in_amsha = pos_in_amsha_deg * 60.0

    # Ruling planet: each sign starts with SIGN_AMSHA_START_PLANET[sign],
    # then cycles through VIMSHOTTARI_PLANETS in the standard order.
    start_planet = SIGN_AMSHA_START_PLANET[sign_name]
    start_idx_in_seq = VIMSHOTTARI_PLANETS.index(start_planet)
    # Amsha index 1 -> start_planet; amsha index 2 -> next in sequence; etc.
    planet_idx = (start_idx_in_seq + amsha_idx_within - 1) % len(VIMSHOTTARI_PLANETS)
    amsha_lord = VIMSHOTTARI_PLANETS[planet_idx]

    # Global amsha index (1-1800)
    amsha_global_idx = (sign_idx * AMSHAS_PER_SIGN) + amsha_idx_within

    return {
        "sign":             sign_name,
        "sign_degree":      round(sign_degree, 6),
        "amsha_index":      amsha_idx_within,
        "amsha_lord":       amsha_lord,
        "amsha_global_idx": amsha_global_idx,
        "arcmin_in_amsha":  round(arcmin_in_amsha, 3),
    }


def _score_traits_against_amsha(
    amsha_lord: str,
    user_traits: Dict[str, str],
) -> Tuple[float, Dict[str, Any]]:
    """
    Score user-reported traits against the amsha lord's classical affinity.

    For each trait dimension the user provides, +1 if the user's value
    appears in the planet's affinity list, 0 otherwise. Returns (score,
    per-dimension breakdown).
    """
    affinity = PLANET_TRAIT_AFFINITY.get(amsha_lord, {})
    score = 0.0
    breakdown: Dict[str, Any] = {}

    for dim, user_value in user_traits.items():
        if dim not in TRAIT_DIMENSIONS:
            breakdown[dim] = {"value": user_value, "score": 0.0, "note": "unsupported_dimension"}
            continue
        if user_value not in TRAIT_DIMENSIONS[dim]:
            breakdown[dim] = {
                "value": user_value, "score": 0.0,
                "note": f"value not in supported set {TRAIT_DIMENSIONS[dim]}",
            }
            continue

        affinity_list = affinity.get(dim, [])
        if user_value in affinity_list:
            score += 1.0
            breakdown[dim] = {"value": user_value, "score": 1.0, "matched": True}
        else:
            breakdown[dim] = {
                "value": user_value, "score": 0.0, "matched": False,
                "expected_for_planet": affinity_list,
            }

    return score, breakdown


# ============================================================================
# Approach C handler
# ============================================================================

# Approach C uses finer granularity than A/B/D — we sample at 5-second
# resolution within the candidate window to actually hit amsha boundaries
# (1 amsha ≈ 48-90s of birth time). HH:MM-only candidate-builder is too
# coarse here; we need HH:MM:SS for amsha refinement. Since cast_chart
# requires HH:MM strictly, we use a different strategy: scan at 1-minute
# resolution (HH:MM, reusing P1's _build_candidate_times) and report the
# matching amshas at each minute — the SEQUENCE of amshas across consecutive
# minutes is what gives sub-minute precision.

DEFAULT_C_SCAN_WINDOW_MINUTES = 30
DEFAULT_C_GRANULARITY_MINUTES = 1
MAX_C_TRAITS_PER_REQUEST = 7  # one per dimension max


def handle_nadi_amsha_rectification(
    dob: str,
    time: str,
    lat: float,
    lon: float,
    timezone: str,
    user_traits: Dict[str, str],
    scan_window_minutes: int = DEFAULT_C_SCAN_WINDOW_MINUTES,
    scan_granularity_minutes: int = DEFAULT_C_GRANULARITY_MINUTES,
    top_n: int = _p1.DEFAULT_TOP_N,
) -> Dict[str, Any]:
    """
    Approach C — Nadi Amsha BTR.

    Refines birth time WITHIN the candidate lagna by matching user-reported
    physical/personality traits against classical nadi amsha trait affinities.

    Use this AFTER A/B/D have determined the correct lagna sign; Approach C
    refines to amsha-level (~10-90 second) precision within that sign.

    user_traits: dict of trait_dimension -> trait_value, e.g.
      {"body_type": "lean", "complexion": "wheatish", "voice": "soft", ...}

    Each dimension is optional. More dimensions provided = sharper score
    discrimination. Maximum 7 (one per dimension).
    """
    # Validation
    if not user_traits:
        raise ValueError("At least one trait dimension required for nadi amsha rectification")
    if len(user_traits) > MAX_C_TRAITS_PER_REQUEST:
        raise ValueError(
            f"Too many traits: {len(user_traits)} > {MAX_C_TRAITS_PER_REQUEST}"
        )
    for dim, val in user_traits.items():
        if dim not in TRAIT_DIMENSIONS:
            raise ValueError(
                f"Unsupported trait dimension {dim!r}; "
                f"supported: {sorted(TRAIT_DIMENSIONS.keys())}"
            )
        if val not in TRAIT_DIMENSIONS[dim]:
            raise ValueError(
                f"Unsupported value {val!r} for trait {dim!r}; "
                f"supported: {TRAIT_DIMENSIONS[dim]}"
            )
    if scan_window_minutes > _p1.MAX_SCAN_WINDOW_MINUTES:
        raise ValueError(
            f"scan_window_minutes={scan_window_minutes} exceeds "
            f"MAX_SCAN_WINDOW_MINUTES={_p1.MAX_SCAN_WINDOW_MINUTES}"
        )
    if scan_granularity_minutes < _p1.MIN_SCAN_GRANULARITY_MINUTES:
        raise ValueError(
            f"scan_granularity_minutes={scan_granularity_minutes} below "
            f"MIN_SCAN_GRANULARITY_MINUTES={_p1.MIN_SCAN_GRANULARITY_MINUTES}"
        )

    candidates = _p1._build_candidate_times(time, scan_window_minutes, scan_granularity_minutes)

    scored: List[Dict[str, Any]] = []
    for candidate_time in candidates:
        try:
            chart = cast_chart(dob, candidate_time, lat, lon, timezone)
        except Exception:
            continue
        lagna = chart.get("lagna") or {}
        lagna_sign = lagna.get("sign")
        lagna_degree = float(lagna.get("degree", 0.0))
        if not lagna_sign:
            continue

        # Compute absolute longitude of lagna
        sign_order = list(_p2.SIGN_LORDS.keys())
        try:
            sign_idx = sign_order.index(lagna_sign)
        except ValueError:
            continue
        lagna_longitude = sign_idx * 30.0 + lagna_degree

        amsha_info = _amsha_for_longitude(lagna_longitude)
        trait_score, trait_breakdown = _score_traits_against_amsha(
            amsha_info["amsha_lord"], user_traits
        )

        scored.append({
            "candidate_time":   candidate_time,
            "lagna_sign":       lagna_sign,
            "lagna_degree":     round(lagna_degree, 4),
            "amsha":            amsha_info,
            "trait_score":      trait_score,
            "trait_max":        float(len(user_traits)),
            "trait_breakdown":  trait_breakdown,
        })

    if not scored:
        return {
            "status":          "no_valid_candidates",
            "approach":        "nadi_amshas",
            "reported_time":   time,
            "rectified_time":  None,
            "rectified_lagna": None,
            "rectified_amsha": None,
            "scan_parameters": {
                "window_minutes":      scan_window_minutes,
                "granularity_minutes": scan_granularity_minutes,
                "candidates_scanned":  len(candidates),
                "candidates_valid":    0,
            },
            "top_candidates": [],
            "winner_chart":   None,
            "supported_traits": TRAIT_DIMENSIONS,
        }

    # Rank: trait_score descending, then sub-rank by arcmin_in_amsha
    # (closer to amsha center is more diagnostic)
    scored.sort(key=lambda c: (
        -c["trait_score"],
        abs(c["amsha"]["arcmin_in_amsha"] - 6.0),  # 6 = center of 12-arcmin amsha
    ))
    top = scored[:top_n]
    winner = top[0]

    try:
        winner_chart = cast_chart(dob, winner["candidate_time"], lat, lon, timezone)
    except Exception as exc:
        winner_chart = {"error": f"winner re-cast failed: {exc}"}

    # Confidence: trait_score / trait_max, gap-adjusted
    if len(scored) >= 2:
        score_gap = top[0]["trait_score"] - top[1]["trait_score"]
        max_possible = float(len(user_traits))
        confidence_pct = (
            min(100.0, (score_gap / max(max_possible, 1.0)) * 100.0)
            if max_possible > 0 else 0.0
        )
    else:
        confidence_pct = 0.0

    return {
        "status":          "ok",
        "approach":        "nadi_amshas",
        "reported_time":   time,
        "rectified_time":  winner["candidate_time"],
        "rectified_lagna": {
            "sign":   winner["lagna_sign"],
            "degree": winner["lagna_degree"],
        },
        "rectified_amsha": winner["amsha"],
        "trait_score":     winner["trait_score"],
        "trait_max":       winner["trait_max"],
        "confidence_pct":  round(confidence_pct, 1),
        "scan_parameters": {
            "window_minutes":      scan_window_minutes,
            "granularity_minutes": scan_granularity_minutes,
            "candidates_scanned":  len(candidates),
            "candidates_valid":    len(scored),
        },
        "top_candidates": [
            {
                "rank":            i + 1,
                "candidate_time":  c["candidate_time"],
                "lagna_sign":      c["lagna_sign"],
                "lagna_degree":    c["lagna_degree"],
                "amsha":           c["amsha"],
                "trait_score":     c["trait_score"],
                "trait_breakdown": c["trait_breakdown"],
            }
            for i, c in enumerate(top)
        ],
        "winner_chart": winner_chart,
        "classical_reference": (
            "Chandra Kala Nadi (Devakeralam) attributed to Achyuta; "
            "Brihat Nadi-amsha tradition. Trait taxonomy simplified from "
            "BPHS Ch. 3 and Phaladeepika Ch. 2 planet-significations."
        ),
    }


def handle_nadi_amshas_info() -> Dict[str, Any]:
    """Static metadata about the nadi amsha system + trait taxonomy."""
    return {
        "amshas_per_sign":     AMSHAS_PER_SIGN,
        "total_amshas":        TOTAL_AMSHAS,
        "amsha_width_deg":     AMSHA_WIDTH_DEG,
        "amsha_width_arcmin":  AMSHA_WIDTH_DEG * 60.0,
        "supported_trait_dimensions": TRAIT_DIMENSIONS,
        "vimshottari_planets": VIMSHOTTARI_PLANETS,
        "sign_amsha_start_planets": SIGN_AMSHA_START_PLANET,
        "note": (
            "Each 30-degree sign is divided into 150 nadi amshas of "
            "12 arcminutes each (0.2 degrees). Approach C refines birth "
            "time WITHIN the candidate lagna; it cannot move the user "
            "across signs. Run KP / event_based / tattva first to lock "
            "the lagna sign, then run nadi_amshas to refine to amsha-level "
            "precision (~10-90 seconds of birth time). The /master endpoint "
            "does this automatically."
        ),
    }


# ============================================================================
# Master Synthesis
# ============================================================================

# Weights for cross-method consensus. Tuned to classical authority + data
# requirements: KP and Parashari need event data; Tattva needs personal
# observation; Nadi amshas need trait data. When multiple methods agree on
# lagna sign, confidence multiplies.
MASTER_WEIGHTS: Dict[str, float] = {
    "kp_based":              1.0,   # Approach D — most algorithmic, deterministic
    "event_based_parashari": 1.0,   # Approach A — most classical
    "tattva":                0.6,   # Approach B — single observation, lower weight
    "nadi_amshas":           0.4,   # Approach C — refinement only, not sign-determination
}


def handle_master_rectification(
    dob: str,
    time: str,
    lat: float,
    lon: float,
    timezone: str,
    events: Optional[List[Dict[str, Any]]] = None,
    observed_tattva: Optional[str] = None,
    user_traits: Optional[Dict[str, str]] = None,
    scan_window_minutes: int = _p1.DEFAULT_SCAN_WINDOW_MINUTES,
    scan_granularity_minutes: int = _p1.DEFAULT_SCAN_GRANULARITY_MINUTES,
) -> Dict[str, Any]:
    """
    Master Synthesis — weighted consensus across all four BTR approaches.

    Runs whichever approaches have data:
      - KP-based + Parashari event_based: if events provided
      - Tattva: if observed_tattva provided
      - Nadi amshas: if user_traits provided (AFTER above, to refine
        within the consensus lagna sign)

    Returns a single rectified_time with cross-method agreement score.
    When multiple methods agree on lagna sign, confidence is high.
    When methods disagree, the response reflects the uncertainty.
    """
    if not (events or observed_tattva or user_traits):
        raise ValueError(
            "Master synthesis requires at least one of: events, "
            "observed_tattva, user_traits"
        )

    # Track per-approach results
    approach_results: Dict[str, Any] = {}
    sign_votes: Dict[str, float] = {}   # sign_name -> total weight
    time_votes: List[Tuple[str, str, float]] = []  # (approach, time, weight)

    # ---- Approach D (KP) + Approach A (Parashari) — both use events ----
    if events:
        try:
            kp_result = _p1.handle_kp_rectification(
                dob=dob, time=time, lat=lat, lon=lon, timezone=timezone,
                events=events,
                scan_window_minutes=scan_window_minutes,
                scan_granularity_minutes=scan_granularity_minutes,
                top_n=5,
            )
            approach_results["kp_based"] = {
                "status":          kp_result.get("status"),
                "rectified_time":  kp_result.get("rectified_time"),
                "rectified_lagna": kp_result.get("rectified_lagna"),
                "confidence_pct":  kp_result.get("confidence_pct"),
            }
            if kp_result.get("status") == "ok":
                rl = kp_result.get("rectified_lagna") or {}
                sign = rl.get("sign")
                if sign:
                    sign_votes[sign] = sign_votes.get(sign, 0.0) + MASTER_WEIGHTS["kp_based"]
                    time_votes.append(("kp_based", kp_result["rectified_time"], MASTER_WEIGHTS["kp_based"]))
        except Exception as exc:
            approach_results["kp_based"] = {"status": "error", "error": str(exc)}

        try:
            parashari_result = _p2.handle_event_based_rectification(
                dob=dob, time=time, lat=lat, lon=lon, timezone=timezone,
                events=events,
                scan_window_minutes=scan_window_minutes,
                scan_granularity_minutes=scan_granularity_minutes,
                top_n=5,
            )
            approach_results["event_based_parashari"] = {
                "status":          parashari_result.get("status"),
                "rectified_time":  parashari_result.get("rectified_time"),
                "rectified_lagna": parashari_result.get("rectified_lagna"),
                "confidence_pct":  parashari_result.get("confidence_pct"),
            }
            if parashari_result.get("status") == "ok":
                rl = parashari_result.get("rectified_lagna") or {}
                sign = rl.get("sign")
                if sign:
                    sign_votes[sign] = sign_votes.get(sign, 0.0) + MASTER_WEIGHTS["event_based_parashari"]
                    time_votes.append(("event_based_parashari", parashari_result["rectified_time"], MASTER_WEIGHTS["event_based_parashari"]))
        except Exception as exc:
            approach_results["event_based_parashari"] = {"status": "error", "error": str(exc)}

    # ---- Approach B (Tattva) ----
    if observed_tattva:
        try:
            tattva_result = _p2.handle_tattva_rectification(
                dob=dob, time=time, lat=lat, lon=lon, timezone=timezone,
                observed_tattva=observed_tattva,
                scan_window_minutes=scan_window_minutes,
                scan_granularity_minutes=scan_granularity_minutes,
            )
            approach_results["tattva"] = {
                "status":          tattva_result.get("status"),
                "rectified_time":  tattva_result.get("rectified_time"),
                "rectified_lagna": tattva_result.get("rectified_lagna"),
                "candidates_matching": tattva_result.get("scan_parameters", {}).get("candidates_matching"),
            }
            if tattva_result.get("status") == "ok":
                rl = tattva_result.get("rectified_lagna") or {}
                sign = rl.get("sign")
                if sign:
                    sign_votes[sign] = sign_votes.get(sign, 0.0) + MASTER_WEIGHTS["tattva"]
                    time_votes.append(("tattva", tattva_result["rectified_time"], MASTER_WEIGHTS["tattva"]))
        except Exception as exc:
            approach_results["tattva"] = {"status": "error", "error": str(exc)}

    # ---- Determine consensus sign + consensus time ----
    consensus_sign: Optional[str] = None
    if sign_votes:
        consensus_sign = max(sign_votes.items(), key=lambda kv: kv[1])[0]

    # Weighted average of rectified times (only those that agree on consensus sign)
    consensus_time: Optional[str] = None
    if consensus_sign and time_votes:
        agreeing_votes = []
        for approach, t, weight in time_votes:
            ar = approach_results.get(approach, {})
            ar_sign = (ar.get("rectified_lagna") or {}).get("sign")
            if ar_sign == consensus_sign:
                agreeing_votes.append((t, weight))
        if agreeing_votes:
            total_w = sum(w for _, w in agreeing_votes)
            avg_minutes = sum(
                (int(t.split(":")[0]) * 60 + int(t.split(":")[1])) * w
                for t, w in agreeing_votes
            ) / max(total_w, 0.001)
            avg_h = int(avg_minutes // 60)
            avg_m = int(round(avg_minutes - avg_h * 60))
            if avg_m == 60:
                avg_h += 1
                avg_m = 0
            consensus_time = f"{avg_h:02d}:{avg_m:02d}"

    # ---- Approach C (Nadi amshas) — refinement INSIDE consensus sign ----
    # Use consensus_time as the new center for the amsha scan window;
    # narrower window since we've already locked the sign.
    nadi_result: Optional[Dict[str, Any]] = None
    if user_traits:
        nadi_center_time = consensus_time if consensus_time else time
        try:
            nadi_result = handle_nadi_amsha_rectification(
                dob=dob, time=nadi_center_time, lat=lat, lon=lon, timezone=timezone,
                user_traits=user_traits,
                scan_window_minutes=min(scan_window_minutes, 30),  # narrow window
                scan_granularity_minutes=scan_granularity_minutes,
                top_n=5,
            )
            approach_results["nadi_amshas"] = {
                "status":          nadi_result.get("status"),
                "rectified_time":  nadi_result.get("rectified_time"),
                "rectified_lagna": nadi_result.get("rectified_lagna"),
                "rectified_amsha": nadi_result.get("rectified_amsha"),
                "trait_score":     nadi_result.get("trait_score"),
                "trait_max":       nadi_result.get("trait_max"),
                "confidence_pct":  nadi_result.get("confidence_pct"),
            }
            # Nadi result REPLACES consensus_time with the amsha-refined value
            # IF the nadi-rectified lagna sign matches the consensus sign.
            nadi_sign = (nadi_result.get("rectified_lagna") or {}).get("sign")
            if nadi_result.get("status") == "ok" and (
                consensus_sign is None or nadi_sign == consensus_sign
            ):
                consensus_time = nadi_result.get("rectified_time", consensus_time)
                if consensus_sign is None:
                    consensus_sign = nadi_sign
        except Exception as exc:
            approach_results["nadi_amshas"] = {"status": "error", "error": str(exc)}

    # ---- Final confidence score: agreement-weighted ----
    total_weight_used = sum(
        MASTER_WEIGHTS[k] for k in approach_results
        if approach_results[k].get("status") == "ok"
    )
    consensus_weight = sign_votes.get(consensus_sign, 0.0) if consensus_sign else 0.0
    agreement_pct = (
        round((consensus_weight / total_weight_used) * 100.0, 1)
        if total_weight_used > 0 else 0.0
    )

    # ---- Recast winning chart at consensus_time ----
    if consensus_time:
        try:
            winner_chart = cast_chart(dob, consensus_time, lat, lon, timezone)
        except Exception as exc:
            winner_chart = {"error": f"winner re-cast failed: {exc}"}
    else:
        winner_chart = None

    return {
        "status":           "ok" if consensus_sign else "no_consensus",
        "approach":         "master_synthesis",
        "reported_time":    time,
        "rectified_time":   consensus_time,
        "rectified_lagna_sign": consensus_sign,
        "agreement_pct":    agreement_pct,
        "approaches_run":   sorted(approach_results.keys()),
        "approaches_succeeded": sorted([
            k for k, v in approach_results.items() if v.get("status") == "ok"
        ]),
        "sign_votes":       sign_votes,
        "per_approach_results": approach_results,
        "winner_chart":     winner_chart,
        "synthesis_note": (
            f"Consensus across {len([k for k,v in approach_results.items() if v.get('status')=='ok'])} "
            f"successful approaches. Weighted lagna-sign agreement: {agreement_pct}%. "
            f"When approaches disagree on the lagna sign, prefer the heavier-weighted "
            f"classical methods (KP and Parashari each weighted 1.0; tattva 0.6; "
            f"nadi amshas 0.4 since they refine rather than determine the sign)."
        ),
    }
