"""
mundane.py — numiVeda Kaaliyo Astro Engine — Module F4 (Mundane Astrology)

Three endpoints for mundane (worldly) astrology — country outlook, company
incorporation analysis, and event/poll-chart analysis:

    handle_country_outlook       — National chart analysis (registry or override)
    handle_company_chart         — Company incorporation chart with mundane lens
    handle_election_prediction   — Event-chart analysis for elections / major
                                   civic events.  NO winner predicted, NO
                                   politician names accepted or emitted.

Design (per HANDOVER_v6 carry-forward, reuse-first):
    P1 — All astronomy through cast_chart (dashaflow).
    P2 — Reuse: chart["shadbala"], chart["yogas"], chart["dashas"],
         chart["jaimini_karakas"], chart["arudha_padas"], chart["graha_yuddha"],
         chart["gandanta"] are ALL pre-computed by cast_chart. F4 only
         interprets them with a mundane lens, never recomputes.
    P3 — Eclipse module reused at MODULE level (not HTTP) via direct import
         of handle_upcoming_eclipses for the election endpoint.
    P5 — F4 has its own COUNTRY_REGISTRY, MUNDANE_HOUSE_MEANINGS,
         MUNDANE_RELEVANT_YOGAS, F4_CITATIONS. No coupling to yogas_helpers
         beyond what cast_chart already exposes.

Liability framing (non-negotiable):
    Every response carries a `disclaimer` field stating classical-research
    framing. /mundane/election_prediction NEVER names parties or politicians
    in input or output. Output describes mundane indicators only ("10th lord
    strong", "Moon afflicted", "eclipse within N days"), never winners.

Input mode flexibility (same pattern as F6/F6b):
    Country endpoint accepts EITHER country_code (registry lookup) OR
    chart_override (user-supplied dob/time/lat/lon/timezone). If both
    provided, override wins.

Public API:
    handle_country_outlook(country_code, chart_override, analysis_date) -> dict
    handle_company_chart(incorporation, business_sector) -> dict
    handle_election_prediction(event, country_code) -> dict

Author: Claude (F4, 2026-05-18)
"""

from typing import Dict, List, Optional, Any
from datetime import date, datetime, timedelta


# Foundation imports (guarded — Principle 1) ─────────────────────────────────
try:
    from dashaflow import cast_chart
except ImportError as e:
    raise ImportError(f"F4 mundane requires dashaflow.cast_chart: {e}")

try:
    from astro_helpers import SIGNS_ORDER, SIGN_TO_LORD
except ImportError as e:
    raise ImportError(f"F4 mundane requires astro_helpers: {e}")

# Module-level reuse of eclipse (F2a) — soft import, election endpoint
# degrades gracefully if eclipse not available
try:
    from eclipse import handle_upcoming_eclipses as _eclipse_upcoming
    _ECLIPSE_AVAILABLE = True
except ImportError:
    _eclipse_upcoming = None
    _ECLIPSE_AVAILABLE = False


# ════════════════════════════════════════════════════════════════════════
# COUNTRY REGISTRY — canonical mundane charts
# ════════════════════════════════════════════════════════════════════════
# Each entry: ISO 3166-1 alpha-2 code → chart parameters.
# Sources documented per entry; this is the mundane-tradition consensus.

COUNTRY_REGISTRY: Dict[str, Dict[str, Any]] = {
    "IN": {
        "dob": "1947-08-15", "time": "00:00",
        "lat": 28.6139, "lon": 77.2090, "timezone": "Asia/Kolkata",
        "name": "India (Republic)",
        "source": "Midnight independence proclamation, New Delhi (KN Rao / B.V. Raman mundane consensus)",
    },
    "US": {
        "dob": "1776-07-04", "time": "17:10",
        "lat": 39.9526, "lon": -75.1652, "timezone": "America/New_York",
        "name": "United States of America",
        "source": "Sibly chart, Philadelphia (mundane astrology consensus)",
    },
    "UK": {
        "dob": "1801-01-01", "time": "00:00",
        "lat": 51.5074, "lon": -0.1278, "timezone": "Europe/London",
        "name": "United Kingdom",
        "source": "Act of Union 1801, London",
    },
    "CN": {
        "dob": "1949-10-01", "time": "15:15",
        "lat": 39.9042, "lon": 116.4074, "timezone": "Asia/Shanghai",
        "name": "China (People's Republic)",
        "source": "PRC proclamation, Tiananmen, Beijing",
    },
    "RU": {
        "dob": "1991-12-25", "time": "19:35",
        "lat": 55.7558, "lon": 37.6173, "timezone": "Europe/Moscow",
        "name": "Russian Federation",
        "source": "Gorbachev resignation / USSR dissolution, Moscow",
    },
    "JP": {
        "dob": "1947-05-03", "time": "00:00",
        "lat": 35.6762, "lon": 139.6503, "timezone": "Asia/Tokyo",
        "name": "Japan",
        "source": "Post-war constitution enacted, Tokyo",
    },
    "DE": {
        "dob": "1990-10-03", "time": "00:00",
        "lat": 52.5200, "lon": 13.4050, "timezone": "Europe/Berlin",
        "name": "Germany (reunified)",
        "source": "Reunification, Berlin",
    },
    "FR": {
        "dob": "1958-10-04", "time": "18:30",
        "lat": 48.8566, "lon": 2.3522, "timezone": "Europe/Paris",
        "name": "France (5th Republic)",
        "source": "5th Republic constitution, Paris",
    },
    "AU": {
        "dob": "1901-01-01", "time": "00:00",
        "lat": -33.8688, "lon": 151.2093, "timezone": "Australia/Sydney",
        "name": "Australia",
        "source": "Federation, Sydney",
    },
    "PK": {
        "dob": "1947-08-14", "time": "00:00",
        "lat": 24.8607, "lon": 67.0011, "timezone": "Asia/Karachi",
        "name": "Pakistan",
        "source": "Independence, Karachi",
    },
}


# ════════════════════════════════════════════════════════════════════════
# MUNDANE INTERPRETATION TABLES
# ════════════════════════════════════════════════════════════════════════

# House meanings in mundane astrology (differ from natal):
# Source: Varahamihira, Brihat Samhita; B.V. Raman, "Mundane Astrology" (1992).
MUNDANE_HOUSE_MEANINGS: Dict[int, str] = {
    1:  "The nation/entity itself; its identity, vitality, general condition",
    2:  "National wealth, treasury, currency, food supply, banking",
    3:  "Communications, transport, neighboring nations, press, courage",
    4:  "Masses, common people, agriculture, land, housing, mining",
    5:  "Speculation, entertainment, children of the nation, education policy, sports",
    6:  "Armed forces, police, debt, disease, opposition, civil unrest",
    7:  "Foreign relations, trade partners, war/peace, open enemies",
    8:  "Mortality rate, secret enemies, foreign debt, transformations, scandals",
    9:  "Judiciary, religion, higher education, philosophy, international relations",
    10: "Government, head of state, ruling party, sovereignty, executive power",
    11: "Parliament, legislative bodies, gains, allies, financial aspirations",
    12: "Losses, expenses, prisons, foreign affairs (covert), spiritual matters",
}

# Mundane-relevant yogas (filtered from cast_chart["yogas"]):
# These are the yogas that carry special significance for nations/companies.
MUNDANE_RELEVANT_YOGAS = {
    # Wealth/prosperity
    "Lakshmi Yoga", "Dhana Yoga", "Mahalakshmi Yoga",
    # Power/governance
    "Raja Yoga", "Gajakesari Yoga", "Adhi Yoga", "Chamara Yoga",
    "Bhadra Yoga", "Hamsa Yoga", "Malavya Yoga", "Ruchaka Yoga", "Sasa Yoga",
    # Negative — affliction / weakness
    "Kemadruma Yoga", "Daridra Yoga", "Sakata Yoga", "Vesi Yoga", "Vasi Yoga",
    # Spiritual / renunciation (mundane meaning: instability of rulership)
    "Pravrajya Yoga", "Sanyasa Yoga",
}

# Business sector → planetary significator mapping
# Source: Phaladeepika, Saravali; sector mappings per B.V. Raman, "Hindu Predictive Astrology"
SECTOR_SIGNIFICATORS: Dict[str, List[str]] = {
    "technology":     ["Mercury", "Rahu"],     # Information, networks, disruption
    "finance":        ["Jupiter", "Venus"],    # Wealth, capital, prosperity
    "banking":        ["Jupiter", "Mercury"],  # Lending, accounts
    "manufacturing":  ["Mars", "Saturn"],      # Heavy industry, construction
    "retail":         ["Mercury", "Venus"],    # Commerce, consumer goods
    "media":          ["Mercury", "Venus"],    # Communications, entertainment
    "energy":         ["Sun", "Mars"],         # Power, oil, electricity
    "healthcare":     ["Jupiter", "Moon"],     # Healing, public wellbeing
    "agriculture":    ["Moon", "Venus"],       # Food, land cultivation
    "real_estate":    ["Mars", "Saturn"],      # Land, property, structures
    "luxury":         ["Venus", "Jupiter"],    # Fashion, jewelry, hospitality
    "transport":      ["Mercury", "Mars"],     # Movement, logistics
    "education":      ["Jupiter", "Mercury"],  # Teaching, learning
    "spiritual":      ["Jupiter", "Ketu"],     # Religion, philosophy, divination
}


# ════════════════════════════════════════════════════════════════════════
# CITATIONS
# ════════════════════════════════════════════════════════════════════════

F4_CITATIONS: Dict[str, List[str]] = {
    "country_outlook": [
        "Varahamihira, Brihat Samhita (6th c. CE), Ch. 5–11 (mundane omens & national fates)",
        "Parashara, Brihat Parashara Hora Shastra, Ch. 86 (Rajya Yoga & royal yogas — applied to states)",
        "B.V. Raman, Mundane Astrology (1992), Ch. 3 (national charts) & Ch. 7 (mundane houses)",
    ],
    "company_chart": [
        "Varahamihira, Brihat Samhita, Ch. 49 (muhurta for establishment)",
        "Parashara, BPHS, Ch. 35–37 (Dhana yogas, wealth indicators)",
        "K.S. Charak, Predictive Astrology (2002), Ch. 12 (incorporation & business charts)",
    ],
    "election_prediction": [
        "Varahamihira, Brihat Samhita, Ch. 9 (political events & graha yuddha)",
        "Parashara, BPHS, Ch. 90 (prashna & event-chart principles applied to civic events)",
        "B.V. Raman, Mundane Astrology, Ch. 12 (election & event analysis)",
        "Classical caveat: mundane astrology describes indicators, not outcomes.",
    ],
}


# Liability framing — every F4 response carries this
F4_DISCLAIMER = (
    "Classical Vedic astrology analysis per Brihat Parashara Hora Shastra and "
    "Brihat Samhita. This is a scholarly/research output, not a prediction "
    "service. Mundane indicators describe planetary conditions in classical "
    "frameworks; they are not forecasts of real-world outcomes."
)

F4_ELECTION_DISCLAIMER_EXTRA = (
    "This endpoint analyzes the chart of a civic event (such as a poll opening "
    "moment). It does NOT predict winners, name parties, name candidates, or "
    "forecast electoral outcomes. Inputs containing such names will not change "
    "the analysis. Use for classical/scholarly study only."
)


# ════════════════════════════════════════════════════════════════════════
# INTERNAL HELPERS
# ════════════════════════════════════════════════════════════════════════

def _cast_or_error(birth: Dict[str, Any], context: str) -> Dict[str, Any]:
    """Cast a chart, returning either the chart or an error dict."""
    try:
        return cast_chart(
            dob=birth["dob"], time=birth["time"],
            lat=birth["lat"], lon=birth["lon"],
            timezone=birth.get("timezone", "Asia/Kolkata"),
        )
    except Exception as e:
        return {"_error": f"Chart cast failed ({context}): {e}"}


def _house_lord(house_num: int, chart: Dict[str, Any]) -> Optional[str]:
    """Return the planet ruling the sign that occupies house N from lagna."""
    lagna = chart.get("lagna", {})
    lagna_sign = lagna.get("sign")
    if not lagna_sign or lagna_sign not in SIGNS_ORDER:
        return None
    lagna_idx = SIGNS_ORDER.index(lagna_sign)
    target_sign_idx = (lagna_idx + house_num - 1) % 12
    target_sign = SIGNS_ORDER[target_sign_idx]
    return SIGN_TO_LORD.get(target_sign)


def _planet_state(planet: str, chart: Dict[str, Any]) -> Dict[str, Any]:
    """Compact state summary of a planet from chart fields."""
    p = chart.get("planets", {}).get(planet, {})
    shadbala = chart.get("shadbala", {}).get(planet, {})
    if isinstance(shadbala, dict):
        total_rupas = shadbala.get("total_rupas") or shadbala.get("total") or shadbala.get("rupas")
    else:
        total_rupas = shadbala
    return {
        "planet":         planet,
        "sign":           p.get("sign"),
        "house":          p.get("house"),
        "dignity":        p.get("dignity"),
        "is_combust":     p.get("is_combust", False),
        "is_retrograde":  p.get("is_retrograde", False),
        "shadbala_rupas": total_rupas,
    }


def _house_lord_assessment(house_num: int, chart: Dict[str, Any]) -> Dict[str, Any]:
    """Strength + condition of the lord of mundane-significant house."""
    lord = _house_lord(house_num, chart)
    if not lord:
        return {"house": house_num,
                "meaning": MUNDANE_HOUSE_MEANINGS.get(house_num, ""),
                "lord": None,
                "verdict": "unknown (lagna not determinable)"}
    state = _planet_state(lord, chart)
    # Verdict synthesis — transparent scoring per Section 8.5
    verdict_parts = []
    dignity = (state.get("dignity") or "").lower()
    if dignity in {"exalted", "mooltrikona", "own_sign"}:
        verdict_parts.append("dignified")
    elif dignity in {"debilitated", "great_enemy"}:
        verdict_parts.append("afflicted")
    elif dignity in {"enemy"}:
        verdict_parts.append("weak")
    else:
        verdict_parts.append("neutral")
    if state.get("is_combust"):
        verdict_parts.append("combust")
    if state.get("is_retrograde"):
        verdict_parts.append("retrograde")
    rupas = state.get("shadbala_rupas")
    if isinstance(rupas, (int, float)):
        if rupas >= 7.0:
            verdict_parts.append("shadbala-strong")
        elif rupas < 5.0:
            verdict_parts.append("shadbala-weak")
    return {
        "house":   house_num,
        "meaning": MUNDANE_HOUSE_MEANINGS.get(house_num, ""),
        "lord":    lord,
        "state":   state,
        "verdict": ", ".join(verdict_parts),
    }


def _filter_mundane_yogas(chart: Dict[str, Any]) -> List[Dict[str, Any]]:
    """From cast_chart's yogas list, pick those with mundane significance."""
    raw = chart.get("yogas", []) or []
    out: List[Dict[str, Any]] = []
    for y in raw:
        if not isinstance(y, dict):
            continue
        name = y.get("name", "")
        # Match either exact or stripped (some yogas may carry trailing variants)
        base = name.replace(" Yoga", "").strip()
        if name in MUNDANE_RELEVANT_YOGAS or f"{base} Yoga" in MUNDANE_RELEVANT_YOGAS:
            out.append(y)
    return out


def _current_dasha_snapshot(chart: Dict[str, Any]) -> Dict[str, Any]:
    """Snapshot of running MD/AD from chart["dashas"] — purely a read."""
    d = chart.get("dashas", {}) or {}
    return {
        "mahadasha":   d.get("maha"),
        "antardasha":  d.get("antar"),
        "pratyantar":  d.get("pratyantar"),
    }


def _moon_condition(chart: Dict[str, Any]) -> Dict[str, Any]:
    """Moon paksha (waxing/waning) state + house — central to mundane work."""
    moon = chart.get("planets", {}).get("Moon", {})
    sun  = chart.get("planets", {}).get("Sun", {})
    moon_long = moon.get("degree")
    sun_long  = sun.get("degree")
    # Determine waxing vs waning by sign-relative position
    moon_sign = moon.get("sign")
    sun_sign  = sun.get("sign")
    paksha = None
    if moon_sign and sun_sign and moon_sign in SIGNS_ORDER and sun_sign in SIGNS_ORDER:
        moon_idx = SIGNS_ORDER.index(moon_sign)
        sun_idx  = SIGNS_ORDER.index(sun_sign)
        # Sign-distance Sun→Moon: 0-5 = waning towards Amavasya, 6-11 = waxing
        # More precise: post-Amavasya (Moon ahead of Sun by < 180°) = Shukla (waxing)
        sign_distance = (moon_idx - sun_idx) % 12
        paksha = "Shukla (waxing)" if sign_distance < 6 else "Krishna (waning)"
    return {
        "sign":         moon_sign,
        "house":        moon.get("house"),
        "nakshatra":    moon.get("nakshatra"),
        "dignity":      moon.get("dignity"),
        "paksha":       paksha,
        "is_combust":   moon.get("is_combust", False),
    }


def _eclipse_proximity(birth: Dict[str, Any], event_date: str,
                       window_days: int = 30) -> Dict[str, Any]:
    """
    Check if any eclipse falls within ±window_days of event_date.
    Reuses F2a eclipse module at the function level (no HTTP roundtrip).
    """
    if not _ECLIPSE_AVAILABLE:
        return {"available": False, "reason": "eclipse module not importable"}
    try:
        # handle_upcoming_eclipses returns upcoming eclipses from a reference date
        result = _eclipse_upcoming(birth, count=4)
        if not isinstance(result, dict):
            return {"available": True, "near_event": [],
                    "note": "eclipse module returned unexpected shape"}
        upcoming = result.get("upcoming_eclipses") or result.get("eclipses") or []
        if not isinstance(upcoming, list):
            return {"available": True, "near_event": [],
                    "note": "no upcoming list in eclipse response"}
        # Parse event date
        try:
            ev = datetime.strptime(event_date, "%Y-%m-%d").date()
        except Exception:
            return {"available": True, "near_event": [],
                    "note": "event_date parse failed"}
        near: List[Dict[str, Any]] = []
        for ecl in upcoming:
            if not isinstance(ecl, dict):
                continue
            ecl_date_str = ecl.get("date") or ecl.get("iso_date") or ecl.get("when")
            if not ecl_date_str:
                continue
            try:
                ecl_date = datetime.strptime(str(ecl_date_str)[:10], "%Y-%m-%d").date()
            except Exception:
                continue
            delta_days = abs((ecl_date - ev).days)
            if delta_days <= window_days:
                near.append({
                    "eclipse_date":  str(ecl_date),
                    "delta_days":    delta_days,
                    "details":       ecl,
                })
        return {
            "available":     True,
            "window_days":   window_days,
            "near_event":    near,
            "count":         len(near),
        }
    except Exception as e:
        return {"available": True, "near_event": [], "error": str(e)}


def _graha_yuddha_summary(chart: Dict[str, Any]) -> Any:
    """Read graha_yuddha (planetary war) from chart. Mundane: instability indicator."""
    gy = chart.get("graha_yuddha")
    if gy is None:
        return {"present": False}
    if isinstance(gy, list):
        return {"present": len(gy) > 0, "count": len(gy), "details": gy}
    if isinstance(gy, dict):
        # Could be {planet: ..., loser: ...} or wrapper
        return {"present": bool(gy), "details": gy}
    return {"present": False, "raw": str(gy)[:200]}


def _arudha_lagna(chart: Dict[str, Any]) -> Any:
    """Read AL from chart["arudha_padas"]. Mundane (company): public-facing image."""
    ap = chart.get("arudha_padas", {})
    if not isinstance(ap, dict):
        return None
    # Try common keys
    for key in ("AL", "Arudha Lagna", "arudha_lagna", "A1"):
        if key in ap:
            return {"key_used": key, "value": ap[key]}
    return {"note": "AL key not found; full arudha_padas exposed below",
            "available_keys": list(ap.keys())[:10]}


# ════════════════════════════════════════════════════════════════════════
# PUBLIC API
# ════════════════════════════════════════════════════════════════════════

def handle_country_outlook(country_code: Optional[str] = None,
                           chart_override: Optional[Dict[str, Any]] = None,
                           analysis_date: Optional[str] = None) -> Dict[str, Any]:
    """
    F4 Endpoint: Mundane outlook for a country.

    Either country_code (registry lookup, ISO 3166-1 alpha-2) OR chart_override
    (user-supplied dob/time/lat/lon/timezone). If both, override wins.

    analysis_date is informational only — current dasha is always reported.
    """
    # Resolve chart input
    chart_birth: Optional[Dict[str, Any]] = None
    chart_label = "unknown"
    chart_source = "unknown"
    if chart_override and all(k in chart_override for k in ("dob", "time", "lat", "lon")):
        chart_birth = {
            "dob": chart_override["dob"],
            "time": chart_override["time"],
            "lat": chart_override["lat"],
            "lon": chart_override["lon"],
            "timezone": chart_override.get("timezone", "Asia/Kolkata"),
        }
        chart_label = chart_override.get("name", "user-supplied entity")
        chart_source = "user override"
    elif country_code:
        code_upper = country_code.upper()
        entry = COUNTRY_REGISTRY.get(code_upper)
        if not entry:
            return {
                "error": f"country_code '{country_code}' not in registry",
                "available_codes": sorted(COUNTRY_REGISTRY.keys()),
                "hint": "Pass chart_override with dob/time/lat/lon/timezone instead.",
                "classical_sources": F4_CITATIONS["country_outlook"],
                "disclaimer": F4_DISCLAIMER,
            }
        chart_birth = {
            "dob": entry["dob"], "time": entry["time"],
            "lat": entry["lat"], "lon": entry["lon"],
            "timezone": entry["timezone"],
        }
        chart_label = entry["name"]
        chart_source = entry["source"]
    else:
        return {
            "error": "Either country_code or chart_override required.",
            "available_codes": sorted(COUNTRY_REGISTRY.keys()),
            "classical_sources": F4_CITATIONS["country_outlook"],
            "disclaimer": F4_DISCLAIMER,
        }

    chart = _cast_or_error(chart_birth, "country chart")
    if "_error" in chart:
        return {"error": chart["_error"],
                "classical_sources": F4_CITATIONS["country_outlook"],
                "disclaimer": F4_DISCLAIMER}

    # Mundane-significant houses: 4 (masses), 7 (foreign), 10 (govt), 11 (parliament)
    mundane_houses = [1, 4, 7, 10, 11]
    house_assessments = [_house_lord_assessment(h, chart) for h in mundane_houses]

    # Amatyakaraka = governance significator in mundane (the "minister")
    karakas = chart.get("jaimini_karakas", {}) or {}
    amk = karakas.get("Amatyakaraka", {}) if isinstance(karakas, dict) else {}

    relevant_yogas = _filter_mundane_yogas(chart)
    dasha_snapshot = _current_dasha_snapshot(chart)
    moon_state = _moon_condition(chart)

    return {
        "entity":               chart_label,
        "chart_source":         chart_source,
        "chart_input":          chart_birth,
        "analysis_date":        analysis_date or date.today().isoformat(),
        "lagna":                chart.get("lagna", {}),
        "moon_condition":       moon_state,
        "house_assessments":    house_assessments,
        "governance_significator_amatyakaraka": amk,
        "mundane_yogas_present": relevant_yogas,
        "mundane_yogas_count":   len(relevant_yogas),
        "current_dasha":         dasha_snapshot,
        "classical_sources":     F4_CITATIONS["country_outlook"],
        "disclaimer":            F4_DISCLAIMER,
    }


def handle_company_chart(incorporation: Dict[str, Any],
                         business_sector: Optional[str] = None) -> Dict[str, Any]:
    """
    F4 Endpoint: Mundane analysis of a company's incorporation chart.

    incorporation: {dob, time, lat, lon, timezone}
    business_sector: optional key from SECTOR_SIGNIFICATORS
    """
    chart = _cast_or_error(incorporation, "company incorporation")
    if "_error" in chart:
        return {"error": chart["_error"],
                "classical_sources": F4_CITATIONS["company_chart"],
                "disclaimer": F4_DISCLAIMER}

    # Mundane houses for companies: 2 (capital), 6 (debt/competition),
    # 10 (business identity), 11 (gains/profits)
    company_houses = [1, 2, 6, 10, 11]
    house_assessments = [_house_lord_assessment(h, chart) for h in company_houses]

    # Sector-specific significator analysis
    sector_analysis: Optional[Dict[str, Any]] = None
    if business_sector:
        sector_key = business_sector.lower().replace(" ", "_").replace("-", "_")
        signifs = SECTOR_SIGNIFICATORS.get(sector_key)
        if signifs:
            sector_analysis = {
                "sector":         business_sector,
                "significators":  signifs,
                "states":         [_planet_state(p, chart) for p in signifs],
                "rationale":      f"Per classical sector mapping, {business_sector} "
                                  f"is governed by {', '.join(signifs)}.",
            }
        else:
            sector_analysis = {
                "sector":            business_sector,
                "note":              "Sector not in classical mapping table.",
                "available_sectors": sorted(SECTOR_SIGNIFICATORS.keys()),
            }

    relevant_yogas = _filter_mundane_yogas(chart)
    arudha = _arudha_lagna(chart)
    dasha_snapshot = _current_dasha_snapshot(chart)

    return {
        "entity":                 "Company (user-supplied incorporation chart)",
        "incorporation":          incorporation,
        "lagna":                  chart.get("lagna", {}),
        "house_assessments":      house_assessments,
        "arudha_lagna_public_image": arudha,
        "sector_analysis":        sector_analysis,
        "wealth_yogas_present":   relevant_yogas,
        "wealth_yogas_count":     len(relevant_yogas),
        "current_dasha":          dasha_snapshot,
        "classical_sources":      F4_CITATIONS["company_chart"],
        "disclaimer":             F4_DISCLAIMER,
    }


def handle_election_prediction(event: Dict[str, Any],
                               country_code: Optional[str] = None) -> Dict[str, Any]:
    """
    F4 Endpoint: Event-chart analysis for a civic event (e.g. poll opening).

    event: {dob, time, lat, lon, timezone} — the event moment
    country_code: optional national-context overlay

    DOES NOT predict winners. DOES NOT name parties or candidates.
    Returns mundane indicators only.
    """
    chart = _cast_or_error(event, "event chart")
    if "_error" in chart:
        return {"error": chart["_error"],
                "classical_sources": F4_CITATIONS["election_prediction"],
                "disclaimer": F4_DISCLAIMER,
                "election_disclaimer": F4_ELECTION_DISCLAIMER_EXTRA}

    # Mundane indicators ONLY — no winner prediction logic anywhere here.

    # 1. Lagna lord state — overall stability of the moment
    lagna_lord = _house_lord(1, chart)
    lagna_lord_state = _planet_state(lagna_lord, chart) if lagna_lord else None

    # 2. 10th lord — governance house, key indicator
    tenth_lord = _house_lord(10, chart)
    tenth_lord_state = _planet_state(tenth_lord, chart) if tenth_lord else None

    # 3. 6th lord — opposition / challenges
    sixth_lord = _house_lord(6, chart)
    sixth_lord_state = _planet_state(sixth_lord, chart) if sixth_lord else None

    # 4. Moon condition — central to event-chart work
    moon_state = _moon_condition(chart)

    # 5. Graha yuddha — classical instability indicator
    yuddha = _graha_yuddha_summary(chart)

    # 6. Gandanta presence
    gandanta = chart.get("gandanta")
    gandanta_summary = (
        {"present": bool(gandanta), "details": gandanta}
        if gandanta is not None else {"present": False}
    )

    # 7. Eclipse proximity (±30 days)
    eclipse_check = _eclipse_proximity(event, event["dob"], window_days=30)

    # 8. National-context overlay (read-only — does not change indicators)
    country_context: Optional[Dict[str, Any]] = None
    if country_code:
        code_upper = country_code.upper()
        entry = COUNTRY_REGISTRY.get(code_upper)
        if entry:
            country_context = {
                "country":  entry["name"],
                "note":     "National chart is referenced for context only; "
                            "event indicators are derived solely from the event chart.",
            }
        else:
            country_context = {
                "country":         country_code,
                "available_codes": sorted(COUNTRY_REGISTRY.keys()),
                "note":            "Country code not in registry; ignored.",
            }

    # Synthesize a verdict band — TRANSPARENT, no winner language
    favorable_factors: List[str] = []
    unfavorable_factors: List[str] = []
    if lagna_lord_state:
        d = (lagna_lord_state.get("dignity") or "").lower()
        if d in {"exalted", "mooltrikona", "own_sign"}:
            favorable_factors.append(f"Lagna lord {lagna_lord} dignified ({d})")
        elif d in {"debilitated", "great_enemy"}:
            unfavorable_factors.append(f"Lagna lord {lagna_lord} afflicted ({d})")
    if tenth_lord_state:
        d = (tenth_lord_state.get("dignity") or "").lower()
        if d in {"exalted", "mooltrikona", "own_sign"}:
            favorable_factors.append(f"10th lord {tenth_lord} dignified ({d})")
        elif d in {"debilitated", "great_enemy"}:
            unfavorable_factors.append(f"10th lord {tenth_lord} afflicted ({d})")
    if moon_state.get("is_combust"):
        unfavorable_factors.append("Moon combust")
    if yuddha.get("present"):
        unfavorable_factors.append("Graha yuddha (planetary war) active")
    if gandanta_summary.get("present"):
        unfavorable_factors.append("Gandanta condition present")
    if eclipse_check.get("count", 0) > 0:
        unfavorable_factors.append(
            f"{eclipse_check['count']} eclipse(s) within ±30 days of event")

    return {
        "event":                       event,
        "event_chart_lagna":           chart.get("lagna", {}),
        "lagna_lord_state":            lagna_lord_state,
        "tenth_lord_state_governance": tenth_lord_state,
        "sixth_lord_state_opposition": sixth_lord_state,
        "moon_condition":              moon_state,
        "graha_yuddha":                yuddha,
        "gandanta":                    gandanta_summary,
        "eclipse_proximity":           eclipse_check,
        "country_context":             country_context,
        "favorable_factors":           favorable_factors,
        "unfavorable_factors":         unfavorable_factors,
        "indicator_count":             {
            "favorable":   len(favorable_factors),
            "unfavorable": len(unfavorable_factors),
        },
        "classical_sources":           F4_CITATIONS["election_prediction"],
        "disclaimer":                  F4_DISCLAIMER,
        "election_disclaimer":         F4_ELECTION_DISCLAIMER_EXTRA,
    }


# ════════════════════════════════════════════════════════════════════════
# F4 module marker — used by patch installer for idempotency check
# ════════════════════════════════════════════════════════════════════════
F4_MODULE_VERSION = "1.0.0"
F4_MODULE_MARKER  = "F4_MUNDANE_2026_05_18"
