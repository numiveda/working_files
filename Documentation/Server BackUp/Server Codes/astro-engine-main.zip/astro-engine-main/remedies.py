"""
remedies.py — Master Remedies Engine (refactored)

REFACTOR CHANGES:
- Imports extract_chart_essentials, get_chart, afflicted_planets, weakest_planet,
  is_planet_safe_for_gemstone, compute_house_lords from astro_helpers
- All output structures IDENTICAL to v1 — zero behavior change

Sub-systems:
- Vedic: gemstones, rudrakshas, mantras, yantras, ishta_devata, donations, fasting
- Therapeutic: colors, sound_therapy, aromatherapy
- Numerology: name, mobile, vehicle, signature, lucky_dates
- Master: for_chart, by_purpose, full_catalog

Personalization rules (defensibility):
- Gemstones: NEVER prescribed for 6/8/12 lords
- Ishta Devata: chosen by Atmakaraka + 12th lord
- Mantras: weighted by weakest planet
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Any

from astro_helpers import (
    extract_chart_essentials as _extract_chart_essentials,
    get_chart as _get_chart,
    afflicted_planets as _afflicted_planets,
    weakest_planet as _weakest_planet,
    is_planet_safe_for_gemstone as _is_planet_safe_for_gemstone,
    SIGNS_ORDER,
)


# ════════════════════════════════════════════════════════════════════════
# JSON LOADERS — Cached at module load
# ════════════════════════════════════════════════════════════════════════

REMEDIES_DATA_DIR = "/opt/astro/remedies_data"

def _load_json(filename: str) -> Dict:
    path = os.path.join(REMEDIES_DATA_DIR, filename)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

try:
    VEDIC        = _load_json("remedies_vedic.json")
    THERAPEUTIC  = _load_json("remedies_therapeutic.json")
    NUMEROLOGY   = _load_json("remedies_numerology.json")
    MASTER_INDEX = _load_json("remedies_master.json")
except Exception as e:
    raise RuntimeError(f"Failed to load remedies catalogs from {REMEDIES_DATA_DIR}: {e}")


# ════════════════════════════════════════════════════════════════════════
# VEDIC SUB-SYSTEM
# ════════════════════════════════════════════════════════════════════════

def gemstones_for_chart(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    chart = _extract_chart_essentials(_get_chart(dob, time, lat, lon, timezone))

    recommended, cautioned, avoided = [], [], []

    for planet, gem_data in VEDIC["gemstones"]["by_planet"].items():
        safety = _is_planet_safe_for_gemstone(planet, chart)
        pdata = chart["planets"].get(planet, {})
        entry = {
            "planet":           planet,
            "gemstone":         gem_data["primary"],
            "sanskrit":         gem_data.get("sanskrit"),
            "house_in_chart":   pdata.get("house"),
            "dignity_in_chart": pdata.get("dignity"),
            "safety_check":     safety,
            "full_details":     gem_data,
        }
        if safety["safe"] is True:
            recommended.append(entry)
        elif safety["safe"] == "with_caution":
            cautioned.append(entry)
        else:
            avoided.append(entry)

    primary = None
    for house in (1, 9, 5, 10, 4, 2):
        lord = chart["house_lords"].get(house)
        if lord:
            for r in recommended:
                if r["planet"] == lord:
                    primary = {"planet": lord, "house_lord_of": house, **r}
                    break
        if primary:
            break

    return {
        "lagna":                chart["lagna_sign"],
        "lagna_lord":           chart["lagna_lord"],
        "primary_recommendation":primary,
        "all_recommended":      recommended,
        "use_with_caution":     cautioned,
        "strictly_avoid":       avoided,
        "critical_safety_rules":VEDIC["gemstones"]["_critical_safety_rules"],
        "classical_source":     "Garuda Purana + Brihat Samhita + Lal Kitab",
    }


def rudrakshas_for_chart(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    chart = _extract_chart_essentials(_get_chart(dob, time, lat, lon, timezone))
    afflicted = _afflicted_planets(chart)

    planet_to_mukhi = {
        "Sun": "12_mukhi", "Moon": "2_mukhi", "Mars": "3_mukhi",
        "Mercury": "4_mukhi", "Jupiter": "5_mukhi", "Venus": "13_mukhi",
        "Saturn": "7_mukhi", "Rahu": "8_mukhi", "Ketu": "9_mukhi",
    }

    recommendations = []
    for ap in afflicted:
        mukhi_key = planet_to_mukhi.get(ap["planet"])
        if mukhi_key and mukhi_key in VEDIC["rudrakshas"]["by_mukhi"]:
            recommendations.append({
                "for_planet":  ap["planet"],
                "afflictions": ap["afflictions"],
                "mukhi":       mukhi_key,
                "details":     VEDIC["rudrakshas"]["by_mukhi"][mukhi_key],
            })

    universal = VEDIC["rudrakshas"]["by_mukhi"]["5_mukhi"]

    return {
        "universal_recommendation": {"mukhi": "5_mukhi", "details": universal,
                                      "note": "5 Mukhi is universally beneficial — basic spiritual remedy for all natives"},
        "personalized_for_afflictions": recommendations,
        "wearing_procedure":  VEDIC["rudrakshas"]["wearing_procedure"],
        "general_rules":      VEDIC["rudrakshas"]["general_rules"],
        "full_catalog":       VEDIC["rudrakshas"]["by_mukhi"],
        "classical_source":   "Padma Purana, Shiva Purana, Garuda Purana 167",
    }


def mantras_for_chart(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    chart = _extract_chart_essentials(_get_chart(dob, time, lat, lon, timezone))
    weakest = _weakest_planet(chart)
    afflicted = _afflicted_planets(chart)

    primary = None
    if weakest and weakest in VEDIC["mantras"]["by_planet"]:
        primary = {
            "planet":    weakest,
            "rationale": f"{weakest} is the weakest planet in chart",
            **VEDIC["mantras"]["by_planet"][weakest],
        }

    all_afflicted_mantras = []
    for a in afflicted:
        planet = a["planet"]
        if planet in VEDIC["mantras"]["by_planet"]:
            all_afflicted_mantras.append({
                "planet":      planet,
                "afflictions": a["afflictions"],
                **VEDIC["mantras"]["by_planet"][planet],
            })

    return {
        "primary_mantra":      primary,
        "all_afflicted_planet_mantras": all_afflicted_mantras,
        "general_rules":       VEDIC["mantras"]["general_rules"],
        "full_catalog":        VEDIC["mantras"]["by_planet"],
        "classical_source":    "BPHS Ch. 84, Mantra Pushpam, Stotra Samhitas",
    }


def yantras_for_chart(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    chart = _extract_chart_essentials(_get_chart(dob, time, lat, lon, timezone))
    afflicted = _afflicted_planets(chart)

    afflicted_yantras = []
    for a in afflicted:
        planet = a["planet"]
        if planet in VEDIC["yantras"]["by_planet"]:
            afflicted_yantras.append({
                "planet": planet,
                "afflictions": a["afflictions"],
                **VEDIC["yantras"]["by_planet"][planet],
            })

    return {
        "afflicted_planet_yantras": afflicted_yantras,
        "universal_home_yantras":   VEDIC["yantras"]["general_yantras"],
        "classical_source":         "Mantra Maharnava + traditional Sri Vidya texts",
    }


def ishta_devata_for_chart(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    chart = _extract_chart_essentials(_get_chart(dob, time, lat, lon, timezone))

    ak = chart["atmakaraka"]
    twelfth = chart["twelfth_lord"]
    lagna_sign = chart["lagna_sign"]

    twelfth_sign = None
    if lagna_sign in SIGNS_ORDER:
        twelfth_sign = SIGNS_ORDER[(SIGNS_ORDER.index(lagna_sign) + 11) % 12]
    twelfth_sign_lord_label = f"{twelfth_sign} ({twelfth})" if twelfth_sign and twelfth else None

    ak_devata = VEDIC["ishta_devata"]["by_planet_as_AK"].get(ak, {}) if ak else {}
    twelfth_devata = VEDIC["ishta_devata"]["by_12th_lord"].get(twelfth_sign_lord_label, "")

    return {
        "atmakaraka":                  ak,
        "atmakaraka_based_devata":     ak_devata,
        "twelfth_house_sign":          twelfth_sign,
        "twelfth_lord":                twelfth,
        "twelfth_lord_based_devata":   twelfth_devata,
        "determination_rule":          VEDIC["ishta_devata"]["determination_rule"],
        "classical_source":            "Jaimini Sutra Ch. 4, BPHS Ch. 47",
    }


def donations_for_chart(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    chart = _extract_chart_essentials(_get_chart(dob, time, lat, lon, timezone))
    afflicted = _afflicted_planets(chart)

    recs = []
    for a in afflicted:
        planet = a["planet"]
        if planet in VEDIC["donations"]["by_planet"]:
            recs.append({
                "planet":      planet,
                "afflictions": a["afflictions"],
                **VEDIC["donations"]["by_planet"][planet],
            })

    return {
        "personalized_donations": recs,
        "general_rules":          VEDIC["donations"]["general_rules"],
        "full_catalog":           VEDIC["donations"]["by_planet"],
        "classical_source":       "Brihat Samhita Ch. 80-83, Lal Kitab tradition",
    }


def fasting_for_chart(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    chart = _extract_chart_essentials(_get_chart(dob, time, lat, lon, timezone))
    weakest = _weakest_planet(chart)

    primary = None
    if weakest and weakest in VEDIC["fasting"]["by_planet"]:
        primary = {
            "planet":   weakest,
            "rationale":f"{weakest} is weakest planet — primary fasting target",
            **VEDIC["fasting"]["by_planet"][weakest],
        }
    elif weakest in ("Rahu", "Ketu"):
        primary = {
            "planet":   weakest,
            **VEDIC["fasting"]["by_planet"]["Rahu_Ketu"],
        }

    return {
        "primary_recommendation": primary,
        "general_rules":          VEDIC["fasting"]["general_rules"],
        "full_catalog":           VEDIC["fasting"]["by_planet"],
        "classical_source":       "Garuda Purana, Vrat Khand",
    }


# ════════════════════════════════════════════════════════════════════════
# THERAPEUTIC SUB-SYSTEM
# ════════════════════════════════════════════════════════════════════════

def color_therapy_for_chart(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    chart = _extract_chart_essentials(_get_chart(dob, time, lat, lon, timezone))
    lagna_lord = chart["lagna_lord"]
    weakest = _weakest_planet(chart)

    recs = {}
    if lagna_lord and lagna_lord in THERAPEUTIC["color_therapy"]["by_planet"]:
        recs["lagna_lord_color"] = {
            "planet": lagna_lord,
            **THERAPEUTIC["color_therapy"]["by_planet"][lagna_lord],
        }
    if weakest and weakest in THERAPEUTIC["color_therapy"]["by_planet"]:
        recs["strengthen_weakest"] = {
            "planet": weakest,
            **THERAPEUTIC["color_therapy"]["by_planet"][weakest],
        }

    avoid_lords = []
    for h in (6, 8, 12):
        l = chart["house_lords"].get(h)
        if l and l in THERAPEUTIC["color_therapy"]["by_planet"]:
            avoid_lords.append({
                "planet": l,
                "house_lord_of": h,
                **THERAPEUTIC["color_therapy"]["by_planet"][l],
            })

    return {
        "lagna":              chart["lagna_sign"],
        "personalized":       recs,
        "avoid_colors_of":    avoid_lords,
        "full_catalog":       THERAPEUTIC["color_therapy"]["by_planet"],
        "room_painting_by_zone": THERAPEUTIC["color_therapy"]["room_painting_by_zone"],
        "classical_source":   "Atharva Veda + modern color therapy synthesis",
    }


def sound_therapy_for_chart(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    chart = _extract_chart_essentials(_get_chart(dob, time, lat, lon, timezone))
    weakest = _weakest_planet(chart)

    primary = None
    if weakest and weakest in THERAPEUTIC["sound_therapy"]["by_planet"]:
        primary = {
            "planet": weakest,
            **THERAPEUTIC["sound_therapy"]["by_planet"][weakest],
        }

    return {
        "primary_recommendation": primary,
        "full_catalog":           THERAPEUTIC["sound_therapy"]["by_planet"],
        "solfeggio_frequencies":  THERAPEUTIC["sound_therapy"]["solfeggio_frequencies"],
        "general_guidance":       THERAPEUTIC["sound_therapy"]["general_guidance"],
        "classical_source":       "Sama Veda + modern solfeggio synthesis",
    }


def aromatherapy_for_chart(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    chart = _extract_chart_essentials(_get_chart(dob, time, lat, lon, timezone))
    weakest = _weakest_planet(chart)
    lagna_lord = chart["lagna_lord"]

    recs = {}
    if lagna_lord and lagna_lord in THERAPEUTIC["aromatherapy"]["by_planet"]:
        recs["lagna_lord"] = {
            "planet": lagna_lord,
            **THERAPEUTIC["aromatherapy"]["by_planet"][lagna_lord],
        }
    if weakest and weakest in THERAPEUTIC["aromatherapy"]["by_planet"]:
        recs["strengthen_weakest"] = {
            "planet": weakest,
            **THERAPEUTIC["aromatherapy"]["by_planet"][weakest],
        }

    return {
        "personalized":     recs,
        "full_catalog":     THERAPEUTIC["aromatherapy"]["by_planet"],
        "general_rules":    THERAPEUTIC["aromatherapy"]["general_rules"],
        "classical_source": "Sushruta Samhita Ch. 24 + Atharva Veda",
    }


# ════════════════════════════════════════════════════════════════════════
# NUMEROLOGY SUB-SYSTEM
# ════════════════════════════════════════════════════════════════════════

def _reduce_to_single(n: int) -> int:
    while n >= 10:
        n = sum(int(d) for d in str(n))
    return n if n else 9


def _name_value_chaldean(name: str) -> int:
    values = NUMEROLOGY["name_correction"]["chaldean_letter_values"]
    total = 0
    for ch in name.upper():
        if ch.isalpha():
            total += values.get(ch, 0)
    return total


def name_numerology(name: str, dob: str) -> Dict:
    parts = dob.split("-")
    if len(parts) != 3:
        return {"error": "DOB must be YYYY-MM-DD"}
    year, month, day = int(parts[0]), int(parts[1]), int(parts[2])
    driver = _reduce_to_single(day)
    conductor = _reduce_to_single(day + month + year)
    name_value = _name_value_chaldean(name)
    name_number = _reduce_to_single(name_value)

    compat_key = f"Driver {driver}"
    compat = NUMEROLOGY["name_correction"]["compatible_name_numbers"].get(compat_key, [])
    incompat = NUMEROLOGY["name_correction"]["incompatible_name_numbers_by_driver"].get(compat_key, [])

    is_compatible = name_number in compat
    is_incompatible = name_number in incompat

    return {
        "name":             name,
        "name_value_raw":   name_value,
        "name_number":      name_number,
        "name_number_planet": NUMEROLOGY["number_planet_correspondence"][str(name_number)],
        "driver":           driver,
        "driver_planet":    NUMEROLOGY["number_planet_correspondence"][str(driver)],
        "conductor":        conductor,
        "conductor_planet": NUMEROLOGY["number_planet_correspondence"][str(conductor)],
        "is_compatible":    is_compatible,
        "is_incompatible":  is_incompatible,
        "compatible_numbers": compat,
        "incompatible_numbers": incompat,
        "correction_strategy":  NUMEROLOGY["name_correction"]["correction_strategy"],
        "classical_source": "Chaldean numerology (Cheiro)",
    }


def mobile_analysis(mobile: str, dob: str) -> Dict:
    cleaned = mobile.replace("+", "").replace("-", "").replace(" ", "")
    if cleaned.startswith("91") and len(cleaned) > 10:
        cleaned = cleaned[2:]
    digit_sum = sum(int(d) for d in cleaned if d.isdigit())
    reduced = _reduce_to_single(digit_sum)
    last_digit = int(cleaned[-1]) if cleaned and cleaned[-1].isdigit() else None

    parts = dob.split("-")
    year, month, day = int(parts[0]), int(parts[1]), int(parts[2])
    driver = _reduce_to_single(day)

    compat = NUMEROLOGY["name_correction"]["compatible_name_numbers"].get(f"Driver {driver}", [])

    return {
        "mobile":           mobile,
        "digit_sum":        digit_sum,
        "reduced":          reduced,
        "reduced_planet":   NUMEROLOGY["number_planet_correspondence"][str(reduced)],
        "last_digit":       last_digit,
        "driver":           driver,
        "is_compatible":    reduced in compat,
        "good_endings_for_purpose": NUMEROLOGY["mobile_number_analysis"]["good_mobile_endings"],
        "general_rules":    NUMEROLOGY["mobile_number_analysis"]["general_rules"],
        "classical_source": "Chaldean numerology",
    }


def vehicle_analysis(registration: str, dob: str) -> Dict:
    digits = [int(c) for c in registration if c.isdigit()]
    digit_sum = sum(digits)
    reduced = _reduce_to_single(digit_sum) if digit_sum else 0

    parts = dob.split("-")
    year, month, day = int(parts[0]), int(parts[1]), int(parts[2])
    driver = _reduce_to_single(day)

    compat = NUMEROLOGY["name_correction"]["compatible_name_numbers"].get(f"Driver {driver}", [])

    return {
        "registration":     registration,
        "digit_sum":        digit_sum,
        "reduced":          reduced,
        "reduced_planet":   NUMEROLOGY["number_planet_correspondence"].get(str(reduced)),
        "driver":           driver,
        "is_compatible":    reduced in compat,
        "good_endings":     NUMEROLOGY["vehicle_number_analysis"]["good_endings"],
        "general_rules":    NUMEROLOGY["vehicle_number_analysis"]["general_rules"],
        "classical_source": "Chaldean numerology",
    }


def signature_guidance(dob: str) -> Dict:
    parts = dob.split("-")
    year, month, day = int(parts[0]), int(parts[1]), int(parts[2])
    driver = _reduce_to_single(day)
    driver_planet = NUMEROLOGY["number_planet_correspondence"][str(driver)]["planet"]
    pen_rec = NUMEROLOGY["signature_analysis"]["best_pen_for_signing_planet"].get(driver_planet)

    return {
        "driver":             driver,
        "driver_planet":      driver_planet,
        "pen_recommendation": pen_rec,
        "principles":         NUMEROLOGY["signature_analysis"]["principles"],
        "common_corrections": NUMEROLOGY["signature_analysis"]["common_corrections"],
        "classical_source":   "Modern numerology + graphology synthesis",
    }


def lucky_dates(dob: str) -> Dict:
    parts = dob.split("-")
    year, month, day = int(parts[0]), int(parts[1]), int(parts[2])
    driver = _reduce_to_single(day)
    data = NUMEROLOGY["lucky_dates"]["by_driver"].get(str(driver), {})

    return {
        "driver":              driver,
        "driver_planet":       NUMEROLOGY["number_planet_correspondence"][str(driver)],
        "lucky_dates_of_month":data.get("lucky_dates"),
        "best_for":            data.get("best_for"),
        "avoid_dates_general": NUMEROLOGY["lucky_dates"]["avoid_dates_general"],
        "universally_lucky_indian_dates": NUMEROLOGY["lucky_dates"]["universally_lucky_indian_dates"],
        "classical_source":    "Chaldean numerology + Indian Panchang tradition",
    }


# ════════════════════════════════════════════════════════════════════════
# MASTER ENDPOINTS
# ════════════════════════════════════════════════════════════════════════

def remedies_for_chart(dob: str, time: str, lat: float, lon: float,
                       timezone: str = "Asia/Kolkata", name: Optional[str] = None) -> Dict:
    out = {
        "input": {"dob": dob, "time": time, "lat": lat, "lon": lon, "name": name},
        "vedic": {
            "gemstones":     gemstones_for_chart(dob, time, lat, lon, timezone),
            "rudrakshas":    rudrakshas_for_chart(dob, time, lat, lon, timezone),
            "mantras":       mantras_for_chart(dob, time, lat, lon, timezone),
            "yantras":       yantras_for_chart(dob, time, lat, lon, timezone),
            "ishta_devata":  ishta_devata_for_chart(dob, time, lat, lon, timezone),
            "donations":     donations_for_chart(dob, time, lat, lon, timezone),
            "fasting":       fasting_for_chart(dob, time, lat, lon, timezone),
        },
        "therapeutic": {
            "color":         color_therapy_for_chart(dob, time, lat, lon, timezone),
            "sound":         sound_therapy_for_chart(dob, time, lat, lon, timezone),
            "aromatherapy":  aromatherapy_for_chart(dob, time, lat, lon, timezone),
        },
        "numerology": {
            "signature":      signature_guidance(dob),
            "lucky_dates":    lucky_dates(dob),
            **({"name":       name_numerology(name, dob)} if name else {}),
        },
        "classical_sources": [
            "Brihat Samhita, BPHS, Phaladeepika, Saravali, Lal Kitab",
            "Garuda Purana, Shiva Purana",
            "Mantra Pushpam, Stotra Samhitas",
            "Atharva Veda, Sama Veda, Sushruta Samhita",
            "Chaldean numerology (Cheiro) + Indian Anka Shastra",
        ],
    }
    return out


def remedies_by_purpose(purpose: str, dob: str, time: str, lat: float, lon: float,
                        timezone: str = "Asia/Kolkata") -> Dict:
    if purpose not in MASTER_INDEX["purposes_to_remedies"]:
        return {
            "error":              f"Unknown purpose: {purpose}",
            "available_purposes": list(MASTER_INDEX["purposes_to_remedies"].keys()),
        }

    chart = _extract_chart_essentials(_get_chart(dob, time, lat, lon, timezone))
    purpose_data = MASTER_INDEX["purposes_to_remedies"][purpose]

    return {
        "purpose":              purpose,
        "chart_summary":        {"lagna": chart["lagna_sign"], "ak": chart["atmakaraka"], "current_md": chart["current_md"]},
        "recommendations":      purpose_data,
        "house_remedies":       MASTER_INDEX["house_specific_remedies"],
        "classical_source":     "Composite — see individual entries",
    }


def full_catalog() -> Dict:
    return {
        "vedic":        VEDIC,
        "therapeutic":  THERAPEUTIC,
        "numerology":   NUMEROLOGY,
        "master_index": MASTER_INDEX,
    }
