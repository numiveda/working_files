"""
yogas_helpers.py — Common chart-query utilities for yoga detection.

Every yoga detection rule needs to ask the chart:
  - Where is planet X (house, sign, longitude)?
  - Is planet X exalted, debilitated, own-sign, friendly?
  - What planets occupy house N?
  - Is house N aspected by planet X?
  - Is planet X aspecting planet Y?
  - Are planets X and Y in mutual reception (exchange)?
  - Is planet X retrograde / combust?
  - Is planet X in a kendra / trikona / dusthana?
  - What is the lord of house N?

These helpers standardize all of that so detection rules stay readable.

Schema expected from cast_chart():
  chart["ascendant"]["sign"]                     -> "Cancer"
  chart["ascendant"]["longitude"]                -> 113.45
  chart["planets"][name]["sign"]                 -> "Leo"
  chart["planets"][name]["longitude"]            -> 132.5
  chart["planets"][name]["house"]                -> 4   (1-12)
  chart["planets"][name]["retrograde"]           -> bool
  chart["planets"][name]["nakshatra"]            -> "Magha"
  chart["planets"][name]["nakshatra_lord"]       -> "Ketu"
  chart["planets"][name]["pada"]                 -> int

(Falls back gracefully if any field is missing.)
"""

from typing import Dict, Any, List, Optional, Set

# ─────────────────────────────────────────────────────────────────────────────
# DOMAIN TABLES
# ─────────────────────────────────────────────────────────────────────────────

SIGNS = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
         "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"]

SIGN_INDEX = {s: i for i, s in enumerate(SIGNS)}  # 0-indexed

SIGN_LORDS = {
    "Aries": "Mars",        "Taurus": "Venus",   "Gemini": "Mercury",
    "Cancer": "Moon",       "Leo": "Sun",        "Virgo": "Mercury",
    "Libra": "Venus",       "Scorpio": "Mars",   "Sagittarius": "Jupiter",
    "Capricorn": "Saturn",  "Aquarius": "Saturn", "Pisces": "Jupiter",
}

# Modern lordships (used as alternative for Rahu/Ketu placement effects, rarely)
COLOR_BENEFIC = {"Jupiter", "Venus", "Mercury", "Moon"}   # natural benefics
COLOR_MALEFIC = {"Sun", "Mars", "Saturn", "Rahu", "Ketu"} # natural malefics

# Exaltation / Debilitation
EXALTATION = {
    "Sun": "Aries",      "Moon": "Taurus",   "Mars": "Capricorn",
    "Mercury": "Virgo",  "Jupiter": "Cancer","Venus": "Pisces",
    "Saturn": "Libra",   "Rahu": "Taurus",   "Ketu": "Scorpio",
}
EXALTATION_DEG = {
    "Sun": 10,    "Moon": 3,    "Mars": 28,    "Mercury": 15,
    "Jupiter": 5, "Venus": 27,  "Saturn": 20,  "Rahu": 20, "Ketu": 20,
}
DEBILITATION = {
    "Sun": "Libra",      "Moon": "Scorpio",   "Mars": "Cancer",
    "Mercury": "Pisces", "Jupiter": "Capricorn","Venus": "Virgo",
    "Saturn": "Aries",   "Rahu": "Scorpio",   "Ketu": "Taurus",
}

# Mooltrikona signs
MOOLTRIKONA = {
    "Sun": ("Leo", 0, 20),         "Moon": ("Taurus", 3, 30),
    "Mars": ("Aries", 0, 12),      "Mercury": ("Virgo", 16, 20),
    "Jupiter": ("Sagittarius", 0, 10),"Venus": ("Libra", 0, 15),
    "Saturn": ("Aquarius", 0, 20),
}

# Own signs (Swakshetra)
OWN_SIGNS = {
    "Sun": ["Leo"],
    "Moon": ["Cancer"],
    "Mars": ["Aries", "Scorpio"],
    "Mercury": ["Gemini", "Virgo"],
    "Jupiter": ["Sagittarius", "Pisces"],
    "Venus": ["Taurus", "Libra"],
    "Saturn": ["Capricorn", "Aquarius"],
}

# Natural friendships (classical, from BPHS)
NATURAL_FRIENDS: Dict[str, Dict[str, str]] = {
    "Sun":     {"Moon":"F","Mars":"F","Jupiter":"F","Mercury":"N","Venus":"E","Saturn":"E"},
    "Moon":    {"Sun":"F","Mercury":"F","Mars":"N","Jupiter":"N","Venus":"N","Saturn":"N"},
    "Mars":    {"Sun":"F","Moon":"F","Jupiter":"F","Mercury":"E","Venus":"N","Saturn":"N"},
    "Mercury": {"Sun":"F","Venus":"F","Moon":"E","Mars":"N","Jupiter":"N","Saturn":"N"},
    "Jupiter": {"Sun":"F","Moon":"F","Mars":"F","Mercury":"E","Venus":"E","Saturn":"N"},
    "Venus":   {"Mercury":"F","Saturn":"F","Sun":"E","Moon":"E","Mars":"N","Jupiter":"N"},
    "Saturn":  {"Mercury":"F","Venus":"F","Sun":"E","Moon":"E","Mars":"E","Jupiter":"N"},
}

# House classifications
KENDRA_HOUSES   = {1, 4, 7, 10}            # angular
TRIKONA_HOUSES  = {1, 5, 9}                # trinal
DUSTHANA_HOUSES = {6, 8, 12}               # malefic houses
UPACHAYA_HOUSES = {3, 6, 10, 11}           # growing houses
PANAPHARA       = {2, 5, 8, 11}            # succedent
APOKLIMA        = {3, 6, 9, 12}            # cadent
MARAKA_HOUSES   = {2, 7}                   # death-inflicting

# House significations (Bhava karakas — natural significators)
HOUSE_KARAKAS = {
    1:  ["Sun"],
    2:  ["Jupiter"],
    3:  ["Mars"],
    4:  ["Moon", "Mercury"],
    5:  ["Jupiter"],
    6:  ["Mars", "Saturn"],
    7:  ["Venus"],
    8:  ["Saturn"],
    9:  ["Sun", "Jupiter"],
    10: ["Sun", "Mercury", "Jupiter", "Saturn"],
    11: ["Jupiter"],
    12: ["Saturn", "Ketu"],
}

# Vedic aspects (Drishti) — each planet aspects the 7th from itself
# (full aspect). Special aspects added:
SPECIAL_ASPECTS = {
    "Mars":    [4, 7, 8],     # 4th, 7th, 8th from itself
    "Jupiter": [5, 7, 9],
    "Saturn":  [3, 7, 10],
    "Rahu":    [5, 7, 9],     # treated like Jupiter in many schools
    "Ketu":    [5, 7, 9],
}
DEFAULT_ASPECT = [7]

ALL_PLANETS = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]
NON_NODES   = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]


# ─────────────────────────────────────────────────────────────────────────────
# CORE CHART QUERIES
# ─────────────────────────────────────────────────────────────────────────────

def asc_sign(chart: dict) -> str:
    """Return ascendant sign name."""
    return chart.get("ascendant", {}).get("sign") or chart.get("lagna", {}).get("sign", "")

def asc_index(chart: dict) -> int:
    """Return ascendant sign 0-indexed (Aries=0)."""
    return SIGN_INDEX.get(asc_sign(chart), 0)

def planet(chart: dict, name: str) -> Dict[str, Any]:
    """Return planet's data dict (or empty)."""
    return chart.get("planets", {}).get(name, {}) or {}

def planet_house(chart: dict, name: str) -> Optional[int]:
    """Return planet's house (1-12) or None if missing."""
    p = planet(chart, name)
    h = p.get("house")
    if h is None:
        # Fallback: compute from sign + ascendant
        s = p.get("sign")
        if s and s in SIGN_INDEX:
            return ((SIGN_INDEX[s] - asc_index(chart)) % 12) + 1
        return None
    return int(h)

def planet_sign(chart: dict, name: str) -> str:
    """Return planet's sign name."""
    return planet(chart, name).get("sign", "")

def planet_lon(chart: dict, name: str) -> float:
    """Return planet's longitude."""
    p = planet(chart, name)
    return float(p.get("longitude", p.get("lon", 0.0)))

def planet_degree_in_sign(chart: dict, name: str) -> float:
    """Degree within current sign (0-30)."""
    return planet_lon(chart, name) % 30.0

def is_retrograde(chart: dict, name: str) -> bool:
    return bool(planet(chart, name).get("retrograde", False))

def is_combust(chart: dict, name: str, orb_deg: float = 8.0) -> bool:
    """Combust if within orb of Sun (excluding Sun itself)."""
    if name == "Sun":
        return False
    sun_lon = planet_lon(chart, "Sun")
    p_lon = planet_lon(chart, name)
    diff = abs(sun_lon - p_lon)
    if diff > 180: diff = 360 - diff
    return diff < orb_deg


# ─────────────────────────────────────────────────────────────────────────────
# DIGNITY HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def is_exalted(chart: dict, name: str) -> bool:
    return planet_sign(chart, name) == EXALTATION.get(name)

def is_debilitated(chart: dict, name: str) -> bool:
    return planet_sign(chart, name) == DEBILITATION.get(name)

def is_own_sign(chart: dict, name: str) -> bool:
    return planet_sign(chart, name) in OWN_SIGNS.get(name, [])

def is_mooltrikona(chart: dict, name: str) -> bool:
    info = MOOLTRIKONA.get(name)
    if not info: return False
    sign, lo, hi = info
    if planet_sign(chart, name) != sign: return False
    return lo <= planet_degree_in_sign(chart, name) < hi

# U12 dignity audit (2026-05-18):
# Previous implementation used only Naisargika (natural) friendship for the friend/enemy
# classification, which disagreed with the native engine's Panchadha (Naisargika + Tatkalika)
# compound friendship in ~4 of 9 planets for canonical charts. Now delegates to the native
# `cast_chart` dignity field and maps the 9-value vocabulary down to the 7-value vocabulary
# the yoga catalogs were written against. Exaltation/debilitation/mooltrikona/own checks
# are preserved as fallbacks for callers that pass partial chart objects without a precomputed
# `dignity` field.

_DIGNITY_MAP = {
    "exalted":      "exalted",
    "mooltrikona":  "mooltrikona",
    "own_sign":     "own",
    "great_friend": "friend",
    "friend":       "friend",
    "neutral":      "neutral",
    "enemy":        "enemy",
    "great_enemy":  "enemy",
    "debilitated":  "debilitated",
}

def dignity(chart: dict, name: str) -> str:
    """Return one of: exalted, mooltrikona, own, friend, neutral, enemy, debilitated.

    Delegates to the engine's precomputed Panchadha (compound) dignity when available,
    falling back to local exaltation/debilitation/mooltrikona/own_sign checks otherwise.
    """
    native = chart.get("planets", {}).get(name, {}).get("dignity")
    if native and native in _DIGNITY_MAP:
        return _DIGNITY_MAP[native]
    if is_debilitated(chart, name):  return "debilitated"
    if is_exalted(chart, name):      return "exalted"
    if is_mooltrikona(chart, name):  return "mooltrikona"
    if is_own_sign(chart, name):     return "own"
    return "neutral"

def dignity_full(chart: dict, name: str) -> str:
    """Return the native 9-value dignity (untranslated).

    For future yoga rules that want to distinguish great_friend from friend, or
    great_enemy from enemy. Returns "neutral" if the native field is absent.
    """
    return chart.get("planets", {}).get(name, {}).get("dignity", "neutral")


# ─────────────────────────────────────────────────────────────────────────────
# HOUSE & LORDSHIP QUERIES
# ─────────────────────────────────────────────────────────────────────────────

def sign_in_house(chart: dict, house: int) -> str:
    """Return the sign occupying house N (whole-sign system)."""
    asc_i = asc_index(chart)
    return SIGNS[(asc_i + house - 1) % 12]

def house_of_sign(chart: dict, sign: str) -> int:
    """Return the house number (1-12) where given sign falls."""
    if sign not in SIGN_INDEX: return 0
    return ((SIGN_INDEX[sign] - asc_index(chart)) % 12) + 1

def lord_of_house(chart: dict, house: int) -> str:
    """Return the planet ruling the sign in house N."""
    sign = sign_in_house(chart, house)
    return SIGN_LORDS.get(sign, "")

def planets_in_house(chart: dict, house: int) -> List[str]:
    """Return list of planets occupying house N."""
    return [p for p in ALL_PLANETS if planet_house(chart, p) == house]

def planets_in_sign(chart: dict, sign: str) -> List[str]:
    """Return list of planets in given sign."""
    return [p for p in ALL_PLANETS if planet_sign(chart, p) == sign]

def is_in_kendra(chart: dict, name: str) -> bool:
    return planet_house(chart, name) in KENDRA_HOUSES

def is_in_trikona(chart: dict, name: str) -> bool:
    return planet_house(chart, name) in TRIKONA_HOUSES

def is_in_dusthana(chart: dict, name: str) -> bool:
    return planet_house(chart, name) in DUSTHANA_HOUSES

def is_in_upachaya(chart: dict, name: str) -> bool:
    return planet_house(chart, name) in UPACHAYA_HOUSES


# ─────────────────────────────────────────────────────────────────────────────
# ASPECT QUERIES (Vedic Drishti)
# ─────────────────────────────────────────────────────────────────────────────

def aspects_from_planet(chart: dict, planet_name: str) -> List[int]:
    """Houses aspected by this planet (by house numbers from natal positions)."""
    h = planet_house(chart, planet_name)
    if h is None: return []
    aspects = SPECIAL_ASPECTS.get(planet_name, DEFAULT_ASPECT)
    return [((h - 1 + a - 1) % 12) + 1 for a in aspects]

def aspects_house(chart: dict, planet_name: str, target_house: int) -> bool:
    """Does this planet aspect target_house?"""
    return target_house in aspects_from_planet(chart, planet_name)

def aspects_planet(chart: dict, aspecting: str, target: str) -> bool:
    """Does 'aspecting' planet aspect 'target' planet?"""
    target_house = planet_house(chart, target)
    if target_house is None: return False
    return aspects_house(chart, aspecting, target_house)

def aspecting_planets_on_house(chart: dict, house: int) -> List[str]:
    """All planets aspecting given house."""
    return [p for p in ALL_PLANETS if aspects_house(chart, p, house)]

def aspecting_planets_on_planet(chart: dict, target: str) -> List[str]:
    """All planets aspecting given planet."""
    return [p for p in ALL_PLANETS if p != target and aspects_planet(chart, p, target)]


# ─────────────────────────────────────────────────────────────────────────────
# CONJUNCTION & EXCHANGE
# ─────────────────────────────────────────────────────────────────────────────

def conjunct(chart: dict, a: str, b: str) -> bool:
    """Two planets conjunct = in same sign."""
    return planet_sign(chart, a) == planet_sign(chart, b) and planet_sign(chart, a) != ""

def mutual_reception(chart: dict, a: str, b: str) -> bool:
    """Parivartana yoga: a in b's sign AND b in a's sign."""
    sa, sb = planet_sign(chart, a), planet_sign(chart, b)
    if not sa or not sb: return False
    return SIGN_LORDS.get(sa) == b and SIGN_LORDS.get(sb) == a


# ─────────────────────────────────────────────────────────────────────────────
# BENEFIC / MALEFIC CLASSIFICATION (functional)
# ─────────────────────────────────────────────────────────────────────────────

def functional_benefics(chart: dict) -> Set[str]:
    """Lords of 1, 4, 5, 7, 9, 10 considered functionally beneficial."""
    out = set()
    for h in (1, 4, 5, 7, 9, 10):
        l = lord_of_house(chart, h)
        if l: out.add(l)
    return out

def functional_malefics(chart: dict) -> Set[str]:
    """Lords of 3, 6, 8, 11 considered functionally malefic (3 and 11 are mild)."""
    out = set()
    for h in (3, 6, 8, 11):
        l = lord_of_house(chart, h)
        if l: out.add(l)
    return out


# ─────────────────────────────────────────────────────────────────────────────
# CONVENIENCE — get a summary of every planet
# ─────────────────────────────────────────────────────────────────────────────

def planet_summary(chart: dict) -> Dict[str, Dict[str, Any]]:
    """Return a compact summary of every planet (for debugging/output)."""
    out = {}
    for p in ALL_PLANETS:
        out[p] = {
            "house":      planet_house(chart, p),
            "sign":       planet_sign(chart, p),
            "longitude":  planet_lon(chart, p),
            "dignity":    dignity(chart, p),
            "retrograde": is_retrograde(chart, p),
            "combust":    is_combust(chart, p),
        }
    return out
