"""
eclipse.py — numiVeda Kaaliyo Astro Engine — Module F2a (Eclipse Analysis)

Three endpoints for eclipse impact:
    handle_natal_eclipses              — Solar+lunar eclipses around birth (configurable window)
    handle_upcoming_eclipses           — Eclipses ahead with personal-impact analysis
    handle_sade_sati_eclipse_extension — Saturn-eclipse intersection during active Sade Sati

Design (per HANDOVER_v4 carry-forward):
    P1 — Swiss Ephemeris ONLY for astronomy. Uses swe.sol_eclipse_when_glob,
         swe.lun_eclipse_when, swe.calc_ut for eclipse Sun/Moon position.
    P2 — Reuse: imports transit_handle_sade_sati for the SS extension; uses
         cast_chart for natal lagna/Moon/Sun degrees.
    P6 — Cross-validation: lunar eclipse natal-house-from-Moon must match
         what /astro/transit/* would compute for the same transit moment.

Public API:
    handle_natal_eclipses(birth, window_days=30) -> dict
    handle_upcoming_eclipses(birth, query_date=None, years_ahead=5) -> dict
    handle_sade_sati_eclipse_extension(birth, query_date=None) -> dict

Module constants:
    NATAL_WINDOW_DEFAULT_DAYS = 30
    NATAL_WINDOW_MAX_DAYS = 180
    UPCOMING_YEARS_DEFAULT = 5
    UPCOMING_YEARS_MAX = 100
    LAGNA_GRAHAN_ORB_DEGREES = 3.0  # within this distance, eclipse "hits" the lagna/Moon/Sun

Author: Claude (F2a, 2026-05-17)
"""

from typing import Dict, List, Optional, Any
from datetime import date, datetime, timedelta

# Foundation imports — guard at module load (Principle 1)
try:
    import swisseph as swe
except ImportError as e:
    raise ImportError(f"F2a eclipse module requires pyswisseph: {e}")

try:
    from dashaflow import cast_chart
except ImportError as e:
    raise ImportError(f"F2a eclipse module requires dashaflow.cast_chart: {e}")

try:
    from transit import handle_sade_sati as _transit_handle_sade_sati
except ImportError as e:
    raise ImportError(f"F2a eclipse module requires transit.handle_sade_sati: {e}")


# ════════════════════════════════════════════════════════════════════════
# MODULE CONSTANTS
# ════════════════════════════════════════════════════════════════════════

NATAL_WINDOW_DEFAULT_DAYS = 30
NATAL_WINDOW_MAX_DAYS = 180
UPCOMING_YEARS_DEFAULT = 5
UPCOMING_YEARS_MAX = 100
LAGNA_GRAHAN_ORB_DEGREES = 3.0   # eclipse degree this close to natal lagna = lagna grahan
MOON_ECLIPSE_ORB_DEGREES = 3.0    # eclipse on/near natal Moon = chandra grahan dosha
SUN_ECLIPSE_ORB_DEGREES = 3.0     # eclipse on/near natal Sun = surya grahan (Pitra signature)

SIGNS = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
         "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"]

# Solar eclipse type bitmask flags (decoded from swe return code)
_SOLAR_FLAGS = ["ECL_TOTAL", "ECL_PARTIAL", "ECL_ANNULAR",
                 "ECL_ANNULAR_TOTAL", "ECL_CENTRAL", "ECL_NONCENTRAL"]
_LUNAR_FLAGS = ["ECL_TOTAL", "ECL_PARTIAL", "ECL_PENUMBRAL"]


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

F2A_CITATIONS = {
    "natal_eclipses": [
        "Brihat Samhita Ch. 5 — Eclipses (Grahana adhyaya): general effects by season and sign",
        "BPHS Ch. 25 — Eclipse effects on natives; eclipse-sign relative to natal Moon as house from Moon",
        "Phaladeepika Ch. 12 — Transit eclipse effects when eclipse degree contacts natal points",
        "Sarvartha Chintamani — Eclipse-degree conjunctions with natal lagna/luminaries (grahan dosha)",
    ],
    "upcoming_eclipses": [
        "BPHS Ch. 25 — Eclipse-from-Moon house position drives life-area impact",
        "Phaladeepika Ch. 12 — Eclipse transit periods of 6 months before/after the event",
        "Hora Sara — Eclipse effects amplified when dasha lord is Sun, Moon, Rahu, or Ketu",
    ],
    "sade_sati_eclipse_extension": [
        "Phaladeepika Ch. 26 — Saturn 7.5-year cycle (Sade Sati)",
        "Brihat Samhita Ch. 5 + Ch. 9 — Saturn-eclipse confluence intensifies the active phase",
        "Sarvartha Chintamani — eclipse during Saturn's transit over Moon's 12th/1st/2nd",
    ],
}


# ════════════════════════════════════════════════════════════════════════
# LOW-LEVEL ECLIPSE COMPUTATION
# ════════════════════════════════════════════════════════════════════════

def _date_to_jd(d: date, hour: float = 0.0) -> float:
    """Date → Julian Day (UT)."""
    return swe.julday(d.year, d.month, d.day, hour)


def _jd_to_iso_datetime(jd: float) -> Dict[str, Any]:
    """Julian Day → human-readable date dict."""
    year, month, day, hour = swe.revjul(jd, swe.GREG_CAL)
    hour_int = int(hour)
    minute = int((hour - hour_int) * 60)
    return {
        "jd": jd,
        "date_utc": f"{year:04d}-{month:02d}-{day:02d}",
        "time_utc": f"{hour_int:02d}:{minute:02d}",
        "year": year, "month": month, "day": day,
    }


def _decode_eclipse_type(type_code: int, eclipse_kind: str) -> List[str]:
    """Decode the type_code bitfield from swe.*_eclipse_when_*."""
    flags = _SOLAR_FLAGS if eclipse_kind == "solar" else _LUNAR_FLAGS
    out = []
    for flag_name in flags:
        if hasattr(swe, flag_name) and (type_code & getattr(swe, flag_name)):
            out.append(flag_name.replace("ECL_", "").title())
    return out


def _eclipse_sidereal_longitude(jd: float, body: int) -> Optional[float]:
    """Sun or Moon sidereal Lahiri longitude at eclipse moment."""
    try:
        swe.set_sid_mode(swe.SIDM_LAHIRI)
        pos, _ = swe.calc_ut(jd, body, swe.FLG_SIDEREAL | swe.FLG_SPEED)
        return pos[0]
    except Exception:
        return None


def _longitude_to_sign_and_degree(longitude: float) -> Dict[str, Any]:
    """Sidereal longitude → {sign, degree_in_sign}."""
    sign_idx = int(longitude / 30) % 12
    deg_in_sign = longitude % 30
    return {
        "longitude":      round(longitude, 4),
        "sign":           SIGNS[sign_idx],
        "degree_in_sign": round(deg_in_sign, 4),
    }


def _angular_distance(deg1: float, deg2: float) -> float:
    """Shortest angular distance between two longitudes (0-180)."""
    diff = abs(deg1 - deg2) % 360
    return min(diff, 360 - diff)


def _house_from_reference(target_longitude: float, ref_longitude: float) -> int:
    """How many signs target is from reference, returning 1-12."""
    target_sign = int(target_longitude / 30) % 12
    ref_sign = int(ref_longitude / 30) % 12
    return ((target_sign - ref_sign) % 12) + 1


def _find_eclipses_in_range(jd_start: float, jd_end: float,
                              eclipse_kind: str = "both") -> List[Dict[str, Any]]:
    """
    Iterate eclipses between jd_start and jd_end (inclusive).
    eclipse_kind: 'solar', 'lunar', or 'both'.
    Returns list of eclipse dicts ordered by JD.
    """
    out: List[Dict[str, Any]] = []
    kinds_to_search = [eclipse_kind] if eclipse_kind in ("solar", "lunar") else ["solar", "lunar"]

    for kind in kinds_to_search:
        jd_cursor = jd_start
        # Safety: cap iterations to prevent runaway
        max_iter = 500
        iters = 0
        while jd_cursor <= jd_end and iters < max_iter:
            iters += 1
            try:
                if kind == "solar":
                    type_code, ecl_data = swe.sol_eclipse_when_glob(
                        jd_cursor, swe.FLG_SWIEPH, 0, False)
                else:
                    type_code, ecl_data = swe.lun_eclipse_when(
                        jd_cursor, swe.FLG_SWIEPH, 0, False)
            except Exception as e:
                # Swisseph occasionally raises near end of ephemeris range
                break

            jd_max = ecl_data[0]
            if jd_max > jd_end:
                break

            type_labels = _decode_eclipse_type(type_code, kind)
            sun_pos = _eclipse_sidereal_longitude(jd_max, swe.SUN)
            moon_pos = _eclipse_sidereal_longitude(jd_max, swe.MOON)

            entry = {
                "kind":            kind,
                "type_code":       int(type_code),
                "type_labels":     type_labels,
                "moment":          _jd_to_iso_datetime(jd_max),
                "sun_sidereal":    _longitude_to_sign_and_degree(sun_pos) if sun_pos is not None else None,
                "moon_sidereal":   _longitude_to_sign_and_degree(moon_pos) if moon_pos is not None else None,
            }
            out.append(entry)
            jd_cursor = jd_max + 1.0  # advance past this eclipse

    # Sort by JD
    out.sort(key=lambda e: e["moment"]["jd"])
    return out


# ════════════════════════════════════════════════════════════════════════
# NATAL ECLIPSES
# ════════════════════════════════════════════════════════════════════════

def _natal_essentials(birth: Dict[str, Any]) -> Dict[str, Any]:
    """Cast natal chart, extract lagna/Moon/Sun longitudes for eclipse comparison."""
    chart = cast_chart(
        dob=birth["dob"], time=birth["time"],
        lat=birth["lat"], lon=birth["lon"],
        timezone=birth.get("timezone", "Asia/Kolkata"),
    )
    lagna = chart.get("lagna", {})
    moon = chart.get("planets", {}).get("Moon", {})
    sun = chart.get("planets", {}).get("Sun", {})

    # Compose absolute sidereal longitudes for lagna/Moon/Sun
    # (lagna stored as sign + degree_in_sign; planets stored similarly)
    def to_absolute(sign: Optional[str], degree: Optional[float]) -> Optional[float]:
        if not sign or sign not in SIGNS or degree is None:
            return None
        return SIGNS.index(sign) * 30 + degree

    return {
        "lagna_sign":      lagna.get("sign"),
        "lagna_degree":    lagna.get("degree"),
        "lagna_longitude": to_absolute(lagna.get("sign"), lagna.get("degree")),
        "moon_sign":       moon.get("sign"),
        "moon_degree":     moon.get("degree"),
        "moon_longitude":  to_absolute(moon.get("sign"), moon.get("degree")),
        "sun_sign":        sun.get("sign"),
        "sun_degree":      sun.get("degree"),
        "sun_longitude":   to_absolute(sun.get("sign"), sun.get("degree")),
        "moon_nakshatra":  moon.get("nakshatra"),
    }


def _classify_eclipse_natal_interaction(eclipse: Dict[str, Any],
                                          natal: Dict[str, Any]) -> Dict[str, Any]:
    """
    For each eclipse, compute relations to natal lagna/Moon/Sun:
      - distance from each
      - which natal house (from Moon, the classical reference)
      - whether it triggers lagna/Moon/Sun grahan signature
    """
    sun_long = (eclipse.get("sun_sidereal") or {}).get("longitude")
    moon_long = (eclipse.get("moon_sidereal") or {}).get("longitude")
    # For natal-degree comparison, use the eclipse-Sun longitude for solar eclipses
    # and eclipse-Moon (which is conjunct Sun within ~180° of lunar eclipse) for lunar.
    # Classical reference point = the eclipse luminary's degree.
    if eclipse["kind"] == "solar":
        eclipse_degree = sun_long
    else:
        eclipse_degree = moon_long
    if eclipse_degree is None:
        return {"error": "Eclipse degree unavailable for natal comparison"}

    natal_lagna = natal.get("lagna_longitude")
    natal_moon = natal.get("moon_longitude")
    natal_sun = natal.get("sun_longitude")

    out: Dict[str, Any] = {}
    triggers: List[str] = []

    if natal_lagna is not None:
        dist = _angular_distance(eclipse_degree, natal_lagna)
        house = _house_from_reference(eclipse_degree, natal_lagna)
        out["distance_from_natal_lagna_deg"] = round(dist, 2)
        out["house_from_natal_lagna"] = house
        if dist <= LAGNA_GRAHAN_ORB_DEGREES:
            triggers.append(f"Lagna Grahan — eclipse {dist:.2f}° from natal lagna (within {LAGNA_GRAHAN_ORB_DEGREES}° orb)")

    if natal_moon is not None:
        dist = _angular_distance(eclipse_degree, natal_moon)
        house = _house_from_reference(eclipse_degree, natal_moon)
        out["distance_from_natal_moon_deg"] = round(dist, 2)
        out["house_from_natal_moon"] = house
        if dist <= MOON_ECLIPSE_ORB_DEGREES:
            triggers.append(f"Chandra Grahan Dosha — eclipse {dist:.2f}° from natal Moon (within {MOON_ECLIPSE_ORB_DEGREES}° orb)")

    if natal_sun is not None:
        dist = _angular_distance(eclipse_degree, natal_sun)
        house = _house_from_reference(eclipse_degree, natal_sun)
        out["distance_from_natal_sun_deg"] = round(dist, 2)
        out["house_from_natal_sun"] = house
        if dist <= SUN_ECLIPSE_ORB_DEGREES:
            triggers.append(f"Surya Grahan — eclipse {dist:.2f}° from natal Sun (within {SUN_ECLIPSE_ORB_DEGREES}° orb; classical Pitra-signature trigger)")

    # Classical house-from-Moon interpretation (BPHS Ch. 25)
    h_moon = out.get("house_from_natal_moon")
    if h_moon:
        out["bphs_house_interpretation"] = _BPHS_ECLIPSE_HOUSE_EFFECTS.get(
            h_moon, "Effects per BPHS Ch. 25 depend on dasha context")

    out["triggers"] = triggers
    out["intensity"] = (
        "HIGH" if len(triggers) >= 2 else
        ("MODERATE" if len(triggers) == 1 else "LOW")
    )
    return out


_BPHS_ECLIPSE_HOUSE_EFFECTS = {
    1:  "Self/health — eclipses in 1st from Moon stress vitality and identity",
    2:  "Family/speech — wealth and verbal harmony affected",
    3:  "Siblings/courage — communication and initiative tested",
    4:  "Home/mother — domestic disruption, real estate themes",
    5:  "Children/intellect/purva punya — creativity, progeny, past-life merit unfold",
    6:  "Conflicts/health — debts, enemies, illness brought to surface",
    7:  "Partner — marriage, partnership tensions or revelations",
    8:  "Transformation — sudden change, hidden matters, occult exposure",
    9:  "Dharma/father — guru, father, long journey, spiritual recalibration",
    10: "Career/karma — profession, public role tested or upgraded",
    11: "Gains/networks — friend circles, income, large-group dynamics shift",
    12: "Losses/foreign — expenses, exile, retreat, hospital stays",
}


def handle_natal_eclipses(birth: Dict[str, Any],
                            window_days: int = NATAL_WINDOW_DEFAULT_DAYS) -> Dict[str, Any]:
    """
    F2a Endpoint: Eclipses around birth.

    Args:
      birth:       BirthInput dict
      window_days: how many days before AND after birth to search.
                   Default 30; clamped to MAX (180).

    Returns:
      List of eclipses (solar + lunar) found in the window, each with
      classical interaction analysis vs natal lagna/Moon/Sun.
    """
    # Clamp window
    try:
        w = int(window_days or NATAL_WINDOW_DEFAULT_DAYS)
    except (TypeError, ValueError):
        w = NATAL_WINDOW_DEFAULT_DAYS
    if w < 1:
        w = 1
    if w > NATAL_WINDOW_MAX_DAYS:
        w = NATAL_WINDOW_MAX_DAYS

    # Parse birth date
    try:
        birth_date = datetime.strptime(birth["dob"], "%Y-%m-%d").date()
    except (KeyError, ValueError) as e:
        return {"error": f"Invalid birth dob: {e}", "citations": F2A_CITATIONS["natal_eclipses"]}

    jd_birth = _date_to_jd(birth_date)
    jd_start = jd_birth - w
    jd_end = jd_birth + w

    natal = _natal_essentials(birth)
    eclipses = _find_eclipses_in_range(jd_start, jd_end, "both")

    # Annotate each with natal interaction
    enriched = []
    for ecl in eclipses:
        interaction = _classify_eclipse_natal_interaction(ecl, natal)
        days_from_birth = ecl["moment"]["jd"] - jd_birth
        ecl_out = dict(ecl)
        ecl_out["days_from_birth"] = round(days_from_birth, 2)
        ecl_out["before_or_after_birth"] = "before" if days_from_birth < 0 else "after"
        ecl_out["natal_interaction"] = interaction
        enriched.append(ecl_out)

    # Summary
    high_intensity = [e for e in enriched
                       if e["natal_interaction"].get("intensity") == "HIGH"]
    summary_lines = []
    if high_intensity:
        for e in high_intensity:
            d = e["moment"]["date_utc"]
            trigs = "; ".join(e["natal_interaction"].get("triggers", []))
            summary_lines.append(f"{d} ({e['kind']}): {trigs}")
    else:
        summary_lines.append("No high-intensity natal-eclipse signatures within window")

    return {
        "success":         True,
        "natal":           {k: v for k, v in natal.items()
                              if k in ("lagna_sign", "moon_sign", "sun_sign", "moon_nakshatra")},
        "window_days":     w,
        "max_window_days": NATAL_WINDOW_MAX_DAYS,
        "birth_date":      birth["dob"],
        "search_range_utc": {
            "from": _jd_to_iso_datetime(jd_start)["date_utc"],
            "to":   _jd_to_iso_datetime(jd_end)["date_utc"],
        },
        "eclipse_count":   len(enriched),
        "high_intensity_count": len(high_intensity),
        "summary":         summary_lines,
        "eclipses":        enriched,
        "classical_sources": F2A_CITATIONS["natal_eclipses"],
    }


# ════════════════════════════════════════════════════════════════════════
# UPCOMING ECLIPSES
# ════════════════════════════════════════════════════════════════════════

def handle_upcoming_eclipses(birth: Dict[str, Any],
                              query_date: Optional[str] = None,
                              years_ahead: int = UPCOMING_YEARS_DEFAULT) -> Dict[str, Any]:
    """
    F2a Endpoint: Eclipses ahead, with personal-impact analysis.

    Args:
      birth:       BirthInput dict
      query_date:  YYYY-MM-DD; defaults to today
      years_ahead: how many years forward to search.
                   Default 5; clamped to MAX (100).
    """
    try:
        y = int(years_ahead or UPCOMING_YEARS_DEFAULT)
    except (TypeError, ValueError):
        y = UPCOMING_YEARS_DEFAULT
    if y < 1:
        y = 1
    if y > UPCOMING_YEARS_MAX:
        y = UPCOMING_YEARS_MAX

    if query_date:
        try:
            start_date = datetime.strptime(query_date, "%Y-%m-%d").date()
        except ValueError as e:
            return {"error": f"Invalid query_date: {e}",
                     "citations": F2A_CITATIONS["upcoming_eclipses"]}
    else:
        start_date = date.today()

    jd_start = _date_to_jd(start_date)
    jd_end = jd_start + (y * 365.25)

    natal = _natal_essentials(birth)
    eclipses = _find_eclipses_in_range(jd_start, jd_end, "both")

    enriched = []
    for ecl in eclipses:
        interaction = _classify_eclipse_natal_interaction(ecl, natal)
        days_ahead = ecl["moment"]["jd"] - jd_start
        ecl_out = dict(ecl)
        ecl_out["days_from_query"] = round(days_ahead, 2)
        ecl_out["natal_interaction"] = interaction
        enriched.append(ecl_out)

    high_intensity = [e for e in enriched
                       if e["natal_interaction"].get("intensity") == "HIGH"]

    summary_lines = []
    if high_intensity:
        for e in high_intensity[:5]:   # cap summary listing
            d = e["moment"]["date_utc"]
            trigs = "; ".join(e["natal_interaction"].get("triggers", []))
            summary_lines.append(f"{d} ({e['kind']}): {trigs}")
        if len(high_intensity) > 5:
            summary_lines.append(f"... and {len(high_intensity) - 5} more high-intensity events")
    else:
        summary_lines.append(f"No high-intensity natal-eclipse contacts in next {y} years")

    return {
        "success":         True,
        "natal":           {k: v for k, v in natal.items()
                              if k in ("lagna_sign", "moon_sign", "sun_sign", "moon_nakshatra")},
        "query_date":      str(start_date),
        "years_ahead":     y,
        "max_years_ahead": UPCOMING_YEARS_MAX,
        "search_range_utc": {
            "from": _jd_to_iso_datetime(jd_start)["date_utc"],
            "to":   _jd_to_iso_datetime(jd_end)["date_utc"],
        },
        "eclipse_count":   len(enriched),
        "high_intensity_count": len(high_intensity),
        "summary":         summary_lines,
        "eclipses":        enriched,
        "classical_sources": F2A_CITATIONS["upcoming_eclipses"],
    }


# ════════════════════════════════════════════════════════════════════════
# SADE SATI ECLIPSE EXTENSION
# ════════════════════════════════════════════════════════════════════════

def handle_sade_sati_eclipse_extension(birth: Dict[str, Any],
                                          query_date: Optional[str] = None) -> Dict[str, Any]:
    """
    F2a Endpoint: Saturn-eclipse intersection layer over Sade Sati state.

    Logic:
      1. Get current Sade Sati state via transit_handle_sade_sati
      2. If active, find all eclipses within ±2 years of query_date
      3. Mark eclipses where Saturn (at eclipse moment) sits in 12th/1st/2nd
         from natal Moon (the active Sade Sati zone). These are
         classically intensification events.
      4. If NOT active, list nearby eclipses anyway with a note that
         Sade Sati isn't currently active, so eclipse impact is generic.
    """
    if query_date:
        try:
            q_date = datetime.strptime(query_date, "%Y-%m-%d").date()
        except ValueError as e:
            return {"error": f"Invalid query_date: {e}",
                     "citations": F2A_CITATIONS["sade_sati_eclipse_extension"]}
    else:
        q_date = date.today()

    # Get Sade Sati state via existing handler
    try:
        ss_state = _transit_handle_sade_sati(birth, str(q_date), None)
    except Exception as e:
        return {"error": f"Sade Sati handler failed: {e}",
                 "citations": F2A_CITATIONS["sade_sati_eclipse_extension"]}

    natal = _natal_essentials(birth)
    natal_moon_long = natal.get("moon_longitude")

    # Find eclipses in ±2 year window around query_date
    jd_q = _date_to_jd(q_date)
    jd_start = jd_q - 730   # ~2 years back
    jd_end = jd_q + 730

    eclipses = _find_eclipses_in_range(jd_start, jd_end, "both")

    # For each eclipse, compute Saturn position at eclipse moment and
    # determine if it falls in the Sade Sati zone (12/1/2 from natal Moon).
    sade_sati_zone_signs = []
    if natal_moon_long is not None:
        moon_sign_idx = int(natal_moon_long / 30) % 12
        # 12th, 1st, 2nd from Moon = signs at indices (moon-1, moon, moon+1) mod 12
        sade_sati_zone_signs = [
            SIGNS[(moon_sign_idx - 1) % 12],  # 12th from Moon
            SIGNS[moon_sign_idx],              # 1st from Moon (Janma)
            SIGNS[(moon_sign_idx + 1) % 12],  # 2nd from Moon
        ]

    annotated_eclipses = []
    for ecl in eclipses:
        jd_max = ecl["moment"]["jd"]
        # Compute Saturn's sidereal sign at this eclipse moment
        try:
            swe.set_sid_mode(swe.SIDM_LAHIRI)
            sat_pos, _ = swe.calc_ut(jd_max, swe.SATURN, swe.FLG_SIDEREAL | swe.FLG_SPEED)
            sat_long = sat_pos[0]
            sat_sign = SIGNS[int(sat_long / 30) % 12]
        except Exception:
            sat_long = None
            sat_sign = None

        in_ss_zone = (sat_sign in sade_sati_zone_signs) if sat_sign else False
        ecl_out = dict(ecl)
        ecl_out["saturn_at_eclipse"] = {
            "sign":              sat_sign,
            "longitude":         round(sat_long, 4) if sat_long is not None else None,
            "in_sade_sati_zone": in_ss_zone,
            "note": (f"Saturn in {sat_sign} during this eclipse falls in the "
                     f"Sade Sati zone (12th/1st/2nd from natal Moon in {natal.get('moon_sign')}). "
                     f"Classical intensification signature.") if in_ss_zone
                    else f"Saturn in {sat_sign} during this eclipse — outside Sade Sati zone.",
        }
        # Also include natal interaction (whether eclipse hits natal points)
        ecl_out["natal_interaction"] = _classify_eclipse_natal_interaction(ecl, natal)
        annotated_eclipses.append(ecl_out)

    # Intensification events = eclipses where Saturn is in SS zone
    intensification_events = [e for e in annotated_eclipses
                                if e["saturn_at_eclipse"].get("in_sade_sati_zone")]

    summary = []
    if ss_state.get("active"):
        summary.append(f"Sade Sati ACTIVE ({ss_state.get('phase_name', ss_state.get('phase', 'unknown phase'))}).")
        if intensification_events:
            summary.append(f"{len(intensification_events)} eclipse(s) in ±2yr window fall within Sade Sati zone — classical intensification.")
        else:
            summary.append("No eclipses in ±2yr window fall within Sade Sati zone.")
    else:
        summary.append(f"Sade Sati NOT currently active. {ss_state.get('reason', '')}")
        summary.append("Eclipse listing below is provided for context only.")

    return {
        "success":               True,
        "query_date":            str(q_date),
        "sade_sati_state":       ss_state,
        "natal":                 {k: v for k, v in natal.items()
                                    if k in ("lagna_sign", "moon_sign", "sun_sign", "moon_nakshatra")},
        "sade_sati_zone_signs":  sade_sati_zone_signs,
        "search_range_utc": {
            "from": _jd_to_iso_datetime(jd_start)["date_utc"],
            "to":   _jd_to_iso_datetime(jd_end)["date_utc"],
        },
        "eclipses_in_window":          len(annotated_eclipses),
        "intensification_event_count": len(intensification_events),
        "summary":                     summary,
        "eclipses":                    annotated_eclipses,
        "classical_sources":           F2A_CITATIONS["sade_sati_eclipse_extension"],
    }
