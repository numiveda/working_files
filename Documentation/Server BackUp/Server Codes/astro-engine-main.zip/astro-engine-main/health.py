"""
health.py — Health + Chakra + Ayurveda Engine (Module B1)

Architecture:
- Uses astro_helpers for shared chart extraction
- 15 endpoints across health (body, disease, mental), ayurveda (prakriti, vikriti, diet, yoga),
  chakras (state, balancing), and longevity

Classical sources cited per function.
"""

from typing import Dict, List, Optional, Any
from datetime import datetime

from astro_helpers import (
    extract_chart_essentials,
    get_chart,
    afflicted_planets,
    weakest_planet,
    CHAKRA_SYSTEM,
    PLANET_TO_BODY_PART,
    PLANET_TO_DOSHA,
    SIGN_TO_DOSHA,
    SIGNS_ORDER,
)

from health_data import (
    HOUSE_TO_BODY_PART,
    PLANET_DETAILED_ORGANS,
    DISEASE_PREDISPOSITION_RULES,
    PRAKRITI_BY_LAGNA,
    NAKSHATRA_DOSHA_MODIFIER,
    DOSHA_CHARACTERISTICS,
    DIET_BY_DOSHA,
    YOGA_BY_DOSHA,
    YOGA_BY_PLANET,
    MENTAL_HEALTH_INDICATORS,
    LONGEVITY_FACTORS,
    HEALING_WINDOWS,
    CHAKRA_BALANCING,
)


# ════════════════════════════════════════════════════════════════════════
# 1. MASTER PROFILE
# ════════════════════════════════════════════════════════════════════════

def full_health_profile(dob: str, time: str, lat: float, lon: float,
                         timezone: str = "Asia/Kolkata",
                         gender: str = "male") -> Dict[str, Any]:
    """Master endpoint — full Health + Chakra + Ayurveda overview."""
    chart = get_chart(dob, time, lat, lon, timezone)
    ch = extract_chart_essentials(chart)

    return {
        "input": {"dob": dob, "time": time, "lat": lat, "lon": lon, "gender": gender},
        "chart_summary": {
            "lagna":          ch["lagna_sign"],
            "moon_sign":      ch["moon_sign"],
            "moon_nakshatra": ch["moon_nakshatra"],
            "atmakaraka":     ch["atmakaraka"],
            "current_md":     ch["current_md"],
        },
        "body_parts":             _body_parts_analysis(ch),
        "illness_predisposition": _illness_predisposition(ch),
        "tridosha":               _tridosha_analysis(ch),
        "prakriti":               _prakriti_determination(ch),
        "vikriti_current":        _vikriti_current(ch),
        "chakras":                _chakra_state(ch),
        "ayurvedic_diet":         _diet_recommendation(ch),
        "yoga_pranayama":         _yoga_pranayama(ch),
        "mental_health":          _mental_health_analysis(ch),
        "longevity":              _longevity_assessment(ch),
        "healing_windows":        _healing_windows(ch),
        "health_remedies":        _health_remedies(ch),
        "classical_sources": [
            "Charaka Samhita (~300 BCE)",
            "Sushruta Samhita (~600 BCE)",
            "Ashtanga Hridaya (Vagbhata, ~600 CE)",
            "Hatha Yoga Pradipika (~1500 CE)",
            "Brihat Parashara Hora Shastra Ch. 30, 75-76",
            "Sarvartha Chintamani (~17th c.)",
        ],
    }


# ════════════════════════════════════════════════════════════════════════
# 2. BODY PARTS ANALYSIS
# ════════════════════════════════════════════════════════════════════════

def _body_parts_analysis(ch: Dict) -> Dict:
    """Map chart placements to body parts; identify weak/strong areas."""
    weak_houses = []
    afflicted_orgs = []

    for planet, pdata in ch["planets"].items():
        house = pdata.get("house")
        dignity = pdata.get("dignity", "")
        retro = pdata.get("is_retrograde", False)
        combust = pdata.get("is_combust", False)

        # Mark organs as afflicted if planet is troubled
        organs = PLANET_DETAILED_ORGANS.get(planet, {})
        if dignity in ("debilitated", "great_enemy", "enemy") or retro or combust:
            afflicted_orgs.append({
                "planet":           planet,
                "organs_at_risk":   organs.get("primary", []),
                "dosha_imbalance":  organs.get("dosha"),
                "reasons":          [r for r in [
                    f"{dignity} dignity" if dignity in ("debilitated", "great_enemy", "enemy") else None,
                    "retrograde" if retro else None,
                    "combust" if combust else None,
                ] if r],
            })
        # Mark house body region as weak if multiple malefics or afflicted house lord
        if house in (6, 8, 12) and planet in ("Sun", "Mars", "Saturn", "Rahu", "Ketu"):
            weak_houses.append({
                "house":     house,
                "body_region": HOUSE_TO_BODY_PART.get(house, {}).get("region"),
                "system":    HOUSE_TO_BODY_PART.get(house, {}).get("system"),
                "afflicted_by": planet,
            })

    # All planets' organ rulership for reference
    all_organs = {}
    for planet, pdata in ch["planets"].items():
        organs = PLANET_DETAILED_ORGANS.get(planet, {})
        all_organs[planet] = {
            "house":     pdata.get("house"),
            "sign":      pdata.get("sign"),
            "dignity":   pdata.get("dignity"),
            "organs":    organs.get("primary", []),
            "dosha":     organs.get("dosha"),
            "tissue":    organs.get("tissue"),
        }

    return {
        "house_to_body_part_map":   HOUSE_TO_BODY_PART,
        "planet_organs_in_chart":   all_organs,
        "afflicted_organs":         afflicted_orgs,
        "weak_house_regions":       weak_houses,
        "classical_source":         "Charaka Samhita Ch. 8 + BPHS Ch. 30",
    }


# ════════════════════════════════════════════════════════════════════════
# 3. ILLNESS PREDISPOSITION
# ════════════════════════════════════════════════════════════════════════

def _illness_predisposition(ch: Dict) -> Dict:
    """Disease tendencies from 6th house + afflicted planets."""
    sixth_house_lord = ch["house_lords"].get(6)
    eighth_house_lord = ch["house_lords"].get(8)
    twelfth_house_lord = ch["house_lords"].get(12)

    # Get sign in 6th house
    lagna = ch["lagna_sign"]
    sixth_sign = None
    if lagna in SIGNS_ORDER:
        sixth_sign = SIGNS_ORDER[(SIGNS_ORDER.index(lagna) + 5) % 12]

    # Planets in 6th house
    planets_in_6 = [p for p, pd in ch["planets"].items() if pd.get("house") == 6]
    planets_in_8 = [p for p, pd in ch["planets"].items() if pd.get("house") == 8]
    planets_in_12 = [p for p, pd in ch["planets"].items() if pd.get("house") == 12]

    six_signs_data = DISEASE_PREDISPOSITION_RULES["6th_house_analysis"]
    sixth_sign_diseases = six_signs_data["by_sign"].get(sixth_sign) if sixth_sign else None

    planet_diseases = []
    for p in planets_in_6:
        d = six_signs_data["planet_in_6th"].get(p)
        if d:
            planet_diseases.append({"planet": p, "tendency": d})

    return {
        "sixth_house": {
            "sign":              sixth_sign,
            "sign_tendency":     sixth_sign_diseases,
            "lord":              sixth_house_lord,
            "planets_present":   planets_in_6,
            "planet_tendencies": planet_diseases,
        },
        "eighth_house": {
            "lord":            eighth_house_lord,
            "planets_present": planets_in_8,
            "interpretation":  DISEASE_PREDISPOSITION_RULES["8th_house_analysis"]["description"],
            "key_rule":        DISEASE_PREDISPOSITION_RULES["8th_house_analysis"]["key_rule"],
        },
        "twelfth_house": {
            "lord":            twelfth_house_lord,
            "planets_present": planets_in_12,
            "interpretation":  DISEASE_PREDISPOSITION_RULES["12th_house_analysis"]["description"],
        },
        "ascendant_afflictions": DISEASE_PREDISPOSITION_RULES["ascendant_afflictions"],
        "classical_source":      "BPHS Ch. 30 (Rishtadhyaya) + Charaka Sutrasthana",
    }


# ════════════════════════════════════════════════════════════════════════
# 4. TRIDOSHA ANALYSIS
# ════════════════════════════════════════════════════════════════════════

def _tridosha_analysis(ch: Dict) -> Dict:
    """Map chart's dosha emphasis."""
    # Tally dosha presence based on planets' natural dosha
    dosha_counts = {"vata": 0, "pitta": 0, "kapha": 0}
    for planet, pdata in ch["planets"].items():
        for d in PLANET_TO_DOSHA.get(planet, []):
            if d in dosha_counts:
                dosha_counts[d] += 1

    # Add sign-based dosha contributions
    for planet, pdata in ch["planets"].items():
        sign = pdata.get("sign")
        if sign:
            sign_dosha = SIGN_TO_DOSHA.get(sign)
            if sign_dosha in dosha_counts:
                dosha_counts[sign_dosha] += 1

    return {
        "dosha_counts":           dosha_counts,
        "dominant_dosha":         max(dosha_counts, key=dosha_counts.get),
        "dosha_characteristics":  DOSHA_CHARACTERISTICS,
        "classical_source":       "Charaka Sutra Sthana + composite Vedic-Ayurvedic synthesis",
    }


# ════════════════════════════════════════════════════════════════════════
# 5. PRAKRITI (BIRTH CONSTITUTION)
# ════════════════════════════════════════════════════════════════════════

def _prakriti_determination(ch: Dict) -> Dict:
    """Determine Prakriti from Lagna + Moon nakshatra."""
    lagna = ch["lagna_sign"]
    moon_nakshatra = ch["moon_nakshatra"]

    primary_prakriti = PRAKRITI_BY_LAGNA.get(lagna, {})
    nakshatra_modifier = NAKSHATRA_DOSHA_MODIFIER.get(moon_nakshatra) if moon_nakshatra else None

    return {
        "lagna":               lagna,
        "moon_nakshatra":      moon_nakshatra,
        "primary_prakriti":    primary_prakriti,
        "nakshatra_modifier":  nakshatra_modifier,
        "determination_rule":  "Lagna sign determines primary dual-dosha. Moon nakshatra modifies. Practitioner should verify with Ayurvedic physical observation.",
        "classical_source":    "Charaka Vimana Ch. 8 + Sushruta Sharira Ch. 4",
    }


# ════════════════════════════════════════════════════════════════════════
# 6. VIKRITI (CURRENT IMBALANCE)
# ════════════════════════════════════════════════════════════════════════

# ── B1 VIKRITI v2 (Round 4) ──
# Composite Vikriti synthesis: dasha + transits + Ritu + age + lunar state.
# Classical: Charaka Vimana Ch.8; Sutra Ch.6 (Ritucharya); Phaladeepika Ch.6;
#            Sarvartha Chintamani Ch.15 (Jyotish health analysis).

import swisseph as _swe
from datetime import datetime as _dt, timezone as _tz, date as _date
from zoneinfo import ZoneInfo as _ZoneInfo


# ── Classical Ritu → dosha mapping (Charaka Samhita Sutra Ch.6) ──
# Each sidereal sign maps to one of 6 Ritus. Each Ritu has classical
# accumulating/vitiating doshas based on environmental conditions.
_SIGNS_ORDER_VIKRITI = ["Aries","Taurus","Gemini","Cancer","Leo","Virgo",
                        "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"]

_SIGN_TO_RITU = {
    # (Ritu Sanskrit, season English, [vitiated doshas], classical note)
    0:  ("Vasanta",  "spring",     ["kapha"],          "Kapha accumulated in winter vitiates; energy of growth"),
    1:  ("Vasanta",  "spring",     ["kapha"],          "Kapha accumulated in winter vitiates; energy of growth"),
    2:  ("Grishma",  "summer",     ["vata"],           "Vata accumulates from heat-depleted body fluids; bodily strength wanes"),
    3:  ("Grishma",  "summer",     ["vata"],           "Vata accumulates from heat-depleted body fluids; bodily strength wanes"),
    4:  ("Varsha",   "monsoon",    ["pitta", "vata"],  "Pitta accumulates from monsoon dampness; vata vitiated by chill"),
    5:  ("Varsha",   "monsoon",    ["pitta", "vata"],  "Pitta accumulates from monsoon dampness; vata vitiated by chill"),
    6:  ("Sharad",   "autumn",     ["pitta"],          "Pitta vitiates strongly after monsoon — peak pitta season"),
    7:  ("Sharad",   "autumn",     ["pitta"],          "Pitta vitiates strongly after monsoon — peak pitta season"),
    8:  ("Hemanta",  "pre-winter", ["kapha"],          "Kapha accumulates from cold/heavy foods; strength returns"),
    9:  ("Hemanta",  "pre-winter", ["kapha"],          "Kapha accumulates from cold/heavy foods; strength returns"),
    10: ("Shishira", "winter",     ["kapha", "vata"],  "Kapha peaks; vata accumulates from dryness and cold"),
    11: ("Shishira", "winter",     ["kapha", "vata"],  "Kapha peaks; vata accumulates from dryness and cold"),
}


# ── Age-bracket dominant dosha (Charaka Vimana Ch.8) ──
def _compute_age_bracket(dob: str) -> Dict:
    """Bala (childhood = kapha), Madhya (middle = pitta), Vriddha (old = vata)."""
    try:
        y, m, d = map(int, dob.split("-"))
        birth = _date(y, m, d)
        today = _date.today()
        age = (today - birth).days / 365.25
    except Exception:
        return {"bracket": None, "age_years": None, "dominant_dosha": None,
                "note": "DOB unparseable"}

    if age < 16:
        bracket, dom = "Bala", "kapha"
        note = "Bala (childhood, <16 yrs) — kapha-dominant phase; growth, accumulation"
    elif age < 60:
        bracket, dom = "Madhya", "pitta"
        note = "Madhya (middle, 16-60 yrs) — pitta-dominant phase; transformation, work, achievement"
    else:
        bracket, dom = "Vriddha", "vata"
        note = "Vriddha (elder, 60+ yrs) — vata-dominant phase; deterioration, dryness, depletion"

    return {
        "bracket":        bracket,
        "age_years":      round(age, 1),
        "dominant_dosha": dom,
        "classical_note": note,
        "citation":       "Charaka Samhita Vimana Sthana Ch.8",
    }


# ── Current transits via swisseph (sidereal Lahiri to match engine) ──
def _compute_current_transits() -> Dict:
    """Compute current sidereal Lahiri positions of Sun, Moon, Mars, Saturn."""
    _swe.set_sid_mode(_swe.SIDM_LAHIRI)
    now = _dt.now(_tz.utc)
    jd = _swe.julday(now.year, now.month, now.day, now.hour + now.minute / 60.0)

    planet_ids = {"Sun": _swe.SUN, "Moon": _swe.MOON, "Mars": _swe.MARS,
                  "Saturn": _swe.SATURN}
    transits = {}
    for name, pid in planet_ids.items():
        pos, _ = _swe.calc_ut(jd, pid, _swe.FLG_SIDEREAL | _swe.FLG_SPEED)
        lon = pos[0]
        sign_idx = int(lon // 30)
        transits[name] = {
            "sign":             _SIGNS_ORDER_VIKRITI[sign_idx],
            "degree_in_sign":   round(lon % 30, 2),
            "longitude":        round(lon, 4),
            "is_retrograde":    pos[3] < 0,
            "daily_speed":      round(pos[3], 4),
        }

    return {
        "computed_at":    now.strftime("%Y-%m-%d %H:%M UTC"),
        "ayanamsha":      "Lahiri",
        "positions":      transits,
    }


# ── Current Ritu (Vedic season) from Sun's sidereal position ──
def _compute_current_ritu(transits: Dict) -> Dict:
    """Map Sun's sidereal sign to one of 6 Ritus per Charaka Samhita."""
    sun = transits.get("positions", {}).get("Sun", {})
    sun_sign = sun.get("sign")
    if not sun_sign or sun_sign not in _SIGNS_ORDER_VIKRITI:
        return {"name": None, "season": None, "vitiated_doshas": [], "note": "Sun position unavailable"}

    sign_idx = _SIGNS_ORDER_VIKRITI.index(sun_sign)
    ritu_name, season, doshas, note = _SIGN_TO_RITU[sign_idx]

    return {
        "name":             ritu_name,
        "season":           season,
        "sun_sign":         sun_sign,
        "vitiated_doshas":  doshas,
        "classical_note":   note,
        "citation":         "Charaka Samhita Sutra Sthana Ch.6 (Ritucharya); Sushruta Samhita Sutra Ch.6",
    }


# ── Lunar state (waxing/waning) — affects daily dosha balance ──
def _compute_lunar_state(transits: Dict) -> Dict:
    """Moon's relationship to Sun determines waxing (kapha-building) or waning (vata-stirring)."""
    sun = transits.get("positions", {}).get("Sun", {})
    moon = transits.get("positions", {}).get("Moon", {})
    if not sun or not moon:
        return {"phase": None, "note": "Sun/Moon positions unavailable"}

    sun_lon = sun.get("longitude", 0)
    moon_lon = moon.get("longitude", 0)

    # Tithi calculation: (Moon longitude - Sun longitude) / 12, mod 30
    diff = (moon_lon - sun_lon) % 360
    tithi_num = int(diff // 12) + 1  # 1 to 30
    is_waxing = tithi_num <= 15  # Shukla paksha (waxing) = 1-15, Krishna paksha (waning) = 16-30

    if is_waxing:
        phase = "Shukla Paksha (waxing)"
        dosha_effect = ["kapha"]
        note = "Waxing Moon builds kapha (anabolic, nourishing). Body retains, accumulates."
    else:
        phase = "Krishna Paksha (waning)"
        dosha_effect = ["vata"]
        note = "Waning Moon stirs vata (catabolic, depleting). Body releases, dries."

    # Tithi-specific names for first/last days
    if tithi_num == 15:
        tithi_label = "Purnima (Full Moon) — peak kapha"
    elif tithi_num == 30:
        tithi_label = "Amavasya (New Moon) — peak vata"
    elif tithi_num == 1:
        tithi_label = "Pratipada (just past Amavasya)"
    else:
        tithi_label = f"Tithi {tithi_num}"

    return {
        "phase":            phase,
        "tithi_num":        tithi_num,
        "tithi_label":      tithi_label,
        "dosha_effect":     dosha_effect,
        "classical_note":   note,
        "citation":         "Brihat Samhita Ch.4-5 (lunar effects on dosha); Charaka Sutra Ch.6",
    }


# ── Transit dosha analysis: where are Sun/Mars/Saturn/Moon now? ──
def _analyze_transit_doshas(transits: Dict) -> Dict:
    """Map current transit planets to their dosha contributions."""
    positions = transits.get("positions", {})

    contributions = []
    if positions.get("Sun"):
        contributions.append({
            "planet": "Sun", "in_sign": positions["Sun"]["sign"],
            "dosha":  ["pitta"],
            "note":   "Sun transit contributes pitta heat; emphasizes pitta in current sign",
        })
    if positions.get("Mars"):
        contributions.append({
            "planet": "Mars", "in_sign": positions["Mars"]["sign"],
            "dosha":  ["pitta"],
            "is_retrograde": positions["Mars"].get("is_retrograde", False),
            "note":   "Mars transit aggravates pitta; retrograde Mars intensifies inflammation",
        })
    if positions.get("Saturn"):
        contributions.append({
            "planet": "Saturn", "in_sign": positions["Saturn"]["sign"],
            "dosha":  ["vata"],
            "is_retrograde": positions["Saturn"].get("is_retrograde", False),
            "note":   "Saturn transit aggravates vata; brings dryness, stiffness, depletion",
        })
    if positions.get("Moon"):
        contributions.append({
            "planet": "Moon", "in_sign": positions["Moon"]["sign"],
            "dosha":  ["vata", "kapha"],
            "note":   "Moon transit modulates vata-kapha; rapid sign change every ~2.25 days",
        })

    # Aggregate vitiated doshas
    aggregate = set()
    for c in contributions:
        for d in c.get("dosha", []):
            aggregate.add(d)

    return {
        "planet_contributions":  contributions,
        "aggregate_doshas":      sorted(aggregate),
        "citation":              "Sarvartha Chintamani Ch.15 (transit health analysis); Phaladeepika Ch.6 (planetary dosha lords)",
    }


def _vikriti_current(ch: Dict, birth: Dict = None) -> Dict:
    """
    Composite Vikriti synthesis — Charaka + Jyotish tradition.

    Components:
        1. Dasha-period dosha (MD + AD lords' doshas)
        2. Current transit dosha (Sun/Mars/Saturn/Moon NOW via swisseph)
        3. Ritu (Vedic season) dosha emphasis
        4. Age-bracket dominant dosha (Bala/Madhya/Vriddha)
        5. Today's lunar state (waxing kapha vs waning vata)

    Returns composite analysis with each component cited per classical source.
    """
    # ── Component 1: Dasha-period dosha (existing logic, preserved) ──
    md = ch.get("current_md")
    ad = ch.get("current_ad")
    md_dosha = PLANET_TO_DOSHA.get(md, []) if md else []
    ad_dosha = PLANET_TO_DOSHA.get(ad, []) if ad else []
    dasha_emphasis = sorted(set(md_dosha + ad_dosha))

    # ── Component 2: Natal afflictions (existing logic, preserved) ──
    afflicted = afflicted_planets(ch)
    afflicted_doshas = sorted(set(
        d for ap in afflicted for d in PLANET_TO_DOSHA.get(ap["planet"], [])
    ))

    # ── Component 3: Current transits (NEW) ──
    transits = _compute_current_transits()
    transit_analysis = _analyze_transit_doshas(transits)
    transit_doshas = transit_analysis["aggregate_doshas"]

    # ── Component 4: Ritu (NEW) ──
    ritu = _compute_current_ritu(transits)
    ritu_doshas = ritu.get("vitiated_doshas", [])

    # ── Component 5: Age bracket (NEW) ──
    age = _compute_age_bracket(birth.get("dob")) if birth and birth.get("dob") else           {"bracket": None, "dominant_dosha": None, "note": "Birth DOB not provided"}

    # ── Component 6: Lunar state (NEW) ──
    lunar = _compute_lunar_state(transits)
    lunar_doshas = lunar.get("dosha_effect", [])

    # ── Composite synthesis ──
    # Count dosha occurrences across all 5 streams + natal affliction
    all_streams = []
    if dasha_emphasis:           all_streams.extend([("dasha", d) for d in dasha_emphasis])
    if transit_doshas:           all_streams.extend([("transit", d) for d in transit_doshas])
    if ritu_doshas:              all_streams.extend([("ritu", d) for d in ritu_doshas])
    if age.get("dominant_dosha"):all_streams.append(("age", age["dominant_dosha"]))
    if lunar_doshas:             all_streams.extend([("lunar", d) for d in lunar_doshas])
    if afflicted_doshas:         all_streams.extend([("affliction", d) for d in afflicted_doshas])

    dosha_score = {"vata": 0, "pitta": 0, "kapha": 0}
    dosha_sources = {"vata": [], "pitta": [], "kapha": []}
    for source, d in all_streams:
        if d in dosha_score:
            dosha_score[d] += 1
            dosha_sources[d].append(source)

    # Determine dominant + secondary
    sorted_doshas = sorted(dosha_score.items(), key=lambda x: -x[1])
    dominant_dosha = sorted_doshas[0][0] if sorted_doshas[0][1] > 0 else None
    secondary_dosha = sorted_doshas[1][0] if len(sorted_doshas) > 1 and sorted_doshas[1][1] > 0 else None

    # Build interpretive paragraph
    interpretation_parts = []
    if dominant_dosha:
        srcs = ", ".join(sorted(set(dosha_sources[dominant_dosha])))
        interpretation_parts.append(
            f"Composite Vikriti shows {dominant_dosha.upper()} dominance "
            f"(score {dosha_score[dominant_dosha]}, sources: {srcs})."
        )
    if secondary_dosha:
        srcs = ", ".join(sorted(set(dosha_sources[secondary_dosha])))
        interpretation_parts.append(
            f"Secondary emphasis: {secondary_dosha} (score {dosha_score[secondary_dosha]}, sources: {srcs})."
        )
    if ritu.get("name"):
        interpretation_parts.append(
            f"Current Ritu is {ritu['name']} ({ritu['season']}) — classically vitiates {', '.join(ritu['vitiated_doshas'])}."
        )
    if age.get("bracket"):
        interpretation_parts.append(
            f"Age-bracket: {age['bracket']} — life-phase emphasizes {age['dominant_dosha']}."
        )
    if lunar.get("tithi_label"):
        interpretation_parts.append(
            f"Lunar phase: {lunar['tithi_label']} ({lunar['phase']}) — stirs {', '.join(lunar['dosha_effect'])}."
        )
    interpretation_parts.append(
        "Recommended: counter the dominant dosha through diet/lifestyle aligned with classical Charaka regimens for this Ritu and age-bracket."
    )

    return {
        # ── Composite synthesis (NEW — top of response for LLM clarity) ──
        "composite_vikriti": {
            "dominant_dosha":     dominant_dosha,
            "secondary_dosha":    secondary_dosha,
            "dosha_scores":       dosha_score,
            "dosha_sources":      dosha_sources,
            "interpretation":     " ".join(interpretation_parts),
        },

        # ── 5 component analyses (NEW) ──
        "dasha_component": {
            "current_md":      md,
            "current_md_dosha":md_dosha,
            "current_ad":      ad,
            "current_ad_dosha":ad_dosha,
            "emphasis":        dasha_emphasis,
            "citation":        "Vimshottari Dasha tradition (BPHS); Phaladeepika Ch.6",
        },
        "transit_component": {
            "transits":        transits,
            "analysis":        transit_analysis,
        },
        "ritu_component":     ritu,
        "age_component":      age,
        "lunar_component":    lunar,

        # ── Natal affliction (existing, preserved) ──
        "natal_affliction_doshas": afflicted_doshas,

        # ── Backward-compat keys (preserved from v1) ──
        "current_md":              md,
        "current_md_dosha":        md_dosha,
        "current_ad":              ad,
        "current_ad_dosha":        ad_dosha,
        "current_dosha_emphasis":  dasha_emphasis,
        "afflicted_planet_doshas": afflicted_doshas,
        "interpretation":          " ".join(interpretation_parts),

        # ── Method + sources ──
        "method": (
            "Composite Vikriti synthesis: dasha-dosha (Vimshottari) + current transit "
            "positions (Swiss Ephemeris Lahiri) + Ritu/season (Charaka) + age-bracket "
            "dominant dosha (Charaka Vimana Ch.8) + lunar state (waxing kapha / waning vata)."
        ),
        "classical_sources": [
            "Charaka Samhita Vimana Sthana Ch.8 — Vikriti analysis, age-bracket doshas",
            "Charaka Samhita Sutra Sthana Ch.6 — Ritucharya (seasonal regimen)",
            "Sushruta Samhita Sutra Sthana Ch.6 — Seasonal dosha vitiation",
            "Sarvartha Chintamani Ch.15 — Jyotish health analysis with transits",
            "Phaladeepika Ch.6 — Planetary dosha lords and health timing",
            "Brihat Samhita Ch.4-5 — Lunar effects on body fluids and doshas",
        ],
    }
# ── END B1 VIKRITI v2 ──
# ════════════════════════════════════════════════════════════════════════
# 7. CHAKRA STATE
# ════════════════════════════════════════════════════════════════════════

def _chakra_state(ch: Dict) -> Dict:
    """Map planets' chakra associations + chart afflictions to chakra status."""
    afflicted = afflicted_planets(ch)
    afflicted_planet_names = [a["planet"] for a in afflicted]

    chakra_status = []
    for chakra_key, chakra_data in CHAKRA_SYSTEM.items():
        primary = chakra_data["primary_planet"]
        secondary = chakra_data["secondary_planet"]

        # Chakra is "afflicted" if primary or secondary planet is afflicted
        is_afflicted = primary in afflicted_planet_names or secondary in afflicted_planet_names

        # Get planet position info
        primary_data = ch["planets"].get(primary, {})

        chakra_status.append({
            "chakra":           chakra_key,
            "name":             chakra_data["name"],
            "primary_planet":   primary,
            "primary_planet_house": primary_data.get("house"),
            "primary_planet_dignity": primary_data.get("dignity"),
            "secondary_planet": secondary,
            "element":          chakra_data["element"],
            "color":            chakra_data["color"],
            "bija_mantra":      chakra_data["bija_mantra"],
            "domain":           chakra_data["domain"],
            "status":           "afflicted" if is_afflicted else "balanced",
            "primary_afflicted":primary in afflicted_planet_names,
        })

    return {
        "chakra_status":    chakra_status,
        "classical_source": "Hatha Yoga Pradipika + Shiva Samhita + composite synthesis",
    }


# ════════════════════════════════════════════════════════════════════════
# 8. CHAKRA BALANCING
# ════════════════════════════════════════════════════════════════════════

def chakra_balancing_for_chart(dob: str, time: str, lat: float, lon: float,
                                timezone: str = "Asia/Kolkata") -> Dict:
    """Per-chakra balancing practices, prioritized by chart afflictions."""
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    chakra_state_data = _chakra_state(ch)

    # Build prioritized list — afflicted chakras first
    prioritized = []
    for cs in chakra_state_data["chakra_status"]:
        if cs["status"] == "afflicted":
            chakra_key = cs["chakra"]
            prioritized.append({
                "priority":  "high",
                "chakra":    chakra_key,
                "name":      cs["name"],
                "reason":    f"{cs['primary_planet']} ({'afflicted' if cs['primary_afflicted'] else 'secondary afflicted'}) governs this chakra",
                "balancing": CHAKRA_BALANCING.get(chakra_key, {}),
            })

    # Add balanced chakras as lower priority
    for cs in chakra_state_data["chakra_status"]:
        if cs["status"] == "balanced":
            chakra_key = cs["chakra"]
            prioritized.append({
                "priority":  "maintenance",
                "chakra":    chakra_key,
                "name":      cs["name"],
                "reason":    "Currently balanced — maintenance practice",
                "balancing": CHAKRA_BALANCING.get(chakra_key, {}),
            })

    return {
        "prioritized_chakra_work": prioritized,
        "full_balancing_catalog":  CHAKRA_BALANCING,
        "classical_source":        "Hatha Yoga Pradipika Ch. 3 + Shiva Samhita",
    }


# ════════════════════════════════════════════════════════════════════════
# 9. AYURVEDIC DIET
# ════════════════════════════════════════════════════════════════════════

def _diet_recommendation(ch: Dict) -> Dict:
    """Diet recommendations based on Prakriti."""
    lagna = ch["lagna_sign"]
    prakriti = PRAKRITI_BY_LAGNA.get(lagna, {})
    primary_dosha = prakriti.get("primary", "vata")

    return {
        "primary_dosha":      primary_dosha,
        "diet_for_primary":   DIET_BY_DOSHA.get(primary_dosha, {}),
        "all_doshas_diet":    DIET_BY_DOSHA,
        "classical_source":   "Charaka Sutra Sthana Ch. 25-27",
    }


# ════════════════════════════════════════════════════════════════════════
# 10. YOGA + PRANAYAMA
# ════════════════════════════════════════════════════════════════════════

def _yoga_pranayama(ch: Dict) -> Dict:
    """Yoga asanas and pranayama for native's chart."""
    lagna = ch["lagna_sign"]
    prakriti = PRAKRITI_BY_LAGNA.get(lagna, {})
    primary_dosha = prakriti.get("primary", "vata")
    weakest = weakest_planet(ch)
    lagna_lord = ch["lagna_lord"]

    primary_yoga = YOGA_BY_DOSHA.get(primary_dosha, {})

    planet_specific_yoga = {}
    if weakest:
        planet_specific_yoga["weakest_planet"] = {
            "planet": weakest,
            "practices": YOGA_BY_PLANET.get(weakest, []),
        }
    if lagna_lord:
        planet_specific_yoga["lagna_lord"] = {
            "planet": lagna_lord,
            "practices": YOGA_BY_PLANET.get(lagna_lord, []),
        }

    return {
        "primary_dosha":             primary_dosha,
        "yoga_for_dosha":            primary_yoga,
        "planet_specific_yoga":      planet_specific_yoga,
        "all_dosha_yoga_catalogs":   YOGA_BY_DOSHA,
        "all_planet_yoga_catalogs":  YOGA_BY_PLANET,
        "classical_source":          "Hatha Yoga Pradipika + Gheranda Samhita",
    }


# ════════════════════════════════════════════════════════════════════════
# 11. MENTAL HEALTH
# ════════════════════════════════════════════════════════════════════════

def _mental_health_analysis(ch: Dict) -> Dict:
    """Moon, Mercury, 5th house analysis for mental tendencies."""
    moon_sign = ch["moon_sign"]
    moon_house = ch["moon_house"]
    mercury_data = ch["planets"].get("Mercury", {})

    moon_sign_pattern = MENTAL_HEALTH_INDICATORS["moon_analysis"]["moon_signs"].get(moon_sign) if moon_sign else None

    # Check Moon afflictions
    moon_afflictions = []
    moon_data = ch["planets"].get("Moon", {})
    moon_house_num = moon_data.get("house")

    if moon_house_num in (6, 8, 12):
        moon_afflictions.append(MENTAL_HEALTH_INDICATORS["moon_analysis"]["moon_afflictions"]["in_6_8_12"])

    # Check if Moon is with Saturn, Mars, Rahu, Ketu
    moon_sign_name = ch["moon_sign"]
    for other_planet in ("Saturn", "Mars", "Rahu", "Ketu"):
        other_data = ch["planets"].get(other_planet, {})
        if other_data.get("sign") == moon_sign_name:
            key = f"with_{other_planet.lower()}"
            note = MENTAL_HEALTH_INDICATORS["moon_analysis"]["moon_afflictions"].get(key)
            if note:
                moon_afflictions.append(note)

    # Stress pattern by dominant dosha
    lagna = ch["lagna_sign"]
    prakriti = PRAKRITI_BY_LAGNA.get(lagna, {})
    primary_dosha = prakriti.get("primary", "vata")
    stress_pattern = MENTAL_HEALTH_INDICATORS["stress_patterns_by_dosha"].get(primary_dosha)

    return {
        "moon_sign":            moon_sign,
        "moon_house":           moon_house_num,
        "moon_sign_pattern":    moon_sign_pattern,
        "moon_afflictions_in_chart": moon_afflictions,
        "mercury_house":        mercury_data.get("house"),
        "mercury_dignity":      mercury_data.get("dignity"),
        "stress_pattern_by_dosha": {
            "primary_dosha":  primary_dosha,
            "pattern":        stress_pattern,
        },
        "general_rules":        MENTAL_HEALTH_INDICATORS,
        "classical_source":     "Charaka Sharirasthana Ch. 1 (Manas) + BPHS Ch. 30",
    }


# ════════════════════════════════════════════════════════════════════════
# 12. LONGEVITY
# ════════════════════════════════════════════════════════════════════════

def _longevity_assessment(ch: Dict) -> Dict:
    """Longevity factors from chart."""
    return {
        "factors_to_assess":      LONGEVITY_FACTORS["positive_factors"] + LONGEVITY_FACTORS["challenging_factors"],
        "classifications":        LONGEVITY_FACTORS["classification"],
        "positive_factors":       LONGEVITY_FACTORS["positive_factors"],
        "challenging_factors":    LONGEVITY_FACTORS["challenging_factors"],
        "preservation_practices": LONGEVITY_FACTORS["preservation_practices"],
        "ayurvedic_rasayana":     LONGEVITY_FACTORS["ayurvedic_rasayana"],
        "note":                   "Longevity assessment is complex and should be done by experienced Jyotishi. Engine provides factors; LLM downstream may synthesize.",
        "classical_source":       "Sarvartha Chintamani + BPHS Ch. 75-76",
    }


# ════════════════════════════════════════════════════════════════════════
# 13. HEALING WINDOWS
# ════════════════════════════════════════════════════════════════════════

def _healing_windows(ch: Dict) -> Dict:
    """Favorable timing for medical decisions."""
    return {
        "favorable_for_treatment":  HEALING_WINDOWS["favorable_for_treatment_start"],
        "avoid_for_major_procedures":HEALING_WINDOWS["avoid_for_major_procedures"],
        "specific_treatments":      HEALING_WINDOWS["specific_treatments"],
        "classical_source":         "Muhurta Chintamani + BPHS",
    }


# ════════════════════════════════════════════════════════════════════════
# 14. HEALTH REMEDIES
# ════════════════════════════════════════════════════════════════════════

def _health_remedies(ch: Dict) -> Dict:
    """Health-specific remedies from chart afflictions."""
    afflicted = afflicted_planets(ch)
    weakest = weakest_planet(ch)

    # Build remedies for each afflicted planet
    recs = []
    for ap in afflicted:
        planet = ap["planet"]
        organs = PLANET_DETAILED_ORGANS.get(planet, {})
        recs.append({
            "planet":          planet,
            "organs_at_risk":  organs.get("primary", []),
            "dosha_imbalance": organs.get("dosha"),
            "yoga":            YOGA_BY_PLANET.get(planet, []),
            "afflictions":     ap["afflictions"],
        })

    return {
        "weakest_planet":       weakest,
        "afflicted_remedies":   recs,
        "general_rasayanas":    LONGEVITY_FACTORS["ayurvedic_rasayana"],
        "general_preservation": LONGEVITY_FACTORS["preservation_practices"],
        "classical_source":     "Composite Vedic + Ayurvedic synthesis",
    }


# ════════════════════════════════════════════════════════════════════════
# PUBLIC ENDPOINT WRAPPERS
# ════════════════════════════════════════════════════════════════════════

def body_parts_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    return _body_parts_analysis(ch)


def illness_predisposition_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    return _illness_predisposition(ch)


def tridosha_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    return _tridosha_analysis(ch)


def prakriti_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    return _prakriti_determination(ch)


def vikriti_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    birth_dict = {"dob": dob, "time": time, "lat": lat, "lon": lon, "timezone": timezone}
    return _vikriti_current(ch, birth_dict)
def chakras_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    return _chakra_state(ch)


def healing_windows_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    return _healing_windows(ch)


def avoidance_windows_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    return {
        "avoid_for_major_procedures": HEALING_WINDOWS["avoid_for_major_procedures"],
        "classical_source":           "Muhurta Chintamani — inauspicious treatment windows",
    }


def diet_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    return _diet_recommendation(ch)


def yoga_pranayama_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    return _yoga_pranayama(ch)


def mental_health_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    return _mental_health_analysis(ch)


def longevity_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    return _longevity_assessment(ch)


def health_remedies_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    return _health_remedies(ch)
