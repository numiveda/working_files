"""
vastu_data.py — Static classical data for Astro Vastu module

Sources (all public domain, classical):
- Manasara Shilpa Shastra (~5th-7th century CE) — primary Vastu treatise
- Mayamatam (~9th-12th century CE) — South Indian Vastu canon
- Brihat Samhita by Varahamihira (~550 CE) — chapters 52-57 on Vastu
- Vishvakarma Prakash (~10th century CE) — practical construction
- Samarangana Sutradhara by Bhoja (~11th century CE)
- Vastu Purusha Mandala — cosmic body / sacred geometry tradition

Architecture:
- All data here is STATIC + CLASSICAL — no LLM-generated content
- Every constant cited to its classical source
- Output structure designed for downstream LLM interpretation
"""

# ════════════════════════════════════════════════════════════════════════
# 1. THE 8 + 1 DIRECTIONS (DISHA)
# Source: Brihat Samhita Ch. 52 — Vastu Vidya
# ════════════════════════════════════════════════════════════════════════

DIRECTIONS = {
    "north":       {"sanskrit": "उत्तर",   "iast": "Uttara",      "deity": "Kubera",     "planet": "Mercury", "element": "water",  "domain": "wealth, finance, career growth"},
    "northeast":   {"sanskrit": "ईशान्य", "iast": "Ishanya",     "deity": "Ishana/Shiva","planet": "Jupiter", "element": "water",  "domain": "spirituality, learning, divine connection — MOST sacred"},
    "east":        {"sanskrit": "पूर्व",    "iast": "Purva",       "deity": "Indra",      "planet": "Sun",     "element": "air",    "domain": "health, vitality, fame, social status"},
    "southeast":   {"sanskrit": "आग्नेय",  "iast": "Agneya",      "deity": "Agni",       "planet": "Venus",   "element": "fire",   "domain": "fire, kitchen, energy, transformation"},
    "south":       {"sanskrit": "दक्षिण",  "iast": "Dakshina",    "deity": "Yama",       "planet": "Mars",    "element": "earth",  "domain": "stability, ancestors, longevity, justice"},
    "southwest":   {"sanskrit": "नैऋत्य",  "iast": "Nairutya",    "deity": "Nirriti",    "planet": "Rahu",    "element": "earth",  "domain": "weight, stability — heaviest sector"},
    "west":        {"sanskrit": "पश्चिम", "iast": "Paschima",    "deity": "Varuna",     "planet": "Saturn",  "element": "water",  "domain": "prosperity, contentment, harvest, completion"},
    "northwest":   {"sanskrit": "वायव्य",  "iast": "Vayavya",     "deity": "Vayu",       "planet": "Moon",    "element": "air",    "domain": "movement, communication, guests, helpers"},
    "center":      {"sanskrit": "ब्रह्म",  "iast": "Brahmasthana","deity": "Brahma",     "planet": None,      "element": "ether",  "domain": "sacred center — MUST remain unobstructed"},
}


# ════════════════════════════════════════════════════════════════════════
# 2. VASTU PURUSHA MANDALA — 81 PADAS (9×9 GRID)
# Source: Manasara Shilpa Shastra Ch. 7-9
# Vastu Purusha lies face-down on the plot. Head at NE, feet at SW.
# 45 deities reside in the 81 padas — they regulate energy of each cell.
# ════════════════════════════════════════════════════════════════════════

# 81-pada layout (9x9 grid) — each cell holds a presiding deity
# Row 0 = North edge (top when facing the plot)
# Col 0 = East edge
# Standard Manasara arrangement:

VASTU_PURUSHA_MANDALA_81 = [
    # Row 0 (NE corner row — northernmost)
    ["Ishana",   "Parjanya", "Jayanta",  "Indra",    "Surya",    "Satya",    "Bhrisha",  "Antariksha","Anila"],
    # Row 1
    ["Diti",     "Aapa",     "Aapavatsa","Aryaman",  "Surya",    "Savita",   "Vivaswan", "Vibhudhadhipa","Pushan"],
    # Row 2
    ["Aditi",   "Mukhya",   "Bhallata", "Brahma",   "Brahma",   "Brahma",   "Mitra",    "Rudra",    "Rudradasa"],
    # Row 3
    ["Apa",     "Aapavatsa","Savitra",  "Brahma",   "Brahma",   "Brahma",   "Indra",    "Indrajaya","Sugriva"],
    # Row 4 (CENTER row — Brahmasthana most sacred)
    ["Jaya",    "Brahma",   "Brahma",   "Brahma",   "BRAHMA",   "Brahma",   "Brahma",   "Brahma",   "Dauvarika"],
    # Row 5
    ["Vitatha", "Mrigaraja","Bhringaraja","Brahma","Brahma",   "Brahma",   "Pitri",    "Mrisha",   "Bhallata"],
    # Row 6
    ["Pushpadanta","Varuna","Asura",    "Shesha",   "Papayakshma","Roga",   "Ahi",      "Mukhya",   "Bhallata"],
    # Row 7
    ["Sosha",   "Aapa",     "Aapavatsa","Daityas",  "Naga",     "Yama",     "Gandharva","Bhringaraja","Mriga"],
    # Row 8 (SW corner row — southernmost)
    ["Bhallata","Soma",     "Bhujanga", "Aditi",    "Diti",     "Indrajaya","Antariksha","Anila",   "Pitri"],
]

# Critical Marma Points — energy junctions; structural impact zones
# These are the bandhas (joints) of the Vastu Purusha — never penetrate with columns, walls, drains
MARMA_POINTS = {
    "brahmasthana":        {"location": "center 3x3",       "criticality": "absolute", "rule": "MUST remain open — no construction, no toilet, no kitchen, no staircase"},
    "ishana_corner":       {"location": "NE pada (1,1)",    "criticality": "high",     "rule": "Sacred — pooja room ideal here; no toilet, no kitchen, no septic tank"},
    "agni_corner":         {"location": "SE pada (1,7)",    "criticality": "high",     "rule": "Fire sector — kitchen, electrical, generators belong here"},
    "nairutya_corner":     {"location": "SW pada (7,1)",    "criticality": "high",     "rule": "Heaviest — master bedroom, storage; never light/airy"},
    "vayavya_corner":      {"location": "NW pada (7,7)",    "criticality": "medium",   "rule": "Movement sector — guest room, garage, washing area"},
    "north_marma":         {"location": "midpoint N edge",  "criticality": "medium",   "rule": "Avoid columns or heavy walls; entrance here is auspicious"},
    "east_marma":          {"location": "midpoint E edge",  "criticality": "medium",   "rule": "Most auspicious entrance — Indra's direction"},
    "south_marma":         {"location": "midpoint S edge",  "criticality": "low",      "rule": "Yama gate — avoid main entrance here"},
    "west_marma":          {"location": "midpoint W edge",  "criticality": "low",      "rule": "Varuna sector — water tanks, storage acceptable"},
}


# ════════════════════════════════════════════════════════════════════════
# 3. ROOM PLACEMENT MATRIX — 16 ROOMS × 8 DIRECTIONS
# Source: Mayamatam Ch. 9 + Manasara Ch. 35 + Vishvakarma Prakash
# Rating: 5 (ideal) → 4 (good) → 3 (acceptable) → 2 (poor) → 1 (avoid)
# ════════════════════════════════════════════════════════════════════════

ROOM_PLACEMENT = {
    "main_entrance": {
        "ideal":     ["north", "east", "northeast"],
        "good":      ["northwest"],
        "avoid":     ["southwest", "south"],
        "rule":      "Indra (E) and Kubera (N) bring wealth/fame. Yama (S) and Nirriti (SW) bring obstacles.",
        "source":    "Manasara Ch. 9, Brihat Samhita 52.94",
    },
    "pooja_room": {
        "ideal":     ["northeast"],
        "good":      ["east", "north"],
        "avoid":     ["south", "southwest", "under_staircase", "bedroom"],
        "rule":      "Ishana (NE) is the seat of Shiva — most sacred. Face deity to East/North while praying.",
        "source":    "Brihat Samhita 52.117, Manasara Ch. 51",
    },
    "kitchen": {
        "ideal":     ["southeast"],
        "good":      ["northwest"],
        "avoid":     ["northeast", "north", "center"],
        "rule":      "Agneya (SE) is Agni's sector. Cook facing east. Never cook facing south.",
        "source":    "Manasara Ch. 36, Mayamatam 9.42",
    },
    "master_bedroom": {
        "ideal":     ["southwest"],
        "good":      ["south", "west"],
        "avoid":     ["northeast", "southeast"],
        "rule":      "SW is heaviest, most stable — anchors the head of household. Head while sleeping: south or east.",
        "source":    "Manasara Ch. 33, Mayamatam 9.55",
    },
    "children_bedroom": {
        "ideal":     ["west", "northwest"],
        "good":      ["east", "north"],
        "avoid":     ["southwest"],
        "rule":      "Children need movement (Vayu/NW) and growth (East). SW is too anchoring for young energy.",
        "source":    "Manasara Ch. 34",
    },
    "guest_bedroom": {
        "ideal":     ["northwest"],
        "good":      ["west"],
        "avoid":     ["southwest", "northeast"],
        "rule":      "Vayavya (NW) ensures guests move on — auspicious turnover energy.",
        "source":    "Vishvakarma Prakash 7.12",
    },
    "study_room": {
        "ideal":     ["northeast", "north"],
        "good":      ["east"],
        "avoid":     ["south", "southwest"],
        "rule":      "Face east or north while studying — Indra (E) brings clarity, Kubera (N) brings wealth through knowledge.",
        "source":    "Brihat Samhita 52.119",
    },
    "office_workspace": {
        "ideal":     ["north", "east", "northeast"],
        "good":      ["west"],
        "avoid":     ["south"],
        "rule":      "Face north for wealth, east for fame. Desk in NE corner of office. Heavy furniture in SW.",
        "source":    "Mayamatam 9.61",
    },
    "toilet_bathroom": {
        "ideal":     ["west", "northwest", "south"],
        "good":      [],
        "avoid":     ["northeast", "center", "east", "southwest"],
        "rule":      "NEVER in NE, center, or east. NW is most acceptable. Toilet should face south or west.",
        "source":    "Manasara Ch. 37",
    },
    "septic_tank": {
        "ideal":     ["northwest"],
        "good":      ["west"],
        "avoid":     ["northeast", "north", "east", "southeast", "center"],
        "rule":      "Underground waste should never touch NE quadrant. NW preferred.",
        "source":    "Vishvakarma Prakash 8.4",
    },
    "water_tank_underground": {
        "ideal":     ["northeast", "north", "east"],
        "good":      [],
        "avoid":     ["southwest", "south", "southeast"],
        "rule":      "Water source belongs in N/E/NE — Varuna and Indra sectors. NEVER in SW.",
        "source":    "Brihat Samhita 53.78",
    },
    "water_tank_overhead": {
        "ideal":     ["southwest", "west"],
        "good":      ["south"],
        "avoid":     ["northeast"],
        "rule":      "Overhead water is heavy — belongs in SW. Opposite rule to underground tanks.",
        "source":    "Manasara Ch. 32",
    },
    "staircase": {
        "ideal":     ["south", "southwest", "west"],
        "good":      ["northwest"],
        "avoid":     ["northeast", "center", "east"],
        "rule":      "Staircases are heavy — anchor them to SW. Clockwise ascending direction.",
        "source":    "Manasara Ch. 31",
    },
    "dining_room": {
        "ideal":     ["west", "east"],
        "good":      ["north"],
        "avoid":     ["south", "southwest"],
        "rule":      "Diners should face east or north while eating. Adjacent to kitchen (SE).",
        "source":    "Mayamatam 9.68",
    },
    "drawing_living_room": {
        "ideal":     ["north", "east", "northeast"],
        "good":      ["northwest"],
        "avoid":     ["southwest"],
        "rule":      "Where guests are received — needs light, openness. NE/N/E ideal. Heavy seating arrangement on S/W walls.",
        "source":    "Vishvakarma Prakash 6.18",
    },
    "storage_heavy": {
        "ideal":     ["southwest", "south", "west"],
        "good":      [],
        "avoid":     ["northeast", "center"],
        "rule":      "Locker, safe, heavy storage — all SW. Heavy furniture against S/W walls.",
        "source":    "Manasara Ch. 30",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 4. VASTU DOSHAS — STRUCTURAL DEFECTS
# Source: Composite of all primary Vastu texts
# ════════════════════════════════════════════════════════════════════════

VASTU_DOSHAS = {
    "ishana_dosha": {
        "name":        "Ishana Dosha (NE Affliction)",
        "description": "Toilet, kitchen, septic, heavy storage, or staircase in NE corner.",
        "severity":    "very_high",
        "effects":     "Loss of wealth, lack of mental clarity, family health issues, spiritual stagnation",
        "remedies":    ["Place clean water bowl in NE", "Camphor lamp daily in NE", "Crystal pyramid", "Cover the affliction with white marble"],
        "source":      "Manasara Ch. 9, Brihat Samhita 52.117",
    },
    "agni_dosha": {
        "name":        "Agni Dosha (SE Affliction)",
        "description": "Toilet, water tank, or master bedroom in SE.",
        "severity":    "high",
        "effects":     "Anger issues, accidents from fire/electricity, fertility issues, financial losses",
        "remedies":    ["Red lamp in SE", "Mars yantra", "Avoid cooking facing south", "Diya lit at sunset"],
        "source":      "Manasara Ch. 36",
    },
    "yama_dosha": {
        "name":        "Yama Dosha (S Affliction)",
        "description": "Main entrance, bedroom of head, or pooja room in S quadrant.",
        "severity":    "medium",
        "effects":     "Conflict with father/authority, delays in life goals, ancestral karmic baggage",
        "remedies":    ["Mars yantra at south wall", "Red-colored heavy items in south", "Pitra pooja"],
        "source":      "Brihat Samhita 52.94",
    },
    "nairutya_dosha": {
        "name":        "Nairutya Dosha (SW Affliction)",
        "description": "Light/open SW; no anchoring weight in SW corner; entrance in SW.",
        "severity":    "very_high",
        "effects":     "Instability, loss of authority, family discord, financial collapse",
        "remedies":    ["Heavy item in SW (cupboard, safe)", "Master bedroom shifted to SW", "Saturn yantra"],
        "source":      "Manasara Ch. 33",
    },
    "varuna_dosha": {
        "name":        "Varuna Dosha (W Affliction)",
        "description": "Toilet or septic in west (acceptable but check positioning).",
        "severity":    "low",
        "effects":     "Minor health issues, slower progress",
        "remedies":    ["Saturn yantra", "Black/dark blue color in W", "Iron items in W"],
        "source":      "Vishvakarma Prakash 8.7",
    },
    "vayu_dosha": {
        "name":        "Vayu Dosha (NW Affliction)",
        "description": "Blocked NW (no door/window), heavy locked storage in NW.",
        "severity":    "medium",
        "effects":     "Lack of opportunities through people/network, guests/clients don't return, communication issues",
        "remedies":    ["Wind chime in NW", "Open windows in NW", "Moon yantra", "White/silver decor"],
        "source":      "Mayamatam 9.55",
    },
    "brahma_dosha": {
        "name":        "Brahma Dosha (Center Affliction)",
        "description": "Anything heavy at center — staircase, pillar, toilet, or heavy furniture in Brahmasthana.",
        "severity":    "very_high",
        "effects":     "Confusion in life direction, family infighting, head of household feels burdened, mental unrest",
        "remedies":    ["Keep center open and light", "Brass diya at center", "Yantra placement", "Open courtyard ideal"],
        "source":      "Manasara Ch. 7 — Vastu Purusha Brahmasthana",
    },
    "plot_shape_dosha": {
        "name":        "Plot Shape Dosha",
        "description": "Triangular, irregular, or NE-cut plots.",
        "severity":    "high",
        "effects":     "Continuous obstacles, financial instability, depending on which corner is cut",
        "remedies":    ["Boundary wall completing the shape", "Plant trees in the cut area", "Energy yantras at corners"],
        "source":      "Brihat Samhita 53.85",
    },
    "road_thrust_dosha": {
        "name":        "Vithi Shoola / Road Thrust",
        "description": "A road dead-ending into the plot (T-junction directly facing entrance).",
        "severity":    "high",
        "effects":     "Constant restlessness, financial drain, accidents, family disharmony — direction-dependent severity",
        "remedies":    ["Tall plant or pillar at thrust point", "Reflective surface", "Hanuman idol facing road"],
        "source":      "Vishvakarma Prakash 5.13",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 5. PLOT SHAPE EVALUATION
# Source: Brihat Samhita Ch. 53 + Manasara Ch. 8
# ════════════════════════════════════════════════════════════════════════

PLOT_SHAPES = {
    "square":           {"rating": "ideal",       "score": 100, "note": "Square (1:1) is most auspicious — perfect Brahmasthana"},
    "rectangle_NS":     {"rating": "good",        "score": 90,  "note": "Rectangle longer N-S — auspicious; called Surya plot"},
    "rectangle_EW":     {"rating": "good",        "score": 85,  "note": "Rectangle longer E-W — auspicious; called Chandra plot"},
    "rectangle_long":   {"rating": "acceptable",  "score": 65,  "note": "Length:width > 2:1 reduces Brahmasthana effectiveness"},
    "ne_extended":      {"rating": "excellent",   "score": 95,  "note": "NE extension — gain in spiritual & financial growth"},
    "ne_cut":           {"rating": "very_poor",   "score": 25,  "note": "NE cut — major loss of wealth, health, peace"},
    "se_extended":      {"rating": "poor",        "score": 40,  "note": "SE extension — fire risk, anger, accidents"},
    "sw_extended":      {"rating": "neutral",     "score": 55,  "note": "SW extension — acceptable; adds stability if matched with NE balance"},
    "sw_cut":           {"rating": "poor",        "score": 35,  "note": "SW cut — loss of authority, instability"},
    "nw_extended":      {"rating": "neutral",     "score": 60,  "note": "NW extension — favors movement-based professions"},
    "triangular":       {"rating": "very_poor",   "score": 15,  "note": "Triangular plot — strong dosha, recommend boundary squaring"},
    "circular":         {"rating": "poor",        "score": 30,  "note": "Round plot — for temples only, not residences"},
    "irregular":        {"rating": "poor",        "score": 30,  "note": "Irregular shape — energy disruption; remedy with boundary wall"},
    "gomukhi":          {"rating": "good",        "score": 80,  "note": "Cow-faced (narrow front, wider back) — auspicious for residences"},
    "vyagra_mukhi":     {"rating": "poor",        "score": 35,  "note": "Tiger-faced (wide front, narrow back) — good for shops only, not homes"},
}


# ════════════════════════════════════════════════════════════════════════
# 6. SLOPE ANALYSIS
# Source: Manasara Ch. 8
# ════════════════════════════════════════════════════════════════════════

SLOPE_ANALYSIS = {
    "north":      {"rating": "excellent", "score": 95, "effect": "Wealth flows in; financial prosperity"},
    "east":       {"rating": "excellent", "score": 95, "effect": "Health, vitality, social recognition"},
    "northeast":  {"rating": "excellent", "score": 100,"effect": "Maximum auspicious — wealth + spirituality"},
    "northwest":  {"rating": "neutral",   "score": 55, "effect": "Acceptable; favors travel-based careers"},
    "west":       {"rating": "poor",      "score": 35, "effect": "Stagnation; energy drains slowly"},
    "south":      {"rating": "very_poor", "score": 15, "effect": "Severe — health and wealth both leak south"},
    "southwest":  {"rating": "very_poor", "score": 10, "effect": "Worst — instability, loss of authority"},
    "southeast":  {"rating": "poor",      "score": 25, "effect": "Fire/accident risk, anger issues"},
}


# ════════════════════════════════════════════════════════════════════════
# 7. ROAD FRONTAGE / ENTRANCE DIRECTION
# Source: Mayamatam 9 + Brihat Samhita 53
# ════════════════════════════════════════════════════════════════════════

ROAD_FRONTAGE = {
    "north":      {"rating": "excellent",  "score": 95, "effect": "Wealth, fame — Kubera"},
    "east":       {"rating": "excellent",  "score": 95, "effect": "Health, vitality — Indra"},
    "northeast":  {"rating": "good",       "score": 80, "effect": "Spiritual + wealth (if entrance correctly placed)"},
    "northwest":  {"rating": "neutral",    "score": 60, "effect": "Movement, networking"},
    "west":       {"rating": "acceptable", "score": 65, "effect": "Stable growth; favors trade"},
    "south":      {"rating": "poor",       "score": 35, "effect": "Difficult — requires remedies"},
    "southwest":  {"rating": "very_poor",  "score": 15, "effect": "Strongly inauspicious; avoid"},
    "southeast":  {"rating": "poor",       "score": 30, "effect": "Fire risk; for industrial use only"},
    "two_roads":  {"rating": "depends",    "score": 70, "effect": "N+E roads = best. S+W = avoid."},
    "four_roads": {"rating": "very_good",  "score": 90, "effect": "Corner plot — auspicious if N+E corner"},
}


# ════════════════════════════════════════════════════════════════════════
# 8. CONSTRUCTION MUHURTA — AUSPICIOUS TIMING
# Source: Brihat Samhita Ch. 56-57 + Muhurta Chintamani
# ════════════════════════════════════════════════════════════════════════

CONSTRUCTION_MUHURTA = {
    "favorable_months": {
        "magha":     "Jan-Feb — wealth gain",
        "phalguna":  "Feb-Mar — health, longevity",
        "vaishakha": "Apr-May — most auspicious; gains in all areas",
        "shravana":  "Jul-Aug — spiritual growth, peace",
        "kartika":   "Oct-Nov — prosperity, vehicle gains",
        "margashirsha":"Nov-Dec — comfort, family harmony",
    },
    "unfavorable_months": ["chaitra", "ashadha", "bhadrapada", "ashvina", "pausha"],
    "favorable_nakshatras": [
        "Rohini", "Mrigashira", "Pushya", "Magha", "Uttara Phalguni",
        "Hasta", "Chitra", "Anuradha", "Uttara Ashadha", "Uttara Bhadrapada", "Revati",
    ],
    "favorable_weekdays":  ["Monday", "Wednesday", "Thursday", "Friday"],
    "unfavorable_weekdays":["Tuesday", "Saturday", "Sunday (mixed)"],
    "favorable_tithis":    ["Dwitiya", "Tritiya", "Panchami", "Saptami", "Dashami", "Ekadashi", "Trayodashi"],
    "unfavorable_tithis":  ["Chaturthi", "Navami", "Chaturdashi", "Amavasya"],
    "key_ceremonies": {
        "bhumi_pujan":     "Ground-breaking ceremony — first foundation stone, NE corner",
        "shilanyas":       "Foundation stone laying — most critical muhurta",
        "vastu_shanti":    "Pre-occupation purification ritual",
        "griha_pravesh":   "House-warming entry ceremony",
    },
    "source":              "Brihat Samhita 56 + Muhurta Chintamani Ch. 8",
}


# ════════════════════════════════════════════════════════════════════════
# 9. BUSINESS VASTU — COMMERCIAL ADAPTATIONS
# Source: Vishvakarma Prakash + modern commercial Vastu codification
# ════════════════════════════════════════════════════════════════════════

BUSINESS_VASTU = {
    "shop_retail": {
        "owner_seat":    "northeast or north (facing east/north)",
        "cash_counter":  "northeast quadrant; cash drawer opens north or east",
        "main_door":     "north, east, or northeast",
        "storage":       "south or west walls",
        "deity_corner":  "northeast",
        "avoid":         "owner facing south, cash counter in SW, entrance in SW",
        "source":        "Modern Vastu (codified from Vishvakarma Prakash 6.20)",
    },
    "office_corporate": {
        "ceo_cabin":     "southwest corner",
        "ceo_facing":    "north or east",
        "boardroom":     "northwest",
        "reception":     "northeast",
        "accounts":      "north",
        "kitchen_pantry":"southeast",
        "server_room":   "southeast (electrical/fire)",
        "toilets":       "west or northwest",
        "source":        "Vishvakarma Prakash 6.18 + practical synthesis",
    },
    "warehouse_factory": {
        "heavy_machinery":"southwest, south",
        "raw_materials": "west",
        "finished_goods":"northwest (to facilitate movement out)",
        "office":        "northeast",
        "owner_seat":    "south or southwest",
        "main_gate":     "east or north",
        "source":        "Manasara Ch. 30 + industrial adaptation",
    },
    "restaurant_hospitality": {
        "kitchen":       "southeast (Agni)",
        "owner_cash":    "northeast",
        "dining_layout": "guests face east or north while eating",
        "entrance":      "north or east",
        "restrooms":     "northwest or west",
        "source":        "Mayamatam 9 + hospitality codification",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 10. CLASSICAL REMEDIES CATALOG
# Source: Composite of all primary Vastu texts
# ════════════════════════════════════════════════════════════════════════

VASTU_REMEDIES = {
    "yantras": {
        "vastu_dosha_nivaran_yantra": "Master remedy for all Vastu doshas; place at center",
        "kuber_yantra":                "Wealth/finance; place in north",
        "mahalakshmi_yantra":          "Prosperity; place in NE pooja room",
        "ganesh_yantra":               "Obstacle removal; main entrance",
        "navagraha_yantra":            "Planetary balance; pooja room",
        "shri_yantra":                 "Universal harmony; NE",
    },
    "metals_and_materials": {
        "copper_plate_with_mantra":    "Bury at construction site or place at center",
        "pyramid_brass":               "Activate Brahmasthana energy",
        "salt_bowl_corner":            "Rock salt absorbs negative energy; replace monthly",
        "camphor_lamp_NE_daily":       "Maintains NE sanctity",
    },
    "plants_and_organics": {
        "tulsi_NE":                    "Sacred basil in NE — wealth, health, spiritual",
        "bamboo_E":                    "Growth, opportunities",
        "ashok_tree_boundary":         "Grief reduction, harmony",
        "avoid_indoor_thorny":         "Cactus, bonsai (restricted), no thorny plants inside",
    },
    "colors_by_direction": {
        "north":      "blue, green, black accents — Mercury/Kubera",
        "northeast":  "white, light yellow, sky blue — Jupiter/Ishana",
        "east":       "white, light blue, soft green — Sun/Indra",
        "southeast":  "red, orange, pink — Venus/Agni",
        "south":      "red, pink, coral — Mars/Yama",
        "southwest":  "brown, beige, deep yellow — Rahu/Nirriti (anchoring)",
        "west":       "white, blue, gray — Saturn/Varuna",
        "northwest":  "white, silver, light gray — Moon/Vayu",
    },
    "mantras_and_pujas": {
        "vastu_purusha_mantra":        "Om Vastu Purushaaya Namaha — invocation",
        "ganesh_atharvashirsha":       "Daily — obstacle clearing",
        "navagraha_homa":              "Annual — planetary affliction balance",
        "rudra_abhishek":              "Specific Shiva worship — for major doshas",
        "vastu_shanti":                "Full Vastu ritual — for new homes / post-rectification",
    },
    "behavioral": {
        "feed_birds_morning":          "Crows fed in SW; pigeons fed in NW",
        "feed_first_chapati_to_cow":   "Daily food offering — prosperity",
        "lamp_at_main_door_dusk":      "Lakshmi welcoming",
        "no_shoes_in_pooja":           "Energy preservation",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 11. CHART-VASTU LINKING RULES
# Source: Synthesis of Vastu Shastra + Jyotish — practitioner tradition
# ════════════════════════════════════════════════════════════════════════
# Maps the native's Vedic chart to personalized Vastu emphasis.
# - Strong Sun → reinforce east entrance / fire sector
# - Strong Moon → reinforce NW / water elements
# - Saturn afflicted → strengthen W/SW remedies
# - Atmakaraka's house lord direction → primary focus zone
# - Current Dasha lord's direction → year's Vastu emphasis

PLANET_TO_DIRECTION = {
    "Sun":     "east",
    "Moon":    "northwest",
    "Mars":    "south",
    "Mercury": "north",
    "Jupiter": "northeast",
    "Venus":   "southeast",
    "Saturn":  "west",
    "Rahu":    "southwest",
    "Ketu":    "southwest",
}

PLANET_TO_DEITY = {
    "Sun":     "Indra",
    "Moon":    "Vayu",
    "Mars":    "Yama",
    "Mercury": "Kubera",
    "Jupiter": "Ishana",
    "Venus":   "Agni",
    "Saturn":  "Varuna",
    "Rahu":    "Nirriti",
    "Ketu":    "Nirriti",
}

HOUSE_TO_LIFE_AREA = {
    1:  "self, body, identity, vitality",
    2:  "wealth, family, speech, food",
    3:  "siblings, courage, communication",
    4:  "home, mother, vehicles, comfort",
    5:  "children, intelligence, creativity",
    6:  "enemies, disease, debts, service",
    7:  "spouse, partnerships, business",
    8:  "longevity, hidden things, transformation",
    9:  "father, fortune, dharma, higher learning",
    10: "career, fame, status",
    11: "gains, income, social network",
    12: "expenses, foreign, liberation",
}
