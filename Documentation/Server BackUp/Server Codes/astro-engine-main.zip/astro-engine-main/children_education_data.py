"""
children_education_data.py — Children + Education classical reference.

Phase C — Module C5.

Public catalogs:
    PUTRA_KARAKAS              — Children karakas (Jupiter primarily)
    FIFTH_HOUSE_INDICATORS     — What 5th house represents
    PUTRA_DOSHA_RULES          — Classical Putra Dosha detection patterns
    PUTRA_DOSHA_REMEDIES       — Remedies per dosha pattern
    EDUCATION_PLANETS          — Mercury/Jupiter/Sun karakas
    EDUCATION_HOUSES           — 2/4/5/9 house roles in education
    FOREIGN_STUDY_PATTERNS     — Classical foreign-education yogas
    D7_SAPTAMSHA_NOTES         — D7 chart interpretation principles
    CLASSICAL_CITATIONS

Sources: BPHS Ch. 28 (Putra Bhava), Saravali Ch. 35, Phaladeepika Ch. 9,
         Sarvartha Chintamani Ch. 14, Jataka Parijata.
All public domain.
"""

from typing import Dict, List


# ════════════════════════════════════════════════════════════════════════
# CHILDREN — Putra Bhava (5th House) classical analysis
# ════════════════════════════════════════════════════════════════════════

PUTRA_KARAKAS: Dict[str, str] = {
    "Jupiter": "Primary karaka for children (Putra Karaka)",
    "Sun":     "Karaka for sons (Putra-Sthana lord influence)",
    "Moon":    "Karaka for emotional bond with children, nurture",
}


FIFTH_HOUSE_INDICATORS: Dict[str, str] = {
    "primary":   "Children, progeny",
    "secondary": "Intelligence (Buddhi), creativity, romance, past-life merit (Purva Punya)",
    "lord_role": "5th lord's placement and strength determine children's well-being",
    "key_factor":"5th house occupancy by benefics OR malefics is most direct indicator",
}


# Putra Dosha detection patterns (5th house afflictions)
PUTRA_DOSHA_RULES: Dict[str, Dict[str, str]] = {
    "malefic_in_5th": {
        "rule":        "Mars, Saturn, Rahu, or Ketu in 5th house without benefic aspect",
        "effect":      "Delays in conception, possible loss of progeny, child-related stress",
        "severity":    "moderate",
    },
    "5th_lord_in_dushthana": {
        "rule":        "5th house lord placed in 6th, 8th, or 12th house",
        "effect":      "Distance from children, health concerns for offspring, karmic obstacles",
        "severity":    "moderate",
    },
    "5th_lord_combust_or_debilitated": {
        "rule":        "5th house lord combust by Sun or debilitated",
        "effect":      "Weakened progeny indication; children may be few or face challenges",
        "severity":    "moderate",
    },
    "jupiter_afflicted": {
        "rule":        "Jupiter (Putra Karaka) in 6/8/12, combust, debilitated, or with malefics without aspect of benefic",
        "effect":      "Primary karaka weakened — overall fertility/progeny support compromised",
        "severity":    "high",
    },
    "5th_aspected_by_malefic_only": {
        "rule":        "5th house has only malefic aspects, no benefic aspect",
        "effect":      "Lack of benevolent influence on progeny matters",
        "severity":    "mild",
    },
    "rahu_or_ketu_in_5th": {
        "rule":        "Specifically Rahu or Ketu in 5th house",
        "effect":      "Past-life karmic patterns playing out through children; possible adoption indications",
        "severity":    "moderate",
    },
    "saturn_aspects_5th_from_difficult_house": {
        "rule":        "Saturn aspecting 5th from 7th, 10th, or 3rd house and is debilitated/enemy",
        "effect":      "Delays in conception; mature parenthood",
        "severity":    "mild",
    },
}


PUTRA_DOSHA_REMEDIES: Dict[str, str] = {
    "primary":     "Santan Gopal Mantra (108 daily) — primary children-blessing mantra",
    "jupiter_strengthen": "Jupiter strengthening: Brihaspati mantra Thursdays, donate yellow items, wear yellow on Thursdays",
    "santana_lakshmi": "Santana Lakshmi Stotra / Putra-Da Lakshmi Vrata for women seeking progeny",
    "putra_kameshti": "Putrakameshti Yajna (classical fire ceremony) — major remedy for serious cases",
    "5th_lord_specific": "Strengthen 5th house lord via classical mantra/donation per chart",
    "rahu_ketu":   "If Rahu/Ketu in 5th: Sarpa Dosha Nivaran (snake-related karmic remedies), feed silver vessels milk",
    "general":     "Donate to schools/children, sponsor child education, support orphanages",
}


# ════════════════════════════════════════════════════════════════════════
# D7 SAPTAMSHA — Children-specific divisional chart
# ════════════════════════════════════════════════════════════════════════

D7_SAPTAMSHA_NOTES: Dict[str, str] = {
    "purpose":      "D7 chart is read for children's nature, gender tendencies, number, and timing",
    "lagna":        "D7 Lagna determines overall children indication",
    "5th_in_d7":    "5th house of D7 = children specifically; planets there reveal nature of children",
    "jupiter_d7":   "Jupiter's placement in D7 is most critical for first child timing and disposition",
    "saturn_d7":    "Saturn afflicting D7 5th = delays in children",
    "ascending_signs":"Male-dominant signs (Aries, Gemini, Leo, Libra, Sagittarius, Aquarius) and female-dominant signs (others) used in D7 — engine returns sign-types only, never gender predictions",
}


# Conception timing dasha indicators
CONCEPTION_TIMING_PLANETS: List[str] = [
    "5th house lord",
    "Jupiter (always favorable)",
    "Moon (especially waxing)",
    "Venus (for first child timing per some texts)",
    "Lord of D7 Lagna",
    "Planets in 5th house (transit and dasha)",
]


# ════════════════════════════════════════════════════════════════════════
# EDUCATION — 2nd + 4th + 5th + 9th house synthesis
# ════════════════════════════════════════════════════════════════════════

EDUCATION_PLANETS: Dict[str, str] = {
    "Mercury": "Primary karaka for learning (Vidya Karaka); intellect, communication, structured knowledge",
    "Jupiter": "Higher learning, wisdom, scriptures, philosophy, doctorates",
    "Sun":     "Authority/recognition in education; government scholarships",
    "Moon":    "Receptivity to learning, memory, emotional engagement with study",
    "Venus":   "Arts education, aesthetics, design, music, dance",
    "Saturn":  "Discipline in study, research, deep specialization (often delayed but profound)",
    "Mars":    "Engineering, surgery, military training, technical sharp-focus",
}


EDUCATION_HOUSES: Dict[int, str] = {
    2:  "Primary education, speech-related skills, family-supported learning",
    4:  "Foundational education, schooling, mother's role in education, vehicles for commute",
    5:  "Intelligence, exam success, higher creative learning, mantra-vidya",
    9:  "Higher education (Vidya Bhava in BPHS), philosophical study, foreign higher learning, guru-shishya tradition",
    11: "Gains from education, social network via education",
    12: "Foreign education, isolation-required study, research in seclusion",
}


# Foreign study classical yogas
FOREIGN_STUDY_PATTERNS: Dict[str, Dict[str, str]] = {
    "rahu_4th_or_9th": {
        "pattern":   "Rahu in 4th house OR 9th house",
        "indication":"Foreign land/foreigner element in education; cross-cultural learning",
        "strength":  "strong",
    },
    "4th_lord_in_12th": {
        "pattern":   "4th house lord placed in 12th house (foreign/expense house)",
        "indication":"Foreign-located primary/secondary education",
        "strength":  "strong",
    },
    "9th_lord_in_12th_or_with_rahu": {
        "pattern":   "9th house lord in 12th house OR conjunct/aspected by Rahu",
        "indication":"Foreign higher education (most powerful foreign-study yoga)",
        "strength":  "very_strong",
    },
    "moon_jupiter_4th_or_9th": {
        "pattern":   "Moon and Jupiter together in 4th or 9th house",
        "indication":"Strong foreign-education yoga (luck + intellect aligned)",
        "strength":  "strong",
    },
    "12th_lord_strong_in_kendra": {
        "pattern":   "12th lord well-placed in a kendra (1st, 4th, 7th, 10th)",
        "indication":"Foreign opportunities including education",
        "strength":  "moderate",
    },
    "mercury_or_jupiter_in_12th": {
        "pattern":   "Mercury or Jupiter in 12th house with dignity",
        "indication":"Foreign learning/teaching opportunities",
        "strength":  "moderate",
    },
}


# Education success indicators (general)
EDUCATION_SUCCESS_INDICATORS: List[str] = [
    "Mercury in own/exalted/friendly sign",
    "Jupiter aspecting 5th house",
    "5th lord well-placed (kendra/trikona)",
    "4th house with benefics (Mercury/Jupiter/Venus)",
    "9th house and lord strong (for higher education)",
    "Saraswati Yoga: Mercury + Jupiter + Venus in kendras",
    "Budhaditya Yoga: Sun + Mercury conjunction (intellectual recognition)",
]


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "putra_bhava":     "BPHS Ch. 28 (Putra Bhava); Saravali Ch. 35; Phaladeepika Ch. 9",
    "putra_dosha":     "BPHS Ch. 28; Jataka Parijata Ch. 12-13 (Putra Khanda)",
    "santan_remedies": "Garuda Purana on Santana Gopal; traditional Putrakameshti Yajna",
    "d7_saptamsha":    "BPHS Ch. 8 (Vargas); Phaladeepika Ch. 4 — D7 for children",
    "education":       "BPHS Ch. 28 (Vidya Bhava); Sarvartha Chintamani Ch. 14 (Vidya)",
    "foreign_study":   "BPHS Ch. 24 (Vyaya/12th); classical foreign-yoga literature",
    "saraswati_yoga":  "Phaladeepika Ch. 6 (yoga combinations); BPHS",
}
