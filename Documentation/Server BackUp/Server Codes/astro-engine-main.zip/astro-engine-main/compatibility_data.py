"""
compatibility_data.py — Classical Vedic marriage matching reference tables.

Phase C — Module C1 (Compatibility / Synastry).

Public catalogs:
    NAKSHATRA_ORDER             — 27 nakshatras in classical order
    NAKSHATRA_TO_VARNA          — Varna (caste) for each nakshatra
    NAKSHATRA_TO_VASHYA         — Vashya (control) class per nakshatra
    NAKSHATRA_TO_YONI           — Yoni (animal) of each nakshatra
    NAKSHATRA_TO_GANA           — Deva / Manushya / Rakshasa gana
    NAKSHATRA_TO_NADI           — Adi / Madhya / Antya nadi
    YONI_COMPATIBILITY          — Yoni-pair score (4 max)
    YONI_NATURAL_ENEMY          — Pairs that lose extra points
    GRAHA_MAITRI_RULES          — Friendship-based Moon-lord scoring
    GANA_MATCH_SCORES           — Gana cross-table
    BHAKOOT_DOSHA_DISTANCES     — Moon-sign distances that cause Bhakoot dosha
    NADI_DOSHA_CANCELLATIONS    — Classical Nadi dosha cancellation rules
    MANGLIK_HOUSES              — Houses where Mars = Manglik
    MANGLIK_CANCELLATIONS       — Classical Manglik cancellation rules
    ASHTAKOOT_WEIGHTS           — Max points per Kuta (totals 36)
    SEVENTH_HOUSE_KARAKAS       — Marriage indicators
    LONGEVITY_BUCKETS           — 8-house longevity comparison brackets
    CLASSICAL_CITATIONS         — Source attributions per technique

All content from public-domain Sanskrit classical texts.
Primary: BPHS Ch. 44 (Vivaha), Phaladeepika Ch. 7, Saravali Ch. 27-28,
         Hora Sara on Manglik, Muhurta Chintamani (marriage muhurta),
         Jataka Parijata Ch. 14, traditional Ashtakoot literature.
"""

from typing import Dict, List, Tuple

# ════════════════════════════════════════════════════════════════════════
# NAKSHATRA ORDER — 27 nakshatras, classical sequence
# ════════════════════════════════════════════════════════════════════════

NAKSHATRA_ORDER: List[str] = [
    "Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashira", "Ardra",
    "Punarvasu", "Pushya", "Ashlesha", "Magha", "Purva Phalguni", "Uttara Phalguni",
    "Hasta", "Chitra", "Swati", "Vishakha", "Anuradha", "Jyeshtha",
    "Mula", "Purva Ashadha", "Uttara Ashadha", "Shravana", "Dhanishta", "Shatabhisha",
    "Purva Bhadrapada", "Uttara Bhadrapada", "Revati",
]


# ════════════════════════════════════════════════════════════════════════
# KUTA #1 — VARNA KUTA (max 1 point)
# Caste-equivalence test: spiritual evolution level
# Source: Brihat Samhita commentary, traditional Ashtakoot
# ════════════════════════════════════════════════════════════════════════
# Varna order (high → low): Brahmin (4) > Kshatriya (3) > Vaishya (2) > Shudra (1)

NAKSHATRA_TO_VARNA: Dict[str, str] = {
    # Brahmin
    "Punarvasu": "Brahmin", "Pushya": "Brahmin", "Vishakha": "Brahmin",
    "Purva Bhadrapada": "Brahmin", "Uttara Bhadrapada": "Brahmin",
    "Purva Phalguni": "Brahmin", "Uttara Phalguni": "Brahmin",
    # Kshatriya
    "Ashwini": "Kshatriya", "Rohini": "Kshatriya", "Mrigashira": "Kshatriya",
    "Pushya": "Kshatriya",  # overlap allowed; some texts vary
    "Hasta": "Kshatriya", "Anuradha": "Kshatriya",
    "Uttara Ashadha": "Kshatriya", "Shravana": "Kshatriya",
    # Vaishya
    "Krittika": "Vaishya", "Magha": "Vaishya", "Mula": "Vaishya",
    "Purva Ashadha": "Vaishya", "Bharani": "Vaishya",
    # Shudra
    "Ardra": "Shudra", "Ashlesha": "Shudra", "Swati": "Shudra",
    "Chitra": "Shudra", "Dhanishta": "Shudra", "Shatabhisha": "Shudra",
    "Jyeshtha": "Shudra", "Revati": "Shudra",
}

VARNA_LEVEL: Dict[str, int] = {
    "Brahmin": 4, "Kshatriya": 3, "Vaishya": 2, "Shudra": 1,
}


# ════════════════════════════════════════════════════════════════════════
# KUTA #2 — VASHYA KUTA (max 2 points)
# Mutual attraction / control category
# 5 vashya classes: Chatushpada, Manava, Jalachara, Vanachara, Keeta
# ════════════════════════════════════════════════════════════════════════

NAKSHATRA_TO_VASHYA: Dict[str, str] = {
    "Ashwini": "Chatushpada",   "Bharani": "Manava",        "Krittika": "Manava",
    "Rohini": "Chatushpada",    "Mrigashira": "Manava",     "Ardra": "Manava",
    "Punarvasu": "Manava",      "Pushya": "Manava",         "Ashlesha": "Keeta",
    "Magha": "Vanachara",       "Purva Phalguni": "Vanachara","Uttara Phalguni": "Manava",
    "Hasta": "Manava",          "Chitra": "Keeta",          "Swati": "Manava",
    "Vishakha": "Manava",       "Anuradha": "Manava",       "Jyeshtha": "Manava",
    "Mula": "Vanachara",        "Purva Ashadha": "Manava",  "Uttara Ashadha": "Manava",
    "Shravana": "Chatushpada",  "Dhanishta": "Jalachara",   "Shatabhisha": "Manava",
    "Purva Bhadrapada": "Manava","Uttara Bhadrapada": "Manava","Revati": "Jalachara",
}

# Vashya compatibility matrix — (person1_vashya, person2_vashya) → points (0-2)
VASHYA_COMPATIBILITY: Dict[Tuple[str, str], float] = {
    ("Manava", "Manava"): 2.0,
    ("Chatushpada", "Chatushpada"): 2.0,
    ("Jalachara", "Jalachara"): 2.0,
    ("Vanachara", "Vanachara"): 2.0,
    ("Keeta", "Keeta"): 2.0,
    ("Manava", "Chatushpada"): 1.0, ("Chatushpada", "Manava"): 1.0,
    ("Manava", "Jalachara"): 1.0, ("Jalachara", "Manava"): 1.0,
    ("Manava", "Vanachara"): 0.5, ("Vanachara", "Manava"): 0.5,
    ("Manava", "Keeta"): 0.5, ("Keeta", "Manava"): 0.5,
    ("Chatushpada", "Jalachara"): 1.0, ("Jalachara", "Chatushpada"): 1.0,
    ("Chatushpada", "Vanachara"): 0.0, ("Vanachara", "Chatushpada"): 0.0,
    ("Jalachara", "Vanachara"): 0.5, ("Vanachara", "Jalachara"): 0.5,
    ("Jalachara", "Keeta"): 0.0, ("Keeta", "Jalachara"): 0.0,
    ("Vanachara", "Keeta"): 0.5, ("Keeta", "Vanachara"): 0.5,
    ("Chatushpada", "Keeta"): 0.0, ("Keeta", "Chatushpada"): 0.0,
}


# ════════════════════════════════════════════════════════════════════════
# KUTA #3 — TARA KUTA (max 3 points)
# Birth-star compatibility based on nakshatra-count distance
# Distance counted from one's nakshatra to the other's, divided by 9
# Remainder determines tara: 1=Janma, 2=Sampat, 3=Vipat, 4=Kshema, 5=Pratyari,
# 6=Sadhaka, 7=Vadha, 8=Mitra, 9=Ati-Mitra
# Good remainders: 2,4,6,8,9 (full points each direction);
# Bad: 3, 5, 7 (zero points that direction)
# ════════════════════════════════════════════════════════════════════════

TARA_GOOD_REMAINDERS: List[int] = [2, 4, 6, 8, 9, 0]  # 0 == 9 in modulo
TARA_BAD_REMAINDERS: List[int] = [3, 5, 7]
TARA_NEUTRAL_REMAINDERS: List[int] = [1]  # Janma — 0 (or sometimes counted favorably depending on text)


# ════════════════════════════════════════════════════════════════════════
# KUTA #4 — YONI KUTA (max 4 points)
# 14 animal yonis classified for sexual / energetic compatibility
# ════════════════════════════════════════════════════════════════════════

NAKSHATRA_TO_YONI: Dict[str, Tuple[str, str]] = {
    # (yoni_animal, gender) — gender used for natural enmity check
    "Ashwini":            ("Horse", "M"),
    "Bharani":            ("Elephant", "M"),
    "Krittika":           ("Sheep", "F"),
    "Rohini":             ("Serpent", "M"),
    "Mrigashira":         ("Serpent", "F"),
    "Ardra":              ("Dog", "F"),
    "Punarvasu":          ("Cat", "F"),
    "Pushya":             ("Sheep", "M"),
    "Ashlesha":           ("Cat", "M"),
    "Magha":              ("Rat", "M"),
    "Purva Phalguni":     ("Rat", "F"),
    "Uttara Phalguni":    ("Cow", "F"),
    "Hasta":              ("Buffalo", "F"),
    "Chitra":             ("Tiger", "F"),
    "Swati":              ("Buffalo", "M"),
    "Vishakha":           ("Tiger", "M"),
    "Anuradha":           ("Deer", "F"),
    "Jyeshtha":           ("Deer", "M"),
    "Mula":               ("Dog", "M"),
    "Purva Ashadha":      ("Monkey", "M"),
    "Uttara Ashadha":     ("Mongoose", "F"),
    "Shravana":           ("Monkey", "F"),
    "Dhanishta":          ("Lion", "F"),
    "Shatabhisha":        ("Horse", "F"),
    "Purva Bhadrapada":   ("Lion", "M"),
    "Uttara Bhadrapada":  ("Cow", "M"),
    "Revati":             ("Elephant", "F"),
}

# Yoni compatibility (classical Hora Sara / BPHS table). 4=same, 0=enemy.
# Note: same yoni same gender = 3 (avoid same-sex twins), same yoni opp gender = 4
YONI_SAME_SCORE: int = 4
YONI_FRIENDLY: List[Tuple[str, str]] = [
    ("Horse", "Buffalo"), ("Elephant", "Sheep"), ("Cow", "Tiger"),
    ("Serpent", "Mongoose"), ("Dog", "Deer"), ("Cat", "Rat"),
    ("Lion", "Monkey"),
]
YONI_NEUTRAL_PAIRS: List[Tuple[str, str]] = [
    ("Horse", "Elephant"), ("Sheep", "Cow"), ("Tiger", "Deer"),
    ("Buffalo", "Cow"), ("Monkey", "Sheep"), ("Cat", "Dog"),
    ("Mongoose", "Rat"),
]
# Natural enemy pairs — lose to 0
YONI_ENEMIES: List[Tuple[str, str]] = [
    ("Cat", "Rat"),    # but Cat-Rat are also listed friendly above in some texts — use enemy as canonical
    ("Dog", "Deer"),
    ("Cow", "Tiger"),
    ("Horse", "Buffalo"),
    ("Sheep", "Monkey"),
    ("Serpent", "Mongoose"),
    ("Elephant", "Lion"),
]


# ════════════════════════════════════════════════════════════════════════
# KUTA #5 — GRAHA MAITRI KUTA (max 5 points)
# Friendship between Moon-sign LORDS
# ════════════════════════════════════════════════════════════════════════

# Classical planetary friendship (Naisargika Maitri) per BPHS Ch. 3
PLANET_FRIENDSHIP: Dict[str, Dict[str, str]] = {
    "Sun":     {"friends": ["Moon", "Mars", "Jupiter"], "neutral": ["Mercury"],
                "enemies": ["Venus", "Saturn"]},
    "Moon":    {"friends": ["Sun", "Mercury"], "neutral": ["Mars", "Jupiter", "Venus", "Saturn"],
                "enemies": []},
    "Mars":    {"friends": ["Sun", "Moon", "Jupiter"], "neutral": ["Venus", "Saturn"],
                "enemies": ["Mercury"]},
    "Mercury": {"friends": ["Sun", "Venus"], "neutral": ["Mars", "Jupiter", "Saturn"],
                "enemies": ["Moon"]},
    "Jupiter": {"friends": ["Sun", "Moon", "Mars"], "neutral": ["Saturn"],
                "enemies": ["Mercury", "Venus"]},
    "Venus":   {"friends": ["Mercury", "Saturn"], "neutral": ["Mars", "Jupiter"],
                "enemies": ["Sun", "Moon"]},
    "Saturn":  {"friends": ["Mercury", "Venus"], "neutral": ["Jupiter"],
                "enemies": ["Sun", "Moon", "Mars"]},
}

# Graha Maitri Kuta scoring: bidirectional check
# Both friends = 5, one friend other neutral = 4, both neutral = 3,
# one neutral one enemy = 1, both enemies = 0, one enemy = depends
GRAHA_MAITRI_SCORE: Dict[Tuple[str, str], int] = {
    ("friend", "friend"):  5,
    ("friend", "neutral"): 4, ("neutral", "friend"): 4,
    ("neutral", "neutral"):3,
    ("friend", "enemy"):   1, ("enemy", "friend"):   1,
    ("neutral", "enemy"):  1, ("enemy", "neutral"):  1,
    ("enemy", "enemy"):    0,
}


# ════════════════════════════════════════════════════════════════════════
# KUTA #6 — GANA KUTA (max 6 points)
# Temperament: Deva (divine), Manushya (human), Rakshasa (demonic)
# ════════════════════════════════════════════════════════════════════════

NAKSHATRA_TO_GANA: Dict[str, str] = {
    "Ashwini": "Deva",          "Bharani": "Manushya",     "Krittika": "Rakshasa",
    "Rohini": "Manushya",       "Mrigashira": "Deva",      "Ardra": "Manushya",
    "Punarvasu": "Deva",        "Pushya": "Deva",          "Ashlesha": "Rakshasa",
    "Magha": "Rakshasa",        "Purva Phalguni": "Manushya","Uttara Phalguni": "Manushya",
    "Hasta": "Deva",            "Chitra": "Rakshasa",      "Swati": "Deva",
    "Vishakha": "Rakshasa",     "Anuradha": "Deva",        "Jyeshtha": "Rakshasa",
    "Mula": "Rakshasa",         "Purva Ashadha": "Manushya","Uttara Ashadha": "Manushya",
    "Shravana": "Deva",         "Dhanishta": "Rakshasa",   "Shatabhisha": "Rakshasa",
    "Purva Bhadrapada": "Manushya","Uttara Bhadrapada": "Manushya","Revati": "Deva",
}

GANA_MATCH_SCORES: Dict[Tuple[str, str], int] = {
    ("Deva", "Deva"):         6,
    ("Manushya", "Manushya"): 6,
    ("Rakshasa", "Rakshasa"): 6,
    ("Deva", "Manushya"):     5, ("Manushya", "Deva"): 5,
    ("Manushya", "Rakshasa"): 1, ("Rakshasa", "Manushya"): 0,  # boy Rakshasa worse
    ("Deva", "Rakshasa"):     1, ("Rakshasa", "Deva"): 0,
}


# ════════════════════════════════════════════════════════════════════════
# KUTA #7 — BHAKOOT KUTA (max 7 points)
# Moon-sign distance dosha
# 2-12, 5-9, 6-8 distances = Bhakoot Dosha (0 points); others = 7
# ════════════════════════════════════════════════════════════════════════

BHAKOOT_DOSHA_DISTANCES: List[Tuple[int, int]] = [
    (2, 12), (12, 2),
    (5, 9),  (9, 5),
    (6, 8),  (8, 6),
]

# Bhakoot cancellations — classical
BHAKOOT_CANCELLATIONS: List[str] = [
    "Moons of both natives ruled by the same planet (e.g., both Cancer or both signs of Mercury)",
    "Lords of the two Moon signs are mutual friends",
    "Lords of the two Moon signs are exchanged (parivartana)",
    "Both Moons in same Nakshatra (Rashi-dosha overridden by Nakshatra similarity)",
]


# ════════════════════════════════════════════════════════════════════════
# KUTA #8 — NADI KUTA (max 8 points) — MOST WEIGHTED
# Body-constitution similarity: Adi / Madhya / Antya
# Same Nadi = 0 points (Nadi Dosha — major)
# ════════════════════════════════════════════════════════════════════════

NAKSHATRA_TO_NADI: Dict[str, str] = {
    "Ashwini": "Adi",          "Bharani": "Madhya",      "Krittika": "Antya",
    "Rohini": "Antya",         "Mrigashira": "Madhya",   "Ardra": "Adi",
    "Punarvasu": "Adi",        "Pushya": "Madhya",       "Ashlesha": "Antya",
    "Magha": "Antya",          "Purva Phalguni": "Madhya","Uttara Phalguni": "Adi",
    "Hasta": "Adi",            "Chitra": "Madhya",       "Swati": "Antya",
    "Vishakha": "Antya",       "Anuradha": "Madhya",     "Jyeshtha": "Adi",
    "Mula": "Adi",             "Purva Ashadha": "Madhya","Uttara Ashadha": "Antya",
    "Shravana": "Antya",       "Dhanishta": "Madhya",    "Shatabhisha": "Adi",
    "Purva Bhadrapada": "Adi", "Uttara Bhadrapada": "Madhya","Revati": "Antya",
}

# Nadi Dosha classical cancellations
NADI_DOSHA_CANCELLATIONS: List[str] = [
    "Both Moons in same sign (Rashi)",
    "Both Moons in same Nakshatra but different Padas",
    "Moon-sign lords of both natives are the same planet",
    "Both natives' Nakshatra lords are the same planet",
    "Both natives have similar dominant element/dosha balance verified separately",
]


# ════════════════════════════════════════════════════════════════════════
# ASHTAKOOT WEIGHTS — sum to 36
# ════════════════════════════════════════════════════════════════════════

ASHTAKOOT_WEIGHTS: Dict[str, int] = {
    "Varna":        1,
    "Vashya":       2,
    "Tara":         3,
    "Yoni":         4,
    "Graha Maitri": 5,
    "Gana":         6,
    "Bhakoot":      7,
    "Nadi":         8,
}

# Score interpretation
ASHTAKOOT_RECOMMENDATION: Dict[str, str] = {
    "excellent":    "30-36 points — exceptional compatibility",
    "very_good":    "24-29 points — strong match",
    "good":         "18-23 points — acceptable; proceed with care",
    "below_threshold":"<18 points — classical texts advise against; doshas must be analyzed",
}


# ════════════════════════════════════════════════════════════════════════
# MANGLIK DOSHA — Mars dosha rules + cancellations
# Source: Hora Sara, BPHS Ch. 44, Phaladeepika Ch. 7
# ════════════════════════════════════════════════════════════════════════

# Houses (from Lagna OR Moon OR Venus) that make a chart Manglik
MANGLIK_HOUSES: List[int] = [1, 4, 7, 8, 12]

# Strict vs partial: 1, 4, 7, 8, 12 = full Manglik per Hora Sara
# Some texts also count 2nd house = partial; we include with caveat
MANGLIK_PARTIAL_HOUSES: List[int] = [2]

MANGLIK_CANCELLATIONS: List[str] = [
    "Both natives are Manglik — doshas cancel each other (most accepted cancellation)",
    "Mars in own sign (Aries or Scorpio) — Mars in Aries 1st or Scorpio 8th does not afflict",
    "Mars in exaltation (Capricorn) or moolatrikona (Aries) — sufficient strength to cancel",
    "Mars conjunct or aspected by Jupiter or full Moon — benefic cancellation",
    "Mars in 1st, 4th, 7th, 8th, 12th from Lagna but in a sign ruled by Mars (Aries, Scorpio) — own sign cancellation",
    "Mars in Cancer in 1st house — debilitated Mars in Lagna loses afflicting power",
    "Native is over 28 — many traditions hold Manglik effects diminish after age 28",
    "If 7th lord is in 7th house, dosha is mitigated regardless of Mars placement",
    "If 8th house is occupied by a benefic, 8th-house Mars dosha is reduced",
]


# ════════════════════════════════════════════════════════════════════════
# 7TH HOUSE MARRIAGE INDICATORS
# Source: BPHS Ch. 44, Phaladeepika Ch. 7, Saravali Ch. 27
# ════════════════════════════════════════════════════════════════════════

SEVENTH_HOUSE_KARAKAS: Dict[str, str] = {
    "Venus":   "Karaka for marriage (especially for males); represents spouse, attraction, harmony",
    "Jupiter": "Karaka for husband (for females); represents wisdom in spouse, ethical bonds",
    "Mars":    "Karaka for sexual energy in marriage; passion or conflict depending on placement",
}

SEVENTH_LORD_DIGNITY_WEIGHTS: Dict[str, int] = {
    "exalted":       4,
    "moolatrikona":  3,
    "own":           3,
    "great_friend":  2,
    "friend":        2,
    "neutral":       1,
    "enemy":         0,
    "great_enemy":   -1,
    "debilitated":   -2,
    "combust":       -1,
}


# ════════════════════════════════════════════════════════════════════════
# LONGEVITY MATCH — 8th house comparison (Ayur Bhava)
# Source: Jataka Parijata Ch. 14, BPHS Ch. 44
# ════════════════════════════════════════════════════════════════════════

LONGEVITY_BUCKETS: Dict[str, str] = {
    "matched":   "Both natives' Ayur bhava (8th house lord) of similar strength → mutually balanced longevity",
    "mismatched":"Significant disparity in 8th house lord strength → potential widowhood concerns per classical texts",
    "weak_both": "Both 8th houses afflicted → karmic shared transformation themes; consider remedial measures",
    "strong_both":"Both 8th houses strong → long, deep marital union",
}


# ════════════════════════════════════════════════════════════════════════
# RELATIONSHIP TYPE → primary karaka focus
# ════════════════════════════════════════════════════════════════════════

RELATIONSHIP_KARAKAS: Dict[str, Dict[str, str]] = {
    "marriage": {
        "primary_house":  "7th",
        "primary_karaka_male":   "Venus",
        "primary_karaka_female": "Jupiter",
        "secondary_house": "2nd (family), 8th (longevity), 12th (bed pleasures)",
    },
    "business": {
        "primary_house":  "7th (partnership) and 10th (career)",
        "primary_karaka": "Mercury (commerce), Jupiter (ethics)",
        "secondary_house": "11th (gains)",
    },
    "friendship": {
        "primary_house":  "11th (friends, gains)",
        "primary_karaka": "Jupiter",
        "secondary_house": "3rd (siblings, peers)",
    },
}


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "ashtakoot":         "Traditional 8-fold Kuta system; Brihat Samhita commentary; BPHS Ch. 44 Vivaha; Muhurta Chintamani",
    "manglik":           "Hora Sara; BPHS Ch. 44 (Mars dosha); Phaladeepika Ch. 7",
    "nadi_dosha":        "BPHS Ch. 44; Phaladeepika Ch. 7; classical Nadi tradition",
    "bhakoot":           "BPHS Ch. 44; Saravali Ch. 27; Muhurta Chintamani Vivaha chapter",
    "navamsha":          "BPHS Ch. 8 (Vargas); Phaladeepika Ch. 4; Jataka Parijata Ch. 4 — D9 as marriage chart",
    "seventh_house":     "BPHS Ch. 44; Phaladeepika Ch. 7; Saravali Ch. 27",
    "venus_jupiter":     "BPHS Ch. 3 (Karakas); Phaladeepika Ch. 2; classical karaka tradition",
    "longevity":         "Jataka Parijata Ch. 14 (Ayur); BPHS Ch. 44",
    "synastry":          "BPHS Ch. 44; Phaladeepika Ch. 7; Jaimini Sutras (mutual aspects)",
    "muhurta_marriage":  "Muhurta Chintamani (Rama Daivajna ~17th c.); Muhurta Martanda; BPHS Ch. 44",
}
