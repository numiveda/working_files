"""
feng_shui_data.py — Static classical data for Feng Shui Personal module

Sources (all public domain, classical):
- I Ching / Yi Jing — 8 Trigrams (Bagua), Pre-Heaven + Post-Heaven arrangements
- Compass School (Sānyuán + Sānhé schools) — Kua numbers, 8 Mansions theory
- Xuán Kōng Fēi Xīng (Flying Stars) — Period 9 (2024–2043), annual stars
- Wǔ Xíng (5 Elements) — Generative + Destructive cycles
- Tiān Gān Dì Zhī (Heavenly Stems + Earthly Branches) — 60-year sexagenary cycle

Architecture notes:
- All data here is STATIC + CLASSICAL — no LLM-generated content
- "Modern application" is left to downstream consumers (apps, reports, B2B API)
- Each constant is cited to its classical source
"""

# ════════════════════════════════════════════════════════════════════════
# 1. THE 8 TRIGRAMS (BAGUA / 八卦)
# Source: I Ching, ~1000 BCE — Pre-Heaven (Fu Xi) + Post-Heaven (King Wen)
# ════════════════════════════════════════════════════════════════════════

BAGUA = {
    "qian":  {
        "chinese":      "乾",
        "pinyin":       "Qián",
        "english":      "Heaven",
        "element":      "metal",
        "direction":    "northwest",  # Post-Heaven arrangement
        "family":       "father",
        "yin_yang":     "yang",
        "binary":       "111",         # 3 unbroken lines (yang)
        "body_part":    "head",
        "attributes":   ["creative", "strong", "leadership", "authority"],
    },
    "kun":   {
        "chinese":      "坤",
        "pinyin":       "Kūn",
        "english":      "Earth",
        "element":      "earth",
        "direction":    "southwest",
        "family":       "mother",
        "yin_yang":     "yin",
        "binary":       "000",         # 3 broken lines (yin)
        "body_part":    "belly",
        "attributes":   ["receptive", "nurturing", "support", "patience"],
    },
    "zhen":  {
        "chinese":      "震",
        "pinyin":       "Zhèn",
        "english":      "Thunder",
        "element":      "wood",
        "direction":    "east",
        "family":       "eldest_son",
        "yin_yang":     "yang",
        "binary":       "001",
        "body_part":    "feet",
        "attributes":   ["arousing", "movement", "initiative", "shock"],
    },
    "xun":   {
        "chinese":      "巽",
        "pinyin":       "Xùn",
        "english":      "Wind",
        "element":      "wood",
        "direction":    "southeast",
        "family":       "eldest_daughter",
        "yin_yang":     "yin",
        "binary":       "110",
        "body_part":    "thighs",
        "attributes":   ["gentle", "penetrating", "wealth", "growth"],
    },
    "kan":   {
        "chinese":      "坎",
        "pinyin":       "Kǎn",
        "english":      "Water",
        "element":      "water",
        "direction":    "north",
        "family":       "middle_son",
        "yin_yang":     "yang",
        "binary":       "010",
        "body_part":    "ears",
        "attributes":   ["abysmal", "danger", "career", "wisdom"],
    },
    "li":    {
        "chinese":      "離",
        "pinyin":       "Lí",
        "english":      "Fire",
        "element":      "fire",
        "direction":    "south",
        "family":       "middle_daughter",
        "yin_yang":     "yin",
        "binary":       "101",
        "body_part":    "eyes",
        "attributes":   ["clinging", "brightness", "fame", "clarity"],
    },
    "gen":   {
        "chinese":      "艮",
        "pinyin":       "Gèn",
        "english":      "Mountain",
        "element":      "earth",
        "direction":    "northeast",
        "family":       "youngest_son",
        "yin_yang":     "yang",
        "binary":       "100",
        "body_part":    "hands",
        "attributes":   ["stillness", "knowledge", "self-cultivation", "stability"],
    },
    "dui":   {
        "chinese":      "兌",
        "pinyin":       "Duì",
        "english":      "Lake",
        "element":      "metal",
        "direction":    "west",
        "family":       "youngest_daughter",
        "yin_yang":     "yin",
        "binary":       "011",
        "body_part":    "mouth",
        "attributes":   ["joyous", "pleasure", "children", "communication"],
    },
}


# ════════════════════════════════════════════════════════════════════════
# 2. KUA NUMBER → TRIGRAM + GROUP
# Source: 8 Mansions (Ba Zhai / 八宅) — Compass School
# Kua 5 is a special case: men become Kua 2 (Kun), women become Kua 8 (Gen)
# ════════════════════════════════════════════════════════════════════════

KUA_TO_TRIGRAM = {
    1: "kan",    # East group
    2: "kun",    # West group
    3: "zhen",   # East group
    4: "xun",    # East group
    # 5 has no trigram — falls back to 2 (M) or 8 (F)
    6: "qian",   # West group
    7: "dui",    # West group
    8: "gen",    # West group
    9: "li",     # East group
}

# East Group vs West Group — compatibility & direction systems
EAST_GROUP_KUAS = [1, 3, 4, 9]
WEST_GROUP_KUAS = [2, 6, 7, 8]


# ════════════════════════════════════════════════════════════════════════
# 3. EIGHT MANSIONS (BA ZHAI) — 4 LUCKY + 4 UNLUCKY DIRECTIONS PER KUA
# Source: Ba Zhai Ming Jing (Bright Mirror of the Eight Mansions), ~1100 CE
#
# Each Kua has 4 favorable and 4 unfavorable directions:
# Lucky:    Sheng Qi (生氣)  — Wealth, success                 [BEST]
#           Tian Yi (天醫)  — Health, healing
#           Yan Nian (延年) — Longevity, relationships
#           Fu Wei (伏位)   — Stability, personal growth
# Unlucky:  Huo Hai (禍害)  — Mishaps, accidents
#           Wu Gui (五鬼)   — Five Ghosts, betrayal
#           Liu Sha (六煞)  — Six Killings, conflicts
#           Jue Ming (絕命) — Total loss                       [WORST]
# ════════════════════════════════════════════════════════════════════════

KUA_DIRECTIONS = {
    1: {  # Kan (Water) — East group
        "sheng_qi":  "southeast",  # +Wealth
        "tian_yi":   "east",       # +Health
        "yan_nian":  "south",      # +Relationships
        "fu_wei":    "north",      # +Personal growth
        "huo_hai":   "west",       # -Mishaps
        "wu_gui":    "northeast",  # -Betrayal
        "liu_sha":   "northwest",  # -Conflicts
        "jue_ming":  "southwest",  # -Total loss
    },
    2: {  # Kun (Earth) — West group
        "sheng_qi":  "northeast",
        "tian_yi":   "west",
        "yan_nian":  "northwest",
        "fu_wei":    "southwest",
        "huo_hai":   "east",
        "wu_gui":    "southeast",
        "liu_sha":   "south",
        "jue_ming":  "north",
    },
    3: {  # Zhen (Thunder) — East group
        "sheng_qi":  "south",
        "tian_yi":   "north",
        "yan_nian":  "southeast",
        "fu_wei":    "east",
        "huo_hai":   "southwest",
        "wu_gui":    "northwest",
        "liu_sha":   "northeast",
        "jue_ming":  "west",
    },
    4: {  # Xun (Wind) — East group
        "sheng_qi":  "north",
        "tian_yi":   "south",
        "yan_nian":  "east",
        "fu_wei":    "southeast",
        "huo_hai":   "northwest",
        "wu_gui":    "southwest",
        "liu_sha":   "west",
        "jue_ming":  "northeast",
    },
    6: {  # Qian (Heaven) — West group
        "sheng_qi":  "west",
        "tian_yi":   "northeast",
        "yan_nian":  "southwest",
        "fu_wei":    "northwest",
        "huo_hai":   "southeast",
        "wu_gui":    "east",
        "liu_sha":   "north",
        "jue_ming":  "south",
    },
    7: {  # Dui (Lake) — West group
        "sheng_qi":  "northwest",
        "tian_yi":   "southwest",
        "yan_nian":  "northeast",
        "fu_wei":    "west",
        "huo_hai":   "north",
        "wu_gui":    "south",
        "liu_sha":   "southeast",
        "jue_ming":  "east",
    },
    8: {  # Gen (Mountain) — West group
        "sheng_qi":  "southwest",
        "tian_yi":   "northwest",
        "yan_nian":  "west",
        "fu_wei":    "northeast",
        "huo_hai":   "south",
        "wu_gui":    "north",
        "liu_sha":   "east",
        "jue_ming":  "southeast",
    },
    9: {  # Li (Fire) — East group
        "sheng_qi":  "east",
        "tian_yi":   "southeast",
        "yan_nian":  "north",
        "fu_wei":    "south",
        "huo_hai":   "northeast",
        "wu_gui":    "west",
        "liu_sha":   "southwest",
        "jue_ming":  "northwest",
    },
}

DIRECTION_MEANINGS = {
    "sheng_qi": {
        "chinese": "生氣",
        "english": "Generating Qi",
        "polarity": "lucky",
        "rank":     1,
        "domain":   "wealth, career success, opportunities",
        "best_for": "main door, office desk facing, business activities",
    },
    "tian_yi": {
        "chinese": "天醫",
        "english": "Heavenly Doctor",
        "polarity": "lucky",
        "rank":     2,
        "domain":   "health, healing, recovery from illness",
        "best_for": "bed head direction, kitchen stove, medicine cabinet",
    },
    "yan_nian": {
        "chinese": "延年",
        "english": "Longevity",
        "polarity": "lucky",
        "rank":     3,
        "domain":   "relationships, marriage, family harmony",
        "best_for": "dining area, family gathering spaces, bedroom",
    },
    "fu_wei": {
        "chinese": "伏位",
        "english": "Stability",
        "polarity": "lucky",
        "rank":     4,
        "domain":   "peace, personal growth, study, meditation",
        "best_for": "study desk, meditation corner, child's bedroom",
    },
    "huo_hai": {
        "chinese": "禍害",
        "english": "Mishaps",
        "polarity": "unlucky",
        "rank":     5,
        "domain":   "minor accidents, legal issues, gossip",
        "avoid_for": "main door, bed head, frequently used spaces",
    },
    "wu_gui": {
        "chinese": "五鬼",
        "english": "Five Ghosts",
        "polarity": "unlucky",
        "rank":     6,
        "domain":   "betrayal, theft, arguments, fire risk",
        "avoid_for": "bedroom, office, valuables storage",
    },
    "liu_sha": {
        "chinese": "六煞",
        "english": "Six Killings",
        "polarity": "unlucky",
        "rank":     7,
        "domain":   "conflicts, scandals, loss of opportunities",
        "avoid_for": "front door, master bedroom, business desk",
    },
    "jue_ming": {
        "chinese": "絕命",
        "english": "Total Loss",
        "polarity": "unlucky",
        "rank":     8,
        "domain":   "severe illness, bankruptcy, broken relationships",
        "avoid_for": "EVERYTHING — most inauspicious direction",
    },
}


# ════════════════════════════════════════════════════════════════════════
# 4. FIVE ELEMENTS (WU XING / 五行)
# Source: Hong Fan chapter of Book of Documents, ~2nd century BCE
# ════════════════════════════════════════════════════════════════════════

WU_XING = {
    "wood":  {"chinese": "木", "color": "green",  "direction": "east",       "season": "spring",      "planet": "jupiter"},
    "fire":  {"chinese": "火", "color": "red",    "direction": "south",      "season": "summer",      "planet": "mars"},
    "earth": {"chinese": "土", "color": "yellow", "direction": "center",     "season": "late_summer", "planet": "saturn"},
    "metal": {"chinese": "金", "color": "white",  "direction": "west",       "season": "autumn",      "planet": "venus"},
    "water": {"chinese": "水", "color": "black",  "direction": "north",      "season": "winter",      "planet": "mercury"},
}

# Generative cycle (Sheng / 相生): each element produces the next
SHENG_CYCLE = {
    "wood":  "fire",   # Wood feeds fire
    "fire":  "earth",  # Fire creates ash → earth
    "earth": "metal",  # Earth bears metal
    "metal": "water",  # Metal carries water (condensation)
    "water": "wood",   # Water nourishes wood
}

# Destructive cycle (Ke / 相剋): each element overcomes another
KE_CYCLE = {
    "wood":  "earth",  # Wood breaks earth (roots)
    "earth": "water",  # Earth dams water
    "water": "fire",   # Water extinguishes fire
    "fire":  "metal",  # Fire melts metal
    "metal": "wood",   # Metal cuts wood
}


# ════════════════════════════════════════════════════════════════════════
# 5. BAGUA AREAS IN THE HOME (LIFE ASPIRATIONS / WESTERN BAGUA)
# Source: Black Hat Tibetan Buddhist Feng Shui (Lin Yun, 1986)
# Mapped from main entrance — entry is always Career/North in this system
# ════════════════════════════════════════════════════════════════════════

BAGUA_AREAS_HOME = {
    "career":            {"direction": "north",     "element": "water", "trigram": "kan",  "color": "black"},
    "knowledge":         {"direction": "northeast", "element": "earth", "trigram": "gen",  "color": "blue"},
    "family":            {"direction": "east",      "element": "wood",  "trigram": "zhen", "color": "green"},
    "wealth":            {"direction": "southeast", "element": "wood",  "trigram": "xun",  "color": "purple"},
    "fame":              {"direction": "south",     "element": "fire",  "trigram": "li",   "color": "red"},
    "relationships":     {"direction": "southwest", "element": "earth", "trigram": "kun",  "color": "pink"},
    "creativity":        {"direction": "west",      "element": "metal", "trigram": "dui",  "color": "white"},
    "helpful_people":    {"direction": "northwest", "element": "metal", "trigram": "qian", "color": "gray"},
    "health":            {"direction": "center",    "element": "earth", "trigram": None,   "color": "yellow"},
}


# ════════════════════════════════════════════════════════════════════════
# 6. PERIOD 9 FLYING STARS (2024–2043)
# Source: Xuan Kong Fei Xing — Three Cycles / Nine Periods
# Period 9 started Feb 4, 2024 (Lichun) and runs to Feb 3, 2044
# Each period is 20 years; we are now in the Fire period ruled by Li
# ════════════════════════════════════════════════════════════════════════

CURRENT_PERIOD = {
    "number":     9,
    "trigram":    "li",
    "element":    "fire",
    "start_year": 2024,
    "end_year":   2043,
    "themes":     ["fire", "spirituality", "AI", "vision", "fame", "media", "women_rising"],
}

# Annual flying star (center palace) for each year
# Pattern: the central star decreases by 1 each year, wrapping 9→8→7→...→1→9
# 2024 = 3 (start of Period 9 cycle)
ANNUAL_CENTER_STARS = {
    2024: 3,
    2025: 2,
    2026: 1,   # Current — water star in center
    2027: 9,
    2028: 8,
    2029: 7,
    2030: 6,
    2031: 5,
    2032: 4,
    2033: 3,
}

# Each star's nature when it visits a sector
STAR_NATURES = {
    1: {"element": "water", "polarity": "auspicious",  "domain": "career, scholarship, fame"},
    2: {"element": "earth", "polarity": "inauspicious","domain": "illness, sickness — avoid"},
    3: {"element": "wood",  "polarity": "inauspicious","domain": "arguments, lawsuits, conflicts"},
    4: {"element": "wood",  "polarity": "auspicious",  "domain": "romance, scholarship, creativity"},
    5: {"element": "earth", "polarity": "very_inauspicious","domain": "disasters, calamities — most feared"},
    6: {"element": "metal", "polarity": "auspicious",  "domain": "authority, government support"},
    7: {"element": "metal", "polarity": "inauspicious","domain": "robbery, violence, betrayal"},
    8: {"element": "earth", "polarity": "auspicious",  "domain": "wealth, prosperity"},
    9: {"element": "fire",  "polarity": "auspicious_when_active","domain": "fame, vision, multiplier of current period"},
}


# ════════════════════════════════════════════════════════════════════════
# 7. CHINESE 4 PILLARS — HEAVENLY STEMS + EARTHLY BRANCHES
# Source: Tang Dynasty Bazi system, codified ~700 CE
# Used for determining "personal element" (Day Master)
# ════════════════════════════════════════════════════════════════════════

HEAVENLY_STEMS = [
    {"name": "Jia",  "chinese": "甲", "element": "wood",  "yin_yang": "yang"},
    {"name": "Yi",   "chinese": "乙", "element": "wood",  "yin_yang": "yin"},
    {"name": "Bing", "chinese": "丙", "element": "fire",  "yin_yang": "yang"},
    {"name": "Ding", "chinese": "丁", "element": "fire",  "yin_yang": "yin"},
    {"name": "Wu",   "chinese": "戊", "element": "earth", "yin_yang": "yang"},
    {"name": "Ji",   "chinese": "己", "element": "earth", "yin_yang": "yin"},
    {"name": "Geng", "chinese": "庚", "element": "metal", "yin_yang": "yang"},
    {"name": "Xin",  "chinese": "辛", "element": "metal", "yin_yang": "yin"},
    {"name": "Ren",  "chinese": "壬", "element": "water", "yin_yang": "yang"},
    {"name": "Gui",  "chinese": "癸", "element": "water", "yin_yang": "yin"},
]

EARTHLY_BRANCHES = [
    {"name": "Zi",   "chinese": "子", "animal": "rat",     "element": "water", "hour_start": 23},
    {"name": "Chou", "chinese": "丑", "animal": "ox",      "element": "earth", "hour_start":  1},
    {"name": "Yin",  "chinese": "寅", "animal": "tiger",   "element": "wood",  "hour_start":  3},
    {"name": "Mao",  "chinese": "卯", "animal": "rabbit",  "element": "wood",  "hour_start":  5},
    {"name": "Chen", "chinese": "辰", "animal": "dragon",  "element": "earth", "hour_start":  7},
    {"name": "Si",   "chinese": "巳", "animal": "snake",   "element": "fire",  "hour_start":  9},
    {"name": "Wu",   "chinese": "午", "animal": "horse",   "element": "fire",  "hour_start": 11},
    {"name": "Wei",  "chinese": "未", "animal": "goat",    "element": "earth", "hour_start": 13},
    {"name": "Shen", "chinese": "申", "animal": "monkey",  "element": "metal", "hour_start": 15},
    {"name": "You",  "chinese": "酉", "animal": "rooster", "element": "metal", "hour_start": 17},
    {"name": "Xu",   "chinese": "戌", "animal": "dog",     "element": "earth", "hour_start": 19},
    {"name": "Hai",  "chinese": "亥", "animal": "pig",     "element": "water", "hour_start": 21},
]

# Year-to-stem-and-branch mapping is computed in feng_shui.py
# Formula: stem_index = (year - 4) % 10, branch_index = (year - 4) % 12
# Reference year: 1984 = Jia Zi (year 1 of 60-cycle, "wood rat")
