"""
compatibility.py — numiVeda Kaaliyo Astro Engine — Module C1 (Compatibility / Synastry)

12 endpoints for two-chart marriage/relationship matching.

Public API:
    handle_profile                — Master synthesis
    handle_ashtakoot              — Full 8-Kuta 36-point matching
    handle_manglik                — Mars dosha analysis with cancellations
    handle_nadi_dosha             — Nadi Kuta detailed
    handle_bhakoot_dosha          — Bhakoot Kuta detailed
    handle_dasha_compatibility    — Current/upcoming dasha overlap analysis
    handle_synastry_aspects       — Cross-aspect map between charts
    handle_d9_navamsha_compat     — D9 Navamsha marriage chart synthesis
    handle_seventh_house_synthesis— Both 7th houses analyzed
    handle_venus_jupiter_synthesis— Marriage karaka cross-analysis
    handle_longevity_match        — 8th house comparison
    handle_timing_for_marriage    — Best marriage muhurta windows

Two BirthInput dicts → Two chart casts → Compared per classical Ashtakoot rules.
"""

from typing import Dict, List, Optional, Any, Tuple

from astro_helpers import (
    extract_chart_essentials,
    get_chart,
    compute_house_lords,
    SIGNS_ORDER,
    SIGN_TO_LORD,
    HOUSE_TO_LIFE_AREA,
)

from compatibility_data import (
    NAKSHATRA_ORDER,
    NAKSHATRA_TO_VARNA, VARNA_LEVEL,
    NAKSHATRA_TO_VASHYA, VASHYA_COMPATIBILITY,
    TARA_GOOD_REMAINDERS, TARA_BAD_REMAINDERS, TARA_NEUTRAL_REMAINDERS,
    NAKSHATRA_TO_YONI, YONI_SAME_SCORE, YONI_FRIENDLY, YONI_ENEMIES, YONI_NEUTRAL_PAIRS,
    PLANET_FRIENDSHIP, GRAHA_MAITRI_SCORE,
    NAKSHATRA_TO_GANA, GANA_MATCH_SCORES,
    BHAKOOT_DOSHA_DISTANCES, BHAKOOT_CANCELLATIONS,
    NAKSHATRA_TO_NADI, NADI_DOSHA_CANCELLATIONS,
    ASHTAKOOT_WEIGHTS, ASHTAKOOT_RECOMMENDATION,
    MANGLIK_HOUSES, MANGLIK_PARTIAL_HOUSES, MANGLIK_CANCELLATIONS,
    SEVENTH_HOUSE_KARAKAS, SEVENTH_LORD_DIGNITY_WEIGHTS,
    LONGEVITY_BUCKETS,
    RELATIONSHIP_KARAKAS,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# CORE — Cast both charts and extract
# ════════════════════════════════════════════════════════════════════════

def _build_person(birth: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Return (raw_chart, essentials) for a person."""
    raw = get_chart(
        dob=birth["dob"],
        time=birth["time"],
        lat=birth["lat"],
        lon=birth["lon"],
        timezone=birth.get("timezone", "Asia/Kolkata"),
    )
    essentials = extract_chart_essentials(raw)
    return raw, essentials


def _sign_index(sign: Optional[str]) -> Optional[int]:
    if not sign or sign not in SIGNS_ORDER:
        return None
    return SIGNS_ORDER.index(sign)


def _house_from_sign(target_sign: str, reference_sign: str) -> Optional[int]:
    t = _sign_index(target_sign)
    r = _sign_index(reference_sign)
    if t is None or r is None:
        return None
    return ((t - r) % 12) + 1


def _planet_relation(p1: str, p2: str) -> str:
    """Return 'friend', 'neutral', or 'enemy' between two planets per Naisargika Maitri."""
    if p1 == p2:
        return "friend"  # Same planet is self-friend
    rels = PLANET_FRIENDSHIP.get(p1, {})
    if p2 in rels.get("friends", []):
        return "friend"
    if p2 in rels.get("enemies", []):
        return "enemy"
    return "neutral"


# ════════════════════════════════════════════════════════════════════════
# ASHTAKOOT — 8 KUTAS
# ════════════════════════════════════════════════════════════════════════

def _varna_kuta(p1_nak: str, p2_nak: str, p1_gender: str) -> Dict[str, Any]:
    """
    Varna Kuta: groom's Varna must be >= bride's Varna.
    Score: 1 if condition met, 0 otherwise.
    """
    v1 = NAKSHATRA_TO_VARNA.get(p1_nak, "Shudra")
    v2 = NAKSHATRA_TO_VARNA.get(p2_nak, "Shudra")
    l1 = VARNA_LEVEL.get(v1, 1)
    l2 = VARNA_LEVEL.get(v2, 1)
    # Convention: groom = male, bride = female. If p1 is male, p1 >= p2.
    if p1_gender.lower().startswith("m"):
        passed = l1 >= l2
    else:
        passed = l2 >= l1
    return {
        "score":   1 if passed else 0,
        "max":     1,
        "person1_varna": v1,
        "person2_varna": v2,
        "passed":  passed,
        "note":    "Groom's Varna should be equal to or higher than bride's per classical rule",
    }


def _vashya_kuta(p1_nak: str, p2_nak: str) -> Dict[str, Any]:
    """Vashya Kuta — mutual control / attraction."""
    v1 = NAKSHATRA_TO_VASHYA.get(p1_nak, "Manava")
    v2 = NAKSHATRA_TO_VASHYA.get(p2_nak, "Manava")
    score = VASHYA_COMPATIBILITY.get((v1, v2), 0.0)
    return {
        "score":   score,
        "max":     2,
        "person1_vashya": v1,
        "person2_vashya": v2,
    }


def _tara_kuta(p1_nak: str, p2_nak: str) -> Dict[str, Any]:
    """
    Tara Kuta — birth-star count distance.
    Compute count from each direction, divide by 9, classify remainder.
    Each direction earns 1.5 points (3 max total).
    """
    if p1_nak not in NAKSHATRA_ORDER or p2_nak not in NAKSHATRA_ORDER:
        return {"score": 0, "max": 3, "error": "unknown nakshatra"}

    i1 = NAKSHATRA_ORDER.index(p1_nak)
    i2 = NAKSHATRA_ORDER.index(p2_nak)

    # Count from p1 to p2 (inclusive of p1): if same, count = 1
    count_1to2 = ((i2 - i1) % 27) + 1
    count_2to1 = ((i1 - i2) % 27) + 1

    rem_1to2 = count_1to2 % 9 if count_1to2 % 9 != 0 else 9
    rem_2to1 = count_2to1 % 9 if count_2to1 % 9 != 0 else 9

    def tara_pts(rem: int) -> float:
        if rem in TARA_GOOD_REMAINDERS:
            return 1.5
        if rem in TARA_NEUTRAL_REMAINDERS:
            return 0.75
        return 0.0  # bad

    pts = tara_pts(rem_1to2) + tara_pts(rem_2to1)
    return {
        "score":   pts,
        "max":     3,
        "remainder_p1_to_p2": rem_1to2,
        "remainder_p2_to_p1": rem_2to1,
        "interpretation": (
            "favorable" if pts >= 2.5 else
            "moderate"  if pts >= 1.5 else
            "challenging"
        ),
    }


def _yoni_kuta(p1_nak: str, p2_nak: str) -> Dict[str, Any]:
    """Yoni Kuta — animal yoni compatibility."""
    y1 = NAKSHATRA_TO_YONI.get(p1_nak, ("Unknown", "M"))
    y2 = NAKSHATRA_TO_YONI.get(p2_nak, ("Unknown", "F"))
    a1, g1 = y1
    a2, g2 = y2

    score = 0
    if a1 == a2:
        # Same yoni: 4 if opposite gender, 3 if same gender
        score = 4 if g1 != g2 else 3
    elif (a1, a2) in YONI_ENEMIES or (a2, a1) in YONI_ENEMIES:
        score = 0
    elif (a1, a2) in YONI_FRIENDLY or (a2, a1) in YONI_FRIENDLY:
        score = 3
    elif (a1, a2) in YONI_NEUTRAL_PAIRS or (a2, a1) in YONI_NEUTRAL_PAIRS:
        score = 2
    else:
        score = 1  # default mild

    return {
        "score":           score,
        "max":             4,
        "person1_yoni":    f"{a1} ({g1})",
        "person2_yoni":    f"{a2} ({g2})",
        "compatibility":   ("same" if a1 == a2 else
                            "enemy" if (a1, a2) in YONI_ENEMIES or (a2, a1) in YONI_ENEMIES else
                            "friendly" if (a1, a2) in YONI_FRIENDLY or (a2, a1) in YONI_FRIENDLY else
                            "neutral"),
    }


def _graha_maitri_kuta(p1_moon_sign: str, p2_moon_sign: str) -> Dict[str, Any]:
    """Graha Maitri Kuta — friendship between Moon-sign LORDS."""
    l1 = SIGN_TO_LORD.get(p1_moon_sign)
    l2 = SIGN_TO_LORD.get(p2_moon_sign)
    if not l1 or not l2:
        return {"score": 0, "max": 5, "error": "unknown moon lord"}

    rel_1to2 = _planet_relation(l1, l2)
    rel_2to1 = _planet_relation(l2, l1)
    score = GRAHA_MAITRI_SCORE.get((rel_1to2, rel_2to1), 0)
    return {
        "score":           score,
        "max":             5,
        "person1_moon_lord": l1,
        "person2_moon_lord": l2,
        "relation_p1_to_p2": rel_1to2,
        "relation_p2_to_p1": rel_2to1,
    }


def _gana_kuta(p1_nak: str, p2_nak: str) -> Dict[str, Any]:
    """Gana Kuta — temperament (Deva/Manushya/Rakshasa)."""
    g1 = NAKSHATRA_TO_GANA.get(p1_nak, "Manushya")
    g2 = NAKSHATRA_TO_GANA.get(p2_nak, "Manushya")
    score = GANA_MATCH_SCORES.get((g1, g2), 0)
    return {
        "score":           score,
        "max":             6,
        "person1_gana":    g1,
        "person2_gana":    g2,
    }


def _bhakoot_kuta(p1_moon_sign: str, p2_moon_sign: str,
                  p1_moon_lord: str, p2_moon_lord: str) -> Dict[str, Any]:
    """Bhakoot Kuta — Moon-sign distance dosha."""
    i1 = _sign_index(p1_moon_sign)
    i2 = _sign_index(p2_moon_sign)
    if i1 is None or i2 is None:
        return {"score": 0, "max": 7, "error": "unknown moon sign"}

    dist_1to2 = ((i2 - i1) % 12) + 1
    dist_2to1 = ((i1 - i2) % 12) + 1

    dosha_active = (dist_1to2, dist_2to1) in BHAKOOT_DOSHA_DISTANCES \
                   or (dist_2to1, dist_1to2) in BHAKOOT_DOSHA_DISTANCES

    # Check cancellations
    cancellations: List[str] = []
    if p1_moon_lord == p2_moon_lord:
        cancellations.append("Both Moons ruled by same planet")
    if _planet_relation(p1_moon_lord, p2_moon_lord) == "friend":
        cancellations.append("Moon-sign lords are mutual friends")

    score = 7 if not dosha_active else (3 if cancellations else 0)
    return {
        "score":              score,
        "max":                7,
        "distance_p1_to_p2":  dist_1to2,
        "distance_p2_to_p1":  dist_2to1,
        "dosha_active":       dosha_active,
        "cancellations":      cancellations,
        "applicable_cancellation_rules": BHAKOOT_CANCELLATIONS,
    }


def _nadi_kuta(p1_nak: str, p2_nak: str,
               p1_moon_sign: str, p2_moon_sign: str) -> Dict[str, Any]:
    """Nadi Kuta — body constitution (most weighted)."""
    n1 = NAKSHATRA_TO_NADI.get(p1_nak, "Adi")
    n2 = NAKSHATRA_TO_NADI.get(p2_nak, "Adi")
    same_nadi = (n1 == n2)

    cancellations: List[str] = []
    if p1_moon_sign == p2_moon_sign:
        cancellations.append("Both Moons in same sign")
    if p1_nak == p2_nak:
        cancellations.append("Both natives in same Nakshatra (different padas required)")
    l1 = SIGN_TO_LORD.get(p1_moon_sign)
    l2 = SIGN_TO_LORD.get(p2_moon_sign)
    if l1 and l2 and l1 == l2:
        cancellations.append("Moon-sign lords are the same planet")

    score = 0 if same_nadi else 8
    if same_nadi and cancellations:
        score = 4  # partial credit when cancellations apply

    return {
        "score":              score,
        "max":                8,
        "person1_nadi":       n1,
        "person2_nadi":       n2,
        "same_nadi":          same_nadi,
        "dosha_active":       same_nadi and not cancellations,
        "cancellations":      cancellations,
        "applicable_cancellation_rules": NADI_DOSHA_CANCELLATIONS,
    }


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT HANDLERS
# ════════════════════════════════════════════════════════════════════════

def handle_ashtakoot(person1: Dict[str, Any], person2: Dict[str, Any],
                     relationship_type: str = "marriage") -> Dict[str, Any]:
    """Endpoint 2: Full 8-Kuta 36-point matching."""
    _, e1 = _build_person(person1)
    _, e2 = _build_person(person2)

    p1_nak = e1.get("moon_nakshatra")
    p2_nak = e2.get("moon_nakshatra")
    p1_moon = e1.get("moon_sign")
    p2_moon = e2.get("moon_sign")
    p1_moon_lord = SIGN_TO_LORD.get(p1_moon)
    p2_moon_lord = SIGN_TO_LORD.get(p2_moon)
    p1_gender = person1.get("gender", "M")
    p2_gender = person2.get("gender", "F")

    if not (p1_nak and p2_nak and p1_moon and p2_moon):
        return {"error": "Could not extract Moon nakshatra/sign for both natives",
                "citation": CLASSICAL_CITATIONS["ashtakoot"]}

    varna   = _varna_kuta(p1_nak, p2_nak, p1_gender)
    vashya  = _vashya_kuta(p1_nak, p2_nak)
    tara    = _tara_kuta(p1_nak, p2_nak)
    yoni    = _yoni_kuta(p1_nak, p2_nak)
    graha   = _graha_maitri_kuta(p1_moon, p2_moon)
    gana    = _gana_kuta(p1_nak, p2_nak)
    bhakoot = _bhakoot_kuta(p1_moon, p2_moon, p1_moon_lord, p2_moon_lord)
    nadi    = _nadi_kuta(p1_nak, p2_nak, p1_moon, p2_moon)

    total_score = (varna["score"] + vashya["score"] + tara["score"] + yoni["score"]
                   + graha["score"] + gana["score"] + bhakoot["score"] + nadi["score"])

    if total_score >= 30:
        verdict = "excellent"
    elif total_score >= 24:
        verdict = "very_good"
    elif total_score >= 18:
        verdict = "good"
    else:
        verdict = "below_threshold"

    return {
        "person1_moon": {"sign": p1_moon, "nakshatra": p1_nak, "moon_lord": p1_moon_lord},
        "person2_moon": {"sign": p2_moon, "nakshatra": p2_nak, "moon_lord": p2_moon_lord},
        "kutas": {
            "varna":        varna,
            "vashya":       vashya,
            "tara":         tara,
            "yoni":         yoni,
            "graha_maitri": graha,
            "gana":         gana,
            "bhakoot":      bhakoot,
            "nadi":         nadi,
        },
        "total_score":      round(total_score, 2),
        "max_score":        36,
        "percentage":       round((total_score / 36) * 100, 1),
        "verdict":          verdict,
        "verdict_meaning":  ASHTAKOOT_RECOMMENDATION[verdict],
        "weights":          ASHTAKOOT_WEIGHTS,
        "citation":         CLASSICAL_CITATIONS["ashtakoot"],
    }


def _check_manglik(chart_essentials: Dict[str, Any]) -> Dict[str, Any]:
    """Check if a single chart is Manglik. Returns details + cancellations."""
    planets = chart_essentials.get("planets", {})
    mars = planets.get("Mars", {})
    if not mars:
        return {"is_manglik": False, "reason": "Mars data not found"}

    mars_sign = mars.get("sign")
    mars_house = mars.get("house")
    mars_dignity = mars.get("dignity", "")

    lagna_sign = chart_essentials.get("lagna_sign")
    moon_sign  = chart_essentials.get("moon_sign")
    venus = planets.get("Venus", {})
    venus_sign = venus.get("sign") if isinstance(venus, dict) else None

    # Check from Lagna, Moon, Venus
    from_lagna = _house_from_sign(mars_sign, lagna_sign) if (mars_sign and lagna_sign) else None
    from_moon  = _house_from_sign(mars_sign, moon_sign) if (mars_sign and moon_sign) else None
    from_venus = _house_from_sign(mars_sign, venus_sign) if (mars_sign and venus_sign) else None

    afflicting_houses: List[Tuple[str, int]] = []
    for ref_name, h in [("Lagna", from_lagna), ("Moon", from_moon), ("Venus", from_venus)]:
        if h is not None and h in MANGLIK_HOUSES:
            afflicting_houses.append((ref_name, h))

    is_manglik = len(afflicting_houses) > 0

    # Check cancellations
    cancellations_active: List[str] = []
    if is_manglik:
        if mars_sign in ("Aries", "Scorpio"):
            cancellations_active.append("Mars in own sign (Aries/Scorpio) — cancellation applies")
        if mars_sign == "Capricorn":
            cancellations_active.append("Mars exalted in Capricorn — cancellation applies")
        if mars_dignity in ("exalted", "own", "moolatrikona"):
            cancellations_active.append(f"Mars in '{mars_dignity}' dignity — strength-based cancellation")
        if mars_sign == "Cancer" and from_lagna == 1:
            cancellations_active.append("Debilitated Mars in 1st house — dosha mitigated")

    return {
        "is_manglik":              is_manglik,
        "afflicting_references":   [{"from": r, "house": h} for r, h in afflicting_houses],
        "mars_sign":               mars_sign,
        "mars_house":              mars_house,
        "mars_dignity":            mars_dignity,
        "house_from_lagna":        from_lagna,
        "house_from_moon":         from_moon,
        "house_from_venus":        from_venus,
        "cancellations_active":    cancellations_active,
        "effective_dosha":         is_manglik and not cancellations_active,
    }


def handle_manglik(person1: Dict[str, Any], person2: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 3: Mars dosha for both charts + mutual cancellation check."""
    _, e1 = _build_person(person1)
    _, e2 = _build_person(person2)

    m1 = _check_manglik(e1)
    m2 = _check_manglik(e2)

    # Mutual cancellation: both Manglik
    mutual_cancellation = m1["is_manglik"] and m2["is_manglik"]

    if mutual_cancellation:
        verdict = "Both natives Manglik — doshas mutually cancel (classical rule)"
    elif m1["effective_dosha"] and m2["effective_dosha"]:
        verdict = "Both have active Manglik dosha — combined remediation recommended"
    elif m1["effective_dosha"] and not m2["is_manglik"]:
        verdict = "Person 1 has active Manglik dosha — match cautioned per classical texts"
    elif m2["effective_dosha"] and not m1["is_manglik"]:
        verdict = "Person 2 has active Manglik dosha — match cautioned per classical texts"
    elif (m1["is_manglik"] and m1["cancellations_active"]) or \
         (m2["is_manglik"] and m2["cancellations_active"]):
        verdict = "Manglik present but classically cancelled — proceed normally"
    else:
        verdict = "Neither native Manglik — no Mars dosha concern"

    return {
        "person1": m1,
        "person2": m2,
        "mutual_cancellation":          mutual_cancellation,
        "verdict":                      verdict,
        "applicable_cancellation_rules":MANGLIK_CANCELLATIONS,
        "citation":                     CLASSICAL_CITATIONS["manglik"],
    }


def handle_nadi_dosha(person1: Dict[str, Any], person2: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 4: Detailed Nadi Kuta analysis."""
    _, e1 = _build_person(person1)
    _, e2 = _build_person(person2)
    p1_nak = e1.get("moon_nakshatra")
    p2_nak = e2.get("moon_nakshatra")
    p1_moon = e1.get("moon_sign")
    p2_moon = e2.get("moon_sign")

    nadi = _nadi_kuta(p1_nak, p2_nak, p1_moon, p2_moon)
    return {
        "person1": {"nakshatra": p1_nak, "moon_sign": p1_moon, "nadi": nadi["person1_nadi"]},
        "person2": {"nakshatra": p2_nak, "moon_sign": p2_moon, "nadi": nadi["person2_nadi"]},
        "kuta":    nadi,
        "note":    "Nadi Kuta is the most weighted of Ashtakoot (8 of 36 points). Same Nadi = body constitution conflict per classical Ayurveda-astrology synthesis.",
        "citation":CLASSICAL_CITATIONS["nadi_dosha"],
    }


def handle_bhakoot_dosha(person1: Dict[str, Any], person2: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 5: Detailed Bhakoot Kuta analysis."""
    _, e1 = _build_person(person1)
    _, e2 = _build_person(person2)
    p1_moon = e1.get("moon_sign")
    p2_moon = e2.get("moon_sign")
    p1_moon_lord = SIGN_TO_LORD.get(p1_moon)
    p2_moon_lord = SIGN_TO_LORD.get(p2_moon)

    kuta = _bhakoot_kuta(p1_moon, p2_moon, p1_moon_lord, p2_moon_lord)
    return {
        "person1": {"moon_sign": p1_moon, "moon_lord": p1_moon_lord},
        "person2": {"moon_sign": p2_moon, "moon_lord": p2_moon_lord},
        "kuta":    kuta,
        "citation":CLASSICAL_CITATIONS["bhakoot"],
    }


def handle_dasha_compatibility(person1: Dict[str, Any], person2: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 6: Current and upcoming dasha overlap analysis."""
    _, e1 = _build_person(person1)
    _, e2 = _build_person(person2)

    md1 = e1.get("current_md")
    ad1 = e1.get("current_ad")
    md2 = e2.get("current_md")
    ad2 = e2.get("current_ad")

    # Friendliness of currently-running planetary periods
    md_relation = _planet_relation(md1, md2) if (md1 and md2) else "unknown"
    ad_relation = _planet_relation(ad1, ad2) if (ad1 and ad2) else "unknown"

    if md_relation == "friend" and ad_relation == "friend":
        verdict = "Highly favorable — both Maha and Antar dashas are mutual friends"
    elif md_relation == "friend":
        verdict = "Favorable Maha dasha alignment; Antar dasha may bring nuanced moments"
    elif md_relation == "enemy" and ad_relation == "enemy":
        verdict = "Challenging period — both current dashas at mutual enmity; specific remediation recommended"
    elif md_relation == "neutral" and ad_relation == "neutral":
        verdict = "Neutral period — neither obstacle nor strong support from current dashas"
    else:
        verdict = "Mixed signals — review specific dasha phases for nuance"

    return {
        "person1": {
            "current_md": md1, "current_ad": ad1,
            "md_full":    e1.get("current_md_full"),
            "ad_full":    e1.get("current_ad_full"),
        },
        "person2": {
            "current_md": md2, "current_ad": ad2,
            "md_full":    e2.get("current_md_full"),
            "ad_full":    e2.get("current_ad_full"),
        },
        "md_mutual_relation": md_relation,
        "ad_mutual_relation": ad_relation,
        "verdict":            verdict,
        "citation":           CLASSICAL_CITATIONS["synastry"],
    }


def handle_synastry_aspects(person1: Dict[str, Any], person2: Dict[str, Any]) -> Dict[str, Any]:
    """
    Endpoint 7: Cross-aspect synthesis. Maps each of person1's planets onto person2's
    natal houses (and vice versa). Highlights significant overlays.
    """
    r1, e1 = _build_person(person1)
    r2, e2 = _build_person(person2)
    p1_lagna = e1.get("lagna_sign")
    p2_lagna = e2.get("lagna_sign")

    def overlay(person_a_planets: Dict[str, Any], person_b_lagna: str) -> List[Dict[str, Any]]:
        out = []
        for planet, pdata in person_a_planets.items():
            if not isinstance(pdata, dict):
                continue
            sign = pdata.get("sign")
            if not sign:
                continue
            house_in_b = _house_from_sign(sign, person_b_lagna)
            if house_in_b is None:
                continue
            out.append({
                "planet":         planet,
                "sign":           sign,
                "house_in_partner_chart": house_in_b,
                "life_area_in_partner":   HOUSE_TO_LIFE_AREA.get(house_in_b, ""),
            })
        return out

    overlay_1on2 = overlay(e1.get("planets", {}), p2_lagna)
    overlay_2on1 = overlay(e2.get("planets", {}), p1_lagna)

    # Identify the most relationship-relevant overlays (planets in 7th, 5th, 4th of partner)
    def critical_hits(overlay_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        return [o for o in overlay_list if o["house_in_partner_chart"] in (4, 5, 7, 8, 11, 12)]

    return {
        "person1_lagna": p1_lagna,
        "person2_lagna": p2_lagna,
        "overlay_person1_on_person2":   overlay_1on2,
        "overlay_person2_on_person1":   overlay_2on1,
        "critical_hits_p1_on_p2":       critical_hits(overlay_1on2),
        "critical_hits_p2_on_p1":       critical_hits(overlay_2on1),
        "note":                         "Cross-house overlays show how each person activates areas of the other's life. Houses 4 (home), 5 (romance/children), 7 (partnership), 8 (intimacy/longevity), 11 (gains), 12 (bed pleasures) are most marriage-relevant.",
        "citation":                     CLASSICAL_CITATIONS["synastry"],
    }


def handle_d9_navamsha_compat(person1: Dict[str, Any], person2: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 8: D9 Navamsha marriage-chart synthesis."""
    r1, e1 = _build_person(person1)
    r2, e2 = _build_person(person2)

    # D9 Lagna from raw chart
    p1_d9_lagna = r1.get("lagna", {}).get("d9_sign")
    p2_d9_lagna = r2.get("lagna", {}).get("d9_sign")

    # D9 Venus and D9 Jupiter (marriage karakas)
    def d9_planet(raw_chart, planet):
        p = raw_chart.get("planets", {}).get(planet, {})
        return {
            "d9_sign":  p.get("d9_sign") if isinstance(p, dict) else None,
            "rashi_sign": p.get("sign") if isinstance(p, dict) else None,
        }

    p1_d9_venus = d9_planet(r1, "Venus")
    p2_d9_venus = d9_planet(r2, "Venus")
    p1_d9_jupiter = d9_planet(r1, "Jupiter")
    p2_d9_jupiter = d9_planet(r2, "Jupiter")
    p1_d9_seventh_lord = SIGN_TO_LORD.get(_seventh_sign(p1_d9_lagna))
    p2_d9_seventh_lord = SIGN_TO_LORD.get(_seventh_sign(p2_d9_lagna))

    # Same D9 Lagna or 7th-from is a major harmony indicator
    matches: List[str] = []
    if p1_d9_lagna and p2_d9_lagna:
        if p1_d9_lagna == p2_d9_lagna:
            matches.append("Both share same D9 Lagna — deep underlying harmony")
        if _house_from_sign(p1_d9_lagna, p2_d9_lagna) == 7 or \
           _house_from_sign(p2_d9_lagna, p1_d9_lagna) == 7:
            matches.append("D9 Lagnas are 7-apart — natural marriage axis")

    if p1_d9_venus["d9_sign"] == p2_d9_venus["d9_sign"]:
        matches.append("D9 Venus signs match — aesthetic/sensual harmony")
    if p1_d9_jupiter["d9_sign"] == p2_d9_jupiter["d9_sign"]:
        matches.append("D9 Jupiter signs match — wisdom/dharma harmony")

    return {
        "person1": {
            "d9_lagna":      p1_d9_lagna,
            "d9_venus":      p1_d9_venus,
            "d9_jupiter":    p1_d9_jupiter,
            "d9_7th_sign":   _seventh_sign(p1_d9_lagna),
            "d9_7th_lord":   p1_d9_seventh_lord,
        },
        "person2": {
            "d9_lagna":      p2_d9_lagna,
            "d9_venus":      p2_d9_venus,
            "d9_jupiter":    p2_d9_jupiter,
            "d9_7th_sign":   _seventh_sign(p2_d9_lagna),
            "d9_7th_lord":   p2_d9_seventh_lord,
        },
        "harmony_indicators":  matches,
        "note":                "D9 (Navamsha) is the marriage chart per BPHS — strongest indicator of marital essence beyond rashi-level cosmetics.",
        "citation":            CLASSICAL_CITATIONS["navamsha"],
    }


def _seventh_sign(sign: Optional[str]) -> Optional[str]:
    """Return the sign opposite (7th from) the given sign."""
    idx = _sign_index(sign)
    if idx is None:
        return None
    return SIGNS_ORDER[(idx + 6) % 12]


def handle_seventh_house_synthesis(person1: Dict[str, Any], person2: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 9: Both 7th houses analyzed."""
    _, e1 = _build_person(person1)
    _, e2 = _build_person(person2)

    def seventh_analysis(essentials: Dict[str, Any]) -> Dict[str, Any]:
        lagna = essentials.get("lagna_sign")
        seventh = _seventh_sign(lagna)
        seventh_lord = SIGN_TO_LORD.get(seventh) if seventh else None
        # Find seventh lord's data
        lord_data = essentials.get("planets", {}).get(seventh_lord, {}) if seventh_lord else {}
        # Planets in 7th house
        planets_in_7th: List[str] = []
        for planet, pdata in essentials.get("planets", {}).items():
            if isinstance(pdata, dict) and pdata.get("house") == 7:
                planets_in_7th.append(planet)
        return {
            "lagna":             lagna,
            "seventh_sign":      seventh,
            "seventh_lord":      seventh_lord,
            "seventh_lord_data": {
                "sign":           lord_data.get("sign"),
                "house":          lord_data.get("house"),
                "dignity":        lord_data.get("dignity"),
                "is_retrograde":  lord_data.get("is_retrograde", False),
                "is_combust":     lord_data.get("is_combust", False),
            },
            "planets_in_7th":   planets_in_7th,
        }

    return {
        "person1": seventh_analysis(e1),
        "person2": seventh_analysis(e2),
        "karakas": SEVENTH_HOUSE_KARAKAS,
        "note":    "7th house = partnership house. Lord's strength and any occupants tell the marital story for each individual.",
        "citation":CLASSICAL_CITATIONS["seventh_house"],
    }


def handle_venus_jupiter_synthesis(person1: Dict[str, Any], person2: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 10: Marriage karakas (Venus + Jupiter) cross-analysis."""
    _, e1 = _build_person(person1)
    _, e2 = _build_person(person2)

    def karaka_data(essentials: Dict[str, Any]) -> Dict[str, Any]:
        v = essentials.get("planets", {}).get("Venus", {})
        j = essentials.get("planets", {}).get("Jupiter", {})
        return {
            "venus": {
                "sign":          v.get("sign"),
                "house":         v.get("house"),
                "dignity":       v.get("dignity"),
                "is_retrograde": v.get("is_retrograde", False),
                "is_combust":    v.get("is_combust", False),
            },
            "jupiter": {
                "sign":          j.get("sign"),
                "house":         j.get("house"),
                "dignity":       j.get("dignity"),
                "is_retrograde": j.get("is_retrograde", False),
                "is_combust":    j.get("is_combust", False),
            },
        }

    k1 = karaka_data(e1)
    k2 = karaka_data(e2)

    cross_observations: List[str] = []
    if k1["venus"]["sign"] == k2["venus"]["sign"]:
        cross_observations.append("Venus signs match — aesthetic and pleasure preferences aligned")
    if k1["jupiter"]["sign"] == k2["jupiter"]["sign"]:
        cross_observations.append("Jupiter signs match — life philosophy and dharma aligned")
    if k1["venus"]["dignity"] in ("exalted", "own") and k2["venus"]["dignity"] in ("exalted", "own"):
        cross_observations.append("Both Venuses in strong dignity — strong mutual attraction and harmony")

    return {
        "person1_karakas":    k1,
        "person2_karakas":    k2,
        "cross_observations": cross_observations,
        "note":               "Venus is karaka for spouse (male chart) and pleasure/harmony in marriage; Jupiter is karaka for husband (female chart) and ethical bonds.",
        "citation":           CLASSICAL_CITATIONS["venus_jupiter"],
    }


def handle_longevity_match(person1: Dict[str, Any], person2: Dict[str, Any]) -> Dict[str, Any]:
    """Endpoint 11: 8th house comparison for joint longevity."""
    _, e1 = _build_person(person1)
    _, e2 = _build_person(person2)

    def eighth_analysis(essentials: Dict[str, Any]) -> Dict[str, Any]:
        lagna = essentials.get("lagna_sign")
        idx = _sign_index(lagna)
        if idx is None:
            return {"lagna": lagna, "eighth_sign": None, "eighth_lord": None}
        eighth_sign = SIGNS_ORDER[(idx + 7) % 12]
        eighth_lord = SIGN_TO_LORD.get(eighth_sign)
        lord_data = essentials.get("planets", {}).get(eighth_lord, {}) if eighth_lord else {}
        planets_in_8th = [p for p, pd in essentials.get("planets", {}).items()
                          if isinstance(pd, dict) and pd.get("house") == 8]
        return {
            "lagna":              lagna,
            "eighth_sign":        eighth_sign,
            "eighth_lord":        eighth_lord,
            "eighth_lord_house":  lord_data.get("house") if isinstance(lord_data, dict) else None,
            "eighth_lord_dignity":lord_data.get("dignity") if isinstance(lord_data, dict) else None,
            "planets_in_8th":     planets_in_8th,
        }

    p1_8 = eighth_analysis(e1)
    p2_8 = eighth_analysis(e2)

    def strength_score(eighth_data: Dict[str, Any]) -> int:
        score = 0
        d = eighth_data.get("eighth_lord_dignity", "")
        if d in ("exalted", "own", "moolatrikona"):
            score += 3
        elif d in ("friend", "great_friend"):
            score += 1
        elif d in ("debilitated", "great_enemy"):
            score -= 2
        if eighth_data.get("eighth_lord_house") in (6, 8, 12):
            score -= 1
        return score

    s1 = strength_score(p1_8)
    s2 = strength_score(p2_8)
    diff = abs(s1 - s2)

    if s1 >= 2 and s2 >= 2:
        bucket = "strong_both"
    elif s1 <= -1 and s2 <= -1:
        bucket = "weak_both"
    elif diff <= 1:
        bucket = "matched"
    else:
        bucket = "mismatched"

    return {
        "person1_eighth":        p1_8,
        "person1_strength":      s1,
        "person2_eighth":        p2_8,
        "person2_strength":      s2,
        "match_bucket":          bucket,
        "match_interpretation":  LONGEVITY_BUCKETS[bucket],
        "note":                  "Joint longevity (Ayur) per Jataka Parijata Ch. 14 — compares 8th house lord strength between partners.",
        "citation":              CLASSICAL_CITATIONS["longevity"],
    }


def handle_timing_for_marriage(person1: Dict[str, Any], person2: Dict[str, Any]) -> Dict[str, Any]:
    """
    Endpoint 12: Marriage muhurta general guidance for the pair.
    Returns classical considerations + each partner's favorable dasha periods.
    """
    _, e1 = _build_person(person1)
    _, e2 = _build_person(person2)

    p1_md = e1.get("current_md")
    p1_ad = e1.get("current_ad")
    p2_md = e2.get("current_md")
    p2_ad = e2.get("current_ad")

    # For marriage timing: Venus, Jupiter, Moon, 7th-lord, 2nd-lord MD/AD periods are favorable
    p1_marriage_lords = [SIGN_TO_LORD.get(_seventh_sign(e1.get("lagna_sign")))]
    p2_marriage_lords = [SIGN_TO_LORD.get(_seventh_sign(e2.get("lagna_sign")))]
    favorable_planets = {"Venus", "Jupiter", "Moon"}
    favorable_planets.update([l for l in p1_marriage_lords if l])
    favorable_planets.update([l for l in p2_marriage_lords if l])

    p1_favorable_now = (p1_md in favorable_planets) or (p1_ad in favorable_planets)
    p2_favorable_now = (p2_md in favorable_planets) or (p2_ad in favorable_planets)

    return {
        "person1_current_dasha":   {"md": p1_md, "ad": p1_ad,
                                     "favorable_for_marriage": p1_favorable_now},
        "person2_current_dasha":   {"md": p2_md, "ad": p2_ad,
                                     "favorable_for_marriage": p2_favorable_now},
        "favorable_dasha_planets": sorted(favorable_planets),
        "classical_muhurta_rules": [
            "Avoid Mala-masa, Kshaya-masa, and Adhika-masa",
            "Avoid eclipse periods (15 days before/after)",
            "Moon should be strong, in a sign favorable to both natives",
            "Avoid Bhadra Karana, Vyatipata Yoga, Vaidhriti Yoga",
            "Favor Friday, Wednesday, Thursday (Venus, Mercury, Jupiter days)",
            "Avoid Rahu Kaal, Yamaganda, Gulika Kalam for the muhurta moment",
            "7th house should be uncluttered by malefics at muhurta moment",
            "Both natives' 7th lord and Venus/Jupiter strong at muhurta",
        ],
        "best_months_classically":  "Magha, Phalguna, Vaishakha, Jyeshtha (Hindu lunar months traditionally favored)",
        "note":                     "For exact date selection, use C3 Muhurta endpoint with proposed candidate dates.",
        "citation":                 CLASSICAL_CITATIONS["muhurta_marriage"],
    }


def handle_profile(person1: Dict[str, Any], person2: Dict[str, Any],
                   relationship_type: str = "marriage") -> Dict[str, Any]:
    """Endpoint 1 (MASTER): Full compatibility synthesis."""
    ashtakoot = handle_ashtakoot(person1, person2, relationship_type)
    manglik   = handle_manglik(person1, person2)
    seventh   = handle_seventh_house_synthesis(person1, person2)
    karakas   = handle_venus_jupiter_synthesis(person1, person2)
    longevity = handle_longevity_match(person1, person2)
    d9        = handle_d9_navamsha_compat(person1, person2)
    dasha     = handle_dasha_compatibility(person1, person2)

    # Headlines
    headlines: List[str] = []
    if "verdict" in ashtakoot:
        headlines.append(f"Ashtakoot: {ashtakoot['total_score']}/36 ({ashtakoot['verdict']}) — {ashtakoot['verdict_meaning']}")
    headlines.append(f"Manglik: {manglik['verdict']}")
    if longevity["match_bucket"] != "matched":
        headlines.append(f"Longevity match: {longevity['match_bucket']} — review classical implications")
    if d9.get("harmony_indicators"):
        headlines.append(f"D9 (Navamsha) harmony: {len(d9['harmony_indicators'])} positive indicator(s)")
    if karakas.get("cross_observations"):
        headlines.append("Marriage karakas (Venus/Jupiter) show cross-resonance")

    return {
        "relationship_type":    relationship_type,
        "headlines":            headlines,
        "ashtakoot":            ashtakoot,
        "manglik":              manglik,
        "seventh_house":        seventh,
        "marriage_karakas":     karakas,
        "longevity_match":      longevity,
        "d9_navamsha":          d9,
        "dasha_compatibility":  dasha,
        "method":               "Synthesis of Ashtakoot 36-point, Manglik dosha (with cancellations), 7th house analysis, Venus/Jupiter karakas, longevity (Ayur Bhava), D9 marriage chart, and current dasha compatibility.",
        "citations": {
            "primary":     CLASSICAL_CITATIONS["ashtakoot"],
            "manglik":     CLASSICAL_CITATIONS["manglik"],
            "synastry":    CLASSICAL_CITATIONS["synastry"],
            "d9":          CLASSICAL_CITATIONS["navamsha"],
            "longevity":   CLASSICAL_CITATIONS["longevity"],
        },
    }
