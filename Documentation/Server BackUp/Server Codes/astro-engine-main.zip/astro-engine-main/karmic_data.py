"""
karmic_data.py — Past Life / Karmic / Moksha classical reference.

Phase D — Module D1 (Past Life / Karmic).

Public catalogs:
    AK_BY_SIGN_THEMES            — Atmakaraka's sign reveals past-life soul lesson
    KARAKAMSHA_HOUSE_DIRECTIONS  — Where AK sits in D9 = soul's ultimate direction
    KETU_NAKSHATRA_KARMA         — Ketu's nakshatra reveals past-life skill/karma
    KETU_SIGN_PAST_LIFE          — Ketu's sign = what soul mastered before
    RAHU_FORWARD_KARMA           — Rahu shows what soul must develop now
    TWELFTH_HOUSE_MOKSHA         — 12th house themes for liberation
    KAAL_SARPA_TYPES             — Classical 12 named Kaal Sarpa types + meanings
    UPAPADA_KARMA                — UL sign reveals spouse-karma reading
    ARUDHA_INTERPRETATIONS       — A1-A12 classical names + worldly-projection meanings
    KARAKA_PAST_LIFE_LESSONS     — Each of 7 Jaimini karakas as past-life lesson
    CLASSICAL_CITATIONS

Sources: Jaimini Upadesha Sutras (~5th c. BCE),
         BPHS Ch. 32 (Karakamsha & Ishta Devata),
         Phaladeepika Ch. 6 (Arudha),
         Garga Hora classical commentary on Kaal Sarpa,
         Brihat Jataka on Ketu placement,
         Sri K.N. Rao classical writings (concepts public domain).
All sources public domain.
"""

from typing import Dict, List


# ════════════════════════════════════════════════════════════════════════
# ATMAKARAKA BY SIGN — Past-life theme of the soul
# Source: Jaimini Upadesha Sutras; BPHS Ch. 32
# ════════════════════════════════════════════════════════════════════════

AK_BY_SIGN_THEMES: Dict[str, Dict[str, str]] = {
    "Aries": {
        "past_life_role":  "Warrior, leader, pioneer, initiator",
        "core_lesson":     "Mastering individual will without ego; channeling courage into dharma",
        "shadow":          "Impulsiveness, anger, conquest-driven karma needing release",
        "soul_direction":  "From conquest to selfless leadership",
    },
    "Taurus": {
        "past_life_role":  "Caretaker of resources, sensualist, builder of comfort",
        "core_lesson":     "Releasing attachment to material security; valuing inner wealth",
        "shadow":          "Possessiveness, stubbornness, sensual indulgence karma",
        "soul_direction":  "From accumulation to sacred stewardship",
    },
    "Gemini": {
        "past_life_role":  "Communicator, scribe, teacher of facts, messenger",
        "core_lesson":     "Moving from information to wisdom; aligning speech with truth",
        "shadow":          "Duality, gossip, intellectual restlessness",
        "soul_direction":  "From clever speech to mantric power",
    },
    "Cancer": {
        "past_life_role":  "Nurturer, mother-figure, emotional protector",
        "core_lesson":     "Releasing emotional dependencies; nurturing without possession",
        "shadow":          "Over-attachment to family/past, emotional manipulation",
        "soul_direction":  "From clinging love to universal compassion",
    },
    "Leo": {
        "past_life_role":  "King, ruler, performer, center-of-attention figure",
        "core_lesson":     "Releasing ego-need for recognition; serving from heart not throne",
        "shadow":          "Pride, dominance, dramatized self-importance",
        "soul_direction":  "From royal ego to servant-leader heart",
    },
    "Virgo": {
        "past_life_role":  "Healer, servant, analyst, perfectionist",
        "core_lesson":     "Releasing critical mind; service without judgment",
        "shadow":          "Anxiety, over-analysis, harsh perfectionism",
        "soul_direction":  "From perfectionist service to surrendered devotion",
    },
    "Libra": {
        "past_life_role":  "Diplomat, lover, aesthete, partner-focused soul",
        "core_lesson":     "Finding self-truth beyond pleasing others; just relationships",
        "shadow":          "Indecision, dependency on partner, surface harmony",
        "soul_direction":  "From people-pleasing to inner sovereign balance",
    },
    "Scorpio": {
        "past_life_role":  "Occultist, alchemist, intense transformer, taboo-breaker",
        "core_lesson":     "Channeling intensity for transformation, not control",
        "shadow":          "Manipulation, jealousy, obsession with power",
        "soul_direction":  "From shadow mastery to luminous wisdom",
    },
    "Sagittarius": {
        "past_life_role":  "Teacher, philosopher, dharmic guide, foreign traveler",
        "core_lesson":     "Living the wisdom one teaches; humility in knowledge",
        "shadow":          "Dogmatism, preaching without practice, restless seeking",
        "soul_direction":  "From learning about dharma to becoming dharma",
    },
    "Capricorn": {
        "past_life_role":  "Achiever, structure-builder, sage of patience",
        "core_lesson":     "Mature responsibility from inner peace, not duty-burden",
        "shadow":          "Pessimism, rigidity, suppression of joy",
        "soul_direction":  "From earned achievement to natural authority through wisdom",
    },
    "Aquarius": {
        "past_life_role":  "Visionary, reformer, outsider with novel insights",
        "core_lesson":     "Connecting visions to ground; collective service over alienation",
        "shadow":          "Detachment as defense, rebellious for its own sake",
        "soul_direction":  "From eccentric vision to community-grounded innovation",
    },
    "Pisces": {
        "past_life_role":  "Mystic, dreamer, devotee, compassionate healer",
        "core_lesson":     "Discriminating compassion; not dissolving into others' pain",
        "shadow":          "Escapism, addiction, victim-savior dynamics",
        "soul_direction":  "From boundary-less merging to luminous discernment",
    },
}


# ════════════════════════════════════════════════════════════════════════
# KARAKAMSHA HOUSE DIRECTION — AK's D9 placement (counted from Lagna) shows soul's direction
# Source: BPHS Ch. 32 — Karakamsha as Soul's Direction
# ════════════════════════════════════════════════════════════════════════

KARAKAMSHA_HOUSE_DIRECTIONS: Dict[int, Dict[str, str]] = {
    1: {
        "theme":  "Self-realization through embodied authenticity",
        "lesson": "Soul incarnates to BE the lesson, not just learn it",
        "remedy": "Self-inquiry (Atma Vichara), Lagna-strengthening practices",
    },
    2: {
        "theme":  "Wealth, family, speech as vehicles for soul work",
        "lesson": "Use voice (speech, song) and resources for dharmic family transmission",
        "remedy": "Mantra recitation, family-lineage rituals, speech discipline",
    },
    3: {
        "theme":  "Effort, courage, communication as soul's tools",
        "lesson": "The soul learns through bold action and sibling-peer interactions",
        "remedy": "Writing, courageous self-expression, Hanuman worship",
    },
    4: {
        "theme":  "Home, emotional security, mother as soul-anchors",
        "lesson": "Inner peace and domestic stability are the soul's foundation",
        "remedy": "Service to mother/mother-figures, domestic puja, Moon mantras",
    },
    5: {
        "theme":  "Mantra, children, creativity, past-life merit as soul-fuel",
        "lesson": "Past-life punya manifests; develop creative spiritual practice",
        "remedy": "Intense mantra sadhana, mantric initiation, creative dharma work",
    },
    6: {
        "theme":  "Service, healing, overcoming obstacles as soul's path",
        "lesson": "Soul evolves through service, debt-clearing, and victory over inner enemies",
        "remedy": "Selfless service, fasting, Hanuman worship, medical/healing service",
    },
    7: {
        "theme":  "Partnerships and worldly engagement as soul's mirrors",
        "lesson": "The soul learns through one-on-one relationships and public engagement",
        "remedy": "Sacred partnership work, balanced engagement with others",
    },
    8: {
        "theme":  "Occult, transformation, mortality as soul's teachers",
        "lesson": "Deep transformation through crises; occult mastery; mortality awareness",
        "remedy": "Tantric sadhana, occult study, mortality meditation, Kali worship",
    },
    9: {
        "theme":  "Dharma, guru, fortune, higher learning as soul's path",
        "lesson": "Soul fulfilling dharma — strong indicator of priest/teacher/guru role",
        "remedy": "Guru bhakti, pilgrimage, scripture study, teaching dharma",
    },
    10: {
        "theme":  "Public action, authority, profession as soul's stage",
        "lesson": "Soul does its work in the public eye; karma yoga through profession",
        "remedy": "Karma yoga, ethical leadership, public service",
    },
    11: {
        "theme":  "Gains, aspirations, networks as soul-themes",
        "lesson": "Fulfillment of soul desires; community-based dharma; abundant gains",
        "remedy": "Group sadhana, fulfilling community dharma, sharing abundance",
    },
    12: {
        "theme":  "Moksha, liberation, foreign settlement, dissolution (CLASSIC YOGI PLACEMENT)",
        "lesson": "Soul's direction is liberation itself — withdrawal, monastic tendencies, foreign/spiritual paths",
        "remedy": "Ekanta sadhana (solitude practice), withdrawal periods, charity, moksha-oriented practices",
    },
}


# ════════════════════════════════════════════════════════════════════════
# KETU PAST-LIFE READING by Nakshatra
# Source: Brihat Jataka commentary, traditional Vimshottari past-life interpretation
# ════════════════════════════════════════════════════════════════════════

KETU_NAKSHATRA_KARMA: Dict[str, str] = {
    "Ashwini":         "Past life as healer/physician; soul brings instinctive healing capacity",
    "Bharani":         "Past life dealing with death/transformation rites; intense karmic completion",
    "Krittika":        "Past life as fire-keeper/warrior; sharp discernment carried forward",
    "Rohini":          "Past life of sensual indulgence or artistic mastery; soul releases attachment to beauty",
    "Mrigashira":      "Past life of seeking/searching/exploration; soul carries restlessness for truth",
    "Ardra":           "Past life of suffering/intense emotion; tears as past karma carried",
    "Punarvasu":       "Past life of returning, repeated learning; soul has cyclical karma",
    "Pushya":          "Past life of nurturing/teaching; soul brings natural caretaker capacity",
    "Ashlesha":        "Past life dealing with serpents/occult/poisons; deep occult karma",
    "Magha":           "Past life of royal/ancestral connection; soul carries ancestral memory",
    "Purva Phalguni":  "Past life of pleasure-seeking; soul releases worldly enjoyment patterns",
    "Uttara Phalguni": "Past life of service/dharmic patronage; soul brings stable dharma karma",
    "Hasta":           "Past life of skilled handwork/craft; manual dexterity past-life skill",
    "Chitra":          "Past life of artistic/architectural creation; designer past life",
    "Swati":           "Past life of independent movement/trade; soul brings detachment",
    "Vishakha":        "Past life of seeking goals intensely; soul releases drive for outcomes",
    "Anuradha":        "Past life of devotion/friendship; soul carries deep loyalty karma",
    "Jyeshtha":        "Past life of leadership with burdens; soul releases authority attachment",
    "Mula":            "Past life of uprooting/destruction; soul has karma of severe endings",
    "Purva Ashadha":   "Past life of invincibility-seeking; soul releases need to win",
    "Uttara Ashadha":  "Past life of victorious dharma; soul brings stable victory karma",
    "Shravana":        "Past life of listening/scripture-keeping; soul carries shruti karma",
    "Dhanishta":       "Past life of wealth/musical mastery; soul releases material/fame karma",
    "Shatabhisha":     "Past life as healer/mystic/secret-keeper; occult medical karma",
    "Purva Bhadrapada":"Past life of intense austerity; soul brings ascetic karma",
    "Uttara Bhadrapada":"Past life of deep wisdom retreat; soul carries cosmic-mind karma",
    "Revati":          "Past life of completion/devotion; soul has end-of-cycle karma",
}


# ════════════════════════════════════════════════════════════════════════
# KETU SIGN — What soul mastered in past life (skill/capacity carried forward)
# ════════════════════════════════════════════════════════════════════════

KETU_SIGN_PAST_LIFE: Dict[str, str] = {
    "Aries":       "Past mastery in courage, leadership, pioneering; soul releases competitive drive",
    "Taurus":      "Past mastery in resource-stewardship, comfort, sensual arts; soul releases material attachment",
    "Gemini":      "Past mastery in communication, learning, multiplicity; soul releases scattered curiosity",
    "Cancer":      "Past mastery in nurturing, emotional intelligence, domestic care; soul releases emotional dependency",
    "Leo":         "Past mastery in self-expression, leadership, performance; soul releases need for recognition",
    "Virgo":       "Past mastery in service, analysis, healing arts; soul releases perfectionism",
    "Libra":       "Past mastery in partnership, diplomacy, aesthetics; soul releases people-pleasing",
    "Scorpio":     "Past mastery in occult, transformation, intensity; soul releases obsession with depth",
    "Sagittarius": "Past mastery in teaching, philosophy, foreign travel; soul releases dogmatic seeking",
    "Capricorn":   "Past mastery in achievement, structure, patience; soul releases burden-of-duty karma",
    "Aquarius":    "Past mastery in vision, reform, group work; soul releases detached-outsider karma",
    "Pisces":      "Past mastery in mysticism, devotion, dissolution; soul releases escapist patterns",
}


# ════════════════════════════════════════════════════════════════════════
# RAHU FORWARD KARMA — what soul must develop in this life
# ════════════════════════════════════════════════════════════════════════

RAHU_FORWARD_KARMA: Dict[str, str] = {
    "Aries":       "Develop courage, initiative, individual will (move from group-passivity)",
    "Taurus":      "Develop material grounding, sensual presence (move from spiritual escapism)",
    "Gemini":      "Develop communication, intellectual flexibility (move from rigid certainty)",
    "Cancer":      "Develop emotional depth, nurturing (move from harsh self-reliance)",
    "Leo":         "Develop creative self-expression, personal authority (move from anonymous service)",
    "Virgo":       "Develop discrimination, service, methodical work (move from chaos/overwhelm)",
    "Libra":       "Develop partnership, harmony, balance (move from solo intensity)",
    "Scorpio":     "Develop emotional/sexual depth, transformation (move from surface comfort)",
    "Sagittarius": "Develop higher learning, dharma, big-picture vision (move from narrow knowledge)",
    "Capricorn":   "Develop responsibility, structure, mature authority (move from immaturity/dependency)",
    "Aquarius":    "Develop vision, innovation, group-soul work (move from ego-driven individualism)",
    "Pisces":      "Develop spiritual surrender, compassion, mystic seeing (move from materialism)",
}


# ════════════════════════════════════════════════════════════════════════
# 12TH HOUSE MOKSHA — Liberation themes by occupant/lord placement
# Source: BPHS Ch. 24 (Vyaya Bhava)
# ════════════════════════════════════════════════════════════════════════

TWELFTH_HOUSE_MOKSHA: Dict[str, Dict[str, str]] = {
    "occupant_Sun": {
        "moksha_path": "Liberation through release of ego-identification and individual will",
        "practice":    "Surya namaskar, Aditya Hridaya, dissolving 'I am the doer' identification",
    },
    "occupant_Moon": {
        "moksha_path": "Liberation through emotional release, mother-karma completion",
        "practice":    "Moon-honoring practices, mother-figure forgiveness, emotional surrender",
    },
    "occupant_Mars": {
        "moksha_path": "Liberation through controlled release of aggression; warrior-yogi path",
        "practice":    "Hanuman bhakti, controlled physical austerity, anger-transmutation",
    },
    "occupant_Mercury": {
        "moksha_path": "Liberation through mind-quieting; speech as sadhana",
        "practice":    "Mauna (silence) practice, mantra japa, intellectual surrender",
    },
    "occupant_Jupiter": {
        "moksha_path": "Liberation through wisdom and guru-bhakti; teaching-as-service",
        "practice":    "Scripture study, guru worship, teaching dharma freely",
    },
    "occupant_Venus": {
        "moksha_path": "Liberation through aesthetic surrender; bhakti through beauty",
        "practice":    "Sri Vidya, devotional arts, surrender through love",
    },
    "occupant_Saturn": {
        "moksha_path": "Liberation through structured renunciation; monastic discipline",
        "practice":    "Saturn fasting, monastic-style practice, karma-clearing through service",
    },
    "occupant_Rahu": {
        "moksha_path": "Liberation through foreign/unconventional spiritual paths",
        "practice":    "Cross-cultural sadhana, foreign teachers, novel spiritual approaches",
    },
    "occupant_Ketu": {
        "moksha_path": "Liberation through total dissolution; jivanmukta tendency",
        "practice":    "Advaita inquiry, complete withdrawal, dissolution practices",
    },
}


# ════════════════════════════════════════════════════════════════════════
# KAAL SARPA TYPES — Classical 12 named variants
# Source: Garga Hora, traditional Kaal Sarpa nivaran tradition
# Rahu-Ketu axis with all 7 planets between them forms full Kaal Sarpa
# Each type named by Rahu's position relative to a specific axis
# ════════════════════════════════════════════════════════════════════════

KAAL_SARPA_TYPES: Dict[str, Dict[str, str]] = {
    "Anant":     {"axis": "Rahu 1st, Ketu 7th",  "domain": "Self-identity vs partnerships; identity-shaking transformations"},
    "Kulik":     {"axis": "Rahu 2nd, Ketu 8th",  "domain": "Wealth/family vs occult/transformation; deep family-karmic cycles"},
    "Vasuki":    {"axis": "Rahu 3rd, Ketu 9th",  "domain": "Effort vs dharma; bold action testing inherited beliefs"},
    "Shankhapal":{"axis": "Rahu 4th, Ketu 10th", "domain": "Home/mother vs career; domestic-vs-worldly tension"},
    "Padma":     {"axis": "Rahu 5th, Ketu 11th", "domain": "Creativity/children vs gains; creative output redefining gains"},
    "Mahapadma": {"axis": "Rahu 6th, Ketu 12th", "domain": "Service/health vs moksha; healing-as-liberation path"},
    "Takshak":   {"axis": "Rahu 7th, Ketu 1st",  "domain": "Partnerships dissolving self-identity; karmic relationship dynamics"},
    "Karkotaka": {"axis": "Rahu 8th, Ketu 2nd",  "domain": "Occult/death vs wealth/family; intense transformation karma"},
    "Shankhachuda":{"axis":"Rahu 9th, Ketu 3rd", "domain": "Dharma vs effort; teaching-mission with earlier life withdrawal"},
    "Ghatak":    {"axis": "Rahu 10th, Ketu 4th", "domain": "Career vs domestic peace; profession-driven karma"},
    "Vishdhar":  {"axis": "Rahu 11th, Ketu 5th", "domain": "Networks/gains vs creativity/children; gain-vs-output karma"},
    "Sheshanag": {"axis": "Rahu 12th, Ketu 6th", "domain": "Foreign/moksha vs service/health; liberation-via-service path"},
}

KAAL_SARPA_PARTIAL_NOTE: str = (
    "Partial Kaal Sarpa — one or more planets fall OUTSIDE the Rahu-Ketu arc. "
    "The escaping planet(s) provide karmic relief in their domain. "
    "Mars outside = warrior/action energy provides karmic escape route. "
    "Sun outside = self-identity provides karmic escape. "
    "Moon outside = emotional intelligence provides karmic escape. "
    "Jupiter outside = wisdom/dharma provides karmic escape. "
    "Saturn outside = discipline/structure provides karmic escape. "
    "Venus outside = devotion/beauty provides karmic escape. "
    "Mercury outside = intellect/communication provides karmic escape."
)


# ════════════════════════════════════════════════════════════════════════
# UPAPADA — Spouse karma reading by UL sign
# Source: Jaimini Upadesha Sutras on Upapada Lagna
# ════════════════════════════════════════════════════════════════════════

UPAPADA_KARMA: Dict[str, str] = {
    "Aries":       "Spouse karma: warrior-type partner; relationship through dynamic conflict-resolution",
    "Taurus":      "Spouse karma: aesthetic/sensual partner; relationship through shared comfort and beauty",
    "Gemini":      "Spouse karma: intellectual partner; relationship through communication and dual-natured engagement",
    "Cancer":      "Spouse karma: nurturing/emotional partner; relationship through emotional security",
    "Leo":         "Spouse karma: charismatic/regal partner; relationship through mutual recognition",
    "Virgo":       "Spouse karma: service-oriented partner; relationship through practical care",
    "Libra":       "Spouse karma: harmonious partner; relationship through balance and aesthetic alignment",
    "Scorpio":     "Spouse karma: intense/transformative partner; relationship through deep transformation",
    "Sagittarius": "Spouse karma: dharmic/wise partner; relationship through shared philosophy",
    "Capricorn":   "Spouse karma: responsible/structured partner; relationship through duty and maturity",
    "Aquarius":    "Spouse karma: visionary/unusual partner; relationship through shared vision/reform",
    "Pisces":      "Spouse karma: spiritual/compassionate partner; relationship through mystical bond",
}


# ════════════════════════════════════════════════════════════════════════
# ARUDHA PADA INTERPRETATIONS — Worldly projections
# Source: Phaladeepika Ch. 6 (Arudha Padas); Jaimini Upadesha Sutras
# ════════════════════════════════════════════════════════════════════════

ARUDHA_INTERPRETATIONS: Dict[int, Dict[str, str]] = {
    1:  {"name": "Arudha Lagna (AL)",      "domain": "How the world sees the self"},
    2:  {"name": "Dhana Pada (A2)",        "domain": "Perceived wealth and family"},
    3:  {"name": "Vikrama Pada (A3)",      "domain": "Perceived effort, courage, sibling-relations"},
    4:  {"name": "Sukha Pada (A4)",        "domain": "Perceived home, comforts, mother"},
    5:  {"name": "Mantra Pada (A5)",       "domain": "Perceived intelligence, creativity, mantra-power"},
    6:  {"name": "Shatru Pada (A6)",       "domain": "Perceived enemies, debts, service"},
    7:  {"name": "Dara Pada (A7)",         "domain": "Perceived partner, business, spouse-image"},
    8:  {"name": "Mrityu Pada (A8)",       "domain": "Perceived transformations, occult interests"},
    9:  {"name": "Pitru Pada (A9)",        "domain": "Perceived dharma, father, fortune"},
    10: {"name": "Karma Pada (A10)",       "domain": "Perceived profession, public actions"},
    11: {"name": "Labha Pada (A11)",       "domain": "Perceived gains, social network"},
    12: {"name": "Upapada (UL/A12)",       "domain": "Spouse, marriage, secret losses"},
}


# ════════════════════════════════════════════════════════════════════════
# KARAKA PAST-LIFE LESSONS — Each Jaimini karaka as a karmic teacher
# Source: Jaimini Upadesha Sutras; classical Jaimini tradition
# ════════════════════════════════════════════════════════════════════════

KARAKA_PAST_LIFE_LESSONS: Dict[str, str] = {
    "Atmakaraka":   "The soul's primary unfinished business; the lesson the soul incarnated to master",
    "Amatyakaraka": "Past-life karmic relationship with profession, authority, public service",
    "Bhratrikaraka":"Past-life karma with siblings, peers, courage-development",
    "Matrikaraka":  "Past-life karma with mother, nurturing-receiving, emotional foundation",
    "Putrakaraka":  "Past-life karma with children, creativity, inherited spiritual merit",
    "Gnatikaraka":  "Past-life karma with obstacles, enemies, debts; lessons of perseverance",
    "Darakaraka":   "Past-life karma with spouse, partnership, intimate union",
}


# ════════════════════════════════════════════════════════════════════════
# REMEDIES FOR KARMIC PATTERNS
# ════════════════════════════════════════════════════════════════════════

KARMIC_REMEDIES: Dict[str, str] = {
    "kaal_sarpa":          "Naga Devata puja; Sarpa Sukta recitation; visit to nag temples; pitri tarpana on amavasya",
    "ketu_intense":        "Hanuman Chalisa daily; Ganesha worship before any new venture; striped flag (Dhwaja)",
    "rahu_intense":        "Durga Saptashati; Maa Kali bhakti; never quit a started task mid-way",
    "12th_strong":         "Ekanta sadhana (solitude); donate at sunset; sleep in clean space; foreign travel for karma-clearing",
    "ak_in_dushthana_d9":  "Ishta Devata worship intensified; AK's planet propitiation",
    "pitr_dosha_indicators":"Pitri tarpana on every amavasya; sraddha rituals; family lineage cleanup",
    "general":             "Tila daana (sesame donation); ekadashi fasting; Vishnu Sahasranama recitation",
}


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "karakamsha":     "BPHS Ch. 32 (Karakamsha Adhyaya); Jaimini Upadesha Sutras Ch. 1",
    "atmakaraka":     "Jaimini Upadesha Sutras; BPHS Ch. 32; classical Jaimini tradition",
    "ketu_past_life": "Brihat Jataka commentary on Ketu; traditional past-life astrology",
    "rahu_forward":   "Phaladeepika Ch. 5 (Rahu-Ketu); traditional nodal axis interpretation",
    "twelfth_house":  "BPHS Ch. 24 (Vyaya Bhava); Phaladeepika Ch. 12 (12th house)",
    "kaal_sarpa":     "Garga Hora; classical Kaal Sarpa nivaran tradition",
    "upapada":        "Jaimini Upadesha Sutras (Upapada Lagna); BPHS Ch. 35",
    "arudha":         "Phaladeepika Ch. 6 (Arudha Padas); Jaimini Upadesha Sutras",
    "ishta_devata":   "Jaimini Upadesha Sutras; classical Ishta Devata tradition via Karakamsha",
}
