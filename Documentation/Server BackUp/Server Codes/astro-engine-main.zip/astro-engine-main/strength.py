"""
strength.py — numiVeda Kaaliyo Astro Engine — Module F3 (Strength Analysis)

Three endpoints synthesizing planetary strength:
    handle_vimshopaka_bala        — 16-fold (Shodasavarga) combined strength
    handle_planetary_summary      — Shadbala + Vimshopaka + Ishta/Kashta synthesis
    handle_strength_comprehensive — All-in-one report with dasha context

Design (per HANDOVER_v5 carry-forward):
    P1 — All inputs come from cast_chart (existing engine).
    P2 — Reuse: Shadbala already exists at /astro/shadbala. F3 calls
         that endpoint's underlying chart["shadbala"] data structure,
         doesn't recompute. Vimshopaka is pure synthesis from pre-computed
         15 D-chart sign fields.
    P5 — F3 has its own _dignity_in_sign() primitive, independent of
         yogas_helpers (which uses a different vocabulary and is consumed
         by yoga catalogs). This isolation prevents F3 from creating
         downstream coupling.

Public API:
    handle_vimshopaka_bala(birth) -> dict
    handle_planetary_summary(birth) -> dict
    handle_strength_comprehensive(birth) -> dict

Author: Claude (F3, 2026-05-18)
"""

from typing import Dict, List, Optional, Any
from datetime import date

# Foundation imports (guarded at module load — Principle 1)
try:
    from dashaflow import cast_chart
except ImportError as e:
    raise ImportError(f"F3 strength requires dashaflow.cast_chart: {e}")

try:
    from astro_helpers import SIGNS_ORDER, SIGN_TO_LORD
except ImportError as e:
    raise ImportError(f"F3 strength requires astro_helpers: {e}")


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL DIGNITY TABLES (independent of yogas_helpers)
# ════════════════════════════════════════════════════════════════════════
# Vocabulary matches cast_chart native dignity field:
#   exalted, mooltrikona, own_sign, great_friend, friend,
#   neutral, enemy, great_enemy, debilitated

# Planet → its own (swakshetra) signs
_OWN_SIGNS = {
    "Sun":     ["Leo"],
    "Moon":    ["Cancer"],
    "Mars":    ["Aries", "Scorpio"],
    "Mercury": ["Gemini", "Virgo"],
    "Jupiter": ["Sagittarius", "Pisces"],
    "Venus":   ["Taurus", "Libra"],
    "Saturn":  ["Capricorn", "Aquarius"],
    "Rahu":    [],   # nodes have no own sign in classical scheme
    "Ketu":    [],
}

# Planet → exaltation sign
_EXALTATION = {
    "Sun":     "Aries",
    "Moon":    "Taurus",
    "Mars":    "Capricorn",
    "Mercury": "Virgo",
    "Jupiter": "Cancer",
    "Venus":   "Pisces",
    "Saturn":  "Libra",
    "Rahu":    "Taurus",       # some sources say Gemini; Taurus is most cited
    "Ketu":    "Scorpio",
}

# Planet → debilitation sign
_DEBILITATION = {
    "Sun":     "Libra",
    "Moon":    "Scorpio",
    "Mars":    "Cancer",
    "Mercury": "Pisces",
    "Jupiter": "Capricorn",
    "Venus":   "Virgo",
    "Saturn":  "Aries",
    "Rahu":    "Scorpio",
    "Ketu":    "Taurus",
}

# Planet → mooltrikona sign (single sign each per classical)
_MOOLTRIKONA = {
    "Sun":     "Leo",          # 0-20° (we approximate as whole sign for sign-only check)
    "Moon":    "Taurus",       # 3-30°
    "Mars":    "Aries",        # 0-12°
    "Mercury": "Virgo",        # 15-20°
    "Jupiter": "Sagittarius",  # 0-10°
    "Venus":   "Libra",        # 0-15°
    "Saturn":  "Aquarius",     # 0-20°
}

# Naisargika (natural) friendships per BPHS Ch. 3
# F = great_friend, f = friend, n = neutral, e = enemy, E = great_enemy
_NAISARGIKA_FRIENDS = {
    "Sun":     {"Moon": "f", "Mars": "f", "Mercury": "n", "Jupiter": "f",
                  "Venus": "e", "Saturn": "e"},
    "Moon":    {"Sun": "f", "Mars": "n", "Mercury": "f", "Jupiter": "n",
                  "Venus": "n", "Saturn": "n"},
    "Mars":    {"Sun": "f", "Moon": "f", "Mercury": "e", "Jupiter": "f",
                  "Venus": "n", "Saturn": "n"},
    "Mercury": {"Sun": "f", "Moon": "e", "Mars": "n", "Jupiter": "n",
                  "Venus": "f", "Saturn": "n"},
    "Jupiter": {"Sun": "f", "Moon": "f", "Mars": "f", "Mercury": "e",
                  "Venus": "e", "Saturn": "n"},
    "Venus":   {"Sun": "e", "Moon": "e", "Mars": "n", "Mercury": "f",
                  "Jupiter": "n", "Saturn": "f"},
    "Saturn":  {"Sun": "e", "Moon": "e", "Mars": "e", "Mercury": "f",
                  "Jupiter": "n", "Venus": "f"},
}


def _dignity_in_sign(planet: str, sign: str) -> str:
    """
    Return the classical dignity of <planet> in <sign>.

    Uses Naisargika (natural) friendship for non-special cases. Returns one of:
      exalted, mooltrikona, own_sign, friend, neutral, enemy, debilitated

    Note: doesn't compute "great_friend" / "great_enemy" because the proper
    compound (Naisargika + Tatkalika) requires the rest of the chart for
    Tatkalika. Each varga is considered standalone here. This matches BPHS
    Ch. 35's Vimshopaka approach which uses sign-based (Naisargika) dignity
    per varga, not chart-context compound.
    """
    if not sign or sign not in SIGNS_ORDER:
        return "neutral"

    # Exalted / debilitated / mooltrikona / own
    if sign == _EXALTATION.get(planet):
        return "exalted"
    if sign == _DEBILITATION.get(planet):
        return "debilitated"
    if sign == _MOOLTRIKONA.get(planet):
        return "mooltrikona"
    if sign in _OWN_SIGNS.get(planet, []):
        return "own_sign"

    # Friend/enemy via dispositor (sign's lord)
    dispositor = SIGN_TO_LORD.get(sign)
    if not dispositor or dispositor == planet:
        return "neutral"

    # Nodes (Rahu/Ketu) use neutral when not exalted/debilitated
    if planet in ("Rahu", "Ketu"):
        return "neutral"

    rel = _NAISARGIKA_FRIENDS.get(planet, {}).get(dispositor, "n")
    return {
        "F": "great_friend",
        "f": "friend",
        "n": "neutral",
        "e": "enemy",
        "E": "great_enemy",
    }.get(rel, "neutral")


# ════════════════════════════════════════════════════════════════════════
# VIMSHOPAKA BALA (BPHS Ch. 35)
# ════════════════════════════════════════════════════════════════════════

# BPHS Shodasavarga weights — sum to 20.0 (hence "vimshopaka" = 20-fold)
_VIMSHOPAKA_WEIGHTS = {
    "d1":  3.5,   # Rasi
    "d2":  1.0,   # Hora
    "d3":  1.0,   # Drekkana
    "d4":  0.5,   # Chaturthamsa
    "d7":  0.5,   # Saptamsa
    "d9":  3.0,   # Navamsa
    "d10": 0.5,   # Dasamsa
    "d12": 0.5,   # Dvadasamsa
    "d16": 2.0,   # Shodasamsa
    "d20": 0.5,   # Vimsamsa
    "d24": 0.5,   # Chaturvimsamsa
    "d27": 0.5,   # Saptavimsamsa
    "d30": 1.0,   # Trimsamsa
    "d40": 0.5,   # Khavedamsa
    "d45": 0.5,   # Akshavedamsa
    "d60": 4.0,   # Shastiamsa (most weighted)
}

# Dignity → points per varga (BPHS Ch. 35; scaled to /20)
_DIGNITY_POINTS = {
    "exalted":      20,
    "mooltrikona":  18,
    "own_sign":     18,    # classical treats own_sign and mooltrikona similarly
    "great_friend": 15,
    "friend":       12,
    "neutral":       8,
    "enemy":         4,
    "great_enemy":   2,
    "debilitated":   1,
}

_VIMSHOPAKA_NAMES = {
    "d1": "Rasi", "d2": "Hora", "d3": "Drekkana", "d4": "Chaturthamsa",
    "d7": "Saptamsa", "d9": "Navamsa", "d10": "Dasamsa", "d12": "Dvadasamsa",
    "d16": "Shodasamsa", "d20": "Vimsamsa", "d24": "Chaturvimsamsa",
    "d27": "Saptavimsamsa", "d30": "Trimsamsa", "d40": "Khavedamsa",
    "d45": "Akshavedamsa", "d60": "Shastiamsa",
}

# Vimshopaka score interpretation bands
def _vimshopaka_band(score: float) -> str:
    """BPHS Ch. 35 interpretation bands for Vimshopaka Bala."""
    if score >= 18.0: return "purna"          # complete strength
    if score >= 15.0: return "uttama"          # excellent
    if score >= 10.0: return "madhyama"        # middling
    if score >= 5.0:  return "alpa"            # weak
    return "nirbala"                            # very weak


_BAND_NARRATIVES = {
    "purna":    "Complete strength (purna). Planet produces its highest classical results — direct, unblocked, sustained.",
    "uttama":   "Excellent strength (uttama). Reliable significations with minor friction. Among the strongest planets in the chart.",
    "madhyama": "Middling strength (madhyama). Mixed results — significations produce when other supporting factors align.",
    "alpa":     "Weak strength (alpa). Significations require explicit remediation or supporting transits to manifest.",
    "nirbala":  "Very weak (nirbala). Significations may not reliably manifest. Classical tradition recommends sustained remediation for this planet's house lordships.",
}


def _compute_vimshopaka_for_planet(planet: str, chart: Dict[str, Any]) -> Dict[str, Any]:
    """
    Compute Vimshopaka Bala for a single planet across all 16 vargas.

    Returns dict with:
      per_varga: [{varga, varga_name, sign, dignity, dignity_points, weight, contribution}]
      total_score: 0-20
      band: purna/uttama/madhyama/alpa/nirbala
    """
    pdata = chart["planets"].get(planet, {})
    per_varga = []
    total_score = 0.0

    for varga, weight in _VIMSHOPAKA_WEIGHTS.items():
        # Get planet's sign in this varga
        if varga == "d1":
            sign = pdata.get("sign")
        else:
            sign = pdata.get(f"{varga}_sign")

        if not sign:
            # Missing data — skip but record
            per_varga.append({
                "varga":          varga,
                "varga_name":     _VIMSHOPAKA_NAMES[varga],
                "sign":           None,
                "dignity":        None,
                "dignity_points": 0,
                "weight":         weight,
                "contribution":   0.0,
            })
            continue

        dig = _dignity_in_sign(planet, sign)
        dig_points = _DIGNITY_POINTS.get(dig, 8)  # default neutral if unknown
        # Contribution = weight × (dignity_points / 20)
        # This normalizes so a planet "exalted in all 16 vargas" sums to 20.0
        contribution = weight * (dig_points / 20.0)
        total_score += contribution

        per_varga.append({
            "varga":          varga,
            "varga_name":     _VIMSHOPAKA_NAMES[varga],
            "sign":           sign,
            "dignity":        dig,
            "dignity_points": dig_points,
            "weight":         weight,
            "contribution":   round(contribution, 4),
        })

    return {
        "planet":      planet,
        "per_varga":   per_varga,
        "total_score": round(total_score, 3),
        "max_score":   20.0,
        "band":        _vimshopaka_band(total_score),
        "narrative":   _BAND_NARRATIVES[_vimshopaka_band(total_score)],
    }


def handle_vimshopaka_bala(birth: Dict[str, Any]) -> Dict[str, Any]:
    """
    F3 Endpoint: 16-fold Vimshopaka Bala (BPHS Ch. 35).

    Computes each planet's combined strength across all 16 divisional charts,
    weighted per BPHS prescription. Returns per-planet breakdown +
    classical interpretation band.
    """
    try:
        chart = cast_chart(
            dob=birth["dob"], time=birth["time"],
            lat=birth["lat"], lon=birth["lon"],
            timezone=birth.get("timezone", "Asia/Kolkata"),
        )
    except Exception as e:
        return {"error": f"Chart cast failed: {e}",
                 "citations": F3_CITATIONS["vimshopaka_bala"]}

    planets = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]
    results = {p: _compute_vimshopaka_for_planet(p, chart) for p in planets}

    # Ranking by total score
    ranked = sorted(
        [{"planet": p, "score": v["total_score"], "band": v["band"]}
         for p, v in results.items()],
        key=lambda x: -x["score"]
    )

    # Headline summary
    strongest = ranked[0]
    weakest = ranked[-1]
    summary = (
        f"Vimshopaka Bala (BPHS Ch. 35): strongest is {strongest['planet']} "
        f"at {strongest['score']:.2f}/20 ({strongest['band']}); "
        f"weakest is {weakest['planet']} at {weakest['score']:.2f}/20 ({weakest['band']})."
    )

    return {
        "success":            True,
        "natal_summary": {
            "lagna_sign":   chart.get("lagna", {}).get("sign"),
            "moon_sign":    chart.get("planets", {}).get("Moon", {}).get("sign"),
            "sun_sign":     chart.get("planets", {}).get("Sun", {}).get("sign"),
        },
        "vimshopaka_per_planet": results,
        "ranking":               ranked,
        "summary":               summary,
        "method": {
            "name":      "Vimshopaka Bala (Shodasavarga)",
            "weight_scheme": _VIMSHOPAKA_WEIGHTS,
            "dignity_points": _DIGNITY_POINTS,
            "bands": {
                "purna":    ">= 18.0",
                "uttama":   "15.0 - 17.99",
                "madhyama": "10.0 - 14.99",
                "alpa":     "5.0 - 9.99",
                "nirbala":  "< 5.0",
            },
        },
        "classical_sources": F3_CITATIONS["vimshopaka_bala"],
    }


# ════════════════════════════════════════════════════════════════════════
# PLANETARY SUMMARY — synthesis of Shadbala + Vimshopaka + Ishta/Kashta
# ════════════════════════════════════════════════════════════════════════

def _get_shadbala_data(chart: Dict[str, Any], planet: str) -> Dict[str, Any]:
    """Pull shadbala for a planet from chart data."""
    sb = chart.get("shadbala", {})
    return sb.get(planet, {}) if isinstance(sb, dict) else {}


def _functional_strength_verdict(shadbala: Dict[str, Any],
                                    vimshopaka_score: float) -> Dict[str, str]:
    """
    Combine Shadbala "is_strong" boolean + Vimshopaka score
    into a functional verdict.

    Returns verdict + classification + recommended action.
    """
    sb_strong = bool(shadbala.get("is_strong", False))
    sb_ratio = float(shadbala.get("strength_ratio", 0.0))
    v_band = _vimshopaka_band(vimshopaka_score)

    # Strong/weak across both systems
    if sb_strong and vimshopaka_score >= 15.0:
        verdict = "FULLY STRONG"
        narrative = ("Strong in both Shadbala and Vimshopaka. Planet's significations "
                      "manifest reliably across life areas. A reliable yogakaraka candidate.")
        recommendation = "Engage this planet's mantras/karakas in major life decisions."
    elif sb_strong and vimshopaka_score >= 10.0:
        verdict = "SHADBALA STRONG"
        narrative = ("Strong in Shadbala (D1 positional/temporal strength) but middling in "
                      "Vimshopaka (divisional reach). Strong in primary domain, mixed in nuance.")
        recommendation = "Trust for high-level outcomes; cross-check Navamsa for sustained themes."
    elif vimshopaka_score >= 15.0:
        verdict = "VIMSHOPAKA STRONG"
        narrative = ("Strong in divisional consensus (Vimshopaka) but below Shadbala minimum. "
                      "Sustained subtle strength across life areas; weaker in raw positional power.")
        recommendation = "Reliable for long-term themes; may need transit support for major events."
    elif sb_ratio >= 0.7 or vimshopaka_score >= 8.0:
        verdict = "MIDDLING"
        narrative = ("Middling across both systems. Significations produce when supporting "
                      "transits/dasha activate. Mixed manifestation pattern.")
        recommendation = "Watch dasha windows where this planet is supported."
    else:
        verdict = "WEAK"
        narrative = ("Weak in both Shadbala and Vimshopaka. Significations require explicit "
                      "remediation or favorable dasha-transit alignment to manifest.")
        recommendation = "Sustained classical remediation traditionally recommended."

    return {
        "verdict":         verdict,
        "narrative":       narrative,
        "recommendation":  recommendation,
        "shadbala_strong": sb_strong,
        "shadbala_ratio":  sb_ratio,
        "vimshopaka_band": v_band,
    }


def handle_planetary_summary(birth: Dict[str, Any]) -> Dict[str, Any]:
    """
    F3 Endpoint: Synthesis of Shadbala + Vimshopaka + Ishta/Kashta phala.

    For each planet, produces a functional strength verdict combining:
      - Shadbala (6-component positional+temporal strength, already computed)
      - Vimshopaka Bala (16-fold divisional consensus, F3 computes)
      - Ishta phala / Kashta phala (beneficial vs malefic — already in shadbala)
    """
    try:
        chart = cast_chart(
            dob=birth["dob"], time=birth["time"],
            lat=birth["lat"], lon=birth["lon"],
            timezone=birth.get("timezone", "Asia/Kolkata"),
        )
    except Exception as e:
        return {"error": f"Chart cast failed: {e}",
                 "citations": F3_CITATIONS["planetary_summary"]}

    planets = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]
    summary_per_planet = {}

    for p in planets:
        sb = _get_shadbala_data(chart, p)
        vimshopaka = _compute_vimshopaka_for_planet(p, chart)
        verdict_obj = _functional_strength_verdict(sb, vimshopaka["total_score"])

        # Ishta/Kashta ratio
        ishta = float(sb.get("ishta_phala", 0.0))
        kashta = float(sb.get("kashta_phala", 0.0))
        if ishta + kashta > 0:
            beneficial_ratio = ishta / (ishta + kashta)
        else:
            beneficial_ratio = 0.5

        if beneficial_ratio >= 0.65:
            phala_disposition = "predominantly beneficial (Ishta-dominant)"
        elif beneficial_ratio <= 0.35:
            phala_disposition = "predominantly malefic (Kashta-dominant)"
        else:
            phala_disposition = "mixed (balanced Ishta-Kashta)"

        summary_per_planet[p] = {
            "verdict":           verdict_obj["verdict"],
            "narrative":         verdict_obj["narrative"],
            "recommendation":    verdict_obj["recommendation"],
            "shadbala": {
                "total_rupas":    sb.get("total_rupas"),
                "required_rupas": sb.get("required_rupas"),
                "is_strong":      sb.get("is_strong"),
                "strength_ratio": sb.get("strength_ratio"),
            },
            "vimshopaka": {
                "score": vimshopaka["total_score"],
                "band":  vimshopaka["band"],
            },
            "phala": {
                "ishta":            ishta,
                "kashta":           kashta,
                "beneficial_ratio": round(beneficial_ratio, 3),
                "disposition":      phala_disposition,
            },
        }

    # Identify functional roles
    strong_planets = [p for p, v in summary_per_planet.items()
                       if v["verdict"] in ("FULLY STRONG", "SHADBALA STRONG", "VIMSHOPAKA STRONG")]
    weak_planets = [p for p, v in summary_per_planet.items()
                     if v["verdict"] == "WEAK"]
    needs_remediation = weak_planets[:]
    if not needs_remediation:
        # Find the lowest-scoring planet anyway
        worst = min(summary_per_planet.items(),
                     key=lambda x: x[1]["vimshopaka"]["score"])
        needs_remediation = [worst[0]]

    return {
        "success": True,
        "natal_summary": {
            "lagna_sign":   chart.get("lagna", {}).get("sign"),
            "moon_sign":    chart.get("planets", {}).get("Moon", {}).get("sign"),
            "sun_sign":     chart.get("planets", {}).get("Sun", {}).get("sign"),
        },
        "per_planet":         summary_per_planet,
        "functionally_strong": strong_planets,
        "functionally_weak":   weak_planets,
        "needs_remediation":   needs_remediation,
        "classical_sources":   F3_CITATIONS["planetary_summary"],
    }


# ════════════════════════════════════════════════════════════════════════
# COMPREHENSIVE — all-in-one report with dasha context
# ════════════════════════════════════════════════════════════════════════

def handle_strength_comprehensive(birth: Dict[str, Any]) -> Dict[str, Any]:
    """
    F3 Endpoint: One-call comprehensive strength report.

    Combines:
      - Full Shadbala (6 components per planet)
      - Vimshopaka Bala (16-fold)
      - Ishta / Kashta phala disposition
      - Functional strength verdict per planet
      - Dasha context: which planet is currently active, what's its strength?
      - Actionable interpretation: which planets carry the load, which need support
    """
    try:
        chart = cast_chart(
            dob=birth["dob"], time=birth["time"],
            lat=birth["lat"], lon=birth["lon"],
            timezone=birth.get("timezone", "Asia/Kolkata"),
        )
    except Exception as e:
        return {"error": f"Chart cast failed: {e}",
                 "citations": F3_CITATIONS["comprehensive"]}

    # Reuse planetary_summary internals
    planets = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]
    comprehensive_per_planet = {}

    for p in planets:
        sb = _get_shadbala_data(chart, p)
        vimshopaka = _compute_vimshopaka_for_planet(p, chart)
        verdict_obj = _functional_strength_verdict(sb, vimshopaka["total_score"])

        # Full Shadbala breakdown
        comprehensive_per_planet[p] = {
            "shadbala_full": {
                "sthana_bala":     sb.get("sthana_bala", {}),
                "dig_bala":        sb.get("dig_bala"),
                "kala_bala":       sb.get("kala_bala"),
                "chesta_bala":     sb.get("chesta_bala"),
                "naisargika_bala": sb.get("naisargika_bala"),
                "drik_bala":       sb.get("drik_bala"),
                "total_rupas":     sb.get("total_rupas"),
                "required_rupas":  sb.get("required_rupas"),
                "is_strong":       sb.get("is_strong"),
                "strength_ratio":  sb.get("strength_ratio"),
            },
            "vimshopaka": vimshopaka,
            "ishta_phala":  sb.get("ishta_phala"),
            "kashta_phala": sb.get("kashta_phala"),
            "verdict":      verdict_obj["verdict"],
            "narrative":    verdict_obj["narrative"],
        }

    # Dasha context
    dashas = chart.get("dashas", {})
    md = dashas.get("maha", {})
    ad = dashas.get("antar", {})
    md_planet = md.get("planet")
    ad_planet = ad.get("planet")

    dasha_strength_context = {}
    for label, dp in [("md", md_planet), ("ad", ad_planet)]:
        if dp and dp in comprehensive_per_planet:
            entry = comprehensive_per_planet[dp]
            dasha_strength_context[label] = {
                "planet":  dp,
                "verdict": entry["verdict"],
                "vimshopaka_score": entry["vimshopaka"]["total_score"],
                "vimshopaka_band":  entry["vimshopaka"]["band"],
                "shadbala_strong":  entry["shadbala_full"]["is_strong"],
            }
        else:
            dasha_strength_context[label] = {
                "planet":  dp,
                "note":    "Active dasha lord is Rahu/Ketu — not included in classical Shadbala/Vimshopaka",
            }

    # Build dasha narrative
    dasha_notes = []
    md_ctx = dasha_strength_context.get("md", {})
    ad_ctx = dasha_strength_context.get("ad", {})
    if "verdict" in md_ctx:
        dasha_notes.append(
            f"Current Mahadasha lord ({md_ctx['planet']}) is {md_ctx['verdict']}. "
            f"Vimshopaka {md_ctx['vimshopaka_score']:.2f}/20 ({md_ctx['vimshopaka_band']})."
        )
    if "verdict" in ad_ctx:
        dasha_notes.append(
            f"Antardasha lord ({ad_ctx['planet']}) is {ad_ctx['verdict']}. "
            f"Vimshopaka {ad_ctx['vimshopaka_score']:.2f}/20 ({ad_ctx['vimshopaka_band']})."
        )

    # Identify functional roles
    ranked_by_vimshopaka = sorted(
        [(p, v["vimshopaka"]["total_score"]) for p, v in comprehensive_per_planet.items()],
        key=lambda x: -x[1]
    )
    strongest = ranked_by_vimshopaka[0]
    weakest = ranked_by_vimshopaka[-1]

    return {
        "success": True,
        "natal_summary": {
            "lagna_sign":   chart.get("lagna", {}).get("sign"),
            "moon_sign":    chart.get("planets", {}).get("Moon", {}).get("sign"),
            "sun_sign":     chart.get("planets", {}).get("Sun", {}).get("sign"),
            "moon_nakshatra": chart.get("planets", {}).get("Moon", {}).get("nakshatra"),
        },
        "per_planet":        comprehensive_per_planet,
        "dasha_context":     dasha_strength_context,
        "dasha_notes":       dasha_notes,
        "strongest_planet": {"planet": strongest[0], "vimshopaka_score": strongest[1]},
        "weakest_planet":   {"planet": weakest[0], "vimshopaka_score": weakest[1]},
        "ranked_by_vimshopaka": [{"planet": p, "score": s} for p, s in ranked_by_vimshopaka],
        "classical_sources":   F3_CITATIONS["comprehensive"],
    }


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

F3_CITATIONS = {
    "vimshopaka_bala": [
        "Brihat Parashara Hora Shastra Ch. 35 — Vimshopaka Bala (16-fold strength via Shodasavarga)",
        "BPHS Ch. 35.10-18 — Specific weight prescriptions for each varga",
        "Phaladeepika Ch. 7 — Divisional strength as predictor of subtle results",
        "Saravali Ch. 4 — Importance of varga-consensus for sustained themes",
    ],
    "planetary_summary": [
        "BPHS Ch. 27 — Shadbala (six-fold strength components)",
        "BPHS Ch. 35 — Vimshopaka Bala (sixteen-fold strength)",
        "BPHS Ch. 27.66-67 — Ishta and Kashta phala (beneficial vs malefic distribution)",
        "Phaladeepika Ch. 7 — Functional benefic/malefic classification by strength",
        "Saravali Ch. 5 — Synthesis principles for combined strength interpretation",
    ],
    "comprehensive": [
        "BPHS Ch. 27 — Six-component Shadbala",
        "BPHS Ch. 35 — Sixteen-fold Vimshopaka Bala",
        "Phaladeepika Ch. 7 — Strength interpretation",
        "Saravali Ch. 4-5 — Strength synthesis",
        "BPHS Ch. 46 — Dasha period effects modulated by planetary strength",
    ],
}
