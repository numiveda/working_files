"""
mokshapatam_data.py — numiVeda Kaaliyo Astro Engine — Module E2.

Moksha Patam (Sanskrit: मोक्ष पटम) game catalogs.
Classical Indian ancestor of Snakes & Ladders, used as a karmic teaching tool.

Public catalogs:
    BOARD                  — 72 houses with full attributes
    CHAKRA_ROWS            — 8 chakras grouped from board houses
    CHAKRA_ORDER           — Ordered chakra list (muladhara→moksha)
    CHAKRA_SHORT           — Display-short names per chakra
    PAST_LIFE_WEIGHT_RULES — Phase 1 roll-count thresholds
    CLASSICAL_CITATIONS

Source: Classical Indian Moksha Patam tradition, the 72-square soul-evolution
        board. Distinct from later Western Snakes & Ladders.
        Houses 1-9 = Muladhara (Physical), 10-18 = Svadhisthana (Astral),
        19-27 = Manipura (Celestial), 28-36 = Anahata (Heart),
        37-45 = Vishuddha (Throat), 46-54 = Ajna (Third Eye),
        55-63 = Sahasrara (Crown), 64-72 = Moksha (Liberation).
"""

from typing import Dict, List


# ════════════════════════════════════════════════════════════════════════
# THE 72 HOUSES — Full board catalog
# Each house: name, sanskrit, chakra, type (virtue/vice/neutral),
#             snake_to (None if no snake), ladder_to (None if no ladder),
#             meaning (classical interpretation)
# ════════════════════════════════════════════════════════════════════════

BOARD: Dict[int, Dict] = {
    # ── ROW 1: MULADHARA (Houses 1-9) — Physical Plane ──
    1:  {"name": "Genesis",            "sanskrit": "उत्पत्ति / जन्म",       "chakra": "muladhara",    "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "The start of the game of life. The soul decides to play, driven by desires, marking a new beginning and an independent phase."},
    2:  {"name": "Maya — Illusion",    "sanskrit": "माया / भ्रम",            "chakra": "muladhara",    "type": "vice",    "snake_to": None, "ladder_to": None,
         "meaning": "The illusion of duality. An active mind, fascination, and mistaking the physical world for ultimate reality."},
    3:  {"name": "Anger",              "sanskrit": "क्रोध",                  "chakra": "muladhara",    "type": "vice",    "snake_to": None, "ladder_to": None,
         "meaning": "Insecurity, value judgements, and mental weakness. It burns everything and causes a downward movement in spiritual growth."},
    4:  {"name": "Greed",              "sanskrit": "लोभ / लालच",             "chakra": "muladhara",    "type": "vice",    "snake_to": None, "ladder_to": None,
         "meaning": "Driven by possession, craving, and an insecure desperate feeling of lack focused on material survival."},
    5:  {"name": "Physical Plane",     "sanskrit": "भौतिक विमान / भू लोक",   "chakra": "muladhara",    "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "The root chakra. Body involvement, survival, fears, and material achievement. Traps the player in the lower self."},
    6:  {"name": "Delusion",           "sanskrit": "मोह / भ्रम",             "chakra": "muladhara",    "type": "vice",    "snake_to": None, "ladder_to": None,
         "meaning": "Attachment to that which is not true. Selfish measures, disharmony, and failure to abide by cosmic laws."},
    7:  {"name": "Conceit",            "sanskrit": "दंभ / मदहोश",            "chakra": "muladhara",    "type": "vice",    "snake_to": None, "ladder_to": None,
         "meaning": "Too much pride, self-deception, and intoxication. Building castles in the air through false identification."},
    8:  {"name": "Avarice",            "sanskrit": "अविद्या",                "chakra": "muladhara",    "type": "vice",    "snake_to": None, "ladder_to": None,
         "meaning": "Envy and Greed combined. A desperate urge to acquire what others have. Materialism, addiction, and struggle in darkness."},
    9:  {"name": "Sensual Plane",      "sanskrit": "काम लोक",                "chakra": "muladhara",    "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "The soul's first evolutionary stage, developing attachments to bodily senses. Driven by desire and lack of true knowledge."},

    # ── ROW 2: SVADHISTHANA (Houses 10-18) — Astral Plane ──
    10: {"name": "Purification",       "sanskrit": "शुद्धि",                 "chakra": "svadhisthana", "type": "virtue",  "snake_to": None, "ladder_to": 23,
         "meaning": "Transcending dullness and inertia. Altering behaviour and purifying the senses to raise one's spiritual vibration."},
    11: {"name": "Entertainment",      "sanskrit": "मनोरंजन",                "chakra": "svadhisthana", "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "A light-spirited stage of well-deserved rest after purification. Music, fine arts, rhythm, and inward joy."},
    12: {"name": "Envy",               "sanskrit": "ईर्ष्या",                "chakra": "svadhisthana", "type": "vice",    "snake_to": 8,    "ladder_to": None,
         "meaning": "Lack of confidence and low energy. The soul vibrating incorrectly and seeking strategies to overpower others."},
    13: {"name": "Nullity",            "sanskrit": "अशक्तता",                "chakra": "svadhisthana", "type": "vice",    "snake_to": None, "ladder_to": None,
         "meaning": "A frozen state of purposelessness, inactivity, and meaningless living. Trapped where no true movement happens."},
    14: {"name": "Astral Plane",       "sanskrit": "एस्ट्रल प्लेन",         "chakra": "svadhisthana", "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "A materially secure plane of water, dreams, fantasy, and psychic power. Driven by feelings, emotions, and excitement."},
    15: {"name": "Fantasy",            "sanskrit": "काल्पनिक",                "chakra": "svadhisthana", "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "Infinite potentialities and unrestrained imagination. Great creativity, but completely lacking in contact with reality."},
    16: {"name": "Jealousy",           "sanskrit": "ईर्ष्या (गहरी)",         "chakra": "svadhisthana", "type": "vice",    "snake_to": 4,    "ladder_to": None,
         "meaning": "A swollen ego burdened by fear of rivalry, suspicion, unfaithfulness, and mental imbalance."},
    17: {"name": "Mercy",              "sanskrit": "दया",                    "chakra": "svadhisthana", "type": "virtue",  "snake_to": None, "ladder_to": 69,
         "meaning": "A divine attribute of forgiveness, kindness, and cosmic love. It refines emotions and sweeps the ego aside."},
    18: {"name": "Plane of Joy",       "sanskrit": "आनंद का विमान",          "chakra": "svadhisthana", "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "Karma Yoga. Deep satisfaction, clarity, and rising above sensual desires with no fear or insecurity."},

    # ── ROW 3: MANIPURA (Houses 19-27) — Celestial Plane ──
    19: {"name": "Karma",              "sanskrit": "कर्म",                   "chakra": "manipura",     "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "The primary reason for continuing illusion. The soul becomes aware of performing actions out of an urge for fulfilment."},
    20: {"name": "Charity",            "sanskrit": "दान",                    "chakra": "manipura",     "type": "virtue",  "snake_to": None, "ladder_to": 32,
         "meaning": "Selfless giving without desiring personal benefit. Elevates energy, brings solutions to problems, and breaks karmic bondage."},
    21: {"name": "Atonement",          "sanskrit": "प्रायश्चित्त",           "chakra": "manipura",     "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "Compensating and trying to improve after acting blindly. Resolves emotional turmoil and removes gravity from wrong karmas."},
    22: {"name": "Dharma",             "sanskrit": "धर्म",                   "chakra": "manipura",     "type": "virtue",  "snake_to": None, "ladder_to": 60,
         "meaning": "Righteousness and moral code of conduct in tune with cosmic principles. Truth, ethics, self-command, and purity."},
    23: {"name": "Celestial Plane",    "sanskrit": "स्वर्गा लोक",            "chakra": "manipura",     "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "The 3rd Chakra plane of infinite life and recreation. Self-luminous power, smart management, and healing abilities."},
    24: {"name": "Bad Company",        "sanskrit": "कुसंगे",                  "chakra": "manipura",     "type": "vice",    "snake_to": 7,    "ladder_to": None,
         "meaning": "A charismatic bad influence that misguides the player, abuses personal power, and thinks wrong is right."},
    25: {"name": "Good Company",       "sanskrit": "अच्छी कंपनी",            "chakra": "manipura",     "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "Partnering with good people to follow Dharma. Nurtures the soul's personality and helps one grow away from stagnant identifications."},
    26: {"name": "Sorrow",             "sanskrit": "दुःख",                   "chakra": "manipura",     "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "A temporary state of depression, constriction, and lost energy. Painful but inevitable and essential as an educational experience."},
    27: {"name": "Seva — Service",     "sanskrit": "सेवा",                   "chakra": "manipura",     "type": "virtue",  "snake_to": None, "ladder_to": 41,
         "meaning": "Selfless service in action, beyond profit or loss. An attitude dedicated to the supreme without keeping rewards in mind."},

    # ── ROW 4: ANAHATA (Houses 28-36) — Heart Plane ──
    28: {"name": "APT Religion",       "sanskrit": "सुधर्मा",                "chakra": "anahata",      "type": "virtue",  "snake_to": None, "ladder_to": 50,
         "meaning": "Acting in harmony with your own inner nature. Non-attachment and evolving without adopting unfair means."},
    29: {"name": "Irreligiosity",      "sanskrit": "अपरिपक्वता",             "chakra": "anahata",      "type": "vice",    "snake_to": 6,    "ladder_to": None,
         "meaning": "Exploiting others through unfair means. Acting contrary to one's Dharma, driven by tension and distraction."},
    30: {"name": "Good",               "sanskrit": "अच्छा",                  "chakra": "anahata",      "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "Harmony, natural flow, and grace. Control over one's inner nature and vibrating correctly in a positive direction."},
    31: {"name": "Sanctity",           "sanskrit": "पवित्रता",                "chakra": "anahata",      "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "A deep calling to learn more and confront reality. Finding truth, experiencing Divine Grace, and understanding nature spirits."},
    32: {"name": "Balance",            "sanskrit": "संतुलन",                  "chakra": "anahata",      "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "The Heart Chakra. Cosmic unity, oneness, extended awareness, and compassion. Stabilises existence with an upward flow of energy."},
    33: {"name": "Fragrance",          "sanskrit": "खुशबू",                  "chakra": "anahata",      "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "Divine fragrances that spread to help humanity. Permanent elimination of bad elements and attracting positive vibrations."},
    34: {"name": "Taste",              "sanskrit": "स्वाद",                  "chakra": "anahata",      "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "The element of water providing pleasure, grace, and creativity. Creates bonds, making the person malleable and adaptable."},
    35: {"name": "Purgatory",          "sanskrit": "दुर्गुण",                "chakra": "anahata",      "type": "vice",    "snake_to": None, "ladder_to": None,
         "meaning": "A karmically blocked situation. Painful but necessary opportunity for purification and reflection after imperfect actions."},
    36: {"name": "Clarity",            "sanskrit": "स्पष्टता",                "chakra": "anahata",      "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "Transparent awareness and strong inner light with no resistance. Clears doubts and confusions, leading to deep purification."},

    # ── ROW 5: VISHUDDHA (Houses 37-45) — Throat Plane ──
    37: {"name": "Awareness",          "sanskrit": "जागरूकता",               "chakra": "vishuddha",    "type": "virtue",  "snake_to": None, "ladder_to": 66,
         "meaning": "Pure witnessing consciousness. Seeing Maya as illusion without value judgements. Transmutes energy and reduces the scope of karma."},
    38: {"name": "Life Energy",        "sanskrit": "प्राणऊर्जा",              "chakra": "vishuddha",    "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "Full of Prana, vibrating with universal energy. Brings balance, preserves life, and aligns with the universe's co-creative force."},
    39: {"name": "Elimination",        "sanskrit": "उन्मूलन",                "chakra": "vishuddha",    "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "Letting go of what is not required and releasing toxins. Creates balance with Prana, crucial for rejuvenation and vitality."},
    40: {"name": "Circulation",        "sanskrit": "परिचलन",                 "chakra": "vishuddha",    "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "Upward/downward movement of vital air and oxygen. Balances body chemistry. Represents healthy circulation of energy and money."},
    41: {"name": "Human Plane",        "sanskrit": "मानव विमान",             "chakra": "vishuddha",    "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "The Throat Chakra — Plane of Siddhis. Becoming truly human: merciful without expectations, deeply compassionate, and mentally free."},
    42: {"name": "Fire",               "sanskrit": "आग",                     "chakra": "vishuddha",    "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "The inner sun and passion for life. Fire for growth, prosperity, and serving humanity, generating light and great teachings."},
    43: {"name": "Birth of Man",       "sanskrit": "मनुष्य का जन्म",          "chakra": "vishuddha",    "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "Beginning something new and becoming more human. Direct experience of being in touch with truth and one's authentic self."},
    44: {"name": "Ignorance",          "sanskrit": "अज्ञानता",               "chakra": "vishuddha",    "type": "vice",    "snake_to": 9,    "ladder_to": None,
         "meaning": "Loss of understanding and absence of light. Acting foolishly out of compulsion, leading to distraction and sensual attachments."},
    45: {"name": "Knowledge",          "sanskrit": "ज्ञान",                  "chakra": "vishuddha",    "type": "virtue",  "snake_to": None, "ladder_to": 67,
         "meaning": "The urge to know the truth. Opening knowledge through scriptures strengthens the inner voice, wisdom, and conscious behaviour."},

    # ── ROW 6: AJNA (Houses 46-54) — Third Eye Plane ──
    46: {"name": "Conscience",         "sanskrit": "विवेक",                  "chakra": "ajna",         "type": "virtue",  "snake_to": None, "ladder_to": 62,
         "meaning": "The inner voice of right and wrong attuned to ethical living. Opening the third eye provides wisdom to differentiate subtle from gross."},
    47: {"name": "Neutrality",         "sanskrit": "तटस्थता",                 "chakra": "ajna",         "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "The Central Channel (Sushumna). Learning to do nothing, be a pure witness, and stabilise all forces of existence."},
    48: {"name": "Solar Plane",        "sanskrit": "यमुना",                  "chakra": "ajna",         "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "The Pingala/Sun channel — active male energy and heat. Balancing hot and cold, moving beyond personal involvement."},
    49: {"name": "Lunar Plane",        "sanskrit": "गंगा / चंद्र तल",        "chakra": "ajna",         "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "The Ida/Moon channel — active female energy. Brings cooling balance and the restoration of pure consciousness."},
    50: {"name": "Austerity",          "sanskrit": "तपस्या",                 "chakra": "ajna",         "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "6th Chakra plane of high penance, hard work on the self, and tremendous sacrifice. Leads to spiritual mastery and command over elements."},
    51: {"name": "Earth",              "sanskrit": "पृथ्वी",                 "chakra": "ajna",         "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "The Karmaland — the only stage for action, liberation, and playing the divine game. Tolerance, the mother principle, and forbearance."},
    52: {"name": "Violence",           "sanskrit": "हिंसा",                  "chakra": "ajna",         "type": "vice",    "snake_to": 35,   "ladder_to": None,
         "meaning": "Physical or mental violence lacking spiritual fluidity. Committing ethical wrongs at high levels demands severe atonement."},
    53: {"name": "Liquid",             "sanskrit": "तरल / जल लोक",           "chakra": "ajna",         "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "Malleable, formless, and highly adaptable like water. Breaking barriers to merge and blend, providing stable fertility."},
    54: {"name": "Devotion",           "sanskrit": "भक्तियोग",                "chakra": "ajna",         "type": "virtue",  "snake_to": None, "ladder_to": 68,
         "meaning": "Complete surrender, faith, and longing to merge. The shortest, most direct path to cosmic consciousness by mastering the will."},

    # ── ROW 7: SAHASRARA (Houses 55-63) — Crown / Cosmic Plane ──
    55: {"name": "Egotism",            "sanskrit": "अहंभाव / अहंकार",         "chakra": "sahasrara",    "type": "vice",    "snake_to": 3,    "ladder_to": None,
         "meaning": "Being entirely self-centred, where ego and pride overtake everything. The player loses sight of deeper values and divine nature."},
    56: {"name": "Primal Vibration",   "sanskrit": "ओंकार",                  "chakra": "sahasrara",    "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "The plane of Sound (Om). Centring on inner sounds to relieve tension, unlock cosmic knowledge, and inspire high creative energy."},
    57: {"name": "Gaseous",            "sanskrit": "गैसीय / वायुलोक",         "chakra": "sahasrara",    "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "An enlightened, formless state of vital force energy. Becoming clairvoyant, travelling anywhere, manifesting in multiple places."},
    58: {"name": "Radiation",          "sanskrit": "विकिरण / तेजलोक",         "chakra": "sahasrara",    "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "An astral body composed of light, emitting a brilliant cosmic aura. Radiant energy attained through devotion that gathers others."},
    59: {"name": "Reality",            "sanskrit": "हकीकत",                  "chakra": "sahasrara",    "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "The Crown Chakra — an ocean of bliss filled with supreme consciousness and perfect harmony. A realised soul with Siddhis and Samadhi."},
    60: {"name": "Positive Intellect", "sanskrit": "सकारात्मक बुद्धि",        "chakra": "sahasrara",    "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "A blossoming intellect full of wisdom that strictly follows truth and Dharma. Ends separateness by seeing the Divine in everyone."},
    61: {"name": "Negative Intellect", "sanskrit": "नकारात्मक बुद्धि",        "chakra": "sahasrara",    "type": "vice",    "snake_to": 13,   "ladder_to": None,
         "meaning": "Self-centred failure to discern right from wrong. Taking wrong as right depletes psychic energy and creates a downward throw."},
    62: {"name": "Happiness",          "sanskrit": "खुशी / सुख",             "chakra": "sahasrara",    "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "Joy and positivity beyond words, coming purely from within. Deep acceptance and gratitude for whatever life presents."},
    63: {"name": "Darkness",           "sanskrit": "अंधकार / तमस",           "chakra": "sahasrara",    "type": "vice",    "snake_to": 2,    "ladder_to": None,
         "meaning": "Deep sleep, total absence of light and knowledge. Complete surrender to illusion by neglecting karma."},

    # ── ROW 8: MOKSHA PLANE (Houses 64-72) — Liberation ──
    64: {"name": "Phenomenal",         "sanskrit": "प्रकृतिलोक / अद्भुत दुनिया", "chakra": "moksha",     "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "A Godly plane of raised consciousness that understands the origin of Nature, the three gunas, the five elements, and phenomenal existence."},
    65: {"name": "Inner Space",        "sanskrit": "अंतरिक्ष / उड़ते लोक",      "chakra": "moksha",       "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "Moving deeply within to end the separate self and ego. Merging perfectly with the source in extreme humility, holding onto nothing."},
    66: {"name": "Bliss",              "sanskrit": "आनंद लोक / परमानंद",     "chakra": "moksha",       "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "A pure, permanent state beyond pleasure or temporary happiness. Experienced through complete attention to Dharma and pure wisdom."},
    67: {"name": "Cosmic Good",        "sanskrit": "शिवधाम / रुद्रलोक",       "chakra": "moksha",       "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "The Plane of Shiva. Final alchemical purification that destroys false identity and Tamas, completing the evolution of individual consciousness."},
    68: {"name": "Cosmic Consciousness","sanskrit": "लौकिक चेतना / बैकुठ लोक", "chakra": "moksha",       "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "The Plane of Vishnu. The soul's final destination — merging with the Divine, experiencing ultimate bliss, abundance, and liberation. END CONDITION."},
    69: {"name": "Absolute",           "sanskrit": "ब्रह्मलोक / निरपेक्ष",    "chakra": "moksha",       "type": "virtue",  "snake_to": None, "ladder_to": None,
         "meaning": "The Plane of Brahma (Creation). All manifestation and healing happen here, but the soul is not permanently liberated — must continue the play."},
    70: {"name": "True Nature",        "sanskrit": "सच्ची प्रकृति / सतोगुण",  "chakra": "moksha",       "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "Fixed in light, purity, true essence, and high spiritual frequencies (Sattva). However, must return to earth to fully complete the journey."},
    71: {"name": "Activity",           "sanskrit": "रजोगुण",                 "chakra": "moksha",       "type": "neutral", "snake_to": None, "ladder_to": None,
         "meaning": "Dominated by Karma and Rajas (Activity). Sparks ambition, passion, and desire for rewards — pulling the soul back toward earth."},
    72: {"name": "Inertia",            "sanskrit": "तमोगुण",                 "chakra": "moksha",       "type": "vice",    "snake_to": 51,   "ladder_to": None,
         "meaning": "The final snake — Tamas (Inertia). Inactivity and spiritual sleep that veils truth, forcing the soul back to Earth to restart the evolutionary cycle."},
}


# ════════════════════════════════════════════════════════════════════════
# 8 CHAKRA ROWS — Grouping board houses by chakra plane
# Each chakra: name, plane, houses list, virtue/vice/neutral counts, theme
# ════════════════════════════════════════════════════════════════════════

CHAKRA_ROWS: Dict[str, Dict] = {
    "muladhara":    {"name": "Muladhara",    "plane": "Physical Plane",       "houses": [1,2,3,4,5,6,7,8,9],         "virtue_count": 0, "vice_count": 6, "neutral_count": 3,
                     "theme": "Survival, instinct, material existence, and the dense karma of the physical world. The soul begins here in raw embodied life."},
    "svadhisthana": {"name": "Svadhisthana", "plane": "Astral Plane",         "houses": [10,11,12,13,14,15,16,17,18], "virtue_count": 3, "vice_count": 3, "neutral_count": 3,
                     "theme": "Emotion, creativity, fantasy, and the first stirrings of genuine feeling beyond pure survival."},
    "manipura":     {"name": "Manipura",     "plane": "Celestial Plane",      "houses": [19,20,21,22,23,24,25,26,27], "virtue_count": 5, "vice_count": 2, "neutral_count": 2,
                     "theme": "Will, action, and the beginning of conscious karma. The soul starts directing itself."},
    "anahata":      {"name": "Anahata",      "plane": "Heart Plane",          "houses": [28,29,30,31,32,33,34,35,36], "virtue_count": 5, "vice_count": 2, "neutral_count": 2,
                     "theme": "Compassion, love, and the turning point where self-interest begins yielding to the universal. Most souls reach their ceiling here."},
    "vishuddha":    {"name": "Vishuddha",    "plane": "Throat Plane",         "houses": [37,38,39,40,41,42,43,44,45], "virtue_count": 5, "vice_count": 1, "neutral_count": 3,
                     "theme": "Expression, truth, awareness, and genuine spiritual fire. Few souls reach this level in a single lifetime."},
    "ajna":         {"name": "Ajna",         "plane": "Third Eye Plane",      "houses": [46,47,48,49,50,51,52,53,54], "virtue_count": 4, "vice_count": 2, "neutral_count": 3,
                     "theme": "Higher intellect, intuition, and devotion. Intellect cuts both ways here — positive or negative."},
    "sahasrara":    {"name": "Sahasrara",    "plane": "Crown / Cosmic Plane", "houses": [55,56,57,58,59,60,61,62,63], "virtue_count": 5, "vice_count": 2, "neutral_count": 2,
                     "theme": "Light, radiation, bliss, and the final gateway before liberation. Very rare for a soul to reach and remain here."},
    "moksha":       {"name": "Moksha Plane", "plane": "Liberation Plane",     "houses": [64,65,66,67,68,69,70,71,72], "virtue_count": 5, "vice_count": 1, "neutral_count": 3,
                     "theme": "Liberation itself — but even here inertia and activity can trap. House 68 is the only true end."},
}


# Ordered chakra list (for analysis iteration)
CHAKRA_ORDER: List[str] = ["muladhara", "svadhisthana", "manipura", "anahata", "vishuddha", "ajna", "sahasrara", "moksha"]


# Display-short names per chakra
CHAKRA_SHORT: Dict[str, str] = {
    "muladhara":    "Root",
    "svadhisthana": "Sacral",
    "manipura":     "Solar",
    "anahata":      "Heart",
    "vishuddha":    "Throat",
    "ajna":         "Third Eye",
    "sahasrara":    "Crown",
    "moksha":       "Moksha",
}


# ════════════════════════════════════════════════════════════════════════
# PAST LIFE WEIGHT RULES (Phase 1 roll count thresholds)
# ════════════════════════════════════════════════════════════════════════

PAST_LIFE_WEIGHT_RULES: List[Dict] = [
    {"min_count": 0,  "max_count": 0,  "label": "very_clear",   "text": "Very clear karmic slate — minimal burden from previous lives."},
    {"min_count": 1,  "max_count": 2,  "label": "light",        "text": "Light past life karma — some unresolved patterns, but not overwhelming."},
    {"min_count": 3,  "max_count": 4,  "label": "moderate",     "text": "Moderate past life karma — considerable unresolved patterns shaping this life."},
    {"min_count": 5,  "max_count": 6,  "label": "significant",  "text": "Significant past life karma — strong patterns carried forward from previous incarnations."},
    {"min_count": 7,  "max_count": 999,"label": "heavy",        "text": "Heavy karmic burden — substantial unresolved karma from previous lives shaping this incarnation."},
]


# ════════════════════════════════════════════════════════════════════════
# END CONDITIONS
# ════════════════════════════════════════════════════════════════════════

END_CONDITIONS: Dict[str, Dict] = {
    "house_68":  {"label": "House 68 — Cosmic Consciousness (most auspicious)",
                  "description": "The soul reached liberation through the Vishnu plane. The most blessed end condition."},
    "age_80":    {"label": "Age 80 (natural completion)",
                  "description": "The soul completed the journey at the natural lifespan without reaching Moksha. The journey continues into the next life."},
}


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "moksha_patam":   "Classical Indian Moksha Patam (मोक्ष पटम) tradition. The 72-square soul-evolution game predating Western Snakes & Ladders by centuries. Used as a karmic teaching tool aligned with the chakra-based ascent through 8 planes.",
    "chakras":        "8-chakra ascending framework — Muladhara (root) through Sahasrara (crown) + Moksha (liberation). Each chakra row of 9 houses corresponds to a karmic plane of experience.",
    "karma_doctrine": "Sanchita / Prarabdha / Kriyaman / Aagami karma classification per Vedantic and Yogic tradition. Past-life count (phase 1) reflects Sanchita; the journey reflects Prarabdha unfolding; final house position reveals Kriyaman/Aagami.",
    "snakes_ladders": "Classical snake (vice consequence) and ladder (virtue elevation) positions encoded by tradition — not modern Snakes & Ladders variants. Each is a specific karmic teaching about the consequence-pattern of that soul-state.",
    "end_conditions": "End at House 68 (Vaikuntha, Vishnu plane) signifies true Moksha within this incarnation. End at age 80 without reaching H68 signifies a complete but un-liberated life — the journey continues.",
}
