"""
numerology.py — numiVeda Astro Engine

Hand-coded numerology module covering THREE systems:
  • Pythagorean (Western, 1–9 with master numbers 11/22/33)
  • Chaldean    (Ancient Babylonian, 1–8; 9 is sacred, never assigned)
  • Lo Shu Grid (Chinese 3×3 magic square, based on birth date digits)

Decision: the PyPI `numerology` package is stale (no release in 12+ months,
covers only Pythagorean partially, with French interpretations). Numerology
math is purely deterministic and tiny — hand-coding gives full control,
correctness, and zero external dependency risk.

Public API:
    pythagorean(name: str, dob: str) -> dict
    chaldean(name: str, dob: str) -> dict
    lo_shu_grid(dob: str) -> dict
    full_numerology(name: str, dob: str) -> dict   # combines all three
"""

from datetime import date
from typing import Dict, List, Any
from collections import Counter

# ─────────────────────────────────────────────────────────────────────────────
# 1. LETTER VALUE TABLES
# ─────────────────────────────────────────────────────────────────────────────

# Pythagorean: A=1, B=2, ..., I=9, J=1, K=2, ..., Z=8
PYTHAGOREAN = {
    "A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6, "G": 7, "H": 8, "I": 9,
    "J": 1, "K": 2, "L": 3, "M": 4, "N": 5, "O": 6, "P": 7, "Q": 8, "R": 9,
    "S": 1, "T": 2, "U": 3, "V": 4, "W": 5, "X": 6, "Y": 7, "Z": 8,
}

# Chaldean: based on sound/vibration. 9 is never assigned (sacred).
CHALDEAN = {
    "A": 1, "I": 1, "J": 1, "Q": 1, "Y": 1,
    "B": 2, "K": 2, "R": 2,
    "C": 3, "G": 3, "L": 3, "S": 3,
    "D": 4, "M": 4, "T": 4,
    "E": 5, "H": 5, "N": 5, "X": 5,
    "U": 6, "V": 6, "W": 6,
    "O": 7, "Z": 7,
    "F": 8, "P": 8,
    # No letter = 9 in Chaldean (9 is divine, never assigned to mortals)
}

VOWELS = set("AEIOU")

MASTER_NUMBERS = {11, 22, 33}


# ─────────────────────────────────────────────────────────────────────────────
# 2. REDUCTION HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _digit_sum(n: int) -> int:
    """Sum of digits."""
    return sum(int(d) for d in str(abs(n)))


def _reduce(n: int, preserve_master: bool = True) -> int:
    """Reduce to single digit; preserve master numbers if requested."""
    while n > 9:
        if preserve_master and n in MASTER_NUMBERS:
            return n
        n = _digit_sum(n)
    return n


def _name_total(name: str, table: Dict[str, int]) -> int:
    """Sum letter values from a name using the given table."""
    return sum(table.get(ch, 0) for ch in name.upper() if ch.isalpha())


def _parse_dob(dob: str) -> date:
    """Parse YYYY-MM-DD."""
    return date.fromisoformat(dob)


# ─────────────────────────────────────────────────────────────────────────────
# 3. CORE NUMBERS (used by all systems)
# ─────────────────────────────────────────────────────────────────────────────

def _moolank(dob: str) -> int:
    """Moolank / Birth Number — reduced day-of-birth."""
    d = _parse_dob(dob).day
    return _reduce(d)


def _bhagyank(dob: str) -> int:
    """Bhagyank / Life Path Number — reduced full DOB."""
    d = _parse_dob(dob)
    total = d.day + d.month + d.year
    return _reduce(total)


def _kua_number(dob: str, gender: str = "male") -> int:
    """
    Kua number — used in Feng Shui personal directions.
    Formula:
      Male:   (11 - last 2 digits of year reduced) mod 9, 0 → 9, skip 5 → 2
      Female: (last 2 digits of year reduced + 4) mod 9, 0 → 9, skip 5 → 8
    """
    year = _parse_dob(dob).year
    yy = year % 100
    while yy > 9:
        yy = _digit_sum(yy)
    if gender.lower().startswith("m"):
        k = 11 - yy
    else:
        k = yy + 4
    while k > 9:
        k = _digit_sum(k)
    if k == 0:
        k = 9
    if k == 5:
        k = 2 if gender.lower().startswith("m") else 8
    return k


# ─────────────────────────────────────────────────────────────────────────────
# 4. INTERPRETATIONS
# ─────────────────────────────────────────────────────────────────────────────

NUMBER_MEANINGS = {
    1: {"planet": "Sun",      "traits": "Leader, independent, original, ambitious, authoritative"},
    2: {"planet": "Moon",     "traits": "Cooperative, sensitive, diplomatic, intuitive, peace-maker"},
    3: {"planet": "Jupiter",  "traits": "Creative, expressive, optimistic, social, lucky"},
    4: {"planet": "Rahu",     "traits": "Practical, disciplined, methodical, hardworking, foundation-builder"},
    5: {"planet": "Mercury",  "traits": "Adventurous, versatile, communicative, freedom-loving, restless"},
    6: {"planet": "Venus",    "traits": "Loving, responsible, nurturing, artistic, family-oriented"},
    7: {"planet": "Ketu",     "traits": "Spiritual, analytical, mystical, introspective, philosophical"},
    8: {"planet": "Saturn",   "traits": "Powerful, materialistic, disciplined, executive, karmic"},
    9: {"planet": "Mars",     "traits": "Courageous, humanitarian, passionate, completion energy"},
    11: {"planet": "Moon-Sun (Master)", "traits": "Spiritual messenger, intuitive teacher, illumination"},
    22: {"planet": "Master Builder",    "traits": "Practical visionary, large-scale manifestation"},
    33: {"planet": "Master Teacher",    "traits": "Universal compassion, healer, spiritual guide"},
}


# ─────────────────────────────────────────────────────────────────────────────
# 5. PYTHAGOREAN ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────

def pythagorean(name: str, dob: str) -> Dict[str, Any]:
    """Complete Pythagorean numerology analysis."""
    name_total_raw = _name_total(name, PYTHAGOREAN)
    destiny = _reduce(name_total_raw)

    vowel_total = sum(
        PYTHAGOREAN.get(ch, 0)
        for ch in name.upper() if ch in VOWELS
    )
    soul_urge = _reduce(vowel_total)

    consonant_total = sum(
        PYTHAGOREAN.get(ch, 0)
        for ch in name.upper() if ch.isalpha() and ch not in VOWELS
    )
    personality = _reduce(consonant_total)

    moolank = _moolank(dob)
    bhagyank = _bhagyank(dob)

    # Maturity number — adds destiny and life path
    maturity = _reduce(destiny + bhagyank)

    return {
        "system": "Pythagorean",
        "moolank":     {"value": moolank,     **NUMBER_MEANINGS.get(moolank, {})},
        "bhagyank":    {"value": bhagyank,    **NUMBER_MEANINGS.get(bhagyank, {})},
        "destiny":     {"value": destiny,     **NUMBER_MEANINGS.get(destiny, {})},
        "soul_urge":   {"value": soul_urge,   **NUMBER_MEANINGS.get(soul_urge, {})},
        "personality": {"value": personality, **NUMBER_MEANINGS.get(personality, {})},
        "maturity":    {"value": maturity,    **NUMBER_MEANINGS.get(maturity, {})},
        "name_total_raw": name_total_raw,
    }


# ─────────────────────────────────────────────────────────────────────────────
# 6. CHALDEAN ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────

def chaldean(name: str, dob: str) -> Dict[str, Any]:
    """Complete Chaldean numerology analysis. Returns compound + reduced name numbers."""
    name_total_compound = _name_total(name, CHALDEAN)
    # Chaldean preserves the compound (2-digit) number AND its reduction
    name_reduced = _reduce(name_total_compound, preserve_master=False)

    vowel_total = sum(
        CHALDEAN.get(ch, 0)
        for ch in name.upper() if ch in VOWELS
    )
    soul = _reduce(vowel_total, preserve_master=False)

    consonant_total = sum(
        CHALDEAN.get(ch, 0)
        for ch in name.upper() if ch.isalpha() and ch not in VOWELS
    )
    outer = _reduce(consonant_total, preserve_master=False)

    moolank = _moolank(dob)
    bhagyank = _bhagyank(dob)

    return {
        "system": "Chaldean",
        "moolank":   {"value": moolank,  **NUMBER_MEANINGS.get(moolank, {})},
        "bhagyank":  {"value": bhagyank, **NUMBER_MEANINGS.get(bhagyank, {})},
        "name_number_compound": name_total_compound,
        "name_number_single":   {"value": name_reduced, **NUMBER_MEANINGS.get(name_reduced, {})},
        "soul":  {"value": soul,  **NUMBER_MEANINGS.get(soul, {})},
        "outer": {"value": outer, **NUMBER_MEANINGS.get(outer, {})},
        "note": "Chaldean preserves the compound name number — it carries deeper karmic meaning beyond its reduction.",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 7. LO SHU GRID (Chinese Numerology)
# ─────────────────────────────────────────────────────────────────────────────
#
# The Lo Shu magic square is a 3×3 grid where each row, column, and diagonal
# sums to 15. Each cell corresponds to a number 1–9 with a fixed position:
#
#     4  9  2
#     3  5  7
#     8  1  6
#
# The native's DOB digits (DD-MM-YYYY) are plotted into this grid. Missing
# numbers and repeating numbers reveal personality strengths/weaknesses.

LO_SHU_POSITIONS = {
    4: (0, 0), 9: (0, 1), 2: (0, 2),
    3: (1, 0), 5: (1, 1), 7: (1, 2),
    8: (2, 0), 1: (2, 1), 6: (2, 2),
}

LO_SHU_MEANINGS = {
    1: "Self-expression, communication, emotional balance",
    2: "Intuition, sensitivity, cooperation",
    3: "Memory, intellect, logical thinking",
    4: "Discipline, organization, practical skills",
    5: "Will-power, balance, central energy (luck)",
    6: "Creativity, art, love",
    7: "Sacrifice, spirituality, learning",
    8: "Wealth, material energy, business sense",
    9: "Intelligence, ambition, success drive",
}

LO_SHU_PLANES = {
    "Mental Plane (4-9-2)":      [4, 9, 2],
    "Emotional Plane (3-5-7)":   [3, 5, 7],
    "Practical Plane (8-1-6)":   [8, 1, 6],
    "Thought Plane (4-3-8)":     [4, 3, 8],
    "Will Plane (9-5-1)":        [9, 5, 1],
    "Action Plane (2-7-6)":      [2, 7, 6],
    "Golden Yog (4-5-6)":        [4, 5, 6],   # diagonal
    "Silver Yog (2-5-8)":        [2, 5, 8],   # diagonal
}


def lo_shu_grid(dob: str) -> Dict[str, Any]:
    """Generate the Lo Shu Grid analysis from DOB."""
    d = _parse_dob(dob)
    # Compile all digits: day + month + year + moolank + bhagyank
    moolank = _moolank(dob)
    bhagyank = _bhagyank(dob)
    digit_str = f"{d.day:02d}{d.month:02d}{d.year}{moolank}{bhagyank}"
    digits = [int(c) for c in digit_str if c != "0"]   # 0 is not placed in Lo Shu
    counts = Counter(digits)

    # Build the grid
    grid: List[List[str]] = [["·", "·", "·"], ["·", "·", "·"], ["·", "·", "·"]]
    for num, (r, c) in LO_SHU_POSITIONS.items():
        if counts.get(num, 0) > 0:
            grid[r][c] = str(num) * counts[num]

    missing = sorted([n for n in range(1, 10) if counts.get(n, 0) == 0])
    present = sorted([n for n in range(1, 10) if counts.get(n, 0) > 0])

    # Detect active planes (Raj Yogas)
    active_yogas: List[Dict[str, Any]] = []
    for plane_name, nums in LO_SHU_PLANES.items():
        if all(counts.get(n, 0) > 0 for n in nums):
            active_yogas.append({
                "plane":   plane_name,
                "numbers": nums,
                "effect":  "ACTIVE — full strength of this plane in life",
            })

    return {
        "system": "Lo Shu Grid (Chinese)",
        "grid": grid,
        "grid_visual": "\n".join("  ".join(row) for row in grid),
        "digit_counts":  dict(counts),
        "present_numbers": present,
        "missing_numbers": [
            {"number": n, "meaning_missing": f"Lacks: {LO_SHU_MEANINGS[n]}"}
            for n in missing
        ],
        "active_yogas": active_yogas,
        "moolank":  moolank,
        "bhagyank": bhagyank,
        "summary": (
            f"{len(present)} numbers active, {len(missing)} missing, "
            f"{len(active_yogas)} yogas formed."
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
# 8. FULL COMBINED ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────

def full_numerology(name: str, dob: str, gender: str = "male") -> Dict[str, Any]:
    """All three systems + Kua, in one envelope."""
    return {
        "name":      name,
        "dob":       dob,
        "gender":    gender,
        "pythagorean": pythagorean(name, dob),
        "chaldean":    chaldean(name, dob),
        "lo_shu":      lo_shu_grid(dob),
        "kua_number":  _kua_number(dob, gender),
    }
