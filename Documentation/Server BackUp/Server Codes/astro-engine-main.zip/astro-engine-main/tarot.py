"""
tarot.py — numiVeda Kaaliyo Astro Engine — Module D2 (Tarot Engine)

10 endpoints for Rider-Waite-Smith Tarot readings.

Endpoints:
    handle_profile           — Master reading (birth-seeded Celtic Cross)
    handle_daily_card        — One card for today (date + birth seeded)
    handle_three_card        — Past/Present/Future spread
    handle_celtic_cross      — 10-card Celtic Cross
    handle_year_ahead        — 12 cards, one per month from solar return
    handle_decision          — 5-card decision spread
    handle_card_meaning      — Lookup specific card by name
    handle_suit_overview     — Suit-level themes (Cups/Wands/Swords/Pentacles/Major)
    handle_shuffle           — Fresh random shuffle (non-deterministic)
    handle_question_focused  — 3-card draw seeded by question text + birth

Architecture:
    - No chart casting required.
    - RNG seeded with hash(dob + spread_type + optional_context) for
      deterministic personal readings. Same DOB + same spread = same cards
      until user requests fresh_shuffle=True.
    - All 78 cards from public-domain Rider-Waite-Smith (1909).
    - Returns classical card data + position-specific question.
      Interpretation is downstream app responsibility.
"""

import hashlib
import random
from datetime import datetime, date
from typing import Dict, List, Optional, Any

from tarot_data import (
    FULL_DECK,
    MAJOR_ARCANA,
    SUITS,
    SUIT_METADATA,
    SPREAD_LAYOUTS,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# RNG SEEDING — Deterministic per (birth_dob, spread, context)
# ════════════════════════════════════════════════════════════════════════

def _seed_rng(seed_components: List[str]) -> random.Random:
    """
    Create a deterministic RNG from a list of seed strings.
    Same components → same RNG state → same draws.
    """
    combined = "|".join(seed_components)
    h = hashlib.sha256(combined.encode("utf-8")).hexdigest()
    seed_int = int(h[:16], 16)  # use first 16 hex chars as 64-bit int
    return random.Random(seed_int)


def _fresh_rng() -> random.Random:
    """Non-deterministic RNG (true random shuffle)."""
    return random.Random()


# ════════════════════════════════════════════════════════════════════════
# CORE DRAW LOGIC
# ════════════════════════════════════════════════════════════════════════

def _shuffle_deck(rng: random.Random) -> List[Dict]:
    """Return a shuffled copy of the full 78-card deck."""
    deck_copy = list(FULL_DECK)
    rng.shuffle(deck_copy)
    return deck_copy


def _draw_cards(rng: random.Random, count: int) -> List[Dict]:
    """Draw `count` cards from a shuffled deck, with random orientation (upright/reversed)."""
    shuffled = _shuffle_deck(rng)
    drawn = shuffled[:count]
    result: List[Dict] = []
    for card in drawn:
        # Random orientation — 50/50
        reversed_flag = rng.random() < 0.5
        result.append({
            "name":       card["name"],
            "arcana":     card["arcana"],
            "suit":       card.get("suit"),
            "number":     card.get("number"),
            "element":    card.get("element"),
            "planet":     card.get("planet"),
            "sign":       card.get("sign"),
            "keywords":   card.get("keywords", []),
            "orientation":"reversed" if reversed_flag else "upright",
            "meaning":    card["reversed"] if reversed_flag else card["upright"],
            "astro_link": card.get("astro_link"),
        })
    return result


def _apply_to_spread(spread_name: str, drawn_cards: List[Dict]) -> List[Dict]:
    """Map drawn cards to spread positions with position-specific questions."""
    layout = SPREAD_LAYOUTS[spread_name]
    positions = layout["positions"]
    if len(drawn_cards) != len(positions):
        raise ValueError(f"Spread {spread_name} expects {len(positions)} cards, got {len(drawn_cards)}")
    result: List[Dict] = []
    for pos, card in zip(positions, drawn_cards):
        result.append({
            "position":         pos["index"],
            "position_name":    pos["name"],
            "position_question":pos["question"],
            "card":             card,
        })
    return result


def _get_rng_for_request(birth: Optional[Dict[str, Any]],
                        spread_type: str,
                        context_seed: str = "",
                        fresh_shuffle: bool = False) -> random.Random:
    """Build RNG with birth-anchored seeding unless fresh_shuffle requested."""
    if fresh_shuffle or birth is None:
        return _fresh_rng()
    components = [birth.get("dob", ""), spread_type]
    if context_seed:
        components.append(context_seed)
    return _seed_rng(components)


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT HANDLERS
# ════════════════════════════════════════════════════════════════════════

def handle_daily_card(birth: Optional[Dict[str, Any]] = None,
                      target_date: Optional[str] = None,
                      fresh_shuffle: bool = False) -> Dict[str, Any]:
    """Endpoint 2: Single card for the target date (defaults to today)."""
    if target_date is None:
        target_date = date.today().isoformat()
    # Date is part of seed → different card each day, but same day always returns same card
    rng = _get_rng_for_request(birth, "daily_card", context_seed=target_date,
                                fresh_shuffle=fresh_shuffle)
    cards = _draw_cards(rng, 1)
    spread = _apply_to_spread("daily_card", cards)
    return {
        "spread_type":     "daily_card",
        "target_date":     target_date,
        "deterministic":   not fresh_shuffle and birth is not None,
        "seeded_by":       ["dob", "daily_card", target_date] if (birth and not fresh_shuffle) else "random",
        "draw":            spread,
        "citation":        CLASSICAL_CITATIONS["tarot"],
    }


def handle_three_card(birth: Optional[Dict[str, Any]] = None,
                      context: str = "",
                      fresh_shuffle: bool = False) -> Dict[str, Any]:
    """Endpoint 3: Past / Present / Future three-card spread."""
    rng = _get_rng_for_request(birth, "three_card", context_seed=context,
                                fresh_shuffle=fresh_shuffle)
    cards = _draw_cards(rng, 3)
    spread = _apply_to_spread("three_card", cards)
    return {
        "spread_type":     "three_card",
        "context":         context or "(no specific context)",
        "deterministic":   not fresh_shuffle and birth is not None,
        "draw":            spread,
        "citation":        CLASSICAL_CITATIONS["spreads"],
    }


def handle_celtic_cross(birth: Optional[Dict[str, Any]] = None,
                        context: str = "",
                        fresh_shuffle: bool = False) -> Dict[str, Any]:
    """Endpoint 4: Full 10-card Celtic Cross spread."""
    rng = _get_rng_for_request(birth, "celtic_cross", context_seed=context,
                                fresh_shuffle=fresh_shuffle)
    cards = _draw_cards(rng, 10)
    spread = _apply_to_spread("celtic_cross", cards)
    return {
        "spread_type":     "celtic_cross",
        "context":         context or "(no specific context)",
        "deterministic":   not fresh_shuffle and birth is not None,
        "draw":            spread,
        "citation":        CLASSICAL_CITATIONS["spreads"],
    }


def handle_year_ahead(birth: Optional[Dict[str, Any]] = None,
                      start_year: Optional[int] = None,
                      fresh_shuffle: bool = False) -> Dict[str, Any]:
    """Endpoint 5: 12 cards, one per month, starting from a year (defaults to current)."""
    if start_year is None:
        start_year = date.today().year
    context = f"year_{start_year}"
    rng = _get_rng_for_request(birth, "year_ahead", context_seed=context,
                                fresh_shuffle=fresh_shuffle)
    cards = _draw_cards(rng, 12)
    spread = _apply_to_spread("year_ahead", cards)
    # Add calendar month labels
    months_named = ["January", "February", "March", "April", "May", "June",
                    "July", "August", "September", "October", "November", "December"]
    for i, slot in enumerate(spread):
        slot["calendar_month"] = months_named[i]
        slot["year"] = start_year
    return {
        "spread_type":     "year_ahead",
        "start_year":      start_year,
        "deterministic":   not fresh_shuffle and birth is not None,
        "draw":            spread,
        "citation":        CLASSICAL_CITATIONS["spreads"],
    }


def handle_decision(birth: Optional[Dict[str, Any]] = None,
                    decision_context: str = "",
                    fresh_shuffle: bool = False) -> Dict[str, Any]:
    """Endpoint 6: 5-card decision spread (situation/path-A/path-B/needed/recommendation)."""
    rng = _get_rng_for_request(birth, "decision", context_seed=decision_context,
                                fresh_shuffle=fresh_shuffle)
    cards = _draw_cards(rng, 5)
    spread = _apply_to_spread("decision", cards)
    return {
        "spread_type":      "decision",
        "decision_context": decision_context or "(no specific decision context)",
        "deterministic":    not fresh_shuffle and birth is not None,
        "draw":             spread,
        "citation":         CLASSICAL_CITATIONS["spreads"],
    }


def handle_card_meaning(card_name: str) -> Dict[str, Any]:
    """Endpoint 7: Lookup specific card by name (case-insensitive)."""
    if not card_name:
        return {"error": "card_name required"}
    target = card_name.strip().lower()
    for card in FULL_DECK:
        if card["name"].lower() == target:
            return {
                "name":         card["name"],
                "arcana":       card["arcana"],
                "suit":         card.get("suit"),
                "number":       card.get("number"),
                "element":      card.get("element"),
                "planet":       card.get("planet"),
                "sign":         card.get("sign"),
                "keywords":     card.get("keywords", []),
                "upright":      card["upright"],
                "reversed":     card["reversed"],
                "astro_link":   card.get("astro_link"),
                "citation":     CLASSICAL_CITATIONS["tarot"],
            }
    return {
        "error":          f"Card '{card_name}' not found in 78-card RWS deck",
        "valid_examples": ["The Fool", "Ace of Cups", "Knight of Wands", "Queen of Pentacles", "Death"],
    }


def handle_suit_overview(suit: Optional[str] = None) -> Dict[str, Any]:
    """Endpoint 8: Suit-level themes. If suit=None, returns all suits + Major Arcana."""
    if suit:
        suit_normalized = suit.strip().capitalize()
        if suit_normalized in SUIT_METADATA:
            meta = SUIT_METADATA[suit_normalized]
            cards_in_suit = [c for c in FULL_DECK if c.get("suit") == suit_normalized]
            return {
                "suit":      suit_normalized,
                "metadata":  meta,
                "card_count":len(cards_in_suit),
                "cards":     [{"name": c["name"], "keywords": c.get("keywords", [])}
                              for c in cards_in_suit],
                "citation":  CLASSICAL_CITATIONS["suit_element"],
            }
        elif suit_normalized.lower() == "major":
            return {
                "suit":      "Major Arcana",
                "metadata":  {"element": "All", "domain": "Spiritual life lessons, archetypes, major themes",
                              "card_count": 22},
                "card_count":22,
                "cards":     [{"name": c["name"], "number": c["number"],
                                "keywords": c.get("keywords", [])} for c in MAJOR_ARCANA],
                "citation":  CLASSICAL_CITATIONS["tarot"],
            }
        else:
            return {"error": f"Suit '{suit}' not recognized",
                    "valid_options": SUITS + ["Major"]}

    # No suit specified — return all 4 suits + Major summary
    overview = {}
    for s in SUITS:
        overview[s] = {
            **SUIT_METADATA[s],
            "card_count": 14,
        }
    overview["Major Arcana"] = {
        "element": "All", "domain": "Spiritual life lessons, archetypes, major themes",
        "card_count": 22,
    }
    return {
        "all_suits":      overview,
        "total_cards":    78,
        "citation":       CLASSICAL_CITATIONS["suit_element"],
    }


def handle_shuffle() -> Dict[str, Any]:
    """Endpoint 9: Fresh non-deterministic full deck shuffle. Returns 78-card order."""
    rng = _fresh_rng()
    shuffled = _shuffle_deck(rng)
    return {
        "shuffle_type":  "fresh_random",
        "deterministic": False,
        "card_count":    len(shuffled),
        "order":         [{"position": i+1, "card_name": c["name"], "arcana": c["arcana"]}
                          for i, c in enumerate(shuffled)],
        "note":          "Order is non-reproducible — for ad-hoc draws, not for personal readings",
        "citation":      CLASSICAL_CITATIONS["tarot"],
    }


def handle_question_focused(question_text: str,
                            birth: Optional[Dict[str, Any]] = None,
                            fresh_shuffle: bool = False) -> Dict[str, Any]:
    """Endpoint 10: 3-card draw focused on a user-provided question."""
    if not question_text or not question_text.strip():
        return {"error": "question_text is required"}
    # Question text becomes context seed; same question + same birth = same cards
    rng = _get_rng_for_request(birth, "question_focused",
                                context_seed=question_text.strip(),
                                fresh_shuffle=fresh_shuffle)
    cards = _draw_cards(rng, 3)
    spread = _apply_to_spread("question_focused", cards)
    return {
        "spread_type":     "question_focused",
        "question":        question_text.strip(),
        "deterministic":   not fresh_shuffle and birth is not None,
        "draw":            spread,
        "note":            "Same question + same birth = same cards. Use fresh_shuffle=True for a new draw.",
        "citation":        CLASSICAL_CITATIONS["spreads"],
    }


def handle_profile(birth: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Endpoint 1 (MASTER): Birth-seeded Celtic Cross + daily card + summary."""
    today = date.today().isoformat()
    daily = handle_daily_card(birth, today, fresh_shuffle=False)
    celtic = handle_celtic_cross(birth, context="master_profile", fresh_shuffle=False)

    headlines: List[str] = []
    if daily.get("draw"):
        d_card = daily["draw"][0]["card"]
        headlines.append(
            f"Today's card: {d_card['name']} ({d_card['orientation']}) — {d_card['meaning'][:80]}..."
        )
    if celtic.get("draw"):
        sig_card = celtic["draw"][0]["card"]   # significator
        outcome_card = celtic["draw"][-1]["card"]  # final outcome
        headlines.append(
            f"Significator: {sig_card['name']} ({sig_card['orientation']})"
        )
        headlines.append(
            f"Final Outcome: {outcome_card['name']} ({outcome_card['orientation']})"
        )

    return {
        "headlines":      headlines,
        "daily_card":     daily,
        "celtic_cross":   celtic,
        "method":         "Birth-anchored deterministic shuffle via SHA-256-seeded RNG. Same birth = same readings. Spread layouts follow traditional Tarot scholarship.",
        "deck_source":    CLASSICAL_CITATIONS["tarot"],
        "spread_source":  CLASSICAL_CITATIONS["spreads"],
    }
