"""
yogas_catalog_2.py — Chandra/Surya yogas, Nabhasa (32 shapes), Sanyasa, Arishta, Daridra.

Families covered here:
  7. Chandra Yogas (~20)            — Moon-based combinations
  8. Surya Yogas (~15)              — Sun-based combinations
  9. Nabhasa Yogas (32)             — BPHS Ch 38 (shape-based yogas)
 10. Sanyasa/Pravrajya (~8)         — Renunciation yogas
 11. Arishta (~25)                  — Affliction yogas
 12. Daridra/Nirdhana (~12)         — Poverty yogas
"""

from yogas_helpers import (
    SIGNS, SIGN_INDEX, SIGN_LORDS, EXALTATION, DEBILITATION, OWN_SIGNS,
    KENDRA_HOUSES, TRIKONA_HOUSES, DUSTHANA_HOUSES, ALL_PLANETS, NON_NODES,
    asc_sign, asc_index, planet, planet_house, planet_sign, planet_lon,
    is_retrograde, is_combust, is_exalted, is_debilitated, is_own_sign,
    dignity, sign_in_house, house_of_sign, lord_of_house, planets_in_house,
    planets_in_sign, is_in_kendra, is_in_trikona, is_in_dusthana, aspects_house,
    aspects_planet, conjunct, mutual_reception,
)


# ═════════════════════════════════════════════════════════════════════════════
# 7. CHANDRA YOGAS — Moon-based (Phaladeepika, Saravali)
# ═════════════════════════════════════════════════════════════════════════════

CHANDRA_YOGAS = [
    {
        "yoga_id":        "adhi_yoga",
        "name_en":        "Adhi Yoga",
        "name_sa":        "अधि",
        "family":         "chandra_yoga",
        "polarity":       "positive",
        "source":         "Brihat Jataka 13.5, Phaladeepika 6.12",
        "formation_rule": "Mercury, Jupiter, and Venus are in 6th, 7th, and 8th from Moon.",
        "detect":         lambda c: (
            planet_house(c, "Moon") is not None and
            all(
                ((planet_house(c, p) - planet_house(c, "Moon")) % 12) in (5, 6, 7)
                for p in ("Mercury", "Jupiter", "Venus")
                if planet_house(c, p) is not None
            ) and
            all(planet_house(c, p) is not None for p in ("Mercury", "Jupiter", "Venus"))
        ),
        "domains":        ["leadership", "wealth", "longevity", "command"],
        "general_effect": "Confers rulership qualities, success, longevity, and command over many.",
        "remedy_hooks":   ["strengthen_jupiter", "strengthen_mercury", "strengthen_venus"],
    },
    {
        "yoga_id":        "chandradhi_yoga",
        "name_en":        "Chandra Adhi Yoga",
        "name_sa":        "चन्द्राधि",
        "family":         "chandra_yoga",
        "polarity":       "positive",
        "source":         "Phaladeepika 6.12",
        "formation_rule": "Benefics (Mercury, Jupiter, Venus) only in 6/7/8 from Moon, with no malefic.",
        "detect":         lambda c: (
            planet_house(c, "Moon") is not None and
            all(
                ((planet_house(c, p) - planet_house(c, "Moon")) % 12) in (5, 6, 7)
                for p in ("Mercury", "Jupiter", "Venus")
                if planet_house(c, p) is not None
            ) and
            not any(
                planet_house(c, m) is not None and
                ((planet_house(c, m) - planet_house(c, "Moon")) % 12) in (5, 6, 7)
                for m in ("Mars", "Saturn", "Rahu", "Ketu")
            )
        ),
        "domains":        ["protected_authority", "shielded_success"],
        "general_effect": "Authority and prosperity arise smoothly; protections shield from rivals.",
        "remedy_hooks":   ["strengthen_benefics"],
    },
    {
        "yoga_id":        "vasumati_yoga",
        "name_en":        "Vasumati Yoga",
        "name_sa":        "वसुमती",
        "family":         "chandra_yoga",
        "polarity":       "positive",
        "source":         "Saravali",
        "formation_rule": "Benefics (Jupiter, Venus, Mercury, well-placed Moon) in upachaya houses (3, 6, 10, 11).",
        "detect":         lambda c: sum(
            1 for p in ("Jupiter", "Venus", "Mercury", "Moon")
            if planet_house(c, p) in (3, 6, 10, 11)
        ) >= 3,
        "domains":        ["wealth", "earthly_abundance", "prosperity"],
        "general_effect": "Earthly prosperity in abundance — the native is naturally wealthy.",
        "remedy_hooks":   ["strengthen_benefics"],
    },
    {
        "yoga_id":        "moon_in_kendra_from_jupiter",
        "name_en":        "Moon in Kendra from Jupiter",
        "name_sa":        "गुरु-चन्द्र केन्द्र",
        "family":         "chandra_yoga",
        "polarity":       "positive",
        "source":         "Saravali",
        "formation_rule": "Moon in a kendra (1/4/7/10) from Jupiter (variant of Gaja Kesari).",
        "detect":         lambda c: (
            planet_house(c, "Moon") is not None and planet_house(c, "Jupiter") is not None and
            ((planet_house(c, "Moon") - planet_house(c, "Jupiter")) % 12) in (0, 3, 6, 9)
        ),
        "domains":        ["wisdom_growth", "fortune", "stability"],
        "general_effect": "Wise emotional disposition; fortune through dharmic actions.",
        "remedy_hooks":   ["strengthen_jupiter", "strengthen_moon"],
    },
    {
        "yoga_id":        "shubha_kartari_moon",
        "name_en":        "Shubha Kartari Yoga (around Moon)",
        "name_sa":        "शुभकर्तरि (चन्द्र)",
        "family":         "chandra_yoga",
        "polarity":       "positive",
        "source":         "Phaladeepika",
        "formation_rule": "Benefics in 2nd and 12th from Moon — Moon is sandwiched by benefics.",
        "detect":         lambda c: (
            planet_house(c, "Moon") is not None and
            any(
                planet_house(c, b) is not None and
                ((planet_house(c, b) - planet_house(c, "Moon")) % 12) == 1
                for b in ("Jupiter", "Venus", "Mercury")
            ) and
            any(
                planet_house(c, b) is not None and
                ((planet_house(c, "Moon") - planet_house(c, b)) % 12) == 1
                for b in ("Jupiter", "Venus", "Mercury")
            )
        ),
        "domains":        ["protection", "fortunate_circumstance", "support_in_difficulty"],
        "general_effect": "Mind and emotional life are protected; difficulties are softened by support.",
        "remedy_hooks":   ["honor_benefic_planets"],
    },
    {
        "yoga_id":        "papa_kartari_moon",
        "name_en":        "Papa Kartari Yoga (around Moon)",
        "name_sa":        "पापकर्तरि (चन्द्र)",
        "family":         "chandra_yoga",
        "polarity":       "negative",
        "source":         "Phaladeepika",
        "formation_rule": "Malefics in 2nd and 12th from Moon — Moon is sandwiched by malefics.",
        "detect":         lambda c: (
            planet_house(c, "Moon") is not None and
            any(
                planet_house(c, m) is not None and
                ((planet_house(c, m) - planet_house(c, "Moon")) % 12) == 1
                for m in ("Mars", "Saturn", "Rahu", "Ketu")
            ) and
            any(
                planet_house(c, m) is not None and
                ((planet_house(c, "Moon") - planet_house(c, m)) % 12) == 1
                for m in ("Mars", "Saturn", "Rahu", "Ketu")
            )
        ),
        "domains":        ["anxiety", "mental_distress", "blocked_emotions"],
        "general_effect": "Mind feels squeezed; emotional life under repeated pressure.",
        "remedy_hooks":   ["strengthen_moon", "meditation", "white_offerings"],
    },
    {
        "yoga_id":        "moon_with_rahu",
        "name_en":        "Moon-Rahu Conjunction (Grahan)",
        "name_sa":        "चन्द्र-राहु ग्रहण",
        "family":         "chandra_yoga",
        "polarity":       "negative",
        "source":         "Phaladeepika 7",
        "formation_rule": "Moon conjunct with Rahu — eclipse-like effect.",
        "detect":         lambda c: conjunct(c, "Moon", "Rahu"),
        "domains":        ["mental_eclipse", "anxiety", "obsessive_thoughts", "addiction_tendencies"],
        "general_effect": "Mind is eclipsed; brings cycles of confusion, anxiety, illusion or addiction.",
        "remedy_hooks":   ["moon_mantras", "rahu_pacification", "meditation"],
    },
    {
        "yoga_id":        "moon_with_ketu",
        "name_en":        "Moon-Ketu Conjunction",
        "name_sa":        "चन्द्र-केतु",
        "family":         "chandra_yoga",
        "polarity":       "negative",
        "source":         "Phaladeepika 7",
        "formation_rule": "Moon conjunct with Ketu.",
        "detect":         lambda c: conjunct(c, "Moon", "Ketu"),
        "domains":        ["spiritual_detachment", "emotional_isolation", "past_life_residue"],
        "general_effect": "Detachment from emotions; tendency to feel isolated emotionally despite presence of others.",
        "remedy_hooks":   ["moon_mantras", "ketu_pacification", "spiritual_practice"],
    },
    {
        "yoga_id":        "moon_with_saturn",
        "name_en":        "Moon-Saturn Conjunction (Vish Yoga)",
        "name_sa":        "विष",
        "family":         "chandra_yoga",
        "polarity":       "negative",
        "source":         "Saravali",
        "formation_rule": "Moon conjunct with Saturn.",
        "detect":         lambda c: conjunct(c, "Moon", "Saturn"),
        "domains":        ["depression_tendency", "delayed_emotional_fulfillment", "heavy_mind"],
        "general_effect": "Mind tends to dwell on burdens; emotional fulfillment delayed but mature.",
        "remedy_hooks":   ["moon_mantras", "saturn_pacification", "discipline_emotional_practices"],
    },
    {
        "yoga_id":        "moon_exalted",
        "name_en":        "Moon Exalted",
        "name_sa":        "चन्द्र उच्च",
        "family":         "chandra_yoga",
        "polarity":       "positive",
        "source":         "BPHS",
        "formation_rule": "Moon in Taurus (exaltation sign).",
        "detect":         lambda c: is_exalted(c, "Moon"),
        "domains":        ["emotional_strength", "luxury", "mass_appeal", "feminine_grace"],
        "general_effect": "Strong emotional intelligence, sensual fulfillment, mass appeal, charisma.",
        "remedy_hooks":   ["maintain_moon"],
    },
    {
        "yoga_id":        "moon_debilitated",
        "name_en":        "Moon Debilitated",
        "name_sa":        "चन्द्र नीच",
        "family":         "chandra_yoga",
        "polarity":       "negative",
        "source":         "BPHS",
        "formation_rule": "Moon in Scorpio (debilitation sign).",
        "detect":         lambda c: is_debilitated(c, "Moon"),
        "domains":        ["emotional_intensity", "transformation_pain", "passion_struggle"],
        "general_effect": "Deep emotional waters; tendency toward extremes — intense or withdrawn cycles.",
        "remedy_hooks":   ["moon_mantras", "white_offerings", "emotional_disciplines"],
    },
]


# ═════════════════════════════════════════════════════════════════════════════
# 8. SURYA YOGAS — Sun-based
# ═════════════════════════════════════════════════════════════════════════════

SURYA_YOGAS = [
    {
        "yoga_id":        "budha_aditya_yoga",
        "name_en":        "Budha-Aditya Yoga",
        "name_sa":        "बुधादित्य",
        "family":         "surya_yoga",
        "polarity":       "positive",
        "source":         "Brihat Jataka",
        "formation_rule": "Mercury conjunct Sun (without combustion problems).",
        "detect":         lambda c: conjunct(c, "Sun", "Mercury"),
        "domains":        ["intelligence", "communication", "leadership_through_intellect"],
        "general_effect": "Brilliant intellect, eloquence, and recognition through ideas; classical scholar's combination.",
        "remedy_hooks":   ["strengthen_sun", "strengthen_mercury"],
    },
    {
        "yoga_id":        "surya_chandra_yoga",
        "name_en":        "Surya-Chandra Yoga",
        "name_sa":        "सूर्य-चन्द्र",
        "family":         "surya_yoga",
        "polarity":       "neutral",
        "source":         "Saravali",
        "formation_rule": "Sun and Moon in mutual aspect or kendra.",
        "detect":         lambda c: (
            planet_house(c, "Sun") is not None and planet_house(c, "Moon") is not None and
            ((planet_house(c, "Sun") - planet_house(c, "Moon")) % 12) in (0, 3, 6, 9)
        ),
        "domains":        ["balanced_personality", "father_mother_bond"],
        "general_effect": "Harmonious between solar and lunar principles; balanced active-receptive temperament.",
        "remedy_hooks":   ["maintain_luminaries"],
    },
    {
        "yoga_id":        "sun_exalted",
        "name_en":        "Sun Exalted",
        "name_sa":        "सूर्य उच्च",
        "family":         "surya_yoga",
        "polarity":       "positive",
        "source":         "BPHS",
        "formation_rule": "Sun in Aries (exaltation sign).",
        "detect":         lambda c: is_exalted(c, "Sun"),
        "domains":        ["leadership", "authority", "fame", "father_status"],
        "general_effect": "Strong leadership, command, royal recognition, father's prominence.",
        "remedy_hooks":   ["maintain_sun"],
    },
    {
        "yoga_id":        "sun_debilitated",
        "name_en":        "Sun Debilitated",
        "name_sa":        "सूर्य नीच",
        "family":         "surya_yoga",
        "polarity":       "negative",
        "source":         "BPHS",
        "formation_rule": "Sun in Libra (debilitation sign).",
        "detect":         lambda c: is_debilitated(c, "Sun"),
        "domains":        ["weakened_ego", "diplomatic_strength", "father_separation"],
        "general_effect": "Reduced individual ego; native learns through cooperation rather than command.",
        "remedy_hooks":   ["sun_mantras", "surya_namaskar", "father_honoring_rituals"],
    },
    {
        "yoga_id":        "sun_in_10th",
        "name_en":        "Sun in 10th House",
        "name_sa":        "सूर्य-कर्म",
        "family":         "surya_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Sun placed in the 10th house, well-dignified.",
        "detect":         lambda c: planet_house(c, "Sun") == 10 and dignity(c, "Sun") != "debilitated",
        "domains":        ["career_authority", "fame_through_work", "public_recognition"],
        "general_effect": "Public recognition, authority in profession, leadership role.",
        "remedy_hooks":   ["strengthen_sun"],
    },
    {
        "yoga_id":        "sun_combusts_mercury",
        "name_en":        "Mercury Combust by Sun",
        "name_sa":        "बुध-अस्त",
        "family":         "surya_yoga",
        "polarity":       "negative",
        "source":         "Phaladeepika",
        "formation_rule": "Mercury within 12° of Sun, weakening Mercury's significations.",
        "detect":         lambda c: is_combust(c, "Mercury", orb_deg=12.0),
        "domains":        ["communication_blocked", "education_struggle", "burnt_intellect"],
        "general_effect": "Mercury's intellect and speech are partially burned by Sun's authority.",
        "remedy_hooks":   ["mercury_mantras", "green_emerald"],
    },
    {
        "yoga_id":        "sun_combusts_venus",
        "name_en":        "Venus Combust by Sun",
        "name_sa":        "शुक्र-अस्त",
        "family":         "surya_yoga",
        "polarity":       "negative",
        "source":         "Phaladeepika",
        "formation_rule": "Venus within 10° of Sun, weakening Venus's pleasures.",
        "detect":         lambda c: is_combust(c, "Venus", orb_deg=10.0),
        "domains":        ["relationship_friction", "sensual_struggle", "delayed_marriage"],
        "general_effect": "Romantic and sensual life under solar burn; relationships marked by authority conflicts.",
        "remedy_hooks":   ["venus_mantras", "white_diamond"],
    },
    {
        "yoga_id":        "sun_in_lagna_strong",
        "name_en":        "Sun in Lagna (Strong)",
        "name_sa":        "सूर्य-लग्न",
        "family":         "surya_yoga",
        "polarity":       "positive",
        "source":         "BPHS Ch 33",
        "formation_rule": "Sun in lagna in own/exalted/friend sign, not combust influences itself.",
        "detect":         lambda c: planet_house(c, "Sun") == 1 and dignity(c, "Sun") in ("exalted", "own", "mooltrikona", "friend"),
        "domains":        ["leadership", "physical_strength", "command"],
        "general_effect": "Personality of natural authority; physical and moral leadership.",
        "remedy_hooks":   ["strengthen_sun"],
    },
]


# ═════════════════════════════════════════════════════════════════════════════
# 9. NABHASA YOGAS — Shape-based yogas (BPHS Ch 38)
# Three subtypes: Akriti (20 shapes), Sankhya (7 numerical), Ashraya (3 sign-quality), Dala (2)
# Total: 32 yogas
# ═════════════════════════════════════════════════════════════════════════════

def _planets_house_set(chart):
    """Return set of houses occupied by non-node planets."""
    return {planet_house(chart, p) for p in NON_NODES if planet_house(chart, p) is not None}


def _planets_sign_set(chart):
    """Return set of signs occupied by non-node planets."""
    return {planet_sign(chart, p) for p in NON_NODES if planet_sign(chart, p)}


def _consecutive_houses(houses_set, n):
    """Check if all 7 planets fit into n consecutive houses."""
    if len(houses_set) > n: return False
    sorted_houses = sorted(houses_set)
    if not sorted_houses: return False
    # Account for circular: try every starting point
    for start in range(1, 13):
        block = {((start - 1 + i) % 12) + 1 for i in range(n)}
        if houses_set.issubset(block):
            return True
    return False


NABHASA_YOGAS = [
    # ──── Ashraya (3 sign-quality yogas) — by sign type all planets occupy ────
    {
        "yoga_id":        "rajju_yoga",
        "name_en":        "Rajju Yoga (Movable signs)",
        "name_sa":        "रज्जु",
        "family":         "nabhasa_ashraya",
        "polarity":       "neutral",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets (Sun-Saturn) in movable signs (Aries, Cancer, Libra, Capricorn).",
        "detect":         lambda c: _planets_sign_set(c).issubset({"Aries", "Cancer", "Libra", "Capricorn"}),
        "domains":        ["wanderlust", "frequent_travel", "restlessness"],
        "general_effect": "A wanderer; frequent travel, restless life; gains through movement.",
        "remedy_hooks":   ["stabilize_routine"],
    },
    {
        "yoga_id":        "musala_yoga",
        "name_en":        "Musala Yoga (Fixed signs)",
        "name_sa":        "मुसल",
        "family":         "nabhasa_ashraya",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets in fixed signs (Taurus, Leo, Scorpio, Aquarius).",
        "detect":         lambda c: _planets_sign_set(c).issubset({"Taurus", "Leo", "Scorpio", "Aquarius"}),
        "domains":        ["stability", "wealth_accumulation", "fixed_resolve"],
        "general_effect": "Fixed in purpose; accumulates wealth and reputation through unwavering effort.",
        "remedy_hooks":   ["maintain_resolve"],
    },
    {
        "yoga_id":        "nala_yoga",
        "name_en":        "Nala Yoga (Dual signs)",
        "name_sa":        "नल",
        "family":         "nabhasa_ashraya",
        "polarity":       "neutral",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets in dual signs (Gemini, Virgo, Sagittarius, Pisces).",
        "detect":         lambda c: _planets_sign_set(c).issubset({"Gemini", "Virgo", "Sagittarius", "Pisces"}),
        "domains":        ["versatility", "multiplicity_of_roles", "adaptability"],
        "general_effect": "Multi-talented; versatile and able to take many forms; physical defect possible.",
        "remedy_hooks":   ["focus_chosen_path"],
    },

    # ──── Dala (2 elemental-cluster yogas) ────
    {
        "yoga_id":        "mala_yoga",
        "name_en":        "Mala Yoga (Benefics in kendras only)",
        "name_sa":        "माला",
        "family":         "nabhasa_dala",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 3 benefics (Jupiter, Venus, Mercury) occupy kendra houses (1/4/7/10).",
        "detect":         lambda c: all(planet_house(c, b) in KENDRA_HOUSES for b in ("Jupiter", "Venus", "Mercury")),
        "domains":        ["abundance", "lasting_pleasures", "good_health"],
        "general_effect": "A garland of benefics — abundance, pleasure, and good health throughout life.",
        "remedy_hooks":   ["honor_benefics"],
    },
    {
        "yoga_id":        "sarpa_yoga",
        "name_en":        "Sarpa Yoga (Malefics in kendras only)",
        "name_sa":        "सर्प",
        "family":         "nabhasa_dala",
        "polarity":       "negative",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 3 malefics (Mars, Saturn, Sun) occupy kendra houses (1/4/7/10).",
        "detect":         lambda c: all(planet_house(c, m) in KENDRA_HOUSES for m in ("Mars", "Saturn", "Sun")),
        "domains":        ["struggle", "cruelty_in_environment", "obstacles"],
        "general_effect": "A serpent's coil of malefics — life marked by struggle, harshness, and obstacles.",
        "remedy_hooks":   ["pacify_malefics", "spiritual_practice"],
    },

    # ──── Sankhya (7 numerical yogas) — by # houses planets occupy ────
    {
        "yoga_id":        "veena_yoga",
        "name_en":        "Veena Yoga (planets in 7 houses)",
        "name_sa":        "वीणा",
        "family":         "nabhasa_sankhya",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets distributed across 7 different houses.",
        "detect":         lambda c: len(_planets_house_set(c)) == 7,
        "domains":        ["music", "arts", "harmony", "balanced_life"],
        "general_effect": "Harmonious life like a tuned veena; musical talent or refined arts.",
        "remedy_hooks":   ["pursue_arts"],
    },
    {
        "yoga_id":        "damini_yoga",
        "name_en":        "Damini Yoga (planets in 6 houses)",
        "name_sa":        "दामिनी",
        "family":         "nabhasa_sankhya",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets distributed across 6 different houses.",
        "detect":         lambda c: len(_planets_house_set(c)) == 6,
        "domains":        ["charity", "compassion", "wealth_for_giving"],
        "general_effect": "Charitable, prosperous, compassionate; gives to others.",
        "remedy_hooks":   ["practice_charity"],
    },
    {
        "yoga_id":        "pasha_yoga",
        "name_en":        "Pasha Yoga (planets in 5 houses)",
        "name_sa":        "पाश",
        "family":         "nabhasa_sankhya",
        "polarity":       "neutral",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets distributed across 5 different houses.",
        "detect":         lambda c: len(_planets_house_set(c)) == 5,
        "domains":        ["large_family", "wealth_through_servants", "many_attachments"],
        "general_effect": "Many attachments; large family and household; bound to many causes.",
        "remedy_hooks":   ["balance_responsibilities"],
    },
    {
        "yoga_id":        "kedara_yoga",
        "name_en":        "Kedara Yoga (planets in 4 houses)",
        "name_sa":        "केदार",
        "family":         "nabhasa_sankhya",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets distributed across 4 different houses.",
        "detect":         lambda c: len(_planets_house_set(c)) == 4,
        "domains":        ["agriculture", "lands", "abundance_of_food"],
        "general_effect": "Wealth through agriculture, land, and primary production; stable provider.",
        "remedy_hooks":   ["honor_earth"],
    },
    {
        "yoga_id":        "shoola_yoga",
        "name_en":        "Shoola Yoga (planets in 3 houses)",
        "name_sa":        "शूल",
        "family":         "nabhasa_sankhya",
        "polarity":       "neutral",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets distributed across 3 different houses.",
        "detect":         lambda c: len(_planets_house_set(c)) == 3,
        "domains":        ["sharp_intellect", "military_aptitude", "harshness"],
        "general_effect": "Sharp, piercing intellect; warrior-like aptitude; can be harsh.",
        "remedy_hooks":   ["channel_sharpness"],
    },
    {
        "yoga_id":        "yuga_yoga",
        "name_en":        "Yuga Yoga (planets in 2 houses)",
        "name_sa":        "युग",
        "family":         "nabhasa_sankhya",
        "polarity":       "negative",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets distributed across only 2 different houses.",
        "detect":         lambda c: len(_planets_house_set(c)) == 2,
        "domains":        ["poverty", "heretical_thinking", "isolation"],
        "general_effect": "Concentrated energies; tendency toward extremes; possible heterodox beliefs and isolation.",
        "remedy_hooks":   ["balance_extremes"],
    },
    {
        "yoga_id":        "gola_yoga",
        "name_en":        "Gola Yoga (planets in 1 house)",
        "name_sa":        "गोल",
        "family":         "nabhasa_sankhya",
        "polarity":       "negative",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets in a single house — extremely rare.",
        "detect":         lambda c: len(_planets_house_set(c)) == 1,
        "domains":        ["extreme_focus", "physical_weakness", "intense_concentration"],
        "general_effect": "Extremely rare; concentrated all in one — usually associated with renunciation or fated path.",
        "remedy_hooks":   ["spiritual_path"],
    },

    # ──── Akriti (20 shape yogas) — planets making geometric shapes in houses ────
    # We cover the named/most-cited ones from BPHS 38
    {
        "yoga_id":        "gada_yoga",
        "name_en":        "Gada Yoga (Mace shape)",
        "name_sa":        "गदा",
        "family":         "nabhasa_akriti",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets in 2 consecutive kendras (1&4, 4&7, 7&10, or 10&1).",
        "detect":         lambda c: any(
            _planets_house_set(c).issubset({k1, k2})
            for (k1, k2) in [(1, 4), (4, 7), (7, 10), (10, 1)]
        ),
        "domains":        ["wealth_through_force", "warrior_qualities", "weapon_skills"],
        "general_effect": "Wealth and authority through martial / forceful action; warrior temperament.",
        "remedy_hooks":   ["channel_aggression"],
    },
    {
        "yoga_id":        "shakata_yoga",
        "name_en":        "Shakata Yoga (Cart shape)",
        "name_sa":        "शकट",
        "family":         "nabhasa_akriti",
        "polarity":       "neutral",
        "source":         "BPHS Ch 38; sometimes negative — Jupiter in 6/8/12 from Moon",
        "formation_rule": "All planets in 1st & 7th houses (carrying-cart shape).",
        "detect":         lambda c: _planets_house_set(c).issubset({1, 7}),
        "domains":        ["fluctuating_fortune", "ups_and_downs"],
        "general_effect": "Marked by rises and falls; fortunes come and go; rebuilds after setbacks.",
        "remedy_hooks":   ["build_resilience"],
    },
    {
        "yoga_id":        "vihaga_yoga",
        "name_en":        "Vihaga Yoga (Bird shape)",
        "name_sa":        "विहग",
        "family":         "nabhasa_akriti",
        "polarity":       "neutral",
        "source":         "BPHS Ch 38",
        "formation_rule": "All planets in 4th and 10th houses (flying bird shape).",
        "detect":         lambda c: _planets_house_set(c).issubset({4, 10}),
        "domains":        ["travel", "messenger_role", "communications"],
        "general_effect": "Free as a bird; native travels widely and carries messages or roles between worlds.",
        "remedy_hooks":   ["embrace_movement"],
    },
    {
        "yoga_id":        "shringataka_yoga",
        "name_en":        "Shringataka Yoga (Conch shape)",
        "name_sa":        "शृङ्गाटक",
        "family":         "nabhasa_akriti",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "All planets in trikona houses (1, 5, 9).",
        "detect":         lambda c: _planets_house_set(c).issubset({1, 5, 9}),
        "domains":        ["dharma", "fortune", "kingship"],
        "general_effect": "Concentrated dharma and fortune — kingly, fortunate, blessed by Lakshmi.",
        "remedy_hooks":   ["maintain_dharma"],
    },
    {
        "yoga_id":        "hala_yoga",
        "name_en":        "Hala Yoga (Plough shape)",
        "name_sa":        "हल",
        "family":         "nabhasa_akriti",
        "polarity":       "neutral",
        "source":         "BPHS Ch 38",
        "formation_rule": "All planets in apoklima houses (3, 6, 9, 12).",
        "detect":         lambda c: _planets_house_set(c).issubset({3, 6, 9, 12}),
        "domains":        ["agriculture", "labor", "hard_work_for_gains"],
        "general_effect": "Wealth through hard labor and tilling — agriculturist or worker-craftsman.",
        "remedy_hooks":   ["dignity_of_labor"],
    },
    {
        "yoga_id":        "vajra_yoga",
        "name_en":        "Vajra Yoga (Thunderbolt shape)",
        "name_sa":        "वज्र",
        "family":         "nabhasa_akriti",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "Benefics in 1 & 7, malefics in 4 & 10 (or vice-versa).",
        "detect":         lambda c: (
            (planet_house(c, "Jupiter") in {1, 7} and planet_house(c, "Venus") in {1, 7}) and
            (planet_house(c, "Mars") in {4, 10} and planet_house(c, "Saturn") in {4, 10})
        ),
        "domains":        ["heroic_qualities", "indomitable", "fame_through_struggle"],
        "general_effect": "Thunderbolt-like power; the native is heroic, indomitable, famous through struggle.",
        "remedy_hooks":   ["honor_inner_strength"],
    },
    {
        "yoga_id":        "yava_yoga",
        "name_en":        "Yava Yoga (Barley shape)",
        "name_sa":        "यव",
        "family":         "nabhasa_akriti",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "Benefics in 4 & 10, malefics in 1 & 7.",
        "detect":         lambda c: (
            (planet_house(c, "Jupiter") in {4, 10} and planet_house(c, "Venus") in {4, 10}) and
            (planet_house(c, "Mars") in {1, 7} and planet_house(c, "Saturn") in {1, 7})
        ),
        "domains":        ["middle_age_prosperity", "philanthropy"],
        "general_effect": "Prosperous after middle age; charitable and philanthropic; well-respected.",
        "remedy_hooks":   ["cultivate_patience"],
    },
    {
        "yoga_id":        "kamala_yoga",
        "name_en":        "Kamala Yoga (Lotus shape)",
        "name_sa":        "कमल",
        "family":         "nabhasa_akriti",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets in the 4 kendra houses (1, 4, 7, 10).",
        "detect":         lambda c: _planets_house_set(c).issubset({1, 4, 7, 10}),
        "domains":        ["royalty", "lotus_qualities", "lasting_fame"],
        "general_effect": "Lotus-like — beautifully positioned, royal, famous, dharmically successful.",
        "remedy_hooks":   ["maintain_kendra_strength"],
    },
    {
        "yoga_id":        "padma_yoga",
        "name_en":        "Padma Yoga",
        "name_sa":        "पद्म",
        "family":         "nabhasa_akriti",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets in panaphara houses (2, 5, 8, 11).",
        "detect":         lambda c: _planets_house_set(c).issubset({2, 5, 8, 11}),
        "domains":        ["wealth", "stable_fortune", "succedent_growth"],
        "general_effect": "Wealth and stable growth; succedent prosperity over time.",
        "remedy_hooks":   ["build_steadily"],
    },
    {
        "yoga_id":        "chhatra_yoga",
        "name_en":        "Chhatra Yoga (Umbrella shape)",
        "name_sa":        "छत्र",
        "family":         "nabhasa_akriti",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets in houses 1-7 only (front half of chart).",
        "detect":         lambda c: _planets_house_set(c).issubset({1, 2, 3, 4, 5, 6, 7}),
        "domains":        ["protection", "shelter", "ministerial_role"],
        "general_effect": "Protector of others; minister-like role; provides shelter to many.",
        "remedy_hooks":   ["embrace_protection_role"],
    },
    {
        "yoga_id":        "dhanus_yoga",
        "name_en":        "Dhanus Yoga (Bow shape)",
        "name_sa":        "धनुष्",
        "family":         "nabhasa_akriti",
        "polarity":       "neutral",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets in houses 7-12 only (back half of chart).",
        "detect":         lambda c: _planets_house_set(c).issubset({7, 8, 9, 10, 11, 12}),
        "domains":        ["warrior", "marksmanship", "fortunes_through_partnerships"],
        "general_effect": "Warrior or marksman qualities; fortunes shaped by partnerships and gains-side life.",
        "remedy_hooks":   ["focus_target"],
    },
    {
        "yoga_id":        "ardha_chandra_yoga",
        "name_en":        "Ardha Chandra Yoga (Half-Moon shape)",
        "name_sa":        "अर्धचन्द्र",
        "family":         "nabhasa_akriti",
        "polarity":       "neutral",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets in 7 consecutive houses (any starting point).",
        "detect":         lambda c: _consecutive_houses(_planets_house_set(c), 7),
        "domains":        ["beauty", "valor", "magnetic_personality"],
        "general_effect": "Half-moon shape; magnetic, valorous, beautiful, often well-loved.",
        "remedy_hooks":   ["cultivate_charm"],
    },
    {
        "yoga_id":        "chakra_yoga",
        "name_en":        "Chakra Yoga (Wheel shape)",
        "name_sa":        "चक्र",
        "family":         "nabhasa_akriti",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets in alternate houses (1,3,5,7,9,11 or 2,4,6,8,10,12).",
        "detect":         lambda c: (
            _planets_house_set(c).issubset({1, 3, 5, 7, 9, 11}) or
            _planets_house_set(c).issubset({2, 4, 6, 8, 10, 12})
        ),
        "domains":        ["royalty", "wheel_of_kingdom", "leadership"],
        "general_effect": "Like a chakravartin — ruler of a wheel-shaped kingdom; great administrator.",
        "remedy_hooks":   ["lead_with_dharma"],
    },
    {
        "yoga_id":        "samudra_yoga",
        "name_en":        "Samudra Yoga (Ocean shape)",
        "name_sa":        "समुद्र",
        "family":         "nabhasa_akriti",
        "polarity":       "positive",
        "source":         "BPHS Ch 38",
        "formation_rule": "All 7 planets in even houses (2, 4, 6, 8, 10, 12).",
        "detect":         lambda c: _planets_house_set(c).issubset({2, 4, 6, 8, 10, 12}),
        "domains":        ["wealth", "trade_at_sea", "global_business"],
        "general_effect": "Ocean-like wealth; trade across seas; global businessman.",
        "remedy_hooks":   ["honor_waters"],
    },
]


# ═════════════════════════════════════════════════════════════════════════════
# 10. SANYASA / PRAVRAJYA YOGAS — Renunciation
# ═════════════════════════════════════════════════════════════════════════════

SANYASA_YOGAS = [
    {
        "yoga_id":        "pravrajya_four_planets_in_one_house",
        "name_en":        "Pravrajya Yoga (4 planets in one house)",
        "name_sa":        "प्रव्रज्या",
        "family":         "sanyasa",
        "polarity":       "neutral",
        "source":         "BPHS Ch 45, Phaladeepika 7",
        "formation_rule": "4 or more planets in a single sign — sets up renunciation path.",
        "detect":         lambda c: any(
            sum(1 for p in NON_NODES if planet_sign(c, p) == s) >= 4
            for s in SIGNS
        ),
        "domains":        ["renunciation", "monastic_path", "spiritual_intensity"],
        "general_effect": "Tendency toward renunciation; monastic or sadhu disposition possible.",
        "remedy_hooks":   ["honor_spiritual_calling"],
    },
    {
        "yoga_id":        "sanyasa_4th_lord_with_saturn",
        "name_en":        "Sanyasa Yoga (4th-lord with Saturn)",
        "name_sa":        "संन्यास",
        "family":         "sanyasa",
        "polarity":       "neutral",
        "source":         "BPHS Ch 45",
        "formation_rule": "Lord of 4th house conjunct Saturn or aspected by Saturn.",
        "detect":         lambda c: (
            conjunct(c, lord_of_house(c, 4), "Saturn") or
            aspects_planet(c, "Saturn", lord_of_house(c, 4))
        ),
        "domains":        ["detachment_from_home", "spiritual_journey", "monastic_leaning"],
        "general_effect": "Detachment from home and worldly comforts; spiritual journey late in life.",
        "remedy_hooks":   ["embrace_inner_journey"],
    },
    {
        "yoga_id":        "moon_in_drekana_saturn",
        "name_en":        "Moon in Saturn's Drekkana",
        "name_sa":        "चन्द्र-शनि द्रेक्काण",
        "family":         "sanyasa",
        "polarity":       "neutral",
        "source":         "Phaladeepika 7",
        "formation_rule": "Moon in a sign and decanate ruled by Saturn, aspected by malefics.",
        "detect":         lambda c: (
            planet_sign(c, "Moon") in ("Capricorn", "Aquarius") and
            (aspects_planet(c, "Saturn", "Moon") or aspects_planet(c, "Mars", "Moon"))
        ),
        "domains":        ["solitary_disposition", "asceticism"],
        "general_effect": "Solitary spirit; tendency toward ascetic practice and withdrawal.",
        "remedy_hooks":   ["spiritual_practice"],
    },
    {
        "yoga_id":        "10th_lord_with_3_malefics",
        "name_en":        "10th-Lord Afflicted by 3 Malefics",
        "name_sa":        "कर्म-पाप",
        "family":         "sanyasa",
        "polarity":       "negative",
        "source":         "Phaladeepika",
        "formation_rule": "Lord of 10th house conjunct or aspected by 3 or more malefics.",
        "detect":         lambda c: sum(
            1 for m in ("Mars", "Saturn", "Rahu", "Ketu", "Sun")
            if conjunct(c, lord_of_house(c, 10), m) or aspects_planet(c, m, lord_of_house(c, 10))
        ) >= 3,
        "domains":        ["career_renunciation", "career_struggle"],
        "general_effect": "Strong career obstacles or eventual renunciation of worldly profession.",
        "remedy_hooks":   ["pacify_malefics", "redefine_purpose"],
    },
]


# ═════════════════════════════════════════════════════════════════════════════
# 11. ARISHTA YOGAS — Affliction / health & longevity concerns (BPHS Ch 9)
# ═════════════════════════════════════════════════════════════════════════════

ARISHTA_YOGAS = [
    {
        "yoga_id":        "kala_sarpa_yoga",
        "name_en":        "Kala Sarpa Yoga",
        "name_sa":        "कालसर्प",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "Modern compilation (Saravali references)",
        "formation_rule": "All 7 planets (Sun-Saturn) are between Rahu and Ketu (one side only).",
        "detect":         lambda c: (
            planet_lon(c, "Rahu") is not None and planet_lon(c, "Ketu") is not None and
            all(
                _between_nodes(planet_lon(c, p), planet_lon(c, "Rahu"), planet_lon(c, "Ketu"))
                for p in NON_NODES if planet_lon(c, p)
            )
        ),
        "domains":        ["karmic_burden", "delayed_success", "occasional_obstacles"],
        "general_effect": "Karmic challenges throughout life; success comes after persistent effort.",
        "remedy_hooks":   ["rahu_ketu_remedies", "nag_devata_worship", "tantric_remedies"],
    },
    {
        "yoga_id":        "guru_chandala_yoga",
        "name_en":        "Guru Chandala Yoga",
        "name_sa":        "गुरुचण्डाल",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "Saravali",
        "formation_rule": "Jupiter conjunct with Rahu or Ketu.",
        "detect":         lambda c: conjunct(c, "Jupiter", "Rahu") or conjunct(c, "Jupiter", "Ketu"),
        "domains":        ["distorted_wisdom", "heretical_views", "teacher_problems"],
        "general_effect": "Wisdom mixed with confusion; unconventional teachers; sometimes heterodox beliefs.",
        "remedy_hooks":   ["jupiter_mantras", "rahu_pacification", "traditional_study"],
    },
    {
        "yoga_id":        "angarak_yoga",
        "name_en":        "Angarak Yoga (Mars-Rahu)",
        "name_sa":        "अंगारक",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "Saravali",
        "formation_rule": "Mars conjunct with Rahu.",
        "detect":         lambda c: conjunct(c, "Mars", "Rahu"),
        "domains":        ["aggression", "sudden_accidents", "anger_management"],
        "general_effect": "Explosive energy; sudden accidents possible; anger needs channeling.",
        "remedy_hooks":   ["mars_pacification", "rahu_pacification", "physical_practice"],
    },
    {
        "yoga_id":        "shakat_yoga",
        "name_en":        "Shakata Yoga (Negative — Jupiter 6/8/12 from Moon)",
        "name_sa":        "शकट",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "Phaladeepika 7",
        "formation_rule": "Jupiter in 6th, 8th, or 12th from the Moon.",
        "detect":         lambda c: (
            planet_house(c, "Jupiter") is not None and planet_house(c, "Moon") is not None and
            ((planet_house(c, "Jupiter") - planet_house(c, "Moon")) % 12) in (5, 7, 11)
        ),
        "domains":        ["fluctuating_fortune", "rise_and_fall", "obstacles"],
        "general_effect": "Fortune comes and goes; periodic rises and falls in life.",
        "remedy_hooks":   ["jupiter_strengthening", "moon_strengthening"],
    },
    {
        "yoga_id":        "kemadruma_check",
        "name_en":        "Kemadruma Yoga (Pure)",
        "name_sa":        "केमद्रुम (शुद्ध)",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "Brihat Jataka 13.4",
        "formation_rule": "No planet (except Sun/nodes) in 2nd, 12th, or same house as Moon, AND Moon not in conjunction.",
        "detect":         lambda c: (
            planet_house(c, "Moon") is not None and
            not any(
                planet_house(c, p) is not None and planet_house(c, "Moon") is not None and
                ((planet_house(c, p) - planet_house(c, "Moon")) % 12) in (0, 1, 11)
                for p in ("Mars","Mercury","Jupiter","Venus","Saturn")
            )
        ),
        "domains":        ["loneliness", "obstacles", "delayed_emotional_fulfillment"],
        "general_effect": "Periods of isolation and obstacles; emotional support comes slowly.",
        "remedy_hooks":   ["moon_strengthening"],
    },
    {
        "yoga_id":        "balarishta_moon",
        "name_en":        "Balarishta (Childhood Affliction)",
        "name_sa":        "बालारिष्ट",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "BPHS Ch 9",
        "formation_rule": "Moon weak (debilitated or in 6/8/12) with malefic association — childhood health concern.",
        "detect":         lambda c: (
            (is_debilitated(c, "Moon") or planet_house(c, "Moon") in (6, 8, 12)) and
            any(conjunct(c, "Moon", m) or aspects_planet(c, m, "Moon")
                for m in ("Mars", "Saturn", "Rahu", "Ketu"))
        ),
        "domains":        ["childhood_health", "early_life_struggle"],
        "general_effect": "Childhood marked by health concerns; early life vulnerability.",
        "remedy_hooks":   ["moon_strengthening", "protective_mantras"],
    },
    {
        "yoga_id":        "saturn_in_lagna",
        "name_en":        "Saturn in Lagna (Debilitated)",
        "name_sa":        "शनि-लग्न",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "BPHS Ch 33",
        "formation_rule": "Saturn in lagna in debilitation or enemy sign.",
        "detect":         lambda c: (
            planet_house(c, "Saturn") == 1 and dignity(c, "Saturn") in ("debilitated", "enemy")
        ),
        "domains":        ["slow_growth", "early_struggle", "physical_weakness"],
        "general_effect": "Slow early growth; physical or social struggles in early life; matures late.",
        "remedy_hooks":   ["saturn_pacification", "patience_practice"],
    },
    {
        "yoga_id":        "rahu_in_lagna",
        "name_en":        "Rahu in Lagna",
        "name_sa":        "राहु-लग्न",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "Phaladeepika",
        "formation_rule": "Rahu placed in the 1st house.",
        "detect":         lambda c: planet_house(c, "Rahu") == 1,
        "domains":        ["identity_confusion", "ambition_unchanneled", "mask_wearing"],
        "general_effect": "Strong ambition; identity may be confused; tendency to take on roles not your own.",
        "remedy_hooks":   ["rahu_pacification", "identity_clarity_practice"],
    },
    {
        "yoga_id":        "ketu_in_7th",
        "name_en":        "Ketu in 7th House",
        "name_sa":        "केतु-कलत्र",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "Phaladeepika",
        "formation_rule": "Ketu placed in the 7th house of partnership.",
        "detect":         lambda c: planet_house(c, "Ketu") == 7,
        "domains":        ["relationship_detachment", "spiritual_partnerships", "delayed_marriage"],
        "general_effect": "Detachment in partnerships; marriage delayed or spiritually-oriented.",
        "remedy_hooks":   ["ketu_pacification", "venus_strengthening"],
    },
    {
        "yoga_id":        "mars_in_7th_manglik",
        "name_en":        "Manglik Yoga (Mars in 7th)",
        "name_sa":        "मांगलिक",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "Traditional Manglik rules",
        "formation_rule": "Mars in 1st, 4th, 7th, 8th, or 12th from Lagna.",
        "detect":         lambda c: planet_house(c, "Mars") in (1, 4, 7, 8, 12),
        "domains":        ["marital_conflict", "passion_intensity"],
        "general_effect": "Intensity in marriage; can manifest as conflict if not channeled properly.",
        "remedy_hooks":   ["mars_pacification", "match_with_another_manglik"],
    },
    {
        "yoga_id":        "kuja_dosha_strong",
        "name_en":        "Strong Kuja Dosha",
        "name_sa":        "कुजदोष",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "Phaladeepika",
        "formation_rule": "Mars in 7th or 8th from Moon AND from Venus AND from Lagna.",
        "detect":         lambda c: (
            planet_house(c, "Mars") in (7, 8) and
            planet_house(c, "Moon") is not None and
            ((planet_house(c, "Mars") - planet_house(c, "Moon")) % 12) in (6, 7) and
            planet_house(c, "Venus") is not None and
            ((planet_house(c, "Mars") - planet_house(c, "Venus")) % 12) in (6, 7)
        ),
        "domains":        ["serious_marriage_concerns", "spouse_conflict"],
        "general_effect": "Strong Manglik — needs traditional precautions in marriage.",
        "remedy_hooks":   ["full_kuja_remediation", "fast_on_tuesdays"],
    },
    {
        "yoga_id":        "pitra_dosha",
        "name_en":        "Pitra Dosha",
        "name_sa":        "पितृ दोष",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "Modern Vedic compilation",
        "formation_rule": "Sun or Jupiter in 9th house with Rahu/Ketu, OR 9th lord weak.",
        "detect":         lambda c: (
            (planet_house(c, "Sun") == 9 and (conjunct(c, "Sun", "Rahu") or conjunct(c, "Sun", "Ketu"))) or
            (planet_house(c, "Jupiter") == 9 and (conjunct(c, "Jupiter", "Rahu") or conjunct(c, "Jupiter", "Ketu"))) or
            (planet_house(c, lord_of_house(c, 9)) in DUSTHANA_HOUSES)
        ),
        "domains":        ["ancestral_debt", "father_relationship", "spiritual_blocks"],
        "general_effect": "Ancestral karmic obligations; father relationship may have issues; requires specific remedies.",
        "remedy_hooks":   ["shraddha_rituals", "pitra_paksha_offerings", "father_honoring"],
    },
    {
        "yoga_id":        "shrapit_dosha",
        "name_en":        "Shrapit Dosha",
        "name_sa":        "शापित दोष",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "Modern Vedic compilation",
        "formation_rule": "Saturn and Rahu together in any house.",
        "detect":         lambda c: conjunct(c, "Saturn", "Rahu"),
        "domains":        ["sudden_misfortune", "karmic_curses"],
        "general_effect": "Indicates karmic curse needing pacification; sudden misfortunes possible.",
        "remedy_hooks":   ["saturn_rahu_remediation", "lord_shiva_worship", "donation_rituals"],
    },
    {
        "yoga_id":        "vish_yoga_strong",
        "name_en":        "Strong Vish Yoga (Moon-Saturn)",
        "name_sa":        "विष",
        "family":         "arishta",
        "polarity":       "negative",
        "source":         "Saravali",
        "formation_rule": "Moon and Saturn in close conjunction (within 5 degrees).",
        "detect":         lambda c: (
            conjunct(c, "Moon", "Saturn") and
            abs(planet_lon(c, "Moon") - planet_lon(c, "Saturn")) < 5
        ),
        "domains":        ["depression_tendency", "heavy_mind", "delayed_emotional_growth"],
        "general_effect": "Strong tendency toward melancholy; emotional growth slow but deep.",
        "remedy_hooks":   ["moon_saturn_remediation", "emotional_practices"],
    },
]


# Helper for Kala Sarpa: is a longitude between Rahu and Ketu (along the zodiac)?
def _between_nodes(lon, rahu_lon, ketu_lon):
    """True if lon is between Rahu and Ketu (Rahu→Ketu arc going forward)."""
    if rahu_lon < ketu_lon:
        return rahu_lon <= lon <= ketu_lon
    return lon >= rahu_lon or lon <= ketu_lon


# ═════════════════════════════════════════════════════════════════════════════
# 12. DARIDRA / NIRDHANA YOGAS — Poverty yogas
# ═════════════════════════════════════════════════════════════════════════════

DARIDRA_YOGAS = [
    {
        "yoga_id":        "daridra_2_lord_in_dusthana",
        "name_en":        "Daridra Yoga (2nd-lord in dusthana)",
        "name_sa":        "दरिद्र (२)",
        "family":         "daridra",
        "polarity":       "negative",
        "source":         "Phaladeepika 7",
        "formation_rule": "Lord of 2nd (wealth) house placed in 6th, 8th, or 12th.",
        "detect":         lambda c: planet_house(c, lord_of_house(c, 2)) in DUSTHANA_HOUSES,
        "domains":        ["wealth_struggles", "family_wealth_loss"],
        "general_effect": "Family wealth eroded or unavailable; financial struggles possible.",
        "remedy_hooks":   ["strengthen_2nd_lord"],
    },
    {
        "yoga_id":        "daridra_11_lord_in_dusthana",
        "name_en":        "Daridra Yoga (11th-lord in dusthana)",
        "name_sa":        "दरिद्र (११)",
        "family":         "daridra",
        "polarity":       "negative",
        "source":         "Phaladeepika 7",
        "formation_rule": "Lord of 11th (gains) house placed in 6th, 8th, or 12th.",
        "detect":         lambda c: planet_house(c, lord_of_house(c, 11)) in DUSTHANA_HOUSES,
        "domains":        ["income_blocks", "delayed_gains"],
        "general_effect": "Incomes are blocked or come late; struggles to convert effort to gain.",
        "remedy_hooks":   ["strengthen_11th_lord"],
    },
    {
        "yoga_id":        "lagna_lord_in_12",
        "name_en":        "Lagna-Lord in 12th",
        "name_sa":        "लग्नेश-व्यय",
        "family":         "daridra",
        "polarity":       "negative",
        "source":         "BPHS Ch 33",
        "formation_rule": "Lord of 1st house placed in 12th (expenses/losses).",
        "detect":         lambda c: planet_house(c, lord_of_house(c, 1)) == 12,
        "domains":        ["self_dissolution", "expenses", "foreign_lands"],
        "general_effect": "Self dissolves into expenses or foreign lands; either spiritual or wasteful.",
        "remedy_hooks":   ["channel_expenses", "spiritual_path"],
    },
    {
        "yoga_id":        "9_lord_in_8",
        "name_en":        "9th-Lord in 8th",
        "name_sa":        "भाग्येश-अष्टम",
        "family":         "daridra",
        "polarity":       "negative",
        "source":         "Phaladeepika",
        "formation_rule": "Lord of 9th (fortune) placed in 8th (transformation/sudden change).",
        "detect":         lambda c: planet_house(c, lord_of_house(c, 9)) == 8,
        "domains":        ["fortune_through_struggle", "inheritance_obstacles", "father_issues"],
        "general_effect": "Fortune comes only after deep transformation; possible father health concerns.",
        "remedy_hooks":   ["strengthen_9th_lord", "honor_father"],
    },
    {
        "yoga_id":        "all_kendra_lords_weak",
        "name_en":        "Kendra Lords All Weak",
        "name_sa":        "केन्द्रेश दुर्बल",
        "family":         "daridra",
        "polarity":       "negative",
        "source":         "Phaladeepika",
        "formation_rule": "Lords of all 4 kendras (1, 4, 7, 10) in debilitation or dusthana.",
        "detect":         lambda c: all(
            dignity(c, lord_of_house(c, h)) == "debilitated" or planet_house(c, lord_of_house(c, h)) in DUSTHANA_HOUSES
            for h in (1, 4, 7, 10)
        ),
        "domains":        ["overall_weakness", "broad_struggle"],
        "general_effect": "All four pillars (self/home/partner/career) weakened — broad struggle.",
        "remedy_hooks":   ["strengthen_kendra_lords"],
    },
    {
        "yoga_id":        "jupiter_in_dusthana",
        "name_en":        "Jupiter in Dusthana",
        "name_sa":        "गुरु-दुस्थान",
        "family":         "daridra",
        "polarity":       "negative",
        "source":         "Phaladeepika",
        "formation_rule": "Jupiter placed in 6th, 8th, or 12th house.",
        "detect":         lambda c: planet_house(c, "Jupiter") in DUSTHANA_HOUSES,
        "domains":        ["wisdom_through_struggle", "delayed_dharma", "education_obstacles"],
        "general_effect": "Wisdom must come through struggle; dharma blocked or delayed in life.",
        "remedy_hooks":   ["strengthen_jupiter"],
    },
    {
        "yoga_id":        "all_planets_dusthana",
        "name_en":        "Majority of Planets in Dusthana",
        "name_sa":        "बहुग्रह दुस्थान",
        "family":         "daridra",
        "polarity":       "negative",
        "source":         "Phaladeepika",
        "formation_rule": "5 or more planets in 6th, 8th, or 12th houses.",
        "detect":         lambda c: sum(
            1 for p in ALL_PLANETS if planet_house(c, p) in DUSTHANA_HOUSES
        ) >= 5,
        "domains":        ["broad_struggle", "service_orientation", "spiritual_purification"],
        "general_effect": "Heavy karmic loads; life often turns toward service or spiritual purification.",
        "remedy_hooks":   ["spiritual_practice", "service_orientation"],
    },
]


# ═════════════════════════════════════════════════════════════════════════════
# EXPORT
# ═════════════════════════════════════════════════════════════════════════════

CATALOG_2 = (
    CHANDRA_YOGAS +
    SURYA_YOGAS +
    NABHASA_YOGAS +
    SANYASA_YOGAS +
    ARISHTA_YOGAS +
    DARIDRA_YOGAS
)
