"""
pet_astro.py — numiVeda Kaaliyo Astro Engine — Module F6 (Pet Astrology)

Three endpoints for Vedic pet astrology:
    handle_pet_compatibility — Pet-owner compatibility via adapted nakshatra koots
    handle_pet_naming        — Akshara-based name recommendations from pet nakshatra
    handle_pet_personality   — Pet personality from natal nakshatra + (when available) Sun & lagna

Input modes (per F6 scope decision):
    Mode 1 (birth):       dob + time + lat + lon + timezone  → full chart cast
    Mode 2 (acquisition): acquisition_date + acquisition_time + acquisition_lat +
                          acquisition_lon + acquisition_timezone  → operative chart
                          (Moon nakshatra at acquisition = operative pet nakshatra)

Design (per HANDOVER_v5 carry-forward):
    P1 — All astronomy through cast_chart.
    P2 — Reuse: NAKSHATRA_TO_YONI + YONI_FRIENDLY tables from compatibility.py
         (same pattern F1 used for human koot scoring).
    P5 — F6 has its own Gana table + Tara cycle + akshara fallback. No
         dependency on yogas_helpers.

Public API:
    handle_pet_compatibility(pet, owner) -> dict
    handle_pet_naming(pet) -> dict
    handle_pet_personality(pet) -> dict

Author: Claude (F6, 2026-05-18)
"""

from typing import Dict, List, Optional, Any, Tuple

try:
    from dashaflow import cast_chart
except ImportError as e:
    raise ImportError(f"F6 pet_astro requires dashaflow.cast_chart: {e}")

try:
    from astro_helpers import SIGN_TO_LORD, SIGNS_ORDER
except ImportError as e:
    raise ImportError(f"F6 pet_astro requires astro_helpers: {e}")

# Reuse Yoni tables from compatibility.py (same pattern as F1)
try:
    from compatibility import (
        NAKSHATRA_TO_YONI,
        YONI_SAME_SCORE,
        YONI_FRIENDLY,
        YONI_NEUTRAL_PAIRS,
        YONI_ENEMIES,
    )
except ImportError as e:
    raise ImportError(f"F6 pet_astro requires compatibility module: {e}")


# ════════════════════════════════════════════════════════════════════════
# NAKSHATRA TABLES (F6's own — no dependency on yogas_helpers)
# ════════════════════════════════════════════════════════════════════════

_NAKSHATRAS_ORDER = [
    "Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashira", "Ardra",
    "Punarvasu", "Pushya", "Ashlesha", "Magha", "Purva Phalguni",
    "Uttara Phalguni", "Hasta", "Chitra", "Swati", "Vishakha", "Anuradha",
    "Jyeshtha", "Mula", "Purva Ashadha", "Uttara Ashadha", "Shravana",
    "Dhanishta", "Shatabhisha", "Purva Bhadrapada", "Uttara Bhadrapada",
    "Revati",
]

# Nakshatra → Gana (BPHS Ch. 7) — divine / human / demonic temperament
_NAKSHATRA_TO_GANA = {
    "Ashwini": "Deva", "Bharani": "Manushya", "Krittika": "Rakshasa",
    "Rohini": "Manushya", "Mrigashira": "Deva", "Ardra": "Manushya",
    "Punarvasu": "Deva", "Pushya": "Deva", "Ashlesha": "Rakshasa",
    "Magha": "Rakshasa", "Purva Phalguni": "Manushya",
    "Uttara Phalguni": "Manushya", "Hasta": "Deva", "Chitra": "Rakshasa",
    "Swati": "Deva", "Vishakha": "Rakshasa", "Anuradha": "Deva",
    "Jyeshtha": "Rakshasa", "Mula": "Rakshasa", "Purva Ashadha": "Manushya",
    "Uttara Ashadha": "Manushya", "Shravana": "Deva",
    "Dhanishta": "Rakshasa", "Shatabhisha": "Rakshasa",
    "Purva Bhadrapada": "Manushya", "Uttara Bhadrapada": "Manushya",
    "Revati": "Deva",
}

# Gana Kuta scoring (BPHS Ch. 7) — max 6 points
_GANA_SCORE = {
    ("Deva", "Deva"): 6, ("Manushya", "Manushya"): 6, ("Rakshasa", "Rakshasa"): 6,
    ("Deva", "Manushya"): 5, ("Manushya", "Deva"): 5,
    ("Manushya", "Rakshasa"): 0, ("Rakshasa", "Manushya"): 0,
    ("Deva", "Rakshasa"): 1, ("Rakshasa", "Deva"): 1,
}

# Nakshatra → Lord (used for Graha Maitri Kuta)
_NAKSHATRA_TO_LORD = {
    "Ashwini": "Ketu", "Bharani": "Venus", "Krittika": "Sun",
    "Rohini": "Moon", "Mrigashira": "Mars", "Ardra": "Rahu",
    "Punarvasu": "Jupiter", "Pushya": "Saturn", "Ashlesha": "Mercury",
    "Magha": "Ketu", "Purva Phalguni": "Venus", "Uttara Phalguni": "Sun",
    "Hasta": "Moon", "Chitra": "Mars", "Swati": "Rahu",
    "Vishakha": "Jupiter", "Anuradha": "Saturn", "Jyeshtha": "Mercury",
    "Mula": "Ketu", "Purva Ashadha": "Venus", "Uttara Ashadha": "Sun",
    "Shravana": "Moon", "Dhanishta": "Mars", "Shatabhisha": "Rahu",
    "Purva Bhadrapada": "Jupiter", "Uttara Bhadrapada": "Saturn", "Revati": "Mercury",
}

# Tara cycle (Hora Sara) — 9-fold relationship between two nakshatras
_TARA_TABLE = [
    {"idx": 1, "name": "Janma",    "nature": "Mixed",        "effect": "Reset; original imprint"},
    {"idx": 2, "name": "Sampat",   "nature": "Auspicious",   "effect": "Wealth, prosperity, support"},
    {"idx": 3, "name": "Vipat",    "nature": "Inauspicious", "effect": "Danger, obstacles"},
    {"idx": 4, "name": "Kshema",   "nature": "Auspicious",   "effect": "Wellbeing, peace"},
    {"idx": 5, "name": "Pratyak",  "nature": "Inauspicious", "effect": "Hindrances, returns"},
    {"idx": 6, "name": "Sadhaka",  "nature": "Auspicious",   "effect": "Accomplishment"},
    {"idx": 7, "name": "Vadha",    "nature": "Inauspicious", "effect": "Major obstacles"},
    {"idx": 8, "name": "Mitra",    "nature": "Auspicious",   "effect": "Friendship"},
    {"idx": 9, "name": "Ati-Mitra","nature": "Auspicious",   "effect": "Strong friendship, growth"},
]

# Tara Kuta scoring (BPHS Ch. 7) — max 3 points
# Auspicious taras (2,4,6,8,9 indices in 1-based) → 3 pts
# Mixed (1) → 1.5 pts
# Inauspicious (3,5,7) → 0 pts
_TARA_KUTA_POINTS = {
    1: 1.5, 2: 3.0, 3: 0.0, 4: 3.0, 5: 0.0, 6: 3.0, 7: 0.0, 8: 3.0, 9: 3.0
}

# Planet-to-planet friendship (Naisargika) for Graha Maitri Kuta
# F = friend, n = neutral, e = enemy
_GRAHA_FRIENDS = {
    "Sun":     {"Sun": "F", "Moon": "F", "Mars": "F", "Mercury": "n", "Jupiter": "F",
                  "Venus": "e", "Saturn": "e", "Rahu": "e", "Ketu": "n"},
    "Moon":    {"Sun": "F", "Moon": "F", "Mars": "n", "Mercury": "F", "Jupiter": "n",
                  "Venus": "n", "Saturn": "n", "Rahu": "n", "Ketu": "n"},
    "Mars":    {"Sun": "F", "Moon": "F", "Mars": "F", "Mercury": "e", "Jupiter": "F",
                  "Venus": "n", "Saturn": "n", "Rahu": "n", "Ketu": "F"},
    "Mercury": {"Sun": "F", "Moon": "e", "Mars": "n", "Mercury": "F", "Jupiter": "n",
                  "Venus": "F", "Saturn": "n", "Rahu": "n", "Ketu": "n"},
    "Jupiter": {"Sun": "F", "Moon": "F", "Mars": "F", "Mercury": "e", "Jupiter": "F",
                  "Venus": "e", "Saturn": "n", "Rahu": "n", "Ketu": "n"},
    "Venus":   {"Sun": "e", "Moon": "e", "Mars": "n", "Mercury": "F", "Jupiter": "n",
                  "Venus": "F", "Saturn": "F", "Rahu": "F", "Ketu": "n"},
    "Saturn":  {"Sun": "e", "Moon": "e", "Mars": "e", "Mercury": "F", "Jupiter": "n",
                  "Venus": "F", "Saturn": "F", "Rahu": "F", "Ketu": "n"},
    "Rahu":    {"Sun": "e", "Moon": "n", "Mars": "n", "Mercury": "n", "Jupiter": "n",
                  "Venus": "F", "Saturn": "F", "Rahu": "F", "Ketu": "n"},
    "Ketu":    {"Sun": "n", "Moon": "n", "Mars": "F", "Mercury": "n", "Jupiter": "n",
                  "Venus": "n", "Saturn": "n", "Rahu": "n", "Ketu": "F"},
}

# Graha Maitri Kuta scoring — max 5 points
_GRAHA_MAITRI_SCORE = {
    ("F", "F"): 5.0,   # both friends → max
    ("F", "n"): 4.0, ("n", "F"): 4.0,
    ("n", "n"): 3.0,
    ("F", "e"): 1.0, ("e", "F"): 1.0,
    ("n", "e"): 0.5, ("e", "n"): 0.5,
    ("e", "e"): 0.0,
}

# Akshara fallback table (used if nakshatra_data isn't available)
# Each nakshatra has 4 padas with classical akshara
_NAKSHATRA_AKSHARAS = {
    "Ashwini":          ["Chu", "Che", "Cho", "La"],
    "Bharani":          ["Li", "Lu", "Le", "Lo"],
    "Krittika":         ["A", "Ee", "U", "Ay"],
    "Rohini":           ["O", "Va", "Vee", "Vu"],
    "Mrigashira":       ["Ve", "Vo", "Ka", "Kee"],
    "Ardra":            ["Ku", "Gha", "Ng", "Chh"],
    "Punarvasu":        ["Ke", "Ko", "Ha", "Hee"],
    "Pushya":           ["Hu", "He", "Ho", "Da"],
    "Ashlesha":         ["Dee", "Du", "De", "Do"],
    "Magha":            ["Ma", "Mee", "Mu", "Me"],
    "Purva Phalguni":   ["Mo", "Ta", "Tee", "Tu"],
    "Uttara Phalguni":  ["Te", "To", "Pa", "Pee"],
    "Hasta":            ["Pu", "Sha", "Na", "Tha"],
    "Chitra":           ["Pe", "Po", "Ra", "Ree"],
    "Swati":            ["Ru", "Re", "Ro", "Ta"],
    "Vishakha":         ["Tee", "Tu", "Te", "To"],
    "Anuradha":         ["Na", "Nee", "Nu", "Ne"],
    "Jyeshtha":         ["No", "Ya", "Yee", "Yu"],
    "Mula":             ["Ye", "Yo", "Bha", "Bhi"],
    "Purva Ashadha":    ["Bhu", "Dha", "Pha", "Dha"],
    "Uttara Ashadha":   ["Bhe", "Bho", "Ja", "Jee"],
    "Shravana":         ["Khee", "Khu", "Khe", "Kho"],
    "Dhanishta":        ["Ga", "Gee", "Gu", "Ge"],
    "Shatabhisha":      ["Go", "Sa", "See", "Su"],
    "Purva Bhadrapada": ["Se", "So", "Da", "Dee"],
    "Uttara Bhadrapada":["Du", "Tha", "Jha", "Yna"],
    "Revati":           ["De", "Do", "Cha", "Chee"],
}


# ════════════════════════════════════════════════════════════════════════
# INPUT RESOLUTION — birth vs acquisition mode
# ════════════════════════════════════════════════════════════════════════

def _resolve_pet_chart(pet: Dict[str, Any]) -> Tuple[Dict[str, Any], str]:
    """
    Resolve pet's operative chart from either birth or acquisition mode.

    Returns (chart, mode) where mode is 'birth' or 'acquisition'.
    Raises ValueError if neither mode's data is complete.
    """
    # Mode 1: full birth
    has_birth = all(pet.get(k) for k in ("dob", "time", "lat", "lon"))
    if has_birth:
        chart = cast_chart(
            dob=pet["dob"], time=pet["time"],
            lat=pet["lat"], lon=pet["lon"],
            timezone=pet.get("timezone", "Asia/Kolkata"),
        )
        return chart, "birth"

    # Mode 2: acquisition
    has_acq = all(pet.get(k) for k in
                    ("acquisition_date", "acquisition_time",
                     "acquisition_lat", "acquisition_lon"))
    if has_acq:
        chart = cast_chart(
            dob=pet["acquisition_date"],
            time=pet["acquisition_time"],
            lat=pet["acquisition_lat"],
            lon=pet["acquisition_lon"],
            timezone=pet.get("acquisition_timezone", "Asia/Kolkata"),
        )
        return chart, "acquisition"

    raise ValueError(
        "Pet input requires either full birth details "
        "(dob + time + lat + lon + timezone) OR acquisition details "
        "(acquisition_date + acquisition_time + acquisition_lat + "
        "acquisition_lon + acquisition_timezone)"
    )


def _pet_pada_from_nakshatra_lon(moon_data: Dict[str, Any]) -> int:
    """
    Estimate pet's nakshatra pada from Moon's longitude.
    Each nakshatra spans 13°20' (800 arcmin); each pada spans 3°20' (200 arcmin).
    """
    # Try the easy path first
    pada = moon_data.get("nakshatra_pada") or moon_data.get("pada")
    if pada and 1 <= pada <= 4:
        return int(pada)

    # Compute from longitude
    lon = moon_data.get("longitude") or moon_data.get("lon")
    if lon is None:
        return 1
    in_nak = (lon % (360.0 / 27.0))  # degrees into current nakshatra
    pada = int(in_nak / (13.0 + 20.0/60.0) * 4) + 1
    return max(1, min(4, pada))


# ════════════════════════════════════════════════════════════════════════
# KOOT SCORERS (F6's adapted Ashtakoota — Tara, Yoni, Gana, Graha Maitri)
# ════════════════════════════════════════════════════════════════════════

def _score_tara(pet_nak: str, owner_nak: str) -> Dict[str, Any]:
    """Tara Kuta: 9-fold relationship between nakshatras."""
    try:
        p_idx = _NAKSHATRAS_ORDER.index(pet_nak)
        o_idx = _NAKSHATRAS_ORDER.index(owner_nak)
    except ValueError:
        return {"error": f"Unknown nakshatra: pet={pet_nak} owner={owner_nak}",
                 "score": 0.0, "max": 3.0}

    # Tara cycle from owner's perspective (i.e., pet's nakshatra position from owner)
    offset = (p_idx - o_idx) % 9
    tara = _TARA_TABLE[offset]
    score = _TARA_KUTA_POINTS[tara["idx"]]

    return {
        "score":   score,
        "max":     3.0,
        "tara":    tara["name"],
        "nature":  tara["nature"],
        "effect":  tara["effect"],
        "explanation": (
            f"Pet's nakshatra ({pet_nak}) from owner's nakshatra ({owner_nak}) "
            f"falls in {tara['name']} tara — {tara['effect'].lower()}."
        ),
    }


def _score_yoni(pet_nak: str, owner_nak: str) -> Dict[str, Any]:
    """Yoni Kuta: animal-yoni compatibility. The most pet-relevant koot."""
    p_yoni = NAKSHATRA_TO_YONI.get(pet_nak, ("Unknown", "M"))
    o_yoni = NAKSHATRA_TO_YONI.get(owner_nak, ("Unknown", "F"))

    p_animal, p_gender = p_yoni
    o_animal, o_gender = o_yoni

    # Same yoni
    if p_animal == o_animal:
        if p_gender != o_gender:
            score = 4.0  # opposite gender same yoni — max
            note = f"Same yoni ({p_animal}), complementary genders — natural harmony."
        else:
            score = 3.0  # same gender same yoni — slight friction
            note = f"Same yoni ({p_animal}), same gender — strong affinity with mild rivalry."
    # Enemy pairs
    elif ((p_animal, o_animal) in YONI_ENEMIES or
            (o_animal, p_animal) in YONI_ENEMIES):
        score = 0.0
        note = f"Yoni enmity ({p_animal} vs {o_animal}) — classical natural antagonism."
    # Friendly pairs
    elif ((p_animal, o_animal) in YONI_FRIENDLY or
            (o_animal, p_animal) in YONI_FRIENDLY):
        score = 3.0
        note = f"Yoni friendship ({p_animal} ↔ {o_animal}) — natural harmony."
    # Neutral pairs (explicit or default)
    elif ((p_animal, o_animal) in YONI_NEUTRAL_PAIRS or
            (o_animal, p_animal) in YONI_NEUTRAL_PAIRS):
        score = 2.0
        note = f"Yoni neutrality ({p_animal} / {o_animal}) — workable compatibility."
    else:
        score = 1.0
        note = f"Yoni weak alignment ({p_animal} / {o_animal})."

    return {
        "score":       score,
        "max":         4.0,
        "pet_yoni":    p_animal,
        "owner_yoni":  o_animal,
        "explanation": note,
    }


def _score_gana(pet_nak: str, owner_nak: str) -> Dict[str, Any]:
    """Gana Kuta: temperament harmony (Deva/Manushya/Rakshasa)."""
    p_gana = _NAKSHATRA_TO_GANA.get(pet_nak, "Manushya")
    o_gana = _NAKSHATRA_TO_GANA.get(owner_nak, "Manushya")
    score = float(_GANA_SCORE.get((p_gana, o_gana), 0))

    if p_gana == o_gana:
        note = f"Same gana ({p_gana}) — natural temperament alignment."
    elif (p_gana, o_gana) in [("Manushya", "Rakshasa"), ("Rakshasa", "Manushya")]:
        note = f"Manushya-Rakshasa gana mismatch — friction in daily handling."
    elif (p_gana, o_gana) in [("Deva", "Rakshasa"), ("Rakshasa", "Deva")]:
        note = f"Deva-Rakshasa gana — opposing energies but manageable."
    else:
        note = f"{p_gana}-{o_gana} gana pairing — generally harmonious."

    return {
        "score":      score,
        "max":        6.0,
        "pet_gana":   p_gana,
        "owner_gana": o_gana,
        "explanation": note,
    }


def _score_graha_maitri(pet_nak: str, owner_nak: str) -> Dict[str, Any]:
    """Graha Maitri Kuta: planetary friendship between nakshatra lords."""
    p_lord = _NAKSHATRA_TO_LORD.get(pet_nak)
    o_lord = _NAKSHATRA_TO_LORD.get(owner_nak)

    if not p_lord or not o_lord:
        return {"error": "Unknown nakshatra lord",
                 "score": 0.0, "max": 5.0}

    if p_lord == o_lord:
        score = 5.0
        note = f"Both ruled by {p_lord} — identical planetary signature."
    else:
        rel_p_to_o = _GRAHA_FRIENDS.get(p_lord, {}).get(o_lord, "n")
        rel_o_to_p = _GRAHA_FRIENDS.get(o_lord, {}).get(p_lord, "n")
        score = _GRAHA_MAITRI_SCORE.get((rel_p_to_o, rel_o_to_p), 0.0)
        descriptor = {
            "FF": "mutual friends",
            "Fn": "friend-neutral",
            "nF": "neutral-friend",
            "nn": "mutual neutrals",
            "Fe": "friend-enemy mismatch",
            "eF": "enemy-friend mismatch",
            "ne": "neutral-enemy",
            "en": "enemy-neutral",
            "ee": "mutual enemies",
        }.get(rel_p_to_o + rel_o_to_p, "mixed")
        note = (f"Pet ruled by {p_lord}, owner by {o_lord} — "
                  f"{descriptor} planetary signature.")

    return {
        "score":      score,
        "max":        5.0,
        "pet_lord":   p_lord,
        "owner_lord": o_lord,
        "explanation": note,
    }


# ════════════════════════════════════════════════════════════════════════
# PUBLIC API: handle_pet_compatibility
# ════════════════════════════════════════════════════════════════════════

def handle_pet_compatibility(pet: Dict[str, Any],
                              owner: Dict[str, Any]) -> Dict[str, Any]:
    """
    F6 Endpoint: Pet-owner compatibility via adapted nakshatra koots.

    Scores 4 koots: Tara (max 3), Yoni (max 4), Gana (max 6), Graha Maitri (max 5).
    Total max: 18.

    Bands:
      14-18 → Excellent fit
      10-13 → Good fit
      6-9   → Moderate fit
      0-5   → Challenging fit
    """
    # Resolve pet's operative chart
    try:
        pet_chart, pet_mode = _resolve_pet_chart(pet)
    except ValueError as e:
        return {"error": str(e), "citations": F6_CITATIONS["compatibility"]}
    except Exception as e:
        return {"error": f"Pet chart cast failed: {e}",
                 "citations": F6_CITATIONS["compatibility"]}

    # Owner: standard birth details required
    try:
        owner_chart = cast_chart(
            dob=owner["dob"], time=owner["time"],
            lat=owner["lat"], lon=owner["lon"],
            timezone=owner.get("timezone", "Asia/Kolkata"),
        )
    except Exception as e:
        return {"error": f"Owner chart cast failed: {e}",
                 "citations": F6_CITATIONS["compatibility"]}

    pet_moon = pet_chart["planets"]["Moon"]
    owner_moon = owner_chart["planets"]["Moon"]
    pet_nak = pet_moon["nakshatra"]
    owner_nak = owner_moon["nakshatra"]

    # Run koot scorers
    tara = _score_tara(pet_nak, owner_nak)
    yoni = _score_yoni(pet_nak, owner_nak)
    gana = _score_gana(pet_nak, owner_nak)
    graha = _score_graha_maitri(pet_nak, owner_nak)

    total = tara["score"] + yoni["score"] + gana["score"] + graha["score"]
    max_total = 18.0

    # Band
    if total >= 14.0:
        band = "Excellent fit"
        verdict = ("Exceptional harmony. This pet and owner are classically aligned "
                    "across temperament, planetary signature, and natural yoni.")
    elif total >= 10.0:
        band = "Good fit"
        verdict = ("Strong compatibility. Minor friction points exist but overall "
                    "the pet-owner bond is well-supported by classical signatures.")
    elif total >= 6.0:
        band = "Moderate fit"
        verdict = ("Workable but requires conscious accommodation. Either yoni "
                    "friction or gana mismatch needs awareness in daily care.")
    else:
        band = "Challenging fit"
        verdict = ("Significant classical friction. Bond is achievable but requires "
                    "explicit care: routines, time-of-day choices, and patience matter more.")

    return {
        "success":     True,
        "input_mode":  pet_mode,
        "pet_nakshatra":   pet_nak,
        "owner_nakshatra": owner_nak,
        "koot_scores": {
            "tara":         tara,
            "yoni":         yoni,
            "gana":         gana,
            "graha_maitri": graha,
        },
        "total_score":  round(total, 2),
        "max_score":    max_total,
        "percentage":   round((total / max_total) * 100, 1),
        "band":         band,
        "verdict":      verdict,
        "classical_sources": F6_CITATIONS["compatibility"],
    }


# ════════════════════════════════════════════════════════════════════════
# PUBLIC API: handle_pet_naming
# ════════════════════════════════════════════════════════════════════════

def handle_pet_naming(pet: Dict[str, Any]) -> Dict[str, Any]:
    """
    F6 Endpoint: Pet naming via classical akshara from birth/acquisition nakshatra-pada.

    Returns the pada-specific akshara, the full akshara_set for the nakshatra
    (4 alternatives), and example pet names in English starting with the akshara.
    """
    try:
        pet_chart, pet_mode = _resolve_pet_chart(pet)
    except ValueError as e:
        return {"error": str(e), "citations": F6_CITATIONS["naming"]}
    except Exception as e:
        return {"error": f"Pet chart cast failed: {e}",
                 "citations": F6_CITATIONS["naming"]}

    moon = pet_chart["planets"]["Moon"]
    pet_nak = moon["nakshatra"]
    pada = _pet_pada_from_nakshatra_lon(moon)

    akshara_set = _NAKSHATRA_AKSHARAS.get(pet_nak, [])
    pada_akshara = akshara_set[pada - 1] if (akshara_set and 1 <= pada <= 4) else None

    # Suggest sample pet names by akshara (gentle classical-feeling suggestions)
    # These are illustrative — we don't pretend to be a name-database
    name_suggestions = _generate_name_suggestions(pada_akshara)

    return {
        "success":         True,
        "input_mode":      pet_mode,
        "operative_nakshatra": pet_nak,
        "operative_pada":  pada,
        "recommended_akshara": pada_akshara,
        "all_aksharas_for_nakshatra": akshara_set,
        "name_suggestions": name_suggestions,
        "tradition_note": (
            "Classical Vedic naming uses the akshara of the birth nakshatra-pada. "
            "In acquisition mode, the operative nakshatra is the Moon's position "
            "at the moment of bringing the pet home — this functions as the "
            "household-relevant nakshatra (Prashna-style anchor)."
        ),
        "classical_sources": F6_CITATIONS["naming"],
    }


def _generate_name_suggestions(akshara: Optional[str]) -> List[str]:
    """
    Illustrative pet names by starting akshara.
    A small curated set — not a database. Helps customer immediately see
    what an akshara-based name would sound like.
    """
    if not akshara:
        return []
    suggestions = {
        "Chu": ["Chuchu", "Chunky"],   "Che": ["Cheeky", "Cherry"],
        "Cho": ["Chocolate", "Cholo"], "La":  ["Laila", "Lassi"],
        "Li":  ["Lily", "Lima"],       "Lu":  ["Lulu", "Lucky"],
        "Le":  ["Leo", "Leela"],       "Lo":  ["Lola", "Lotus"],
        "A":   ["Asha", "Ace"],         "Ee":  ["Eera", "Eevee"],
        "U":   ["Uma", "Udit"],          "Ay":  ["Ayan", "Ayra"],
        "O":   ["Oreo", "Omi"],          "Va":  ["Vada", "Vaani"],
        "Vee": ["Veera", "Vinny"],      "Vu":  ["Voodoo", "Vudu"],
        "Ve":  ["Vera", "Velvet"],      "Vo":  ["Voro", "Vovo"],
        "Ka":  ["Kali", "Kanu"],         "Kee": ["Keeko", "Keera"],
        "Ku":  ["Kuku", "Kunal"],        "Gha": ["Ghani"],
        "Ng":  ["Ngo"],                  "Chh": ["Chhabi"],
        "Ke":  ["Kelo", "Kesar"],        "Ko":  ["Koko", "Kopi"],
        "Ha":  ["Hari", "Halu"],         "Hee": ["Heera", "Hema"],
        "Hu":  ["Hugo", "Hutch"],        "He":  ["Hero", "Hena"],
        "Ho":  ["Honey", "Holi"],        "Da":  ["Daisy", "Damu"],
        "Dee": ["Deepak", "Deedee"],    "Du":  ["Duke", "Duggu"],
        "De":  ["Devi", "Deva"],         "Do":  ["Doodle", "Dora"],
        "Ma":  ["Maya", "Mango"],        "Mee": ["Meera", "Meekoo"],
        "Mu":  ["Mukti", "Muffin"],     "Me":  ["Melu", "Meghu"],
        "Mo":  ["Mochi", "Moti"],        "Ta":  ["Tara", "Tashi"],
        "Tee": ["Teeku", "Teena"],      "Tu":  ["Tutu", "Tuffy"],
        "Te":  ["Teja", "Telu"],         "To":  ["Toto", "Toffee"],
        "Pa":  ["Panda", "Papa"],        "Pee": ["Peelu", "Peeko"],
        "Pu":  ["Puchki", "Pumpkin"],   "Sha": ["Shanti", "Shadow"],
        "Na":  ["Nani", "Nibu"],         "Tha": ["Thora"],
        "Pe":  ["Pepper", "Peshi"],     "Po":  ["Popo", "Potato"],
        "Ra":  ["Rani", "Raja"],         "Ree": ["Reeshu", "Reema"],
        "Ru":  ["Rumi", "Ruby"],         "Re":  ["Reva", "Reshu"],
        "Ro":  ["Romeo", "Rocco"],      "Nee": ["Neelu", "Neela"],
        "Nu":  ["Nugget", "Nuru"],      "Ne":  ["Nemo", "Nero"],
        "No":  ["Nora", "Noah"],         "Ya":  ["Yashi", "Yara"],
        "Yee": ["Yeshu"],                "Yu":  ["Yuki", "Yug"],
        "Ye":  ["Yeti"],                  "Yo":  ["Yogi", "Yoyo"],
        "Bha": ["Bhalu", "Bhakti"],     "Bhi": ["Bheeshma"],
        "Bhu": ["Bhumi", "Bhura"],      "Dha": ["Dharm", "Dhanu"],
        "Pha": ["Phoolu"],               "Bhe": ["Bheera"],
        "Bho": ["Bhola", "Bhoot"],      "Ja":  ["Jaya", "Jambu"],
        "Jee": ["Jeevu"],                "Khee":["Kheel"],
        "Khu": ["Khushi"],               "Khe": ["Kheer"],
        "Kho": ["Khoja"],                "Ga":  ["Gauri", "Gappu"],
        "Gee": ["Geeta", "Geeko"],      "Gu":  ["Guggu", "Gulli"],
        "Ge":  ["Gemini", "Gele"],      "Go":  ["Gogo", "Golu"],
        "Sa":  ["Sara", "Suki"],         "See": ["Seeta", "Seena"],
        "Su":  ["Suri", "Sunny"],       "Se":  ["Sehu", "Sena"],
        "So":  ["Sonu", "Soda"],         "Jha": ["Jhalu"],
        "Yna": ["Yna"],                  "Cha": ["Chand", "Cherry"],
        "Chee":["Cheeku", "Cheena"],
    }
    return suggestions.get(akshara, [])


# ════════════════════════════════════════════════════════════════════════
# PUBLIC API: handle_pet_personality
# ════════════════════════════════════════════════════════════════════════

# Sign → element + general nature (for personality narrative)
_SIGN_TO_ELEMENT = {
    "Aries":       ("Fire", "active, leader-natured, territorial"),
    "Taurus":      ("Earth", "calm, deliberate, comfort-loving"),
    "Gemini":      ("Air", "curious, communicative, restless"),
    "Cancer":      ("Water", "emotional, family-bonded, moody"),
    "Leo":         ("Fire", "dominant, attention-loving, dignified"),
    "Virgo":       ("Earth", "particular, methodical, clean-natured"),
    "Libra":       ("Air", "social, harmony-seeking, charming"),
    "Scorpio":     ("Water", "intense, loyal, protective, secretive"),
    "Sagittarius": ("Fire", "adventurous, free-spirited, friendly"),
    "Capricorn":   ("Earth", "disciplined, patient, hierarchical"),
    "Aquarius":    ("Air", "unusual, independent, friendly"),
    "Pisces":      ("Water", "gentle, sensitive, empathetic"),
}

# Nakshatra → temperament traits (condensed classical readings)
_NAKSHATRA_PET_TRAITS = {
    "Ashwini":          "Fast, energetic, healing-natured. Loves running, recovers quickly.",
    "Bharani":          "Intense, transformation-oriented. Strong-willed, protective.",
    "Krittika":         "Sharp, alert, fiery. Good guard nature, can be assertive.",
    "Rohini":           "Beautiful, sensual, comfort-seeking. Affectionate, food-motivated.",
    "Mrigashira":       "Curious, gentle, searching. Sniffs out everything, observant.",
    "Ardra":            "Stormy, emotional, sharp. Can be moody but deeply attached.",
    "Punarvasu":        "Returning, restorative, optimistic. Good companion, forgiving nature.",
    "Pushya":           "Nurturing, gentle, devoted. The most loyal of pet nakshatras.",
    "Ashlesha":         "Clever, watchful, slightly secretive. Wise; can be possessive.",
    "Magha":            "Royal, proud, ancestrally-oriented. Carries dignity, expects respect.",
    "Purva Phalguni":   "Playful, affectionate, social. Loves attention and physical comfort.",
    "Uttara Phalguni":  "Generous, helpful, reliable. Stable temperament.",
    "Hasta":            "Skillful, dextrous, healing. Good with hands/paws; gentle nature.",
    "Chitra":           "Striking appearance, artistic, watchful. Attention-seeking but elegant.",
    "Swati":            "Independent, free-spirited, social. Diplomatic; needs balance.",
    "Vishakha":         "Determined, goal-oriented, intense. Persistent in habits.",
    "Anuradha":         "Friendly, social, devoted. Bonds deeply with the family.",
    "Jyeshtha":         "Senior-natured, protective, courageous. Dominant but caring.",
    "Mula":             "Investigative, root-seeking, fierce. Hunts toys; intense play.",
    "Purva Ashadha":    "Invigorating, powerful, water-loving. Strong-willed.",
    "Uttara Ashadha":   "Triumphant, reliable, leader-natured. Calm dominance.",
    "Shravana":         "Listening, learning, attentive. Trains easily, responsive.",
    "Dhanishta":        "Musical, rhythmic, social. Loves household activity.",
    "Shatabhisha":      "Healing, secretive, independent. Unusual; needs space.",
    "Purva Bhadrapada": "Intense, philosophical, sensitive. Bonds deeply; can be moody.",
    "Uttara Bhadrapada":"Wise, deep, watery. Calm and quietly affectionate.",
    "Revati":           "Nurturing, gentle, traveling-natured. Loves family; sensitive to mood.",
}


def handle_pet_personality(pet: Dict[str, Any]) -> Dict[str, Any]:
    """
    F6 Endpoint: Pet personality from natal/operative chart.

    Birth mode: full personality including Moon-nakshatra, Sun sign, lagna sign,
                ruling planet for the chart.
    Acquisition mode: nakshatra-only personality (acquisition Sun/lagna doesn't
                       represent the pet's permanent nature).
    """
    try:
        pet_chart, pet_mode = _resolve_pet_chart(pet)
    except ValueError as e:
        return {"error": str(e), "citations": F6_CITATIONS["personality"]}
    except Exception as e:
        return {"error": f"Pet chart cast failed: {e}",
                 "citations": F6_CITATIONS["personality"]}

    moon = pet_chart["planets"]["Moon"]
    pet_nak = moon["nakshatra"]
    pet_moon_sign = moon["sign"]

    # Nakshatra-based traits (both modes)
    nak_traits = _NAKSHATRA_PET_TRAITS.get(pet_nak, "Unique temperament.")
    gana = _NAKSHATRA_TO_GANA.get(pet_nak, "Manushya")
    nak_lord = _NAKSHATRA_TO_LORD.get(pet_nak, "Unknown")
    yoni_data = NAKSHATRA_TO_YONI.get(pet_nak, ("Unknown", "M"))
    pet_yoni_animal, pet_yoni_gender = yoni_data

    result: Dict[str, Any] = {
        "success":             True,
        "input_mode":          pet_mode,
        "operative_nakshatra": pet_nak,
        "operative_pada":      _pet_pada_from_nakshatra_lon(moon),
        "operative_moon_sign": pet_moon_sign,
        "nakshatra_traits":    nak_traits,
        "yoni_signature": {
            "animal": pet_yoni_animal,
            "gender": pet_yoni_gender,
            "note":   f"The {pet_yoni_animal} yoni is the classical animal-archetype for {pet_nak}.",
        },
        "gana":      gana,
        "gana_note": {
            "Deva":     "Divine-natured: gentle, harmonious temperament",
            "Manushya": "Human-natured: balanced, family-oriented temperament",
            "Rakshasa": "Intense-natured: powerful, sometimes wild temperament",
        }.get(gana, ""),
        "ruling_planet": nak_lord,
    }

    if pet_mode == "birth":
        # Full personality: Sun + lagna available and meaningful
        sun = pet_chart["planets"].get("Sun", {})
        sun_sign = sun.get("sign")
        lagna_sign = pet_chart.get("lagna", {}).get("sign")

        sun_elem, sun_nature = (
            _SIGN_TO_ELEMENT.get(sun_sign, ("?", "")) if sun_sign else ("?", "")
        )
        lagna_elem, lagna_nature = (
            _SIGN_TO_ELEMENT.get(lagna_sign, ("?", "")) if lagna_sign else ("?", "")
        )
        moon_elem, moon_nature = _SIGN_TO_ELEMENT.get(pet_moon_sign, ("?", ""))

        result.update({
            "sun_sign":     sun_sign,
            "sun_nature":   sun_nature,
            "lagna_sign":   lagna_sign,
            "lagna_nature": lagna_nature,
            "moon_nature":  moon_nature,
            "personality_synthesis": (
                f"This pet's core nature is {nak_traits} The Moon in {pet_moon_sign} "
                f"({moon_elem} element) gives an emotional baseline of: {moon_nature}. "
                + (f"The Sun in {sun_sign} ({sun_nature}) shapes how the pet expresses "
                    f"itself; " if sun_sign else "")
                + (f"the lagna ({lagna_sign}, {lagna_nature}) governs physical presence."
                    if lagna_sign else "")
            ),
        })
    else:
        # Acquisition mode — nakshatra-only personality
        result["personality_synthesis"] = (
            f"Operative nakshatra personality: {nak_traits} Sun-sign and lagna analysis "
            f"are not classically defensible in acquisition mode, so this profile relies on "
            f"the operative nakshatra signature and {pet_yoni_animal}-yoni temperament."
        )
        result["mode_note"] = (
            "Pet's full birth chart not provided. Personality reflects the operative "
            "nakshatra at the acquisition moment (the household-relevant signature)."
        )

    result["classical_sources"] = F6_CITATIONS["personality"]
    return result


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

F6_CITATIONS = {
    "compatibility": [
        "BPHS Ch. 7 — Ashtakoota foundations (Tara, Yoni, Gana, Graha Maitri)",
        "Hora Sara — Yoni Kuta animal hierarchy (28 yoni assignments)",
        "Saravali Ch. 33 — Animal yoni interpretations and friendship/enmity",
        "Phaladeepika Ch. 14 — Nakshatra-based relationship signatures",
        "Note: F6 adapts the classical Ashtakoota for pet-human relationships, "
        "retaining the 4 koots that meaningfully apply (Tara/Yoni/Gana/Graha Maitri) "
        "and dropping the marriage-specific 4 (Varna/Vashya/Bhakoot/Nadi).",
    ],
    "naming": [
        "Brihat Samhita Ch. 99 — Akshara-based naming from birth nakshatra-pada",
        "Phaladeepika Ch. 14 — Pada-specific naming syllables",
        "Note: Acquisition mode anchors to the operative nakshatra (Moon at acquisition), "
        "following classical Prashna (horary) tradition for moment-based astrology.",
    ],
    "personality": [
        "Phaladeepika Ch. 14 — Nakshatra personality readings",
        "Saravali Ch. 33 — Animal yoni nature and temperament",
        "BPHS Ch. 7 — Gana (Deva/Manushya/Rakshasa) classification",
        "BPHS Ch. 3 — Sign-element-temperament mappings",
        "Note: In acquisition mode, only nakshatra-level traits are presented since "
        "Sun and lagna at the acquisition moment don't describe the pet's permanent nature.",
    ],
}
