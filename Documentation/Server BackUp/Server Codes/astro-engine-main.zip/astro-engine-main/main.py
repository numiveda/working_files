"""
numiVeda Astro Engine — FastAPI Service
Runs on Kaaliyo VPS at trade.kaaliyo.com/astro/*
Replaces AstrologyAPI with self-hosted Swiss Ephemeris via dashaflow (KP via kp_pro.py - vedicastro removed 2026-05-17)

Endpoints:
  Vedic — /astro/chart, /planets, /dasha, /dasha/current, /yogas, /shadbala,
           /ashtakavarga, /transit, /panchang, /divisional/{div}, /jaimini,
           /special, /compatibility, /sadesati, /manglik, /doshas,
           /career, /muhurtha
  KP    — /astro/kp
"""

import os
import swisseph as _swe

# ── Critical: set Swiss Ephemeris data path BEFORE any flatlib import ──
_EPHE_PATH = '/usr/local/lib/python3.12/dist-packages/flatlib/resources/swefiles'
_swe.set_ephe_path(_EPHE_PATH)

from fastapi import FastAPI, HTTPException, Security, Depends
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict
from typing import Optional
from datetime import date

from dashaflow import (
    cast_chart,
    calculate_transit,
    check_muhurtha,
    calc_kuja_dosha,
    analyze_career,
)

# ── Lal Kitab + Numerology + Muhurta modules ──
from lal_kitab import analyze_lal_kitab
from numerology import full_numerology, pythagorean, chaldean, lo_shu_grid
from muhurta import choghadiya, rahu_kaal, abhijit_muhurta, hora, full_muhurta


# === BEGIN NAKSHATRA IMPORTS ===
from nakshatra import (
    analyze_full         as nakshatra_analyze_full,
    analyze_janma        as nakshatra_analyze_janma,
    analyze_all_planets  as nakshatra_analyze_all_planets,
    analyze_tara         as nakshatra_analyze_tara,
    analyze_compatibility as nakshatra_analyze_compatibility,
    get_static           as nakshatra_get_static,
)
# === BEGIN YOGAS-V2 IMPORTS ===
from yogas import (
    detect_all       as yogasv2_detect_all,
    detect_active    as yogasv2_detect_active,
    detect_positive  as yogasv2_detect_positive,
    detect_negative  as yogasv2_detect_negative,
    get_catalog      as yogasv2_get_catalog,
    get_yoga         as yogasv2_get_yoga,
)
# === BEGIN TIMELINE IMPORTS ===
from yogas_timeline import (
    timeline_annual, timeline_5year, timeline_10year, timeline_15year,
)
from timeline_dasha_walker import get_dasha_state as _tl_get_dasha_state
from datetime import datetime as _tl_datetime
# === BEGIN NUMEROLOGY V2 IMPORTS ===
from numerology_v2_engine import (
    full_reading       as numv2_full_reading,
    static_numbers     as numv2_static_numbers,
    karmic_layer       as numv2_karmic_layer,
    time_cycles        as numv2_time_cycles,
    compatibility      as numv2_compatibility,
)
# === END NUMEROLOGY V2 IMPORTS ===
# === END TIMELINE IMPORTS ===
# === END YOGAS-V2 IMPORTS ===
# === END NAKSHATRA IMPORTS ===

# ─── Config ─────────────────────────────────────────────────────────────────────
API_KEY = os.getenv("ASTRO_API_KEY", "numiveda-astro-secret-2026")

# ── Feng Shui module imports ──
from feng_shui import (
    full_personal_profile, calculate_kua, get_eight_directions,
    calculate_year_animal, calculate_day_master, element_interactions,
    calculate_lo_shu, flying_stars_for_year, get_bagua_home_map,
    feng_shui_compatibility, year_outlook,
)
from feng_shui_data import KUA_TO_TRIGRAM


# ── Astro Vastu module imports ──
from vastu import (
    full_vastu_profile,
    personal_directions_endpoint as vastu_personal_directions,
    plot_analysis as vastu_plot_analysis,
    room_placement_endpoint as vastu_room_placement,
    doshas_endpoint as vastu_doshas,
    remedies_endpoint as vastu_remedies,
    marma_points_endpoint as vastu_marma,
    auspicious_construction_endpoint as vastu_construction_muhurta,
    business_vastu_endpoint as vastu_business,
    yantra_directions as vastu_yantra_directions,
)


# ── Master Remedies module (3a) imports ──
from remedies import (
    gemstones_for_chart,
    rudrakshas_for_chart,
    mantras_for_chart,
    yantras_for_chart,
    ishta_devata_for_chart,
    donations_for_chart,
    fasting_for_chart,
    color_therapy_for_chart,
    sound_therapy_for_chart,
    aromatherapy_for_chart,
    name_numerology,
    mobile_analysis,
    vehicle_analysis,
    signature_guidance,
    lucky_dates,
    remedies_for_chart,
    remedies_by_purpose,
    full_catalog as remedies_full_catalog,
)


# ── Esoteric Remedies module (3b) imports ──
from remedies_esoteric import (
    planetary_hours_info, goetia_reference, planetary_squares,
    olympic_spirits, talismans_summary,
    atharva_suktas_by_purpose, atharva_healing_hymns,
    atharva_protection_hymns, atharva_abhichar_nullifier, atharva_peace_invocations,
    personal_mahavidya, kavachas_catalog, devi_for_purpose,
    dasha_mahavidya_full, navadurga_correspondence,
    vbt_dharana_for_chart, vbt_breath_techniques, vbt_awareness_techniques,
    vbt_all_112, vbt_devotional_practices,
    tree_of_life, sephirot_for_chart, kabbalistic_paths, divine_names_planetary,
    decan_ruler, hellenistic_time_lord, planetary_deities_cross_tradition,
)


# ── Health module (B1) imports ──
from health import (
    full_health_profile,
    body_parts_endpoint as health_body_parts,
    illness_predisposition_endpoint as health_illness,
    tridosha_endpoint as health_tridosha,
    prakriti_endpoint as health_prakriti,
    vikriti_endpoint as health_vikriti,
    chakras_endpoint as health_chakras,
    chakra_balancing_for_chart as health_chakra_balancing,
    healing_windows_endpoint as health_healing_windows,
    avoidance_windows_endpoint as health_avoidance_windows,
    diet_endpoint as health_diet,
    yoga_pranayama_endpoint as health_yoga_pranayama,
    mental_health_endpoint as health_mental,
    longevity_endpoint as health_longevity,
    health_remedies_endpoint as health_remedies,
)


# ── Career + Wealth module (B2) imports ──
from career_wealth import (
    full_career_profile,
    d10_deep_dive,
    karaka_analysis_for_chart,
    natural_career_fields_endpoint,
    career_timing_endpoint,
    professional_dasha_endpoint,
    full_wealth_profile,
    dhana_yogas_endpoint,
    income_sources_endpoint,
    wealth_risk_areas_endpoint,
    income_windows_endpoint,
    wealth_remedies_endpoint,
)


# ── Prashna module (B3) imports ──
from prashna import (
    full_prashna_profile,
    lagna_analysis_endpoint as prashna_lagna,
    moon_analysis_endpoint as prashna_moon,
    significator_endpoint as prashna_significator,
    timing_endpoint as prashna_timing,
    yes_no_endpoint as prashna_yes_no,
    kp_horary_endpoint as prashna_kp,
    aroodha_lagna_endpoint as prashna_aroodha,
    swara_endpoint as prashna_swara,
    specific_query_endpoint as prashna_specific,
)


# ── TRANSIT C0 MODULE IMPORTS ──
from transit import (
    handle_profile               as transit_handle_profile,
    handle_current_positions     as transit_handle_current_positions,
    handle_personal_houses       as transit_handle_personal_houses,
    handle_sade_sati             as transit_handle_sade_sati,
    handle_jupiter_transit       as transit_handle_jupiter_transit,
    handle_saturn_transit        as transit_handle_saturn_transit,
    handle_rahu_ketu_transit     as transit_handle_rahu_ketu_transit,
    handle_eclipses_impact       as transit_handle_eclipses_impact,
    handle_gochara_phala         as transit_handle_gochara_phala,
    handle_ashtaka_varga_transit as transit_handle_ashtaka_varga_transit,
    handle_major_alerts_12months as transit_handle_major_alerts_12months,
    handle_retrograde_periods    as transit_handle_retrograde_periods,
)
# ── END TRANSIT C0 IMPORTS ──


# ── COMPATIBILITY C1 MODULE IMPORTS ──
from compatibility import (
    handle_profile                  as compat_handle_profile,
    handle_ashtakoot                as compat_handle_ashtakoot,
    handle_manglik                  as compat_handle_manglik,
    handle_nadi_dosha               as compat_handle_nadi_dosha,
    handle_bhakoot_dosha            as compat_handle_bhakoot_dosha,
    handle_dasha_compatibility      as compat_handle_dasha_compatibility,
    handle_synastry_aspects         as compat_handle_synastry_aspects,
    handle_d9_navamsha_compat       as compat_handle_d9_navamsha_compat,
    handle_seventh_house_synthesis  as compat_handle_seventh_house_synthesis,
    handle_venus_jupiter_synthesis  as compat_handle_venus_jupiter_synthesis,
    handle_longevity_match          as compat_handle_longevity_match,
    handle_timing_for_marriage      as compat_handle_timing_for_marriage,
)

# ── F1a: Non-Marriage Relationships (2026-05-17) ──
# ── F1b: business_partner + colleague + matrix imports ──
from relationships import (
    handle_friendship          as rel_handle_friendship,
    handle_mentor              as rel_handle_mentor,
    handle_family              as rel_handle_family,
    handle_business_partner    as rel_handle_business_partner,
    handle_colleague           as rel_handle_colleague,
    handle_compatibility_matrix as rel_handle_compatibility_matrix,
    MATRIX_HARD_CEILING        as REL_MATRIX_HARD_CEILING,
)


# ── F2a: Eclipse module imports (2026-05-17) ──
from eclipse import (
    handle_natal_eclipses                  as ecl_handle_natal_eclipses,
    handle_upcoming_eclipses               as ecl_handle_upcoming_eclipses,
    handle_sade_sati_eclipse_extension     as ecl_handle_sade_sati_extension,
    NATAL_WINDOW_DEFAULT_DAYS              as ECL_NATAL_WINDOW_DEFAULT,
    NATAL_WINDOW_MAX_DAYS                  as ECL_NATAL_WINDOW_MAX,
    UPCOMING_YEARS_DEFAULT                 as ECL_UPCOMING_YEARS_DEFAULT,
    UPCOMING_YEARS_MAX                     as ECL_UPCOMING_YEARS_MAX,
)


# ── F2b: Pitra Dosha module imports (2026-05-17) ──
from pitra_dosha import (
    handle_pitra_dosha_profile          as pd_handle_profile,
    handle_pitra_dosha_intensity        as pd_handle_intensity,
    handle_pitra_dosha_remedies_timing  as pd_handle_remedies_timing,
    MAHALAYA_YEARS_DEFAULT              as PD_MAHALAYA_YEARS_DEFAULT,
    MAHALAYA_YEARS_MAX                  as PD_MAHALAYA_YEARS_MAX,
)


# ── F3: Strength module imports (2026-05-18) ──
from strength import (
    handle_vimshopaka_bala         as st_handle_vimshopaka_bala,
    handle_planetary_summary       as st_handle_planetary_summary,
    handle_strength_comprehensive  as st_handle_comprehensive,
)


# ── F9: Birthday Quick imports (2026-05-18) ──
from birthday_quick import (
    handle_birthday_quick     as bq_handle_quick,
    handle_birthday_headline  as bq_handle_headline,
)


# ── F6: Pet Astrology imports (2026-05-18) ──
from pet_astro import (
    handle_pet_compatibility   as pet_handle_compatibility,
    handle_pet_naming          as pet_handle_naming,
    handle_pet_personality     as pet_handle_personality,
)


# ── F6b: Pet Acquisition Muhurta imports (2026-05-18) ──
from pet_muhurta import (
    handle_check_acquisition_day        as pm_handle_check_day,
    handle_acquisition_window_scan      as pm_handle_window_scan,
)


# ── F4: Mundane module imports (2026-05-18) ──
from mundane import (
    handle_country_outlook       as mn_handle_country_outlook,
    handle_company_chart         as mn_handle_company_chart,
    handle_election_prediction   as mn_handle_election_prediction,
    COUNTRY_REGISTRY             as MN_COUNTRY_REGISTRY,
)


# ── F5: Pregnancy module imports (2026-05-18) ──
from pregnancy import (
    handle_conception_muhurta        as pg_handle_conception_muhurta,
    handle_santana_yogas             as pg_handle_santana_yogas,
    handle_prenatal_remedies         as pg_handle_prenatal_remedies,
    handle_bala_arishta              as pg_handle_bala_arishta,
    handle_newborn_naming_window     as pg_handle_newborn_naming_window,
    handle_garbha_shanti_remedies    as pg_handle_garbha_shanti_remedies,
    PCPNDT_NOTE                      as PG_PCPNDT_NOTE,
)


# ── F7: Family Karma module imports (2026-05-18) ──
from family_karma import (
    handle_family_patterns         as fk_handle_family_patterns,
    handle_ancestral_strengths     as fk_handle_ancestral_strengths,
    handle_lineage_yogas           as fk_handle_lineage_yogas,
    handle_karaka_inheritance      as fk_handle_karaka_inheritance,
    handle_dasha_lineage           as fk_handle_dasha_lineage,
)

# ── END COMPATIBILITY C1 IMPORTS ──


# ── VARSHAPHALA C2 MODULE IMPORTS ──
from varshaphala import (
    handle_profile               as varsha_handle_profile,
    handle_cast_chart            as varsha_handle_cast_chart,
    handle_muntha                as varsha_handle_muntha,
    handle_year_lord             as varsha_handle_year_lord,
    handle_tajik_aspects         as varsha_handle_tajik_aspects,
    handle_sahams                as varsha_handle_sahams,
    handle_monthly_predictions   as varsha_handle_monthly_predictions,
    handle_dasha_for_year        as varsha_handle_dasha_for_year,
    handle_event_timing          as varsha_handle_event_timing,
    handle_year_remedies         as varsha_handle_year_remedies,
)
# ── END VARSHAPHALA C2 IMPORTS ──


# ── MUHURTA PRO C3 MODULE IMPORTS ──
from muhurta_pro import (
    handle_profile             as mhpro_handle_profile,
    handle_check_moment        as mhpro_handle_check_moment,
    handle_find_window         as mhpro_handle_find_window,
    handle_marriage_muhurta    as mhpro_handle_marriage_muhurta,
    handle_business_muhurta    as mhpro_handle_business_muhurta,
    handle_travel_muhurta      as mhpro_handle_travel_muhurta,
    handle_property_muhurta    as mhpro_handle_property_muhurta,
    handle_medical_muhurta     as mhpro_handle_medical_muhurta,
)
# ── END MUHURTA PRO C3 IMPORTS ──


# ── PANCHANG C4 MODULE IMPORTS ──
from panchang import (
    handle_full       as panchang_handle_full,
    handle_tithi      as panchang_handle_tithi,
    handle_nakshatra  as panchang_handle_nakshatra,
    handle_yoga       as panchang_handle_yoga,
    handle_karana     as panchang_handle_karana,
    handle_rahu_kalam as panchang_handle_rahu_kalam,
)
# ── END PANCHANG C4 IMPORTS ──


# ── CHILDREN/EDUCATION C5 MODULE IMPORTS ──
from children_education import (
    handle_children_profile     as c5_handle_children_profile,
    handle_5th_house_analysis   as c5_handle_5th_house,
    handle_conception_timing    as c5_handle_conception_timing,
    handle_d7_saptamsha         as c5_handle_d7_saptamsha,
    handle_putra_dosha          as c5_handle_putra_dosha,
    handle_education_profile    as c5_handle_education_profile,
    handle_4th_5th_synthesis    as c5_handle_4th_5th_synthesis,
    handle_foreign_study_yoga   as c5_handle_foreign_study_yoga,
)
# ── END CHILDREN/EDUCATION C5 IMPORTS ──


# ── KARMIC D1 MODULE IMPORTS ──
from karmic import (
    handle_profile               as karmic_handle_profile,
    handle_karakamsha            as karmic_handle_karakamsha,
    handle_atmakaraka_journey    as karmic_handle_atmakaraka_journey,
    handle_ketu_past_life        as karmic_handle_ketu_past_life,
    handle_rahu_forward_karma    as karmic_handle_rahu_forward_karma,
    handle_twelfth_house_moksha  as karmic_handle_twelfth_house_moksha,
    handle_kaal_sarpa            as karmic_handle_kaal_sarpa,
    handle_upapada_karma         as karmic_handle_upapada_karma,
    handle_arudha_padas          as karmic_handle_arudha_padas,
)
# ── END KARMIC D1 IMPORTS ──


# ── TAROT D2 MODULE IMPORTS ──
from tarot import (
    handle_profile           as tarot_handle_profile,
    handle_daily_card        as tarot_handle_daily_card,
    handle_three_card        as tarot_handle_three_card,
    handle_celtic_cross      as tarot_handle_celtic_cross,
    handle_year_ahead        as tarot_handle_year_ahead,
    handle_decision          as tarot_handle_decision,
    handle_card_meaning      as tarot_handle_card_meaning,
    handle_suit_overview     as tarot_handle_suit_overview,
    handle_shuffle           as tarot_handle_shuffle,
    handle_question_focused  as tarot_handle_question_focused,
)
# ── END TAROT D2 IMPORTS ──


# ── NADI D5 MODULE IMPORTS ──
from nadi import (
    handle_profile                  as nadi_handle_profile,
    handle_moon_pada_analysis       as nadi_handle_moon_pada_analysis,
    handle_ak_nakshatra_signature   as nadi_handle_ak_nakshatra_signature,
    handle_pada_attributes          as nadi_handle_pada_attributes,
    handle_bhrigu_aspects           as nadi_handle_bhrigu_aspects,
    handle_nakshatra_yogas          as nadi_handle_nakshatra_yogas,
)
# ── END NADI D5 IMPORTS ──


# ── ICHING D3 MODULE IMPORTS ──
from iching import (
    handle_profile                 as iching_handle_profile,
    handle_cast_question           as iching_handle_cast_question,
    handle_daily_hexagram          as iching_handle_daily_hexagram,
    handle_hexagram_lookup         as iching_handle_hexagram_lookup,
    handle_trigram_lookup          as iching_handle_trigram_lookup,
    handle_changing_lines_analysis as iching_handle_changing_lines_analysis,
    handle_year_ahead_hexagrams    as iching_handle_year_ahead_hexagrams,
    handle_decision_hexagram       as iching_handle_decision_hexagram,
    handle_shuffle_cast            as iching_handle_shuffle_cast,
    handle_question_focused        as iching_handle_question_focused,
)
# ── END ICHING D3 IMPORTS ──


# ── KP PRO D4 MODULE IMPORTS ──
from kp_pro import (
    handle_profile                as kp_handle_profile,
    handle_sub_lord_for_longitude as kp_handle_sub_lord_for_longitude,
    handle_planet_sub_lords       as kp_handle_planet_sub_lords,
    handle_lagna_sub_lord         as kp_handle_lagna_sub_lord,
    handle_cuspal_sub_lords       as kp_handle_cuspal_sub_lords,
    handle_ruling_planets         as kp_handle_ruling_planets,
    handle_significators          as kp_handle_significators,
    handle_house_significators    as kp_handle_house_significators,
    handle_moment_lookup          as kp_handle_moment_lookup,
    handle_query_horoscope        as kp_handle_query_horoscope,
)
# ── END KP PRO D4 IMPORTS ──


# ── ASTROCARTOGRAPHY D6 MODULE IMPORTS ──
from astrocartography import (
    handle_profile             as acg_handle_profile,
    handle_planetary_lines     as acg_handle_planetary_lines,
    handle_relocate_chart      as acg_handle_relocate_chart,
    handle_local_space         as acg_handle_local_space,
    handle_location_compare    as acg_handle_location_compare,
    handle_optimal_locations   as acg_handle_optimal_locations,
)
# ── END ASTROCARTOGRAPHY D6 IMPORTS ──


# ── TRANSIT ASPECTS U3 MODULE IMPORTS ──
from transit_aspects import (
    handle_applying_aspects_to_natal as txa_handle_applying,
    handle_upcoming_exact_aspects    as txa_handle_upcoming,
)
# ── END TRANSIT ASPECTS U3 IMPORTS ──


# ── RAMAL E1 MODULE IMPORTS ──
from ramal import (
    handle_profile           as ramal_handle_profile,
    handle_cast_chart        as ramal_handle_cast_chart,
    handle_cast_from_throws  as ramal_handle_cast_from_throws,
    handle_figure_from_throw as ramal_handle_figure_from_throw,
    handle_figure_lookup     as ramal_handle_figure_lookup,
    handle_figures_catalog   as ramal_handle_figures_catalog,
    handle_house_domains     as ramal_handle_house_domains,
    handle_hope_formula      as ramal_handle_hope_formula,
    handle_check_theft       as ramal_handle_check_theft,
    handle_check_captivity   as ramal_handle_check_captivity,
    handle_dot_count         as ramal_handle_dot_count,
    handle_question_reading  as ramal_handle_question_reading,
)
# ── END RAMAL E1 IMPORTS ──


# ── MOKSHAPATAM E2 MODULE IMPORTS ──
from mokshapatam import (
    handle_profile             as mp_handle_profile,
    handle_board_catalog       as mp_handle_board_catalog,
    handle_chakra_catalog      as mp_handle_chakra_catalog,
    handle_past_life_weight    as mp_handle_past_life_weight,
    handle_chakra_analysis     as mp_handle_chakra_analysis,
    handle_cumulative_pattern  as mp_handle_cumulative_pattern,
    handle_journey_narrative   as mp_handle_journey_narrative,
    handle_chart_data          as mp_handle_chart_data,
    handle_validate_journey    as mp_handle_validate_journey,
)
# ── END MOKSHAPATAM E2 IMPORTS ──

app = FastAPI(title="numiVeda Astro Engine", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


def verify_key(key: str = Security(api_key_header)):
    if key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return key


# ─── Request Models ──────────────────────────────────────────────────────────────
class BirthInput(BaseModel):
    dob: str           # YYYY-MM-DD
    time: str          # HH:MM (24h)
    lat: float
    lon: float
    timezone: str = "Asia/Kolkata"




class NumerologyInput(BaseModel):
    name: str
    date_of_birth: str
    gender: Optional[str] = "male"


class MuhurtaInput(BaseModel):
    date: str
    latitude: float
    longitude: float
    timezone: Optional[str] = "Asia/Kolkata"


class TransitInput(BaseModel):
    dob: str
    time: str
    lat: float
    lon: float
    timezone: str = "Asia/Kolkata"
    transit_date: Optional[str] = None  # YYYY-MM-DD, defaults to today




# ── F1a: RelationshipInput (2026-05-17) ──
class RelationshipInput(BaseModel):
    person1: BirthInput
    person2: BirthInput
    # Optional context — improves synthesis but never required.
    # For mentor: role1/role2 ∈ {"mentor", "mentee"}
    # For family: any free-text label (e.g. "mother", "elder_sibling")
    role1: Optional[str] = None
    role2: Optional[str] = None
    # For family endpoint only: "parent-child" | "sibling" | "extended"
    subtype: Optional[str] = None

# ── F2a: EclipseInput (2026-05-17) ──
class EclipseInput(BaseModel):
    """Input for /astro/eclipse/* endpoints (and Sade-Sati eclipse extension)."""
    birth: BirthInput
    # natal_eclipses: window (days) before+after birth; default 30, max 180
    window_days: Optional[int] = None
    # upcoming_eclipses
    query_date: Optional[str] = None    # YYYY-MM-DD
    years_ahead: Optional[int] = None   # default 5, max 100

# ── F2b: PitraDoshaInput (2026-05-17) ──
class PitraDoshaInput(BaseModel):
    """Input for /astro/pitra_dosha/* endpoints."""
    birth: BirthInput
    # remedies_timing only:
    query_date: Optional[str] = None    # YYYY-MM-DD; defaults to today
    years_ahead: Optional[int] = None   # default 5, max 50

# ── F3: StrengthInput (2026-05-18) ──
class StrengthInput(BaseModel):
    """Input for /astro/strength/* endpoints."""
    birth: BirthInput


# ── F9: BirthdayInput (2026-05-18) ──
class BirthdayInput(BaseModel):
    """Input for /astro/birthday/* endpoints."""
    birth: BirthInput
    query_date: Optional[str] = None    # YYYY-MM-DD; defaults to today


# ── F6: PetInput + PetCompatInput (2026-05-18) ──
class PetInput(BaseModel):
    """
    Pet input — supports either full birth details or acquisition details.

    Mode 1 (birth): dob, time, lat, lon, timezone
    Mode 2 (acquisition): acquisition_date, acquisition_time, acquisition_lat,
                          acquisition_lon, acquisition_timezone
    """
    # Mode 1 — full birth chart
    dob:      Optional[str] = None
    time:     Optional[str] = None
    lat:      Optional[float] = None
    lon:      Optional[float] = None
    timezone: Optional[str] = "Asia/Kolkata"
    # Mode 2 — acquisition (when pet was brought home)
    acquisition_date:     Optional[str] = None
    acquisition_time:     Optional[str] = None
    acquisition_lat:      Optional[float] = None
    acquisition_lon:      Optional[float] = None
    acquisition_timezone: Optional[str] = "Asia/Kolkata"


class PetCompatInput(BaseModel):
    """Input for /astro/pet/compatibility — pet + owner."""
    pet:   PetInput
    owner: BirthInput


# ── F6b: Acquisition input classes (2026-05-18) ──
class AcquisitionLocationInput(BaseModel):
    """Location where pet will be acquired."""
    lat:      float
    lon:      float
    timezone: Optional[str] = "Asia/Kolkata"


class AcquisitionDayInput(BaseModel):
    """Input for /astro/pet/check_acquisition_day — single date check."""
    owner:                BirthInput
    acquisition_date:     str   # YYYY-MM-DD
    acquisition_location: AcquisitionLocationInput


class AcquisitionWindowInput(BaseModel):
    """Input for /astro/pet/auspicious_acquisition_window — date range scan."""
    owner:                BirthInput
    start_date:           Optional[str] = None   # YYYY-MM-DD; defaults to today
    end_date:             Optional[str] = None   # YYYY-MM-DD; defaults to start+14 days
    acquisition_location: AcquisitionLocationInput


# ── F4: Mundane Astrology inputs (2026-05-18) ──
class CountryOutlookInput(BaseModel):
    """Input for /astro/mundane/country_outlook.

    Either country_code (ISO 3166-1 alpha-2) or chart_override required.
    If both provided, chart_override wins.
    """
    country_code:    Optional[str] = None
    chart_override:  Optional[BirthInput] = None
    analysis_date:   Optional[str] = None   # YYYY-MM-DD; informational


class CompanyChartInput(BaseModel):
    """Input for /astro/mundane/company_chart.

    incorporation: BirthInput-shaped chart of the company's incorporation.
    business_sector: optional, e.g. 'technology', 'finance', 'retail'.
    """
    incorporation:    BirthInput
    business_sector:  Optional[str] = None


class ElectionEventInput(BaseModel):
    """Input for /astro/mundane/election_prediction.

    event: BirthInput-shaped chart of the civic event moment (e.g. poll opening).
    country_code: optional ISO 3166-1 alpha-2 for national context overlay.

    NOTE: This endpoint does NOT predict winners. Inputs containing party
    or candidate names are ignored.
    """
    event:         BirthInput
    country_code:  Optional[str] = None


# ── F5-U1: StrictBirthInput (2026-05-18) ──
#
# F5 endpoints use this strict variant of BirthInput which REJECTS any
# unknown field (Pydantic v2 default silently drops, leaving no audit
# trail; strict mode raises ValidationError → HTTP 422 with field name
# in the response, satisfying PCPNDT auditability).
#
# DO NOT use this for pre-F5 endpoints — would break legitimate clients.
#
class StrictBirthInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    dob: str           # YYYY-MM-DD
    time: str          # HH:MM (24h)
    lat: float
    lon: float
    timezone: str = "Asia/Kolkata"


# ── F5: Pregnancy Astrology inputs (2026-05-18) ──
#
# PCPNDT compliance note: NONE of these schemas accept any field related to
# foetal gender determination. This is deliberate engineering policy per the
# Pre-Conception and Pre-Natal Diagnostic Techniques Act, 1994 (India).
# Forbidden field names (gender, sex, linga, etc.) will trigger 400/422.
#
class PregnancyLocationInput(BaseModel):
    """Geo + timezone for muhurta scoring."""
    model_config = ConfigDict(extra="forbid")
    lat:      float
    lon:      float
    timezone: str = "Asia/Kolkata"


class ConceptionMuhurtaInput(BaseModel):
    """Input for /astro/pregnancy/conception_muhurta — Garbhadhana scan."""
    model_config = ConfigDict(extra="forbid")
    female_chart:  StrictBirthInput
    male_chart:    Optional[StrictBirthInput] = None
    location:      PregnancyLocationInput
    start_date:    Optional[str] = None   # YYYY-MM-DD; defaults to today
    end_date:      Optional[str] = None   # YYYY-MM-DD; defaults to start+14d
    max_days:      Optional[int] = 30     # cap; default 30


class SantanaYogasInput(BaseModel):
    """Input for /astro/pregnancy/santana_yogas — couple's combined analysis."""
    model_config = ConfigDict(extra="forbid")
    person1: StrictBirthInput
    person2: StrictBirthInput


class PrenatalRemediesInput(BaseModel):
    """Input for /astro/pregnancy/prenatal_remedies — month-by-month Garbha Sanskara."""
    model_config = ConfigDict(extra="forbid")
    mother_chart:       StrictBirthInput
    gestational_month:  int            # 1-9
    father_chart:       Optional[StrictBirthInput] = None


class BalaArishtaInput(BaseModel):
    """Input for /astro/pregnancy/bala_arishta — classical Bala-Arishta yoga screen.

    SENSITIVE: returns classical karmic patterns + shanti remedies, NOT a
    medical or psychological diagnosis.
    """
    model_config = ConfigDict(extra="forbid")
    child_chart: StrictBirthInput


class NewbornNamingInput(BaseModel):
    """Input for /astro/pregnancy/newborn_naming_window — Namakarana muhurta + aksharas."""
    model_config = ConfigDict(extra="forbid")
    child_chart:     StrictBirthInput
    naming_location: PregnancyLocationInput


class GarbhaShantiInput(BaseModel):
    """Input for /astro/pregnancy/garbha_shanti_remedies — classical spiritual practices.

    Classical practices ONLY. Always supplementary to medical care.
    """
    model_config = ConfigDict(extra="forbid")
    mother_chart:       StrictBirthInput
    gestational_month:  Optional[int] = None   # 1-9
    father_chart:       Optional[StrictBirthInput] = None


# ── F7: Family Karma inputs (2026-05-18) ──
# All F7 inputs use StrictBirthInput (from F5-U1) to reject unknown
# fields at the HTTP layer. self_birth is required; ancestor charts are
# optional and reduce synthesis depth gracefully when absent.
#
class FamilyPatternsInput(BaseModel):
    """Input for /astro/karma/family_patterns — multi-chart pattern detection."""
    model_config = ConfigDict(extra="forbid")
    self_birth:                       StrictBirthInput
    mother_birth:                     Optional[StrictBirthInput] = None
    father_birth:                     Optional[StrictBirthInput] = None
    paternal_grandfather_birth:       Optional[StrictBirthInput] = None
    maternal_grandfather_birth:       Optional[StrictBirthInput] = None


class AncestralStrengthsInput(BaseModel):
    """Input for /astro/karma/ancestral_strengths — 4th/9th/12th deep dive + overlay."""
    model_config = ConfigDict(extra="forbid")
    self_birth:    StrictBirthInput
    mother_birth:  Optional[StrictBirthInput] = None
    father_birth:  Optional[StrictBirthInput] = None


class LineageYogasInput(BaseModel):
    """Input for /astro/karma/lineage_yogas — classical multi-generation yoga catalog."""
    model_config = ConfigDict(extra="forbid")
    self_birth:    StrictBirthInput
    mother_birth:  Optional[StrictBirthInput] = None
    father_birth:  Optional[StrictBirthInput] = None


class KarakaInheritanceInput(BaseModel):
    """Input for /astro/karma/karaka_inheritance — Jaimini karaka cross-chart synthesis."""
    model_config = ConfigDict(extra="forbid")
    self_birth:                       StrictBirthInput
    mother_birth:                     Optional[StrictBirthInput] = None
    father_birth:                     Optional[StrictBirthInput] = None
    paternal_grandfather_birth:       Optional[StrictBirthInput] = None
    maternal_grandfather_birth:       Optional[StrictBirthInput] = None


class DashaLineageInput(BaseModel):
    """Input for /astro/karma/dasha_lineage — cross-chart dasha overlap timing."""
    model_config = ConfigDict(extra="forbid")
    self_birth:        StrictBirthInput
    mother_birth:      Optional[StrictBirthInput] = None
    father_birth:      Optional[StrictBirthInput] = None
    lookahead_years:   Optional[int] = 20



class CompatibilityInput(BaseModel):
    person1: BirthInput
    person2: BirthInput


class MuhurthaInput(BaseModel):
    activity: str       # marriage, business, travel, education, medical, etc.
    date: str           # YYYY-MM-DD
    time: str           # HH:MM
    lat: float
    lon: float
    timezone: str = "Asia/Kolkata"


# ─── Helpers ─────────────────────────────────────────────────────────────────────
def get_chart(b: BirthInput) -> dict:
    try:
        return cast_chart(
            dob=b.dob, time=b.time,
            lat=b.lat, lon=b.lon,
            timezone=b.timezone,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# === BEGIN NAKSHATRA MODELS ===
class NakshatraCompatibilityInput(BaseModel):
    nak1: str
    nak2: str
# === END NAKSHATRA MODELS ===



# === BEGIN NUMEROLOGY V2 MODELS ===
class NumerologyV2Input(BaseModel):
    name: str
    date_of_birth: str       # YYYY-MM-DD
    gender: str = "male"
    target_year: Optional[int] = None
    target_month: Optional[int] = None
    target_date: Optional[str] = None

class NumerologyV2CompatInput(BaseModel):
    name_a: str
    dob_a: str
    name_b: str
    dob_b: str
# === END NUMEROLOGY V2 MODELS ===





# ─── Health ───────────────────────────────────────────────────────────────────────
@app.get("/astro/health")
def health():
    return {"status": "ok", "service": "numiVeda Astro Engine v2.0", "systems": ["Vedic", "KP"]}


# ═══════════════════════════════════════════════════════════════════════════════
# VEDIC ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@app.post("/astro/chart", dependencies=[Depends(verify_key)])
def natal_chart(b: BirthInput):
    """Full natal chart — everything in one call."""
    return {"success": True, "data": get_chart(b)}


@app.post("/astro/planets", dependencies=[Depends(verify_key)])
def planets(b: BirthInput):
    chart = get_chart(b)
    return {"success": True, "lagna": chart["lagna"], "planets": chart["planets"]}


@app.post("/astro/dasha", dependencies=[Depends(verify_key)])
def dasha(b: BirthInput):
    return {"success": True, "data": get_chart(b)["dashas"]}


@app.post("/astro/dasha/current", dependencies=[Depends(verify_key)])
def dasha_current(b: BirthInput):
    d = get_chart(b)["dashas"]
    return {
        "success": True,
        "maha_dasha":  d["maha"],
        "antar_dasha": d["antar"],
        "pratyantar":  d["pratyantar"],
        "sukshma":     d["sukshma"],
        "prana":       d["prana"],
    }


@app.post("/astro/yogas", dependencies=[Depends(verify_key)])
def yogas(b: BirthInput):
    return {"success": True, "data": get_chart(b)["yogas"]}


@app.post("/astro/shadbala", dependencies=[Depends(verify_key)])
def shadbala(b: BirthInput):
    return {"success": True, "data": get_chart(b)["shadbala"]}


@app.post("/astro/ashtakavarga", dependencies=[Depends(verify_key)])
def ashtakavarga(b: BirthInput):
    return {"success": True, "data": get_chart(b)["ashtakavarga"]}


@app.post("/astro/transit", dependencies=[Depends(verify_key)])
def transit(t: TransitInput):
    natal = cast_chart(dob=t.dob, time=t.time, lat=t.lat, lon=t.lon, timezone=t.timezone)
    result = calculate_transit(
        transit_date_str=t.transit_date or str(date.today()),
        natal_chart=natal,
        timezone_str=t.timezone,
    )
    return {"success": True, "data": result}


@app.post("/astro/panchang", dependencies=[Depends(verify_key)])
def panchang(b: BirthInput):
    return {"success": True, "data": get_chart(b)["panchang"]}


@app.post("/astro/divisional/{div}", dependencies=[Depends(verify_key)])
def divisional(div: str, b: BirthInput):
    """
    Returns planet signs AND correct house numbers for any divisional chart.
    House is calculated relative to the divisional lagna (1-based).
    Fixes the +1 house offset bug.
    """
    valid = {"D1","D2","D3","D4","D7","D9","D10","D12","D16","D20","D24","D27","D30","D40","D45","D60"}
    if div.upper() not in valid:
        raise HTTPException(status_code=400, detail=f"Invalid: {div}. Valid: {', '.join(sorted(valid))}")

    SIGNS = ["Aries","Taurus","Gemini","Cancer","Leo","Virgo",
             "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"]

    # D1 is the rasi chart — use base "sign" field, not "d1_sign"


    is_rasi = div.upper() == "D1"


    key = "sign" if is_rasi else f"{div.lower()}_sign"


    chart = get_chart(b)


    lagna_sign = chart["lagna"].get(key)


    if not lagna_sign or lagna_sign not in SIGNS:


        raise HTTPException(status_code=400,


            detail=f"Divisional {div} unavailable (lagna {key}={lagna_sign})")


    lagna_idx = SIGNS.index(lagna_sign)

    def sign_to_house(sign):
        if not sign or sign not in SIGNS:
            return None
        return ((SIGNS.index(sign) - lagna_idx) % 12) + 1

    planets_out = {}
    for planet, data in chart["planets"].items():
        sign = data.get(key)
        planets_out[planet] = {"sign": sign, "house": sign_to_house(sign)}

    return {
        "success": True,
        "chart":   div.upper(),
        "lagna":   {"sign": lagna_sign, "house": 1},
        "planets": planets_out,
    }


@app.post("/astro/jaimini", dependencies=[Depends(verify_key)])
def jaimini(b: BirthInput):
    return {"success": True, "data": get_chart(b)["jaimini_karakas"]}


@app.post("/astro/special", dependencies=[Depends(verify_key)])
def special(b: BirthInput):
    chart = get_chart(b)
    return {
        "success": True,
        "kaal_sarpa":   chart["kaal_sarpa"],
        "gandanta":     chart["gandanta"],
        "graha_yuddha": chart["graha_yuddha"],
    }


@app.post("/astro/compatibility", dependencies=[Depends(verify_key)])
def compatibility(c: CompatibilityInput):
    """
    Marriage compatibility — master 12-component synthesis.

    # ── U9: /astro/compatibility modernized (2026-05-17) ──
    Previously called legacy calculate_ashtakoot() with wrong kwargs.
    Now delegates to compat_handle_profile() which returns the full
    Ashtakoot + Manglik + Nadi + Bhakoot + D9 + 7H + Karakas + Longevity
    + Dasha + Synastry + Marriage Muhurta synthesis.
    """
    try:
        p1 = {"dob": c.person1.dob, "time": c.person1.time,
              "lat": c.person1.lat, "lon": c.person1.lon,
              "timezone": c.person1.timezone}
        p2 = {"dob": c.person2.dob, "time": c.person2.time,
              "lat": c.person2.lat, "lon": c.person2.lon,
              "timezone": c.person2.timezone}
        result = compat_handle_profile(p1, p2, relationship_type="marriage")
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/sadesati", dependencies=[Depends(verify_key)])
def sadesati(b: BirthInput):
    natal = get_chart(b)
    transit_data = calculate_transit(
        transit_date_str=str(date.today()),
        natal_chart=natal,
        timezone_str=b.timezone,
    )
    ss = transit_data["sade_sati"]
    active = ss.get("active", False)
    moon_sign = natal["planets"]["Moon"]["sign"]
    saturn_sign = ss.get("saturn_transit_sign", "")
    return {
        "success": True,
        "as_of": str(date.today()),
        "natal_moon_sign": moon_sign,
        "saturn_current_sign": saturn_sign,
        "is_active": active,
        "phase": ss.get("phase"),
        "summary": (
            f"Sade Sati ACTIVE (Phase: {ss.get('phase')}). Saturn in {saturn_sign}, Moon sign {moon_sign}."
            if active else
            f"Sade Sati not active. Saturn in {saturn_sign}, Moon sign {moon_sign}."
        ),
    }


@app.post("/astro/manglik", dependencies=[Depends(verify_key)])
def manglik(b: BirthInput):
    natal = get_chart(b)
    result = calc_kuja_dosha(natal)
    score = result["total_score"]
    if not result["is_manglik"]:
        status = "NOT_MANGLIK"
        interpretation = "No significant Mangal Dosha detected."
    elif score >= 100:
        status = "HIGHLY_EFFECTIVE"
        interpretation = "Strong Mangal Dosha — needs careful compatibility matching."
    elif score >= 60:
        status = "EFFECTIVE"
        interpretation = "Moderate Mangal Dosha present."
    else:
        status = "LESS_EFFECTIVE"
        interpretation = "Mild Mangal Dosha — likely cancelled or weak."
    return {
        "success": True,
        "is_manglik": result["is_manglik"],
        "status": status,
        "total_score": score,
        "breakdown": result["breakdown"],
        "interpretation": interpretation,
    }


@app.post("/astro/doshas", dependencies=[Depends(verify_key)])
def doshas(b: BirthInput):
    """Single call — Sade Sati + Manglik + Kaal Sarpa."""
    natal = get_chart(b)
    transit_data = calculate_transit(
        transit_date_str=str(date.today()),
        natal_chart=natal,
        timezone_str=b.timezone,
    )
    ss = transit_data["sade_sati"]
    mk = calc_kuja_dosha(natal)
    score = mk["total_score"]
    ks = natal.get("kaal_sarpa")

    if not mk["is_manglik"]:         manglik_status = "NOT_MANGLIK"
    elif score >= 100:                manglik_status = "HIGHLY_EFFECTIVE"
    elif score >= 60:                 manglik_status = "EFFECTIVE"
    else:                             manglik_status = "LESS_EFFECTIVE"

    return {
        "success": True,
        "sade_sati": {
            "is_active":           ss.get("active", False),
            "phase":               ss.get("phase"),
            "natal_moon_sign":     natal["planets"]["Moon"]["sign"],
            "saturn_current_sign": ss.get("saturn_transit_sign"),
        },
        "manglik": {
            "is_manglik":  mk["is_manglik"],
            "status":      manglik_status,
            "total_score": score,
            "breakdown":   mk["breakdown"],
        },
        "kaal_sarpa": {
            "is_present":  ks is not None,
            "type":        ks.get("type") if ks else None,
            "description": ks.get("description") if ks else "No Kaal Sarpa Dosha detected.",
        },
    }


@app.post("/astro/career", dependencies=[Depends(verify_key)])
def career(b: BirthInput):
    """D10-based career analysis — 10th house, career themes, strong planets."""
    try:
        result = analyze_career(
            dob=b.dob, time=b.time,
            lat=b.lat, lon=b.lon,
            timezone=b.timezone,
        )
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/muhurtha", dependencies=[Depends(verify_key)])
def muhurtha(m: MuhurthaInput):
    """Auspicious timing check for an activity on a given date/time."""
    try:
        result = check_muhurtha(
            activity=m.activity,
            date=m.date,
            time=m.time,
            lat=m.lat,
            lon=m.lon,
            timezone=m.timezone,
        )
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ═══════════════════════════════════════════════════════════════════════════════
# KP ASTROLOGY ENDPOINT
# ═══════════════════════════════════════════════════════════════════════════════

# ── KP CONSOLIDATION (Round 1) ──
# Was: vedicastro-backed KP (had tropical-zodiac bug pre-hotfix).
# Now: thin wrapper around kp_handle_profile() — single KP code path.
# Hotfix history: ayanamsha="KP" -> "Lahiri" applied 2026-05-17.
# Consolidation: vedicastro dependency removed 2026-05-17.
@app.post("/astro/kp", dependencies=[Depends(verify_key)])
def kp_chart(b: BirthInput):
    """
    KP (Krishnamurti Paddhati) full chart synthesis.

    Internally calls kp_handle_profile() from kp_pro.py — same engine that
    powers /astro/kp/profile. Returns the comprehensive KP analysis:
    lagna sub-lord, planet sub-lords, cuspal sub-lords (Placidus), birth
    ruling planets, significators (4-level hierarchy), all keyed for
    downstream LLM consumption.

    This endpoint is preserved for backward compatibility with myJyotish
    chat. For new code, /astro/kp/profile is the canonical path.
    """
    out = kp_handle_profile({
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    })
    out["_deprecation_note"] = (
        "This endpoint mirrors /astro/kp/profile. "
        "For new integrations, prefer /astro/kp/profile."
    )
    return out
# ── END KP CONSOLIDATION ──


@app.post("/astro/lalkitab", dependencies=[Depends(verify_key)])
def lalkitab(b: BirthInput):
    """Lal Kitab analysis: houses, planets, rin, remedies."""
    try:
        natal = get_chart(b)
        return {"success": True, **analyze_lal_kitab(natal)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lal Kitab analysis failed: {e}")


# ─── 22. Numerology ────────────────────────────────────────────────────────
@app.post("/astro/numerology", dependencies=[Depends(verify_key)])
def numerology_full(b: NumerologyInput):
    """Full numerology: Pythagorean + Chaldean + Lo Shu + Kua."""
    try:
        return {"success": True, **full_numerology(b.name, b.date_of_birth, b.gender)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Numerology failed: {e}")


@app.post("/astro/numerology/pythagorean", dependencies=[Depends(verify_key)])
def numerology_pythagorean(b: NumerologyInput):
    try:
        return {"success": True, **pythagorean(b.name, b.date_of_birth)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Pythagorean failed: {e}")


@app.post("/astro/numerology/chaldean", dependencies=[Depends(verify_key)])
def numerology_chaldean(b: NumerologyInput):
    try:
        return {"success": True, **chaldean(b.name, b.date_of_birth)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Chaldean failed: {e}")


@app.post("/astro/numerology/loshu", dependencies=[Depends(verify_key)])
def numerology_loshu(b: NumerologyInput):
    try:
        return {"success": True, **lo_shu_grid(b.date_of_birth)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lo Shu failed: {e}")


# ─── 23. Muhurta ───────────────────────────────────────────────────────────
@app.post("/astro/muhurta", dependencies=[Depends(verify_key)])
def muhurta_full(b: MuhurtaInput):
    """Full muhurta: Choghadiya + Rahu Kaal + Abhijit."""
    try:
        return {"success": True, **full_muhurta(b.date, b.latitude, b.longitude, b.timezone)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Muhurta failed: {e}")


@app.post("/astro/muhurta/choghadiya", dependencies=[Depends(verify_key)])
def muhurta_choghadiya(b: MuhurtaInput):
    try:
        return {"success": True, **choghadiya(b.date, b.latitude, b.longitude, b.timezone)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Choghadiya failed: {e}")


@app.post("/astro/muhurta/rahukaal", dependencies=[Depends(verify_key)])
def muhurta_rahukaal(b: MuhurtaInput):
    try:
        return {"success": True, **rahu_kaal(b.date, b.latitude, b.longitude, b.timezone)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Rahu Kaal failed: {e}")


@app.post("/astro/muhurta/hora", dependencies=[Depends(verify_key)])
def muhurta_hora(b: MuhurtaInput):
    try:
        return {"success": True, **hora(b.date, b.latitude, b.longitude, b.timezone)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Hora failed: {e}")


@app.post("/astro/muhurta/abhijit", dependencies=[Depends(verify_key)])
def muhurta_abhijit(b: MuhurtaInput):
    try:
        return {"success": True, **abhijit_muhurta(b.date, b.latitude, b.longitude, b.timezone)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Abhijit failed: {e}")

# === BEGIN NAKSHATRA ENDPOINTS ===

@app.post("/astro/nakshatra")
async def nakshatra_full(birth: BirthInput, _: str = Depends(verify_key)):
    """Full nakshatra analysis: Janma + Surya + Lagna + all 9 planets summary."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        return nakshatra_analyze_full(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Nakshatra analysis failed: {str(e)}")


@app.post("/astro/nakshatra/janma")
async def nakshatra_janma(birth: BirthInput, _: str = Depends(verify_key)):
    """Janma (Moon) nakshatra deep dive — the foundational reading."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        return nakshatra_analyze_janma(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Janma analysis failed: {str(e)}")


@app.post("/astro/nakshatra/all_planets")
async def nakshatra_all_planets(birth: BirthInput, _: str = Depends(verify_key)):
    """Full 16-attribute + 9-pada-sub-attribute analysis for all 9 planets (heavy payload)."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        return nakshatra_analyze_all_planets(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"All-planets analysis failed: {str(e)}")


@app.post("/astro/nakshatra/tara")
async def nakshatra_tara(birth: BirthInput, _: str = Depends(verify_key)):
    """27-Tara cycle from Janma + current Moon transit Tara."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        # Build a transit chart for today for current-tara lookup
        from datetime import datetime
        now = datetime.now()
        transit_chart = cast_chart(
            dob=now.strftime("%Y-%m-%d"),
            time=now.strftime("%H:%M"),
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        return nakshatra_analyze_tara(chart, transit_chart=transit_chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Tara analysis failed: {str(e)}")


@app.post("/astro/nakshatra/compatibility")
async def nakshatra_compatibility(
    inp: NakshatraCompatibilityInput,
    _: str = Depends(verify_key),
):
    """Quick 4-factor nakshatra compatibility (Gana/Nadi/Yoni/Varna)."""
    try:
        return nakshatra_analyze_compatibility(inp.nak1, inp.nak2)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Compatibility failed: {str(e)}")


@app.get("/astro/nakshatra/static/{name}")
async def nakshatra_static(
    name: str, pada: int = 1,
    _: str = Depends(verify_key),
):
    """Pure encyclopedia lookup — no birth chart needed. Used by the chat app."""
    try:
        return nakshatra_get_static(name, pada)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Static lookup failed: {str(e)}")


# === END NAKSHATRA ENDPOINTS ===

# === BEGIN YOGAS-V2 ENDPOINTS ===

@app.post("/astro/yogas/detect")
async def yogasv2_detect(birth: BirthInput, _: str = Depends(verify_key)):
    """Full yoga scan: detect all 198 yogas and return all (active + non-active)."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        return yogasv2_detect_all(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yogas detect failed: {str(e)}")


@app.post("/astro/yogas/active")
async def yogasv2_active(birth: BirthInput, _: str = Depends(verify_key)):
    """Return only the yogas currently present in the chart."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        return yogasv2_detect_active(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yogas active failed: {str(e)}")


@app.post("/astro/yogas/positive")
async def yogasv2_positive(birth: BirthInput, _: str = Depends(verify_key)):
    """Active positive yogas only, sorted by strength descending."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        return yogasv2_detect_positive(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yogas positive failed: {str(e)}")


@app.post("/astro/yogas/negative")
async def yogasv2_negative(birth: BirthInput, _: str = Depends(verify_key)):
    """Active negative yogas (doshas, arishtas) only, sorted by strength descending."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        return yogasv2_detect_negative(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yogas negative failed: {str(e)}")


@app.get("/astro/yogas/catalog")
async def yogasv2_catalog(family: str = None, _: str = Depends(verify_key)):
    """Full catalog of all 198 yogas (no chart needed). Optional family filter."""
    try:
        return yogasv2_get_catalog(family_filter=family)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yogas catalog failed: {str(e)}")


@app.get("/astro/yogas/single/{yoga_id}")
async def yogasv2_single(yoga_id: str, _: str = Depends(verify_key)):
    """Lookup a single yoga's metadata by ID."""
    try:
        return yogasv2_get_yoga(yoga_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yoga lookup failed: {str(e)}")


# === END YOGAS-V2 ENDPOINTS ===

# === BEGIN TIMELINE ENDPOINTS ===

def _build_timeline_callables(natal_chart, birth_dt, birth: BirthInput):
    """Build the dasha_fn and transit_fn callables for the timeline engine."""
    moon_lon = natal_chart.get("planets", {}).get("Moon", {}).get("longitude", 0.0)

    def dasha_fn(target_date):
        return _tl_get_dasha_state(moon_lon, birth_dt, target_date)

    def transit_fn(target_date):
        return cast_chart(
            dob=target_date.strftime("%Y-%m-%d"),
            time=target_date.strftime("%H:%M"),
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )

    return dasha_fn, transit_fn


@app.post("/astro/yogas/timeline/annual")
async def yogas_timeline_annual(birth: BirthInput, _: str = Depends(verify_key)):
    """Annual (12-month) yoga activation timeline. Used for the Annual Compass Report."""
    try:
        natal_chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        birth_dt = _tl_datetime.fromisoformat(f"{birth.dob}T{birth.time}:00")
        dasha_fn, transit_fn = _build_timeline_callables(natal_chart, birth_dt, birth)
        return timeline_annual(natal_chart, birth_dt, dasha_fn, transit_fn)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Annual timeline failed: {str(e)}")


@app.post("/astro/yogas/timeline/5year")
async def yogas_timeline_5year(birth: BirthInput, _: str = Depends(verify_key)):
    """5-year yoga activation timeline. Mid-term wealth/career planning horizon."""
    try:
        natal_chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        birth_dt = _tl_datetime.fromisoformat(f"{birth.dob}T{birth.time}:00")
        dasha_fn, transit_fn = _build_timeline_callables(natal_chart, birth_dt, birth)
        return timeline_5year(natal_chart, birth_dt, dasha_fn, transit_fn)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"5-year timeline failed: {str(e)}")


@app.post("/astro/yogas/timeline/10year")
async def yogas_timeline_10year(birth: BirthInput, _: str = Depends(verify_key)):
    """10-year yoga activation timeline. Long-term life-chapter horizon."""
    try:
        natal_chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        birth_dt = _tl_datetime.fromisoformat(f"{birth.dob}T{birth.time}:00")
        dasha_fn, transit_fn = _build_timeline_callables(natal_chart, birth_dt, birth)
        return timeline_10year(natal_chart, birth_dt, dasha_fn, transit_fn)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"10-year timeline failed: {str(e)}")


@app.post("/astro/yogas/timeline/15year")
async def yogas_timeline_15year(birth: BirthInput, _: str = Depends(verify_key)):
    """15-year yoga activation timeline. Full Mahadasha cycle context."""
    try:
        natal_chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        birth_dt = _tl_datetime.fromisoformat(f"{birth.dob}T{birth.time}:00")
        dasha_fn, transit_fn = _build_timeline_callables(natal_chart, birth_dt, birth)
        return timeline_15year(natal_chart, birth_dt, dasha_fn, transit_fn)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"15-year timeline failed: {str(e)}")


# === END TIMELINE ENDPOINTS ===

# === BEGIN NUMEROLOGY V2 ENDPOINTS ===

@app.post("/astro/numerology_v2/full")
async def numv2_full(inp: NumerologyV2Input, _: str = Depends(verify_key)):
    """Complete Numerology v2 reading — all static, karmic, time-cycle layers."""
    try:
        return numv2_full_reading(inp.name, inp.date_of_birth, inp.gender)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Numerology v2 full failed: {str(e)}")


@app.post("/astro/numerology_v2/static")
async def numv2_static(inp: NumerologyV2Input, _: str = Depends(verify_key)):
    """Just the static identity numbers — Pythagorean, Chaldean, Lo Shu, Kua."""
    try:
        return numv2_static_numbers(inp.name, inp.date_of_birth, inp.gender)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Numerology v2 static failed: {str(e)}")


@app.post("/astro/numerology_v2/karmic")
async def numv2_karmic(inp: NumerologyV2Input, _: str = Depends(verify_key)):
    """Karmic layer — debt numbers, lessons, hidden passion."""
    try:
        return numv2_karmic_layer(inp.name, inp.date_of_birth)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Numerology v2 karmic failed: {str(e)}")


@app.post("/astro/numerology_v2/cycles")
async def numv2_cycles(inp: NumerologyV2Input, _: str = Depends(verify_key)):
    """Time cycles — Universal Year, Personal Year/Month/Day, Pinnacles, Challenges, 15-yr Life Arc."""
    try:
        return numv2_time_cycles(
            inp.date_of_birth, inp.target_year, inp.target_month, inp.target_date
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Numerology v2 cycles failed: {str(e)}")


@app.post("/astro/numerology_v2/compatibility")
async def numv2_compat(inp: NumerologyV2CompatInput, _: str = Depends(verify_key)):
    """Two-person numerological compatibility scoring."""
    try:
        return numv2_compatibility(inp.name_a, inp.dob_a, inp.name_b, inp.dob_b)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Numerology v2 compat failed: {str(e)}")


# === END NUMEROLOGY V2 ENDPOINTS ===


# ══════════════════════════════════════════════════════════════════════
# ── FENG SHUI PERSONAL MODULE ──
# 9 endpoints — Classical Bazhai + Bazi + Lo Shu + Flying Stars
# Sources: Ba Zhai Ming Jing, Bazi Four Pillars, Lo Shu, Xuan Kong Fei Xing
# ══════════════════════════════════════════════════════════════════════

class FengShuiInput(BaseModel):
    dob: str           # YYYY-MM-DD
    gender: str        # "male" or "female"
    time: Optional[str] = "12:00"
    lat: Optional[float] = None
    lon: Optional[float] = None
    timezone: Optional[str] = "Asia/Kolkata"
    target_year: Optional[int] = None


class FengShuiCompatInput(BaseModel):
    person_a: FengShuiInput
    person_b: FengShuiInput


def _parse_fs_input(inp):
    """Helper — parse FengShuiInput into year, month, day components."""
    try:
        year, month, day = inp.dob.split("-")
        return int(year), int(month), int(day)
    except Exception:
        raise HTTPException(status_code=400, detail=f"Invalid dob format. Use YYYY-MM-DD. Got: {inp.dob}")


@app.post("/astro/fengshui/profile")
def fengshui_profile(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Master endpoint — full personal Feng Shui profile."""
    y, m, d = _parse_fs_input(inp)
    return full_personal_profile(y, m, d, inp.gender, inp.target_year)


@app.post("/astro/fengshui/kua")
def fengshui_kua(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Kua number + trigram + East/West group + compatible Kuas."""
    y, m, d = _parse_fs_input(inp)
    return calculate_kua(y, inp.gender, m, d)


@app.post("/astro/fengshui/directions")
def fengshui_directions(inp: FengShuiInput, _: str = Depends(verify_key)):
    """8 directions ranked — 4 lucky + 4 unlucky."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    return get_eight_directions(kua["kua_effective"])


@app.post("/astro/fengshui/elements")
def fengshui_elements(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Bazi Day Master + Year Animal Element + Wu Xing interactions."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    return {
        "year_animal":       calculate_year_animal(kua["solar_year_used"]),
        "day_master":        calculate_day_master(y, m, d),
        "personal_element":  element_interactions(kua["personal_element"]),
        "classical_source":  "Bazi Four Pillars + Wu Xing",
    }


@app.post("/astro/fengshui/loshu")
def fengshui_loshu(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Lo Shu Grid 3x3 with missing/excessive numbers analysis."""
    y, m, d = _parse_fs_input(inp)
    return calculate_lo_shu(y, m, d)


@app.post("/astro/fengshui/flying_stars")
def fengshui_flying_stars(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Xuan Kong Flying Stars for given year + native's personal palace star."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    target = inp.target_year or 2026
    return flying_stars_for_year(kua["kua_effective"], target)


@app.post("/astro/fengshui/bagua_home")
def fengshui_bagua_home(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Bagua home map — 9 life areas with colors, materials, alignment."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    return get_bagua_home_map(kua["kua_effective"])


@app.post("/astro/fengshui/compatibility")
def fengshui_compatibility_endpoint(inp: FengShuiCompatInput, _: str = Depends(verify_key)):
    """Two-person Feng Shui compatibility."""
    a_y, a_m, a_d = _parse_fs_input(inp.person_a)
    b_y, b_m, b_d = _parse_fs_input(inp.person_b)
    return feng_shui_compatibility(
        {"birth_year": a_y, "birth_month": a_m, "birth_day": a_d, "gender": inp.person_a.gender},
        {"birth_year": b_y, "birth_month": b_m, "birth_day": b_d, "gender": inp.person_b.gender},
    )


@app.post("/astro/fengshui/year_outlook")
def fengshui_year_outlook(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Personal year outlook — flying stars + zodiac year compatibility."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    target = inp.target_year or 2026
    return year_outlook(kua["kua_effective"], y, target)

# ── END FENG SHUI PERSONAL MODULE ──


# ══════════════════════════════════════════════════════════════════════
# ── ASTRO VASTU MODULE ──
# 10 endpoints — Classical Vastu Shastra personalized to Vedic chart
# Sources: Manasara, Mayamatam, Brihat Samhita, Vishvakarma Prakash
# ══════════════════════════════════════════════════════════════════════

class VastuPlotInput(BaseModel):
    shape: str            # "square", "rectangle_NS", "ne_extended", "triangular", etc.
    slope: str            # "north", "northeast", "south", etc.
    road_facing: str      # main road direction
    water_body: Optional[str] = None   # placement of well/pond/borewell


class VastuDoshaInput(BaseModel):
    observations: list    # ["toilet_in_NE", "kitchen_in_SE", "staircase_at_center"]


class VastuBusinessInput(BaseModel):
    business_type: str    # "shop_retail", "office_corporate", "warehouse_factory", "restaurant_hospitality"


class VastuRemedyQuery(BaseModel):
    for_dosha: Optional[str] = None   # specific dosha key, or None for full catalog


@app.post("/astro/vastu/profile")
def vastu_profile(inp: BirthInput, _: str = Depends(verify_key)):
    """Master endpoint — full personal Vastu analysis tied to native's Vedic chart."""
    return full_vastu_profile(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/vastu/personal_directions")
def vastu_personal_dirs(inp: BirthInput, _: str = Depends(verify_key)):
    """8 directions personalized to native's chart — Lagna/Moon/AK/Dasha overlay."""
    return vastu_personal_directions(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/vastu/plot_analysis")
def vastu_plot(inp: VastuPlotInput, _: str = Depends(verify_key)):
    """Plot evaluation — shape, slope, road facing, water body — with composite score."""
    return vastu_plot_analysis(
        shape=inp.shape, slope=inp.slope,
        road_facing=inp.road_facing, water_body=inp.water_body,
    )


@app.post("/astro/vastu/room_placement")
def vastu_rooms(inp: BirthInput, _: str = Depends(verify_key)):
    """Full room placement matrix — 16 rooms × 8 directions with classical citations."""
    return vastu_room_placement(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/vastu/doshas")
def vastu_doshas_endpoint(inp: VastuDoshaInput, _: str = Depends(verify_key)):
    """Detect Vastu doshas from observations of the home."""
    return vastu_doshas(observations=inp.observations)


@app.post("/astro/vastu/remedies")
def vastu_remedies_endpoint(inp: VastuRemedyQuery, _: str = Depends(verify_key)):
    """Full Vastu remedies catalog — optionally filtered for a specific dosha."""
    return vastu_remedies(for_dosha=inp.for_dosha)


@app.get("/astro/vastu/marma_points")
def vastu_marma_endpoint(_: str = Depends(verify_key)):
    """Vastu Purusha Mandala (81-pada grid) + critical marma points."""
    return vastu_marma()


@app.post("/astro/vastu/auspicious_construction")
def vastu_construction(inp: BirthInput, _: str = Depends(verify_key)):
    """Construction muhurta — months, nakshatras, tithis, weekdays — chart-aware."""
    return vastu_construction_muhurta(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/vastu/business_vastu")
def vastu_business_endpoint(inp: VastuBusinessInput, _: str = Depends(verify_key)):
    """Business Vastu — commercial space configuration by type."""
    return vastu_business(business_type=inp.business_type)


@app.post("/astro/vastu/yantra_directions")
def vastu_yantra(inp: BirthInput, _: str = Depends(verify_key)):
    """Personal yantra placement directions based on afflicted planets in chart."""
    return vastu_yantra_directions(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )

# ── END ASTRO VASTU MODULE ──


# ══════════════════════════════════════════════════════════════════════
# ── MASTER REMEDIES MODULE (3a) ──
# 18 endpoints — Vedic + Therapeutic + Numerology + Master
# Sources: Brihat Samhita, BPHS, Garuda Purana, Atharva Veda, Cheiro
# ══════════════════════════════════════════════════════════════════════

class RemedyNameInput(BaseModel):
    name: str
    dob: str            # YYYY-MM-DD


class RemedyMobileInput(BaseModel):
    mobile: str
    dob: str


class RemedyVehicleInput(BaseModel):
    registration: str
    dob: str


class RemedyDobOnlyInput(BaseModel):
    dob: str


class RemedyChartWithNameInput(BaseModel):
    dob: str
    time: str
    lat: float
    lon: float
    timezone: Optional[str] = "Asia/Kolkata"
    name: Optional[str] = None


class RemedyPurposeInput(BaseModel):
    purpose: str
    dob: str
    time: str
    lat: float
    lon: float
    timezone: Optional[str] = "Asia/Kolkata"


# ── Master endpoints (3) ──

@app.post("/astro/remedies/for_chart")
def remedies_master_for_chart(inp: RemedyChartWithNameInput, _: str = Depends(verify_key)):
    """MASTER — full personalized remedies (Vedic + Therapeutic + Numerology) for a chart."""
    return remedies_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata", name=inp.name,
    )


@app.post("/astro/remedies/by_purpose")
def remedies_master_by_purpose(inp: RemedyPurposeInput, _: str = Depends(verify_key)):
    """Filter remedies by life-area: wealth_and_prosperity, health_and_longevity, career_and_authority, relationship_and_marriage, education_and_intelligence, spirituality_and_moksha, obstacle_removal, protection_from_negativity, saturn_sade_sati_relief."""
    return remedies_by_purpose(
        purpose=inp.purpose, dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.get("/astro/remedies/full_catalog")
def remedies_master_full_catalog(_: str = Depends(verify_key)):
    """Return complete catalog (all 4 JSONs) for inspection/export."""
    return remedies_full_catalog()


# ── Vedic endpoints (7) ──

@app.post("/astro/remedies/vedic/gemstones")
def remedies_vedic_gemstones(inp: BirthInput, _: str = Depends(verify_key)):
    """Gemstones for chart — filtered by classical safety rules (no 6/8/12 lords)."""
    return gemstones_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/vedic/rudrakshas")
def remedies_vedic_rudrakshas(inp: BirthInput, _: str = Depends(verify_key)):
    """Rudrakshas for chart — based on afflicted planets."""
    return rudrakshas_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/vedic/mantras")
def remedies_vedic_mantras(inp: BirthInput, _: str = Depends(verify_key)):
    """Mantras for weakest planet + all afflicted planets."""
    return mantras_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/vedic/yantras")
def remedies_vedic_yantras(inp: BirthInput, _: str = Depends(verify_key)):
    """Yantras — afflicted planet specific + universal home yantras."""
    return yantras_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/vedic/ishta_devata")
def remedies_vedic_ishta_devata(inp: BirthInput, _: str = Depends(verify_key)):
    """Determine personal deity from Atmakaraka + 12th lord."""
    return ishta_devata_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/vedic/donations")
def remedies_vedic_donations(inp: BirthInput, _: str = Depends(verify_key)):
    """Donations for afflicted planets — items, recipients, day."""
    return donations_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/vedic/fasting")
def remedies_vedic_fasting(inp: BirthInput, _: str = Depends(verify_key)):
    """Fasting for weakest planet — vrat name, rules."""
    return fasting_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


# ── Therapeutic endpoints (3) ──

@app.post("/astro/remedies/therapeutic/colors")
def remedies_therapeutic_colors(inp: BirthInput, _: str = Depends(verify_key)):
    """Color therapy — strengthen weakest, avoid 6/8/12 lord colors."""
    return color_therapy_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/therapeutic/sound")
def remedies_therapeutic_sound(inp: BirthInput, _: str = Depends(verify_key)):
    """Sound/raga/frequency therapy for weakest planet."""
    return sound_therapy_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/therapeutic/aromatherapy")
def remedies_therapeutic_aroma(inp: BirthInput, _: str = Depends(verify_key)):
    """Aromatherapy — essential oils, incense per planet."""
    return aromatherapy_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


# ── Numerology endpoints (5) ──

@app.post("/astro/remedies/numerology/name")
def remedies_numerology_name(inp: RemedyNameInput, _: str = Depends(verify_key)):
    """Chaldean name numerology — compatibility with Driver/Conductor."""
    return name_numerology(name=inp.name, dob=inp.dob)


@app.post("/astro/remedies/numerology/mobile")
def remedies_numerology_mobile(inp: RemedyMobileInput, _: str = Depends(verify_key)):
    """Mobile number analysis — digit sum, compatibility, recommendations."""
    return mobile_analysis(mobile=inp.mobile, dob=inp.dob)


@app.post("/astro/remedies/numerology/vehicle")
def remedies_numerology_vehicle(inp: RemedyVehicleInput, _: str = Depends(verify_key)):
    """Vehicle registration analysis — safety and resale guidance."""
    return vehicle_analysis(registration=inp.registration, dob=inp.dob)


@app.post("/astro/remedies/numerology/signature")
def remedies_numerology_signature(inp: RemedyDobOnlyInput, _: str = Depends(verify_key)):
    """Signature principles + planet-specific pen recommendation."""
    return signature_guidance(dob=inp.dob)


@app.post("/astro/remedies/numerology/lucky_dates")
def remedies_numerology_lucky_dates(inp: RemedyDobOnlyInput, _: str = Depends(verify_key)):
    """Lucky dates of month based on Driver + universal Indian dates."""
    return lucky_dates(dob=inp.dob)

# ── END MASTER REMEDIES MODULE (3a) ──


# ══════════════════════════════════════════════════════════════════════
# ── ESOTERIC REMEDIES MODULE (3b) ──
# 27 endpoints — Solomonic + Atharva Vedic + Tantric + VBT + Kabbalistic + Egyptian/Hellenistic
# All sources public domain. Classical correspondence reference framing.
# ══════════════════════════════════════════════════════════════════════

class EsotericPurposeInput(BaseModel):
    purpose: str


class EsotericPlanetInput(BaseModel):
    planet: Optional[str] = None


class EsotericWeekdayInput(BaseModel):
    weekday: Optional[str] = None


# ── Solomonic (5) ──

@app.post("/astro/remedies/esoteric/solomonic/planetary_hours")
def esoteric_planetary_hours(inp: EsotericWeekdayInput, _: str = Depends(verify_key)):
    """Classical Chaldean planetary hour system + day rulers + best uses."""
    return planetary_hours_info(weekday=inp.weekday)


@app.post("/astro/remedies/esoteric/solomonic/goetia")
def esoteric_goetia(inp: EsotericPlanetInput, _: str = Depends(verify_key)):
    """72 Goetia reference (first 18 listed) — academic/correspondence reference only."""
    return goetia_reference(planet=inp.planet)


@app.get("/astro/remedies/esoteric/solomonic/planetary_squares")
def esoteric_planetary_squares(_: str = Depends(verify_key)):
    """Planetary magic squares (Kameas) from Agrippa."""
    return planetary_squares()


@app.get("/astro/remedies/esoteric/solomonic/olympic_spirits")
def esoteric_olympic_spirits(_: str = Depends(verify_key)):
    """7 Olympic Spirits from Arbatel of Magic (1575)."""
    return olympic_spirits()


@app.get("/astro/remedies/esoteric/solomonic/talismans")
def esoteric_talismans(_: str = Depends(verify_key)):
    """Classical Hermetic planetary talisman composition (metal, color, timing)."""
    return talismans_summary()


# ── Atharva Vedic (5) ──

@app.post("/astro/remedies/esoteric/atharva/by_purpose")
def esoteric_atharva_by_purpose(inp: EsotericPurposeInput, _: str = Depends(verify_key)):
    """Atharva Veda hymns by purpose: healing, protection, peace, prosperity, nullification."""
    return atharva_suktas_by_purpose(purpose=inp.purpose)


@app.get("/astro/remedies/esoteric/atharva/healing_hymns")
def esoteric_atharva_healing(_: str = Depends(verify_key)):
    """Atharva Veda Bhaishajya (healing) hymns catalog."""
    return atharva_healing_hymns()


@app.get("/astro/remedies/esoteric/atharva/protection_hymns")
def esoteric_atharva_protection(_: str = Depends(verify_key)):
    """Atharva Veda Raksha (protection) hymns catalog."""
    return atharva_protection_hymns()


@app.get("/astro/remedies/esoteric/atharva/abhichar_nullifier")
def esoteric_atharva_nullifier(_: str = Depends(verify_key)):
    """Atharva Veda DEFENSIVE hymns for nullification — self-protection only."""
    return atharva_abhichar_nullifier()


@app.get("/astro/remedies/esoteric/atharva/peace_invocations")
def esoteric_atharva_peace(_: str = Depends(verify_key)):
    """Atharva Veda Shanti (peace) invocations."""
    return atharva_peace_invocations()


# ── Tantric (5) ──

@app.post("/astro/remedies/esoteric/tantric/personal_mahavidya")
def esoteric_personal_mahavidya(inp: BirthInput, _: str = Depends(verify_key)):
    """Personal Mahavidya by weakest planet + Atmakaraka."""
    return personal_mahavidya(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.get("/astro/remedies/esoteric/tantric/kavachas")
def esoteric_kavachas(_: str = Depends(verify_key)):
    """Classical kavachas (armor mantras) catalog."""
    return kavachas_catalog()


@app.post("/astro/remedies/esoteric/tantric/devi_for_purpose")
def esoteric_devi_purpose(inp: EsotericPurposeInput, _: str = Depends(verify_key)):
    """Devi recommendation by purpose (wealth, knowledge, marriage, etc.)."""
    return devi_for_purpose(purpose=inp.purpose)


@app.get("/astro/remedies/esoteric/tantric/dasha_mahavidya")
def esoteric_dasha_mahavidya(_: str = Depends(verify_key)):
    """Full Dasha Mahavidya (10 Wisdom Goddesses) catalog."""
    return dasha_mahavidya_full()


@app.get("/astro/remedies/esoteric/tantric/navadurga")
def esoteric_navadurga(_: str = Depends(verify_key)):
    """Navadurga (9 forms of Durga) — Navaratri correspondence."""
    return navadurga_correspondence()


# ── Vigyan Bhairava Tantra (5) ──

@app.post("/astro/remedies/esoteric/vbt/dharana_for_chart")
def esoteric_vbt_dharana(inp: BirthInput, _: str = Depends(verify_key)):
    """Recommend Vigyan Bhairava dharana based on weakest planet in chart."""
    return vbt_dharana_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.get("/astro/remedies/esoteric/vbt/breath_techniques")
def esoteric_vbt_breath(_: str = Depends(verify_key)):
    """VBT breath-based dharanas."""
    return vbt_breath_techniques()


@app.get("/astro/remedies/esoteric/vbt/awareness_techniques")
def esoteric_vbt_awareness(_: str = Depends(verify_key)):
    """VBT pure awareness dharanas."""
    return vbt_awareness_techniques()


@app.get("/astro/remedies/esoteric/vbt/all_112")
def esoteric_vbt_all(_: str = Depends(verify_key)):
    """VBT — categorization of all 112 dharanas + sample translations."""
    return vbt_all_112()


@app.get("/astro/remedies/esoteric/vbt/devotional_practices")
def esoteric_vbt_devotional(_: str = Depends(verify_key)):
    """VBT devotional/bhava-based dharanas."""
    return vbt_devotional_practices()


# ── Kabbalistic (4) ──

@app.get("/astro/remedies/esoteric/kabbalistic/tree_of_life")
def esoteric_tree_of_life(_: str = Depends(verify_key)):
    """Tree of Life — 10 sephiroth with planetary attributions."""
    return tree_of_life()


@app.post("/astro/remedies/esoteric/kabbalistic/sephirot_for_chart")
def esoteric_sephirot_chart(inp: BirthInput, _: str = Depends(verify_key)):
    """Personal sephirot mapping — Lagna lord, current MD, Atmakaraka sephiroth."""
    return sephirot_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.get("/astro/remedies/esoteric/kabbalistic/paths")
def esoteric_kabbalistic_paths(_: str = Depends(verify_key)):
    """22 paths of the Tree of Life with planetary path summary."""
    return kabbalistic_paths()


@app.get("/astro/remedies/esoteric/kabbalistic/divine_names")
def esoteric_divine_names(_: str = Depends(verify_key)):
    """Divine names + planetary archangels (Hermetic Qabalah)."""
    return divine_names_planetary()


# ── Egyptian / Hellenistic (3) ──

@app.post("/astro/remedies/esoteric/hellenic/decan_ruler")
def esoteric_decan_ruler(inp: BirthInput, _: str = Depends(verify_key)):
    """36-decan system — Lagna sign decans + full 36 table."""
    return decan_ruler(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/esoteric/hellenic/time_lord")
def esoteric_time_lord(inp: BirthInput, _: str = Depends(verify_key)):
    """Hellenistic profections — current year's profected house lord."""
    return hellenistic_time_lord(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.get("/astro/remedies/esoteric/hellenic/planetary_deities")
def esoteric_planetary_deities(_: str = Depends(verify_key)):
    """Cross-tradition planetary deity correspondence (Vedic, Egyptian, Greek, Roman, Norse, etc.)."""
    return planetary_deities_cross_tradition()

# ── END ESOTERIC REMEDIES MODULE (3b) ──


# ══════════════════════════════════════════════════════════════════════
# ── HEALTH MODULE (B1) ──
# 15 endpoints — Health + Chakra + Ayurveda
# Sources: Charaka Samhita, Sushruta Samhita, Ashtanga Hridaya,
#          Hatha Yoga Pradipika, BPHS, Sarvartha Chintamani
# ══════════════════════════════════════════════════════════════════════

@app.post("/astro/health/profile")
def health_profile(inp: BirthInput, _: str = Depends(verify_key)):
    """Master endpoint — full Health + Chakra + Ayurveda profile."""
    return full_health_profile(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/body_parts")
def health_body_parts_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Body parts by house + planet; afflicted organs in chart."""
    return health_body_parts(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/illness_predisposition")
def health_illness_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Disease tendencies from 6th house, 8th house, ascendant afflictions."""
    return health_illness(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/tridosha")
def health_tridosha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Vata/Pitta/Kapha analysis from planets + signs in chart."""
    return health_tridosha(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/prakriti")
def health_prakriti_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Birth constitution (Prakriti) from Lagna + Moon nakshatra."""
    return health_prakriti(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/vikriti_current")
def health_vikriti_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Current dosha imbalance (Vikriti) from current dasha + afflictions."""
    return health_vikriti(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/chakras")
def health_chakras_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """7 chakras with personal afflicted/balanced status based on planetary placements."""
    return health_chakras(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/chakra_balancing")
def health_chakra_balancing_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Specific chakra balancing practices prioritized by chart afflictions."""
    return health_chakra_balancing(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/healing_windows")
def health_healing_windows_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Best dasha/transit windows for medical treatment."""
    return health_healing_windows(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/avoidance_windows")
def health_avoidance_windows_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Windows to avoid major medical procedures."""
    return health_avoidance_windows(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/ayurvedic_diet")
def health_diet_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Dietary recommendations by Prakriti."""
    return health_diet(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/yoga_pranayama")
def health_yoga_pranayama_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Yoga asanas + pranayama for native's chart."""
    return health_yoga_pranayama(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/mental_health")
def health_mental_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Mind analysis (Moon, Mercury, 5th house) — stress patterns, predispositions."""
    return health_mental(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/longevity_factors")
def health_longevity_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Ayurvedic + astrological longevity factors assessment."""
    return health_longevity(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/health_remedies")
def health_remedies_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Health-specific remedies from chart afflictions."""
    return health_remedies(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )

# ── END HEALTH MODULE (B1) ──


# ══════════════════════════════════════════════════════════════════════
# ── CAREER + WEALTH MODULE (B2) ──
# 12 endpoints — Career (6) + Wealth (6)
# Sources: BPHS Ch. 35-40, Phaladeepika, Jataka Parijata, Saravali,
#          Sarvartha Chintamani, Jaimini Sutras
# ══════════════════════════════════════════════════════════════════════

# ── Career endpoints (6) ──

@app.post("/astro/career/profile")
def career_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master career profile — karakas, D10, raja yogas, fields."""
    return full_career_profile(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/career/d10_deep_dive")
def career_d10_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """D10 Dashamsha analysis — career direction."""
    return d10_deep_dive(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/career/karaka_analysis")
def career_karaka_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Career karakas — Sun, Saturn, Mercury, Jupiter + AK/AmK."""
    return karaka_analysis_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/career/natural_fields")
def career_fields_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Compatible career fields from chart placements."""
    return natural_career_fields_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/career/timing")
def career_timing_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Best dasha periods for career moves, promotions."""
    return career_timing_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/career/professional_dasha")
def career_dasha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Current MD/AD lord's career-relevance analysis."""
    return professional_dasha_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


# ── Wealth endpoints (6) ──

@app.post("/astro/wealth/profile")
def wealth_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master wealth profile — Dhana yogas, sources, risks, remedies."""
    return full_wealth_profile(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/wealth/dhana_yogas")
def wealth_dhana_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """All wealth-bestowing yogas detected in chart."""
    return dhana_yogas_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/wealth/income_sources")
def wealth_sources_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """11th house lord + planets indicating income sources."""
    return income_sources_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/wealth/risk_areas")
def wealth_risk_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Loss patterns — 12th, 8th, Kemadruma, Daridra yogas."""
    return wealth_risk_areas_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/wealth/income_windows")
def wealth_windows_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Best dasha windows for income peaks."""
    return income_windows_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/wealth/wealth_remedies")
def wealth_remedies_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Wealth-specific remedies — Kubera, Lakshmi, Sri Yantra, behavioral."""
    return wealth_remedies_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )

# ── END CAREER + WEALTH MODULE (B2) ──


# ══════════════════════════════════════════════════════════════════════
# ── PRASHNA MODULE (B3) ──
# 10 endpoints — Prashna (Horary) astrology
# Sources: Tajik Neelakanthi, Prashna Marga, KP methodology,
#          Brihat Samhita commentary, Daivagya Vallabha
# ══════════════════════════════════════════════════════════════════════

class PrashnaInput(BaseModel):
    """Input schema for Prashna (horary) endpoints.

    Question is cast at the moment it is asked — NOT birth time.
    """
    question_datetime: str        # ISO format e.g. "2026-05-16T11:30:00"
    question_lat: float
    question_lon: float
    question_timezone: Optional[str] = "Asia/Kolkata"
    question_category: Optional[str] = "general"  # marriage, career, health, travel, finance, missing_item, legal_matter, general
    question_text: Optional[str] = None


@app.post("/astro/prashna/profile")
def prashna_profile_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Master Prashna profile — complete horary chart analysis."""
    return full_prashna_profile(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        timezone=inp.question_timezone or "Asia/Kolkata",
        category=inp.question_category or "general",
        question_text=inp.question_text,
    )


@app.post("/astro/prashna/lagna_analysis")
def prashna_lagna_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Lagna at moment of question + signature interpretation."""
    return prashna_lagna(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/moon_analysis")
def prashna_moon_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Moon's role in answering the question (Chandra Lagna analysis)."""
    return prashna_moon(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/significator")
def prashna_significator_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Karaka identification for the question category."""
    return prashna_significator(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        category=inp.question_category or "general",
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/timing")
def prashna_timing_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """When the matter will resolve."""
    return prashna_timing(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        category=inp.question_category or "general",
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/yes_no")
def prashna_yes_no_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Binary YES/NO answer — multi-method synthesis (classical + KP)."""
    return prashna_yes_no(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        category=inp.question_category or "general",
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/kp_horary")
def prashna_kp_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """KP horary — Ruling Planets + cuspal sub-lord framework."""
    return prashna_kp(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        category=inp.question_category or "general",
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/aroodha_lagna")
def prashna_aroodha_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Aroodha Lagna (Jaimini horary technique) — public manifestation indicator."""
    return prashna_aroodha(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/swara")
def prashna_swara_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Swara (breath/nostril) analysis rules at moment of question."""
    return prashna_swara(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/specific_query")
def prashna_specific_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Category-templated reading combining all techniques."""
    return prashna_specific(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        category=inp.question_category or "general",
        timezone=inp.question_timezone or "Asia/Kolkata",
        question_text=inp.question_text,
    )

# ── END PRASHNA MODULE (B3) ──


# ════════════════════════════════════════════════════════════════════════
# ── TRANSIT C0 MODULE ──
# Phase C0 — Transit Engine (12 endpoints)
# Sources: BPHS Ch. 41, Phaladeepika Ch. 26-27, Saravali Ch. 39, BPHS Ch. 67
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _TransitBaseModel
from typing import Optional as _TransitOptional

class TransitInput(_TransitBaseModel):
    birth: BirthInput
    transit_date: _TransitOptional[str] = None      # ISO "YYYY-MM-DD"; default = today
    transit_time: _TransitOptional[str] = "12:00"   # HH:MM; default = midday


def _transit_birth_dict(birth: BirthInput) -> dict:
    return {
        "dob":      birth.dob,
        "time":     birth.time,
        "lat":      birth.lat,
        "lon":      birth.lon,
        "timezone": birth.timezone,
    }


@app.post("/astro/transit/profile")
def transit_profile_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Master transit overview synthesizing all key transit signals."""
    return transit_handle_profile(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/current_positions")
def transit_current_positions_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """All 9 planets' current sidereal positions for transit moment."""
    return transit_handle_current_positions(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/personal_houses")
def transit_personal_houses_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Planets transiting through native's natal houses (from Lagna + from Moon)."""
    return transit_handle_personal_houses(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/sade_sati")
def transit_sade_sati_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Saturn Sade Sati exact phase + remediation guidance."""
    return transit_handle_sade_sati(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/jupiter_transit")
def transit_jupiter_transit_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Current Jupiter transit + house-from-Lagna effects + AV strength."""
    return transit_handle_jupiter_transit(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/saturn_transit")
def transit_saturn_transit_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Saturn deep transit analysis with Sade Sati cross-reference + AV strength."""
    return transit_handle_saturn_transit(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/rahu_ketu_transit")
def transit_rahu_ketu_transit_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Rahu-Ketu nodal axis transit (~18 month cadence)."""
    return transit_handle_rahu_ketu_transit(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/eclipses_impact")
def transit_eclipses_impact_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Eclipse axis (Rahu/Ketu) proximity to natal Sun/Moon/Lagna."""
    return transit_handle_eclipses_impact(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/gochara_phala")
def transit_gochara_phala_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Classical Gochara Phala per planet (with Vedha blockage check)."""
    return transit_handle_gochara_phala(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/ashtaka_varga_transit")
def transit_ashtaka_varga_transit_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Bhinnashtaka + Sarvashtaka Varga strength of current transits."""
    return transit_handle_ashtaka_varga_transit(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/major_alerts_12months")
def transit_major_alerts_12months_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Major transit events forecasted for next 12 months (quarterly sampling)."""
    return transit_handle_major_alerts_12months(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/retrograde_periods")
def transit_retrograde_periods_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Personal impact of current retrograde periods (Mercury/Venus/Mars/Jupiter/Saturn)."""
    return transit_handle_retrograde_periods(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )

# ── END TRANSIT C0 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── COMPATIBILITY C1 MODULE ──
# Phase C — Module C1 — Two-chart Vedic compatibility (12 endpoints)
# Sources: BPHS Ch. 44, Phaladeepika Ch. 7, Saravali Ch. 27-28,
#          Hora Sara, Muhurta Chintamani, Jataka Parijata Ch. 14
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _CompatBaseModel
from typing import Optional as _CompatOptional

class CompatibilityInput(_CompatBaseModel):
    person1: BirthInput
    person2: BirthInput
    relationship_type: _CompatOptional[str] = "marriage"
    person1_gender: _CompatOptional[str] = "M"
    person2_gender: _CompatOptional[str] = "F"


def _compat_birth_dict(b: BirthInput, gender: str) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
        "gender":   gender,
    }


@app.post("/astro/compat/profile")
def compat_profile_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Master compatibility synthesis — Ashtakoot + Manglik + 7th + karakas + D9 + longevity."""
    return compat_handle_profile(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
        inp.relationship_type or "marriage",
    )


@app.post("/astro/compat/ashtakoot")
def compat_ashtakoot_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Full 8-Kuta 36-point Ashtakoot matching."""
    return compat_handle_ashtakoot(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
        inp.relationship_type or "marriage",
    )


@app.post("/astro/compat/manglik")
def compat_manglik_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Mars dosha analysis for both charts with classical cancellations."""
    return compat_handle_manglik(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/nadi_dosha")
def compat_nadi_dosha_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Nadi Kuta detailed analysis (most weighted: 8/36 points)."""
    return compat_handle_nadi_dosha(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/bhakoot_dosha")
def compat_bhakoot_dosha_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Bhakoot Kuta — Moon-sign distance dosha with cancellations."""
    return compat_handle_bhakoot_dosha(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/dasha_compatibility")
def compat_dasha_compatibility_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Current and upcoming dasha overlap between both natives."""
    return compat_handle_dasha_compatibility(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/synastry_aspects")
def compat_synastry_aspects_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Cross-chart aspect mapping — each person's planets in partner's houses."""
    return compat_handle_synastry_aspects(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/d9_navamsha_compat")
def compat_d9_navamsha_compat_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """D9 Navamsha marriage-chart synthesis (deepest marriage indicator)."""
    return compat_handle_d9_navamsha_compat(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/seventh_house_synthesis")
def compat_seventh_house_synthesis_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Both natives' 7th houses analyzed for partnership indications."""
    return compat_handle_seventh_house_synthesis(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/venus_jupiter_synthesis")
def compat_venus_jupiter_synthesis_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Marriage karakas Venus + Jupiter cross-analysis between charts."""
    return compat_handle_venus_jupiter_synthesis(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/longevity_match")
def compat_longevity_match_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """8th house (Ayur Bhava) comparison for joint longevity per Jataka Parijata Ch. 14."""
    return compat_handle_longevity_match(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/timing_for_marriage")
def compat_timing_for_marriage_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Marriage muhurta general guidance + each partner's favorable dasha periods."""
    return compat_handle_timing_for_marriage(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )

# ── END COMPATIBILITY C1 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── VARSHAPHALA C2 MODULE ──
# Phase C — Module C2 — Annual chart / solar return (10 endpoints)
# Sources: Tajik Neelakanthi (~16th c.), Varshaphala Paddhati, Phaladeepika Ch. 8
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _VarshaBaseModel

class VarshaphalaInput(_VarshaBaseModel):
    birth: BirthInput
    year: int   # Target Varsha year (e.g., 2026 = the solar year starting from solar return in 2026)


def _varsha_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/varshaphala/profile")
def varsha_profile_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Master Varshaphala synthesis — solar return + Muntha + Varshesha + yogas + Sahams + remedies."""
    return varsha_handle_profile(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/cast_chart")
def varsha_cast_chart_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Solar return chart for target year — iterative Sun-longitude convergence."""
    return varsha_handle_cast_chart(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/muntha")
def varsha_muntha_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Muntha sign + lord + house in solar return chart."""
    return varsha_handle_muntha(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/year_lord")
def varsha_year_lord_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Varshesha (Year Lord) selection from 5 classical candidates."""
    return varsha_handle_year_lord(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/tajik_aspects")
def varsha_tajik_aspects_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Ithasala / Eesharafa / Mutthasila yoga detection in solar return chart."""
    return varsha_handle_tajik_aspects(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/sahams")
def varsha_sahams_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """20 classical Sahams (Hellenistic-Tajik Lots) — Punya, Vidya, Yashas, Mitra, etc."""
    return varsha_handle_sahams(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/monthly_predictions")
def varsha_monthly_predictions_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """12-month breakdown — each month's Muntha house and themes."""
    return varsha_handle_monthly_predictions(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/dasha_for_year")
def varsha_dasha_for_year_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Mudda dasha — Vimshottari ratios compressed to solar return year."""
    return varsha_handle_dasha_for_year(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/event_timing")
def varsha_event_timing_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Key event windows synthesized from Muntha + Year Lord + Sahams."""
    return varsha_handle_event_timing(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/year_remedies")
def varsha_year_remedies_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Year-specific classical remedies based on Varshesha and Muntha placement."""
    return varsha_handle_year_remedies(_varsha_birth_dict(inp.birth), inp.year)

# ── END VARSHAPHALA C2 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── MUHURTA PRO C3 MODULE ──
# Phase C — Module C3 — Electional astrology (8 endpoints)
# Namespace: /astro/muhurta_pro/* to avoid collision with /astro/muhurta/*
# Sources: Muhurta Chintamani, Muhurta Martanda, Muhurta Ganapati
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _MhProBaseModel
from typing import Optional as _MhProOptional


class MuhurtaProInput(_MhProBaseModel):
    check_datetime: str        # ISO "2026-05-16T11:30:00"
    lat: float
    lon: float
    timezone: _MhProOptional[str] = "Asia/Kolkata"
    purpose: _MhProOptional[str] = "general"  # marriage/business/travel/property/medical/general


class MuhurtaProFindWindowInput(_MhProBaseModel):
    check_datetime: str
    lat: float
    lon: float
    timezone: _MhProOptional[str] = "Asia/Kolkata"
    purpose: _MhProOptional[str] = "general"
    search_days: _MhProOptional[int] = 30
    min_score: _MhProOptional[float] = 70.0


@app.post("/astro/muhurta_pro/profile")
def mhpro_profile_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Master moment analysis — score primary purpose + compare across all 6 purposes."""
    return mhpro_handle_profile(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata", inp.purpose or "general",
    )


@app.post("/astro/muhurta_pro/check_moment")
def mhpro_check_moment_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Is THIS moment good for X? Composite 0-100 score with verdict."""
    return mhpro_handle_check_moment(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata", inp.purpose or "general",
    )


@app.post("/astro/muhurta_pro/find_window")
def mhpro_find_window_ep(inp: MuhurtaProFindWindowInput, _: str = Depends(verify_key)):
    """Find next favorable window for purpose within search_days, samples 6h intervals."""
    return mhpro_handle_find_window(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata",
        inp.purpose or "general",
        inp.search_days or 30,
        inp.min_score if inp.min_score is not None else 70.0,
    )


@app.post("/astro/muhurta_pro/marriage_muhurta")
def mhpro_marriage_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Marriage-specific Muhurta scoring + classical rule reference."""
    return mhpro_handle_marriage_muhurta(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/muhurta_pro/business_muhurta")
def mhpro_business_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Business inception Muhurta scoring + classical rule reference."""
    return mhpro_handle_business_muhurta(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/muhurta_pro/travel_muhurta")
def mhpro_travel_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Travel/yatra Muhurta scoring + classical rule reference."""
    return mhpro_handle_travel_muhurta(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/muhurta_pro/property_muhurta")
def mhpro_property_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Property/Griha Pravesh Muhurta scoring + classical rule reference."""
    return mhpro_handle_property_muhurta(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/muhurta_pro/medical_muhurta")
def mhpro_medical_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Medical procedure Muhurta scoring + classical rule reference."""
    return mhpro_handle_medical_muhurta(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata",
    )

# ── END MUHURTA PRO C3 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── PANCHANG C4 MODULE ──
# Phase C — Module C4 — Daily Panchang (6 endpoints)
# Sources: BPHS Ch. 99 (Panchang Adhyaya), classical calendar tradition
# Note: Phase A has /astro/panchang endpoint already (legacy);
#       C4 namespace uses /astro/panchang/* sub-paths (no collision)
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _PanchangBaseModel
from typing import Optional as _PanchangOptional


class PanchangInput(_PanchangBaseModel):
    date: str             # YYYY-MM-DD
    lat: float
    lon: float
    timezone: _PanchangOptional[str] = "Asia/Kolkata"


@app.post("/astro/panchang/full")
def panchang_full_ep(inp: PanchangInput, _: str = Depends(verify_key)):
    """Full Panchang — all 5 limbs + Rahu Kaal/Yama Gandam/Gulika Kalam time bands."""
    return panchang_handle_full(inp.date, inp.lat, inp.lon, inp.timezone or "Asia/Kolkata")


@app.post("/astro/panchang/tithi")
def panchang_tithi_ep(inp: PanchangInput, _: str = Depends(verify_key)):
    """Tithi only (lunar day, name, paksha)."""
    return panchang_handle_tithi(inp.date, inp.lat, inp.lon, inp.timezone or "Asia/Kolkata")


@app.post("/astro/panchang/nakshatra")
def panchang_nakshatra_ep(inp: PanchangInput, _: str = Depends(verify_key)):
    """Nakshatra of the Moon for the date + ruling planet."""
    return panchang_handle_nakshatra(inp.date, inp.lat, inp.lon, inp.timezone or "Asia/Kolkata")


@app.post("/astro/panchang/yoga")
def panchang_yoga_ep(inp: PanchangInput, _: str = Depends(verify_key)):
    """Yoga (Sun+Moon longitude segment) + favorability classification."""
    return panchang_handle_yoga(inp.date, inp.lat, inp.lon, inp.timezone or "Asia/Kolkata")


@app.post("/astro/panchang/karana")
def panchang_karana_ep(inp: PanchangInput, _: str = Depends(verify_key)):
    """Karana (half-tithi) + Bhadra warning flag."""
    return panchang_handle_karana(inp.date, inp.lat, inp.lon, inp.timezone or "Asia/Kolkata")


@app.post("/astro/panchang/rahu_kalam")
def panchang_rahu_kalam_ep(inp: PanchangInput, _: str = Depends(verify_key)):
    """Rahu Kalam + Yama Gandam + Gulika Kalam time bands (NOAA sunrise/sunset)."""
    return panchang_handle_rahu_kalam(inp.date, inp.lat, inp.lon, inp.timezone or "Asia/Kolkata")

# ── END PANCHANG C4 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── CHILDREN/EDUCATION C5 MODULE ──
# Phase C — Module C5 — 5th house deep-dive (children) + Education (8 endpoints)
# Sources: BPHS Ch. 28, Saravali Ch. 35, Phaladeepika Ch. 9, Sarvartha Chintamani Ch. 14
# ════════════════════════════════════════════════════════════════════════

def _c5_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/children/profile")
def c5_children_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master children analysis — 5th house + Putra Dosha + D7 + conception timing synthesis."""
    return c5_handle_children_profile(_c5_birth_dict(inp))


@app.post("/astro/children/5th_house_analysis")
def c5_5th_house_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """5th house deep-dive — sign, lord, occupants, aspects."""
    return c5_handle_5th_house(_c5_birth_dict(inp))


@app.post("/astro/children/conception_timing")
def c5_conception_timing_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Conception-favorable dasha windows (Jupiter, 5th lord, Moon, Venus periods)."""
    return c5_handle_conception_timing(_c5_birth_dict(inp))


@app.post("/astro/children/d7_saptamsha")
def c5_d7_saptamsha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """D7 Saptamsha (children-specific divisional chart) synthesis."""
    return c5_handle_d7_saptamsha(_c5_birth_dict(inp))


@app.post("/astro/children/putra_dosha")
def c5_putra_dosha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Putra Dosha detection — 5 classical patterns + severity + remedies."""
    return c5_handle_putra_dosha(_c5_birth_dict(inp))


@app.post("/astro/education/profile")
def c5_education_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master education analysis — Mercury/Jupiter karakas + house synthesis + foreign-study."""
    return c5_handle_education_profile(_c5_birth_dict(inp))


@app.post("/astro/education/4th_5th_synthesis")
def c5_education_4th_5th_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """2/4/5/9 house education synthesis + Saraswati/Budhaditya yoga detection."""
    return c5_handle_4th_5th_synthesis(_c5_birth_dict(inp))


@app.post("/astro/education/foreign_study_yoga")
def c5_education_foreign_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Foreign education yoga detection — 6 classical patterns + strength rollup."""
    return c5_handle_foreign_study_yoga(_c5_birth_dict(inp))

# ── END CHILDREN/EDUCATION C5 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── KARMIC D1 MODULE ──
# Phase D — Module D1 — Past Life / Karmic (9 endpoints)
# Sources: Jaimini Upadesha Sutras, BPHS Ch. 24/32, Phaladeepika Ch. 6,
#          Garga Hora (Kaal Sarpa)
# ════════════════════════════════════════════════════════════════════════

def _karmic_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/karmic/profile")
def karmic_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master karmic synthesis — Karakamsha + AK + Ketu + Rahu + 12th + Kaal Sarpa + Upapada."""
    return karmic_handle_profile(_karmic_birth_dict(inp))


@app.post("/astro/karmic/karakamsha")
def karmic_karakamsha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """AK's D9 placement + Ishta Devata + soul's ultimate direction."""
    return karmic_handle_karakamsha(_karmic_birth_dict(inp))


@app.post("/astro/karmic/atmakaraka_journey")
def karmic_ak_journey_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Atmakaraka by sign — past-life soul lesson + intensity by degree."""
    return karmic_handle_atmakaraka_journey(_karmic_birth_dict(inp))


@app.post("/astro/karmic/ketu_past_life")
def karmic_ketu_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Ketu's sign + nakshatra — past-life karmic capacity and skill."""
    return karmic_handle_ketu_past_life(_karmic_birth_dict(inp))


@app.post("/astro/karmic/rahu_forward_karma")
def karmic_rahu_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Rahu's sign + house — forward developmental karma to embrace."""
    return karmic_handle_rahu_forward_karma(_karmic_birth_dict(inp))


@app.post("/astro/karmic/twelfth_house_moksha")
def karmic_moksha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """12th house occupants + lord — moksha/liberation karma path."""
    return karmic_handle_twelfth_house_moksha(_karmic_birth_dict(inp))


@app.post("/astro/karmic/kaal_sarpa")
def karmic_kaal_sarpa_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Kaal Sarpa dosha detection + classical 12-type identification + remedies."""
    return karmic_handle_kaal_sarpa(_karmic_birth_dict(inp))


@app.post("/astro/karmic/upapada_karma")
def karmic_upapada_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Upapada Lagna spouse karma reading per Jaimini Upadesha Sutras."""
    return karmic_handle_upapada_karma(_karmic_birth_dict(inp))


@app.post("/astro/karmic/arudha_padas")
def karmic_arudha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """All 12 Arudha Padas — worldly projections of each life-area."""
    return karmic_handle_arudha_padas(_karmic_birth_dict(inp))

# ── END KARMIC D1 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── TAROT D2 MODULE ──
# Phase D — Module D2 — Rider-Waite-Smith Tarot (10 endpoints)
# Source: RWS deck (1909, public domain); Waite's Pictorial Key (1910)
# Architecture: Birth-anchored deterministic RNG seeding; no chart casting
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _TarotBaseModel
from typing import Optional as _TarotOptional


class TarotBirthInput(_TarotBaseModel):
    """Optional birth — if absent, draws are fresh-random."""
    dob: _TarotOptional[str] = None
    time: _TarotOptional[str] = None
    fresh_shuffle: _TarotOptional[bool] = False


class TarotProfileInput(TarotBirthInput):
    pass


class TarotDailyInput(TarotBirthInput):
    target_date: _TarotOptional[str] = None  # YYYY-MM-DD, defaults to today


class TarotSpreadInput(TarotBirthInput):
    context: _TarotOptional[str] = ""


class TarotYearInput(TarotBirthInput):
    start_year: _TarotOptional[int] = None


class TarotDecisionInput(TarotBirthInput):
    decision_context: _TarotOptional[str] = ""


class TarotCardLookupInput(_TarotBaseModel):
    card_name: str


class TarotSuitInput(_TarotBaseModel):
    suit: _TarotOptional[str] = None


class TarotQuestionInput(TarotBirthInput):
    question_text: str


def _tarot_birth_to_dict(inp) -> _TarotOptional[dict]:
    """Convert TarotBirthInput to dict-or-None for engine."""
    if inp.dob is None:
        return None
    return {"dob": inp.dob, "time": inp.time or "12:00"}


@app.post("/astro/tarot/profile")
def tarot_profile_ep(inp: TarotProfileInput, _: str = Depends(verify_key)):
    """Master Tarot reading — birth-seeded Celtic Cross + daily card synthesis."""
    return tarot_handle_profile(_tarot_birth_to_dict(inp))


@app.post("/astro/tarot/daily_card")
def tarot_daily_ep(inp: TarotDailyInput, _: str = Depends(verify_key)):
    """Single card for the target date (defaults to today). Birth-seeded if DOB provided."""
    return tarot_handle_daily_card(_tarot_birth_to_dict(inp), inp.target_date,
                                    inp.fresh_shuffle or False)


@app.post("/astro/tarot/three_card")
def tarot_three_card_ep(inp: TarotSpreadInput, _: str = Depends(verify_key)):
    """Past/Present/Future three-card spread."""
    return tarot_handle_three_card(_tarot_birth_to_dict(inp), inp.context or "",
                                    inp.fresh_shuffle or False)


@app.post("/astro/tarot/celtic_cross")
def tarot_celtic_ep(inp: TarotSpreadInput, _: str = Depends(verify_key)):
    """Full 10-card Celtic Cross spread."""
    return tarot_handle_celtic_cross(_tarot_birth_to_dict(inp), inp.context or "",
                                      inp.fresh_shuffle or False)


@app.post("/astro/tarot/year_ahead")
def tarot_year_ahead_ep(inp: TarotYearInput, _: str = Depends(verify_key)):
    """12 cards, one per month, for the start_year (defaults to current year)."""
    return tarot_handle_year_ahead(_tarot_birth_to_dict(inp), inp.start_year,
                                    inp.fresh_shuffle or False)


@app.post("/astro/tarot/decision")
def tarot_decision_ep(inp: TarotDecisionInput, _: str = Depends(verify_key)):
    """5-card decision spread (situation/path-A/path-B/needed/recommendation)."""
    return tarot_handle_decision(_tarot_birth_to_dict(inp), inp.decision_context or "",
                                  inp.fresh_shuffle or False)


@app.post("/astro/tarot/card_meaning")
def tarot_card_meaning_ep(inp: TarotCardLookupInput, _: str = Depends(verify_key)):
    """Lookup a specific card by name (case-insensitive). E.g. 'The Fool', 'Ace of Cups'."""
    return tarot_handle_card_meaning(inp.card_name)


@app.post("/astro/tarot/suit_overview")
def tarot_suit_overview_ep(inp: TarotSuitInput, _: str = Depends(verify_key)):
    """Suit-level themes. If suit=None, returns overview of all 4 suits + Major Arcana."""
    return tarot_handle_suit_overview(inp.suit)


@app.post("/astro/tarot/shuffle")
def tarot_shuffle_ep(_: str = Depends(verify_key)):
    """Fresh non-deterministic full deck shuffle. Returns 78-card order."""
    return tarot_handle_shuffle()


@app.post("/astro/tarot/question_focused")
def tarot_question_focused_ep(inp: TarotQuestionInput, _: str = Depends(verify_key)):
    """3-card draw focused on user-provided question. Deterministic per question+birth."""
    return tarot_handle_question_focused(inp.question_text, _tarot_birth_to_dict(inp),
                                          inp.fresh_shuffle or False)

# ── END TAROT D2 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── NADI D5 MODULE ──
# Phase D — Module D5 — Nadi Astrology (6 endpoints)
# Sources: Brihat Samhita, Bhrigu Samhita, classical Nadi tradition
# ════════════════════════════════════════════════════════════════════════

def _nadi_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/nadi/profile")
def nadi_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master Nadi synthesis — Moon-pada + AK-nakshatra + Bhrigu + yogas."""
    return nadi_handle_profile(_nadi_birth_dict(inp))


@app.post("/astro/nadi/moon_pada_analysis")
def nadi_moon_pada_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Moon's nakshatra-pada deep-dive — deity/animal/varna/gana + Gandanta detection."""
    return nadi_handle_moon_pada_analysis(_nadi_birth_dict(inp))


@app.post("/astro/nadi/ak_nakshatra_signature")
def nadi_ak_signature_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Atmakaraka's nakshatra signature — soul's karmic-vibrational identity."""
    return nadi_handle_ak_nakshatra_signature(_nadi_birth_dict(inp))


@app.post("/astro/nadi/pada_attributes")
def nadi_pada_attributes_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Per-planet pada attributes — deity/yoni/varna/gana/body_part/dosha across all 9 planets."""
    return nadi_handle_pada_attributes(_nadi_birth_dict(inp))


@app.post("/astro/nadi/bhrigu_aspects")
def nadi_bhrigu_aspects_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Bhrigu Nadi 2nd-from-planet result patterns + classical Bhrigu principles."""
    return nadi_handle_bhrigu_aspects(_nadi_birth_dict(inp))


@app.post("/astro/nadi/nakshatra_yogas")
def nadi_yogas_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Classical nakshatra-level yogas — Gandanta, Mula, Ashlesha, Jyeshtha + Rahu-Ketu intensifiers."""
    return nadi_handle_nakshatra_yogas(_nadi_birth_dict(inp))

# ── END NADI D5 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── ICHING D3 MODULE ──
# Phase D — Module D3 — I-Ching (10 endpoints)
# Source: King Wen sequence (~1100 BCE, public domain); Wilhelm-Baynes 1924
# Architecture: Birth-anchored deterministic 3-coin casting via SHA-256 RNG
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _IchingBaseModel
from typing import Optional as _IchingOptional, List as _IchingList


class IchingBirthInput(_IchingBaseModel):
    """Optional birth — if absent, casts are fresh-random."""
    dob: _IchingOptional[str] = None
    fresh_shuffle: _IchingOptional[bool] = False


class IchingProfileInput(IchingBirthInput):
    pass


class IchingCastQuestionInput(IchingBirthInput):
    question_text: _IchingOptional[str] = ""


class IchingDailyInput(IchingBirthInput):
    target_date: _IchingOptional[str] = None


class IchingHexLookupInput(_IchingBaseModel):
    hexagram_number: int


class IchingTrigramInput(_IchingBaseModel):
    trigram_name: _IchingOptional[str] = None


class IchingChangingLinesInput(_IchingBaseModel):
    hexagram_number: int
    changing_line_numbers: _IchingList[int]


class IchingYearInput(IchingBirthInput):
    start_year: _IchingOptional[int] = None


class IchingDecisionInput(IchingBirthInput):
    decision_context: _IchingOptional[str] = ""


class IchingQuestionFocusedInput(IchingBirthInput):
    question_text: str


def _iching_birth_to_dict(inp) -> _IchingOptional[dict]:
    if inp.dob is None:
        return None
    return {"dob": inp.dob}


@app.post("/astro/iching/profile")
def iching_profile_ep(inp: IchingProfileInput, _: str = Depends(verify_key)):
    """Master I-Ching synthesis — daily + life-path hexagrams + headlines."""
    return iching_handle_profile(_iching_birth_to_dict(inp))


@app.post("/astro/iching/cast_question")
def iching_cast_question_ep(inp: IchingCastQuestionInput, _: str = Depends(verify_key)):
    """Cast for a specific question. Returns primary + changing lines + resultant."""
    return iching_handle_cast_question(inp.question_text or "",
                                        _iching_birth_to_dict(inp),
                                        inp.fresh_shuffle or False)


@app.post("/astro/iching/daily_hexagram")
def iching_daily_ep(inp: IchingDailyInput, _: str = Depends(verify_key)):
    """One hexagram for the target date (defaults to today). Birth-seeded."""
    return iching_handle_daily_hexagram(_iching_birth_to_dict(inp),
                                         inp.target_date,
                                         inp.fresh_shuffle or False)


@app.post("/astro/iching/hexagram_lookup")
def iching_hex_lookup_ep(inp: IchingHexLookupInput, _: str = Depends(verify_key)):
    """Lookup hexagram by King Wen number (1-64)."""
    return iching_handle_hexagram_lookup(inp.hexagram_number)


@app.post("/astro/iching/trigram_lookup")
def iching_trigram_lookup_ep(inp: IchingTrigramInput, _: str = Depends(verify_key)):
    """Lookup trigram by name (Heaven/Earth/Thunder/etc.) or get all 8."""
    return iching_handle_trigram_lookup(inp.trigram_name)


@app.post("/astro/iching/changing_lines_analysis")
def iching_changing_lines_ep(inp: IchingChangingLinesInput, _: str = Depends(verify_key)):
    """Interpret specific changing lines of a hexagram + compute resultant."""
    return iching_handle_changing_lines_analysis(inp.hexagram_number,
                                                  inp.changing_line_numbers)


@app.post("/astro/iching/year_ahead_hexagrams")
def iching_year_ahead_ep(inp: IchingYearInput, _: str = Depends(verify_key)):
    """12 hexagrams, one per month, for the start_year (defaults to current)."""
    return iching_handle_year_ahead_hexagrams(_iching_birth_to_dict(inp),
                                               inp.start_year,
                                               inp.fresh_shuffle or False)


@app.post("/astro/iching/decision_hexagram")
def iching_decision_ep(inp: IchingDecisionInput, _: str = Depends(verify_key)):
    """Decision reading — proceed/wait/mixed verdict based on hexagram archetype."""
    return iching_handle_decision_hexagram(inp.decision_context or "",
                                            _iching_birth_to_dict(inp),
                                            inp.fresh_shuffle or False)


@app.post("/astro/iching/shuffle_cast")
def iching_shuffle_ep(_: str = Depends(verify_key)):
    """Fresh non-deterministic cast — not reproducible."""
    return iching_handle_shuffle_cast()


@app.post("/astro/iching/question_focused")
def iching_question_focused_ep(inp: IchingQuestionFocusedInput, _: str = Depends(verify_key)):
    """Birth+question-seeded reading. Same question + same birth = same cast."""
    return iching_handle_question_focused(inp.question_text,
                                           _iching_birth_to_dict(inp),
                                           inp.fresh_shuffle or False)

# ── END ICHING D3 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── KP PRO D4 MODULE ──
# Phase D — Module D4 — Krishnamurti Paddhati (10 endpoints)
# Source: K.S. Krishnamurti "Krishnamurti Paddhati" (1971); Vimshottari from BPHS
# KP-lite: Lahiri ayanamsha + equal-house cusps (engine note)
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _KpBaseModel
from typing import Optional as _KpOptional, List as _KpList


class KpLongitudeInput(_KpBaseModel):
    longitude: float  # 0-360 zodiac longitude


class KpRulingPlanetsInput(_KpBaseModel):
    """At least one of birth OR query_moment+query_lat+query_lon required."""
    birth: _KpOptional[BirthInput] = None
    query_moment: _KpOptional[str] = None
    query_lat: _KpOptional[float] = None
    query_lon: _KpOptional[float] = None
    query_timezone: _KpOptional[str] = "Asia/Kolkata"


class KpHouseSignificatorInput(_KpBaseModel):
    birth: BirthInput
    house: int  # 1-12


class KpMomentInput(_KpBaseModel):
    query_moment: str  # ISO datetime
    query_lat: float
    query_lon: float
    query_timezone: _KpOptional[str] = "Asia/Kolkata"


class KpQueryHoroscopeInput(_KpBaseModel):
    birth: BirthInput
    query_moment: str
    query_lat: float
    query_lon: float
    question_house: int  # 1-12
    query_timezone: _KpOptional[str] = "Asia/Kolkata"


def _kp_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/kp/profile")
def kp_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master KP-lite synthesis — Lagna sub-lord + planet sub-lords + cusps + RPs + significators."""
    return kp_handle_profile(_kp_birth_dict(inp))


@app.post("/astro/kp/sub_lord_for_longitude")
def kp_sub_lord_lon_ep(inp: KpLongitudeInput, _: str = Depends(verify_key)):
    """Compute star/sub/sub-sub lord for ANY zodiac longitude (0-360)."""
    return kp_handle_sub_lord_for_longitude(inp.longitude)


@app.post("/astro/kp/planet_sub_lords")
def kp_planet_sub_lords_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Sub-lords for all 9 planets in the chart."""
    return kp_handle_planet_sub_lords(_kp_birth_dict(inp))


@app.post("/astro/kp/lagna_sub_lord")
def kp_lagna_sl_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Lagna sub-lord — the single most important KP indicator."""
    return kp_handle_lagna_sub_lord(_kp_birth_dict(inp))


@app.post("/astro/kp/cuspal_sub_lords")
def kp_cuspal_sl_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Sub-lords for all 12 house cusps (equal-house from Lagna)."""
    return kp_handle_cuspal_sub_lords(_kp_birth_dict(inp))


@app.post("/astro/kp/ruling_planets")
def kp_ruling_planets_ep(inp: KpRulingPlanetsInput, _: str = Depends(verify_key)):
    """5 KP Ruling Planets at birth, at query moment, or both."""
    birth_dict = _kp_birth_dict(inp.birth) if inp.birth else None
    return kp_handle_ruling_planets(
        birth=birth_dict,
        query_moment=inp.query_moment,
        query_lat=inp.query_lat,
        query_lon=inp.query_lon,
        query_timezone=inp.query_timezone or "Asia/Kolkata",
    )


@app.post("/astro/kp/significators")
def kp_significators_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Each planet's signified houses per KP hierarchy."""
    return kp_handle_significators(_kp_birth_dict(inp))


@app.post("/astro/kp/house_significators")
def kp_house_sig_ep(inp: KpHouseSignificatorInput, _: str = Depends(verify_key)):
    """Which planets signify a given house (1-12) at all 4 KP levels."""
    return kp_handle_house_significators(_kp_birth_dict(inp.birth), inp.house)


@app.post("/astro/kp/moment_lookup")
def kp_moment_ep(inp: KpMomentInput, _: str = Depends(verify_key)):
    """KP analysis for arbitrary moment — RPs + Lagna sub-lord at that moment."""
    return kp_handle_moment_lookup(
        inp.query_moment, inp.query_lat, inp.query_lon,
        inp.query_timezone or "Asia/Kolkata",
    )


@app.post("/astro/kp/query_horoscope")
def kp_query_horoscope_ep(inp: KpQueryHoroscopeInput, _: str = Depends(verify_key)):
    """KP yes/no for a question — compare birth significators of question_house with current RPs."""
    return kp_handle_query_horoscope(
        _kp_birth_dict(inp.birth),
        inp.query_moment, inp.query_lat, inp.query_lon,
        inp.question_house,
        inp.query_timezone or "Asia/Kolkata",
    )

# ── END KP PRO D4 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── ASTROCARTOGRAPHY D6 MODULE ──
# Phase D — Module D6 — Astrocartography / Relocation (6 endpoints)
# Source: Jim Lewis "Astro*Carto*Graphy" (1976) + classical relocation (Vettius Valens)
# Uses Swiss Ephemeris 2.10 directly for RA/Dec/GMST/ARMC.
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _AcgBaseModel
from typing import Optional as _AcgOptional, List as _AcgList


class AcgRelocateInput(_AcgBaseModel):
    birth: BirthInput
    new_lat: float
    new_lon: float
    new_timezone: _AcgOptional[str] = None
    location_name: _AcgOptional[str] = None


class AcgLocationItem(_AcgBaseModel):
    name: _AcgOptional[str] = None
    lat: float
    lon: float
    timezone: _AcgOptional[str] = None


class AcgLocationCompareInput(_AcgBaseModel):
    birth: BirthInput
    locations: _AcgList[AcgLocationItem]


class AcgOptimalInput(_AcgBaseModel):
    birth: BirthInput
    theme: str  # career_success, wealth_finance, love_relationships, spiritual_growth, etc.
    top_n: _AcgOptional[int] = 10
    region: _AcgOptional[str] = None


def _acg_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/astrocartography/profile")
def acg_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master astrocartography synthesis — all 36 lines + parans + headlines."""
    return acg_handle_profile(_acg_birth_dict(inp))


@app.post("/astro/astrocartography/planetary_lines")
def acg_planetary_lines_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """All 36 planetary lines: 4 lines × 9 planets (MC/IC meridians + AC/DC latitude-curves)."""
    return acg_handle_planetary_lines(_acg_birth_dict(inp))


@app.post("/astro/astrocartography/relocate_chart")
def acg_relocate_ep(inp: AcgRelocateInput, _: str = Depends(verify_key)):
    """Recast chart at new location. Returns relocated lagna + planet-house shifts vs birth chart."""
    return acg_handle_relocate_chart(
        _acg_birth_dict(inp.birth),
        inp.new_lat, inp.new_lon,
        inp.new_timezone, inp.location_name,
    )


@app.post("/astro/astrocartography/local_space")
def acg_local_space_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Directional azimuths from birthplace to major destinations (~70 cities)."""
    return acg_handle_local_space(_acg_birth_dict(inp))


@app.post("/astro/astrocartography/location_compare")
def acg_location_compare_ep(inp: AcgLocationCompareInput, _: str = Depends(verify_key)):
    """Compare angular-planet placements across multiple locations."""
    locs = [{"name": l.name, "lat": l.lat, "lon": l.lon, "timezone": l.timezone}
            for l in inp.locations]
    return acg_handle_location_compare(_acg_birth_dict(inp.birth), locs)


@app.post("/astro/astrocartography/optimal_locations")
def acg_optimal_ep(inp: AcgOptimalInput, _: str = Depends(verify_key)):
    """Recommend top cities for a given life-theme (career_success / love_relationships / spiritual_growth / etc.)."""
    return acg_handle_optimal_locations(
        _acg_birth_dict(inp.birth),
        inp.theme, inp.top_n or 10, inp.region,
    )

# ── END ASTROCARTOGRAPHY D6 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── TRANSIT ASPECTS U3 MODULE ──
# Phase D — Upgrade 3 — Applying/separating transit aspects + exact-aspect calendar
# Source: Ptolemy "Tetrabiblos" + BPHS Ch. 26 + Swiss Eph 2.10
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _TxaBaseModel
from typing import Optional as _TxaOptional


class TxaApplyingInput(_TxaBaseModel):
    birth: BirthInput
    moment: _TxaOptional[str] = None  # ISO datetime; defaults to now UTC
    tradition: _TxaOptional[str] = "both"  # "western", "vedic", or "both"
    min_orb: _TxaOptional[float] = 0.0
    max_orb: _TxaOptional[float] = 8.0


class TxaUpcomingInput(_TxaBaseModel):
    birth: BirthInput
    days_ahead: _TxaOptional[int] = 30
    moment_start: _TxaOptional[str] = None
    tradition: _TxaOptional[str] = "western"
    step_hours: _TxaOptional[float] = 6.0


def _txa_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/transit/applying_aspects_to_natal")
def txa_applying_ep(inp: TxaApplyingInput, _: str = Depends(verify_key)):
    """Currently-active transit aspects to natal planets with applying/separating + orb."""
    return txa_handle_applying(
        _txa_birth_dict(inp.birth),
        moment=inp.moment,
        tradition=inp.tradition or "both",
        min_orb=inp.min_orb if inp.min_orb is not None else 0.0,
        max_orb=inp.max_orb if inp.max_orb is not None else 8.0,
    )


@app.post("/astro/transit/upcoming_exact_aspects")
def txa_upcoming_ep(inp: TxaUpcomingInput, _: str = Depends(verify_key)):
    """Forward-step Swiss Eph to find upcoming exact transit-to-natal aspects."""
    return txa_handle_upcoming(
        _txa_birth_dict(inp.birth),
        days_ahead=inp.days_ahead or 30,
        moment_start=inp.moment_start,
        tradition=inp.tradition or "western",
        step_hours=inp.step_hours or 6.0,
    )

# ── END TRANSIT ASPECTS U3 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── RAMAL E1 MODULE ──
# Phase E — Module E1 — Ramal Shastra divination (11 endpoints)
# Source: Classical Indian Ramal (Zaycha system) — distinct from Western Geomancy
# Port of myRamal repo (numiveda/myRamal) — pure computational engine
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _RamalBaseModel
from typing import Optional as _RamalOptional, List as _RamalList


class RamalThrowInput(_RamalBaseModel):
    throw_values: _RamalList[int]  # 4 integers


class RamalMotherKeysInput(_RamalBaseModel):
    mother_keys: _RamalList[str]  # 4 row-pattern keys


class RamalThrowsInput(_RamalBaseModel):
    throws: _RamalList[_RamalList[int]]  # 4 throws × 4 integers each


class RamalFigureLookupInput(_RamalBaseModel):
    key: _RamalOptional[str] = None
    number: _RamalOptional[int] = None


class RamalQuestionInput(_RamalBaseModel):
    throws: _RamalList[_RamalList[int]]  # 4 throws × 4 integers
    question: str
    domain: _RamalOptional[str] = "other"
    first_name: _RamalOptional[str] = "Querent"


@app.post("/astro/ramal/profile")
def ramal_profile_ep(inp: RamalThrowsInput, _: str = Depends(verify_key)):
    """Master Ramal profile — 15-house chart + all 4 classical special rules applied."""
    return ramal_handle_profile(inp.throws)


@app.post("/astro/ramal/cast_chart")
def ramal_cast_chart_ep(inp: RamalMotherKeysInput, _: str = Depends(verify_key)):
    """4 Mother keys (e.g. 'odd-even-even-odd') → complete 15-house chart."""
    return ramal_handle_cast_chart(inp.mother_keys)


@app.post("/astro/ramal/cast_from_throws")
def ramal_cast_from_throws_ep(inp: RamalThrowsInput, _: str = Depends(verify_key)):
    """4 throws × 4 row values each → 4 Mothers → 15-house chart."""
    return ramal_handle_cast_from_throws(inp.throws)


@app.post("/astro/ramal/figure_from_throw")
def ramal_figure_from_throw_ep(inp: RamalThrowInput, _: str = Depends(verify_key)):
    """Single throw of 4 row values → 1 figure with attributes."""
    return ramal_handle_figure_from_throw(inp.throw_values)


@app.post("/astro/ramal/figure_lookup")
def ramal_figure_lookup_ep(inp: RamalFigureLookupInput, _: str = Depends(verify_key)):
    """Look up a figure by row-pattern key OR by classical number 1-16."""
    return ramal_handle_figure_lookup(key=inp.key, number=inp.number)


@app.post("/astro/ramal/figures_catalog")
def ramal_figures_catalog_ep(_: str = Depends(verify_key)):
    """Return all 16 figures + categories + natures."""
    return ramal_handle_figures_catalog()


@app.post("/astro/ramal/house_domains")
def ramal_house_domains_ep(_: str = Depends(verify_key)):
    """Return all 15 house meanings + domain→house mapping."""
    return ramal_handle_house_domains()


@app.post("/astro/ramal/hope_formula")
def ramal_hope_formula_ep(inp: RamalMotherKeysInput, _: str = Depends(verify_key)):
    """Triple Prastara for H11 hopes-domain."""
    return ramal_handle_hope_formula(inp.mother_keys)


@app.post("/astro/ramal/check_theft")
def ramal_check_theft_ep(inp: RamalMotherKeysInput, _: str = Depends(verify_key)):
    """Scan for theft indicators."""
    return ramal_handle_check_theft(inp.mother_keys)


@app.post("/astro/ramal/check_captivity")
def ramal_check_captivity_ep(inp: RamalMotherKeysInput, _: str = Depends(verify_key)):
    """Check H12/H15 captivity exception."""
    return ramal_handle_check_captivity(inp.mother_keys)


@app.post("/astro/ramal/dot_count")
def ramal_dot_count_ep(inp: RamalMotherKeysInput, _: str = Depends(verify_key)):
    """Bindu count → life/death verdict."""
    return ramal_handle_dot_count(inp.mother_keys)


@app.post("/astro/ramal/question_reading")
def ramal_question_reading_ep(inp: RamalQuestionInput, _: str = Depends(verify_key)):
    """Question-focused master: cast chart + apply domain rule + AI prompt context."""
    return ramal_handle_question_reading(
        throws=inp.throws,
        question=inp.question,
        domain=inp.domain or "other",
        first_name=inp.first_name or "Querent",
    )

# ── END RAMAL E1 MODULE ──


# ════════════════════════════════════════════════════════════════════════
# ── MOKSHAPATAM E2 MODULE ──
# Phase E — Module E2 — Moksha Patam karmic journey analysis (9 endpoints)
# Source: Classical Indian Moksha Patam (72-square soul-evolution game)
# Port of myMokshaPatam repo (numiveda/myMokshaPatam) — analysis-only architecture
# Client owns game loop; engine analyzes completed journey deterministically.
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _MpBaseModel, Field as _MpField
from typing import Optional as _MpOptional, List as _MpList, Any as _MpAny, Dict as _MpDict


class MpRollItem(_MpBaseModel):
    roll_number: _MpOptional[int] = None
    dice:        _MpOptional[int] = None
    age_before:  _MpOptional[int] = None
    age_after:   _MpOptional[int] = None
    house_after: int
    snake_hit:   _MpOptional[bool] = False
    snake_from:  _MpOptional[int] = None
    snake_to:    _MpOptional[int] = None
    ladder_hit:  _MpOptional[bool] = False
    ladder_from: _MpOptional[int] = None
    ladder_to:   _MpOptional[int] = None


class MpPastLifeWeightInput(_MpBaseModel):
    phase1_roll_count: int


class MpChakraAnalysisInput(_MpBaseModel):
    journey: _MpList[_MpDict[str, _MpAny]]


class MpCumulativePatternInput(_MpBaseModel):
    journey:           _MpList[_MpDict[str, _MpAny]]
    phase1_roll_count: int
    end_condition:     str  # "house_68" or "age_80"
    final_house:       int


class MpJourneyNarrativeInput(_MpBaseModel):
    journey:           _MpList[_MpDict[str, _MpAny]]
    phase1_roll_count: _MpOptional[int] = 0


class MpChartDataInput(_MpBaseModel):
    journey: _MpList[_MpDict[str, _MpAny]]


class MpValidateInput(_MpBaseModel):
    phase1_roll_count: int
    end_condition:     str
    final_house:       int
    final_age:         _MpOptional[int] = None
    total_rolls:       _MpOptional[int] = None
    journey:           _MpList[_MpDict[str, _MpAny]]


class MpProfileInput(_MpBaseModel):
    journey:           _MpList[_MpDict[str, _MpAny]]
    phase1_roll_count: int
    end_condition:     str
    final_house:       int
    final_age:         int
    total_rolls:       _MpOptional[int] = None


@app.post("/astro/mokshapatam/profile")
def mp_profile_ep(inp: MpProfileInput, _: str = Depends(verify_key)):
    """MASTER: full Moksha Patam analysis (validation + chakra + pattern + narrative + chart)."""
    return mp_handle_profile(
        journey=inp.journey,
        phase1_roll_count=inp.phase1_roll_count,
        end_condition=inp.end_condition,
        final_house=inp.final_house,
        final_age=inp.final_age,
        total_rolls=inp.total_rolls,
    )


@app.post("/astro/mokshapatam/board_catalog")
def mp_board_catalog_ep(_: str = Depends(verify_key)):
    """All 72 houses with attributes (chakra, type, snake_to, ladder_to, meaning)."""
    return mp_handle_board_catalog()


@app.post("/astro/mokshapatam/chakra_catalog")
def mp_chakra_catalog_ep(_: str = Depends(verify_key)):
    """All 8 chakras with theme + house assignments."""
    return mp_handle_chakra_catalog()


@app.post("/astro/mokshapatam/past_life_weight")
def mp_past_life_weight_ep(inp: MpPastLifeWeightInput, _: str = Depends(verify_key)):
    """Phase 1 roll count → karma label (very_clear/light/moderate/significant/heavy)."""
    return mp_handle_past_life_weight(inp.phase1_roll_count)


@app.post("/astro/mokshapatam/chakra_analysis")
def mp_chakra_analysis_ep(inp: MpChakraAnalysisInput, _: str = Depends(verify_key)):
    """Per-chakra time/virtue/vice/neutral breakdown of a completed journey."""
    return mp_handle_chakra_analysis(inp.journey)


@app.post("/astro/mokshapatam/cumulative_pattern")
def mp_cumulative_pattern_ep(inp: MpCumulativePatternInput, _: str = Depends(verify_key)):
    """Dominant snake, dominant ladder, trajectory, chakra-most-time, karmic label."""
    return mp_handle_cumulative_pattern(
        journey=inp.journey,
        phase1_roll_count=inp.phase1_roll_count,
        end_condition=inp.end_condition,
        final_house=inp.final_house,
    )


@app.post("/astro/mokshapatam/journey_narrative")
def mp_journey_narrative_ep(inp: MpJourneyNarrativeInput, _: str = Depends(verify_key)):
    """Text narrative of full journey for AI consumption."""
    return mp_handle_journey_narrative(inp.journey, inp.phase1_roll_count or 0)


@app.post("/astro/mokshapatam/chart_data")
def mp_chart_data_ep(inp: MpChartDataInput, _: str = Depends(verify_key)):
    """3-panel visualization data: chakra_time, virtue_vs_vice, journey_arc."""
    return mp_handle_chart_data(inp.journey)


@app.post("/astro/mokshapatam/validate_journey")
def mp_validate_journey_ep(inp: MpValidateInput, _: str = Depends(verify_key)):
    """Verify journey structural consistency (houses valid, ages monotonic, snake/ladder match catalog)."""
    journey_input = {
        "phase1_roll_count": inp.phase1_roll_count,
        "end_condition":     inp.end_condition,
        "final_house":       inp.final_house,
        "final_age":         inp.final_age,
        "total_rolls":       inp.total_rolls,
        "journey":           inp.journey,
    }
    return mp_handle_validate_journey(journey_input)

# ── END MOKSHAPATAM E2 MODULE ──



# ── F1a: /astro/relationship/* (2026-05-17) ──

@app.post("/astro/relationship/friendship", dependencies=[Depends(verify_key)])
def relationship_friendship(r: RelationshipInput):
    """
    Friendship compatibility — emotional + intellectual rapport.
    Frame: 3rd house (peers), 11th house (gains/friends); karakas Mercury, Moon, Venus.
    Returns multi-stream evidence (koot + moon-synastry + house-overlay + Mercury-Moon cross)
    with composite score 0-100 and classical citations.
    """
    try:
        p1 = {"dob": r.person1.dob, "time": r.person1.time,
              "lat": r.person1.lat, "lon": r.person1.lon,
              "timezone": r.person1.timezone}
        p2 = {"dob": r.person2.dob, "time": r.person2.time,
              "lat": r.person2.lat, "lon": r.person2.lon,
              "timezone": r.person2.timezone}
        result = rel_handle_friendship(p1, p2, role1=r.role1, role2=r.role2)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/relationship/mentor", dependencies=[Depends(verify_key)])
def relationship_mentor(r: RelationshipInput):
    """
    Mentor / Guru-Shishya compatibility.
    Frame: 5H (disciple from guru) / 9H (guru from disciple); karaka Jupiter, AK resonance.
    Roles (optional): role1/role2 in {"mentor","mentee"}; if absent, returns both directional readings.
    Multi-stream evidence with composite score 0-100 and classical citations.
    """
    try:
        p1 = {"dob": r.person1.dob, "time": r.person1.time,
              "lat": r.person1.lat, "lon": r.person1.lon,
              "timezone": r.person1.timezone}
        p2 = {"dob": r.person2.dob, "time": r.person2.time,
              "lat": r.person2.lat, "lon": r.person2.lon,
              "timezone": r.person2.timezone}
        result = rel_handle_mentor(p1, p2, role1=r.role1, role2=r.role2)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/relationship/family", dependencies=[Depends(verify_key)])
def relationship_family(r: RelationshipInput):
    """
    Family compatibility — parent-child, sibling, or extended.
    Subtype (optional, defaults to "extended"):
        "parent-child" → 4/9/10/5 houses; Matri/Pitri/Putra karakas
        "sibling"      → 3/11 houses;     Bhratrikaraka
        "extended"     → all family houses + all 4 family karakas
    Multi-stream evidence + composite score 0-100 + classical citations.
    """
    try:
        p1 = {"dob": r.person1.dob, "time": r.person1.time,
              "lat": r.person1.lat, "lon": r.person1.lon,
              "timezone": r.person1.timezone}
        p2 = {"dob": r.person2.dob, "time": r.person2.time,
              "lat": r.person2.lat, "lon": r.person2.lon,
              "timezone": r.person2.timezone}
        result = rel_handle_family(p1, p2,
                                    role1=r.role1, role2=r.role2,
                                    subtype=r.subtype)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))



# ── U10 fix-1: /astro/nakshatra/compatibility_from_birth ──
class NakshatraCompatFromBirthInput(BaseModel):
    person1: BirthInput
    person2: BirthInput


@app.post("/astro/nakshatra/compatibility_from_birth")
async def nakshatra_compatibility_from_birth(
    inp: NakshatraCompatFromBirthInput,
    _: str = Depends(verify_key),
):
    """
    BirthInput-shaped variant of /astro/nakshatra/compatibility.

    Casts both charts, extracts each native's Moon nakshatra, and runs
    the same 4-factor (Gana/Nadi/Yoni/Varna) classical analysis.
    Lets callers use the standard person1/person2 birth payload that
    every other compatibility endpoint accepts, instead of pre-computing
    nakshatra names.

    The original /astro/nakshatra/compatibility (with nak1/nak2 string
    inputs) remains available and unchanged.
    """
    try:
        from nakshatra import analyze_compatibility
        c1 = cast_chart(
            dob=inp.person1.dob, time=inp.person1.time,
            lat=inp.person1.lat, lon=inp.person1.lon,
            timezone=inp.person1.timezone,
        )
        c2 = cast_chart(
            dob=inp.person2.dob, time=inp.person2.time,
            lat=inp.person2.lat, lon=inp.person2.lon,
            timezone=inp.person2.timezone,
        )
        nak1 = c1["planets"]["Moon"].get("nakshatra")
        nak2 = c2["planets"]["Moon"].get("nakshatra")
        if not (nak1 and nak2):
            raise HTTPException(
                status_code=500,
                detail=(f"Could not extract Moon nakshatra from one or both "
                        f"charts (got: p1={nak1!r}, p2={nak2!r})"),
            )
        result = analyze_compatibility(nak1, nak2)
        return {
            "success": True,
            "person1_moon_nakshatra": nak1,
            "person2_moon_nakshatra": nak2,
            "data": result,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Nakshatra-from-birth compatibility failed: {e}",
        )



# ── F1b: /astro/relationship/* (business + colleague + matrix) ──

class BirthInputWithLabel(BaseModel):
    """A birth input that ALSO carries a human-readable label for the matrix endpoint."""
    label: Optional[str] = None
    dob: str
    time: str
    lat: float
    lon: float
    timezone: str = "Asia/Kolkata"


class CompatibilityMatrixInput(BaseModel):
    """Native vs N others, ranked by composite compatibility per relationship_type."""
    native: BirthInput
    others: list  # list of BirthInputWithLabel-shaped dicts (pydantic validates loosely; handler is defensive)
    relationship_type: str  # friendship | mentor | family | business_partner | colleague
    subtype: Optional[str] = None       # family-only: parent-child|sibling|extended
    max_others: Optional[int] = 20      # clamped server-side to MATRIX_HARD_CEILING (50)


@app.post("/astro/relationship/business_partner", dependencies=[Depends(verify_key)])
def relationship_business_partner(r: RelationshipInput):
    """
    Business Partner / Co-founder compatibility — Arth+Karma alignment.
    Frame: 7H/10H/11H, karakas Mercury+Jupiter+AmK, D10 cross-overlay.
    Multi-stream evidence + composite score 0-100 + classical citations.
    """
    try:
        p1 = {"dob": r.person1.dob, "time": r.person1.time,
              "lat": r.person1.lat, "lon": r.person1.lon,
              "timezone": r.person1.timezone}
        p2 = {"dob": r.person2.dob, "time": r.person2.time,
              "lat": r.person2.lat, "lon": r.person2.lon,
              "timezone": r.person2.timezone}
        return rel_handle_business_partner(p1, p2, role1=r.role1, role2=r.role2)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/relationship/colleague", dependencies=[Depends(verify_key)])
def relationship_colleague(r: RelationshipInput):
    """
    Workplace colleague compatibility — operational fit.
    Frame: 6H/10H/3H, karakas Saturn+Mars+Mercury, Saturn-Mars synastry signal.
    Multi-stream evidence + composite score 0-100 + classical citations.
    """
    try:
        p1 = {"dob": r.person1.dob, "time": r.person1.time,
              "lat": r.person1.lat, "lon": r.person1.lon,
              "timezone": r.person1.timezone}
        p2 = {"dob": r.person2.dob, "time": r.person2.time,
              "lat": r.person2.lat, "lon": r.person2.lon,
              "timezone": r.person2.timezone}
        return rel_handle_colleague(p1, p2, role1=r.role1, role2=r.role2)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/relationship/compatibility_matrix", dependencies=[Depends(verify_key)])
def relationship_compatibility_matrix(m: CompatibilityMatrixInput):
    """
    Compatibility matrix — rank N candidates against one native.

    Works for ALL 5 relationship types (friendship, mentor, family,
    business_partner, colleague). Family endpoint accepts an optional
    `subtype` ("parent-child" | "sibling" | "extended").

    max_others is clamped server-side to MATRIX_HARD_CEILING (currently 50).
    """
    try:
        native = {"dob": m.native.dob, "time": m.native.time,
                  "lat": m.native.lat, "lon": m.native.lon,
                  "timezone": m.native.timezone}
        # m.others is List[dict] — pass through directly; handler is defensive
        return rel_handle_compatibility_matrix(
            native=native,
            others=m.others,
            relationship_type=m.relationship_type,
            subtype=m.subtype,
            max_others=m.max_others if m.max_others is not None else 20,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))



# ── F2a: /astro/eclipse/* endpoints (2026-05-17) ──

@app.post("/astro/eclipse/natal_eclipses", dependencies=[Depends(verify_key)])
def eclipse_natal_eclipses(e: EclipseInput):
    """
    Solar+lunar eclipses around birth (configurable window).
    Default ±30 days, max ±180 days. Classical interaction analysis vs
    natal lagna/Moon/Sun: lagna-grahan, chandra-grahan, surya-grahan triggers,
    plus BPHS Ch.25 house-from-Moon interpretation.
    """
    try:
        birth_dict = {
            "dob": e.birth.dob, "time": e.birth.time,
            "lat": e.birth.lat, "lon": e.birth.lon,
            "timezone": e.birth.timezone,
        }
        wd = e.window_days if e.window_days is not None else ECL_NATAL_WINDOW_DEFAULT
        return ecl_handle_natal_eclipses(birth_dict, window_days=wd)
    except Exception as ex:
        raise HTTPException(status_code=400, detail=str(ex))


@app.post("/astro/eclipse/upcoming", dependencies=[Depends(verify_key)])
def eclipse_upcoming(e: EclipseInput):
    """
    Eclipses ahead with personal-impact analysis.
    Default 5 years ahead, max 100 years. Each eclipse annotated with
    natal interaction (distance from lagna/Moon/Sun, BPHS house-from-Moon).
    """
    try:
        birth_dict = {
            "dob": e.birth.dob, "time": e.birth.time,
            "lat": e.birth.lat, "lon": e.birth.lon,
            "timezone": e.birth.timezone,
        }
        ya = e.years_ahead if e.years_ahead is not None else ECL_UPCOMING_YEARS_DEFAULT
        return ecl_handle_upcoming_eclipses(
            birth_dict, query_date=e.query_date, years_ahead=ya)
    except Exception as ex:
        raise HTTPException(status_code=400, detail=str(ex))


@app.post("/astro/eclipse/sade_sati_extension", dependencies=[Depends(verify_key)])
def eclipse_sade_sati_extension(e: EclipseInput):
    """
    Saturn-eclipse intersection during Sade Sati.

    Layers eclipse computation over the rich Sade Sati handler. Lists eclipses
    within ±2 years of query_date and marks those where Saturn (at eclipse
    moment) falls in the 12th/1st/2nd from natal Moon — the active Sade Sati
    zone, classically signifying intensification of the Sade Sati phase.
    """
    try:
        birth_dict = {
            "dob": e.birth.dob, "time": e.birth.time,
            "lat": e.birth.lat, "lon": e.birth.lon,
            "timezone": e.birth.timezone,
        }
        return ecl_handle_sade_sati_extension(
            birth_dict, query_date=e.query_date)
    except Exception as ex:
        raise HTTPException(status_code=400, detail=str(ex))



# ── F2b: /astro/pitra_dosha/* endpoints (2026-05-17) ──

@app.post("/astro/pitra_dosha/profile", dependencies=[Depends(verify_key)])
def pitra_dosha_profile(p: PitraDoshaInput):
    """
    Detect classical Pitra Dosha signatures in a natal chart.

    Checks: Sun-Rahu/Ketu conjunction, Sun-Saturn malefic combination,
    Rahu/Ketu/Saturn aspects on Sun, weak Sun dignity, 9H lord in dusthana,
    9L weak/combust, Surya grahan (natal eclipse on Sun — reuses F2a).

    Returns verdict (STRONG/MODERATE/MILD/ABSENT) with each signature's
    severity (1-3), evidence text, and classical source citation.
    """
    try:
        birth_dict = {
            "dob": p.birth.dob, "time": p.birth.time,
            "lat": p.birth.lat, "lon": p.birth.lon,
            "timezone": p.birth.timezone,
        }
        return pd_handle_profile(birth_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pitra_dosha/intensity", dependencies=[Depends(verify_key)])
def pitra_dosha_intensity(p: PitraDoshaInput):
    """
    Score Pitra Dosha intensity 0-100 + which signatures contributed.

    Severity-weighted scoring (severity 3 = 30 pts, 2 = 15, 1 = 5; capped at 100).
    Returns banded verdict (HIGH/MODERATE/MILD/ABSENT) + top contributors with
    classical citations.
    """
    try:
        birth_dict = {
            "dob": p.birth.dob, "time": p.birth.time,
            "lat": p.birth.lat, "lon": p.birth.lon,
            "timezone": p.birth.timezone,
        }
        return pd_handle_intensity(birth_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pitra_dosha/remedies_timing", dependencies=[Depends(verify_key)])
def pitra_dosha_remedies_timing(p: PitraDoshaInput):
    """
    Pitru Paksha windows + classical tradition (NOT prescription).

    Computes annual Pitru Paksha (Krishna Paksha of Bhadrapada-Ashvin) windows
    for the next N years (configurable, default 5, max 50). Includes Mahalaya
    Amavasya identification, active dasha context, and classical remedies
    described as 'tradition' with citations.
    """
    try:
        birth_dict = {
            "dob": p.birth.dob, "time": p.birth.time,
            "lat": p.birth.lat, "lon": p.birth.lon,
            "timezone": p.birth.timezone,
        }
        ya = p.years_ahead if p.years_ahead is not None else PD_MAHALAYA_YEARS_DEFAULT
        return pd_handle_remedies_timing(
            birth_dict, query_date=p.query_date, years_ahead=ya)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))



# ── F3: /astro/strength/* endpoints (2026-05-18) ──

@app.post("/astro/strength/vimshopaka_bala", dependencies=[Depends(verify_key)])
def strength_vimshopaka_bala(s: StrengthInput):
    """
    Vimshopaka Bala (BPHS Ch. 35) — 16-fold combined strength across Shodasavarga.

    For each planet (Sun-Saturn), computes weighted dignity score across all
    16 divisional charts (D1 through D60). Returns per-planet breakdown +
    classical interpretation band (purna/uttama/madhyama/alpa/nirbala).
    """
    try:
        birth_dict = {
            "dob": s.birth.dob, "time": s.birth.time,
            "lat": s.birth.lat, "lon": s.birth.lon,
            "timezone": s.birth.timezone,
        }
        return st_handle_vimshopaka_bala(birth_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/strength/planetary_summary", dependencies=[Depends(verify_key)])
def strength_planetary_summary(s: StrengthInput):
    """
    Synthesis: Shadbala + Vimshopaka + Ishta/Kashta phala per planet.

    Returns functional strength verdict (FULLY STRONG / SHADBALA STRONG /
    VIMSHOPAKA STRONG / MIDDLING / WEAK) with classical narrative and
    actionable recommendation. Identifies which planets carry the chart
    and which need remediation.
    """
    try:
        birth_dict = {
            "dob": s.birth.dob, "time": s.birth.time,
            "lat": s.birth.lat, "lon": s.birth.lon,
            "timezone": s.birth.timezone,
        }
        return st_handle_planetary_summary(birth_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/strength/comprehensive", dependencies=[Depends(verify_key)])
def strength_comprehensive(s: StrengthInput):
    """
    All-in-one strength report: Shadbala + Vimshopaka + Ishta/Kashta + dasha context.

    Most detailed strength endpoint. Includes:
      - Full 6-component Shadbala per planet
      - 16-fold Vimshopaka with per-varga breakdown
      - Ishta/Kashta phala dispositions
      - Functional strength verdicts
      - Active dasha (MD + AD) strength context
      - Strongest/weakest planet ranking
    """
    try:
        birth_dict = {
            "dob": s.birth.dob, "time": s.birth.time,
            "lat": s.birth.lat, "lon": s.birth.lon,
            "timezone": s.birth.timezone,
        }
        return st_handle_comprehensive(birth_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))



# ── F9: /astro/birthday/* endpoints (2026-05-18) ──

@app.post("/astro/birthday/quick", dependencies=[Depends(verify_key)])
def birthday_quick(b: BirthdayInput):
    """
    Full daily astrological snapshot for the native on query_date.

    Returns: panchang, active dasha (5 levels), tara state, transit highlights
    (Saturn/Jupiter/Rahu/Ketu houses from natal), auspicious + inauspicious
    daily yogas (Sarvartha Siddhi, Amrit Siddhi, Vish, Mrityu, Dwi/Tripushkar,
    Guru Pushya, Ravi Pushya), mood, and headline.

    query_date defaults to today. Accepts any YYYY-MM-DD for past/future queries.
    """
    try:
        birth_dict = {
            "dob": b.birth.dob, "time": b.birth.time,
            "lat": b.birth.lat, "lon": b.birth.lon,
            "timezone": b.birth.timezone,
        }
        return bq_handle_quick(birth_dict, query_date=b.query_date)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/birthday/headline", dependencies=[Depends(verify_key)])
def birthday_headline(b: BirthdayInput):
    """
    One-sentence summary of the day. Trimmed response for WhatsApp/push messages.

    Returns: {query_date, headline, mood, mood_emoji, key_signal}
    """
    try:
        birth_dict = {
            "dob": b.birth.dob, "time": b.birth.time,
            "lat": b.birth.lat, "lon": b.birth.lon,
            "timezone": b.birth.timezone,
        }
        return bq_handle_headline(birth_dict, query_date=b.query_date)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))



# ── F6: /astro/pet/* endpoints (2026-05-18) ──

@app.post("/astro/pet/compatibility", dependencies=[Depends(verify_key)])
def pet_compatibility(p: PetCompatInput):
    """
    Pet-owner compatibility via adapted nakshatra koots
    (Tara, Yoni, Gana, Graha Maitri — total max 18).

    Pet input supports two modes:
      - Birth: dob + time + lat + lon + timezone
      - Acquisition: acquisition_date + acquisition_time + acquisition_lat +
                     acquisition_lon + acquisition_timezone

    Owner input: standard birth details (BirthInput).

    Returns: per-koot scores with explanations, total score, percentage, band,
    and verdict. Classically grounded in BPHS Ch. 7 + Hora Sara yoni hierarchy.
    """
    try:
        pet_dict = p.pet.dict(exclude_none=True)
        owner_dict = {
            "dob": p.owner.dob, "time": p.owner.time,
            "lat": p.owner.lat, "lon": p.owner.lon,
            "timezone": p.owner.timezone,
        }
        return pet_handle_compatibility(pet_dict, owner_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pet/naming", dependencies=[Depends(verify_key)])
def pet_naming(p: PetInput):
    """
    Pet naming via classical akshara from operative nakshatra-pada.

    Returns the pada-specific akshara, all 4 alternatives for the nakshatra,
    and illustrative pet-name suggestions for each akshara.
    """
    try:
        pet_dict = p.dict(exclude_none=True)
        return pet_handle_naming(pet_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pet/personality", dependencies=[Depends(verify_key)])
def pet_personality(p: PetInput):
    """
    Pet personality from natal/operative chart.

    Birth mode: full personality (Moon nakshatra + Sun sign + lagna + ruling planet).
    Acquisition mode: nakshatra-only personality (Sun/lagna at acquisition
                       don't represent permanent pet nature; honest classical scope).

    Returns: nakshatra traits, yoni animal signature, gana classification,
    ruling planet, and personality synthesis.
    """
    try:
        pet_dict = p.dict(exclude_none=True)
        return pet_handle_personality(pet_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))



# ── F6b: /astro/pet/{check,window} endpoints (2026-05-18) ──

@app.post("/astro/pet/check_acquisition_day", dependencies=[Depends(verify_key)])
def pet_check_acquisition_day(a: AcquisitionDayInput):
    """
    Check whether a specific date is auspicious for pet acquisition.

    Owner's tara state, daily yogas (Sarvartha Siddhi/Amrit Siddhi/Vish/Mrityu/etc.),
    yoni alignment of operative nakshatra, and Sade Sati status are all scored.
    Returns full breakdown + verdict + recommended intra-day window (Abhijit muhurta).
    """
    try:
        owner_dict = {
            "dob": a.owner.dob, "time": a.owner.time,
            "lat": a.owner.lat, "lon": a.owner.lon,
            "timezone": a.owner.timezone,
        }
        location_dict = {
            "lat": a.acquisition_location.lat,
            "lon": a.acquisition_location.lon,
            "timezone": a.acquisition_location.timezone,
        }
        return pm_handle_check_day(owner_dict, a.acquisition_date, location_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pet/auspicious_acquisition_window", dependencies=[Depends(verify_key)])
def pet_acquisition_window_scan(a: AcquisitionWindowInput):
    """
    Scan a date range and rank auspicious days for pet acquisition.

    Default: 14 days from today. Maximum 30 days.

    Returns top 5 recommended days (with full scoring breakdown + Abhijit window),
    list of days to avoid, full ranked list, and summary headline.
    """
    try:
        owner_dict = {
            "dob": a.owner.dob, "time": a.owner.time,
            "lat": a.owner.lat, "lon": a.owner.lon,
            "timezone": a.owner.timezone,
        }
        location_dict = {
            "lat": a.acquisition_location.lat,
            "lon": a.acquisition_location.lon,
            "timezone": a.acquisition_location.timezone,
        }
        return pm_handle_window_scan(owner_dict, a.start_date, a.end_date,
                                        location_dict, max_days=30)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ── F4: /astro/mundane/* endpoints (2026-05-18) ──

@app.post("/astro/mundane/country_outlook", dependencies=[Depends(verify_key)])
def mundane_country_outlook(c: CountryOutlookInput):
    """
    Mundane astrology outlook for a country.

    Provide EITHER country_code (ISO 3166-1 alpha-2; see registry below)
    OR chart_override with dob/time/lat/lon/timezone for custom entity.

    Available registered country codes: IN, US, UK, CN, RU, JP, DE, FR, AU, PK.

    Reuses cast_chart's pre-computed shadbala, yogas, dashas, and
    jaimini_karakas. Interprets through mundane house meanings
    (Varahamihira / Raman). NOT a prediction service — research framing.
    """
    try:
        override_dict = None
        if c.chart_override is not None:
            override_dict = {
                "dob":      c.chart_override.dob,
                "time":     c.chart_override.time,
                "lat":      c.chart_override.lat,
                "lon":      c.chart_override.lon,
                "timezone": c.chart_override.timezone,
            }
        return mn_handle_country_outlook(
            country_code=c.country_code,
            chart_override=override_dict,
            analysis_date=c.analysis_date,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/mundane/company_chart", dependencies=[Depends(verify_key)])
def mundane_company_chart(c: CompanyChartInput):
    """
    Mundane analysis of a company's incorporation chart.

    Inputs: incorporation date/time/place + optional business_sector.
    Sectors supported: technology, finance, banking, manufacturing,
    retail, media, energy, healthcare, agriculture, real_estate,
    luxury, transport, education, spiritual.

    Returns mundane-house lord assessments (2/6/10/11 emphasis),
    Arudha Lagna (public-facing image), wealth/governance yogas,
    and current dasha.
    """
    try:
        incorp_dict = {
            "dob":      c.incorporation.dob,
            "time":     c.incorporation.time,
            "lat":      c.incorporation.lat,
            "lon":      c.incorporation.lon,
            "timezone": c.incorporation.timezone,
        }
        return mn_handle_company_chart(
            incorporation=incorp_dict,
            business_sector=c.business_sector,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/mundane/election_prediction", dependencies=[Depends(verify_key)])
def mundane_election_prediction(c: ElectionEventInput):
    """
    Event-chart mundane analysis (e.g. for poll opening moment).

    DOES NOT predict winners. DOES NOT name parties or candidates.
    Returns classical mundane indicators only:
    lagna lord state, 10th lord (governance), 6th lord (opposition),
    Moon condition, graha yuddha, gandanta, eclipse proximity.

    Each response carries a disclaimer field clarifying scholarly framing.
    """
    try:
        event_dict = {
            "dob":      c.event.dob,
            "time":     c.event.time,
            "lat":      c.event.lat,
            "lon":      c.event.lon,
            "timezone": c.event.timezone,
        }
        return mn_handle_election_prediction(
            event=event_dict,
            country_code=c.country_code,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ── F5: /astro/pregnancy/* endpoints (2026-05-18) ──
#
# PCPNDT compliance note: None of these endpoints accept or emit foetal
# gender data. The Garbha Linga Nirnaya classical topic is deliberately
# omitted from the engine per PCPNDT Act, 1994 (India). Module docstring
# in pregnancy.py documents this engineering policy.
#

@app.post("/astro/pregnancy/conception_muhurta", dependencies=[Depends(verify_key)])
def pregnancy_conception_muhurta(c: ConceptionMuhurtaInput):
    """
    Garbhadhana muhurta — day-by-day scan for auspicious conception
    attempt windows. Reuses cast_chart + panchang shape from dashaflow.
    Goes beyond /astro/children/conception_timing (which gives multi-year
    dasha windows) by adding day-level muhurta scoring.

    Returns top auspicious days + days to avoid + full ranked scan with
    transparent scoring (every point labeled).
    """
    try:
        female_dict = {
            "dob":      c.female_chart.dob,
            "time":     c.female_chart.time,
            "lat":      c.female_chart.lat,
            "lon":      c.female_chart.lon,
            "timezone": c.female_chart.timezone,
        }
        male_dict = None
        if c.male_chart is not None:
            male_dict = {
                "dob":      c.male_chart.dob,
                "time":     c.male_chart.time,
                "lat":      c.male_chart.lat,
                "lon":      c.male_chart.lon,
                "timezone": c.male_chart.timezone,
            }
        location_dict = {
            "lat":      c.location.lat,
            "lon":      c.location.lon,
            "timezone": c.location.timezone,
        }
        return pg_handle_conception_muhurta(
            female_chart=female_dict,
            male_chart=male_dict,
            location=location_dict,
            start_date=c.start_date,
            end_date=c.end_date,
            max_days=c.max_days or 30,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pregnancy/santana_yogas", dependencies=[Depends(verify_key)])
def pregnancy_santana_yogas(s: SantanaYogasInput):
    """
    Couple's combined santana yoga analysis. Reads each partner's 5th
    lord, Jupiter, Putrakaraka (Jaimini); surfaces supportive indicators
    and caution flags (Putra Dosha, Ketu in 5th, 5th lord in dusthana).

    Output complements /astro/children/5th_house_analysis (single-person)
    by combining BOTH partners' charts.
    """
    try:
        p1 = {
            "dob":      s.person1.dob,
            "time":     s.person1.time,
            "lat":      s.person1.lat,
            "lon":      s.person1.lon,
            "timezone": s.person1.timezone,
        }
        p2 = {
            "dob":      s.person2.dob,
            "time":     s.person2.time,
            "lat":      s.person2.lat,
            "lon":      s.person2.lon,
            "timezone": s.person2.timezone,
        }
        return pg_handle_santana_yogas(person1_chart=p1, person2_chart=p2)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pregnancy/prenatal_remedies", dependencies=[Depends(verify_key)])
def pregnancy_prenatal_remedies(r: PrenatalRemediesInput):
    """
    Month-by-month Garbha Sanskara remedies for gestational month 1-9.
    Returns the classical practices for the specified month plus mother's
    chart-specific personalization (Jupiter, Moon, 5th lord state).

    Sources: Garbha Upanishad; Sushruta Sharira Sthana; Charaka Sharira.
    Output: spiritual practice guidance, NEVER medical advice.
    """
    try:
        mother = {
            "dob":      r.mother_chart.dob,
            "time":     r.mother_chart.time,
            "lat":      r.mother_chart.lat,
            "lon":      r.mother_chart.lon,
            "timezone": r.mother_chart.timezone,
        }
        father = None
        if r.father_chart is not None:
            father = {
                "dob":      r.father_chart.dob,
                "time":     r.father_chart.time,
                "lat":      r.father_chart.lat,
                "lon":      r.father_chart.lon,
                "timezone": r.father_chart.timezone,
            }
        return pg_handle_prenatal_remedies(
            mother_chart=mother,
            gestational_month=r.gestational_month,
            father_chart=father,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pregnancy/bala_arishta", dependencies=[Depends(verify_key)])
def pregnancy_bala_arishta(b: BalaArishtaInput):
    """
    Classical Bala-Arishta yoga screen for a child's chart.

    SENSITIVE: returns classical early-childhood-affliction yoga findings
    framed as karmic patterns + shanti remedies. NOT medical/psychological
    diagnosis. Sources: BPHS Ch. 8; Jataka Tatva; Saravali Ch. 7.

    Response carries `sensitive_topic_disclaimer` field.
    """
    try:
        child = {
            "dob":      b.child_chart.dob,
            "time":     b.child_chart.time,
            "lat":      b.child_chart.lat,
            "lon":      b.child_chart.lon,
            "timezone": b.child_chart.timezone,
        }
        return pg_handle_bala_arishta(child_chart=child)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pregnancy/newborn_naming_window", dependencies=[Depends(verify_key)])
def pregnancy_newborn_naming_window(n: NewbornNamingInput):
    """
    Namakarana muhurta + classical akshara letters from Janma Nakshatra.

    Returns the pada-specific akshara, all 4 nakshatra aksharas as
    alternatives, classical 10th/11th/12th day naming candidates with
    muhurta scoring, and family-priest selection guidance.

    Sources: Muhurta Chintamani Ch. 6; BPHS Ch. 100.
    """
    try:
        child = {
            "dob":      n.child_chart.dob,
            "time":     n.child_chart.time,
            "lat":      n.child_chart.lat,
            "lon":      n.child_chart.lon,
            "timezone": n.child_chart.timezone,
        }
        loc = {
            "lat":      n.naming_location.lat,
            "lon":      n.naming_location.lon,
            "timezone": n.naming_location.timezone,
        }
        return pg_handle_newborn_naming_window(
            child_chart=child, naming_location=loc,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pregnancy/garbha_shanti_remedies", dependencies=[Depends(verify_key)])
def pregnancy_garbha_shanti_remedies(g: GarbhaShantiInput):
    """
    Garbha Shanti remedies for problematic pregnancies (recurrent
    miscarriage, complications, classical Garbha-pida indicators).

    SENSITIVE: classical SPIRITUAL practices only, never medical. Always
    supplementary to prescribed medical care, never substitutive.
    Sources: Brahma Vaivarta Purana; Garuda Purana; classical Garbha
    Raksha texts; Vaishnava Santana Gopala tradition.

    Response carries `sensitive_topic_disclaimer` field.
    """
    try:
        mother = {
            "dob":      g.mother_chart.dob,
            "time":     g.mother_chart.time,
            "lat":      g.mother_chart.lat,
            "lon":      g.mother_chart.lon,
            "timezone": g.mother_chart.timezone,
        }
        father = None
        if g.father_chart is not None:
            father = {
                "dob":      g.father_chart.dob,
                "time":     g.father_chart.time,
                "lat":      g.father_chart.lat,
                "lon":      g.father_chart.lon,
                "timezone": g.father_chart.timezone,
            }
        return pg_handle_garbha_shanti_remedies(
            mother_chart=mother,
            gestational_month=g.gestational_month,
            father_chart=father,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ── F7: /astro/karma/* endpoints (2026-05-18) ──
#
# Multi-chart family-karma synthesis on top of existing single-chart
# modules (pitra_dosha, karmic, children_education). Inputs use
# StrictBirthInput for HTTP-layer hygiene.
#

def _fk_birth_dict(b):
    """Convert a StrictBirthInput Pydantic model to a dict for handler call."""
    if b is None:
        return None
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/karma/family_patterns", dependencies=[Depends(verify_key)])
def karma_family_patterns(f: FamilyPatternsInput):
    """
    Multi-chart pattern detection. Calls existing pitra_dosha + karmic +
    children_education handlers on each provided chart, then surfaces
    shared affliction signatures, transmitted/broken yogas, and
    inherited Putra-Pitri combinations.

    self_birth is required; mother/father/grandfather charts are optional
    and increase synthesis depth.
    """
    try:
        return fk_handle_family_patterns(
            self_birth                  = _fk_birth_dict(f.self_birth),
            mother_birth                = _fk_birth_dict(f.mother_birth),
            father_birth                = _fk_birth_dict(f.father_birth),
            paternal_grandfather_birth  = _fk_birth_dict(f.paternal_grandfather_birth),
            maternal_grandfather_birth  = _fk_birth_dict(f.maternal_grandfather_birth),
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/karma/ancestral_strengths", dependencies=[Depends(verify_key)])
def karma_ancestral_strengths(a: AncestralStrengthsInput):
    """
    Deep dive on 4th (mother lineage), 9th (father lineage), 12th
    (ancestral karma) houses for self chart, with optional cross-chart
    overlay from parent charts.

    Reuses karmic.handle_twelfth_house_moksha and pitra_dosha.profile.
    Adds matri/pitri transmission overlay if parent charts provided.
    """
    try:
        return fk_handle_ancestral_strengths(
            self_birth   = _fk_birth_dict(a.self_birth),
            mother_birth = _fk_birth_dict(a.mother_birth),
            father_birth = _fk_birth_dict(a.father_birth),
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/karma/lineage_yogas", dependencies=[Depends(verify_key)])
def karma_lineage_yogas(l: LineageYogasInput):
    """
    Detect classical lineage-specific yogas across charts:
    Pitri-Continuity, Matri-Continuity, Pitri-Rupture, Matri-Rupture,
    Putra-Pitri inherited, Kuladevi-Activation, Rahu-Lineage-Shift,
    Ketu-Ancestral-Release.

    Sources: Jaimini Sutras Ch. 2; BPHS Ch. 32; Phaladeepika Ch. 13;
    Saravali Ch. 23.
    """
    try:
        return fk_handle_lineage_yogas(
            self_birth   = _fk_birth_dict(l.self_birth),
            mother_birth = _fk_birth_dict(l.mother_birth),
            father_birth = _fk_birth_dict(l.father_birth),
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/karma/karaka_inheritance", dependencies=[Depends(verify_key)])
def karma_karaka_inheritance(k: KarakaInheritanceInput):
    """
    Jaimini karaka cross-chart comparison. For each of the 7 karakas
    (Atmakaraka, Amatyakaraka, Bhratrikaraka, Matrikaraka, Putrakaraka,
    Gnatikaraka, Darakaraka), compare self vs. each provided ancestor:
    same planet (continued/intensified/released) or different (shifted).

    Source: Jaimini Upadesha Sutras Ch. 2; BPHS Ch. 32.
    """
    try:
        return fk_handle_karaka_inheritance(
            self_birth                  = _fk_birth_dict(k.self_birth),
            mother_birth                = _fk_birth_dict(k.mother_birth),
            father_birth                = _fk_birth_dict(k.father_birth),
            paternal_grandfather_birth  = _fk_birth_dict(k.paternal_grandfather_birth),
            maternal_grandfather_birth  = _fk_birth_dict(k.maternal_grandfather_birth),
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/karma/dasha_lineage", dependencies=[Depends(verify_key)])
def karma_dasha_lineage(d: DashaLineageInput):
    """
    Cross-chart dasha overlap analysis. Identifies periods where self's
    Mahadasha planet matches a parent's MD planet — classical activation
    window for inherited karma in that planet's domain.

    Source: BPHS Ch. 46-52 (Vimshottari); Phaladeepika Ch. 26.
    """
    try:
        return fk_handle_dasha_lineage(
            self_birth      = _fk_birth_dict(d.self_birth),
            mother_birth    = _fk_birth_dict(d.mother_birth),
            father_birth    = _fk_birth_dict(d.father_birth),
            lookahead_years = d.lookahead_years or 20,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ── F10-P1: Birth Time Rectification (KP-based) (2026-05-18) ──
import rectification  # F10-P1


class EventInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    event_type: str
    event_date: str  # YYYY-MM-DD
    weight: float = 1.0


class KPRectificationInput(StrictBirthInput):
    # Inherits dob, time, lat, lon, timezone + extra=forbid from StrictBirthInput
    # Uses PEP 585 lowercase generics (Python 3.9+) — no `from typing import List` needed
    events: list[EventInput]
    scan_window_minutes: int = 120
    scan_granularity_minutes: int = 1
    top_n: int = 5


@app.post(
    "/astro/rectification/kp_based",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p1_kp_rectification(payload: KPRectificationInput):
    try:
        events_dicts = [
            {"event_type": e.event_type, "event_date": e.event_date, "weight": e.weight}
            for e in payload.events
        ]
        result = rectification.handle_kp_rectification(
            dob=payload.dob,
            time=payload.time,
            lat=payload.lat,
            lon=payload.lon,
            timezone=payload.timezone,
            events=events_dicts,
            scan_window_minutes=payload.scan_window_minutes,
            scan_granularity_minutes=payload.scan_granularity_minutes,
            top_n=payload.top_n,
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"KP rectification failed: {exc}")


@app.get(
    "/astro/rectification/supported_events",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p1_supported_events():
    return rectification.handle_supported_events()


# ── F10-P2: BTR Approaches A (Parashari) + B (Tattva) (2026-05-18) ──
import rectification_p2  # F10-P2


class EventInputP2(BaseModel):
    model_config = ConfigDict(extra="forbid")
    event_type: str
    event_date: str  # YYYY-MM-DD
    weight: float = 1.0


class EventBasedRectificationInput(StrictBirthInput):
    # Inherits dob, time, lat, lon, timezone + extra=forbid from StrictBirthInput
    events: list[EventInputP2]
    scan_window_minutes: int = 120
    scan_granularity_minutes: int = 1
    top_n: int = 5


class TattvaRectificationInput(StrictBirthInput):
    observed_tattva: str  # one of: fire, earth, air, water, ether
    scan_window_minutes: int = 120
    scan_granularity_minutes: int = 1


@app.post(
    "/astro/rectification/event_based",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p2_event_based_rectification(payload: EventBasedRectificationInput):
    try:
        events_dicts = [
            {"event_type": e.event_type, "event_date": e.event_date, "weight": e.weight}
            for e in payload.events
        ]
        result = rectification_p2.handle_event_based_rectification(
            dob=payload.dob,
            time=payload.time,
            lat=payload.lat,
            lon=payload.lon,
            timezone=payload.timezone,
            events=events_dicts,
            scan_window_minutes=payload.scan_window_minutes,
            scan_granularity_minutes=payload.scan_granularity_minutes,
            top_n=payload.top_n,
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Event-based rectification failed: {exc}")


@app.post(
    "/astro/rectification/tattva",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p2_tattva_rectification(payload: TattvaRectificationInput):
    try:
        result = rectification_p2.handle_tattva_rectification(
            dob=payload.dob,
            time=payload.time,
            lat=payload.lat,
            lon=payload.lon,
            timezone=payload.timezone,
            observed_tattva=payload.observed_tattva,
            scan_window_minutes=payload.scan_window_minutes,
            scan_granularity_minutes=payload.scan_granularity_minutes,
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Tattva rectification failed: {exc}")


@app.get(
    "/astro/rectification/supported_tattvas",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p2_supported_tattvas():
    return rectification_p2.handle_supported_tattvas()


# ── F10-P3: BTR Approach C (Nadi Amshas) + Master Synthesis (2026-05-18) ──
import rectification_p3  # F10-P3


class NadiAmshaRectificationInput(StrictBirthInput):
    # Inherits dob, time, lat, lon, timezone + extra=forbid from StrictBirthInput
    # user_traits is a dict of trait_dimension -> trait_value
    # e.g. {"body_type": "lean", "complexion": "wheatish", "voice": "soft"}
    user_traits: dict[str, str]
    scan_window_minutes: int = 30
    scan_granularity_minutes: int = 1
    top_n: int = 5


class MasterEventInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    event_type: str
    event_date: str
    weight: float = 1.0


class MasterRectificationInput(StrictBirthInput):
    # All inputs optional — master uses whichever data the user has.
    # Must have at least one of: events, observed_tattva, user_traits.
    events: list[MasterEventInput] = []
    observed_tattva: str | None = None
    user_traits: dict[str, str] = {}
    scan_window_minutes: int = 120
    scan_granularity_minutes: int = 1


@app.post(
    "/astro/rectification/nadi_amshas",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p3_nadi_amsha_rectification(payload: NadiAmshaRectificationInput):
    try:
        result = rectification_p3.handle_nadi_amsha_rectification(
            dob=payload.dob,
            time=payload.time,
            lat=payload.lat,
            lon=payload.lon,
            timezone=payload.timezone,
            user_traits=payload.user_traits,
            scan_window_minutes=payload.scan_window_minutes,
            scan_granularity_minutes=payload.scan_granularity_minutes,
            top_n=payload.top_n,
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Nadi amsha rectification failed: {exc}")


@app.post(
    "/astro/rectification/master",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p3_master_rectification(payload: MasterRectificationInput):
    try:
        events_list = [
            {"event_type": e.event_type, "event_date": e.event_date, "weight": e.weight}
            for e in payload.events
        ] if payload.events else None

        result = rectification_p3.handle_master_rectification(
            dob=payload.dob,
            time=payload.time,
            lat=payload.lat,
            lon=payload.lon,
            timezone=payload.timezone,
            events=events_list,
            observed_tattva=payload.observed_tattva,
            user_traits=payload.user_traits or None,
            scan_window_minutes=payload.scan_window_minutes,
            scan_granularity_minutes=payload.scan_granularity_minutes,
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Master rectification failed: {exc}")


@app.get(
    "/astro/rectification/nadi_amshas/info",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p3_nadi_amshas_info():
    return rectification_p3.handle_nadi_amshas_info()
