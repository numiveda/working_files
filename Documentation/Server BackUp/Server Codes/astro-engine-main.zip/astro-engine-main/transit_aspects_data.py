"""
transit_aspects_data.py — Aspect definitions for transit-to-natal computations.

Phase D — Upgrade 3 (Transit applying/separating + upcoming exact aspects).

Public catalogs:
    WESTERN_ASPECTS        — Conjunction, opposition, trine, square, sextile
    VEDIC_PLANET_ASPECTS   — Mars 4/7/8, Jupiter 5/7/9, Saturn 3/7/10, others 7
    ORB_BY_PLANET_PAIR     — Tighter orbs for fast/slow planets
    APPLICATION_RULES      — How to determine applying vs separating
    CLASSICAL_CITATIONS

Sources: Western — Ptolemy "Tetrabiblos" (~2nd c. CE, public domain).
         Vedic drishti — BPHS Ch. 26, Phaladeepika Ch. 4 (public domain).
"""

from typing import Dict, List


# ════════════════════════════════════════════════════════════════════════
# WESTERN ASPECTS — Major aspects per Ptolemaic doctrine
# ════════════════════════════════════════════════════════════════════════

WESTERN_ASPECTS: Dict[str, Dict] = {
    "conjunction":  {"angle":   0, "orb_default": 8, "nature": "neutral",
                     "interpretation": "Planets blended; merged energy. Nature depends on planets involved."},
    "opposition":   {"angle": 180, "orb_default": 8, "nature": "tension",
                     "interpretation": "Polarities, projection, awareness through contrast."},
    "trine":        {"angle": 120, "orb_default": 6, "nature": "harmonious",
                     "interpretation": "Flow, ease, talent. Energies in elemental harmony."},
    "square":       {"angle":  90, "orb_default": 6, "nature": "tension",
                     "interpretation": "Friction, growth through challenge, dynamic action."},
    "sextile":      {"angle":  60, "orb_default": 4, "nature": "harmonious",
                     "interpretation": "Opportunity, supportive when conscious effort applied."},
    "quincunx":     {"angle": 150, "orb_default": 3, "nature": "adjustment",
                     "interpretation": "Adjustment, requires conscious adaptation between unrelated areas."},
}


# ════════════════════════════════════════════════════════════════════════
# VEDIC PLANETARY ASPECTS — Drishti per BPHS
# Most planets aspect the 7th house from their position (180°)
# Special aspects (full strength):
#   Mars:    4th + 7th + 8th from itself (90°, 180°, 210°)
#   Jupiter: 5th + 7th + 9th (120°, 180°, 240°)
#   Saturn:  3rd + 7th + 10th (60°, 180°, 270°)
# Rahu/Ketu: 5th + 7th + 9th (same as Jupiter, per some traditions)
# ════════════════════════════════════════════════════════════════════════

VEDIC_PLANET_ASPECTS: Dict[str, List[Dict[str, int]]] = {
    "Sun":     [{"house_from": 7, "angle": 180, "name": "7th (full)"}],
    "Moon":    [{"house_from": 7, "angle": 180, "name": "7th (full)"}],
    "Mars":    [{"house_from": 4, "angle":  90, "name": "4th (full)"},
                {"house_from": 7, "angle": 180, "name": "7th (full)"},
                {"house_from": 8, "angle": 210, "name": "8th (full)"}],
    "Mercury": [{"house_from": 7, "angle": 180, "name": "7th (full)"}],
    "Jupiter": [{"house_from": 5, "angle": 120, "name": "5th (full)"},
                {"house_from": 7, "angle": 180, "name": "7th (full)"},
                {"house_from": 9, "angle": 240, "name": "9th (full)"}],
    "Venus":   [{"house_from": 7, "angle": 180, "name": "7th (full)"}],
    "Saturn":  [{"house_from": 3, "angle":  60, "name": "3rd (full)"},
                {"house_from": 7, "angle": 180, "name": "7th (full)"},
                {"house_from": 10, "angle": 270, "name": "10th (full)"}],
    "Rahu":    [{"house_from": 5, "angle": 120, "name": "5th (full)"},
                {"house_from": 7, "angle": 180, "name": "7th (full)"},
                {"house_from": 9, "angle": 240, "name": "9th (full)"}],
    "Ketu":    [{"house_from": 5, "angle": 120, "name": "5th (full)"},
                {"house_from": 7, "angle": 180, "name": "7th (full)"},
                {"house_from": 9, "angle": 240, "name": "9th (full)"}],
}


# ════════════════════════════════════════════════════════════════════════
# ORB GUIDELINES — Tightness of aspect varies by planet speed
# Faster planets (Sun, Moon) get bigger orbs; slow planets tighter
# ════════════════════════════════════════════════════════════════════════

ORB_BY_PLANET: Dict[str, float] = {
    "Sun":      8.0,
    "Moon":    10.0,
    "Mars":     6.0,
    "Mercury":  6.0,
    "Jupiter":  7.0,
    "Venus":    6.0,
    "Saturn":   6.0,
    "Rahu":     5.0,
    "Ketu":     5.0,
}


# ════════════════════════════════════════════════════════════════════════
# APPLYING vs SEPARATING RULES
# ════════════════════════════════════════════════════════════════════════

APPLICATION_RULES: Dict[str, str] = {
    "applying":   "Faster-moving body is approaching exact aspect. Energy is building, event is forthcoming. Most predictive in transits.",
    "separating": "Faster-moving body has passed exact aspect. Energy is dissipating, event already happened. Less predictive.",
    "exact":      "Bodies within 0.5° of perfect aspect — event is occurring NOW. Highest intensity.",
    "key_principle":"In transit-to-natal, transiting body's speed determines applying/separating since natal is fixed.",
}


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

CLASSICAL_CITATIONS: Dict[str, str] = {
    "western_aspects": "Claudius Ptolemy 'Tetrabiblos' (~2nd c. CE) — major aspect doctrine. Ptolemaic aspects (conjunction, opposition, trine, square, sextile) remain the foundation of Western astrology.",
    "vedic_drishti":   "BPHS Ch. 26 (Drishti Adhyaya); Phaladeepika Ch. 4 — special planetary aspects (Mars 4/7/8, Jupiter 5/7/9, Saturn 3/7/10).",
    "applying":        "Hellenistic 'application' (sunaphe) doctrine — Vettius Valens, Hephaestio. Modern usage per Robert Hand 'Planets in Transit'.",
    "swiss_eph":       "Real-time planetary speeds and positions via Swiss Ephemeris 2.10 (Astrodienst, derived from DE431 JPL ephemerides).",
}
