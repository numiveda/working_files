"""
panchang.py — numiVeda Kaaliyo Astro Engine — Module C4 (Daily Panchang)

6 endpoints for daily Vedic almanac.

Endpoints:
    handle_full         — All 5 limbs + Rahu/Yama/Gulika kalams
    handle_tithi        — Tithi only
    handle_nakshatra    — Nakshatra only
    handle_yoga         — Yoga only
    handle_karana       — Karana only
    handle_rahu_kalam   — Rahu/Yama/Gulika time bands

The chart cast already provides tithi/vara/nakshatra/yoga/karana natively.
This module wraps those + adds favorability classification + computes
sunrise/sunset (NOAA algorithm) + computes Rahu Kalam etc. from sunrise.
"""

from typing import Dict, Any, Tuple
from datetime import datetime, date, timedelta, timezone as tz
import math

from astro_helpers import get_chart

from panchang_data import (
    RAHU_KALAM_SEGMENT, YAMA_GANDAM_SEGMENT, GULIKA_KALAM_SEGMENT,
    DAY_NAMES, DAY_PLANET,
    NAKSHATRA_LORDS,
    YOGA_NAMES, YOGA_FAVORABILITY,
    KARANA_FAVORABILITY,
    TITHI_NAMES,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# NOAA SUNRISE / SUNSET ALGORITHM (public domain)
# Returns sunrise and sunset as local clock-time floats (hours past midnight)
# Accuracy: ~1 minute for mid-latitudes; sufficient for Panchang time bands
# ════════════════════════════════════════════════════════════════════════

def _julian_day(y: int, m: int, d: int) -> float:
    """Julian day number for Gregorian calendar date (midnight UT)."""
    if m <= 2:
        y -= 1
        m += 12
    a = y // 100
    b = 2 - a + a // 4
    jd = math.floor(365.25 * (y + 4716)) + math.floor(30.6001 * (m + 1)) + d + b - 1524.5
    return jd


def _sunrise_sunset(d: date, lat: float, lon: float,
                    timezone_offset_hours: float) -> Tuple[float, float]:
    """
    NOAA-based sunrise/sunset for a given date and location.
    Returns (sunrise_local_hour, sunset_local_hour) as float hours [0-24).

    timezone_offset_hours: e.g., +5.5 for IST.
    Note: simplified to standard solar zenith 90.833° (includes refraction + solar disc radius).
    """
    zenith = 90.833  # degrees — standard for sunrise/sunset
    day_of_year = d.timetuple().tm_yday

    # Approximate time at hour 6 (sunrise) and hour 18 (sunset)
    def calc(rising: bool) -> float:
        lng_hour = lon / 15.0
        t = day_of_year + (((6 if rising else 18) - lng_hour) / 24.0)
        M = (0.9856 * t) - 3.289                                # Sun's mean anomaly
        L = (M + (1.916 * math.sin(math.radians(M)))
             + (0.020 * math.sin(math.radians(2 * M))) + 282.634) % 360  # Sun's true longitude
        RA = (math.degrees(math.atan(0.91764 * math.tan(math.radians(L))))) % 360
        # Move RA to same quadrant as L
        Lquad = math.floor(L / 90) * 90
        RAquad = math.floor(RA / 90) * 90
        RA = (RA + (Lquad - RAquad)) / 15.0
        sin_dec = 0.39782 * math.sin(math.radians(L))
        cos_dec = math.cos(math.asin(sin_dec))
        cos_h = ((math.cos(math.radians(zenith))
                  - (sin_dec * math.sin(math.radians(lat))))
                 / (cos_dec * math.cos(math.radians(lat))))
        if cos_h > 1:
            return float('nan')  # Sun never rises (polar night)
        if cos_h < -1:
            return float('nan')  # Sun never sets (polar day)
        H = math.degrees(math.acos(cos_h))
        if rising:
            H = 360 - H
        H = H / 15.0
        T = H + RA - (0.06571 * t) - 6.622
        UT = (T - lng_hour) % 24
        local_time = (UT + timezone_offset_hours) % 24
        return local_time

    sunrise = calc(rising=True)
    sunset = calc(rising=False)
    return sunrise, sunset


def _hour_to_clock_string(h: float) -> str:
    """Convert float hours (0-24) to 'HH:MM' string."""
    if math.isnan(h):
        return "—"
    hh = int(h)
    mm = int(round((h - hh) * 60))
    if mm == 60:
        hh += 1; mm = 0
    return f"{hh:02d}:{mm:02d}"


def _segment_window(sunrise: float, sunset: float,
                    segment: int) -> Tuple[str, str]:
    """Return (start, end) clock times for given 1-of-8 day-segment."""
    if math.isnan(sunrise) or math.isnan(sunset):
        return "—", "—"
    day_length = sunset - sunrise
    if day_length < 0:
        return "—", "—"
    seg_length = day_length / 8.0
    start = sunrise + segment * seg_length
    end = sunrise + (segment + 1) * seg_length
    return _hour_to_clock_string(start), _hour_to_clock_string(end)


def _parse_timezone_offset(tz_str: str) -> float:
    """Convert 'Asia/Kolkata' to UTC offset in hours. Simple table."""
    # Lightweight mapping for common timezones — engine focuses on Indian usage
    tz_map: Dict[str, float] = {
        "Asia/Kolkata": 5.5, "Asia/Calcutta": 5.5,
        "UTC": 0.0, "Etc/UTC": 0.0,
        "America/New_York": -5.0, "America/Los_Angeles": -8.0,
        "Europe/London": 0.0, "Europe/Paris": 1.0,
        "Asia/Dubai": 4.0, "Asia/Singapore": 8.0, "Asia/Tokyo": 9.0,
        "Australia/Sydney": 10.0,
    }
    if tz_str in tz_map:
        return tz_map[tz_str]
    # Fallback: try 'Etc/GMT+/-N' patterns
    if tz_str.startswith("Etc/GMT"):
        try:
            return -float(tz_str.replace("Etc/GMT", ""))  # GMT+5 = -5 in Etc convention
        except Exception:
            pass
    return 5.5  # default to IST


# ════════════════════════════════════════════════════════════════════════
# CORE — Get raw chart + extract panchang
# ════════════════════════════════════════════════════════════════════════

def _get_panchang(date_str: str, lat: float, lon: float,
                  timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Cast chart at noon and extract panchang."""
    chart = get_chart(
        dob=date_str, time="12:00",
        lat=lat, lon=lon, timezone=timezone,
    )
    return chart.get("panchang", {})


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT HANDLERS
# ════════════════════════════════════════════════════════════════════════

def handle_tithi(date_str: str, lat: float, lon: float,
                 timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Endpoint 2: Tithi only."""
    p = _get_panchang(date_str, lat, lon, timezone)
    t = p.get("tithi", {})
    num = t.get("number")
    return {
        "date":       date_str,
        "tithi_number": num,
        "tithi_name":   t.get("name") or TITHI_NAMES.get(num),
        "paksha":       t.get("paksha"),
        "classical_name": TITHI_NAMES.get(num),
        "citation":     CLASSICAL_CITATIONS["tithi"],
    }


def handle_nakshatra(date_str: str, lat: float, lon: float,
                     timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Endpoint 3: Nakshatra only."""
    p = _get_panchang(date_str, lat, lon, timezone)
    n = p.get("nakshatra", {})
    name = n.get("name")
    return {
        "date":              date_str,
        "nakshatra":         name,
        "pada":              n.get("pada"),
        "ruling_planet":     n.get("lord") or NAKSHATRA_LORDS.get(name),
        "classical_lord":    NAKSHATRA_LORDS.get(name),
        "citation":          CLASSICAL_CITATIONS["nakshatra"],
    }


def handle_yoga(date_str: str, lat: float, lon: float,
                timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Endpoint 4: Yoga only."""
    p = _get_panchang(date_str, lat, lon, timezone)
    y = p.get("yoga", {})
    name = y.get("name")
    return {
        "date":             date_str,
        "yoga_index":       y.get("index"),
        "yoga_name":        name,
        "favorability":     YOGA_FAVORABILITY.get(name, "unknown"),
        "classical_total":  27,
        "citation":         CLASSICAL_CITATIONS["yoga"],
    }


def handle_karana(date_str: str, lat: float, lon: float,
                  timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Endpoint 5: Karana only."""
    p = _get_panchang(date_str, lat, lon, timezone)
    k = p.get("karana")
    # k may be string or dict
    if isinstance(k, dict):
        name = k.get("name")
    else:
        name = k
    return {
        "date":         date_str,
        "karana":       name,
        "favorability": KARANA_FAVORABILITY.get(name, "unknown"),
        "bhadra_warning": (KARANA_FAVORABILITY.get(name) == "inauspicious_bhadra"),
        "note":         "If karana is Vishti/Bhadra — avoid new ventures",
        "citation":     CLASSICAL_CITATIONS["karana"],
    }


def handle_rahu_kalam(date_str: str, lat: float, lon: float,
                      timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Endpoint 6: Rahu Kalam + Yama Gandam + Gulika Kalam time bands."""
    d = date.fromisoformat(date_str)
    weekday = d.weekday()
    tz_offset = _parse_timezone_offset(timezone)
    sunrise, sunset = _sunrise_sunset(d, lat, lon, tz_offset)

    rahu_seg = RAHU_KALAM_SEGMENT[weekday]
    yama_seg = YAMA_GANDAM_SEGMENT[weekday]
    gulika_seg = GULIKA_KALAM_SEGMENT[weekday]

    rahu_start, rahu_end = _segment_window(sunrise, sunset, rahu_seg)
    yama_start, yama_end = _segment_window(sunrise, sunset, yama_seg)
    gulika_start, gulika_end = _segment_window(sunrise, sunset, gulika_seg)

    return {
        "date":          date_str,
        "weekday":       DAY_NAMES[weekday],
        "weekday_planet":DAY_PLANET[weekday],
        "location":      {"lat": lat, "lon": lon, "timezone": timezone},
        "sunrise":       _hour_to_clock_string(sunrise),
        "sunset":        _hour_to_clock_string(sunset),
        "day_length_hours": round(sunset - sunrise, 2) if not math.isnan(sunset - sunrise) else None,
        "rahu_kalam":    {"start": rahu_start, "end": rahu_end,
                          "segment": rahu_seg + 1, "of_total": 8},
        "yama_gandam":   {"start": yama_start, "end": yama_end,
                          "segment": yama_seg + 1, "of_total": 8},
        "gulika_kalam":  {"start": gulika_start, "end": gulika_end,
                          "segment": gulika_seg + 1, "of_total": 8},
        "method":        "Sunrise/sunset computed via NOAA algorithm (~1min accuracy); day split into 8 equal segments per classical Panchang tradition",
        "citation":      CLASSICAL_CITATIONS["rahu_kalam"] + "; " + CLASSICAL_CITATIONS["sunrise_calc"],
    }


def handle_full(date_str: str, lat: float, lon: float,
                timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """Endpoint 1: Full Panchang — all 5 limbs + Rahu/Yama/Gulika kalams."""
    p = _get_panchang(date_str, lat, lon, timezone)
    rahu = handle_rahu_kalam(date_str, lat, lon, timezone)

    tithi_obj = p.get("tithi", {})
    nak = p.get("nakshatra", {})
    yoga_obj = p.get("yoga", {})
    karana_obj = p.get("karana")
    karana_name = karana_obj.get("name") if isinstance(karana_obj, dict) else karana_obj

    return {
        "date":     date_str,
        "location": {"lat": lat, "lon": lon, "timezone": timezone},
        "panchang_limbs": {
            "tithi": {
                "number":   tithi_obj.get("number"),
                "name":     tithi_obj.get("name") or TITHI_NAMES.get(tithi_obj.get("number")),
                "paksha":   tithi_obj.get("paksha"),
            },
            "vara": p.get("vara", {}),
            "nakshatra": {
                "name":   nak.get("name"),
                "pada":   nak.get("pada"),
                "lord":   nak.get("lord") or NAKSHATRA_LORDS.get(nak.get("name", "")),
            },
            "yoga": {
                "index":          yoga_obj.get("index"),
                "name":           yoga_obj.get("name"),
                "favorability":   YOGA_FAVORABILITY.get(yoga_obj.get("name", ""), "unknown"),
            },
            "karana": {
                "name":         karana_name,
                "favorability": KARANA_FAVORABILITY.get(karana_name, "unknown"),
            },
        },
        "time_bands": {
            "sunrise":     rahu["sunrise"],
            "sunset":      rahu["sunset"],
            "rahu_kalam":  rahu["rahu_kalam"],
            "yama_gandam": rahu["yama_gandam"],
            "gulika_kalam":rahu["gulika_kalam"],
        },
        "overall_assessment": (
            "auspicious" if (
                YOGA_FAVORABILITY.get(yoga_obj.get("name", "")) == "auspicious"
                and KARANA_FAVORABILITY.get(karana_name) == "auspicious"
                and tithi_obj.get("number") not in (4, 9, 14, 19, 24, 29, 30)
            ) else
            "inauspicious" if (
                YOGA_FAVORABILITY.get(yoga_obj.get("name", "")) == "inauspicious"
                or KARANA_FAVORABILITY.get(karana_name) == "inauspicious_bhadra"
                or tithi_obj.get("number") == 30
            ) else
            "mixed"
        ),
        "citation":  CLASSICAL_CITATIONS["panchang"],
    }
