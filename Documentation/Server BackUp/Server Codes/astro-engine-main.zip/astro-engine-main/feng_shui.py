"""
feng_shui.py — Personal Feng Shui Computation Engine

Schools used (all classical, all public domain):
- Bazhai (Eight Mansions / 八宅) — Compass School, ~1100 CE
- Bazi (Four Pillars of Destiny / 八字) — Tang Dynasty, ~700 CE
- Lo Shu Grid (洛書) — Yi Jing tradition, pre-1000 BCE
- Xuan Kong Flying Stars (玄空飛星) — Period 9 (2024–2043)
- Wu Xing (Five Elements / 五行) — pre-2000 BCE

Architecture:
- All computation is deterministic and rule-based — no LLM interpretation
- Every output includes structured metadata for downstream consumers
- Personal recommendations cite classical source
- "Modern application" is left to downstream apps/reports/B2B clients

API contract:
- All endpoints accept the same BirthInput schema as the rest of the engine
- Plus: gender (male/female) — required for Kua calculation
- All outputs are JSON with classical_source citations
"""

from datetime import datetime, date
from typing import Optional, Dict, List, Any

from feng_shui_data import (
    BAGUA,
    KUA_TO_TRIGRAM,
    EAST_GROUP_KUAS,
    WEST_GROUP_KUAS,
    KUA_DIRECTIONS,
    DIRECTION_MEANINGS,
    WU_XING,
    SHENG_CYCLE,
    KE_CYCLE,
    BAGUA_AREAS_HOME,
    CURRENT_PERIOD,
    ANNUAL_CENTER_STARS,
    STAR_NATURES,
    HEAVENLY_STEMS,
    EARTHLY_BRANCHES,
)


# ════════════════════════════════════════════════════════════════════════
# 1. KUA NUMBER — THE CORE OF PERSONAL FENG SHUI
# ════════════════════════════════════════════════════════════════════════

def calculate_kua(birth_year: int, gender: str, birth_month: int = 6, birth_day: int = 15) -> Dict[str, Any]:
    """
    Calculate Kua number from solar year + gender.

    The Feng Shui year begins at Lichun (~Feb 4), NOT at Jan 1.
    Anyone born before Feb 4 belongs to the previous solar year.

    Classical formulae (Period 7 and earlier vs current Period):
      Male:   (11 - last 2 digits reduced) mod 9, with 0 -> 9
      Female: (4 + last 2 digits reduced) mod 9, with 0 -> 9

    Special case: Kua 5 has no trigram.
      Male Kua 5 -> use Kua 2 (Kun)
      Female Kua 5 -> use Kua 8 (Gen)

    Source: Ba Zhai Ming Jing (Bright Mirror of the Eight Mansions), Song Dynasty.
    """
    gender = gender.lower().strip()
    if gender not in ("male", "female", "m", "f"):
        raise ValueError(f"gender must be 'male' or 'female', got: {gender}")
    gender = "male" if gender.startswith("m") else "female"

    # Apply Lichun rule — Feng Shui year starts Feb 4
    solar_year = birth_year
    if birth_month == 1 or (birth_month == 2 and birth_day < 4):
        solar_year = birth_year - 1

    # Reduce last 2 digits of solar year to single digit
    yy = solar_year % 100
    while yy >= 10:
        yy = sum(int(d) for d in str(yy))

    if gender == "male":
        kua_raw = (11 - yy) % 9
        if kua_raw == 0:
            kua_raw = 9
    else:
        # Modern (post-2000) female formula uses 4; classical was 5
        # We use 4 per the most widely accepted modern Compass School consensus
        kua_raw = (4 + yy) % 9
        if kua_raw == 0:
            kua_raw = 9

    # Handle Kua 5 substitution
    kua_effective = kua_raw
    substitution_note = None
    if kua_raw == 5:
        if gender == "male":
            kua_effective = 2
            substitution_note = "Kua 5 has no trigram. Male Kua 5 uses Kua 2 (Kun / Earth / Mother)."
        else:
            kua_effective = 8
            substitution_note = "Kua 5 has no trigram. Female Kua 5 uses Kua 8 (Gen / Mountain / Youngest Son)."

    trigram_key = KUA_TO_TRIGRAM[kua_effective]
    trigram = BAGUA[trigram_key]

    group = "east" if kua_effective in EAST_GROUP_KUAS else "west"

    return {
        "kua_number":             kua_raw,
        "kua_effective":          kua_effective,
        "substitution_note":      substitution_note,
        "trigram_key":            trigram_key,
        "trigram_chinese":        trigram["chinese"],
        "trigram_pinyin":         trigram["pinyin"],
        "trigram_english":        trigram["english"],
        "personal_element":       trigram["element"],
        "yin_yang":               trigram["yin_yang"],
        "family_position":        trigram["family"],
        "body_part_governed":     trigram["body_part"],
        "group":                  group,
        "group_label":            "East Group (火/木/水)" if group == "east" else "West Group (金/土)",
        "compatible_kuas":        EAST_GROUP_KUAS if group == "east" else WEST_GROUP_KUAS,
        "incompatible_kuas":      WEST_GROUP_KUAS if group == "east" else EAST_GROUP_KUAS,
        "attributes":             trigram["attributes"],
        "solar_year_used":        solar_year,
        "lichun_adjusted":        solar_year != birth_year,
        "classical_source":       "Ba Zhai Ming Jing, Song Dynasty (~1100 CE)",
    }


# ════════════════════════════════════════════════════════════════════════
# 2. EIGHT DIRECTIONS — LUCKY AND UNLUCKY
# ════════════════════════════════════════════════════════════════════════

def get_eight_directions(kua_effective: int) -> Dict[str, Any]:
    """
    Return all 8 directional energies for a given Kua, ranked.

    Source: Ba Zhai system — every Kua has 4 favorable + 4 unfavorable directions.
    Strict ranking: Sheng Qi (best) > Tian Yi > Yan Nian > Fu Wei > Fu Wei > Huo Hai > Wu Gui > Liu Sha > Jue Ming (worst)
    """
    if kua_effective not in KUA_DIRECTIONS:
        raise ValueError(f"Invalid Kua: {kua_effective}")

    directions_for_kua = KUA_DIRECTIONS[kua_effective]
    result_lucky = []
    result_unlucky = []

    for direction_type, compass_direction in directions_for_kua.items():
        meaning = DIRECTION_MEANINGS[direction_type]
        entry = {
            "direction_type":      direction_type,
            "chinese":             meaning["chinese"],
            "english":             meaning["english"],
            "rank":                meaning["rank"],
            "compass_direction":   compass_direction,
            "polarity":            meaning["polarity"],
            "domain":              meaning["domain"],
        }
        if meaning["polarity"] == "lucky":
            entry["best_for"] = meaning["best_for"]
            result_lucky.append(entry)
        else:
            entry["avoid_for"] = meaning["avoid_for"]
            result_unlucky.append(entry)

    result_lucky.sort(key=lambda x: x["rank"])
    result_unlucky.sort(key=lambda x: x["rank"])

    return {
        "lucky_directions":      result_lucky,
        "unlucky_directions":    result_unlucky,
        "best_direction":        result_lucky[0]["compass_direction"],
        "worst_direction":       result_unlucky[-1]["compass_direction"],
        "primary_application":   {
            "sleeping":            "head pointed toward " + result_lucky[3]["compass_direction"] + " (Fu Wei)",
            "working":             "desk facing " + result_lucky[0]["compass_direction"] + " (Sheng Qi)",
            "main_door_facing":    result_lucky[0]["compass_direction"],
            "kitchen_stove_back":  "stove back toward " + result_unlucky[-1]["compass_direction"] + " (Jue Ming — burn the worst direction)",
        },
        "classical_source":      "Ba Zhai Ming Jing — Eight Mansions Theory",
    }


# ════════════════════════════════════════════════════════════════════════
# 3. ELEMENT ANALYSIS — BAZI DAY MASTER + YEAR ANIMAL
# ════════════════════════════════════════════════════════════════════════

def calculate_year_animal(year: int) -> Dict[str, Any]:
    """
    Chinese zodiac year animal + element.

    Reference: 1984 = Jia Zi (Year 1 of the 60-year cycle, Wood Rat).
    Stem cycle is 10, Branch cycle is 12. LCM is 60 = sexagenary cycle.
    """
    stem_index = (year - 4) % 10
    branch_index = (year - 4) % 12

    stem = HEAVENLY_STEMS[stem_index]
    branch = EARTHLY_BRANCHES[branch_index]

    return {
        "year":                  year,
        "year_stem":             stem["name"],
        "year_stem_chinese":     stem["chinese"],
        "year_stem_element":     stem["element"],
        "year_stem_polarity":    stem["yin_yang"],
        "year_branch":           branch["name"],
        "year_branch_chinese":   branch["chinese"],
        "year_animal":           branch["animal"],
        "year_branch_element":   branch["element"],
        "full_name":             f"{stem['yin_yang'].title()} {stem['element'].title()} {branch['animal'].title()}",
        "popular_name":          f"{branch['animal'].title()} of {stem['element'].title()}",
        "classical_source":      "Tang Dynasty Bazi (60-year sexagenary cycle)",
    }


def calculate_day_master(birth_year: int, birth_month: int, birth_day: int) -> Dict[str, Any]:
    """
    Calculate Day Master (Day Stem) from birth date.

    Uses the classical 60-day sexagenary day cycle anchored to a known reference.
    Reference: 1900-01-01 was Jia Xu (Stem index 0, Branch index 10).
    Compute days elapsed since reference, modulo 60.
    """
    reference = date(1900, 1, 1)
    target = date(birth_year, birth_month, birth_day)
    days_elapsed = (target - reference).days

    # 1900-01-01 was day-stem Jia (index 0), day-branch Xu (index 10)
    day_stem_index = days_elapsed % 10
    day_branch_index = (days_elapsed + 10) % 12

    stem = HEAVENLY_STEMS[day_stem_index]
    branch = EARTHLY_BRANCHES[day_branch_index]

    return {
        "day_master_stem":           stem["name"],
        "day_master_stem_chinese":   stem["chinese"],
        "day_master_element":        stem["element"],
        "day_master_polarity":       stem["yin_yang"],
        "day_master_full":           f"{stem['yin_yang'].title()} {stem['element'].title()}",
        "day_branch":                branch["name"],
        "day_branch_chinese":        branch["chinese"],
        "day_branch_animal":         branch["animal"],
        "day_branch_element":        branch["element"],
        "interpretation":            _interpret_day_master(stem),
        "classical_source":          "Bazi Four Pillars — Day Pillar (日柱) tradition",
    }


def _interpret_day_master(stem: Dict[str, str]) -> Dict[str, str]:
    """
    Classical Day Master personality archetype.
    Source: Wei Qian Li, Yuan Tian-Gang and later Bazi commentaries.
    """
    interpretations = {
        ("wood", "yang"):  {"archetype": "Jia Wood — Tall Tree", "core": "Upright, principled, ambitious, grows steadily toward light", "career_natural": "leadership, education, law, forestry, structural roles"},
        ("wood", "yin"):   {"archetype": "Yi Wood — Vine / Flower", "core": "Flexible, social, adaptive, grows around obstacles", "career_natural": "arts, design, hospitality, networking, healing"},
        ("fire", "yang"):  {"archetype": "Bing Fire — Sun", "core": "Bright, charismatic, generous, visible, attention-seeking", "career_natural": "performance, broadcasting, leadership, motivation, sales"},
        ("fire", "yin"):   {"archetype": "Ding Fire — Candle / Lamp", "core": "Refined, intuitive, mystical, focused, slow-burning", "career_natural": "research, spirituality, writing, intimate teaching, craft"},
        ("earth", "yang"): {"archetype": "Wu Earth — Mountain", "core": "Stable, reliable, slow, protective, immovable", "career_natural": "real estate, agriculture, banking, institutional roles, foundations"},
        ("earth", "yin"):  {"archetype": "Ji Earth — Soil / Field", "core": "Nurturing, fertile, accommodating, supports others' growth", "career_natural": "education, healthcare, agriculture, social work, gardening"},
        ("metal", "yang"): {"archetype": "Geng Metal — Sword / Axe", "core": "Sharp, decisive, just, cutting through obstacles, principled", "career_natural": "military, surgery, law enforcement, athletics, engineering"},
        ("metal", "yin"):  {"archetype": "Xin Metal — Jewel / Ornament", "core": "Refined, precious, beautiful, requires polish, particular", "career_natural": "luxury, jewelry, design, finance, precision crafts"},
        ("water", "yang"): {"archetype": "Ren Water — Ocean / River", "core": "Vast, intelligent, far-reaching, deep, exploratory", "career_natural": "shipping, travel, philosophy, exploration, international trade"},
        ("water", "yin"):  {"archetype": "Gui Water — Rain / Dew", "core": "Gentle, perceptive, mystical, nourishing, hidden depth", "career_natural": "psychology, intuitive arts, music, counseling, esoteric study"},
    }
    return interpretations.get((stem["element"], stem["yin_yang"]),
                                {"archetype": "Unknown", "core": "", "career_natural": ""})


def element_interactions(element: str) -> Dict[str, Any]:
    """
    Return generative and destructive relationships for an element.
    Used to determine: lucky colors, harmful colors, supporting people, draining people.
    """
    element_data = WU_XING[element]
    feeds = SHENG_CYCLE[element]            # I produce this
    fed_by = next(k for k, v in SHENG_CYCLE.items() if v == element)  # This produces me
    weakens = KE_CYCLE[element]             # I overcome this
    weakened_by = next(k for k, v in KE_CYCLE.items() if v == element)  # This overcomes me

    return {
        "element":            element,
        "chinese":            element_data["chinese"],
        "primary_color":      element_data["color"],
        "direction":          element_data["direction"],
        "season":             element_data["season"],
        "vedic_planet":       element_data["planet"],
        "supporting": {
            "element":          fed_by,
            "rule":             f"{fed_by.title()} produces {element.title()} (Sheng cycle)",
            "color":            WU_XING[fed_by]["color"],
            "use_when":         "weak, low energy, recovering, learning",
        },
        "self_strengthening": {
            "element":          element,
            "rule":             f"{element.title()} reinforces {element.title()}",
            "color":            element_data["color"],
            "use_when":         "stable, building confidence, public appearances",
        },
        "draining": {
            "element":          feeds,
            "rule":             f"{element.title()} produces {feeds.title()} (you give energy to it)",
            "color":            WU_XING[feeds]["color"],
            "avoid_when":       "exhausted, overworked, burning out",
        },
        "harming": {
            "element":          weakened_by,
            "rule":             f"{weakened_by.title()} destroys {element.title()} (Ke cycle)",
            "color":            WU_XING[weakened_by]["color"],
            "avoid_when":       "always — wear sparingly, avoid in critical spaces",
        },
        "controlled_by_you": {
            "element":          weakens,
            "rule":             f"{element.title()} destroys {weakens.title()} (you overcome it)",
            "color":            WU_XING[weakens]["color"],
            "use_when":         "asserting boundaries, ending things, confrontations",
        },
    }


# ════════════════════════════════════════════════════════════════════════
# 4. LO SHU GRID — 3×3 MAGIC SQUARE FROM DOB
# ════════════════════════════════════════════════════════════════════════

def calculate_lo_shu(birth_year: int, birth_month: int, birth_day: int) -> Dict[str, Any]:
    """
    Place DOB digits into the classical 3x3 Lo Shu magic square.
    Each row, column, and diagonal sums to 15.

    Classical layout (King Wen / Post-Heaven arrangement):
        4 9 2
        3 5 7
        8 1 6

    Numbers present indicate developed traits.
    Numbers missing indicate areas needing cultivation.
    """
    # Collect all non-zero digits from DOB
    dob_str = f"{birth_day:02d}{birth_month:02d}{birth_year:04d}"
    digits_present = [int(d) for d in dob_str if d != "0"]

    counts = {n: digits_present.count(n) for n in range(1, 10)}
    missing = [n for n in range(1, 10) if counts[n] == 0]

    # Classical Lo Shu position meanings
    position_meanings = {
        1: {"position": "south_center",  "trigram": "kan",  "element": "water", "domain": "career, social skills, emotional expression",       "compass": "north"},
        2: {"position": "north_right",   "trigram": "kun",  "element": "earth", "domain": "relationships, partnership, motherhood, intuition", "compass": "southwest"},
        3: {"position": "south_left",    "trigram": "zhen", "element": "wood",  "domain": "family, communication, initiative, courage",         "compass": "east"},
        4: {"position": "north_left",    "trigram": "xun",  "element": "wood",  "domain": "wealth, learning, scholarship, mental flexibility", "compass": "southeast"},
        5: {"position": "center",        "trigram": None,   "element": "earth", "domain": "balance, center, life purpose, identity",            "compass": "center"},
        6: {"position": "center_right",  "trigram": "qian", "element": "metal", "domain": "leadership, authority, helpful people, fatherhood",  "compass": "northwest"},
        7: {"position": "east_center",   "trigram": "dui",  "element": "metal", "domain": "creativity, children, joy, expression, romance",     "compass": "west"},
        8: {"position": "north_center",  "trigram": "gen",  "element": "earth", "domain": "knowledge, self-cultivation, study, stability",      "compass": "northeast"},
        9: {"position": "south_center_top","trigram": "li", "element": "fire",  "domain": "fame, recognition, reputation, vision, clarity",     "compass": "south"},
    }

    grid_analysis = []
    for n in range(1, 10):
        analysis = {
            "number":    n,
            "count":     counts[n],
            "status":    "missing" if counts[n] == 0 else ("strong" if counts[n] >= 3 else ("present" if counts[n] >= 1 else "missing")),
            **position_meanings[n],
        }
        grid_analysis.append(analysis)

    # Excessive numbers (3+ occurrences) indicate over-expression
    excessive = [n for n in range(1, 10) if counts[n] >= 3]

    return {
        "grid_layout": [
            [4, 9, 2],
            [3, 5, 7],
            [8, 1, 6],
        ],
        "dob_digits":            digits_present,
        "counts":                counts,
        "missing_numbers":       missing,
        "excessive_numbers":     excessive,
        "analysis":              grid_analysis,
        "interpretation_guide":  {
            "missing":    "Indicates areas requiring conscious cultivation. Wear corresponding color, place corresponding element in the corresponding sector of home.",
            "present":    "Naturally developed. Reliable strength.",
            "excessive":  "Over-expression. May indicate imbalance, fixation, or strong karmic theme requiring conscious moderation.",
        },
        "classical_source":      "Lo Shu Square (洛書) — pre-1000 BCE, Yi Jing tradition",
    }


# ════════════════════════════════════════════════════════════════════════
# 5. FLYING STARS — PERSONAL ANNUAL READING
# ════════════════════════════════════════════════════════════════════════

def flying_stars_for_year(kua_effective: int, year: int) -> Dict[str, Any]:
    """
    Return the 9-Palace Flying Star chart for a given year + native's interaction.
    Each sector of the 9-palace grid hosts a star (1-9) annually.

    Mechanics: center star decreases by 1 each year (then wraps 1->9).
    All other palaces fill via the Lo Shu sequence around center.
    """
    if year not in ANNUAL_CENTER_STARS:
        # Extrapolate: 2026 = star 1. Each year decreases by 1.
        offset = year - 2026
        center_star = ((1 - offset - 1) % 9) + 1
    else:
        center_star = ANNUAL_CENTER_STARS[year]

    # Lo Shu sequence: from center, the next palace is NW, then W, NE, S, N, SW, E, SE
    # Sequence order: center, NW, W, NE, S, N, SW, E, SE
    palace_order = ["center", "northwest", "west", "northeast", "south", "north", "southwest", "east", "southeast"]

    # Stars fill in ascending order from center_star, wrapping 9->1
    palace_stars = {}
    for i, palace in enumerate(palace_order):
        star = ((center_star + i - 1) % 9) + 1
        palace_stars[palace] = star

    # Build per-palace analysis
    palaces = []
    for palace, star in palace_stars.items():
        nature = STAR_NATURES[star]
        palaces.append({
            "palace":       palace,
            "star":         star,
            "element":      nature["element"],
            "polarity":     nature["polarity"],
            "domain":       nature["domain"],
        })

    # Identify native's personal palace (Kua trigram direction)
    trigram_key = KUA_TO_TRIGRAM[kua_effective]
    personal_palace = BAGUA[trigram_key]["direction"]
    personal_star = palace_stars.get(personal_palace)
    personal_nature = STAR_NATURES[personal_star] if personal_star else None

    return {
        "year":                  year,
        "period":                CURRENT_PERIOD["number"],
        "period_element":        CURRENT_PERIOD["element"],
        "center_star":           center_star,
        "center_star_nature":    STAR_NATURES[center_star],
        "palaces":               palaces,
        "personal_palace":       personal_palace,
        "personal_star":         personal_star,
        "personal_star_nature":  personal_nature,
        "year_themes":           CURRENT_PERIOD["themes"],
        "classical_source":      "Xuan Kong Fei Xing (Flying Stars), Period 9 (2024–2043)",
    }


# ════════════════════════════════════════════════════════════════════════
# 6. BAGUA HOME MAP — LIFE AREAS BY HOUSE SECTOR
# ════════════════════════════════════════════════════════════════════════

def get_bagua_home_map(kua_effective: int) -> Dict[str, Any]:
    """
    Return the 9 life areas of the home (Bagua/Pa Kua) with:
    - Compass direction
    - Element
    - Lucky color for that sector
    - Materials/objects to enhance
    - Common remediation if afflicted
    - Personal direction alignment for native's Kua
    """
    native_directions = KUA_DIRECTIONS[kua_effective]
    direction_to_kua_meaning = {v: k for k, v in native_directions.items()}

    areas = []
    for area_name, area_data in BAGUA_AREAS_HOME.items():
        compass = area_data["direction"]
        kua_direction_type = direction_to_kua_meaning.get(compass)
        kua_polarity = None
        if kua_direction_type:
            kua_polarity = DIRECTION_MEANINGS[kua_direction_type]["polarity"]

        areas.append({
            "life_area":         area_name,
            "compass_direction": compass,
            "element":           area_data["element"],
            "trigram":           area_data["trigram"],
            "primary_color":     area_data["color"],
            "enhancing_materials": _enhance_materials(area_data["element"]),
            "objects_to_place":  _bagua_objects(area_name),
            "objects_to_avoid":  _bagua_avoid(area_name, area_data["element"]),
            "personal_alignment": {
                "kua_direction_type": kua_direction_type,
                "kua_polarity":       kua_polarity,
                "recommendation":     _personal_area_advice(area_name, kua_polarity),
            },
        })

    return {
        "kua_effective":     kua_effective,
        "areas":             areas,
        "usage_note":        "Stand at main entrance facing into the home. The entrance is always 'Career/North' in the BTB Bagua. Map each area accordingly.",
        "classical_source":  "Three Cycles & Nine Periods + BTB Bagua synthesis",
    }


def _enhance_materials(element: str) -> List[str]:
    materials = {
        "water": ["water features", "mirrors", "glass", "blue/black objects", "fish bowl", "fountain"],
        "wood":  ["plants (live)", "wooden furniture", "green objects", "vertical lines", "rectangular shapes"],
        "fire":  ["candles", "red/orange objects", "triangular shapes", "actual sunlight", "fireplace"],
        "earth": ["ceramics", "crystals", "yellow/brown/beige objects", "square shapes", "stones"],
        "metal": ["metal objects", "white/gray/silver objects", "round shapes", "coins", "bells, chimes"],
    }
    return materials.get(element, [])


def _bagua_objects(area: str) -> List[str]:
    objects = {
        "career":         ["water feature", "career symbols", "moving water imagery"],
        "knowledge":      ["books", "earth crystals", "study tools", "blue or earth-tone decor"],
        "family":         ["family photos", "plants", "wooden objects from parents or elders"],
        "wealth":         ["healthy plant (3 or 9 stalks)", "wealth bowl", "purple cloth", "running water"],
        "fame":           ["awards/certificates", "red candle", "bright lights", "horse imagery"],
        "relationships":  ["pairs of objects (mandarin ducks, doves)", "pink/red roses", "double-happiness symbol"],
        "creativity":     ["children's photos", "art supplies", "white metal objects", "music instruments"],
        "helpful_people": ["images of helpful figures/mentors", "metal bells", "silver/gray objects"],
        "health":         ["yellow earthen objects", "round fruits", "wellness symbols"],
    }
    return objects.get(area, [])


def _bagua_avoid(area: str, element: str) -> List[str]:
    # Each element is harmed by the one that controls it in Ke cycle
    enemy = next(k for k, v in KE_CYCLE.items() if v == element)
    return [
        f"{enemy.title()} element objects (e.g. {WU_XING[enemy]['color']} colors, {enemy} materials)",
        "clutter and broken objects",
        "trash bins, mirrors facing the bed (in relationships/bedroom sectors)",
    ]


def _personal_area_advice(area: str, kua_polarity: Optional[str]) -> str:
    if kua_polarity == "lucky":
        return f"This direction is one of your favorable directions. Strengthen the {area} aspirations here — this area will amplify naturally for you."
    elif kua_polarity == "unlucky":
        return f"This direction is one of your unfavorable directions. Place {area}-supporting objects with care; use remediation cures. Avoid spending excessive time here."
    return "Neutral direction for your Kua; standard Bagua enhancement applies."


# ════════════════════════════════════════════════════════════════════════
# 7. COMPATIBILITY — TWO PEOPLE
# ════════════════════════════════════════════════════════════════════════

def feng_shui_compatibility(person_a: Dict, person_b: Dict) -> Dict[str, Any]:
    """
    Calculate Feng Shui compatibility between two people.
    Inputs: each person has birth_year, birth_month, birth_day, gender.

    Returns: Kua group match, element interaction, year animal interaction, day master interaction.
    """
    a_kua = calculate_kua(person_a["birth_year"], person_a["gender"], person_a.get("birth_month", 6), person_a.get("birth_day", 15))
    b_kua = calculate_kua(person_b["birth_year"], person_b["gender"], person_b.get("birth_month", 6), person_b.get("birth_day", 15))

    a_animal = calculate_year_animal(a_kua["solar_year_used"])
    b_animal = calculate_year_animal(b_kua["solar_year_used"])

    a_dm = calculate_day_master(person_a["birth_year"], person_a["birth_month"], person_a["birth_day"])
    b_dm = calculate_day_master(person_b["birth_year"], person_b["birth_month"], person_b["birth_day"])

    # Kua group compatibility
    same_group = a_kua["group"] == b_kua["group"]
    kua_compatibility = "high" if same_group else "moderate (different groups can complement but require conscious effort)"

    # Element interaction (personal trigram element)
    a_el, b_el = a_kua["personal_element"], b_kua["personal_element"]
    element_relationship = _compare_elements(a_el, b_el)

    # Year animal compatibility (classical triads + clashes)
    animal_relationship = _animal_compatibility(a_animal["year_animal"], b_animal["year_animal"])

    # Day Master compatibility
    dm_relationship = _compare_elements(a_dm["day_master_element"], b_dm["day_master_element"])

    # Overall score (very simple weighted)
    score = 0
    score += 25 if same_group else 10
    score += {"highly_compatible": 25, "compatible": 18, "neutral": 12, "challenging": 6, "destructive": 2}[element_relationship["compatibility"]]
    score += {"triad": 25, "harmonious_pair": 20, "neutral": 12, "clash": 5, "destruction": 2}[animal_relationship["relationship"]]
    score += {"highly_compatible": 25, "compatible": 18, "neutral": 12, "challenging": 6, "destructive": 2}[dm_relationship["compatibility"]]

    return {
        "person_a":              {"kua": a_kua["kua_effective"], "element": a_el, "animal": a_animal["year_animal"], "day_master": a_dm["day_master_full"]},
        "person_b":              {"kua": b_kua["kua_effective"], "element": b_el, "animal": b_animal["year_animal"], "day_master": b_dm["day_master_full"]},
        "kua_groups":            {"a": a_kua["group"], "b": b_kua["group"], "same_group": same_group, "compatibility": kua_compatibility},
        "trigram_elements":      element_relationship,
        "year_animals":          animal_relationship,
        "day_masters":           dm_relationship,
        "overall_score_100":     score,
        "overall_band":          _band(score),
        "classical_source":      "Bazhai + Bazi composite compatibility — Compass School",
    }


def _compare_elements(a: str, b: str) -> Dict[str, str]:
    if a == b:
        return {"a": a, "b": b, "rule": f"Both are {a.title()}", "compatibility": "compatible", "note": "Same element — reinforcing. Strong shared values but can lead to stagnation."}
    if SHENG_CYCLE[a] == b:
        return {"a": a, "b": b, "rule": f"{a.title()} produces {b.title()} (Sheng cycle)", "compatibility": "highly_compatible", "note": f"{a.title()} person nurtures {b.title()} person."}
    if SHENG_CYCLE[b] == a:
        return {"a": a, "b": b, "rule": f"{b.title()} produces {a.title()} (Sheng cycle)", "compatibility": "highly_compatible", "note": f"{b.title()} person nurtures {a.title()} person."}
    if KE_CYCLE[a] == b:
        return {"a": a, "b": b, "rule": f"{a.title()} destroys {b.title()} (Ke cycle)", "compatibility": "challenging", "note": f"{a.title()} person can overwhelm or control {b.title()} person."}
    if KE_CYCLE[b] == a:
        return {"a": a, "b": b, "rule": f"{b.title()} destroys {a.title()} (Ke cycle)", "compatibility": "challenging", "note": f"{b.title()} person can overwhelm or control {a.title()} person."}
    return {"a": a, "b": b, "rule": "Neutral", "compatibility": "neutral", "note": "Neither cycle applies."}


def _animal_compatibility(a: str, b: str) -> Dict[str, str]:
    """
    Classical Chinese zodiac compatibility — Three Harmonies (San He) and Six Clashes (Liu Chong).
    """
    triads = [
        {"rat", "dragon", "monkey"},
        {"ox", "snake", "rooster"},
        {"tiger", "horse", "dog"},
        {"rabbit", "goat", "pig"},
    ]
    clashes = {
        ("rat", "horse"), ("ox", "goat"), ("tiger", "monkey"),
        ("rabbit", "rooster"), ("dragon", "dog"), ("snake", "pig"),
    }
    harmonious_pairs = {
        ("rat", "ox"), ("tiger", "pig"), ("rabbit", "dog"),
        ("dragon", "rooster"), ("snake", "monkey"), ("horse", "goat"),
    }

    if a == b:
        return {"a": a, "b": b, "rule": "Same animal", "relationship": "neutral", "note": "Self-reflection — strong understanding but may amplify shared weaknesses."}

    pair_set = {a, b}
    for triad in triads:
        if pair_set.issubset(triad):
            return {"a": a, "b": b, "rule": "Three Harmonies (San He) triad", "relationship": "triad", "note": "Excellent compatibility — natural allies."}

    for (x, y) in clashes:
        if pair_set == {x, y}:
            return {"a": a, "b": b, "rule": "Six Clashes (Liu Chong)", "relationship": "clash", "note": "Direct opposition — friction, growth through conflict."}

    for (x, y) in harmonious_pairs:
        if pair_set == {x, y}:
            return {"a": a, "b": b, "rule": "Six Harmonies (Liu He) pair", "relationship": "harmonious_pair", "note": "Strong, complementary compatibility."}

    # Punishments (Xing) — simplified to "destruction" band
    destructions = {("rat","goat"), ("ox","horse"), ("tiger","snake"), ("rabbit","dragon"), ("monkey","pig"), ("rooster","dog")}
    for (x, y) in destructions:
        if pair_set == {x, y}:
            return {"a": a, "b": b, "rule": "Destruction (Xiang Po)", "relationship": "destruction", "note": "Subtle undermining — requires conscious effort."}

    return {"a": a, "b": b, "rule": "No classical relation", "relationship": "neutral", "note": "Neither harmony nor clash — typical neutral pairing."}


def _band(score: int) -> str:
    if score >= 85: return "excellent"
    if score >= 70: return "very_good"
    if score >= 55: return "good"
    if score >= 40: return "average"
    if score >= 25: return "challenging"
    return "difficult"


# ════════════════════════════════════════════════════════════════════════
# 8. YEAR OUTLOOK — ANNUAL PERSONAL FORECAST
# ════════════════════════════════════════════════════════════════════════

def year_outlook(kua_effective: int, birth_year: int, target_year: int) -> Dict[str, Any]:
    """
    Synthesize a personal year outlook from Flying Stars + Year Animal compatibility.
    """
    flying = flying_stars_for_year(kua_effective, target_year)
    native_animal = calculate_year_animal(birth_year)["year_animal"]
    year_animal = calculate_year_animal(target_year)["year_animal"]
    animal_rel = _animal_compatibility(native_animal, year_animal)

    return {
        "year":                    target_year,
        "native_kua":              kua_effective,
        "native_animal":           native_animal,
        "year_animal":             year_animal,
        "animal_relationship":     animal_rel,
        "flying_stars_year":       flying,
        "key_themes":              _year_themes_for_native(flying["personal_star_nature"], animal_rel),
        "classical_source":        "Composite: Flying Stars + Zodiac (San He / Liu Chong)",
    }


def _year_themes_for_native(personal_star_nature: Optional[Dict], animal_rel: Dict) -> List[str]:
    themes = []
    if personal_star_nature:
        polarity = personal_star_nature.get("polarity", "")
        domain = personal_star_nature.get("domain", "")
        if "auspicious" in polarity:
            themes.append(f"Favorable energy in your personal palace: {domain}")
        elif "inauspicious" in polarity:
            themes.append(f"Caution in personal palace: {domain}")
    if animal_rel["relationship"] == "triad":
        themes.append("Strong year — your animal is in triad with the year animal")
    elif animal_rel["relationship"] == "clash":
        themes.append("Challenging year — your animal clashes with the year animal. Avoid major life changes if possible.")
    elif animal_rel["relationship"] == "harmonious_pair":
        themes.append("Supportive year — your animal harmonizes with the year animal.")
    return themes


# ════════════════════════════════════════════════════════════════════════
# 9. MASTER PROFILE — THE "ONE CALL GIVES EVERYTHING" ENDPOINT
# ════════════════════════════════════════════════════════════════════════

def full_personal_profile(birth_year: int, birth_month: int, birth_day: int,
                           gender: str, target_year: Optional[int] = None) -> Dict[str, Any]:
    """
    Compute the complete personal Feng Shui profile.
    This is the master endpoint — one call returns every classical reading.
    """
    target_year = target_year or datetime.now().year

    kua_data = calculate_kua(birth_year, gender, birth_month, birth_day)
    kua_effective = kua_data["kua_effective"]

    directions = get_eight_directions(kua_effective)
    year_animal = calculate_year_animal(kua_data["solar_year_used"])
    day_master = calculate_day_master(birth_year, birth_month, birth_day)
    personal_el = element_interactions(kua_data["personal_element"])
    lo_shu = calculate_lo_shu(birth_year, birth_month, birth_day)
    flying = flying_stars_for_year(kua_effective, target_year)
    bagua_home = get_bagua_home_map(kua_effective)
    year_view = year_outlook(kua_effective, birth_year, target_year)

    # Synthesis: lucky colors (from personal element + supporting element)
    lucky_colors = [personal_el["primary_color"], personal_el["supporting"]["color"], personal_el["self_strengthening"]["color"]]
    avoid_colors = [personal_el["harming"]["color"]]
    drain_colors = [personal_el["draining"]["color"]]

    # Synthesis: lucky numbers (from Kua trigram binary + Lo Shu favored positions)
    kua_lucky_numbers = {
        1: [1, 6, 7],   # Kan — water element
        2: [2, 5, 8],   # Kun — earth
        3: [3, 4, 9],   # Zhen — wood
        4: [3, 4, 9],   # Xun — wood
        6: [6, 7, 1],   # Qian — metal
        7: [6, 7, 1],   # Dui — metal
        8: [2, 5, 8],   # Gen — earth
        9: [9, 3, 4],   # Li — fire
    }
    lucky_numbers = kua_lucky_numbers.get(kua_effective, [])

    return {
        "input": {
            "birth_year":   birth_year,
            "birth_month":  birth_month,
            "birth_day":    birth_day,
            "gender":       gender,
            "target_year":  target_year,
        },
        "kua_profile":         kua_data,
        "eight_directions":    directions,
        "year_animal":         year_animal,
        "day_master":          day_master,
        "personal_element":    personal_el,
        "lo_shu_grid":         lo_shu,
        "flying_stars":        flying,
        "bagua_home_map":      bagua_home,
        "year_outlook":        year_view,
        "synthesis": {
            "lucky_colors":       lucky_colors,
            "drain_colors":       drain_colors,
            "avoid_colors":       avoid_colors,
            "lucky_numbers":      lucky_numbers,
            "best_direction":     directions["best_direction"],
            "worst_direction":    directions["worst_direction"],
            "sleep_head_to":      directions["primary_application"]["sleeping"],
            "work_facing":        directions["primary_application"]["working"],
            "career_archetype":   day_master["interpretation"]["archetype"],
            "natural_careers":    day_master["interpretation"]["career_natural"],
            "body_part_governed": kua_data["body_part_governed"],
            "key_year_themes":    year_view["key_themes"],
        },
        "classical_sources": [
            "Ba Zhai Ming Jing (Song Dynasty, ~1100 CE)",
            "Bazi Four Pillars (Tang Dynasty, ~700 CE)",
            "Lo Shu Square (pre-1000 BCE)",
            "Xuan Kong Fei Xing (Period 9: 2024–2043)",
            "Wu Xing classical cycles",
        ],
    }
