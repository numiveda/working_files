"""
iching.py — numiVeda Kaaliyo Astro Engine — Module D3 (I-Ching Engine)

10 endpoints for I-Ching (Book of Changes) consultation.

Endpoints:
    handle_profile               — Master reading (birth-seeded casting)
    handle_cast_question         — Full reading with question seed
    handle_daily_hexagram        — One hexagram for today
    handle_hexagram_lookup       — Lookup by hexagram number (1-64)
    handle_trigram_lookup        — Lookup trigram by name
    handle_changing_lines_analysis — Interpret changing lines + resultant
    handle_year_ahead_hexagrams  — 12 hexagrams, one per month
    handle_decision_hexagram     — Yes/no/proceed-wait reading
    handle_shuffle_cast          — Fresh non-deterministic cast
    handle_question_focused      — Birth+question-seeded reading

Architecture:
    - No chart casting required.
    - SHA-256-seeded RNG ensures determinism: same birth+question → same casting.
    - 3-coin method simulated: 6 lines × 3 coins → values 6/7/8/9.
    - Changing lines (6, 9) transform → produces resultant hexagram.
"""

import hashlib
import random
from datetime import datetime, date
from typing import Dict, List, Optional, Any, Tuple

from iching_data import (
    TRIGRAMS, TRIGRAM_BY_BINARY,
    HEXAGRAMS, HEXAGRAM_BY_BINARY, HEXAGRAM_BY_NUMBER,
    COIN_VALUES,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# RNG SEEDING (SHA-256 based, deterministic)
# ════════════════════════════════════════════════════════════════════════

def _seed_rng(seed_components: List[str]) -> random.Random:
    combined = "|".join(seed_components)
    h = hashlib.sha256(combined.encode("utf-8")).hexdigest()
    seed_int = int(h[:16], 16)
    return random.Random(seed_int)


def _fresh_rng() -> random.Random:
    return random.Random()


def _get_rng_for_request(birth: Optional[Dict[str, Any]],
                        endpoint_type: str,
                        context_seed: str = "",
                        fresh_shuffle: bool = False) -> random.Random:
    if fresh_shuffle or birth is None:
        return _fresh_rng()
    components = [birth.get("dob", ""), endpoint_type]
    if context_seed:
        components.append(context_seed)
    return _seed_rng(components)


# ════════════════════════════════════════════════════════════════════════
# CASTING LOGIC (3-coin method)
# ════════════════════════════════════════════════════════════════════════

def _cast_line(rng: random.Random) -> int:
    """
    3-coin method: each coin is heads(3) or tails(2). Sum of 3 coins yields 6-9.
    Statistical probabilities (traditional):
      6 (old yin):    1/8 = 12.5%
      7 (young yang): 3/8 = 37.5%
      8 (young yin):  3/8 = 37.5%
      9 (old yang):   1/8 = 12.5%
    Implementation matches probabilities.
    """
    coin_sum = sum(rng.choice([2, 3]) for _ in range(3))
    return coin_sum  # returns 6, 7, 8, or 9


def _cast_hexagram(rng: random.Random) -> Dict[str, Any]:
    """Cast 6 lines bottom-up. Return primary hexagram + changing lines + resultant."""
    line_values = [_cast_line(rng) for _ in range(6)]   # bottom to top

    # Build primary binary (1 = yang, 0 = yin)
    primary_binary = "".join("1" if v in (7, 9) else "0" for v in line_values)
    primary = HEXAGRAM_BY_BINARY.get(primary_binary)

    # Identify changing lines (6 and 9)
    changing_lines = []
    for i, v in enumerate(line_values, start=1):
        if v in (6, 9):
            changing_lines.append({
                "line":      i,  # 1-6 bottom-up
                "value":     v,
                "type":      COIN_VALUES[v]["type"],
                "transforms_to": COIN_VALUES[v]["changes_to"],
                "meaning":   primary["lines"][i-1] if primary and i-1 < len(primary["lines"]) else None,
            })

    # Compute resultant (transform changing lines)
    if changing_lines:
        resultant_binary = "".join(
            "1" if v == 6 else  # old yin → yang
            "0" if v == 9 else  # old yang → yin
            "1" if v == 7 else  # young yang stays
            "0"                 # young yin stays
            for v in line_values
        )
        resultant = HEXAGRAM_BY_BINARY.get(resultant_binary)
    else:
        resultant_binary = primary_binary
        resultant = None

    return {
        "line_values":       line_values,
        "primary_binary":    primary_binary,
        "primary":           primary,
        "changing_lines":    changing_lines,
        "has_changing_lines":len(changing_lines) > 0,
        "resultant_binary":  resultant_binary,
        "resultant":         resultant,
    }


def _format_hexagram_summary(hex_data: Dict) -> Dict[str, Any]:
    """Trim verbose data for response payload."""
    if not hex_data:
        return None
    return {
        "number":   hex_data["number"],
        "name":     hex_data["name"],
        "chinese":  hex_data.get("chinese"),
        "binary":   hex_data["binary"],
        "upper":    hex_data["upper"],
        "lower":    hex_data["lower"],
        "judgment": hex_data["judgment"],
        "image":    hex_data["image"],
    }


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT HANDLERS
# ════════════════════════════════════════════════════════════════════════

def handle_cast_question(question_text: str = "",
                         birth: Optional[Dict[str, Any]] = None,
                         fresh_shuffle: bool = False) -> Dict[str, Any]:
    """Endpoint 2: Full reading with question seed."""
    rng = _get_rng_for_request(birth, "cast_question", context_seed=question_text,
                                fresh_shuffle=fresh_shuffle)
    cast = _cast_hexagram(rng)
    return {
        "question":           question_text or "(no specific question)",
        "deterministic":      not fresh_shuffle and birth is not None,
        "method":             "3-coin casting (probabilities: 1/8 old yin, 3/8 young yang, 3/8 young yin, 1/8 old yang)",
        "line_values":        cast["line_values"],
        "primary":            _format_hexagram_summary(cast["primary"]),
        "changing_lines":     cast["changing_lines"],
        "has_changing_lines": cast["has_changing_lines"],
        "resultant":          _format_hexagram_summary(cast["resultant"]) if cast["resultant"] else None,
        "interpretation_note":(
            "Read the primary hexagram for the present situation. "
            "Changing lines indicate the active transformation points. "
            "Resultant hexagram shows the situation moving toward."
        ) if cast["has_changing_lines"] else "No changing lines — situation is stable in the primary hexagram's significance.",
        "citation":           CLASSICAL_CITATIONS["iching"],
    }


def handle_daily_hexagram(birth: Optional[Dict[str, Any]] = None,
                          target_date: Optional[str] = None,
                          fresh_shuffle: bool = False) -> Dict[str, Any]:
    """Endpoint 3: One hexagram for the target date (defaults to today)."""
    if target_date is None:
        target_date = date.today().isoformat()
    rng = _get_rng_for_request(birth, "daily_hexagram", context_seed=target_date,
                                fresh_shuffle=fresh_shuffle)
    cast = _cast_hexagram(rng)
    return {
        "target_date":     target_date,
        "deterministic":   not fresh_shuffle and birth is not None,
        "line_values":     cast["line_values"],
        "primary":         _format_hexagram_summary(cast["primary"]),
        "changing_lines":  cast["changing_lines"],
        "resultant":       _format_hexagram_summary(cast["resultant"]) if cast["resultant"] else None,
        "note":             f"Today's guidance hexagram for {target_date}. Same birth + same date = same hexagram.",
        "citation":        CLASSICAL_CITATIONS["iching"],
    }


def handle_hexagram_lookup(hexagram_number: int) -> Dict[str, Any]:
    """Endpoint 4: Lookup hexagram by King Wen number (1-64)."""
    if not isinstance(hexagram_number, int) or hexagram_number < 1 or hexagram_number > 64:
        return {"error": "hexagram_number must be int between 1 and 64"}
    hex_data = HEXAGRAM_BY_NUMBER.get(hexagram_number)
    if not hex_data:
        return {"error": f"Hexagram {hexagram_number} not found"}
    return {
        **hex_data,
        "citation": CLASSICAL_CITATIONS["iching"],
    }


def handle_trigram_lookup(trigram_name: Optional[str] = None) -> Dict[str, Any]:
    """Endpoint 5: Lookup trigram by name (Heaven/Earth/Thunder/etc.) or get all."""
    if trigram_name is None:
        return {
            "all_trigrams":  TRIGRAMS,
            "trigram_count": len(TRIGRAMS),
            "citation":      CLASSICAL_CITATIONS["trigrams"],
        }
    name_normalized = trigram_name.strip().capitalize()
    if name_normalized in TRIGRAMS:
        return {
            "trigram":       name_normalized,
            **TRIGRAMS[name_normalized],
            "citation":      CLASSICAL_CITATIONS["trigrams"],
        }
    return {
        "error":          f"Trigram '{trigram_name}' not found",
        "valid_options":  list(TRIGRAMS.keys()),
    }


def handle_changing_lines_analysis(hexagram_number: int,
                                   changing_line_numbers: List[int]) -> Dict[str, Any]:
    """Endpoint 6: Interpret changing lines of a specific hexagram + compute resultant."""
    if not isinstance(hexagram_number, int) or hexagram_number < 1 or hexagram_number > 64:
        return {"error": "hexagram_number must be int between 1 and 64"}
    primary = HEXAGRAM_BY_NUMBER.get(hexagram_number)
    if not primary:
        return {"error": f"Hexagram {hexagram_number} not found"}

    # Validate changing line numbers (1-6)
    valid_lines = [l for l in changing_line_numbers if isinstance(l, int) and 1 <= l <= 6]
    if not valid_lines:
        return {
            "primary":          _format_hexagram_summary(primary),
            "changing_lines":   [],
            "note":              "No changing lines specified — primary hexagram stands as full guidance",
            "citation":         CLASSICAL_CITATIONS["iching"],
        }

    # Build resultant: flip changing-line bits
    primary_bits = list(primary["binary"])
    for line_num in valid_lines:
        idx = line_num - 1  # binary is bottom-up
        primary_bits[idx] = "1" if primary_bits[idx] == "0" else "0"
    resultant_binary = "".join(primary_bits)
    resultant = HEXAGRAM_BY_BINARY.get(resultant_binary)

    # Compile changing line meanings
    line_meanings: List[Dict[str, str]] = []
    for line_num in valid_lines:
        idx = line_num - 1
        if idx < len(primary["lines"]):
            line_meanings.append({
                "line":     line_num,
                "meaning":  primary["lines"][idx],
            })

    return {
        "primary":         _format_hexagram_summary(primary),
        "changing_lines":  line_meanings,
        "resultant":       _format_hexagram_summary(resultant),
        "interpretation":  (
            f"Primary {primary['name']} → Resultant {resultant['name']} via "
            f"changing line(s) {valid_lines}. The transformation moves from "
            f"'{primary['judgment'][:60]}...' toward '{resultant['judgment'][:60]}...'."
        ) if resultant else "Resultant computation failed",
        "citation":        CLASSICAL_CITATIONS["iching"],
    }


def handle_year_ahead_hexagrams(birth: Optional[Dict[str, Any]] = None,
                                start_year: Optional[int] = None,
                                fresh_shuffle: bool = False) -> Dict[str, Any]:
    """Endpoint 7: 12 hexagrams, one per month."""
    if start_year is None:
        start_year = date.today().year
    rng = _get_rng_for_request(birth, "year_ahead_hexagrams",
                                context_seed=f"year_{start_year}",
                                fresh_shuffle=fresh_shuffle)
    months_named = ["January", "February", "March", "April", "May", "June",
                    "July", "August", "September", "October", "November", "December"]
    monthly_hexagrams: List[Dict[str, Any]] = []
    for i in range(12):
        cast = _cast_hexagram(rng)
        monthly_hexagrams.append({
            "month_number":    i + 1,
            "month_name":      months_named[i],
            "year":            start_year,
            "primary":         _format_hexagram_summary(cast["primary"]),
            "changing_lines":  cast["changing_lines"],
            "resultant":       _format_hexagram_summary(cast["resultant"]) if cast["resultant"] else None,
        })
    return {
        "start_year":          start_year,
        "deterministic":       not fresh_shuffle and birth is not None,
        "monthly_hexagrams":   monthly_hexagrams,
        "month_count":         12,
        "citation":            CLASSICAL_CITATIONS["iching"],
    }


def handle_decision_hexagram(decision_context: str = "",
                             birth: Optional[Dict[str, Any]] = None,
                             fresh_shuffle: bool = False) -> Dict[str, Any]:
    """Endpoint 8: Yes/no/proceed-wait reading."""
    rng = _get_rng_for_request(birth, "decision_hexagram",
                                context_seed=decision_context, fresh_shuffle=fresh_shuffle)
    cast = _cast_hexagram(rng)
    primary = cast["primary"]
    resultant = cast["resultant"]

    # Interpret as decision verdict based on hexagram themes
    # Auspicious hexagrams (proceed): 1, 11, 14, 15, 16, 19, 24, 34, 41, 42, 46, 50, 55, 58, 59
    # Cautionary hexagrams (wait/no): 6, 12, 23, 29, 33, 36, 39, 47, 51, 60
    # Mixed: all others
    auspicious = {1, 11, 14, 15, 16, 19, 24, 34, 41, 42, 46, 50, 55, 58, 59}
    cautionary = {6, 12, 23, 29, 33, 36, 39, 47, 51, 60}
    primary_num = primary["number"] if primary else None

    if primary_num in auspicious:
        verdict = "PROCEED — favorable signs"
    elif primary_num in cautionary:
        verdict = "WAIT — cautionary signs; reconsider timing"
    else:
        verdict = "MIXED — proceed with awareness; conditions are conditional"

    # If changing lines present, suggest the resultant direction matters more
    if cast["has_changing_lines"] and resultant:
        verdict += f" | Direction of change: {resultant['name']}"

    return {
        "decision_context":  decision_context or "(no specific decision)",
        "deterministic":     not fresh_shuffle and birth is not None,
        "verdict":           verdict,
        "primary":           _format_hexagram_summary(primary),
        "changing_lines":    cast["changing_lines"],
        "resultant":         _format_hexagram_summary(resultant) if resultant else None,
        "note":              "Decision verdict is engine-mapped from hexagram archetypes; for nuanced reading, consult the judgment + image + changing line meanings of the primary and resultant hexagrams.",
        "citation":          CLASSICAL_CITATIONS["iching"],
    }


def handle_shuffle_cast() -> Dict[str, Any]:
    """Endpoint 9: Fresh non-deterministic cast (true random)."""
    rng = _fresh_rng()
    cast = _cast_hexagram(rng)
    return {
        "fresh_cast":      True,
        "deterministic":   False,
        "line_values":     cast["line_values"],
        "primary":         _format_hexagram_summary(cast["primary"]),
        "changing_lines":  cast["changing_lines"],
        "resultant":       _format_hexagram_summary(cast["resultant"]) if cast["resultant"] else None,
        "note":             "Fresh non-deterministic cast — not reproducible. For personal recurring guidance, use cast_question with birth+question.",
        "citation":        CLASSICAL_CITATIONS["iching"],
    }


def handle_question_focused(question_text: str,
                            birth: Optional[Dict[str, Any]] = None,
                            fresh_shuffle: bool = False) -> Dict[str, Any]:
    """Endpoint 10: Birth+question-seeded reading (alias of cast_question with required question)."""
    if not question_text or not question_text.strip():
        return {"error": "question_text is required"}
    return handle_cast_question(question_text.strip(), birth, fresh_shuffle)


def handle_profile(birth: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Endpoint 1 (MASTER): Birth-anchored I-Ching synthesis."""
    daily = handle_daily_hexagram(birth, date.today().isoformat())
    life_reading = handle_cast_question(question_text="my life path",
                                         birth=birth, fresh_shuffle=False)

    headlines: List[str] = []
    if daily.get("primary"):
        p = daily["primary"]
        headlines.append(f"Today's hexagram: #{p['number']} {p['name']}")
    if life_reading.get("primary"):
        p = life_reading["primary"]
        headlines.append(f"Life-path hexagram: #{p['number']} {p['name']}")
        if life_reading.get("resultant"):
            r = life_reading["resultant"]
            headlines.append(f"Direction of change: → #{r['number']} {r['name']}")

    return {
        "headlines":      headlines,
        "daily":          daily,
        "life_path":      life_reading,
        "method":         "Birth-anchored deterministic 3-coin casting via SHA-256 seeded RNG. Same birth = consistent personal readings.",
        "citation":       CLASSICAL_CITATIONS["iching"],
    }
