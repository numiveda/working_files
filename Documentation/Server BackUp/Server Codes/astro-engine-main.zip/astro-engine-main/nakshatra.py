"""
nakshatra.py — numiVeda Astro Engine

The main nakshatra analysis module.

Public API:
    analyze_full(chart)                     -> Janma + Surya + Lagna + all planets
    analyze_janma(chart)                    -> Just Moon nakshatra deep dive
    analyze_all_planets(chart)              -> All 9 planets with full nakshatra attrs
    analyze_tara(chart, transit_chart=None) -> 27-Tara cycle from Janma
    analyze_compatibility(nak1, nak2)       -> Standalone compatibility scoring
    get_static(name)                        -> Pure encyclopedia lookup (no chart)

All return pure structured data — no narrative prose. LLMs handle writing.
"""

from typing import Dict, Any, List, Optional
from nakshatra_data import (
    NAKSHATRAS, NAKSHATRA_BY_NAME, TARA_TYPES,
    GANA_COMPATIBILITY, YONI_ENEMY_PAIRS, NADI_COMPATIBILITY,
)
from nakshatra_padas import PADAS, get_nakshatra_and_pada


# ─────────────────────────────────────────────────────────────────────────────
# CHART READERS — pull nakshatra info from dashaflow.cast_chart() output
# ─────────────────────────────────────────────────────────────────────────────

def _read_planet(chart: dict, planet: str) -> Dict[str, Any]:
    """Read a planet's nakshatra data from cast_chart() output."""
    p = chart.get("planets", {}).get(planet, {})
    return {
        "nakshatra_name": p.get("nakshatra", ""),
        "pada":           p.get("pada", 0),
        "nakshatra_lord": p.get("nakshatra_lord", ""),
        "sign":           p.get("sign", ""),
        "longitude":      p.get("longitude", p.get("lon", 0.0)),
        "retrograde":     p.get("retrograde", p.get("isRetro", False)),
    }


def _read_lagna(chart: dict) -> Dict[str, Any]:
    """Read ascendant's nakshatra info if available, else compute from longitude."""
    asc = chart.get("ascendant", {}) or chart.get("lagna", {})
    if "nakshatra" in asc:
        return {
            "nakshatra_name": asc.get("nakshatra", ""),
            "pada":           asc.get("pada", 0),
            "nakshatra_lord": asc.get("nakshatra_lord", ""),
            "sign":           asc.get("sign", ""),
            "longitude":      asc.get("longitude", asc.get("lon", 0.0)),
        }
    # Fallback: compute from longitude
    lon = asc.get("longitude", asc.get("lon", 0.0))
    nak_idx, pada = get_nakshatra_and_pada(lon)
    nak_data = NAKSHATRAS.get(nak_idx, {})
    return {
        "nakshatra_name": nak_data.get("name_en", ""),
        "pada":           pada,
        "nakshatra_lord": nak_data.get("lord", ""),
        "sign":           asc.get("sign", ""),
        "longitude":      lon,
    }


# ─────────────────────────────────────────────────────────────────────────────
# CORE BUILDER — assemble the full attribute block for one nakshatra+pada
# ─────────────────────────────────────────────────────────────────────────────

def _build_attributes(nakshatra_name: str, pada: int) -> Dict[str, Any]:
    """
    Build the rich attribute block: all 16 nakshatra attrs + 9 pada sub-attrs.
    """
    nak_key = nakshatra_name.lower()
    if nak_key not in NAKSHATRA_BY_NAME:
        return {"error": f"Unknown nakshatra: {nakshatra_name}"}

    nak = NAKSHATRA_BY_NAME[nak_key]
    nak_idx = nak["index"]

    pada_data = PADAS.get((nak_idx, pada), {})

    return {
        # Identity
        "nakshatra_index":   nak_idx,
        "name_en":           nak["name_en"],
        "name_sa":           nak["name_sa"],
        "pada":              pada,
        "rashi_span":        nak.get("rashi_span", []),
        "range_deg":         nak.get("range_deg", []),

        # The 16 classical attributes
        "lord":              {"en": nak["lord"],     "sa": nak.get("lord_sa", "")},
        "deity":             {"en": nak["deity"],    "sa": nak.get("deity_sa", ""), "role": nak.get("deity_role", "")},
        "symbol":            {"en": nak["symbol"],   "sa": nak.get("symbol_sa", "")},
        "gana":              {"en": nak["gana"],     "sa": nak.get("gana_sa", "")},
        "yoni":              {"en": nak["yoni"],     "sa": nak.get("yoni_sa", ""), "gender": nak.get("yoni_gender", "")},
        "varna":             {"en": nak["varna"],    "sa": nak.get("varna_sa", "")},
        "nadi":              {"en": nak["nadi"],     "sa": nak.get("nadi_sa", "")},
        "paya":              {"en": nak["paya"],     "sa": nak.get("paya_sa", "")},
        "tatva":             {"en": nak["tatva"],    "sa": nak.get("tatva_sa", "")},
        "guna":              {"en": nak["guna"],     "sa": nak.get("guna_sa", "")},
        "caste_direction":   nak.get("caste_direction", ""),
        "body_part":         nak.get("body_part", ""),
        "motion":            {"en": nak["motion"],   "sa": nak.get("motion_sa", "")},
        "shakti":            {"en": nak["shakti"],   "sa": nak.get("shakti_sa", "")},
        "akshara_set":       nak.get("akshara_set", []),
        "spiritual_lesson":  nak.get("spiritual_lesson", ""),

        # Deep narrative-ready data
        "mythology":         nak.get("mythology", ""),
        "life_theme":        nak.get("life_theme", ""),
        "career_pointers":   nak.get("career_pointers", []),
        "personality_traits":nak.get("personality_traits", []),

        # Pada-level sub-attributes
        "pada_attributes": {
            "navamsa_sign":          pada_data.get("navamsa_sign", ""),
            "sub_lord":              pada_data.get("sub_lord", ""),
            "akshara":               pada_data.get("akshara", ""),
            "akshara_sa":            pada_data.get("akshara_sa", ""),
            "body_part_pada":        pada_data.get("body_part_pada", ""),
            "career_nuance":         pada_data.get("career_nuance", ""),
            "relationship_pattern":  pada_data.get("relationship_pattern", ""),
            "spiritual_lesson_pada": pada_data.get("spiritual_lesson_pada", ""),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# 1. FULL ANALYSIS — Janma + Surya + Lagna + all planets
# ─────────────────────────────────────────────────────────────────────────────

def analyze_full(chart: dict) -> Dict[str, Any]:
    """
    Returns the three pillars (Janma/Surya/Lagna) + nakshatra summary per all 9 planets.
    """
    moon = _read_planet(chart, "Moon")
    sun  = _read_planet(chart, "Sun")
    lagna = _read_lagna(chart)

    out: Dict[str, Any] = {
        "janma_nakshatra":  {
            "_source": "Moon",
            "longitude": moon["longitude"],
            **_build_attributes(moon["nakshatra_name"], moon["pada"]),
        },
        "surya_nakshatra":  {
            "_source": "Sun",
            "longitude": sun["longitude"],
            **_build_attributes(sun["nakshatra_name"], sun["pada"]),
        },
        "lagna_nakshatra":  {
            "_source": "Ascendant",
            "longitude": lagna["longitude"],
            **_build_attributes(lagna["nakshatra_name"], lagna["pada"]),
        },
        "all_planets_summary": {},
    }

    # Brief per-planet summary (compact, for the chat app's chart overview)
    for planet in ("Sun", "Moon", "Mars", "Mercury", "Jupiter",
                   "Venus", "Saturn", "Rahu", "Ketu"):
        p = _read_planet(chart, planet)
        if not p["nakshatra_name"]:
            continue
        nak_key = p["nakshatra_name"].lower()
        nak = NAKSHATRA_BY_NAME.get(nak_key, {})
        out["all_planets_summary"][planet] = {
            "nakshatra":      p["nakshatra_name"],
            "nakshatra_sa":   nak.get("name_sa", ""),
            "pada":           p["pada"],
            "nakshatra_lord": p["nakshatra_lord"],
            "sign":           p["sign"],
        }

    return out


# ─────────────────────────────────────────────────────────────────────────────
# 2. JANMA ONLY — Moon nakshatra deep dive
# ─────────────────────────────────────────────────────────────────────────────

def analyze_janma(chart: dict) -> Dict[str, Any]:
    """Just the Moon nakshatra — the most important single endpoint."""
    moon = _read_planet(chart, "Moon")
    return {
        "_source":   "Moon",
        "longitude": moon["longitude"],
        **_build_attributes(moon["nakshatra_name"], moon["pada"]),
    }


# ─────────────────────────────────────────────────────────────────────────────
# 3. ALL PLANETS — full nakshatra attrs for every planet (heavy payload)
# ─────────────────────────────────────────────────────────────────────────────

def analyze_all_planets(chart: dict) -> Dict[str, Any]:
    """Full nakshatra + pada attributes for all 9 planets."""
    result: Dict[str, Any] = {}
    for planet in ("Sun", "Moon", "Mars", "Mercury", "Jupiter",
                   "Venus", "Saturn", "Rahu", "Ketu"):
        p = _read_planet(chart, planet)
        if not p["nakshatra_name"]:
            continue
        result[planet] = {
            "_planet":   planet,
            "longitude": p["longitude"],
            "retrograde": p["retrograde"],
            **_build_attributes(p["nakshatra_name"], p["pada"]),
        }
    return {"planets": result}


# ─────────────────────────────────────────────────────────────────────────────
# 4. 27-TARA CYCLE — from Janma, what tara is the current Moon transit?
# ─────────────────────────────────────────────────────────────────────────────

def analyze_tara(chart: dict, transit_chart: Optional[dict] = None) -> Dict[str, Any]:
    """
    Returns the 9-fold Tara cycle starting from Janma nakshatra, repeated 3 times
    to cover all 27 nakshatras. Each transit nakshatra (1-27) maps to one of the
    9 Tara types relative to Janma.

    If transit_chart is provided, also returns the current Tara state from today's
    Moon transit.
    """
    moon = _read_planet(chart, "Moon")
    nak_key = moon["nakshatra_name"].lower()
    if nak_key not in NAKSHATRA_BY_NAME:
        return {"error": f"Unknown Janma nakshatra: {moon['nakshatra_name']}"}

    janma_idx = NAKSHATRA_BY_NAME[nak_key]["index"]

    # Build the full 27-nakshatra map: for each transit nakshatra,
    # which Tara is it relative to Janma?
    tara_map: List[Dict[str, Any]] = []
    for n in range(1, 28):
        # Offset from Janma (1-indexed): how many nakshatras forward to reach n
        offset = (n - janma_idx) % 27
        tara_idx = (offset % 9) + 1  # cycles 1..9
        tara_info = TARA_TYPES[tara_idx - 1]
        nak_data = NAKSHATRAS[n]
        tara_map.append({
            "transit_nakshatra_idx": n,
            "transit_nakshatra_en":  nak_data["name_en"],
            "transit_nakshatra_sa":  nak_data["name_sa"],
            "tara_idx":              tara_idx,
            "tara_name_en":          tara_info["name_en"],
            "tara_name_sa":          tara_info["name_sa"],
            "nature":                tara_info["nature"],
            "effect":                tara_info["effect"],
        })

    result: Dict[str, Any] = {
        "janma_nakshatra":   moon["nakshatra_name"],
        "janma_nakshatra_idx": janma_idx,
        "tara_cycle":        tara_map,
        "tara_types_reference": TARA_TYPES,
    }

    # Current tara if transit chart given
    if transit_chart:
        t_moon = _read_planet(transit_chart, "Moon")
        t_nak_key = t_moon["nakshatra_name"].lower()
        if t_nak_key in NAKSHATRA_BY_NAME:
            t_idx = NAKSHATRA_BY_NAME[t_nak_key]["index"]
            current = next((t for t in tara_map if t["transit_nakshatra_idx"] == t_idx), None)
            if current:
                result["current_tara"] = current

    return result


# ─────────────────────────────────────────────────────────────────────────────
# 5. COMPATIBILITY — standalone Rajju/Vedha/Gana/Nadi/Yoni between two nakshatras
# ─────────────────────────────────────────────────────────────────────────────

def analyze_compatibility(nak1_name: str, nak2_name: str) -> Dict[str, Any]:
    """
    Returns standalone compatibility scoring between two nakshatras.
    Useful for quick checks without re-running full Ashtakoot.
    """
    k1 = nak1_name.lower()
    k2 = nak2_name.lower()
    if k1 not in NAKSHATRA_BY_NAME or k2 not in NAKSHATRA_BY_NAME:
        return {"error": f"Unknown nakshatra(s): {nak1_name}, {nak2_name}"}

    n1 = NAKSHATRA_BY_NAME[k1]
    n2 = NAKSHATRA_BY_NAME[k2]

    # Gana compatibility
    g1, g2 = n1["gana"], n2["gana"]
    key = tuple(sorted([g1, g2]))
    # Normalize lookup: GANA_COMPATIBILITY has ordered keys; build symmetric
    gana_score = None
    for (a, b), v in GANA_COMPATIBILITY.items():
        if {a, b} == {g1, g2}:
            gana_score = v
            break
    gana_score = gana_score or {"score": 0, "level": "Unknown", "note": ""}

    # Nadi compatibility
    nadi_score = None
    for (a, b), v in NADI_COMPATIBILITY.items():
        if {a, b} == {n1["nadi"], n2["nadi"]}:
            nadi_score = v
            break
    nadi_score = nadi_score or {"score": 0, "level": "Unknown", "note": ""}

    # Yoni — same yoni = excellent; enemy pair = bad; otherwise mixed
    y1, y2 = n1["yoni"], n2["yoni"]
    if y1 == y2:
        yoni_score = {"score": 4, "level": "Excellent", "note": f"Same yoni ({y1}) — natural harmony"}
    elif {y1, y2} in [set(p) for p in YONI_ENEMY_PAIRS]:
        yoni_score = {"score": 0, "level": "Poor",      "note": f"Enemy yoni pair ({y1}–{y2}) — friction"}
    else:
        yoni_score = {"score": 2, "level": "Neutral",   "note": f"Different yonis ({y1}, {y2}) — workable"}

    # Varna — descending compatibility (Brahmin > Kshatriya > Vaishya > Shudra)
    varna_rank = {"Brahmin": 4, "Kshatriya": 3, "Vaishya": 2, "Shudra": 1, "Mlechha": 0, "Butcher": 0, "Servant": 0}
    v1 = varna_rank.get(n1["varna"], 0)
    v2 = varna_rank.get(n2["varna"], 0)
    if v1 >= v2:
        varna_score = {"score": 1, "level": "OK", "note": "Male native's varna ≥ partner's"}
    else:
        varna_score = {"score": 0, "level": "Caution", "note": "Female partner's varna > male — traditional caution"}

    # Total summary
    total = (gana_score["score"] + nadi_score["score"] +
             yoni_score["score"] + varna_score["score"])

    return {
        "nakshatra_1": {"en": n1["name_en"], "sa": n1.get("name_sa", "")},
        "nakshatra_2": {"en": n2["name_en"], "sa": n2.get("name_sa", "")},
        "gana":  gana_score,
        "nadi":  nadi_score,
        "yoni":  yoni_score,
        "varna": varna_score,
        "summary_score":  total,
        "max_possible":   19,
        "interpretation": (
            "Excellent overall match" if total >= 15 else
            "Good match with minor frictions" if total >= 10 else
            "Workable but needs effort" if total >= 6 else
            "Significant frictions — consider with care"
        ),
        "note": (
            "This is a 4-factor subset of the full 8-Ashtakoot. "
            "Full marriage compatibility should use /astro/compatibility."
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
# 6. STATIC ENCYCLOPEDIA — pure lookup (no chart)
# ─────────────────────────────────────────────────────────────────────────────

def get_static(name: str, pada: Optional[int] = None) -> Dict[str, Any]:
    """
    Pure encyclopedia lookup. Pass a nakshatra name (and optional pada 1-4).
    Used by the chat app to fetch facts mid-conversation without a chart.
    """
    if pada is None:
        pada = 1
    if pada < 1 or pada > 4:
        return {"error": "pada must be 1-4"}

    nak_key = name.lower().strip()
    if nak_key not in NAKSHATRA_BY_NAME:
        # Try fuzzy alternatives
        alternatives = [k for k in NAKSHATRA_BY_NAME if nak_key in k or k in nak_key]
        return {
            "error": f"Unknown nakshatra: '{name}'",
            "suggestions": alternatives[:5],
        }

    return _build_attributes(NAKSHATRA_BY_NAME[nak_key]["name_en"], pada)
