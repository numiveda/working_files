"""
pitra_dosha.py — numiVeda Kaaliyo Astro Engine — Module F2b (Pitra Dosha)

Three endpoints for ancestral-debt / Sun-affliction analysis:
    handle_pitra_dosha_profile          — Detect classical Pitra Dosha signatures
    handle_pitra_dosha_intensity        — Score 0-100 + which signatures contributed
    handle_pitra_dosha_remedies_timing  — Mahalaya Paksha windows + remedies (tradition-marked)

Design (per HANDOVER_v4 carry-forward + F1a/F2a lessons):
    P1 — Swiss Ephemeris is the source. cast_chart for all natal/transit work.
    P2 — Reuse: imports `handle_natal_eclipses` from eclipse.py for the
         "Surya grahan" (eclipse-on-Sun) signature — F2a paid off.
         Imports cast_chart for Mahalaya iteration.
    P3 — No duplication. Mahalaya logic is iterative panchang scan, not
         a parallel computation of lunar position.

Public API:
    handle_pitra_dosha_profile(birth) -> dict
    handle_pitra_dosha_intensity(birth) -> dict
    handle_pitra_dosha_remedies_timing(birth, query_date=None, years_ahead=5) -> dict

Module constants:
    MAHALAYA_YEARS_DEFAULT = 5
    MAHALAYA_YEARS_MAX = 50

Author: Claude (F2b, 2026-05-17)
"""

from typing import Dict, List, Optional, Any
from datetime import date, datetime, timedelta

# Foundation imports — guarded at module load (Principle 1)
try:
    from dashaflow import cast_chart
except ImportError as e:
    raise ImportError(f"F2b pitra_dosha requires dashaflow.cast_chart: {e}")

try:
    from astro_helpers import SIGNS_ORDER, SIGN_TO_LORD
except ImportError as e:
    raise ImportError(f"F2b pitra_dosha requires astro_helpers: {e}")

try:
    from eclipse import handle_natal_eclipses as _ecl_handle_natal_eclipses
except ImportError as e:
    raise ImportError(f"F2b pitra_dosha requires eclipse.handle_natal_eclipses (F2a): {e}")


# ════════════════════════════════════════════════════════════════════════
# MODULE CONSTANTS
# ════════════════════════════════════════════════════════════════════════

MAHALAYA_YEARS_DEFAULT = 5
MAHALAYA_YEARS_MAX = 50

# Sun-affliction degree orb (within how many degrees of Rahu/Ketu/Saturn
# do we count as "afflicting" by conjunction — same-house is the broader trigger)
PITRA_CONJ_ORB_DEGREES = 10.0


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

F2B_CITATIONS = {
    "profile": [
        "Brihat Parashara Hora Shastra Ch. 32 — Afflictions to Sun and to the 9th house indicate Pitra Dosha",
        "Brihat Jataka Ch. 2 — Sun is the universal Pita karaka (father-significator)",
        "Phaladeepika Ch. 6 — Rahu-Ketu conjunction/aspect to Sun classical trigger",
        "Saravali Ch. 6 — Saturn-Sun malefic combinations afflict the paternal line",
        "Jataka Parijata Ch. 4 — 9th house and its lord as 'pita bhava' / dharma karaka",
    ],
    "intensity": [
        "BPHS Ch. 32 — combined weight of affliction sources determines dosha severity",
        "Phaladeepika Ch. 6 — multiple simultaneous afflictions classically intensify the dosha",
        "Sarvartha Chintamani — natal eclipses on Sun (Surya grahan) reinforce ancestral karma signature",
    ],
    "remedies_timing": [
        "Garuda Purana Ch. 12 — Pitru Paksha (Krishna Paksha of Bhadrapada-Ashvin) is the classical remediation window",
        "Skanda Purana — Mahalaya Amavasya as the most potent day for Pitru Tarpana",
        "Vishnu Purana Book III Ch. 13-15 — Tarpana procedure and ancestral offerings",
        "Yajnavalkya Smriti — Shraddha (rite of ancestor remembrance) tradition",
        "Manusmriti Ch. 3 — Pinda-Dana (rice-ball offerings) for the three preceding generations",
    ],
}


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL TRADITION (NOT prescription) — for remedies endpoint
# Marked as 'tradition' per F2b scope decision (Q2 = Option 3)
# ════════════════════════════════════════════════════════════════════════

PITRA_REMEDIES_TRADITION = {
    "tarpana": {
        "description": ("Water offering to ancestors performed daily during Pitru Paksha. "
                        "Classically uses water mixed with black sesame seeds, offered to the south "
                        "(direction of ancestors per Garuda Purana)."),
        "timing":      "Daily during Pitru Paksha; especially potent on Mahalaya Amavasya",
        "source":      "Vishnu Purana Book III Ch. 13",
    },
    "pinda_dana": {
        "description": ("Rice-ball offering for the three preceding paternal generations "
                        "(father, grandfather, great-grandfather). Traditionally performed by "
                        "eldest son but any descendant may offer."),
        "timing":      "On Mahalaya Amavasya or the tithi corresponding to the ancestor's death-tithi",
        "source":      "Manusmriti Ch. 3.122-152",
    },
    "shraddha": {
        "description": ("Rite of ancestor remembrance involving recitation, donation, and food offering "
                        "to brahmins/the needy. Symbolically nourishes the ancestral line."),
        "timing":      "On the tithi of the ancestor's passing (Tithi-Shraddha) and during Pitru Paksha",
        "source":      "Yajnavalkya Smriti Acharadhyaya",
    },
    "donation": {
        "description": ("Classical recommendation: donate sesame seeds (black or white), iron, "
                        "blanket, ghee, and food to brahmins or the needy on behalf of ancestors. "
                        "Specifically benefits during Pitru Paksha."),
        "timing":      "Throughout Pitru Paksha; emphasis on Mahalaya Amavasya",
        "source":      "Garuda Purana Ch. 12",
    },
    "narayana_bali": {
        "description": ("Vedic ritual specifically prescribed for ancestors who died unnaturally "
                        "or whose post-death rites were incomplete. Performed at sacred tirthas "
                        "(traditionally Gaya, Trimbakeshwar, Rameshwaram)."),
        "timing":      "Any auspicious muhurta; emphasis on lunar Bhadrapada and Pitru Paksha",
        "source":      "Garuda Purana; Tristhali Setu commentary",
    },
}


# ════════════════════════════════════════════════════════════════════════
# CORE PRIMITIVES (extraction from cast_chart)
# ════════════════════════════════════════════════════════════════════════

def _to_absolute_longitude(sign: Optional[str], degree: Optional[float]) -> Optional[float]:
    """Sign + degree-in-sign → 0-360 sidereal longitude."""
    if not sign or sign not in SIGNS_ORDER or degree is None:
        return None
    return SIGNS_ORDER.index(sign) * 30 + degree


def _angular_distance(deg1: Optional[float], deg2: Optional[float]) -> Optional[float]:
    if deg1 is None or deg2 is None:
        return None
    diff = abs(deg1 - deg2) % 360
    return min(diff, 360 - diff)


def _extract_pitra_primitives(birth: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract everything F2b needs from a single cast_chart call.
    Returns nested dict with Sun/Rahu/Ketu/Saturn data + 9H lord + active dasha.
    """
    chart = cast_chart(
        dob=birth["dob"], time=birth["time"],
        lat=birth["lat"], lon=birth["lon"],
        timezone=birth.get("timezone", "Asia/Kolkata"),
    )

    sun = chart["planets"]["Sun"]
    rahu = chart["planets"]["Rahu"]
    ketu = chart["planets"]["Ketu"]
    saturn = chart["planets"]["Saturn"]
    moon = chart["planets"]["Moon"]
    lagna = chart["lagna"]

    sun_long = _to_absolute_longitude(sun.get("sign"), sun.get("degree"))
    rahu_long = _to_absolute_longitude(rahu.get("sign"), rahu.get("degree"))
    ketu_long = _to_absolute_longitude(ketu.get("sign"), ketu.get("degree"))
    saturn_long = _to_absolute_longitude(saturn.get("sign"), saturn.get("degree"))

    # 9th lord
    lagna_sign = lagna.get("sign")
    ninth_lord_planet = None
    ninth_lord_data = None
    ninth_sign = None
    if lagna_sign in SIGNS_ORDER:
        ninth_idx = (SIGNS_ORDER.index(lagna_sign) + 8) % 12
        ninth_sign = SIGNS_ORDER[ninth_idx]
        ninth_lord_planet = SIGN_TO_LORD.get(ninth_sign)
        if ninth_lord_planet and ninth_lord_planet in chart["planets"]:
            ninth_lord_data = chart["planets"][ninth_lord_planet]

    # Find planets in same house as Sun
    sun_house = sun.get("house")
    sun_housemates = [p for p, d in chart["planets"].items()
                       if p != "Sun" and d.get("house") == sun_house]

    # Find planets aspecting Sun (Vedic 3/7/10 + special)
    sun_sign = sun.get("sign")
    aspecting_sun = []
    for pname, pdata in chart["planets"].items():
        if pname == "Sun":
            continue
        if sun_sign in pdata.get("aspects", []):
            aspecting_sun.append(pname)

    # Active dasha for remedies timing
    dashas = chart.get("dashas", {})
    md = dashas.get("maha", {})
    ad = dashas.get("antar", {})

    return {
        "lagna_sign":    lagna_sign,
        "sun": {
            **{k: sun.get(k) for k in
                ("sign", "degree", "house", "nakshatra",
                 "dignity", "is_combust", "is_retrograde")},
            "longitude": sun_long,
        },
        "rahu": {
            **{k: rahu.get(k) for k in ("sign", "degree", "house", "aspects")},
            "longitude": rahu_long,
        },
        "ketu": {
            **{k: ketu.get(k) for k in ("sign", "degree", "house", "aspects")},
            "longitude": ketu_long,
        },
        "saturn": {
            **{k: saturn.get(k) for k in ("sign", "degree", "house", "dignity", "aspects")},
            "longitude": saturn_long,
        },
        "moon_sign":         moon.get("sign"),
        "ninth_house_sign":  ninth_sign,
        "ninth_lord_planet": ninth_lord_planet,
        "ninth_lord_data":   ninth_lord_data,
        "sun_housemates":    sun_housemates,
        "planets_aspecting_sun": aspecting_sun,
        "active_md":         md,
        "active_ad":         ad,
    }


# ════════════════════════════════════════════════════════════════════════
# SIGNATURE DETECTION
# ════════════════════════════════════════════════════════════════════════

def _detect_signatures(prim: Dict[str, Any],
                        birth: Dict[str, Any]) -> Dict[str, Any]:
    """
    Detect classical Pitra Dosha signatures. Returns:
      {
        "signatures":      [...list of detected signatures...],
        "types_evaluated": int  # how many distinct signature types we checked
      }

    Each signature entry: {name, present, severity (1-3), evidence (text), source}

    Severity scale:
      1 = mild signature  (counts but not dominant)
      2 = moderate
      3 = strong/primary

    # ── U13: signature type counting refactor (2026-05-18) ──
    Signature type evaluation count:
      - Signatures 1-5b always evaluated: 7 types
      - Signature 6 (9th lord) evaluated only when nl_data available: +3 types
      - Signature 8 (Surya grahan) always evaluated: +1 type
      Total: 8 minimum, 11 typical (when 9th lord data present)
    """
    sigs: List[Dict[str, Any]] = []
    types_evaluated: int = 0
    sun = prim["sun"]
    rahu = prim["rahu"]
    ketu = prim["ketu"]
    saturn = prim["saturn"]

    # ── Signature 1: Sun-Rahu conjunction (classical PRIMARY trigger) ──
    types_evaluated += 1
    sun_rahu_same_house = (sun.get("house") == rahu.get("house"))
    sun_rahu_close = False
    sr_dist = _angular_distance(sun.get("longitude"), rahu.get("longitude"))
    if sr_dist is not None and sr_dist <= PITRA_CONJ_ORB_DEGREES:
        sun_rahu_close = True
    if sun_rahu_same_house or sun_rahu_close:
        sigs.append({
            "name":     "sun_rahu_conjunction",
            "present":  True,
            "severity": 3,
            "evidence": (f"Sun in house {sun.get('house')} ({sun.get('sign')}) with Rahu in house "
                          f"{rahu.get('house')} ({rahu.get('sign')}); "
                          f"{'same house' if sun_rahu_same_house else f'within {sr_dist:.1f}° orb'}. "
                          f"Classical Pitra Dosha primary trigger."),
            "source":   "Phaladeepika Ch. 6; BPHS Ch. 32",
        })

    # ── Signature 2: Sun-Ketu conjunction ──
    types_evaluated += 1
    sun_ketu_same_house = (sun.get("house") == ketu.get("house"))
    sk_dist = _angular_distance(sun.get("longitude"), ketu.get("longitude"))
    sun_ketu_close = (sk_dist is not None and sk_dist <= PITRA_CONJ_ORB_DEGREES)
    if sun_ketu_same_house or sun_ketu_close:
        sigs.append({
            "name":     "sun_ketu_conjunction",
            "present":  True,
            "severity": 3,
            "evidence": (f"Sun in house {sun.get('house')} ({sun.get('sign')}) with Ketu in house "
                          f"{ketu.get('house')} ({ketu.get('sign')}); "
                          f"{'same house' if sun_ketu_same_house else f'within {sk_dist:.1f}° orb'}. "
                          f"Classical Pitra Dosha trigger (Ketu axis intensifies past-karma signature)."),
            "source":   "Phaladeepika Ch. 6; BPHS Ch. 32",
        })

    # ── Signature 3: Rahu/Ketu aspects Sun by sign ──
    types_evaluated += 2  # rahu_aspects_sun + ketu_aspects_sun
    sun_sign = sun.get("sign")
    rahu_aspects = rahu.get("aspects", []) or []
    ketu_aspects = ketu.get("aspects", []) or []
    if sun_sign and sun_sign in rahu_aspects:
        sigs.append({
            "name":     "rahu_aspects_sun",
            "present":  True,
            "severity": 2,
            "evidence": (f"Rahu in {rahu.get('sign')} aspects Sun's sign {sun_sign} "
                          f"(Vedic drishti). Moderate Pitra signature."),
            "source":   "Phaladeepika Ch. 6",
        })
    if sun_sign and sun_sign in ketu_aspects:
        sigs.append({
            "name":     "ketu_aspects_sun",
            "present":  True,
            "severity": 2,
            "evidence": (f"Ketu in {ketu.get('sign')} aspects Sun's sign {sun_sign} "
                          f"(Vedic drishti). Moderate Pitra signature."),
            "source":   "Phaladeepika Ch. 6",
        })

    # ── Signature 4: Sun-Saturn conjunction or Saturn aspects Sun ──
    types_evaluated += 1
    sun_saturn_same_house = (sun.get("house") == saturn.get("house"))
    ss_dist = _angular_distance(sun.get("longitude"), saturn.get("longitude"))
    sun_saturn_close = (ss_dist is not None and ss_dist <= PITRA_CONJ_ORB_DEGREES)
    saturn_aspects = saturn.get("aspects", []) or []
    saturn_aspects_sun = (sun_sign in saturn_aspects) if sun_sign else False

    if sun_saturn_same_house or sun_saturn_close:
        sigs.append({
            "name":     "sun_saturn_conjunction",
            "present":  True,
            "severity": 2,
            "evidence": (f"Sun in house {sun.get('house')} with Saturn in house {saturn.get('house')}; "
                          f"{'same house' if sun_saturn_same_house else f'within {ss_dist:.1f}° orb'}. "
                          f"Saturn-Sun affliction signature for paternal line."),
            "source":   "Saravali Ch. 6; BPHS Ch. 32",
        })
    elif saturn_aspects_sun:
        sigs.append({
            "name":     "saturn_aspects_sun",
            "present":  True,
            "severity": 1,
            "evidence": (f"Saturn in {saturn.get('sign')} aspects Sun's sign {sun_sign}. "
                          f"Mild paternal-line affliction signature."),
            "source":   "Saravali Ch. 6",
        })

    # ── Signature 5: Sun is combust or fallen (debilitated) ──
    types_evaluated += 2  # sun_combust + sun_weak_dignity (both evaluated)
    if sun.get("is_combust"):
        sigs.append({
            "name":     "sun_combust",
            "present":  True,
            "severity": 1,
            "evidence": ("Sun is combust (within ~12° of Sun's own degree — unusual; flag as data anomaly if seen). "
                          "Indicates weakened Pita karaka."),
            "source":   "BPHS Ch. 2",
        })
    if sun.get("dignity") in ("debilitated", "fallen", "enemy"):
        sigs.append({
            "name":     "sun_weak_dignity",
            "present":  True,
            "severity": 1,
            "evidence": (f"Sun is {sun.get('dignity')} (sign {sun.get('sign')}). Weakened Pita karaka."),
            "source":   "BPHS Ch. 2; Brihat Jataka Ch. 2",
        })

    # ── Signature 6: 9th lord afflicted ──
    nl_data = prim.get("ninth_lord_data") or {}
    if nl_data:
        types_evaluated += 3  # ninth_lord_in_dusthana + _weak + _combust
        nl_planet = prim.get("ninth_lord_planet")
        nl_house = nl_data.get("house")
        nl_dignity = nl_data.get("dignity")
        nl_combust = nl_data.get("is_combust", False)
        if nl_house in (6, 8, 12):
            sigs.append({
                "name":     "ninth_lord_in_dusthana",
                "present":  True,
                "severity": 2,
                "evidence": (f"9th lord ({nl_planet}) sits in house {nl_house} (dusthana). "
                              f"Father's house lord in difficulty — Pitra signature."),
                "source":   "BPHS Ch. 32; Jataka Parijata Ch. 4",
            })
        if nl_dignity in ("debilitated", "fallen", "enemy"):
            sigs.append({
                "name":     "ninth_lord_weak",
                "present":  True,
                "severity": 1,
                "evidence": (f"9th lord ({nl_planet}) has weak dignity ({nl_dignity}). "
                              f"Father-significator weakened."),
                "source":   "BPHS Ch. 32",
            })
        if nl_combust:
            sigs.append({
                "name":     "ninth_lord_combust",
                "present":  True,
                "severity": 1,
                "evidence": f"9th lord ({nl_planet}) is combust. Pitra karaka secondary affliction.",
                "source":   "BPHS Ch. 32",
            })

    # ── Signature 7: Sun in 9th house aspected/conjunct Rahu or Ketu ──
    if sun.get("house") == 9:
        # Sun in 9H itself is generally good; only flag if it's also afflicted
        if any(s["name"] in ("sun_rahu_conjunction", "sun_ketu_conjunction",
                              "rahu_aspects_sun", "ketu_aspects_sun")
               for s in sigs):
            # Already captured above; don't duplicate
            pass

    # ── Signature 8: Surya grahan (eclipse on natal Sun) — reuse F2a! ──
    # This is the F2a/F2b integration point.
    types_evaluated += 1
    try:
        ecl_result = _ecl_handle_natal_eclipses(birth, window_days=180)
        for ecl in ecl_result.get("eclipses", []):
            interaction = ecl.get("natal_interaction", {})
            dist_sun = interaction.get("distance_from_natal_sun_deg")
            triggers = interaction.get("triggers", [])
            if dist_sun is not None and dist_sun <= 3.0:
                sigs.append({
                    "name":     "surya_grahan_natal",
                    "present":  True,
                    "severity": 3,
                    "evidence": (f"Natal eclipse on/near natal Sun: {ecl['moment']['date_utc']} "
                                  f"({ecl['kind']}, {'+'.join(ecl['type_labels'])}, "
                                  f"{dist_sun:.2f}° from natal Sun). "
                                  f"Classical Surya grahan signature reinforces Pitra Dosha."),
                    "source":   "Sarvartha Chintamani; Brihat Samhita Ch. 5",
                })
                break  # one is enough
    except Exception as e:
        # If F2a misbehaves, skip this signature; don't fail F2b
        sigs.append({
            "name":     "surya_grahan_check_failed",
            "present":  False,
            "severity": 0,
            "evidence": f"Could not check natal eclipses (reason: {e})",
            "source":   "N/A",
        })

    return {"signatures": sigs, "types_evaluated": types_evaluated}


# ════════════════════════════════════════════════════════════════════════
# PROFILE
# ════════════════════════════════════════════════════════════════════════

def handle_pitra_dosha_profile(birth: Dict[str, Any]) -> Dict[str, Any]:
    """
    F2b Endpoint: Detect classical Pitra Dosha signatures.
    Returns the full list of detected signatures with severity + evidence.
    """
    try:
        prim = _extract_pitra_primitives(birth)
    except Exception as e:
        return {"error": f"Chart cast failed: {e}",
                 "citations": F2B_CITATIONS["profile"]}

    detection_result = _detect_signatures(prim, birth)
    sigs = detection_result["signatures"]
    types_evaluated = detection_result["types_evaluated"]
    present = [s for s in sigs if s.get("present")]

    # Classify
    if any(s["severity"] >= 3 for s in present):
        verdict = "STRONG"
    elif any(s["severity"] >= 2 for s in present):
        verdict = "MODERATE"
    elif present:
        verdict = "MILD"
    else:
        verdict = "ABSENT"

    summary_lines = []
    if not present:
        summary_lines.append("No classical Pitra Dosha signatures detected in natal chart.")
    else:
        for s in present:
            summary_lines.append(f"• [{s['severity']}] {s['name']}: {s['evidence'][:140]}")

    return {
        "success":            True,
        "verdict":            verdict,
        "natal": {
            "lagna_sign":       prim["lagna_sign"],
            "sun_sign":         prim["sun"]["sign"],
            "sun_house":        prim["sun"]["house"],
            "sun_dignity":      prim["sun"]["dignity"],
            "rahu_house":       prim["rahu"]["house"],
            "ketu_house":       prim["ketu"]["house"],
            "saturn_house":     prim["saturn"]["house"],
            "ninth_house_sign": prim["ninth_house_sign"],
            "ninth_lord":       prim["ninth_lord_planet"],
        },
        "signatures_present":         present,
        "signatures_checked":         len(sigs),          # detected (back-compat with U13)
        "signature_types_evaluated":  types_evaluated,     # NEW: total signature TYPES checked
        "signatures_present_count":   len(present),
        "summary":               summary_lines,
        "classical_sources":     F2B_CITATIONS["profile"],
    }


# ════════════════════════════════════════════════════════════════════════
# INTENSITY
# ════════════════════════════════════════════════════════════════════════

def handle_pitra_dosha_intensity(birth: Dict[str, Any]) -> Dict[str, Any]:
    """
    F2b Endpoint: Score 0-100 + which signatures contributed.

    Scoring weights (severity → points):
      severity 3 = 30 points each (max 60 if two strong signatures both present)
      severity 2 = 15 points each
      severity 1 = 5 points each

    Caps at 100. Higher score = more intense classical Pitra Dosha signature.
    """
    try:
        prim = _extract_pitra_primitives(birth)
    except Exception as e:
        return {"error": f"Chart cast failed: {e}",
                 "citations": F2B_CITATIONS["intensity"]}

    detection_result = _detect_signatures(prim, birth)
    sigs = detection_result["signatures"]
    types_evaluated = detection_result["types_evaluated"]
    present = [s for s in sigs if s.get("present")]

    SEVERITY_WEIGHT = {3: 30, 2: 15, 1: 5}
    raw_score = sum(SEVERITY_WEIGHT.get(s["severity"], 0) for s in present)
    score = min(raw_score, 100)

    # Banded verdict
    if score >= 60:
        band = "HIGH"
        narrative = ("Multiple strong Pitra Dosha signatures present. Classical tradition "
                      "recommends formal Pitru remediation, especially during Pitru Paksha "
                      "and on Mahalaya Amavasya.")
    elif score >= 30:
        band = "MODERATE"
        narrative = ("Pitra Dosha signature present at moderate intensity. Classical "
                      "Pitru Paksha observances are traditionally beneficial.")
    elif score > 0:
        band = "MILD"
        narrative = ("Minor Pitra signature detected. General Pitru Paksha awareness "
                      "is sufficient per classical tradition.")
    else:
        band = "ABSENT"
        narrative = ("No Pitra Dosha signatures detected. Standard ancestral observances "
                      "remain culturally meaningful but no specific dosha-driven remediation is indicated.")

    # Top contributing signatures
    by_severity = sorted(present, key=lambda s: -s["severity"])
    top_contributors = []
    for s in by_severity[:5]:
        top_contributors.append({
            "name":     s["name"],
            "severity": s["severity"],
            "weight":   SEVERITY_WEIGHT.get(s["severity"], 0),
            "evidence": s["evidence"],
            "source":   s["source"],
        })

    return {
        "success":         True,
        "intensity_score": score,
        "raw_score":       raw_score,
        "band":            band,
        "narrative":       narrative,
        "signatures_present_count":   len(present),
        "signature_types_evaluated":  types_evaluated,     # NEW (U13)
        "top_contributors": top_contributors,
        "classical_sources": F2B_CITATIONS["intensity"],
    }


# ════════════════════════════════════════════════════════════════════════
# REMEDIES TIMING
# ════════════════════════════════════════════════════════════════════════

def _find_pitru_paksha_window(year: int,
                                lat: float, lon: float, tz: str) -> Dict[str, Any]:
    """
    Find the Pitru Paksha window (Krishna Paksha of Bhadrapada-Ashvin)
    for a given year. Iterates panchang day-by-day across late Aug through
    mid-Oct and collects all Krishna paksha days; the Amavasya at the end
    is Mahalaya Amavasya.
    """
    krishna_days: List[Dict[str, Any]] = []
    amavasya_date: Optional[str] = None

    start = date(year, 8, 25)
    for i in range(55):  # scan ~55 days
        d = start + timedelta(days=i)
        try:
            c = cast_chart(dob=d.strftime("%Y-%m-%d"), time="12:00",
                            lat=lat, lon=lon, timezone=tz)
        except Exception:
            continue
        pan = c.get("panchang", {})
        tithi = pan.get("tithi", {})
        if tithi.get("paksha") == "Krishna":
            entry = {
                "date":      str(d),
                "tithi":     tithi.get("name"),
                "tithi_num": tithi.get("number"),
            }
            krishna_days.append(entry)
            if tithi.get("name") == "Amavasya" or tithi.get("number") == 30:
                amavasya_date = str(d)

    if not krishna_days:
        return {
            "year": year,
            "found": False,
            "error": "Could not locate Pitru Paksha window via panchang iteration",
        }

    return {
        "year":              year,
        "found":             True,
        "krishna_days":      krishna_days,
        "window_start":      krishna_days[0]["date"],
        "window_end":        krishna_days[-1]["date"],
        "mahalaya_amavasya": amavasya_date,
        "total_days":        len(krishna_days),
        "lat_used":          lat,
        "lon_used":          lon,
        "tz_used":           tz,
    }


def handle_pitra_dosha_remedies_timing(birth: Dict[str, Any],
                                         query_date: Optional[str] = None,
                                         years_ahead: int = MAHALAYA_YEARS_DEFAULT) -> Dict[str, Any]:
    """
    F2b Endpoint: Pitru Paksha windows + dasha context + classical tradition.

    Args:
      birth:       BirthInput dict
      query_date:  YYYY-MM-DD; defaults to today (anchors year iteration)
      years_ahead: number of years forward to compute Mahalaya windows for.
                   Default 5, clamped to MAX (50).
    """
    try:
        y = int(years_ahead or MAHALAYA_YEARS_DEFAULT)
    except (TypeError, ValueError):
        y = MAHALAYA_YEARS_DEFAULT
    if y < 1:
        y = 1
    if y > MAHALAYA_YEARS_MAX:
        y = MAHALAYA_YEARS_MAX

    if query_date:
        try:
            anchor = datetime.strptime(query_date, "%Y-%m-%d").date()
        except ValueError as e:
            return {"error": f"Invalid query_date: {e}",
                     "citations": F2B_CITATIONS["remedies_timing"]}
    else:
        anchor = date.today()

    # Get native's dasha context for narrative
    try:
        prim = _extract_pitra_primitives(birth)
        md = prim.get("active_md") or {}
        ad = prim.get("active_ad") or {}
    except Exception as e:
        return {"error": f"Chart cast failed: {e}",
                 "citations": F2B_CITATIONS["remedies_timing"]}

    md_planet = md.get("planet")
    ad_planet = ad.get("planet")
    pitra_relevant_dashas = {"Sun", "Rahu", "Ketu", "Saturn"}
    md_relevant = (md_planet in pitra_relevant_dashas)
    ad_relevant = (ad_planet in pitra_relevant_dashas)

    # Compute Pitru Paksha windows for each year
    lat = birth.get("lat", 28.6139)
    lon = birth.get("lon", 77.2090)
    tz = birth.get("timezone", "Asia/Kolkata")

    windows = []
    for yr in range(anchor.year, anchor.year + y):
        windows.append(_find_pitru_paksha_window(yr, lat, lon, tz))

    found_windows = [w for w in windows if w.get("found")]

    # Dasha-aware narrative
    dasha_note_parts = []
    if md_relevant:
        dasha_note_parts.append(
            f"Current Mahadasha lord is {md_planet} — classically a Pitra-relevant period "
            f"(amplifies need for Pitru observances)."
        )
    if ad_relevant:
        dasha_note_parts.append(
            f"Current Antardasha lord is {ad_planet} — Pitra-relevant sub-period."
        )
    if not (md_relevant or ad_relevant):
        dasha_note_parts.append(
            f"Current dasha (MD={md_planet}, AD={ad_planet}) is not directly Pitra-relevant; "
            f"observances during Pitru Paksha remain culturally meaningful."
        )

    return {
        "success":         True,
        "query_date":      str(anchor),
        "years_ahead":     y,
        "max_years_ahead": MAHALAYA_YEARS_MAX,
        "active_dasha": {
            "md_planet":   md_planet,
            "md_pitra_relevant": md_relevant,
            "ad_planet":   ad_planet,
            "ad_pitra_relevant": ad_relevant,
        },
        "dasha_context_note": " ".join(dasha_note_parts),
        "pitru_paksha_windows":     windows,
        "windows_resolved":         len(found_windows),
        "tradition": {
            "_label": "classical tradition (not prescription)",
            "_note": (
                "The following remedy descriptions reflect classical Hindu tradition as documented "
                "in Garuda Purana, Vishnu Purana, Manusmriti, and Yajnavalkya Smriti. "
                "They are not medical or religious prescriptions; consult qualified vaidikas/priests for ritual specifics."
            ),
            "remedies": PITRA_REMEDIES_TRADITION,
        },
        "classical_sources": F2B_CITATIONS["remedies_timing"],
    }
