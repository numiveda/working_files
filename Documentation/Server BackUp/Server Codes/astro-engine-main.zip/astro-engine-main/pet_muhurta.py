"""
pet_muhurta.py — numiVeda Kaaliyo Astro Engine — Module F6b (Pet Acquisition Muhurta)

Two endpoints for selecting auspicious pet-acquisition dates+times:
    handle_check_acquisition_day        — Single-date verdict
    handle_acquisition_window_scan      — Range scan, returns ranked recommendations

Design (per HANDOVER_v5 carry-forward):
    P1 — All astronomy through cast_chart + swisseph (sunrise/sunset for Abhijit).
    P2 — Reuse: F9's _detect_daily_yogas + tara logic; cast_chart for daily
         panchang; Yoni tables from compatibility.py for yoni-friendliness check.
    P5 — Self-contained scoring logic. No dependency on yogas_helpers.

Public API:
    handle_check_acquisition_day(owner, acquisition_date, acquisition_location) -> dict
    handle_acquisition_window_scan(owner, start_date, end_date, acquisition_location) -> dict

Author: Claude (F6b, 2026-05-18)
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import date, datetime, timedelta

try:
    from dashaflow import cast_chart
except ImportError as e:
    raise ImportError(f"F6b pet_muhurta requires dashaflow.cast_chart: {e}")

try:
    import swisseph as swe
except ImportError as e:
    raise ImportError(f"F6b pet_muhurta requires swisseph: {e}")

# Reuse F9's daily yoga detection — single source of truth
try:
    from birthday_quick import (
        _detect_daily_yogas,
        _compute_tara,
        _NAKSHATRAS_ORDER as _NAK_ORDER,
    )
except ImportError as e:
    raise ImportError(f"F6b pet_muhurta requires birthday_quick (F9 module): {e}")

# Yoni tables from compatibility
try:
    from compatibility import (
        NAKSHATRA_TO_YONI, YONI_FRIENDLY, YONI_ENEMIES, YONI_NEUTRAL_PAIRS,
    )
except ImportError as e:
    raise ImportError(f"F6b pet_muhurta requires compatibility module: {e}")


# ════════════════════════════════════════════════════════════════════════
# SCORING SCHEME — transparent + classical
# ════════════════════════════════════════════════════════════════════════

# Positive signals (added to day score)
_SCORE_AMRIT_SIDDHI       = 5   # highest single auspicious yoga
_SCORE_SARVARTHA_SIDDHI   = 4
_SCORE_GURU_PUSHYA        = 6   # rarest, most auspicious
_SCORE_RAVI_PUSHYA        = 5
_SCORE_DWIPUSHKAR         = 3
_SCORE_TRIPUSHKAR         = 4

# Tara contributions (owner's tara on the candidate day)
_SCORE_TARA = {
    "Janma":    0,    # mixed — no bonus, no penalty
    "Sampat":   3,
    "Vipat":   -4,
    "Kshema":   3,
    "Pratyak": -4,
    "Sadhaka":  3,
    "Vadha":   -5,
    "Mitra":    3,
    "Ati-Mitra": 4,   # strongest tara bonus
}

# Inauspicious daily yoga penalties
_SCORE_VISH        = -5
_SCORE_MRITYU      = -8   # heaviest penalty — classically avoid

# Yoni alignment (operative pet nakshatra vs owner's natal nakshatra)
_SCORE_YONI_SAME_OPPOSITE_GENDER = 2
_SCORE_YONI_FRIENDLY             = 2
_SCORE_YONI_NEUTRAL              = 1
_SCORE_YONI_ENEMY                = -3
_SCORE_YONI_SAME_SAME_GENDER     = 1   # neutral-mild

# Sade Sati penalty (peak phase only — Madhya = Saturn in 1st from natal Moon)
_SCORE_SADE_SATI_PEAK = -3
_SCORE_SADE_SATI_EDGE = -1


# Banding thresholds
def _band_from_score(score: float) -> Tuple[str, str]:
    """Returns (band_label, narrative)."""
    if score >= 12:
        return ("EXCEPTIONAL", "Rare alignment of multiple auspicious signals. Classical tradition strongly favors this day.")
    if score >= 7:
        return ("AUSPICIOUS", "Multiple positive signals align. A good day to bring the pet home.")
    if score >= 3:
        return ("ACCEPTABLE", "Generally workable. Some positive signals, no major obstructions.")
    if score >= 0:
        return ("NEUTRAL", "Mixed signals. Neither strongly favored nor obstructed.")
    if score >= -4:
        return ("UNFAVORABLE", "Notable obstructions. Consider an alternative day if possible.")
    return ("AVOID", "Strongly inauspicious — Vish/Mrityu yoga or Vadha tara active. Postpone if possible.")


# ════════════════════════════════════════════════════════════════════════
# ABHIJIT MUHURTA — universally auspicious mid-day window
# ════════════════════════════════════════════════════════════════════════

def _compute_sunrise_sunset(year: int, month: int, day: int,
                              lat: float, lon: float,
                              timezone_offset_hours: float) -> Optional[Tuple[float, float]]:
    """
    Compute local sunrise and sunset hours (0-24 decimal) for given date+place.
    Returns (sunrise_local, sunset_local) or None if calculation fails.

    Uses swisseph rise_trans with disc center.
    """
    try:
        # Start search 24h before local midnight (to ensure we find the right rise/set)
        # Local midnight in UT = julday(date, 0) - tz_offset/24
        jd_local_midnight_ut = swe.julday(year, month, day, 0.0) - (timezone_offset_hours / 24.0)
        jd_search_start = jd_local_midnight_ut - 0.5    # 12 hours before local midnight

        rise_flag = swe.CALC_RISE | swe.BIT_DISC_CENTER
        set_flag  = swe.CALC_SET  | swe.BIT_DISC_CENTER
        geopos = (lon, lat, 0.0)

        result_rise = swe.rise_trans(jd_search_start, swe.SUN, rise_flag, geopos)
        result_set  = swe.rise_trans(jd_search_start, swe.SUN, set_flag, geopos)

        if not result_rise or not result_set:
            return None

        # pyswisseph returns (retc, tret_tuple) where tret_tuple[0] = JD
        try:
            jd_rise = result_rise[1][0]
            jd_set  = result_set[1][0]
        except (IndexError, TypeError):
            return None

        # If found rise is before local midnight, search again from later
        # (we want sunrise OF the requested local date)
        if jd_rise < jd_local_midnight_ut:
            result_rise = swe.rise_trans(jd_local_midnight_ut, swe.SUN, rise_flag, geopos)
            if result_rise:
                try:
                    jd_rise = result_rise[1][0]
                except (IndexError, TypeError):
                    return None

        if jd_set < jd_rise:
            # Sunset before sunrise → search forward
            result_set = swe.rise_trans(jd_rise, swe.SUN, set_flag, geopos)
            if result_set:
                try:
                    jd_set = result_set[1][0]
                except (IndexError, TypeError):
                    return None

        # Convert JD-UT to local clock hours (0-24)
        sunrise_local = (jd_rise - jd_local_midnight_ut) * 24.0
        sunset_local  = (jd_set  - jd_local_midnight_ut) * 24.0

        # Sanity bounds
        if not (0.0 <= sunrise_local <= 24.0):
            return None
        if not (0.0 <= sunset_local <= 30.0):    # sunset can be > 24 if crosses midnight in extreme lats
            return None
        if sunset_local <= sunrise_local:
            return None

        return (sunrise_local, min(sunset_local, 23.99))

    except Exception:
        return None


def _hours_to_hhmm(h: float) -> str:
    """Convert decimal hours to HH:MM string."""
    h = max(0.0, min(23.999, h))
    hh = int(h)
    mm = int((h - hh) * 60)
    return f"{hh:02d}:{mm:02d}"


def _compute_abhijit_muhurta(year: int, month: int, day: int,
                                lat: float, lon: float,
                                timezone_offset_hours: float) -> Optional[Dict[str, Any]]:
    """
    Abhijit muhurta = 8th muhurta of the day from sunrise,
    spanning the midday point. Roughly 24 minutes centered at local noon
    (solar noon = midpoint of sunrise-to-sunset).

    Returns {start, end, midpoint} as HH:MM strings, or None if compute fails.
    """
    times = _compute_sunrise_sunset(year, month, day, lat, lon, timezone_offset_hours)
    if not times:
        return None
    sunrise, sunset = times

    day_length = sunset - sunrise
    if day_length <= 0:
        return None

    # Day divided into 15 muhurtas; Abhijit is the 8th (middle)
    # So Abhijit center = sunrise + 7.5 * (day_length/15) = sunrise + day_length/2
    muhurta_duration_hours = day_length / 15.0
    abhijit_center = sunrise + day_length / 2.0
    abhijit_start = abhijit_center - muhurta_duration_hours / 2.0
    abhijit_end   = abhijit_center + muhurta_duration_hours / 2.0

    return {
        "start_local":   _hours_to_hhmm(abhijit_start),
        "end_local":     _hours_to_hhmm(abhijit_end),
        "midpoint_local": _hours_to_hhmm(abhijit_center),
        "duration_minutes": round(muhurta_duration_hours * 60, 1),
        "note": "Abhijit muhurta — universally auspicious mid-day window. Classically suitable for any new beginning.",
    }


# ════════════════════════════════════════════════════════════════════════
# DAY SCORING
# ════════════════════════════════════════════════════════════════════════

def _check_sade_sati(owner_chart: Dict[str, Any], day_chart: Dict[str, Any]) -> Tuple[int, Optional[str]]:
    """
    Owner's Sade Sati status on the candidate day.

    Returns (penalty_points, phase_description_or_None).
    """
    natal_moon = owner_chart.get("planets", {}).get("Moon", {}).get("sign")
    transit_saturn = day_chart.get("planets", {}).get("Saturn", {}).get("sign")
    if not natal_moon or not transit_saturn:
        return (0, None)

    signs = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra",
             "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"]
    try:
        natal_idx = signs.index(natal_moon)
        sat_idx = signs.index(transit_saturn)
    except ValueError:
        return (0, None)

    # Saturn's house from natal Moon
    house = ((sat_idx - natal_idx) % 12) + 1
    if house == 1:
        return (_SCORE_SADE_SATI_PEAK, "Sade Sati Madhya (Peak) — Saturn over natal Moon")
    if house in (12, 2):
        phase = "Purva (Rising)" if house == 12 else "Uttara (Setting)"
        return (_SCORE_SADE_SATI_EDGE, f"Sade Sati {phase}")
    return (0, None)


def _check_yoni_alignment(operative_nak: str, owner_nak: str) -> Tuple[int, str]:
    """
    Yoni alignment between candidate day's operative nakshatra and owner's nakshatra.

    Returns (points, description).
    """
    pet_yoni = NAKSHATRA_TO_YONI.get(operative_nak, ("Unknown", "M"))
    own_yoni = NAKSHATRA_TO_YONI.get(owner_nak, ("Unknown", "F"))
    p_animal, p_gender = pet_yoni
    o_animal, o_gender = own_yoni

    if p_animal == o_animal:
        if p_gender != o_gender:
            return (_SCORE_YONI_SAME_OPPOSITE_GENDER,
                     f"Yoni same+opposite-gender ({p_animal}) — strong alignment")
        return (_SCORE_YONI_SAME_SAME_GENDER,
                 f"Yoni same+same-gender ({p_animal}) — mild affinity")
    if ((p_animal, o_animal) in YONI_ENEMIES or
            (o_animal, p_animal) in YONI_ENEMIES):
        return (_SCORE_YONI_ENEMY,
                 f"Yoni enmity ({p_animal} vs {o_animal}) — natural antagonism")
    if ((p_animal, o_animal) in YONI_FRIENDLY or
            (o_animal, p_animal) in YONI_FRIENDLY):
        return (_SCORE_YONI_FRIENDLY,
                 f"Yoni friendship ({p_animal} ↔ {o_animal})")
    if ((p_animal, o_animal) in YONI_NEUTRAL_PAIRS or
            (o_animal, p_animal) in YONI_NEUTRAL_PAIRS):
        return (_SCORE_YONI_NEUTRAL,
                 f"Yoni neutrality ({p_animal} / {o_animal})")
    return (0, f"Yoni unclassified pairing ({p_animal} / {o_animal})")


def _tz_offset_hours(timezone_str: str) -> float:
    """
    Convert IANA timezone string to UTC offset in hours.
    Defaults to +5.5 (Asia/Kolkata) on failure.
    """
    try:
        from zoneinfo import ZoneInfo
        from datetime import datetime as dt_class
        tz = ZoneInfo(timezone_str)
        # Use Jan 1 of current year for offset (no DST in target regions usually)
        now = dt_class(date.today().year, 1, 1, 12, 0, 0, tzinfo=tz)
        offset = now.utcoffset()
        if offset:
            return offset.total_seconds() / 3600.0
    except Exception:
        pass
    return 5.5   # Asia/Kolkata default


def _score_single_day(query_date: date,
                        owner_chart: Dict[str, Any],
                        owner_nakshatra: str,
                        acq_lat: float, acq_lon: float,
                        acq_timezone: str) -> Dict[str, Any]:
    """
    Score a single candidate day for pet acquisition.

    Returns full breakdown dict including score, band, signals, recommended time.
    """
    date_str = str(query_date)
    score = 0
    positive_signals: List[str] = []
    negative_signals: List[str] = []

    # Cast chart for the day at noon at the acquisition location
    try:
        day_chart = cast_chart(
            dob=date_str, time="12:00",
            lat=acq_lat, lon=acq_lon,
            timezone=acq_timezone,
        )
    except Exception as e:
        return {
            "date":  date_str,
            "error": f"Day chart cast failed: {e}",
            "score": -999,
            "band":  "ERROR",
        }

    panchang = day_chart.get("panchang", {})
    operative_nak = (panchang.get("nakshatra", {}).get("name")
                      if isinstance(panchang.get("nakshatra"), dict) else None)
    vara_name = (panchang.get("vara", {}).get("name")
                   if isinstance(panchang.get("vara"), dict) else None)

    # ── 1. Daily yoga detection (reuses F9) ──
    yogas = _detect_daily_yogas(panchang)
    for y in yogas.get("auspicious", []):
        name = y["name"]
        if name == "Amrit Siddhi Yoga":
            score += _SCORE_AMRIT_SIDDHI
            positive_signals.append(f"Amrit Siddhi Yoga (+{_SCORE_AMRIT_SIDDHI})")
        elif name == "Sarvartha Siddhi Yoga":
            score += _SCORE_SARVARTHA_SIDDHI
            positive_signals.append(f"Sarvartha Siddhi Yoga (+{_SCORE_SARVARTHA_SIDDHI})")
        elif name == "Guru Pushya Yoga":
            score += _SCORE_GURU_PUSHYA
            positive_signals.append(f"Guru Pushya Yoga (+{_SCORE_GURU_PUSHYA})")
        elif name == "Ravi Pushya Yoga":
            score += _SCORE_RAVI_PUSHYA
            positive_signals.append(f"Ravi Pushya Yoga (+{_SCORE_RAVI_PUSHYA})")
        elif name == "Dwipushkar Yoga":
            score += _SCORE_DWIPUSHKAR
            positive_signals.append(f"Dwipushkar Yoga (+{_SCORE_DWIPUSHKAR})")
        elif name == "Tripushkar Yoga":
            score += _SCORE_TRIPUSHKAR
            positive_signals.append(f"Tripushkar Yoga (+{_SCORE_TRIPUSHKAR})")

    for y in yogas.get("inauspicious", []):
        name = y["name"]
        if name == "Mrityu Yoga":
            score += _SCORE_MRITYU
            negative_signals.append(f"Mrityu Yoga ({_SCORE_MRITYU})")
        elif name == "Vish Yoga":
            score += _SCORE_VISH
            negative_signals.append(f"Vish Yoga ({_SCORE_VISH})")

    # ── 2. Tara from owner's natal nakshatra ──
    tara_info = None
    if operative_nak and owner_nakshatra:
        tara_info = _compute_tara(operative_nak, owner_nakshatra)
        tara_name = tara_info.get("tara_name")
        if tara_name:
            t_score = _SCORE_TARA.get(tara_name, 0)
            score += t_score
            if t_score > 0:
                positive_signals.append(f"Tara {tara_name} (+{t_score}) — {tara_info.get('effect','').lower()}")
            elif t_score < 0:
                negative_signals.append(f"Tara {tara_name} ({t_score}) — {tara_info.get('effect','').lower()}")
            else:
                positive_signals.append(f"Tara {tara_name} (mixed, 0)")

    # ── 3. Yoni alignment ──
    yoni_score, yoni_note = 0, ""
    if operative_nak and owner_nakshatra:
        yoni_score, yoni_note = _check_yoni_alignment(operative_nak, owner_nakshatra)
        score += yoni_score
        if yoni_score > 0:
            positive_signals.append(f"{yoni_note} (+{yoni_score})")
        elif yoni_score < 0:
            negative_signals.append(f"{yoni_note} ({yoni_score})")

    # ── 4. Owner's Sade Sati status ──
    ss_score, ss_note = _check_sade_sati(owner_chart, day_chart)
    if ss_note:
        score += ss_score
        if ss_score < 0:
            negative_signals.append(f"{ss_note} ({ss_score})")
        else:
            positive_signals.append(ss_note)

    # ── 5. Abhijit muhurta (intra-day recommendation) ──
    tz_offset = _tz_offset_hours(acq_timezone)
    abhijit = _compute_abhijit_muhurta(
        query_date.year, query_date.month, query_date.day,
        acq_lat, acq_lon, tz_offset
    )

    band, band_narrative = _band_from_score(score)

    return {
        "date":           date_str,
        "vara":           vara_name,
        "nakshatra":      operative_nak,
        "panchang_brief": {
            "tithi":     panchang.get("tithi"),
            "vara":      vara_name,
            "nakshatra": operative_nak,
        },
        "score":              score,
        "band":               band,
        "band_narrative":     band_narrative,
        "positive_signals":   positive_signals,
        "negative_signals":   negative_signals,
        "tara_for_owner":     tara_info,
        "recommended_time":   abhijit,    # may be None if compute failed
    }


# ════════════════════════════════════════════════════════════════════════
# PUBLIC API: check_acquisition_day
# ════════════════════════════════════════════════════════════════════════

def handle_check_acquisition_day(owner: Dict[str, Any],
                                    acquisition_date: str,
                                    acquisition_location: Dict[str, Any]) -> Dict[str, Any]:
    """
    F6b Endpoint: Check whether a specific date is auspicious for pet acquisition.

    Returns full scoring breakdown + recommended intra-day window.
    """
    try:
        owner_chart = cast_chart(
            dob=owner["dob"], time=owner["time"],
            lat=owner["lat"], lon=owner["lon"],
            timezone=owner.get("timezone", "Asia/Kolkata"),
        )
    except Exception as e:
        return {"error": f"Owner chart cast failed: {e}",
                 "citations": F6B_CITATIONS["check_day"]}

    owner_nakshatra = owner_chart.get("planets", {}).get("Moon", {}).get("nakshatra")

    try:
        q_date = datetime.strptime(acquisition_date, "%Y-%m-%d").date()
    except ValueError as e:
        return {"error": f"Invalid acquisition_date '{acquisition_date}': {e}",
                 "citations": F6B_CITATIONS["check_day"]}

    acq_lat = acquisition_location.get("lat")
    acq_lon = acquisition_location.get("lon")
    acq_tz = acquisition_location.get("timezone", "Asia/Kolkata")
    if acq_lat is None or acq_lon is None:
        return {"error": "acquisition_location requires lat + lon",
                 "citations": F6B_CITATIONS["check_day"]}

    day_score = _score_single_day(q_date, owner_chart, owner_nakshatra,
                                     acq_lat, acq_lon, acq_tz)

    return {
        "success":         True,
        "owner_nakshatra": owner_nakshatra,
        "acquisition_date": acquisition_date,
        "acquisition_location": acquisition_location,
        "verdict":         day_score,
        "summary": _summary_for_single_day(day_score),
        "classical_sources": F6B_CITATIONS["check_day"],
    }


def _summary_for_single_day(day_score: Dict[str, Any]) -> str:
    band = day_score.get("band", "?")
    score = day_score.get("score", 0)
    nak = day_score.get("nakshatra", "?")
    vara = day_score.get("vara", "?")
    if band == "ERROR":
        return f"Could not evaluate this date — see error field."
    if band in ("EXCEPTIONAL", "AUSPICIOUS"):
        return (f"{vara} + {nak}, score {score}: {band}. "
                  f"This is a favorable day to bring the pet home.")
    if band == "ACCEPTABLE":
        return (f"{vara} + {nak}, score {score}: {band}. "
                  f"Workable, no major obstructions.")
    if band == "NEUTRAL":
        return (f"{vara} + {nak}, score {score}: {band}. "
                  f"Neither strongly favored nor obstructed.")
    return (f"{vara} + {nak}, score {score}: {band}. "
              f"Consider an alternative date if flexibility allows.")


# ════════════════════════════════════════════════════════════════════════
# PUBLIC API: acquisition_window_scan
# ════════════════════════════════════════════════════════════════════════

def handle_acquisition_window_scan(owner: Dict[str, Any],
                                      start_date: Optional[str],
                                      end_date: Optional[str],
                                      acquisition_location: Dict[str, Any],
                                      max_days: int = 30) -> Dict[str, Any]:
    """
    F6b Endpoint: Scan a date range and rank auspicious days for pet acquisition.

    Default window: 14 days from today. Max: 30 days.
    Returns top 5 recommended days, list of days to avoid, and full ranked list.
    """
    # Date window resolution
    today = date.today()
    if start_date:
        try:
            sd = datetime.strptime(start_date, "%Y-%m-%d").date()
        except ValueError as e:
            return {"error": f"Invalid start_date '{start_date}': {e}",
                     "citations": F6B_CITATIONS["window_scan"]}
    else:
        sd = today

    if end_date:
        try:
            ed = datetime.strptime(end_date, "%Y-%m-%d").date()
        except ValueError as e:
            return {"error": f"Invalid end_date '{end_date}': {e}",
                     "citations": F6B_CITATIONS["window_scan"]}
    else:
        ed = sd + timedelta(days=14)

    if ed < sd:
        return {"error": "end_date must be on or after start_date",
                 "citations": F6B_CITATIONS["window_scan"]}

    num_days = (ed - sd).days + 1
    if num_days > max_days:
        return {"error": f"Date window {num_days} days exceeds maximum {max_days} days",
                 "citations": F6B_CITATIONS["window_scan"]}
    if num_days < 1:
        return {"error": "Date window must include at least 1 day",
                 "citations": F6B_CITATIONS["window_scan"]}

    # Owner setup
    try:
        owner_chart = cast_chart(
            dob=owner["dob"], time=owner["time"],
            lat=owner["lat"], lon=owner["lon"],
            timezone=owner.get("timezone", "Asia/Kolkata"),
        )
    except Exception as e:
        return {"error": f"Owner chart cast failed: {e}",
                 "citations": F6B_CITATIONS["window_scan"]}

    owner_nakshatra = owner_chart.get("planets", {}).get("Moon", {}).get("nakshatra")

    acq_lat = acquisition_location.get("lat")
    acq_lon = acquisition_location.get("lon")
    acq_tz = acquisition_location.get("timezone", "Asia/Kolkata")
    if acq_lat is None or acq_lon is None:
        return {"error": "acquisition_location requires lat + lon",
                 "citations": F6B_CITATIONS["window_scan"]}

    # Scan
    all_days: List[Dict[str, Any]] = []
    cur = sd
    while cur <= ed:
        d_score = _score_single_day(cur, owner_chart, owner_nakshatra,
                                       acq_lat, acq_lon, acq_tz)
        all_days.append(d_score)
        cur += timedelta(days=1)

    # Rank
    valid_days = [d for d in all_days if d.get("band") != "ERROR"]
    valid_days_sorted = sorted(valid_days, key=lambda d: -d["score"])

    top_recommended = [d for d in valid_days_sorted
                          if d["band"] in ("EXCEPTIONAL", "AUSPICIOUS", "ACCEPTABLE")][:5]
    days_to_avoid = [d for d in valid_days
                       if d["band"] in ("UNFAVORABLE", "AVOID")]

    # Build summary
    if top_recommended:
        best = top_recommended[0]
        summary = (f"Best day in window: {best['date']} ({best['vara']} + {best['nakshatra']}), "
                     f"score {best['score']} ({best['band']}). "
                     f"{len(top_recommended)} day(s) recommended, "
                     f"{len(days_to_avoid)} day(s) to avoid out of {len(valid_days)} scanned.")
    elif days_to_avoid:
        summary = (f"No clearly auspicious days found in window. "
                     f"{len(days_to_avoid)} day(s) to avoid; consider widening the date range.")
    else:
        summary = (f"Scanned {len(valid_days)} days — most are NEUTRAL. "
                     f"No standout auspicious day; consider widening the date range.")

    return {
        "success":             True,
        "owner_nakshatra":     owner_nakshatra,
        "window_searched": {
            "start_date":   str(sd),
            "end_date":     str(ed),
            "days_scanned": num_days,
        },
        "top_recommended":     top_recommended,
        "days_to_avoid":       days_to_avoid,
        "full_ranking":        valid_days_sorted,
        "summary":             summary,
        "classical_sources":   F6B_CITATIONS["window_scan"],
    }


# ════════════════════════════════════════════════════════════════════════
# CLASSICAL CITATIONS
# ════════════════════════════════════════════════════════════════════════

F6B_CITATIONS = {
    "check_day": [
        "Muhurta Chintamani Ch. 5-7 — Daily auspicious/inauspicious yoga classifications",
        "Muhurta Martanda — Abhijit muhurta and universal auspicious windows",
        "Brihat Samhita Ch. 99 — Panchanga foundation",
        "Hora Sara — 9-fold Tara cycle from native's natal nakshatra",
        "BPHS Ch. 7 — Yoni Kuta animal hierarchy",
        "Note: Pet acquisition muhurta optimizes for owner's tara and operative-day "
        "yogas. The pet's chart is unknown at acquisition (this is precisely what "
        "the muhurta is meant to establish), so scoring is one-sided — owner's "
        "natal nakshatra anchors the analysis.",
    ],
    "window_scan": [
        "Muhurta Chintamani Ch. 5-7, Muhurta Martanda — Daily auspicious yoga framework",
        "Hora Sara — Tara cycle analysis for owner-anchored muhurta",
        "BPHS Ch. 7 — Yoni Kuta classical compatibility framework",
        "Phaladeepika Ch. 26 — Saturn cycle (Sade Sati) modifying muhurta selection",
        "Note: Range scan ranks candidate days by transparent additive scoring "
        "(see scoring scheme in response). Recommended days are presented sorted "
        "by total score; ties are broken by date order.",
    ],
}
