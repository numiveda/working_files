"""
timeline_activation_rules.py — Encodes activation rules per yoga family.

Each yoga family has rules that determine when a yoga "fires" beyond its
mere natal presence. The two main trigger types:

1. **Dasha trigger**: The yoga's involved planets are running in MD/AD/PD.
   Strongest when MD planet is the primary yoga-forming planet.

2. **Transit trigger**: Slow-moving planets (Jupiter, Saturn, Rahu, Ketu)
   transit positions that re-activate the yoga (e.g. Jupiter transits a
   kendra from natal Moon = Gaja Kesari reactivation).

Activation intensity:
  - peak     = dasha AND transit alignment (strongest period)
  - moderate = one trigger present (single influence)
  - background = neither, but yoga is natally present (baseline)

Each rule returns ("intensity", trigger_description).
"""

from typing import Dict, Any, List, Tuple, Optional
from yogas_helpers import (
    SIGN_LORDS, KENDRA_HOUSES, TRIKONA_HOUSES, DUSTHANA_HOUSES,
    planet_house, planet_sign, lord_of_house,
)


# ─────────────────────────────────────────────────────────────────────────────
# DASHA TRIGGER HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _is_planet_in_dasha(dasha_state: dict, planet: str) -> Tuple[bool, str]:
    """
    Check if a planet is running at any level (MD/AD/PD) in the dasha state.
    Returns (is_running, level_description).
    """
    if not dasha_state:
        return False, ""
    md = dasha_state.get("md", "")
    ad = dasha_state.get("ad", "")
    pd = dasha_state.get("pd", "")
    if planet == md == ad == pd:
        return True, f"{planet} MD+AD+PD"
    if planet == md and planet == ad:
        return True, f"{planet} MD+AD"
    if planet == md:
        return True, f"{planet} MD"
    if planet == ad:
        return True, f"{planet} AD"
    if planet == pd:
        return True, f"{planet} PD"
    return False, ""


def _both_planets_in_dasha(dasha_state: dict, p1: str, p2: str) -> Tuple[bool, str]:
    """Check if both planets are running at any combined dasha level."""
    md = dasha_state.get("md", "")
    ad = dasha_state.get("ad", "")
    pd = dasha_state.get("pd", "")
    levels = (md, ad, pd)
    if p1 in levels and p2 in levels:
        # Tag which level each
        def lvl(p):
            if p == md: return "MD"
            if p == ad: return "AD"
            if p == pd: return "PD"
            return ""
        return True, f"{p1}({lvl(p1)}) + {p2}({lvl(p2)})"
    return False, ""


# ─────────────────────────────────────────────────────────────────────────────
# TRANSIT TRIGGER HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _transit_house_from_natal_planet(transit_chart: dict, natal_chart: dict,
                                      transit_planet: str, natal_planet: str) -> int:
    """How many houses from natal_planet is transit_planet currently?"""
    nat_h = planet_house(natal_chart, natal_planet)
    # For transit, compute from natal lagna
    trans_sign = planet_sign(transit_chart, transit_planet)
    if not trans_sign or not nat_h:
        return 0
    # Sign-to-house conversion using natal ascendant
    from yogas_helpers import SIGN_INDEX
    asc_idx = SIGN_INDEX.get(natal_chart.get("ascendant", {}).get("sign", ""), 0)
    trans_sign_idx = SIGN_INDEX.get(trans_sign, 0)
    trans_h = ((trans_sign_idx - asc_idx) % 12) + 1
    diff = ((trans_h - nat_h) % 12) + 1
    return diff


def _is_transit_in_kendra_from(transit_chart: dict, natal_chart: dict,
                                transit_planet: str, natal_ref: str) -> bool:
    """Is transit_planet in a kendra (1,4,7,10) from natal natal_ref's position?"""
    diff = _transit_house_from_natal_planet(transit_chart, natal_chart, transit_planet, natal_ref)
    return diff in (1, 4, 7, 10)


def _is_transit_aspecting_house(transit_chart: dict, transit_planet: str, target_house: int) -> bool:
    """Does transit planet aspect target_house in transit chart?"""
    from yogas_helpers import SPECIAL_ASPECTS, DEFAULT_ASPECT
    h = planet_house(transit_chart, transit_planet)
    if h is None: return False
    aspects = SPECIAL_ASPECTS.get(transit_planet, DEFAULT_ASPECT)
    aspected = [((h - 1 + a - 1) % 12) + 1 for a in aspects]
    return target_house in aspected


# ─────────────────────────────────────────────────────────────────────────────
# YOGA ACTIVATION RULES — by family
# ─────────────────────────────────────────────────────────────────────────────

def activation_for_pancha_mahapurusha(yoga, natal_chart, transit_chart, dasha_state):
    """
    Mahapurusha yoga (e.g., Ruchaka, Hamsa) activates strongly when:
    - The Mahapurusha planet itself is in MD or AD (dasha trigger)
    - The planet transits a kendra or its own sign (transit trigger)
    """
    yid = yoga["yoga_id"]
    # Extract planet from yoga_id (e.g., "mahapurusha_jupiter" → "Jupiter")
    planet = yid.replace("mahapurusha_", "").capitalize()
    if planet == "Sun": planet = "Sun"

    dasha_hit, dasha_desc = _is_planet_in_dasha(dasha_state, planet)

    # Transit: is the planet transiting own sign or kendra from lagna?
    transit_sign = planet_sign(transit_chart, planet)
    transit_h = planet_house(transit_chart, planet)
    own_signs = {
        "Mars": ("Aries", "Scorpio"), "Mercury": ("Gemini", "Virgo"),
        "Jupiter": ("Sagittarius", "Pisces"), "Venus": ("Taurus", "Libra"),
        "Saturn": ("Capricorn", "Aquarius"),
    }
    own_or_exalt = transit_sign in own_signs.get(planet, ())
    in_kendra = transit_h in KENDRA_HOUSES
    transit_hit = own_or_exalt or in_kendra

    transit_desc = []
    if own_or_exalt: transit_desc.append(f"{planet} in own sign")
    if in_kendra:    transit_desc.append(f"{planet} in kendra (h{transit_h})")

    if dasha_hit and transit_hit:
        return "peak", f"{dasha_desc} + {'/'.join(transit_desc)}"
    if dasha_hit:
        return "moderate", dasha_desc
    if transit_hit:
        return "moderate", '/'.join(transit_desc)
    return "background", ""


def activation_for_raja_yoga(yoga, natal_chart, transit_chart, dasha_state):
    """
    Raja Yoga activates when its forming planets (kendra-trikona lords) are in dasha.
    """
    yid = yoga["yoga_id"]

    # Extract houses from yoga_id like "raja_yoga_1_5" or named ones
    house_pair = None
    if "raja_yoga_" in yid:
        try:
            parts = yid.split("_")
            h1, h2 = int(parts[-2]), int(parts[-1])
            house_pair = (h1, h2)
        except (ValueError, IndexError):
            pass

    if house_pair:
        l1 = lord_of_house(natal_chart, house_pair[0])
        l2 = lord_of_house(natal_chart, house_pair[1])
        dasha_hit, dasha_desc = _both_planets_in_dasha(dasha_state, l1, l2)

        # Transit: is Jupiter or Saturn aspecting either lord's position?
        nat_h_l1 = planet_house(natal_chart, l1)
        nat_h_l2 = planet_house(natal_chart, l2)
        transit_jup_aspects_l1 = _is_transit_aspecting_house(transit_chart, "Jupiter", nat_h_l1) if nat_h_l1 else False
        transit_jup_aspects_l2 = _is_transit_aspecting_house(transit_chart, "Jupiter", nat_h_l2) if nat_h_l2 else False
        transit_hit = transit_jup_aspects_l1 or transit_jup_aspects_l2

        transit_desc = "Jupiter transit-aspect on yoga lords" if transit_hit else ""

        if dasha_hit and transit_hit:
            return "peak", f"{dasha_desc} + {transit_desc}"
        if dasha_hit:
            return "moderate", dasha_desc
        if transit_hit:
            return "moderate", transit_desc
        return "background", ""

    # Special named Raja Yogas
    if yid == "gaja_kesari_yoga":
        # Activates when Jupiter or Moon in dasha, OR transit Jupiter in kendra from natal Moon
        jd, jd_desc = _is_planet_in_dasha(dasha_state, "Jupiter")
        md, md_desc = _is_planet_in_dasha(dasha_state, "Moon")
        dasha_hit = jd or md
        dasha_desc = jd_desc or md_desc

        transit_hit = _is_transit_in_kendra_from(transit_chart, natal_chart, "Jupiter", "Moon")
        transit_desc = "Transit Jupiter in kendra from natal Moon" if transit_hit else ""

        if dasha_hit and transit_hit:
            return "peak", f"{dasha_desc} + {transit_desc}"
        if dasha_hit:
            return "moderate", dasha_desc
        if transit_hit:
            return "moderate", transit_desc
        return "background", ""

    if yid == "chandra_mangala_yoga":
        moon_d, moon_desc = _is_planet_in_dasha(dasha_state, "Moon")
        mars_d, mars_desc = _is_planet_in_dasha(dasha_state, "Mars")
        if moon_d and mars_d:
            return "peak", f"{moon_desc} + {mars_desc}"
        if moon_d or mars_d:
            return "moderate", moon_desc or mars_desc
        return "background", ""

    if yid == "neecha_bhanga_raja_yoga":
        # Activates when Saturn or Jupiter dasha (cancellation lords)
        for p in ("Saturn", "Jupiter"):
            hit, desc = _is_planet_in_dasha(dasha_state, p)
            if hit: return "moderate", desc
        return "background", ""

    # Default for unnamed raja yogas
    return "background", ""


def activation_for_dhana_yoga(yoga, natal_chart, transit_chart, dasha_state):
    """Dhana yogas activate strongly during wealth-house lord dashas."""
    yid = yoga["yoga_id"]

    # Pattern dhana_yoga_X_Y
    if "dhana_yoga_" in yid:
        try:
            parts = yid.split("_")
            h1, h2 = int(parts[-2]), int(parts[-1])
            l1 = lord_of_house(natal_chart, h1)
            l2 = lord_of_house(natal_chart, h2)
            dasha_hit, dasha_desc = _both_planets_in_dasha(dasha_state, l1, l2)

            # Transit Jupiter aspecting 2nd or 11th from lagna
            transit_hit = (_is_transit_aspecting_house(transit_chart, "Jupiter", 2) or
                          _is_transit_aspecting_house(transit_chart, "Jupiter", 11))
            transit_desc = "Jupiter transit-aspect on wealth houses" if transit_hit else ""

            if dasha_hit and transit_hit:
                return "peak", f"{dasha_desc} + {transit_desc}"
            if dasha_hit:
                return "moderate", dasha_desc
            if transit_hit:
                return "moderate", transit_desc
            return "background", ""
        except (ValueError, IndexError):
            pass

    # Named dhana yogas
    named_planets = {
        "lakshmi_yoga":         "Venus",
        "kubera_yoga":          "Jupiter",
        "kalpadruma_yoga":      "Jupiter",
        "guru_mangala_yoga":    "Jupiter",
        "saraswati_yoga":       "Jupiter",
        "kalanidhi_yoga":       "Jupiter",
        "jupiter_in_2nd":       "Jupiter",
        "venus_in_2nd":         "Venus",
        "moon_in_11th":         "Moon",
    }
    p = named_planets.get(yid)
    if p:
        hit, desc = _is_planet_in_dasha(dasha_state, p)
        if hit:
            return "moderate", desc
        # Transit p in 2nd or 11th from natal lagna
        from yogas_helpers import SIGN_INDEX
        trans_sign = planet_sign(transit_chart, p)
        asc_idx = SIGN_INDEX.get(natal_chart.get("ascendant", {}).get("sign", ""), 0)
        if trans_sign:
            trans_h = ((SIGN_INDEX.get(trans_sign, 0) - asc_idx) % 12) + 1
            if trans_h in (2, 11):
                return "moderate", f"Transit {p} in house {trans_h}"
        return "background", ""

    return "background", ""


def activation_for_vipreet_raja(yoga, natal_chart, transit_chart, dasha_state):
    """Vipreet Raja yogas (Harsha/Sarala/Vimala) activate during dusthana lord dashas."""
    yid = yoga["yoga_id"]
    house_map = {"harsha_yoga": 6, "sarala_yoga": 8, "vimala_yoga": 12}
    h = house_map.get(yid)
    if h:
        lord = lord_of_house(natal_chart, h)
        hit, desc = _is_planet_in_dasha(dasha_state, lord)
        if hit:
            return "moderate", desc
        # Transit Saturn or Jupiter aspecting that house
        transit_hit = (_is_transit_aspecting_house(transit_chart, "Saturn", h) or
                      _is_transit_aspecting_house(transit_chart, "Jupiter", h))
        if transit_hit:
            return "moderate", f"Transit Saturn/Jupiter aspecting house {h}"
    return "background", ""


def activation_for_chandra_yoga(yoga, natal_chart, transit_chart, dasha_state):
    """Chandra yogas activate during Moon dasha or when transit Moon-Jupiter form auspicious patterns."""
    yid = yoga["yoga_id"]

    # Moon dasha is the primary trigger for all chandra yogas
    moon_hit, moon_desc = _is_planet_in_dasha(dasha_state, "Moon")

    if yid in ("adhi_yoga", "chandradhi_yoga", "vasumati_yoga"):
        # Jupiter dasha also activates
        jup_hit, jup_desc = _is_planet_in_dasha(dasha_state, "Jupiter")
        if moon_hit and jup_hit:
            return "peak", f"{moon_desc} + {jup_desc}"
        if moon_hit or jup_hit:
            return "moderate", moon_desc or jup_desc

    if yid in ("moon_with_rahu", "moon_with_saturn", "moon_with_ketu", "papa_kartari_moon"):
        # These activate negatively during malefic dashas
        for malefic in ("Rahu", "Ketu", "Saturn"):
            hit, desc = _is_planet_in_dasha(dasha_state, malefic)
            if hit:
                return "moderate", desc

    if moon_hit:
        return "moderate", moon_desc

    return "background", ""


def activation_for_surya_yoga(yoga, natal_chart, transit_chart, dasha_state):
    """Surya yogas activate during Sun dasha or solar transits."""
    yid = yoga["yoga_id"]

    sun_hit, sun_desc = _is_planet_in_dasha(dasha_state, "Sun")

    if yid == "budha_aditya_yoga":
        merc_hit, merc_desc = _is_planet_in_dasha(dasha_state, "Mercury")
        if sun_hit and merc_hit:
            return "peak", f"{sun_desc} + {merc_desc}"
        if sun_hit or merc_hit:
            return "moderate", sun_desc or merc_desc

    if sun_hit:
        return "moderate", sun_desc
    return "background", ""


def activation_for_argala(yoga, natal_chart, transit_chart, dasha_state):
    """Argala yogas activate when planets occupying the supportive houses are in dasha."""
    yid = yoga["yoga_id"]
    try:
        h = int(yid.replace("argala_h", ""))
    except ValueError:
        return "background", ""

    # The planet(s) creating argala are in 2/4/5/11 from house h
    from yogas_helpers import NON_NODES
    supporting_planets = [
        p for p in NON_NODES
        if planet_house(natal_chart, p) is not None and
        ((planet_house(natal_chart, p) - h) % 12) in (1, 3, 4, 10)
    ]
    for p in supporting_planets:
        hit, desc = _is_planet_in_dasha(dasha_state, p)
        if hit:
            return "moderate", f"Argala-planet {desc}"
    return "background", ""


def activation_for_bhava_yoga(yoga, natal_chart, transit_chart, dasha_state):
    """Bhava yogas activate when the bhava lord is in dasha."""
    yid = yoga["yoga_id"]
    try:
        h = int(yid.replace("strong_bhava_", ""))
    except ValueError:
        return "background", ""

    lord = lord_of_house(natal_chart, h)
    hit, desc = _is_planet_in_dasha(dasha_state, lord)

    # Transit Jupiter aspecting the bhava
    transit_jup = _is_transit_aspecting_house(transit_chart, "Jupiter", h)
    transit_desc = f"Jupiter transit-aspect on h{h}" if transit_jup else ""

    if hit and transit_jup:
        return "peak", f"{desc} + {transit_desc}"
    if hit:
        return "moderate", desc
    if transit_jup:
        return "moderate", transit_desc
    return "background", ""


def activation_for_planet_in_house(yoga, natal_chart, transit_chart, dasha_state):
    """Planet-in-house yogas activate during that planet's dasha."""
    yid = yoga["yoga_id"]

    # Parse "X_in_Yth" pattern
    planets_map = {
        "jupiter": "Jupiter", "venus": "Venus", "mercury": "Mercury",
        "mars": "Mars", "saturn": "Saturn", "sun": "Sun", "moon": "Moon",
    }
    for p_key, p_name in planets_map.items():
        if yid.startswith(p_key + "_in_"):
            hit, desc = _is_planet_in_dasha(dasha_state, p_name)
            if hit:
                return "moderate", desc
            return "background", ""

    return "background", ""


def activation_for_parivartana(yoga, natal_chart, transit_chart, dasha_state):
    """Parivartana yogas activate when either exchange-lord is in dasha."""
    yid = yoga["yoga_id"]
    try:
        # pattern parivartana_X_Y
        parts = yid.split("_")
        h1, h2 = int(parts[-2]), int(parts[-1])
    except (ValueError, IndexError):
        return "background", ""

    l1 = lord_of_house(natal_chart, h1)
    l2 = lord_of_house(natal_chart, h2)
    h1_hit, h1_desc = _is_planet_in_dasha(dasha_state, l1)
    h2_hit, h2_desc = _is_planet_in_dasha(dasha_state, l2)

    if h1_hit and h2_hit:
        return "peak", f"{h1_desc} + {h2_desc}"
    if h1_hit or h2_hit:
        return "moderate", h1_desc or h2_desc
    return "background", ""


def activation_for_arishta(yoga, natal_chart, transit_chart, dasha_state):
    """Arishta yogas activate during malefic dashas — these are when difficulties surface."""
    yid = yoga["yoga_id"]

    # All arishta yogas peak during Rahu/Ketu/Saturn dashas
    for malefic in ("Rahu", "Ketu", "Saturn", "Mars"):
        hit, desc = _is_planet_in_dasha(dasha_state, malefic)
        if hit:
            # Specific yoga + specific malefic = peak negative
            specific = {
                "kala_sarpa_yoga":      ("Rahu", "Ketu"),
                "guru_chandala_yoga":   ("Jupiter", "Rahu", "Ketu"),
                "angarak_yoga":         ("Mars", "Rahu"),
                "shrapit_dosha":        ("Saturn", "Rahu"),
                "vish_yoga_strong":     ("Moon", "Saturn"),
            }
            if yid in specific and malefic in specific[yid]:
                return "peak", f"{desc} (yoga's own malefic)"
            return "moderate", desc

    return "background", ""


def activation_for_special_outcome(yoga, natal_chart, transit_chart, dasha_state):
    """Special outcome yogas — try common planet patterns."""
    yid = yoga["yoga_id"]

    # Map of special yoga → primary trigger planet
    primary_map = {
        "bharati_yoga":           "Jupiter",
        "kurma_yoga":             "Jupiter",
        "khadga_yoga":            "Jupiter",
        "putra_yoga":             "Jupiter",
        "kalatra_yoga":           "Venus",
        "ayushman_yoga":          "Saturn",
        "akhanda_samrajya_yoga":  "Jupiter",
        "saraswati_strict":       "Jupiter",
        "matsya_yoga":            "Jupiter",
    }
    p = primary_map.get(yid)
    if p:
        hit, desc = _is_planet_in_dasha(dasha_state, p)
        if hit:
            return "moderate", desc

    # Lagna-lord based yogas
    if yid in ("lagnesha_in_kendra", "lagnesha_in_trikona"):
        ll = lord_of_house(natal_chart, 1)
        hit, desc = _is_planet_in_dasha(dasha_state, ll)
        if hit:
            return "moderate", desc

    return "background", ""


def activation_for_misc(yoga, natal_chart, transit_chart, dasha_state):
    """Miscellaneous named yogas."""
    yid = yoga["yoga_id"]

    misc_planet_map = {
        "shankh_yoga":             "Jupiter",
        "indra_yoga":              "Moon",
        "parvata_yoga":            "Jupiter",
        "trilochana_yoga":         "Mars",
        "lagnadhi_yoga":           "Jupiter",
        "chandradhi_lagna":        "Moon",
        "amruth_yoga":             "Jupiter",
        "go_yoga":                 "Jupiter",
        "vidya_yoga":              "Mercury",
        "ravi_chandra_yoga":       "Sun",
        "siddha_yoga":             "Jupiter",
        "sat_sangam_yoga":         "Jupiter",
        "jupiter_saturn_conjunction": "Jupiter",
    }
    p = misc_planet_map.get(yid)
    if p:
        hit, desc = _is_planet_in_dasha(dasha_state, p)
        if hit:
            return "moderate", desc

    return "background", ""


def activation_for_nabhasa(yoga, natal_chart, transit_chart, dasha_state):
    """Nabhasa yogas are structural - they're constant, so always background to moderate."""
    # Slow planet transits make these feel stronger
    for p in ("Jupiter", "Saturn"):
        hit, desc = _is_planet_in_dasha(dasha_state, p)
        if hit:
            return "moderate", desc
    return "background", ""


def activation_for_daridra(yoga, natal_chart, transit_chart, dasha_state):
    """Daridra/poverty yogas activate during dusthana-lord dashas."""
    yid = yoga["yoga_id"]

    # These yogas relate to specific weak lords
    weak_lord_map = {
        "daridra_2_lord_in_dusthana":  lord_of_house(natal_chart, 2),
        "daridra_11_lord_in_dusthana": lord_of_house(natal_chart, 11),
        "lagna_lord_in_12":            lord_of_house(natal_chart, 1),
        "9_lord_in_8":                 lord_of_house(natal_chart, 9),
        "jupiter_in_dusthana":         "Jupiter",
    }
    l = weak_lord_map.get(yid)
    if l:
        hit, desc = _is_planet_in_dasha(dasha_state, l)
        if hit:
            return "moderate", desc
    return "background", ""


def activation_for_sanyasa(yoga, natal_chart, transit_chart, dasha_state):
    """Sanyasa yogas surface during Saturn/Ketu dashas."""
    for malefic in ("Saturn", "Ketu"):
        hit, desc = _is_planet_in_dasha(dasha_state, malefic)
        if hit:
            return "moderate", desc
    return "background", ""


# ─────────────────────────────────────────────────────────────────────────────
# DISPATCHER — pick the right rule based on yoga family
# ─────────────────────────────────────────────────────────────────────────────

FAMILY_RULES = {
    "pancha_mahapurusha":  activation_for_pancha_mahapurusha,
    "raja_yoga":           activation_for_raja_yoga,
    "dhana_yoga":          activation_for_dhana_yoga,
    "vipreet_raja":        activation_for_vipreet_raja,
    "chandra_yoga":        activation_for_chandra_yoga,
    "surya_yoga":          activation_for_surya_yoga,
    "argala":              activation_for_argala,
    "bhava_yoga":          activation_for_bhava_yoga,
    "planet_in_house":     activation_for_planet_in_house,
    "parivartana":         activation_for_parivartana,
    "arishta":             activation_for_arishta,
    "special_outcome":     activation_for_special_outcome,
    "misc":                activation_for_misc,
    "nabhasa_akriti":      activation_for_nabhasa,
    "nabhasa_sankhya":     activation_for_nabhasa,
    "nabhasa_ashraya":     activation_for_nabhasa,
    "nabhasa_dala":        activation_for_nabhasa,
    "daridra":             activation_for_daridra,
    "sanyasa":             activation_for_sanyasa,
}


def get_activation_state(yoga, natal_chart, transit_chart, dasha_state):
    """
    Main entry point: return (intensity, trigger_description) for a yoga at a given moment.
    
    intensity ∈ {"peak", "moderate", "background"}
      peak       = dasha + transit alignment
      moderate   = one trigger present
      background = yoga is natally present but neither trigger fires
    """
    family = yoga.get("family", "")
    rule_fn = FAMILY_RULES.get(family)
    if rule_fn is None:
        return "background", ""
    try:
        return rule_fn(yoga, natal_chart, transit_chart, dasha_state)
    except Exception:
        return "background", ""
