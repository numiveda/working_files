"""
ramal.py — numiVeda Kaaliyo Astro Engine — Module E1.

Ramal Shastra divination engine (Indian Zaycha tradition).
Pure deterministic computation — given dice values in, chart and verdicts come out.

11 endpoints:
    handle_profile           — MASTER: cast chart + apply rules + verdicts
    handle_cast_chart        — 4 mother keys → 15-house chart
    handle_cast_from_throws  — 4 throws × 4 values each → full chart
    handle_figure_from_throw — Single throw (4 values) → 1 figure
    handle_figure_lookup     — Key or number → figure attributes
    handle_figures_catalog   — All 16 figures
    handle_house_domains     — All 15 house meanings
    handle_hope_formula      — H11 Triple Prastara
    handle_check_theft       — Theft indicator scan
    handle_check_captivity   — H12-H15 exception check
    handle_dot_count         — Bindu count → life/death rule
    handle_question_reading  — Question-focused: cast + apply domain rules + format

NOTE: Ramal does not use birth chart. All randomness is provided by user as dice throws.
Per user UX: throws can be dice (1-6), digits, or any integers (only odd/even matters).
"""

from typing import Dict, List, Optional, Any

from ramal_data import (
    FIGURES,
    FIGURES_BY_NUMBER,
    HOUSE_DOMAINS,
    DOMAIN_TO_HOUSE,
    CATEGORIES,
    NATURES,
    THEFT_INDICATORS,
    CAPTIVITY_EXCEPTION,
    DOT_COUNT_THRESHOLDS,
    CLASSICAL_CITATIONS,
)


# ════════════════════════════════════════════════════════════════════════
# CORE ROW/FIGURE PRIMITIVES (ports of ramal.js helpers)
# ════════════════════════════════════════════════════════════════════════

def _row_polarity(n: int) -> str:
    """A row's polarity from its dice/integer value: odd or even."""
    return "odd" if n % 2 == 1 else "even"


def _add_rows(a: str, b: str) -> str:
    """
    Prastara row-addition:
    odd  + odd  = even (same → passive)
    even + even = even (same → passive)
    odd  + even = odd  (different → active)
    even + odd  = odd  (different → active)
    """
    return "even" if a == b else "odd"


def _rows_to_key(r1: str, r2: str, r3: str, r4: str) -> str:
    return f"{r1}-{r2}-{r3}-{r4}"


def _lookup_figure(key: str) -> Dict[str, Any]:
    """Look up figure attributes by row-pattern key. Returns Jamaat as fallback."""
    return FIGURES.get(key, FIGURES["even-even-even-even"])


def _add_figures(key_a: str, key_b: str) -> str:
    """Add two figure keys row-by-row → new key."""
    a_rows = key_a.split("-")
    b_rows = key_b.split("-")
    result = [_add_rows(a, b) for a, b in zip(a_rows, b_rows)]
    return "-".join(result)


def _mother_from_throw(throw_values: List[int]) -> Dict[str, Any]:
    """
    Generate 1 Mother figure from 4 row values.
    throw_values: array of 4 integers (1-6 face value, or any integer).
    Only odd/even matters.
    """
    if len(throw_values) != 4:
        raise ValueError(f"Mother throw needs exactly 4 row values, got {len(throw_values)}")
    rows = [_row_polarity(v) for v in throw_values]
    key = _rows_to_key(*rows)
    return {
        "key":          key,
        "rows":         rows,
        "throw_values": throw_values,
        "figure":       _lookup_figure(key),
    }


def _build_chart(mother_keys: List[str]) -> Dict[int, Dict[str, Any]]:
    """
    Build complete 15-house chart from 4 Mother keys.
    H1-H4: Mothers (provided)
    H5-H8: Daughters (transpose rows of H1..H4)
    H9-H12: Nieces (add adjacent pairs)
    H13-H14: Witnesses
    H15: Judge
    """
    if len(mother_keys) != 4:
        raise ValueError(f"Need exactly 4 mother keys, got {len(mother_keys)}")

    # 1-indexed slots
    h: Dict[int, str] = {}

    # H1-H4: Mothers
    for i in range(4):
        h[i + 1] = mother_keys[i]

    # H5-H8: Daughters — transpose
    # H5 = row 1 of [H1, H2, H3, H4]
    # H6 = row 2
    # H7 = row 3
    # H8 = row 4
    for d in range(4):
        rows = [h[1].split("-")[d], h[2].split("-")[d],
                h[3].split("-")[d], h[4].split("-")[d]]
        h[5 + d] = "-".join(rows)

    # H9-H12: Nieces (adjacent pair addition)
    h[9]  = _add_figures(h[1], h[2])
    h[10] = _add_figures(h[3], h[4])
    h[11] = _add_figures(h[5], h[6])
    h[12] = _add_figures(h[7], h[8])

    # H13-H14: Witnesses
    h[13] = _add_figures(h[9],  h[10])  # Right Witness
    h[14] = _add_figures(h[11], h[12])  # Left Witness

    # H15: Judge
    h[15] = _add_figures(h[13], h[14])

    # Resolve to full attribute dicts
    chart: Dict[int, Dict[str, Any]] = {}
    for i in range(1, 16):
        chart[i] = {
            "house":  i,
            "key":    h[i],
            "role":   HOUSE_DOMAINS[i]["role"],
            "domain": HOUSE_DOMAINS[i]["domain"],
            **_lookup_figure(h[i]),
        }
    return chart


# ════════════════════════════════════════════════════════════════════════
# SPECIAL RULES (Hope, Theft, Captivity, Dot count)
# ════════════════════════════════════════════════════════════════════════

def _hope_formula(chart: Dict[int, Dict[str, Any]]) -> Dict[str, Any]:
    """
    Triple Prastara for H11 (hopes):
    Result_A = H1 × H11
    Result_B = H1 × H14
    Final    = A × B
    If Final appears in any of 15 houses → hope fulfilled via that house's domain
    """
    result_a = _add_figures(chart[1]["key"], chart[11]["key"])
    result_b = _add_figures(chart[1]["key"], chart[14]["key"])
    final_key = _add_figures(result_a, result_b)
    final_fig = _lookup_figure(final_key)

    found_in_house: Optional[int] = None
    for i in range(1, 16):
        if chart[i]["key"] == final_key:
            found_in_house = i
            break

    return {
        "result_a":       {"key": result_a, **_lookup_figure(result_a)},
        "result_b":       {"key": result_b, **_lookup_figure(result_b)},
        "final_key":      final_key,
        "final_figure":   final_fig,
        "found_in_house": found_in_house,
        "found_in_domain":HOUSE_DOMAINS[found_in_house]["domain"] if found_in_house else None,
        "hope_fulfilled": found_in_house is not None,
    }


def _check_theft(chart: Dict[int, Dict[str, Any]]) -> Dict[str, Any]:
    """
    If any of Naki, Humra, Atave Kharij, Qabzul Kharij present in 15 houses → theft indicated.
    Otherwise: item misplaced, not stolen.
    """
    present: List[Dict[str, Any]] = []
    for i in range(1, 16):
        if chart[i]["name"] in THEFT_INDICATORS:
            present.append({"house": i, "figure": chart[i]["name"]})
    return {
        "theft_indicated":   len(present) > 0,
        "present_indicators":present,
        "indicators_checked":THEFT_INDICATORS,
        "verdict": (
            "Item was not stolen. It is misplaced in the home. Search there."
            if len(present) == 0 else
            "Theft indicated — at least one classical theft figure is present in the chart."
        ),
    }


def _check_captivity(chart: Dict[int, Dict[str, Any]]) -> Dict[str, Any]:
    """
    Captivity exception: H12 category == Kharij AND H15 figure == Ukla → no release.
    """
    h12_category = chart[12]["category"]
    h15_name = chart[15]["name"]
    triggered = (h12_category == CAPTIVITY_EXCEPTION["h12_must_be_category"]
                 and h15_name == CAPTIVITY_EXCEPTION["h15_must_be_figure"])
    return {
        "exception_triggered": triggered,
        "h12_category":        h12_category,
        "h15_figure":          h15_name,
        "exception_rule":      f"H12 must be {CAPTIVITY_EXCEPTION['h12_must_be_category']} category AND H15 must be {CAPTIVITY_EXCEPTION['h15_must_be_figure']}",
        "verdict":             CAPTIVITY_EXCEPTION["verdict"] if triggered else None,
    }


def _dot_count(chart: Dict[int, Dict[str, Any]]) -> Dict[str, Any]:
    """
    Count total odd rows (Bindus / active points) across all 15 houses.
    >32 = alive, <32 = dead, =32 = extreme distress
    """
    total = 0
    per_house: Dict[int, int] = {}
    for i in range(1, 16):
        rows = chart[i]["key"].split("-")
        count_odd = sum(1 for r in rows if r == "odd")
        per_house[i] = count_odd
        total += count_odd

    if total > 32:
        verdict = "alive"
    elif total < 32:
        verdict = "dead"
    else:
        verdict = "extreme distress, life hangs in balance"

    return {
        "total_dots":    total,
        "per_house":     per_house,
        "verdict":       verdict,
        "threshold_logic": "Bindus > 32 = alive | < 32 = dead | = 32 = extreme distress",
    }


# ════════════════════════════════════════════════════════════════════════
# CHART SUMMARY HELPERS
# ════════════════════════════════════════════════════════════════════════

def _chart_summary_compact(chart: Dict[int, Dict[str, Any]]) -> Dict[int, Dict[str, Any]]:
    """Compact form for downstream AI consumption."""
    summary: Dict[int, Dict[str, Any]] = {}
    for i in range(1, 16):
        summary[i] = {
            "name":     chart[i]["name"],
            "key":      chart[i]["key"],
            "category": chart[i]["category"],
            "nature":   chart[i]["nature"],
            "element":  chart[i]["element"],
            "planet":   chart[i]["planet"],
            "role":     chart[i]["role"],
        }
    return summary


def _format_chart_for_prompt(
    chart: Dict[int, Dict[str, Any]],
    question: str,
    domain: str,
    first_name: str,
) -> str:
    """
    Format the 15-house chart as a structured prompt for AI interpretation layer
    (matches the JS formatChartForPrompt output for prompt compatibility).
    """
    primary_house = DOMAIN_TO_HOUSE.get(domain, 1)
    primary_fig = chart[primary_house]
    judge = chart[15]

    # House grid summary
    house_lines: List[str] = []
    for i in range(1, 16):
        f = chart[i]
        if i <= 4:
            label = f"H{i} (Mother)"
        elif i <= 8:
            label = f"H{i} (Daughter)"
        elif i <= 12:
            label = f"H{i} (Niece)"
        elif i == 13:
            label = "H13 (Right Witness)"
        elif i == 14:
            label = "H14 (Left Witness)"
        else:
            label = "H15 (Judge)"
        house_lines.append(f"  {label}: {f['name']} [{f['category']}, {f['nature']}, {f['element']}, {f['planet']}]")

    # Domain-specific notes
    prastara_note = ""
    captivity_note = ""
    dot_note = ""

    if domain in ("health", "captivity", "legal", "career"):
        prastara_note = "\nPrastara formula available for this domain if relevant."

    if domain == "hopes":
        hope = _hope_formula(chart)
        if hope["hope_fulfilled"]:
            prastara_note = (f"\nHope formula result: Final Figure = {hope['final_figure']['name']} "
                            f"[{hope['final_figure']['category']}, {hope['final_figure']['nature']}]. "
                            f"Found in H{hope['found_in_house']} ({hope['found_in_domain']}) — hope fulfilled via this domain.")
        else:
            prastara_note = (f"\nHope formula result: Final Figure = {hope['final_figure']['name']} "
                            f"[{hope['final_figure']['category']}, {hope['final_figure']['nature']}]. "
                            f"Not found in chart — hope does not manifest.")

    if domain in ("marriage", "wealth"):
        theft = _check_theft(chart)
        if not theft["theft_indicated"] and domain == "marriage":
            prastara_note = f"\nTheft check: {theft['verdict']}"

    if domain == "captivity":
        cap = _check_captivity(chart)
        if cap["exception_triggered"]:
            captivity_note = f"\nCRITICAL EXCEPTION: {cap['verdict']}"

    if domain == "travel":
        dots = _dot_count(chart)
        dot_note = f"\nDot count (Bindu total): {dots['total_dots']} — classical verdict: {dots['verdict']}"

    return f"""RAMAL CHART (pre-computed by engine — do not recalculate):

Question: {question}
Querent's first name: {first_name}
Question domain: {domain}
Primary house: H{primary_house} ({HOUSE_DOMAINS[primary_house]['domain']})

PRIMARY HOUSE FIGURE:
  H{primary_house}: {primary_fig['name']} [{primary_fig['category']}, {primary_fig['nature']}, {primary_fig['element']}, {primary_fig['planet']}]

THE JUDGE:
  H15: {judge['name']} [{judge['category']}, {judge['nature']}] — Judge verdict: {judge['judge']}

ALL 15 HOUSES:
{chr(10).join(house_lines)}
{prastara_note}{captivity_note}{dot_note}

FIGURE DOT PATTERNS (for reference):
  odd row = single dot (•) | even row = double dot (••)"""


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT HANDLERS
# ════════════════════════════════════════════════════════════════════════

def handle_figure_from_throw(throw_values: List[int]) -> Dict[str, Any]:
    """Single throw of 4 row values → 1 figure with attributes."""
    if not isinstance(throw_values, list) or len(throw_values) != 4:
        return {"error": "throw_values must be a list of exactly 4 integers"}
    try:
        result = _mother_from_throw(throw_values)
        return {
            **result,
            "method":   "Each integer's parity (odd/even) determines row polarity. The 4 rows compose the figure key.",
            "citation": CLASSICAL_CITATIONS["ramal_tradition"],
        }
    except Exception as e:
        return {"error": str(e)}


def handle_cast_chart(mother_keys: List[str]) -> Dict[str, Any]:
    """
    4 Mother keys (e.g. 'odd-even-even-odd') → complete 15-house chart.
    """
    if not isinstance(mother_keys, list) or len(mother_keys) != 4:
        return {"error": "mother_keys must be a list of exactly 4 row-pattern keys"}
    try:
        chart = _build_chart(mother_keys)
        return {
            "chart":            chart,
            "summary":          _chart_summary_compact(chart),
            "method":           "15-house chart derived from 4 Mothers: H5-H8 by row transpose, H9-H12 by Prastara pair-addition, H13-H14 Witnesses, H15 Judge.",
            "citation":         CLASSICAL_CITATIONS["prastara"],
        }
    except Exception as e:
        return {"error": str(e)}


def handle_cast_from_throws(throws: List[List[int]]) -> Dict[str, Any]:
    """
    Convenience: 4 throws × 4 row values → full chart.
    throws: [[r1,r2,r3,r4], [r1,r2,r3,r4], [r1,r2,r3,r4], [r1,r2,r3,r4]]
    """
    if not isinstance(throws, list) or len(throws) != 4:
        return {"error": "throws must be a list of exactly 4 throws"}

    mother_results: List[Dict[str, Any]] = []
    mother_keys: List[str] = []
    try:
        for i, throw in enumerate(throws):
            if not isinstance(throw, list) or len(throw) != 4:
                return {"error": f"throw {i+1} must be a list of 4 integers"}
            m = _mother_from_throw(throw)
            mother_results.append(m)
            mother_keys.append(m["key"])
    except Exception as e:
        return {"error": str(e)}

    chart = _build_chart(mother_keys)
    return {
        "mothers":      mother_results,
        "chart":        chart,
        "summary":      _chart_summary_compact(chart),
        "method":       "User-provided 4 throws of 4 row values each → 4 Mothers → 15-house Ramal chart.",
        "citation":     CLASSICAL_CITATIONS["prastara"],
    }


def handle_figure_lookup(key: Optional[str] = None,
                          number: Optional[int] = None) -> Dict[str, Any]:
    """Look up a figure by row-pattern key OR by classical number 1-16."""
    if key is not None:
        if key not in FIGURES:
            return {"error": f"Key '{key}' not in 16 valid figure keys",
                    "valid_keys": list(FIGURES.keys())}
        return {"key": key, "figure": FIGURES[key], "citation": CLASSICAL_CITATIONS["ramal_tradition"]}

    if number is not None:
        if number not in FIGURES_BY_NUMBER:
            return {"error": f"Number must be 1-16, got {number}"}
        figkey = FIGURES_BY_NUMBER[number]
        return {"key": figkey, "figure": FIGURES[figkey], "citation": CLASSICAL_CITATIONS["ramal_tradition"]}

    return {"error": "Provide either 'key' or 'number'"}


def handle_figures_catalog() -> Dict[str, Any]:
    """Return all 16 figures with full attributes."""
    return {
        "figures":       FIGURES,
        "by_number":     FIGURES_BY_NUMBER,
        "categories":    CATEGORIES,
        "natures":       NATURES,
        "figure_count":  len(FIGURES),
        "citation":      CLASSICAL_CITATIONS["ramal_tradition"],
    }


def handle_house_domains() -> Dict[str, Any]:
    """Return all 15 house meanings + domain→house mapping."""
    return {
        "houses":          HOUSE_DOMAINS,
        "domain_to_house": DOMAIN_TO_HOUSE,
        "house_count":     len(HOUSE_DOMAINS),
        "citation":        CLASSICAL_CITATIONS["ramal_tradition"],
    }


def handle_hope_formula(mother_keys: List[str]) -> Dict[str, Any]:
    """Apply hope-formula Triple Prastara to a cast chart."""
    if not isinstance(mother_keys, list) or len(mother_keys) != 4:
        return {"error": "mother_keys must be a list of exactly 4 row-pattern keys"}
    try:
        chart = _build_chart(mother_keys)
        hope = _hope_formula(chart)
        return {
            **hope,
            "method":   "(H1 × H11) combined with (H1 × H14) → Final. If Final appears in any house, hope is fulfilled via that house's domain.",
            "citation": CLASSICAL_CITATIONS["hope_formula"],
        }
    except Exception as e:
        return {"error": str(e)}


def handle_check_theft(mother_keys: List[str]) -> Dict[str, Any]:
    """Scan chart for theft indicators."""
    if not isinstance(mother_keys, list) or len(mother_keys) != 4:
        return {"error": "mother_keys must be a list of exactly 4 row-pattern keys"}
    try:
        chart = _build_chart(mother_keys)
        theft = _check_theft(chart)
        return {
            **theft,
            "method":   "Scan all 15 houses for presence of Naki, Humra, Atave Kharij, Qabzul Kharij. Absence indicates misplacement only.",
            "citation": CLASSICAL_CITATIONS["theft_rule"],
        }
    except Exception as e:
        return {"error": str(e)}


def handle_check_captivity(mother_keys: List[str]) -> Dict[str, Any]:
    """Check H12-H15 captivity exception."""
    if not isinstance(mother_keys, list) or len(mother_keys) != 4:
        return {"error": "mother_keys must be a list of exactly 4 row-pattern keys"}
    try:
        chart = _build_chart(mother_keys)
        cap = _check_captivity(chart)
        return {
            **cap,
            "method":   "Check if H12 is Kharij category AND H15 is Ukla → no release possible.",
            "citation": CLASSICAL_CITATIONS["captivity_rule"],
        }
    except Exception as e:
        return {"error": str(e)}


def handle_dot_count(mother_keys: List[str]) -> Dict[str, Any]:
    """Bindu (dot) count across all 15 houses."""
    if not isinstance(mother_keys, list) or len(mother_keys) != 4:
        return {"error": "mother_keys must be a list of exactly 4 row-pattern keys"}
    try:
        chart = _build_chart(mother_keys)
        dots = _dot_count(chart)
        return {
            **dots,
            "method":   "Count of odd-rows (active points) across all 15 houses. Used in life/death questions.",
            "citation": CLASSICAL_CITATIONS["dot_count"],
        }
    except Exception as e:
        return {"error": str(e)}


def handle_question_reading(
    throws: List[List[int]],
    question: str,
    domain: str = "other",
    first_name: str = "Querent",
) -> Dict[str, Any]:
    """
    Master question-focused endpoint:
    - Cast chart from 4 throws
    - Apply domain-specific rule (hope/theft/captivity/dot)
    - Return primary house figure + Judge + AI-ready prompt context
    """
    if not isinstance(throws, list) or len(throws) != 4:
        return {"error": "throws must be a list of 4 throws (each a list of 4 ints)"}
    if not question or len(question.strip()) < 3:
        return {"error": "question is required (min 3 chars)"}

    domain_normalized = domain if domain in DOMAIN_TO_HOUSE else "other"

    mother_keys: List[str] = []
    mother_results: List[Dict[str, Any]] = []
    try:
        for i, throw in enumerate(throws):
            if not isinstance(throw, list) or len(throw) != 4:
                return {"error": f"throw {i+1} must be a list of 4 integers"}
            m = _mother_from_throw(throw)
            mother_results.append(m)
            mother_keys.append(m["key"])
    except Exception as e:
        return {"error": str(e)}

    chart = _build_chart(mother_keys)
    primary_house = DOMAIN_TO_HOUSE[domain_normalized]
    primary_fig = chart[primary_house]
    judge = chart[15]

    # Domain-specific rule application
    domain_rule_result: Dict[str, Any] = {}
    if domain_normalized == "hopes":
        domain_rule_result["hope_formula"] = _hope_formula(chart)
    if domain_normalized in ("marriage", "wealth"):
        domain_rule_result["theft_check"] = _check_theft(chart)
    if domain_normalized == "captivity":
        domain_rule_result["captivity_check"] = _check_captivity(chart)
    if domain_normalized == "travel":
        domain_rule_result["dot_count"] = _dot_count(chart)

    prompt_context = _format_chart_for_prompt(chart, question.strip(), domain_normalized, first_name)

    return {
        "question":         question.strip(),
        "domain":           domain_normalized,
        "first_name":       first_name,
        "primary_house":    primary_house,
        "primary_figure":   primary_fig,
        "judge":            judge,
        "chart_summary":    _chart_summary_compact(chart),
        "domain_rules":     domain_rule_result,
        "ai_prompt_context": prompt_context,
        "method":           "Question-focused master endpoint: cast chart from throws + apply domain-specific classical rule + format prompt context for AI interpretation layer.",
        "citation":         CLASSICAL_CITATIONS["ramal_tradition"],
    }


def handle_profile(throws: List[List[int]]) -> Dict[str, Any]:
    """
    MASTER endpoint: cast chart + apply ALL classical rules + headlines.
    Used for general overview questions or "show me everything" UX.
    """
    if not isinstance(throws, list) or len(throws) != 4:
        return {"error": "throws must be a list of 4 throws (each a list of 4 ints)"}

    mother_keys: List[str] = []
    try:
        for i, throw in enumerate(throws):
            if not isinstance(throw, list) or len(throw) != 4:
                return {"error": f"throw {i+1} must be a list of 4 integers"}
            mother_keys.append(_mother_from_throw(throw)["key"])
    except Exception as e:
        return {"error": str(e)}

    chart = _build_chart(mother_keys)

    # Apply ALL rules
    hope = _hope_formula(chart)
    theft = _check_theft(chart)
    captivity = _check_captivity(chart)
    dots = _dot_count(chart)

    judge = chart[15]
    right_witness = chart[13]
    left_witness = chart[14]

    # Headlines
    headlines: List[str] = []
    headlines.append(f"Judge (H15): {judge['name']} — {judge['category']}/{judge['nature']} → {judge['judge']}")
    headlines.append(f"Right Witness (H13, past): {right_witness['name']} [{right_witness['category']}]")
    headlines.append(f"Left Witness (H14, future): {left_witness['name']} [{left_witness['category']}]")
    headlines.append(f"Bindu count: {dots['total_dots']} → {dots['verdict']}")
    if hope["hope_fulfilled"]:
        headlines.append(f"Hope formula resolves in H{hope['found_in_house']} ({hope['found_in_domain']})")
    else:
        headlines.append("Hope formula does not resolve in any house")
    if theft["theft_indicated"]:
        headlines.append(f"Theft indicators present: {[t['figure'] for t in theft['present_indicators']]}")
    if captivity["exception_triggered"]:
        headlines.append(f"⚠️ Captivity exception triggered: {captivity['verdict']}")

    return {
        "headlines":     headlines,
        "judge":         judge,
        "witnesses":     {"right": right_witness, "left": left_witness},
        "chart_summary": _chart_summary_compact(chart),
        "rules": {
            "hope_formula":    hope,
            "theft_check":     theft,
            "captivity_check": captivity,
            "dot_count":       dots,
        },
        "method":        "Master Ramal profile — full 15-house chart + all 4 classical special rules applied.",
        "citations":     CLASSICAL_CITATIONS,
    }
