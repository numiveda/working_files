"""
astro_helpers.py — Shared chart extraction + personalization helpers

Centralizes logic previously duplicated across:
- vastu.py (Module 2 — Astro Vastu)
- remedies.py (Module 3a — Master Remedies)
- remedies_esoteric.py (Module 3b — Esoteric Remedies)

Phase B modules (B1 Health, B2 Career/Wealth, B3 Prashna) and beyond will
import from this module instead of re-implementing the same logic.

Public API:
    extract_chart_essentials(chart_data) -> Dict
    get_chart(dob, time, lat, lon, timezone) -> Dict
    compute_house_lords(lagna_sign) -> Dict[int, str]
    afflicted_planets(chart_essentials) -> List[Dict]
    weakest_planet(chart_essentials) -> Optional[str]
    is_planet_safe_for_gemstone(planet, chart_essentials) -> Dict
    planet_to_direction() -> Dict[str, str]
    planet_to_deity() -> Dict[str, str]
    house_to_life_area() -> Dict[int, str]
    signs_order() -> List[str]
    sign_to_lord() -> Dict[str, str]
"""

from typing import Dict, List, Optional, Any
from dashaflow import cast_chart


# ════════════════════════════════════════════════════════════════════════
# CONSTANTS — Used across all Vedic modules
# ════════════════════════════════════════════════════════════════════════

SIGNS_ORDER = [
    "Aries", "Taurus", "Gemini", "Cancer",
    "Leo", "Virgo", "Libra", "Scorpio",
    "Sagittarius", "Capricorn", "Aquarius", "Pisces",
]


SIGN_TO_LORD = {
    "Aries":       "Mars",
    "Taurus":      "Venus",
    "Gemini":      "Mercury",
    "Cancer":      "Moon",
    "Leo":         "Sun",
    "Virgo":       "Mercury",
    "Libra":       "Venus",
    "Scorpio":     "Mars",
    "Sagittarius": "Jupiter",
    "Capricorn":   "Saturn",
    "Aquarius":    "Saturn",
    "Pisces":      "Jupiter",
}


PLANET_TO_DIRECTION = {
    "Sun":     "east",
    "Moon":    "northwest",
    "Mars":    "south",
    "Mercury": "north",
    "Jupiter": "northeast",
    "Venus":   "southeast",
    "Saturn":  "west",
    "Rahu":    "southwest",
    "Ketu":    "southwest",
}


PLANET_TO_DEITY = {
    "Sun":     "Indra",
    "Moon":    "Vayu",
    "Mars":    "Yama",
    "Mercury": "Kubera",
    "Jupiter": "Ishana",
    "Venus":   "Agni",
    "Saturn":  "Varuna",
    "Rahu":    "Nirriti",
    "Ketu":    "Nirriti",
}


HOUSE_TO_LIFE_AREA = {
    1:  "self, body, identity, vitality",
    2:  "wealth, family, speech, food",
    3:  "siblings, courage, communication",
    4:  "home, mother, vehicles, comfort",
    5:  "children, intelligence, creativity",
    6:  "enemies, disease, debts, service",
    7:  "spouse, partnerships, business",
    8:  "longevity, hidden things, transformation",
    9:  "father, fortune, dharma, higher learning",
    10: "career, fame, status",
    11: "gains, income, social network",
    12: "expenses, foreign, liberation",
}


# Classical Vedic planet body-part rulership (Charaka Samhita + BPHS)
PLANET_TO_BODY_PART = {
    "Sun":     "heart, eyes (right), spine, vitality, stomach",
    "Moon":    "mind, blood, lymph, breasts, fluids, left eye",
    "Mars":    "muscles, blood, bone marrow, head, sexual organs",
    "Mercury": "skin, nervous system, lungs, speech, intestines",
    "Jupiter": "liver, fat tissue, thighs, hips, ears",
    "Venus":   "kidneys, reproductive system, throat, semen, beauty",
    "Saturn":  "bones, teeth, knees, nerves, joints, chronic conditions",
    "Rahu":    "skin (chronic), nervous afflictions, poisoning, mysterious illness",
    "Ketu":    "abdominal, immunity, scars, surgical, auto-immune",
}


# Vedic Tridosha (Ayurvedic constitution) associations with planets
PLANET_TO_DOSHA = {
    "Sun":     ["pitta"],
    "Moon":    ["vata", "kapha"],
    "Mars":    ["pitta"],
    "Mercury": ["vata", "pitta", "kapha"],  # tridoshic
    "Jupiter": ["kapha"],
    "Venus":   ["kapha", "vata"],
    "Saturn":  ["vata"],
    "Rahu":    ["vata"],
    "Ketu":    ["vata", "pitta"],
}


# Sign-based Tridosha (sign element determines dosha)
SIGN_TO_DOSHA = {
    "Aries": "pitta",       "Taurus": "kapha",       "Gemini": "vata",
    "Cancer": "kapha",      "Leo": "pitta",          "Virgo": "vata",
    "Libra": "vata",        "Scorpio": "kapha",      "Sagittarius": "pitta",
    "Capricorn": "vata",    "Aquarius": "vata",      "Pisces": "kapha",
}


# Chakra system — 7 chakras + planetary associations
CHAKRA_SYSTEM = {
    "muladhara": {
        "name":           "Muladhara (Root)",
        "location":       "perineum, base of spine",
        "primary_planet": "Mars",
        "secondary_planet":"Saturn",
        "element":        "earth",
        "color":          "red",
        "bija_mantra":    "Lam",
        "petals":         4,
        "domain":         "survival, security, foundation, instinct",
    },
    "svadhisthana": {
        "name":           "Svadhisthana (Sacral)",
        "location":       "sacrum, lower abdomen",
        "primary_planet": "Moon",
        "secondary_planet":"Venus",
        "element":        "water",
        "color":          "orange",
        "bija_mantra":    "Vam",
        "petals":         6,
        "domain":         "emotions, sexuality, creativity, fluidity",
    },
    "manipura": {
        "name":           "Manipura (Solar Plexus)",
        "location":       "navel",
        "primary_planet": "Sun",
        "secondary_planet":"Mars",
        "element":        "fire",
        "color":          "yellow",
        "bija_mantra":    "Ram",
        "petals":         10,
        "domain":         "willpower, identity, transformation, vitality",
    },
    "anahata": {
        "name":           "Anahata (Heart)",
        "location":       "center of chest",
        "primary_planet": "Venus",
        "secondary_planet":"Mercury",
        "element":        "air",
        "color":          "green (sometimes pink)",
        "bija_mantra":    "Yam",
        "petals":         12,
        "domain":         "love, compassion, balance, healing",
    },
    "vishuddha": {
        "name":           "Vishuddha (Throat)",
        "location":       "throat",
        "primary_planet": "Mercury",
        "secondary_planet":"Jupiter",
        "element":        "ether",
        "color":          "blue",
        "bija_mantra":    "Ham",
        "petals":         16,
        "domain":         "expression, truth, communication, sound",
    },
    "ajna": {
        "name":           "Ajna (Third Eye)",
        "location":       "between eyebrows",
        "primary_planet": "Jupiter",
        "secondary_planet":"Sun",
        "element":        "light/mind",
        "color":          "indigo/violet",
        "bija_mantra":    "Om",
        "petals":         2,
        "domain":         "intuition, insight, wisdom, perception",
    },
    "sahasrara": {
        "name":           "Sahasrara (Crown)",
        "location":       "top of head",
        "primary_planet": "Ketu",
        "secondary_planet":"Jupiter",
        "element":        "consciousness",
        "color":          "violet/white",
        "bija_mantra":    "(silent / Aum)",
        "petals":         1000,
        "domain":         "moksha, divine connection, universal awareness",
    },
}


# ════════════════════════════════════════════════════════════════════════
# CHART EXTRACTION — The single canonical implementation
# ════════════════════════════════════════════════════════════════════════

def extract_chart_essentials(chart_data: Dict) -> Dict[str, Any]:
    """
    Pull chart essentials from cast_chart() output.

    Verified output structure (May 16, 2026):
      chart_data["lagna"]            = {sign, degree, nakshatra, pada, d2_sign...}
      chart_data["planets"]          = dict keyed by name (Sun/Moon/.../Ketu)
        each planet has {sign, degree, house, nakshatra, pada, dignity,
                          is_retrograde, is_combust, nakshatra_lord}
      chart_data["jaimini_karakas"]  = dict {Atmakaraka, Amatyakaraka, ...}
        each karaka: {planet, degree, description, sign, house, d9_sign}
      chart_data["dashas"]           = {maha, antar, pratyantar, sukshma, prana, timeline}
        each of maha/antar/etc is the CURRENTLY ACTIVE period
          {planet, start, end, years, days}
    """
    out = {
        "lagna_sign":         None,
        "lagna_degree":       None,
        "lagna_nakshatra":    None,
        "lagna_pada":         None,
        "lagna_lord":         None,
        "moon_sign":          None,
        "moon_house":         None,
        "moon_nakshatra":     None,
        "moon_pada":          None,
        "moon_nakshatra_lord":None,
        "sun_sign":           None,
        "sun_house":          None,
        "atmakaraka":         None,
        "atmakaraka_full":    None,
        "amatyakaraka":       None,
        "amatyakaraka_full":  None,
        "all_karakas":        {},
        "planets":            {},
        "current_md":         None,
        "current_md_full":    None,
        "current_ad":         None,
        "current_ad_full":    None,
        "current_pd":         None,
        "house_lords":        {},
        "twelfth_lord":       None,
    }

    # ── Lagna ──
    lagna_obj = chart_data.get("lagna")
    if isinstance(lagna_obj, dict):
        out["lagna_sign"]      = lagna_obj.get("sign")
        out["lagna_degree"]    = lagna_obj.get("degree")
        out["lagna_nakshatra"] = lagna_obj.get("nakshatra")
        out["lagna_pada"]      = lagna_obj.get("pada")
    elif isinstance(lagna_obj, str):
        out["lagna_sign"] = lagna_obj

    # ── Planets (dict keyed by name) ──
    planets_obj = chart_data.get("planets", {})
    if isinstance(planets_obj, dict):
        for name, pdata in planets_obj.items():
            if not isinstance(pdata, dict):
                continue
            out["planets"][name] = {
                "sign":           pdata.get("sign"),
                "degree":         pdata.get("degree"),
                "house":          pdata.get("house"),
                "nakshatra":      pdata.get("nakshatra"),
                "pada":           pdata.get("pada"),
                "nakshatra_lord": pdata.get("nakshatra_lord"),
                "dignity":        pdata.get("dignity"),
                "is_retrograde":  pdata.get("is_retrograde", False),
                "is_combust":     pdata.get("is_combust", False),
            }

        # Moon special-case
        moon = planets_obj.get("Moon", {})
        if isinstance(moon, dict):
            out["moon_sign"]           = moon.get("sign")
            out["moon_house"]          = moon.get("house")
            out["moon_nakshatra"]      = moon.get("nakshatra")
            out["moon_pada"]           = moon.get("pada")
            out["moon_nakshatra_lord"] = moon.get("nakshatra_lord")

        # Sun special-case
        sun = planets_obj.get("Sun", {})
        if isinstance(sun, dict):
            out["sun_sign"]  = sun.get("sign")
            out["sun_house"] = sun.get("house")

    elif isinstance(planets_obj, list):
        # Defensive fallback: older format
        for p in planets_obj:
            if not isinstance(p, dict):
                continue
            name = (p.get("name") or p.get("planet") or "").title()
            if name:
                out["planets"][name] = {
                    "sign":          p.get("sign"),
                    "house":         p.get("house"),
                    "degree":        p.get("degree"),
                    "nakshatra":     p.get("nakshatra"),
                    "is_retrograde": p.get("is_retrograde", p.get("isRetro", False)),
                }
                if name == "Moon":
                    out["moon_sign"]  = p.get("sign")
                    out["moon_house"] = p.get("house")
                if name == "Sun":
                    out["sun_sign"]  = p.get("sign")
                    out["sun_house"] = p.get("house")

    # ── Jaimini Karakas ──
    jk = chart_data.get("jaimini_karakas", {})
    if isinstance(jk, dict):
        for karaka_name, karaka_data in jk.items():
            if isinstance(karaka_data, dict):
                out["all_karakas"][karaka_name] = karaka_data
        ak = jk.get("Atmakaraka", {})
        if isinstance(ak, dict):
            out["atmakaraka"]      = ak.get("planet")
            out["atmakaraka_full"] = ak
        amk = jk.get("Amatyakaraka", {})
        if isinstance(amk, dict):
            out["amatyakaraka"]      = amk.get("planet")
            out["amatyakaraka_full"] = amk

    # ── Dashas — maha/antar are CURRENTLY ACTIVE directly ──
    dashas = chart_data.get("dashas", {})
    if isinstance(dashas, dict):
        md = dashas.get("maha")
        if isinstance(md, dict):
            out["current_md"]      = md.get("planet")
            out["current_md_full"] = md
        ad = dashas.get("antar")
        if isinstance(ad, dict):
            out["current_ad"]      = ad.get("planet")
            out["current_ad_full"] = ad
        pd = dashas.get("pratyantar")
        if isinstance(pd, dict):
            out["current_pd"]      = pd.get("planet")

    # ── Derive house lords from lagna ──
    out["house_lords"]  = compute_house_lords(out["lagna_sign"])
    out["lagna_lord"]   = out["house_lords"].get(1)
    out["twelfth_lord"] = out["house_lords"].get(12)

    return out


def get_chart(dob: str, time: str, lat: float, lon: float,
              timezone: str = "Asia/Kolkata") -> Dict:
    """Wrapper for dashaflow.cast_chart with consistent error message."""
    try:
        return cast_chart(dob=dob, time=time, lat=lat, lon=lon, timezone=timezone)
    except Exception as e:
        raise RuntimeError(f"Chart casting failed: {e}")


def compute_house_lords(lagna_sign: Optional[str]) -> Dict[int, str]:
    """Given Lagna sign, return dict mapping house number 1-12 to its lord."""
    if not lagna_sign or lagna_sign not in SIGNS_ORDER:
        return {}
    start = SIGNS_ORDER.index(lagna_sign)
    return {
        h: SIGN_TO_LORD[SIGNS_ORDER[(start + h - 1) % 12]]
        for h in range(1, 13)
    }


# ════════════════════════════════════════════════════════════════════════
# AFFLICTION DETECTION
# ════════════════════════════════════════════════════════════════════════

def afflicted_planets(chart: Dict) -> List[Dict[str, Any]]:
    """
    Return list of afflicted planets with reasons.

    A planet is afflicted if ANY of:
    - House in (6, 8, 12) — dushthana
    - is_retrograde == True
    - is_combust == True
    - dignity in ("debilitated", "great_enemy", "enemy")
    """
    out = []
    for planet, pdata in chart.get("planets", {}).items():
        house   = pdata.get("house")
        dignity = pdata.get("dignity", "")
        retro   = pdata.get("is_retrograde", False)
        combust = pdata.get("is_combust", False)

        reasons = []
        if house in (6, 8, 12):
            reasons.append(f"dushthana house {house}")
        if retro:
            reasons.append("retrograde")
        if combust:
            reasons.append("combust")
        if dignity in ("debilitated", "great_enemy", "enemy"):
            reasons.append(f"{dignity} dignity")

        if reasons:
            out.append({
                "planet":      planet,
                "house":       house,
                "dignity":     dignity,
                "is_retrograde":retro,
                "is_combust":  combust,
                "afflictions": reasons,
            })
    return out


def weakest_planet(chart: Dict) -> Optional[str]:
    """
    Return single weakest planet — used for primary mantra/yantra recommendation.

    Severity scoring:
    - Dushthana house (6/8/12): +3
    - Debilitated dignity: +2
    - Combust: +2
    - Retrograde: +1
    """
    afflicted = afflicted_planets(chart)
    if not afflicted:
        return None

    def severity(a):
        score = 0
        for r in a["afflictions"]:
            if "dushthana" in r:        score += 3
            if "debilitated" in r:      score += 2
            if "combust" in r:          score += 2
            if "retrograde" in r:       score += 1
        return score

    return max(afflicted, key=severity)["planet"]


def is_planet_safe_for_gemstone(planet: str, chart: Dict) -> Dict[str, Any]:
    """
    Classical safety check: NEVER prescribe gemstones for 6/8/12 lords.
    """
    house_lords = chart.get("house_lords", {})
    bad_houses = [h for h in (6, 8, 12) if house_lords.get(h) == planet]

    if bad_houses:
        return {
            "safe":   False,
            "reason": f"{planet} is lord of dushthana house(s) {bad_houses} — "
                      f"gemstone would strengthen malefic results",
        }

    pdata = chart.get("planets", {}).get(planet, {})
    if pdata.get("dignity") == "debilitated":
        return {
            "safe":   "with_caution",
            "reason": f"{planet} is debilitated — gemstone use requires upagem trial first",
        }

    return {
        "safe":   True,
        "reason": f"{planet} is not 6/8/12 lord — gemstone is appropriate",
    }


# ════════════════════════════════════════════════════════════════════════
# PUBLIC GETTERS — for any module that needs the constants
# ════════════════════════════════════════════════════════════════════════

def planet_to_direction() -> Dict[str, str]:
    return dict(PLANET_TO_DIRECTION)


def planet_to_deity() -> Dict[str, str]:
    return dict(PLANET_TO_DEITY)


def house_to_life_area() -> Dict[int, str]:
    return dict(HOUSE_TO_LIFE_AREA)


def signs_order() -> List[str]:
    return list(SIGNS_ORDER)


def sign_to_lord() -> Dict[str, str]:
    return dict(SIGN_TO_LORD)


def planet_to_body_part() -> Dict[str, str]:
    return dict(PLANET_TO_BODY_PART)


def planet_to_dosha() -> Dict[str, List[str]]:
    return {k: list(v) for k, v in PLANET_TO_DOSHA.items()}


def sign_to_dosha() -> Dict[str, str]:
    return dict(SIGN_TO_DOSHA)


def chakra_system() -> Dict:
    """Return full chakra system data — used by health/chakra module."""
    return {k: dict(v) for k, v in CHAKRA_SYSTEM.items()}
