"""
patch_main_muhurta_pro.py — Wires 8 Muhurta Pro (C3) endpoints into main.py.

Namespace: /astro/muhurta_pro/* to AVOID collision with existing /astro/muhurta/*
(Phase A engine already has muhurta/abhijit, muhurta/choghadiya, etc.)

Uses verify_key auth pattern. Idempotent.

Run from /opt/astro:
    sudo python3 patch_main_muhurta_pro.py
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── MUHURTA PRO C3 MODULE ──"


IMPORT_BLOCK = '''
# ── MUHURTA PRO C3 MODULE IMPORTS ──
from muhurta_pro import (
    handle_profile             as mhpro_handle_profile,
    handle_check_moment        as mhpro_handle_check_moment,
    handle_find_window         as mhpro_handle_find_window,
    handle_marriage_muhurta    as mhpro_handle_marriage_muhurta,
    handle_business_muhurta    as mhpro_handle_business_muhurta,
    handle_travel_muhurta      as mhpro_handle_travel_muhurta,
    handle_property_muhurta    as mhpro_handle_property_muhurta,
    handle_medical_muhurta     as mhpro_handle_medical_muhurta,
)
# ── END MUHURTA PRO C3 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── MUHURTA PRO C3 MODULE ──
# Phase C — Module C3 — Electional astrology (8 endpoints)
# Namespace: /astro/muhurta_pro/* to avoid collision with /astro/muhurta/*
# Sources: Muhurta Chintamani, Muhurta Martanda, Muhurta Ganapati
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _MhProBaseModel
from typing import Optional as _MhProOptional


class MuhurtaProInput(_MhProBaseModel):
    check_datetime: str        # ISO "2026-05-16T11:30:00"
    lat: float
    lon: float
    timezone: _MhProOptional[str] = "Asia/Kolkata"
    purpose: _MhProOptional[str] = "general"  # marriage/business/travel/property/medical/general


class MuhurtaProFindWindowInput(_MhProBaseModel):
    check_datetime: str
    lat: float
    lon: float
    timezone: _MhProOptional[str] = "Asia/Kolkata"
    purpose: _MhProOptional[str] = "general"
    search_days: _MhProOptional[int] = 30
    min_score: _MhProOptional[float] = 70.0


@app.post("/astro/muhurta_pro/profile")
def mhpro_profile_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Master moment analysis — score primary purpose + compare across all 6 purposes."""
    return mhpro_handle_profile(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata", inp.purpose or "general",
    )


@app.post("/astro/muhurta_pro/check_moment")
def mhpro_check_moment_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Is THIS moment good for X? Composite 0-100 score with verdict."""
    return mhpro_handle_check_moment(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata", inp.purpose or "general",
    )


@app.post("/astro/muhurta_pro/find_window")
def mhpro_find_window_ep(inp: MuhurtaProFindWindowInput, _: str = Depends(verify_key)):
    """Find next favorable window for purpose within search_days, samples 6h intervals."""
    return mhpro_handle_find_window(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata",
        inp.purpose or "general",
        inp.search_days or 30,
        inp.min_score if inp.min_score is not None else 70.0,
    )


@app.post("/astro/muhurta_pro/marriage_muhurta")
def mhpro_marriage_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Marriage-specific Muhurta scoring + classical rule reference."""
    return mhpro_handle_marriage_muhurta(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/muhurta_pro/business_muhurta")
def mhpro_business_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Business inception Muhurta scoring + classical rule reference."""
    return mhpro_handle_business_muhurta(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/muhurta_pro/travel_muhurta")
def mhpro_travel_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Travel/yatra Muhurta scoring + classical rule reference."""
    return mhpro_handle_travel_muhurta(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/muhurta_pro/property_muhurta")
def mhpro_property_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Property/Griha Pravesh Muhurta scoring + classical rule reference."""
    return mhpro_handle_property_muhurta(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/muhurta_pro/medical_muhurta")
def mhpro_medical_ep(inp: MuhurtaProInput, _: str = Depends(verify_key)):
    """Medical procedure Muhurta scoring + classical rule reference."""
    return mhpro_handle_medical_muhurta(
        inp.check_datetime, inp.lat, inp.lon,
        inp.timezone or "Asia/Kolkata",
    )

# ── END MUHURTA PRO C3 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present in main.py.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_muhurta_pro_c3_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_muhurta_pro_c3_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ Muhurta Pro C3 module patched into main.py")
    print("   8 endpoints under /astro/muhurta_pro/* (note: namespace avoids /astro/muhurta/*)")


if __name__ == "__main__":
    main()
