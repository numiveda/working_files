#!/usr/bin/env python3
"""
patch_f1b_relationships.py
─────────────────────────────────────────────────────────────────────────
F1b — Business Partner + Colleague + Compatibility Matrix.

PREREQUISITES:
    - F1a must already be applied (verified via marker presence)
    - /opt/astro/f1b_extension.py must be present on disk (scp'd separately)

PATCH STEPS:
    1. Preconditions (files present, F1a marker present)
    2. Append F1b extension to /opt/astro/relationships.py
    3. Smoke test as user `trading` (includes main.py per U10v2 lesson)
    4. Inject F1b import block into main.py
    5. Append F1b endpoint registrations to main.py
    6. Syntax check + auto-rollback on failure

CHARACTERISTICS:
    - Idempotent (marker checks at each phase)
    - Reversible (timestamped backups of BOTH files)
    - Smoke test includes main.py import (U10v2 hardening pattern)
    - Auto-rollback rolls BOTH files if any step fails

Usage:
    sudo python3 /opt/astro/patch_f1b_relationships.py

Author: Claude (F1b, 2026-05-17)
"""

import os
import sys
import shutil
import subprocess
import py_compile
from datetime import datetime

MAIN_PY          = "/opt/astro/main.py"
RELATIONSHIPS_PY = "/opt/astro/relationships.py"
F1B_EXTENSION_PY = "/opt/astro/f1b_extension.py"

# Markers (unique to F1b)
MARKER_REL_F1B   = "──── F1b SECTION (2026-05-17) ────"
MARKER_MAIN_IMP  = "# ── F1b: business_partner + colleague + matrix imports ──"
MARKER_MAIN_EPS  = "# ── F1b: /astro/relationship/* (business + colleague + matrix) ──"

# Anchor: F1a import block in main.py (we extend it)
F1A_IMPORT_BLOCK = """# ── F1a: Non-Marriage Relationships (2026-05-17) ──
from relationships import (
    handle_friendship  as rel_handle_friendship,
    handle_mentor      as rel_handle_mentor,
    handle_family      as rel_handle_family,
)"""

# Replacement: same F1a block + F1b extension import lines
F1A_PLUS_F1B_IMPORT_BLOCK = """# ── F1a: Non-Marriage Relationships (2026-05-17) ──
# ── F1b: business_partner + colleague + matrix imports ──
from relationships import (
    handle_friendship          as rel_handle_friendship,
    handle_mentor              as rel_handle_mentor,
    handle_family              as rel_handle_family,
    handle_business_partner    as rel_handle_business_partner,
    handle_colleague           as rel_handle_colleague,
    handle_compatibility_matrix as rel_handle_compatibility_matrix,
    MATRIX_HARD_CEILING        as REL_MATRIX_HARD_CEILING,
)"""

# F1b endpoint registrations appended to main.py
F1B_ENDPOINT_BLOCK = '''


# ── F1b: /astro/relationship/* (business + colleague + matrix) ──

class BirthInputWithLabel(BaseModel):
    """A birth input that ALSO carries a human-readable label for the matrix endpoint."""
    label: Optional[str] = None
    dob: str
    time: str
    lat: float
    lon: float
    timezone: str = "Asia/Kolkata"


class CompatibilityMatrixInput(BaseModel):
    """Native vs N others, ranked by composite compatibility per relationship_type."""
    native: BirthInput
    others: list  # list of BirthInputWithLabel-shaped dicts (pydantic validates loosely; handler is defensive)
    relationship_type: str  # friendship | mentor | family | business_partner | colleague
    subtype: Optional[str] = None       # family-only: parent-child|sibling|extended
    max_others: Optional[int] = 20      # clamped server-side to MATRIX_HARD_CEILING (50)


@app.post("/astro/relationship/business_partner", dependencies=[Depends(verify_key)])
def relationship_business_partner(r: RelationshipInput):
    """
    Business Partner / Co-founder compatibility — Arth+Karma alignment.
    Frame: 7H/10H/11H, karakas Mercury+Jupiter+AmK, D10 cross-overlay.
    Multi-stream evidence + composite score 0-100 + classical citations.
    """
    try:
        p1 = {"dob": r.person1.dob, "time": r.person1.time,
              "lat": r.person1.lat, "lon": r.person1.lon,
              "timezone": r.person1.timezone}
        p2 = {"dob": r.person2.dob, "time": r.person2.time,
              "lat": r.person2.lat, "lon": r.person2.lon,
              "timezone": r.person2.timezone}
        return rel_handle_business_partner(p1, p2, role1=r.role1, role2=r.role2)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/relationship/colleague", dependencies=[Depends(verify_key)])
def relationship_colleague(r: RelationshipInput):
    """
    Workplace colleague compatibility — operational fit.
    Frame: 6H/10H/3H, karakas Saturn+Mars+Mercury, Saturn-Mars synastry signal.
    Multi-stream evidence + composite score 0-100 + classical citations.
    """
    try:
        p1 = {"dob": r.person1.dob, "time": r.person1.time,
              "lat": r.person1.lat, "lon": r.person1.lon,
              "timezone": r.person1.timezone}
        p2 = {"dob": r.person2.dob, "time": r.person2.time,
              "lat": r.person2.lat, "lon": r.person2.lon,
              "timezone": r.person2.timezone}
        return rel_handle_colleague(p1, p2, role1=r.role1, role2=r.role2)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/relationship/compatibility_matrix", dependencies=[Depends(verify_key)])
def relationship_compatibility_matrix(m: CompatibilityMatrixInput):
    """
    Compatibility matrix — rank N candidates against one native.

    Works for ALL 5 relationship types (friendship, mentor, family,
    business_partner, colleague). Family endpoint accepts an optional
    `subtype` ("parent-child" | "sibling" | "extended").

    max_others is clamped server-side to MATRIX_HARD_CEILING (currently 50).
    """
    try:
        native = {"dob": m.native.dob, "time": m.native.time,
                  "lat": m.native.lat, "lon": m.native.lon,
                  "timezone": m.native.timezone}
        # m.others is List[dict] — pass through directly; handler is defensive
        return rel_handle_compatibility_matrix(
            native=native,
            others=m.others,
            relationship_type=m.relationship_type,
            subtype=m.subtype,
            max_others=m.max_others if m.max_others is not None else 20,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
'''


# ═══════════════════════════════════════════════════════════════════════
# Utilities
# ═══════════════════════════════════════════════════════════════════════

def fail(msg, restore_pairs=None):
    print(f"\n❌ ERROR: {msg}")
    if restore_pairs:
        for backup, target in restore_pairs:
            if backup and os.path.exists(backup):
                shutil.copy2(backup, target)
                print(f"   🔄 Restored {target} from {backup}")
    sys.exit(1)


def syntax_check(path, restore_pairs=None):
    try:
        py_compile.compile(path, doraise=True)
        print(f"   ✅ Syntax OK: {path}")
    except py_compile.PyCompileError as e:
        fail(f"Syntax error in {path}: {e}", restore_pairs=restore_pairs)


def smoke_test_as_trading():
    """Layered smoke INCLUDING main.py (U10v2 hardening pattern)."""
    smoke_script = """
import sys, traceback
sys.path.insert(0, '/opt/astro')
layers = [
    ('swisseph',      'swisseph'),
    ('dashaflow',     'dashaflow'),
    ('astro_helpers', 'astro_helpers'),
    ('compatibility', 'compatibility'),
    ('relationships', 'relationships'),
    ('nakshatra',     'nakshatra'),
    ('main',          'main'),
]
for label, modname in layers:
    try:
        __import__(modname)
        print(f'OK    {label}')
    except Exception:
        print(f'FAIL  {label}')
        traceback.print_exc()
        sys.exit(1)

from relationships import (
    handle_friendship, handle_mentor, handle_family,
    handle_business_partner, handle_colleague, handle_compatibility_matrix,
    MATRIX_HARD_CEILING,
)
print(f'OK    F1a+F1b handlers (matrix ceiling={MATRIX_HARD_CEILING})')

import main
print(f'OK    main.app has {len(main.app.routes)} routes registered')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_script] if is_root
           else ["python3", "-c", smoke_script])
    result = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.stderr.strip():
        print(f"   ── stderr ──")
        for line in result.stderr.strip().split("\n"):
            print(f"   {line}")
    return result.returncode == 0


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════

def main():
    print("=" * 70)
    print("F1b — Business Partner + Colleague + Matrix installer")
    print("=" * 70)

    # ── Step 1: preconditions ──
    if not os.path.exists(MAIN_PY):
        fail(f"{MAIN_PY} not found")
    if not os.path.exists(RELATIONSHIPS_PY):
        fail(f"{RELATIONSHIPS_PY} not found")
    if not os.path.exists(F1B_EXTENSION_PY):
        fail(f"{F1B_EXTENSION_PY} not found — scp the extension file to /opt/astro/ first")
    print(f"✅ All input files present")

    # ── Step 2: verify F1a is applied (we extend its imports) ──
    with open(MAIN_PY, "r") as f:
        main_content = f.read()
    if "F1a: Non-Marriage Relationships" not in main_content:
        fail("F1a marker not found in main.py — F1a must be applied before F1b.")
    print(f"✅ F1a marker confirmed in main.py")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    rel_backup  = None
    main_backup = None

    # ═══════════════════════════════════════════════════════════════
    # PHASE A — Append F1b extension to relationships.py
    # ═══════════════════════════════════════════════════════════════
    print("\n── Phase A: Append F1b extension to relationships.py ──")
    with open(RELATIONSHIPS_PY, "r") as f:
        rel_content = f.read()

    if MARKER_REL_F1B in rel_content:
        print("   ⏭️  F1b section already present in relationships.py, skipping")
    else:
        with open(F1B_EXTENSION_PY, "r") as f:
            ext_content = f.read()
        if MARKER_REL_F1B not in ext_content:
            fail(f"Sanity check failed: F1b marker not found in {F1B_EXTENSION_PY}. "
                 f"The extension file may be corrupted.")

        rel_backup = f"{RELATIONSHIPS_PY}.before_f1b_{ts}"
        shutil.copy2(RELATIONSHIPS_PY, rel_backup)
        print(f"   ✅ Backup: {rel_backup}")

        if not rel_content.endswith("\n"):
            rel_content += "\n"
        new_rel_content = rel_content + ext_content
        with open(RELATIONSHIPS_PY, "w") as f:
            f.write(new_rel_content)
        print(f"   ✅ Appended F1b extension ({len(ext_content)} bytes)")
        syntax_check(RELATIONSHIPS_PY,
                     restore_pairs=[(rel_backup, RELATIONSHIPS_PY)])

    # ═══════════════════════════════════════════════════════════════
    # PHASE B — Inject F1b imports + endpoints into main.py
    # ═══════════════════════════════════════════════════════════════
    print("\n── Phase B: Inject F1b imports + endpoints into main.py ──")

    f1b_imports_done = (MARKER_MAIN_IMP in main_content)
    f1b_endpoints_done = (MARKER_MAIN_EPS in main_content)

    if f1b_imports_done and f1b_endpoints_done:
        print("   ⏭️  Both F1b markers already in main.py, skipping")
    else:
        if not f1b_imports_done:
            if F1A_IMPORT_BLOCK not in main_content:
                restore = [(rel_backup, RELATIONSHIPS_PY)] if rel_backup else []
                fail("F1a import block anchor not found in main.py — cannot extend safely",
                     restore_pairs=restore)

        main_backup = f"{MAIN_PY}.before_f1b_{ts}"
        shutil.copy2(MAIN_PY, main_backup)
        print(f"   ✅ Backup: {main_backup}")

        # Inject imports
        if not f1b_imports_done:
            main_content = main_content.replace(
                F1A_IMPORT_BLOCK, F1A_PLUS_F1B_IMPORT_BLOCK, 1)
            print(f"   ✅ Extended F1a import block with F1b symbols")

        # Append endpoints
        if not f1b_endpoints_done:
            if not main_content.endswith("\n"):
                main_content += "\n"
            main_content += F1B_ENDPOINT_BLOCK
            print(f"   ✅ Appended F1b endpoint registrations")

        with open(MAIN_PY, "w") as f:
            f.write(main_content)

        # Syntax check with auto-rollback
        restore = [(main_backup, MAIN_PY)]
        if rel_backup:
            restore.append((rel_backup, RELATIONSHIPS_PY))
        syntax_check(MAIN_PY, restore_pairs=restore)

    # ═══════════════════════════════════════════════════════════════
    # PHASE C — Snapshots
    # ═══════════════════════════════════════════════════════════════
    print("\n── Phase C: Snapshots after-state ──")
    if rel_backup:
        snap = f"{RELATIONSHIPS_PY}.after_f1b_{ts}"
        shutil.copy2(RELATIONSHIPS_PY, snap)
        print(f"   ✅ {snap}")
    if main_backup:
        snap = f"{MAIN_PY}.after_f1b_{ts}"
        shutil.copy2(MAIN_PY, snap)
        print(f"   ✅ {snap}")
    if not (rel_backup or main_backup):
        print("   ⏭️  No changes made; skipping snapshot")

    # ═══════════════════════════════════════════════════════════════
    # PHASE D — Layered smoke including main.py
    # ═══════════════════════════════════════════════════════════════
    print("\n── Phase D: Layered import smoke (as user `trading`, INCLUDES main.py) ──")
    ok = smoke_test_as_trading()
    if not ok:
        restore = []
        if main_backup: restore.append((main_backup, MAIN_PY))
        if rel_backup:  restore.append((rel_backup, RELATIONSHIPS_PY))
        fail("Smoke test failed — see traceback above for failed layer",
             restore_pairs=restore)

    print("\n" + "=" * 70)
    print("F1b PATCH APPLIED — next steps:")
    print("  sudo systemctl restart astro && sleep 3")
    print("  curl http://localhost:8001/astro/health      ← MUST return 200")
    print("  Then run verification sweep (see F1B runbook)")
    print("=" * 70)


if __name__ == "__main__":
    main()
