#!/usr/bin/env python3
"""
patch_f4_mundane_v3.py — F4 Mundane Astrology installer (v3)

v1 → v2 fix: Anchor A2 had 3 blank lines between AcquisitionWindowInput body
             and CompatibilityInput; actual main.py has 5 blank lines (lines
             627-631 inclusive). v1 failed cleanly at Phase A, file untouched.
             v2 has byte-verified anchor (sed + cat -A + awk triple check).

v2 → v3 fix: subprocess.check_call invocations for import checks were running
             with sudo's sanitized environment + no cwd, so `from dashaflow
             import cast_chart` failed even though the live uvicorn-launched
             service imports it fine (uvicorn auto-adds cwd to sys.path).
             v3 explicitly passes cwd="/opt/astro" + env with
             PYTHONPATH="/opt/astro" to every subprocess.check_call. v2 failed
             cleanly at Phase A, file untouched.

Installs /astro/mundane/country_outlook, /astro/mundane/company_chart,
/astro/mundane/election_prediction into main.py. Module file mundane.py
must already be present at /opt/astro/mundane.py.

Phase A — Precondition + anchor validation (file UNTOUCHED if fail)
Phase B — Backup main.py
Phase C — Insert F4 import block (anchored on F6b → END COMPATIBILITY C1)
Phase D — Insert F4 Pydantic input models (anchored after F6b acquisition
          input classes, before CompatibilityInput at line 632)
Phase E — Append F4 routes to end of main.py
Phase F — Snapshot + syntax check + layered smoke (auto-rollback if any fail)

Idempotency: marker comment "# ── F4: Mundane module imports (2026-05-18) ──"
is checked first; if present, exit cleanly without changes.

Author: Claude (F4 v3, 2026-05-18)
"""

import os
import sys
import shutil
import subprocess
import time
import importlib

# ─── Configuration ──────────────────────────────────────────────────────────
ASTRO_DIR    = "/opt/astro"
MAIN_PY      = os.path.join(ASTRO_DIR, "main.py")
MUNDANE_PY   = os.path.join(ASTRO_DIR, "mundane.py")
PATCH_NAME   = "f4_mundane"
TIMESTAMP    = time.strftime("%Y%m%d_%H%M%S")
BACKUP_PATH  = f"{MAIN_PY}.before_{PATCH_NAME}_{TIMESTAMP}"
SNAPSHOT_PATH = f"{MAIN_PY}.after_{PATCH_NAME}_{TIMESTAMP}"
MARKER       = "# ── F4: Mundane module imports (2026-05-18) ──"

# ─── Anchors (byte-verified from production main.py on 2026-05-18) ──────────

# Anchor A1: insertion zone for F4 imports — between F6b import block close
# and the "END COMPATIBILITY C1" sentinel. Byte-verified via cat -A.
ANCHOR_F6B_IMPORT_BLOCK = (
    "from pet_muhurta import (\n"
    "    handle_check_acquisition_day        as pm_handle_check_day,\n"
    "    handle_acquisition_window_scan      as pm_handle_window_scan,\n"
    ")\n"
    "\n"
    "# ── END COMPATIBILITY C1 IMPORTS ──"
)

NEW_F6B_PLUS_F4_IMPORTS = (
    "from pet_muhurta import (\n"
    "    handle_check_acquisition_day        as pm_handle_check_day,\n"
    "    handle_acquisition_window_scan      as pm_handle_window_scan,\n"
    ")\n"
    "\n"
    "\n"
    "# ── F4: Mundane module imports (2026-05-18) ──\n"
    "from mundane import (\n"
    "    handle_country_outlook       as mn_handle_country_outlook,\n"
    "    handle_company_chart         as mn_handle_company_chart,\n"
    "    handle_election_prediction   as mn_handle_election_prediction,\n"
    "    COUNTRY_REGISTRY             as MN_COUNTRY_REGISTRY,\n"
    ")\n"
    "\n"
    "# ── END COMPATIBILITY C1 IMPORTS ──"
)

# Anchor A2: insertion zone for Pydantic input models.
# Byte-verified (sed + cat -A + awk) on 2026-05-18:
#   Line 626: "    acquisition_location: AcquisitionLocationInput$"
#   Line 627: "$"   (blank)
#   Line 628: "$"   (blank)
#   Line 629: "$"   (blank)
#   Line 630: "$"   (blank)
#   Line 631: "$"   (blank)
#   Line 632: "class CompatibilityInput(BaseModel):$"
# That is FIVE blank lines (\n) between the two classes, not three. v1 failed
# at Phase A because of this. Also note: there's a SECOND CompatibilityInput
# at line 2561 with base _CompatBaseModel, NOT BaseModel — so the anchor
# below is still unique.
ANCHOR_BEFORE_COMPATIBILITY_INPUT = (
    "class AcquisitionWindowInput(BaseModel):\n"
    "    \"\"\"Input for /astro/pet/auspicious_acquisition_window — date range scan.\"\"\"\n"
    "    owner:                BirthInput\n"
    "    start_date:           Optional[str] = None   # YYYY-MM-DD; defaults to today\n"
    "    end_date:             Optional[str] = None   # YYYY-MM-DD; defaults to start+14 days\n"
    "    acquisition_location: AcquisitionLocationInput\n"
    "\n"   # blank line 627
    "\n"   # blank line 628
    "\n"   # blank line 629
    "\n"   # blank line 630
    "\n"   # blank line 631
    "class CompatibilityInput(BaseModel):"
)

NEW_F4_INPUT_MODELS_PLUS_COMPAT = (
    "class AcquisitionWindowInput(BaseModel):\n"
    "    \"\"\"Input for /astro/pet/auspicious_acquisition_window — date range scan.\"\"\"\n"
    "    owner:                BirthInput\n"
    "    start_date:           Optional[str] = None   # YYYY-MM-DD; defaults to today\n"
    "    end_date:             Optional[str] = None   # YYYY-MM-DD; defaults to start+14 days\n"
    "    acquisition_location: AcquisitionLocationInput\n"
    "\n"
    "\n"
    "# ── F4: Mundane Astrology inputs (2026-05-18) ──\n"
    "class CountryOutlookInput(BaseModel):\n"
    "    \"\"\"Input for /astro/mundane/country_outlook.\n"
    "\n"
    "    Either country_code (ISO 3166-1 alpha-2) or chart_override required.\n"
    "    If both provided, chart_override wins.\n"
    "    \"\"\"\n"
    "    country_code:    Optional[str] = None\n"
    "    chart_override:  Optional[BirthInput] = None\n"
    "    analysis_date:   Optional[str] = None   # YYYY-MM-DD; informational\n"
    "\n"
    "\n"
    "class CompanyChartInput(BaseModel):\n"
    "    \"\"\"Input for /astro/mundane/company_chart.\n"
    "\n"
    "    incorporation: BirthInput-shaped chart of the company's incorporation.\n"
    "    business_sector: optional, e.g. 'technology', 'finance', 'retail'.\n"
    "    \"\"\"\n"
    "    incorporation:    BirthInput\n"
    "    business_sector:  Optional[str] = None\n"
    "\n"
    "\n"
    "class ElectionEventInput(BaseModel):\n"
    "    \"\"\"Input for /astro/mundane/election_prediction.\n"
    "\n"
    "    event: BirthInput-shaped chart of the civic event moment (e.g. poll opening).\n"
    "    country_code: optional ISO 3166-1 alpha-2 for national context overlay.\n"
    "\n"
    "    NOTE: This endpoint does NOT predict winners. Inputs containing party\n"
    "    or candidate names are ignored.\n"
    "    \"\"\"\n"
    "    event:         BirthInput\n"
    "    country_code:  Optional[str] = None\n"
    "\n"
    "\n"
    "\n"
    "class CompatibilityInput(BaseModel):"
)

# Anchor A3: append at end-of-file. main.py confirmed via cat -A to end with
# the last raise HTTPException line + LF, no trailing blank line.
F4_ROUTES_APPEND = (
    "\n"
    "\n"
    "# ── F4: /astro/mundane/* endpoints (2026-05-18) ──\n"
    "\n"
    "@app.post(\"/astro/mundane/country_outlook\", dependencies=[Depends(verify_key)])\n"
    "def mundane_country_outlook(c: CountryOutlookInput):\n"
    "    \"\"\"\n"
    "    Mundane astrology outlook for a country.\n"
    "\n"
    "    Provide EITHER country_code (ISO 3166-1 alpha-2; see registry below)\n"
    "    OR chart_override with dob/time/lat/lon/timezone for custom entity.\n"
    "\n"
    "    Available registered country codes: IN, US, UK, CN, RU, JP, DE, FR, AU, PK.\n"
    "\n"
    "    Reuses cast_chart's pre-computed shadbala, yogas, dashas, and\n"
    "    jaimini_karakas. Interprets through mundane house meanings\n"
    "    (Varahamihira / Raman). NOT a prediction service — research framing.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        override_dict = None\n"
    "        if c.chart_override is not None:\n"
    "            override_dict = {\n"
    "                \"dob\":      c.chart_override.dob,\n"
    "                \"time\":     c.chart_override.time,\n"
    "                \"lat\":      c.chart_override.lat,\n"
    "                \"lon\":      c.chart_override.lon,\n"
    "                \"timezone\": c.chart_override.timezone,\n"
    "            }\n"
    "        return mn_handle_country_outlook(\n"
    "            country_code=c.country_code,\n"
    "            chart_override=override_dict,\n"
    "            analysis_date=c.analysis_date,\n"
    "        )\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
    "\n"
    "\n"
    "@app.post(\"/astro/mundane/company_chart\", dependencies=[Depends(verify_key)])\n"
    "def mundane_company_chart(c: CompanyChartInput):\n"
    "    \"\"\"\n"
    "    Mundane analysis of a company's incorporation chart.\n"
    "\n"
    "    Inputs: incorporation date/time/place + optional business_sector.\n"
    "    Sectors supported: technology, finance, banking, manufacturing,\n"
    "    retail, media, energy, healthcare, agriculture, real_estate,\n"
    "    luxury, transport, education, spiritual.\n"
    "\n"
    "    Returns mundane-house lord assessments (2/6/10/11 emphasis),\n"
    "    Arudha Lagna (public-facing image), wealth/governance yogas,\n"
    "    and current dasha.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        incorp_dict = {\n"
    "            \"dob\":      c.incorporation.dob,\n"
    "            \"time\":     c.incorporation.time,\n"
    "            \"lat\":      c.incorporation.lat,\n"
    "            \"lon\":      c.incorporation.lon,\n"
    "            \"timezone\": c.incorporation.timezone,\n"
    "        }\n"
    "        return mn_handle_company_chart(\n"
    "            incorporation=incorp_dict,\n"
    "            business_sector=c.business_sector,\n"
    "        )\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
    "\n"
    "\n"
    "@app.post(\"/astro/mundane/election_prediction\", dependencies=[Depends(verify_key)])\n"
    "def mundane_election_prediction(c: ElectionEventInput):\n"
    "    \"\"\"\n"
    "    Event-chart mundane analysis (e.g. for poll opening moment).\n"
    "\n"
    "    DOES NOT predict winners. DOES NOT name parties or candidates.\n"
    "    Returns classical mundane indicators only:\n"
    "    lagna lord state, 10th lord (governance), 6th lord (opposition),\n"
    "    Moon condition, graha yuddha, gandanta, eclipse proximity.\n"
    "\n"
    "    Each response carries a disclaimer field clarifying scholarly framing.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        event_dict = {\n"
    "            \"dob\":      c.event.dob,\n"
    "            \"time\":     c.event.time,\n"
    "            \"lat\":      c.event.lat,\n"
    "            \"lon\":      c.event.lon,\n"
    "            \"timezone\": c.event.timezone,\n"
    "        }\n"
    "        return mn_handle_election_prediction(\n"
    "            event=event_dict,\n"
    "            country_code=c.country_code,\n"
    "        )\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
)


# ─── Phase logic ────────────────────────────────────────────────────────────

def log(msg: str) -> None:
    print(f"[patch_f4] {msg}", flush=True)


def fail(msg: str, code: int = 1) -> None:
    print(f"[patch_f4] FAIL: {msg}", file=sys.stderr, flush=True)
    sys.exit(code)


def run_in_astro_env(python_code: str) -> None:
    """
    Run a Python snippet with the same import environment as the live service.

    The live uvicorn-launched astro service has WorkingDirectory=/opt/astro,
    which puts /opt/astro on sys.path[0] automatically. When this installer
    is invoked via `sudo python3 ...`, sudo sanitizes the environment AND
    `-c` does NOT inject cwd onto sys.path by default — so `from dashaflow
    import cast_chart` fails here even though it succeeds in production.

    Fix: explicitly pass cwd="/opt/astro" + env with PYTHONPATH="/opt/astro"
    so subprocess imports match the live-service path resolution.

    This issue was caught in patch v2 (Phase A, file untouched).
    """
    env = os.environ.copy()
    existing_pp = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = (
        ASTRO_DIR if not existing_pp else f"{ASTRO_DIR}{os.pathsep}{existing_pp}"
    )
    subprocess.check_call(
        [sys.executable, "-c", python_code],
        cwd=ASTRO_DIR,
        env=env,
    )


def phase_a_preflight() -> str:
    """Precondition + anchor validation. File UNTOUCHED on any failure."""
    log("Phase A — precondition + anchor validation")

    # A.1 — Files exist
    if not os.path.isfile(MAIN_PY):
        fail(f"main.py not found at {MAIN_PY}")
    if not os.path.isfile(MUNDANE_PY):
        fail(f"mundane.py not found at {MUNDANE_PY} — upload it first")

    # A.2 — Read main.py
    with open(MAIN_PY, "r", encoding="utf-8") as f:
        content = f.read()

    # A.3 — Idempotency check
    if MARKER in content:
        log("Marker already present in main.py — patch is idempotent, exiting.")
        sys.exit(0)

    # A.4 — Anchor A1 must be present exactly once
    a1_count = content.count(ANCHOR_F6B_IMPORT_BLOCK)
    if a1_count != 1:
        fail(f"Anchor A1 (F6b import block) appears {a1_count} times; expected exactly 1. "
             "main.py may have drifted from the byte-verified state.")

    # A.5 — Anchor A2 must be present exactly once
    a2_count = content.count(ANCHOR_BEFORE_COMPATIBILITY_INPUT)
    if a2_count != 1:
        fail(f"Anchor A2 (AcquisitionWindowInput → CompatibilityInput) appears "
             f"{a2_count} times; expected exactly 1.")

    # A.6 — mundane.py is importable as a syntactic check
    try:
        run_in_astro_env(
            "import ast; ast.parse(open('/opt/astro/mundane.py').read())"
        )
    except subprocess.CalledProcessError:
        fail("mundane.py failed syntax check")

    # A.7 — Module dependencies importable (with /opt/astro on sys.path, just
    #       like the live uvicorn service). This catches any missing import in
    #       mundane.py BEFORE we touch main.py.
    log("Verifying mundane.py imports cleanly...")
    cmd = (
        "import mundane; "
        "assert hasattr(mundane, 'handle_country_outlook'); "
        "assert hasattr(mundane, 'handle_company_chart'); "
        "assert hasattr(mundane, 'handle_election_prediction'); "
        "assert hasattr(mundane, 'COUNTRY_REGISTRY'); "
        "assert len(mundane.COUNTRY_REGISTRY) >= 10; "
        "print('mundane.py imports OK')"
    )
    try:
        run_in_astro_env(cmd)
    except subprocess.CalledProcessError:
        fail("mundane.py import test failed — fix module before re-running patch")

    log("Phase A — OK (file untouched)")
    return content


def phase_b_backup() -> None:
    log(f"Phase B — backing up main.py → {BACKUP_PATH}")
    shutil.copy2(MAIN_PY, BACKUP_PATH)
    if not os.path.isfile(BACKUP_PATH):
        fail("Backup creation failed")
    log("Phase B — OK")


def phase_c_imports(content: str) -> str:
    log("Phase C — inserting F4 import block")
    new_content = content.replace(ANCHOR_F6B_IMPORT_BLOCK, NEW_F6B_PLUS_F4_IMPORTS, 1)
    if new_content == content:
        fail("Phase C: anchor replacement made no change (UNEXPECTED — Phase A passed)")
    if new_content.count(MARKER) != 1:
        fail(f"Phase C: marker count after insert = {new_content.count(MARKER)} (expected 1)")
    log("Phase C — OK (in memory)")
    return new_content


def phase_d_models(content: str) -> str:
    log("Phase D — inserting F4 Pydantic input models")
    new_content = content.replace(
        ANCHOR_BEFORE_COMPATIBILITY_INPUT,
        NEW_F4_INPUT_MODELS_PLUS_COMPAT,
        1,
    )
    if new_content == content:
        fail("Phase D: anchor replacement made no change")
    for cls in ("CountryOutlookInput", "CompanyChartInput", "ElectionEventInput"):
        if f"class {cls}(BaseModel)" not in new_content:
            fail(f"Phase D: {cls} not inserted")
    log("Phase D — OK (in memory)")
    return new_content


def phase_e_routes(content: str) -> str:
    log("Phase E — appending F4 routes to end of main.py")
    new_content = content + F4_ROUTES_APPEND
    for route in ("/astro/mundane/country_outlook",
                  "/astro/mundane/company_chart",
                  "/astro/mundane/election_prediction"):
        if route not in new_content:
            fail(f"Phase E: route {route} not present after append")
    log("Phase E — OK (in memory)")
    return new_content


def phase_f_write_and_verify(new_content: str) -> None:
    log(f"Phase F — writing new main.py + snapshot → {SNAPSHOT_PATH}")
    with open(MAIN_PY, "w", encoding="utf-8") as f:
        f.write(new_content)
    shutil.copy2(MAIN_PY, SNAPSHOT_PATH)

    # F.1 — Syntax check
    log("Phase F.1 — syntax check on new main.py")
    try:
        run_in_astro_env(
            "import ast; ast.parse(open('/opt/astro/main.py').read())"
        )
    except subprocess.CalledProcessError:
        log("Syntax check FAILED — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        fail("Phase F.1: syntax error in new main.py — rolled back from backup")

    # F.2 — Layered smoke: import mundane, then import main, then check each handler
    log("Phase F.2 — layered smoke (import mundane → import main → assertions)")
    smoke = (
        "import mundane; "
        # Functional assertion: country registry size + handler shape
        "assert 'IN' in mundane.COUNTRY_REGISTRY, 'IN missing'; "
        "assert 'US' in mundane.COUNTRY_REGISTRY, 'US missing'; "
        "assert len(mundane.COUNTRY_REGISTRY) >= 10, 'registry too small'; "
        # Disclaimer present
        "assert mundane.F4_DISCLAIMER, 'disclaimer missing'; "
        "assert 'NOT' in mundane.F4_ELECTION_DISCLAIMER_EXTRA.upper() or 'not' in mundane.F4_ELECTION_DISCLAIMER_EXTRA, 'election disclaimer weak'; "
        # Actual handler invocation — country outlook for India
        "r = mundane.handle_country_outlook(country_code='IN'); "
        "assert 'error' not in r, f'India outlook errored: {r.get(\"error\")}'; "
        "assert r['entity'] == 'India (Republic)', f'entity mismatch: {r[\"entity\"]}'; "
        "assert 'classical_sources' in r, 'citations missing'; "
        "assert 'disclaimer' in r, 'disclaimer field missing'; "
        "assert 'house_assessments' in r and len(r['house_assessments']) >= 4, 'houses missing'; "
        # Registry-not-found path
        "r2 = mundane.handle_country_outlook(country_code='ZZ'); "
        "assert 'error' in r2, 'ZZ should error'; "
        # Override path
        "r3 = mundane.handle_country_outlook(chart_override={'dob':'1980-12-31','time':'09:40','lat':26.1445,'lon':91.7362,'timezone':'Asia/Kolkata','name':'Test Entity'}); "
        "assert 'error' not in r3, f'override path errored: {r3.get(\"error\")}'; "
        # Company chart with sector
        "r4 = mundane.handle_company_chart(incorporation={'dob':'2010-01-01','time':'09:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}, business_sector='technology'); "
        "assert 'error' not in r4, f'company chart errored: {r4.get(\"error\")}'; "
        "assert r4.get('sector_analysis') is not None, 'sector_analysis missing'; "
        "assert r4['sector_analysis']['significators'] == ['Mercury','Rahu'], 'tech significators wrong'; "
        # Election endpoint — verify NO winner field, disclaimers present
        "r5 = mundane.handle_election_prediction(event={'dob':'2024-06-04','time':'08:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}, country_code='IN'); "
        "assert 'error' not in r5, f'election analysis errored: {r5.get(\"error\")}'; "
        "assert 'winner' not in str(r5).lower() or 'no winner' in str(r5).lower() or 'predict winners' in str(r5).lower(), 'winner language detected'; "
        "assert 'election_disclaimer' in r5, 'election disclaimer missing'; "
        "assert 'favorable_factors' in r5 and 'unfavorable_factors' in r5, 'factors missing'; "
        # NOW import main.py — this is the critical layered test (per Section 3.5)
        "import main; "
        "print('Smoke: all assertions PASSED, main.py imports OK')"
    )
    try:
        run_in_astro_env(smoke)
    except subprocess.CalledProcessError:
        log("Smoke test FAILED — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        fail("Phase F.2: smoke test failed — rolled back from backup")

    log("Phase F — OK (changes committed, snapshot saved)")


def main() -> None:
    print("=" * 72)
    print(f"patch_f4_mundane_v3.py — F4 Mundane Astrology installer")
    print(f"Timestamp: {TIMESTAMP}")
    print(f"Backup will go to: {BACKUP_PATH}")
    print(f"Snapshot will go to: {SNAPSHOT_PATH}")
    print("=" * 72)

    content = phase_a_preflight()
    phase_b_backup()
    new_content = phase_c_imports(content)
    new_content = phase_d_models(new_content)
    new_content = phase_e_routes(new_content)
    phase_f_write_and_verify(new_content)

    print("=" * 72)
    print("F4 patch installation: SUCCESS")
    print("Next step: sudo systemctl restart astro && sleep 3")
    print(f"Then: curl -s -o /dev/null -w 'HTTP %{{http_code}}\\n' http://localhost:8001/astro/health")
    print(f"And:  curl -s http://localhost:8001/openapi.json | python3 -c "
          "\"import json,sys; print('Total paths:', len(json.load(sys.stdin)['paths']))\"")
    print("Expected: HTTP 200, Total paths: 308 (was 305, +3)")
    print("=" * 72)


if __name__ == "__main__":
    main()
