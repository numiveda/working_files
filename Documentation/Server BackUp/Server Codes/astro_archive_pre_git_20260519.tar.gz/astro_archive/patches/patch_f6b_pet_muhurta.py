#!/usr/bin/env python3
"""
patch_f6b_pet_muhurta.py
─────────────────────────────────────────────────────────────────────────
F6b — Pet Acquisition Muhurta: 2 endpoints

    POST /astro/pet/check_acquisition_day
    POST /astro/pet/auspicious_acquisition_window

PREREQUISITES:
    - /opt/astro/pet_muhurta.py present (scp'd separately)
    - F6 applied (we splice after F6's imports)

PHASES:
    A — Preconditions + pre-import smoke that pet_muhurta.py loads cleanly
    B — Inject import block after F6's imports
    C — Inject AcquisitionDayInput + AcquisitionWindowInput classes
    D — Append 2 endpoint registrations
    E — Snapshot
    F — Full layered smoke INCLUDING main.py with F6b functional assertions

Idempotent. Auto-rollback on syntax or smoke failure.

Usage:
    sudo python3 /opt/astro/patch_f6b_pet_muhurta.py

Author: Claude (F6b, 2026-05-18)
"""

import os
import sys
import shutil
import subprocess
import py_compile
from datetime import datetime

MAIN_PY      = "/opt/astro/main.py"
MUHURTA_PY   = "/opt/astro/pet_muhurta.py"

MARKER_IMPORT    = "# ── F6b: Pet Acquisition Muhurta imports (2026-05-18) ──"
MARKER_INPUT_CLS = "# ── F6b: Acquisition input classes (2026-05-18) ──"
MARKER_ENDPOINTS = "# ── F6b: /astro/pet/{check,window} endpoints (2026-05-18) ──"

# Anchor: F6 import tail
F6_IMPORT_TAIL = """from pet_astro import (
    handle_pet_compatibility   as pet_handle_compatibility,
    handle_pet_naming          as pet_handle_naming,
    handle_pet_personality     as pet_handle_personality,
)"""

F6_PLUS_F6B_IMPORT_BLOCK = """from pet_astro import (
    handle_pet_compatibility   as pet_handle_compatibility,
    handle_pet_naming          as pet_handle_naming,
    handle_pet_personality     as pet_handle_personality,
)


{MARKER_IMPORT}
from pet_muhurta import (
    handle_check_acquisition_day        as pm_handle_check_day,
    handle_acquisition_window_scan      as pm_handle_window_scan,
)""".replace("{MARKER_IMPORT}", MARKER_IMPORT)


# Anchor: F6 PetCompatInput class
PET_COMPAT_INPUT_ANCHOR = '''class PetCompatInput(BaseModel):
    """Input for /astro/pet/compatibility — pet + owner."""
    pet:   PetInput
    owner: BirthInput'''

ACQUISITION_INPUT_BLOCK = '''


{MARKER_INPUT_CLS}
class AcquisitionLocationInput(BaseModel):
    """Location where pet will be acquired."""
    lat:      float
    lon:      float
    timezone: Optional[str] = "Asia/Kolkata"


class AcquisitionDayInput(BaseModel):
    """Input for /astro/pet/check_acquisition_day — single date check."""
    owner:                BirthInput
    acquisition_date:     str   # YYYY-MM-DD
    acquisition_location: AcquisitionLocationInput


class AcquisitionWindowInput(BaseModel):
    """Input for /astro/pet/auspicious_acquisition_window — date range scan."""
    owner:                BirthInput
    start_date:           Optional[str] = None   # YYYY-MM-DD; defaults to today
    end_date:             Optional[str] = None   # YYYY-MM-DD; defaults to start+14 days
    acquisition_location: AcquisitionLocationInput'''.replace("{MARKER_INPUT_CLS}", MARKER_INPUT_CLS)


F6B_ENDPOINT_BLOCK = '''


{MARKER_ENDPOINTS}

@app.post("/astro/pet/check_acquisition_day", dependencies=[Depends(verify_key)])
def pet_check_acquisition_day(a: AcquisitionDayInput):
    """
    Check whether a specific date is auspicious for pet acquisition.

    Owner's tara state, daily yogas (Sarvartha Siddhi/Amrit Siddhi/Vish/Mrityu/etc.),
    yoni alignment of operative nakshatra, and Sade Sati status are all scored.
    Returns full breakdown + verdict + recommended intra-day window (Abhijit muhurta).
    """
    try:
        owner_dict = {
            "dob": a.owner.dob, "time": a.owner.time,
            "lat": a.owner.lat, "lon": a.owner.lon,
            "timezone": a.owner.timezone,
        }
        location_dict = {
            "lat": a.acquisition_location.lat,
            "lon": a.acquisition_location.lon,
            "timezone": a.acquisition_location.timezone,
        }
        return pm_handle_check_day(owner_dict, a.acquisition_date, location_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pet/auspicious_acquisition_window", dependencies=[Depends(verify_key)])
def pet_acquisition_window_scan(a: AcquisitionWindowInput):
    """
    Scan a date range and rank auspicious days for pet acquisition.

    Default: 14 days from today. Maximum 30 days.

    Returns top 5 recommended days (with full scoring breakdown + Abhijit window),
    list of days to avoid, full ranked list, and summary headline.
    """
    try:
        owner_dict = {
            "dob": a.owner.dob, "time": a.owner.time,
            "lat": a.owner.lat, "lon": a.owner.lon,
            "timezone": a.owner.timezone,
        }
        location_dict = {
            "lat": a.acquisition_location.lat,
            "lon": a.acquisition_location.lon,
            "timezone": a.acquisition_location.timezone,
        }
        return pm_handle_window_scan(owner_dict, a.start_date, a.end_date,
                                        location_dict, max_days=30)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
'''.replace("{MARKER_ENDPOINTS}", MARKER_ENDPOINTS)


# ═══════════════════════════════════════════════════════════════════════
# Utilities
# ═══════════════════════════════════════════════════════════════════════

def fail(msg, restore_pairs=None):
    print(f"\n❌ ERROR: {msg}")
    if restore_pairs:
        for backup, target in restore_pairs:
            if backup and os.path.exists(backup):
                shutil.copy2(backup, target)
                print(f"   🔄 Restored {target} from {backup}")
    sys.exit(1)


def syntax_check(path, restore_pairs=None):
    try:
        py_compile.compile(path, doraise=True)
        print(f"   ✅ Syntax OK: {path}")
    except py_compile.PyCompileError as e:
        fail(f"Syntax error in {path}: {e}", restore_pairs=restore_pairs)


def smoke_test_as_trading():
    """Layered smoke INCLUDING main.py + F6b functional assertions."""
    smoke_script = r"""
import sys, traceback
sys.path.insert(0, '/opt/astro')
layers = [
    ('swisseph',       'swisseph'),
    ('dashaflow',      'dashaflow'),
    ('astro_helpers',  'astro_helpers'),
    ('compatibility',  'compatibility'),
    ('relationships',  'relationships'),
    ('nakshatra',      'nakshatra'),
    ('transit',        'transit'),
    ('eclipse',        'eclipse'),
    ('pitra_dosha',    'pitra_dosha'),
    ('strength',       'strength'),
    ('birthday_quick', 'birthday_quick'),
    ('pet_astro',      'pet_astro'),
    ('pet_muhurta',    'pet_muhurta'),
    ('main',           'main'),
]
for label, modname in layers:
    try:
        __import__(modname)
        print(f'OK    {label}')
    except Exception:
        print(f'FAIL  {label}')
        traceback.print_exc()
        sys.exit(1)

# F6b sanity: band thresholds
from pet_muhurta import _band_from_score
b, _ = _band_from_score(15);  assert b == 'EXCEPTIONAL', f"15 should be EXCEPTIONAL, got {b}"
b, _ = _band_from_score(8);   assert b == 'AUSPICIOUS',  f"8 should be AUSPICIOUS, got {b}"
b, _ = _band_from_score(4);   assert b == 'ACCEPTABLE',  f"4 should be ACCEPTABLE, got {b}"
b, _ = _band_from_score(1);   assert b == 'NEUTRAL',     f"1 should be NEUTRAL, got {b}"
b, _ = _band_from_score(-3);  assert b == 'UNFAVORABLE', f"-3 should be UNFAVORABLE, got {b}"
b, _ = _band_from_score(-10); assert b == 'AVOID',       f"-10 should be AVOID, got {b}"
print('OK    F6b band thresholds (6 cases) pass')

# F6b sanity: yoni alignment scoring
from pet_muhurta import _check_yoni_alignment, _SCORE_YONI_SAME_OPPOSITE_GENDER
# Ashwini (Horse M) + Shatabhisha (Horse F) → same+opposite gender
s, n = _check_yoni_alignment('Ashwini', 'Shatabhisha')
assert s == _SCORE_YONI_SAME_OPPOSITE_GENDER, f"Horse-MF yoni should be {_SCORE_YONI_SAME_OPPOSITE_GENDER}, got {s}"
print(f'OK    F6b yoni alignment Ashwini-Shatabhisha: +{s}')

# F6b sanity: hours_to_hhmm utility
from pet_muhurta import _hours_to_hhmm
assert _hours_to_hhmm(11.5) == '11:30', f"11.5 → expected 11:30, got {_hours_to_hhmm(11.5)}"
assert _hours_to_hhmm(0.0) == '00:00'
assert _hours_to_hhmm(12.25) == '12:15'
print('OK    F6b time formatting (3 cases) pass')

# Note: Abhijit muhurta + sunrise/sunset compute is verified functionally via
# /astro/pet/check_acquisition_day in runbook Step 7 — depends on real swisseph
# behavior which can't be stub-tested.

import main
print(f'OK    main.app has {len(main.app.routes)} routes registered')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_script] if is_root
           else ["python3", "-c", smoke_script])
    result = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.stderr.strip():
        print(f"   ── stderr ──")
        for line in result.stderr.strip().split("\n"):
            print(f"   {line}")
    return result.returncode == 0


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════

def main():
    print("=" * 70)
    print("F6b — Pet Acquisition Muhurta Module Installer (2 endpoints)")
    print("=" * 70)

    if not os.path.exists(MAIN_PY):
        fail(f"{MAIN_PY} not found")
    if not os.path.exists(MUHURTA_PY):
        fail(f"{MUHURTA_PY} not found — scp it to /opt/astro/ first")
    print(f"✅ Found {MUHURTA_PY}")

    # Pre-check
    print("\n── Pre-check: pet_muhurta.py imports cleanly as user `trading` ──")
    smoke_pre = """
import sys
sys.path.insert(0, '/opt/astro')
import pet_muhurta
print(f'pet_muhurta loaded, public funcs: '
      f'{[n for n in dir(pet_muhurta) if n.startswith("handle_")]}')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_pre] if is_root
           else ["python3", "-c", smoke_pre])
    r = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if r.returncode != 0:
        fail(f"pet_muhurta.py failed to import:\n{r.stderr}\n{r.stdout}")
    print(f"   {r.stdout.strip()}")

    with open(MAIN_PY, "r") as f:
        content = f.read()
    orig_size = len(content)
    orig_lines = content.count("\n") + 1
    print(f"\nmain.py: {orig_size} bytes, {orig_lines} lines")

    if (MARKER_IMPORT in content
            and MARKER_INPUT_CLS in content
            and MARKER_ENDPOINTS in content):
        print("\n✅ All F6b markers already present — patch was applied. No changes.")
        return

    # Anchor validation
    if F6_IMPORT_TAIL not in content:
        fail("F6 import tail anchor not found in main.py — was F6 applied?")
    print("✅ F6 anchor confirmed")
    if PET_COMPAT_INPUT_ANCHOR not in content:
        fail("PetCompatInput anchor not found in main.py — was F6 applied?")
    print("✅ PetCompatInput anchor confirmed")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    main_backup = f"{MAIN_PY}.before_f6b_{ts}"
    shutil.copy2(MAIN_PY, main_backup)
    print(f"✅ Backup: {main_backup}")

    if MARKER_IMPORT not in content:
        content = content.replace(F6_IMPORT_TAIL, F6_PLUS_F6B_IMPORT_BLOCK, 1)
        print("✅ Injected F6b import block after F6 imports")

    if MARKER_INPUT_CLS not in content:
        content = content.replace(
            PET_COMPAT_INPUT_ANCHOR,
            PET_COMPAT_INPUT_ANCHOR + ACQUISITION_INPUT_BLOCK,
            1
        )
        print("✅ Injected acquisition input classes after PetCompatInput")

    if MARKER_ENDPOINTS not in content:
        if not content.endswith("\n"):
            content += "\n"
        content += F6B_ENDPOINT_BLOCK
        print("✅ Appended 2 F6b endpoint registrations")

    with open(MAIN_PY, "w") as f:
        f.write(content)
    new_size = len(content)
    new_lines = content.count("\n") + 1
    print(f"\n✅ Wrote main.py: {new_size} bytes ({new_size - orig_size:+d}), "
          f"{new_lines} lines ({new_lines - orig_lines:+d})")

    snap = f"{MAIN_PY}.after_f6b_{ts}"
    shutil.copy2(MAIN_PY, snap)
    print(f"✅ Snapshot: {snap}")
    syntax_check(MAIN_PY, restore_pairs=[(main_backup, MAIN_PY)])

    print("\n── Phase F: Layered smoke (as `trading`, INCLUDES main.py + F6b asserts) ──")
    ok = smoke_test_as_trading()
    if not ok:
        fail("Smoke test failed — rolling back",
             restore_pairs=[(main_backup, MAIN_PY)])

    print("\n" + "=" * 70)
    print("F6b PATCH APPLIED — next steps:")
    print("  sudo systemctl restart astro && sleep 3")
    print("  curl http://localhost:8001/astro/health      ← MUST return 200")
    print("  Then run verification sweep (see F6b runbook)")
    print("=" * 70)


if __name__ == "__main__":
    main()
