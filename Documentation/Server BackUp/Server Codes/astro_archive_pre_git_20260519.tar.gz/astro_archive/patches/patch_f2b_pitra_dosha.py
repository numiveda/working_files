#!/usr/bin/env python3
"""
patch_f2b_pitra_dosha.py
─────────────────────────────────────────────────────────────────────────
F2b — Pitra Dosha module: 3 endpoints (profile, intensity, remedies_timing)

PREREQUISITES:
    - /opt/astro/pitra_dosha.py present (scp'd separately)
    - F2a Eclipse module installed (pitra_dosha.py imports from eclipse.py)

PHASES:
    A — Preconditions + pre-import smoke that pitra_dosha.py loads cleanly
    B — Inject import block in main.py after F2a's import block
    C — Inject PitraDoshaInput Pydantic class after EclipseInput
    D — Append 3 endpoint registrations
    E — Snapshot
    F — Full layered smoke INCLUDING main.py (U10v2 hardening pattern)

Idempotent. Auto-rollback on syntax or smoke failure.

Usage:
    sudo python3 /opt/astro/patch_f2b_pitra_dosha.py

Author: Claude (F2b, 2026-05-17)
"""

import os
import sys
import shutil
import subprocess
import py_compile
from datetime import datetime

MAIN_PY        = "/opt/astro/main.py"
PITRA_DOSHA_PY = "/opt/astro/pitra_dosha.py"

MARKER_IMPORT    = "# ── F2b: Pitra Dosha module imports (2026-05-17) ──"
MARKER_INPUT_CLS = "# ── F2b: PitraDoshaInput (2026-05-17) ──"
MARKER_ENDPOINTS = "# ── F2b: /astro/pitra_dosha/* endpoints (2026-05-17) ──"

# Anchor: the F2a import block tail; we splice F2b imports after it
F2A_IMPORT_TAIL = """    UPCOMING_YEARS_MAX                     as ECL_UPCOMING_YEARS_MAX,
)"""

F2A_PLUS_F2B_IMPORT_BLOCK = """    UPCOMING_YEARS_MAX                     as ECL_UPCOMING_YEARS_MAX,
)


{MARKER_IMPORT}
from pitra_dosha import (
    handle_pitra_dosha_profile          as pd_handle_profile,
    handle_pitra_dosha_intensity        as pd_handle_intensity,
    handle_pitra_dosha_remedies_timing  as pd_handle_remedies_timing,
    MAHALAYA_YEARS_DEFAULT              as PD_MAHALAYA_YEARS_DEFAULT,
    MAHALAYA_YEARS_MAX                  as PD_MAHALAYA_YEARS_MAX,
)""".replace("{MARKER_IMPORT}", MARKER_IMPORT)


# Anchor: the EclipseInput class (F2a marker)
ECLIPSE_INPUT_ANCHOR = """# ── F2a: EclipseInput (2026-05-17) ──
class EclipseInput(BaseModel):
    \"\"\"Input for /astro/eclipse/* endpoints (and Sade-Sati eclipse extension).\"\"\"
    birth: BirthInput
    # natal_eclipses: window (days) before+after birth; default 30, max 180
    window_days: Optional[int] = None
    # upcoming_eclipses
    query_date: Optional[str] = None    # YYYY-MM-DD
    years_ahead: Optional[int] = None   # default 5, max 100"""

PITRA_INPUT_BLOCK = '''

{MARKER_INPUT_CLS}
class PitraDoshaInput(BaseModel):
    """Input for /astro/pitra_dosha/* endpoints."""
    birth: BirthInput
    # remedies_timing only:
    query_date: Optional[str] = None    # YYYY-MM-DD; defaults to today
    years_ahead: Optional[int] = None   # default 5, max 50
'''.replace("{MARKER_INPUT_CLS}", MARKER_INPUT_CLS)


F2B_ENDPOINT_BLOCK = '''


{MARKER_ENDPOINTS}

@app.post("/astro/pitra_dosha/profile", dependencies=[Depends(verify_key)])
def pitra_dosha_profile(p: PitraDoshaInput):
    """
    Detect classical Pitra Dosha signatures in a natal chart.

    Checks: Sun-Rahu/Ketu conjunction, Sun-Saturn malefic combination,
    Rahu/Ketu/Saturn aspects on Sun, weak Sun dignity, 9H lord in dusthana,
    9L weak/combust, Surya grahan (natal eclipse on Sun — reuses F2a).

    Returns verdict (STRONG/MODERATE/MILD/ABSENT) with each signature's
    severity (1-3), evidence text, and classical source citation.
    """
    try:
        birth_dict = {
            "dob": p.birth.dob, "time": p.birth.time,
            "lat": p.birth.lat, "lon": p.birth.lon,
            "timezone": p.birth.timezone,
        }
        return pd_handle_profile(birth_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pitra_dosha/intensity", dependencies=[Depends(verify_key)])
def pitra_dosha_intensity(p: PitraDoshaInput):
    """
    Score Pitra Dosha intensity 0-100 + which signatures contributed.

    Severity-weighted scoring (severity 3 = 30 pts, 2 = 15, 1 = 5; capped at 100).
    Returns banded verdict (HIGH/MODERATE/MILD/ABSENT) + top contributors with
    classical citations.
    """
    try:
        birth_dict = {
            "dob": p.birth.dob, "time": p.birth.time,
            "lat": p.birth.lat, "lon": p.birth.lon,
            "timezone": p.birth.timezone,
        }
        return pd_handle_intensity(birth_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pitra_dosha/remedies_timing", dependencies=[Depends(verify_key)])
def pitra_dosha_remedies_timing(p: PitraDoshaInput):
    """
    Pitru Paksha windows + classical tradition (NOT prescription).

    Computes annual Pitru Paksha (Krishna Paksha of Bhadrapada-Ashvin) windows
    for the next N years (configurable, default 5, max 50). Includes Mahalaya
    Amavasya identification, active dasha context, and classical remedies
    described as 'tradition' with citations.
    """
    try:
        birth_dict = {
            "dob": p.birth.dob, "time": p.birth.time,
            "lat": p.birth.lat, "lon": p.birth.lon,
            "timezone": p.birth.timezone,
        }
        ya = p.years_ahead if p.years_ahead is not None else PD_MAHALAYA_YEARS_DEFAULT
        return pd_handle_remedies_timing(
            birth_dict, query_date=p.query_date, years_ahead=ya)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
'''.replace("{MARKER_ENDPOINTS}", MARKER_ENDPOINTS)


# ═══════════════════════════════════════════════════════════════════════
# Utilities
# ═══════════════════════════════════════════════════════════════════════

def fail(msg, restore_pairs=None):
    print(f"\n❌ ERROR: {msg}")
    if restore_pairs:
        for backup, target in restore_pairs:
            if backup and os.path.exists(backup):
                shutil.copy2(backup, target)
                print(f"   🔄 Restored {target} from {backup}")
    sys.exit(1)


def syntax_check(path, restore_pairs=None):
    try:
        py_compile.compile(path, doraise=True)
        print(f"   ✅ Syntax OK: {path}")
    except py_compile.PyCompileError as e:
        fail(f"Syntax error in {path}: {e}", restore_pairs=restore_pairs)


def smoke_test_as_trading():
    """Layered smoke INCLUDING main.py (U10v2 hardening pattern)."""
    smoke_script = """
import sys, traceback
sys.path.insert(0, '/opt/astro')
layers = [
    ('swisseph',      'swisseph'),
    ('dashaflow',     'dashaflow'),
    ('astro_helpers', 'astro_helpers'),
    ('compatibility', 'compatibility'),
    ('relationships', 'relationships'),
    ('nakshatra',     'nakshatra'),
    ('transit',       'transit'),
    ('eclipse',       'eclipse'),
    ('pitra_dosha',   'pitra_dosha'),
    ('main',          'main'),
]
for label, modname in layers:
    try:
        __import__(modname)
        print(f'OK    {label}')
    except Exception:
        print(f'FAIL  {label}')
        traceback.print_exc()
        sys.exit(1)

from pitra_dosha import (
    handle_pitra_dosha_profile,
    handle_pitra_dosha_intensity,
    handle_pitra_dosha_remedies_timing,
    MAHALAYA_YEARS_DEFAULT, MAHALAYA_YEARS_MAX,
)
print(f'OK    pitra_dosha module API '
      f'(mahalaya_default={MAHALAYA_YEARS_DEFAULT}, mahalaya_max={MAHALAYA_YEARS_MAX})')

import main
print(f'OK    main.app has {len(main.app.routes)} routes registered')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_script] if is_root
           else ["python3", "-c", smoke_script])
    result = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.stderr.strip():
        print(f"   ── stderr ──")
        for line in result.stderr.strip().split("\n"):
            print(f"   {line}")
    return result.returncode == 0


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════

def main():
    print("=" * 70)
    print("F2b — Pitra Dosha module installer (3 endpoints)")
    print("=" * 70)

    if not os.path.exists(MAIN_PY):
        fail(f"{MAIN_PY} not found")
    if not os.path.exists(PITRA_DOSHA_PY):
        fail(f"{PITRA_DOSHA_PY} not found — scp it to /opt/astro/ first")
    print(f"✅ Found {PITRA_DOSHA_PY}")

    # ── Pre-check: pitra_dosha.py imports cleanly ──
    print("\n── Pre-check: pitra_dosha.py imports cleanly as user `trading` ──")
    smoke_pre = """
import sys
sys.path.insert(0, '/opt/astro')
import pitra_dosha
print(f'pitra_dosha loaded, public funcs: '
      f'{[n for n in dir(pitra_dosha) if n.startswith(\"handle_\")]}')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_pre] if is_root
           else ["python3", "-c", smoke_pre])
    r = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if r.returncode != 0:
        fail(f"pitra_dosha.py failed to import:\n{r.stderr}\n{r.stdout}")
    print(f"   {r.stdout.strip()}")

    with open(MAIN_PY, "r") as f:
        content = f.read()
    orig_size = len(content)
    orig_lines = content.count("\n") + 1
    print(f"\nmain.py: {orig_size} bytes, {orig_lines} lines")

    # Idempotency
    if (MARKER_IMPORT in content
            and MARKER_INPUT_CLS in content
            and MARKER_ENDPOINTS in content):
        print("\n✅ All F2b markers already present — patch was applied. No changes.")
        return

    # Anchor validation
    if F2A_IMPORT_TAIL not in content:
        fail("F2a import tail anchor not found in main.py — was F2a applied?")
    print("✅ F2a anchor confirmed")
    if ECLIPSE_INPUT_ANCHOR not in content:
        fail("EclipseInput anchor not found in main.py — was F2a applied?")
    print("✅ EclipseInput anchor confirmed")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    main_backup = f"{MAIN_PY}.before_f2b_{ts}"
    shutil.copy2(MAIN_PY, main_backup)
    print(f"✅ Backup: {main_backup}")

    # ── Phase B: Inject import block ──
    if MARKER_IMPORT not in content:
        content = content.replace(F2A_IMPORT_TAIL, F2A_PLUS_F2B_IMPORT_BLOCK, 1)
        print("✅ Injected F2b import block after F2a imports")
    else:
        print("⏭️  F2b import marker present, skipping")

    # ── Phase C: Inject PitraDoshaInput class after EclipseInput ──
    if MARKER_INPUT_CLS not in content:
        content = content.replace(
            ECLIPSE_INPUT_ANCHOR,
            ECLIPSE_INPUT_ANCHOR + PITRA_INPUT_BLOCK,
            1
        )
        print("✅ Injected PitraDoshaInput class after EclipseInput")
    else:
        print("⏭️  PitraDoshaInput marker present, skipping")

    # ── Phase D: Append endpoints ──
    if MARKER_ENDPOINTS not in content:
        if not content.endswith("\n"):
            content += "\n"
        content += F2B_ENDPOINT_BLOCK
        print("✅ Appended 3 F2b endpoint registrations")
    else:
        print("⏭️  Endpoint marker present, skipping")

    with open(MAIN_PY, "w") as f:
        f.write(content)
    new_size = len(content)
    new_lines = content.count("\n") + 1
    print(f"\n✅ Wrote main.py: {new_size} bytes ({new_size - orig_size:+d}), "
          f"{new_lines} lines ({new_lines - orig_lines:+d})")

    # ── Phase E: Snapshot + syntax ──
    snap = f"{MAIN_PY}.after_f2b_{ts}"
    shutil.copy2(MAIN_PY, snap)
    print(f"✅ Snapshot: {snap}")
    syntax_check(MAIN_PY, restore_pairs=[(main_backup, MAIN_PY)])

    # ── Phase F: Full smoke (including main.py) ──
    print("\n── Phase F: Layered smoke (as user `trading`, INCLUDES main.py) ──")
    ok = smoke_test_as_trading()
    if not ok:
        fail("Smoke test failed — rolling back main.py",
             restore_pairs=[(main_backup, MAIN_PY)])

    print("\n" + "=" * 70)
    print("F2b PATCH APPLIED — next steps:")
    print("  sudo systemctl restart astro && sleep 3")
    print("  curl http://localhost:8001/astro/health      ← MUST return 200")
    print("  Then run verification sweep (see F2B runbook)")
    print("=" * 70)


if __name__ == "__main__":
    main()
