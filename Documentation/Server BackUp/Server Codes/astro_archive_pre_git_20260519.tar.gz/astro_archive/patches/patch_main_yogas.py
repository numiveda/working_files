#!/usr/bin/env python3
"""
patch_main_yogas.py — Auto-patches /opt/astro/main.py with yogas blocks.

Behaviour:
  - Reads /opt/astro/main.py
  - Creates timestamped backup
  - Adds BLOCK_A imports (skips if already present)
  - Skips BLOCK_B models (none needed)
  - Adds BLOCK_C endpoints (skips if already present)
  - Syntax-validates result with ast.parse()
  - Rolls back on syntax error

NOTE: This patcher does NOT replace the existing /astro/yogas endpoint.
It adds a parallel /astro/yogas/* family under the new namespace.
The legacy /astro/yogas endpoint (from old code) remains untouched.
"""
import ast
import os
import re
import shutil
import sys
from datetime import datetime
from main_patches_yogas import (
    BLOCK_A_IMPORTS,
    BLOCK_C_ENDPOINTS,
)

MAIN_PATH = "/opt/astro/main.py"


def patch():
    if not os.path.exists(MAIN_PATH):
        print(f"❌ {MAIN_PATH} not found")
        sys.exit(1)

    # Backup
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = f"{MAIN_PATH}.backup_yogas_{ts}"
    shutil.copy2(MAIN_PATH, backup)
    print(f"✓ Backup created: {backup}")

    with open(MAIN_PATH, "r", encoding="utf-8") as f:
        content = f.read()

    original = content
    changes_made = []

    # ─── BLOCK A: imports ───────────────────────────────────────────────────
    if "BEGIN YOGAS-V2 IMPORTS" in content:
        print("⊙ BLOCK A (imports): already present, skipping")
    else:
        lines = content.split("\n")
        last_import = 0
        for i, line in enumerate(lines[:150]):
            if line.strip().startswith(("import ", "from ")) and not line.strip().startswith("#"):
                last_import = i
        lines.insert(last_import + 1, BLOCK_A_IMPORTS.strip())
        content = "\n".join(lines)
        changes_made.append("BLOCK A (imports)")
        print("✓ BLOCK A (imports) added")

    # ─── BLOCK C: endpoints ────────────────────────────────────────────────
    if "BEGIN YOGAS-V2 ENDPOINTS" in content:
        print("⊙ BLOCK C (endpoints): already present, skipping")
    else:
        # Insert before "@app.on_event" if present, else before "__main__", else append
        on_event_match = re.search(r"\n@app\.on_event\(", content)
        if on_event_match:
            pos = on_event_match.start()
            content = content[:pos] + "\n\n" + BLOCK_C_ENDPOINTS.strip() + "\n\n" + content[pos:]
            print("✓ BLOCK C (endpoints) added before @app.on_event")
        else:
            main_block = re.search(r"\nif\s+__name__\s*==\s*[\"']__main__[\"']", content)
            if main_block:
                pos = main_block.start()
                content = content[:pos] + "\n\n" + BLOCK_C_ENDPOINTS.strip() + "\n\n" + content[pos:]
                print("✓ BLOCK C (endpoints) added before __main__ block")
            else:
                content = content.rstrip() + "\n\n" + BLOCK_C_ENDPOINTS.strip() + "\n"
                print("✓ BLOCK C (endpoints) appended at end of file")
        changes_made.append("BLOCK C (endpoints)")

    # ─── Validate syntax ────────────────────────────────────────────────────
    try:
        ast.parse(content)
    except SyntaxError as e:
        print(f"❌ Syntax error after patching: {e}")
        print(f"   Rolling back from {backup}")
        shutil.copy2(backup, MAIN_PATH)
        sys.exit(1)

    # ─── Write ───────────────────────────────────────────────────────────────
    if content == original:
        print("⊙ No changes needed — main.py already patched")
        return

    with open(MAIN_PATH, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"✓ main.py patched successfully")
    print(f"  Changes: {', '.join(changes_made)}")
    print(f"  Backup retained: {backup}")


if __name__ == "__main__":
    patch()
