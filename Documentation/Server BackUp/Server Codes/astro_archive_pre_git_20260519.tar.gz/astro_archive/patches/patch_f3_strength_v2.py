#!/usr/bin/env python3
"""
patch_f3_strength.py
─────────────────────────────────────────────────────────────────────────
F3 — Strength Module: 3 endpoints (vimshopaka_bala, planetary_summary, comprehensive)

PREREQUISITES:
    - /opt/astro/strength.py present (scp'd separately)
    - F2b applied (we splice after F2b's imports)

PHASES:
    A — Preconditions + pre-import smoke that strength.py loads cleanly
    B — Inject import block after F2b's imports
    C — Inject StrengthInput Pydantic class after PitraDoshaInput
    D — Append 3 endpoint registrations
    E — Snapshot
    F — Full layered smoke INCLUDING main.py (U10v2 hardening)

Idempotent. Auto-rollback on syntax or smoke failure.

Usage:
    sudo python3 /opt/astro/patch_f3_strength.py

Author: Claude (F3, 2026-05-18)
"""

import os
import sys
import shutil
import subprocess
import py_compile
from datetime import datetime

MAIN_PY     = "/opt/astro/main.py"
STRENGTH_PY = "/opt/astro/strength.py"

MARKER_IMPORT    = "# ── F3: Strength module imports (2026-05-18) ──"
MARKER_INPUT_CLS = "# ── F3: StrengthInput (2026-05-18) ──"
MARKER_ENDPOINTS = "# ── F3: /astro/strength/* endpoints (2026-05-18) ──"

# Anchor: F2b import block tail; splice F3 imports after
F2B_IMPORT_TAIL = """    MAHALAYA_YEARS_DEFAULT              as PD_MAHALAYA_YEARS_DEFAULT,
    MAHALAYA_YEARS_MAX                  as PD_MAHALAYA_YEARS_MAX,
)"""

F2B_PLUS_F3_IMPORT_BLOCK = """    MAHALAYA_YEARS_DEFAULT              as PD_MAHALAYA_YEARS_DEFAULT,
    MAHALAYA_YEARS_MAX                  as PD_MAHALAYA_YEARS_MAX,
)


{MARKER_IMPORT}
from strength import (
    handle_vimshopaka_bala         as st_handle_vimshopaka_bala,
    handle_planetary_summary       as st_handle_planetary_summary,
    handle_strength_comprehensive  as st_handle_comprehensive,
)""".replace("{MARKER_IMPORT}", MARKER_IMPORT)


# Anchor: PitraDoshaInput class (F2b marker)
PITRA_INPUT_ANCHOR = """# ── F2b: PitraDoshaInput (2026-05-17) ──
class PitraDoshaInput(BaseModel):
    \"\"\"Input for /astro/pitra_dosha/* endpoints.\"\"\"
    birth: BirthInput
    # remedies_timing only:
    query_date: Optional[str] = None    # YYYY-MM-DD; defaults to today
    years_ahead: Optional[int] = None   # default 5, max 50"""

STRENGTH_INPUT_BLOCK = '''

{MARKER_INPUT_CLS}
class StrengthInput(BaseModel):
    """Input for /astro/strength/* endpoints."""
    birth: BirthInput
'''.replace("{MARKER_INPUT_CLS}", MARKER_INPUT_CLS)


F3_ENDPOINT_BLOCK = '''


{MARKER_ENDPOINTS}

@app.post("/astro/strength/vimshopaka_bala", dependencies=[Depends(verify_key)])
def strength_vimshopaka_bala(s: StrengthInput):
    """
    Vimshopaka Bala (BPHS Ch. 35) — 16-fold combined strength across Shodasavarga.

    For each planet (Sun-Saturn), computes weighted dignity score across all
    16 divisional charts (D1 through D60). Returns per-planet breakdown +
    classical interpretation band (purna/uttama/madhyama/alpa/nirbala).
    """
    try:
        birth_dict = {
            "dob": s.birth.dob, "time": s.birth.time,
            "lat": s.birth.lat, "lon": s.birth.lon,
            "timezone": s.birth.timezone,
        }
        return st_handle_vimshopaka_bala(birth_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/strength/planetary_summary", dependencies=[Depends(verify_key)])
def strength_planetary_summary(s: StrengthInput):
    """
    Synthesis: Shadbala + Vimshopaka + Ishta/Kashta phala per planet.

    Returns functional strength verdict (FULLY STRONG / SHADBALA STRONG /
    VIMSHOPAKA STRONG / MIDDLING / WEAK) with classical narrative and
    actionable recommendation. Identifies which planets carry the chart
    and which need remediation.
    """
    try:
        birth_dict = {
            "dob": s.birth.dob, "time": s.birth.time,
            "lat": s.birth.lat, "lon": s.birth.lon,
            "timezone": s.birth.timezone,
        }
        return st_handle_planetary_summary(birth_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/strength/comprehensive", dependencies=[Depends(verify_key)])
def strength_comprehensive(s: StrengthInput):
    """
    All-in-one strength report: Shadbala + Vimshopaka + Ishta/Kashta + dasha context.

    Most detailed strength endpoint. Includes:
      - Full 6-component Shadbala per planet
      - 16-fold Vimshopaka with per-varga breakdown
      - Ishta/Kashta phala dispositions
      - Functional strength verdicts
      - Active dasha (MD + AD) strength context
      - Strongest/weakest planet ranking
    """
    try:
        birth_dict = {
            "dob": s.birth.dob, "time": s.birth.time,
            "lat": s.birth.lat, "lon": s.birth.lon,
            "timezone": s.birth.timezone,
        }
        return st_handle_comprehensive(birth_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
'''.replace("{MARKER_ENDPOINTS}", MARKER_ENDPOINTS)


# ═══════════════════════════════════════════════════════════════════════
# Utilities
# ═══════════════════════════════════════════════════════════════════════

def fail(msg, restore_pairs=None):
    print(f"\n❌ ERROR: {msg}")
    if restore_pairs:
        for backup, target in restore_pairs:
            if backup and os.path.exists(backup):
                shutil.copy2(backup, target)
                print(f"   🔄 Restored {target} from {backup}")
    sys.exit(1)


def syntax_check(path, restore_pairs=None):
    try:
        py_compile.compile(path, doraise=True)
        print(f"   ✅ Syntax OK: {path}")
    except py_compile.PyCompileError as e:
        fail(f"Syntax error in {path}: {e}", restore_pairs=restore_pairs)


def smoke_test_as_trading():
    """Layered smoke INCLUDING main.py (U10v2 hardening)."""
    smoke_script = """
import sys, traceback
sys.path.insert(0, '/opt/astro')
layers = [
    ('swisseph',      'swisseph'),
    ('dashaflow',     'dashaflow'),
    ('astro_helpers', 'astro_helpers'),
    ('compatibility', 'compatibility'),
    ('relationships', 'relationships'),
    ('nakshatra',     'nakshatra'),
    ('transit',       'transit'),
    ('eclipse',       'eclipse'),
    ('pitra_dosha',   'pitra_dosha'),
    ('strength',      'strength'),
    ('main',          'main'),
]
for label, modname in layers:
    try:
        __import__(modname)
        print(f'OK    {label}')
    except Exception:
        print(f'FAIL  {label}')
        traceback.print_exc()
        sys.exit(1)

from strength import (
    handle_vimshopaka_bala,
    handle_planetary_summary,
    handle_strength_comprehensive,
    _dignity_in_sign,
)
# Spot-test dignity in well-known cases
# Note: Sun in Leo can return 'mooltrikona' (Leo 0-20° classical range)
# OR 'own_sign' (Leo 20-30°). Without degree data, defaults to mooltrikona
# (the more protective classical reading; equal points in Vimshopaka).
sun_leo = _dignity_in_sign('Sun', 'Leo')
assert sun_leo in ('own_sign', 'mooltrikona'), f\"Sun in Leo should be own_sign or mooltrikona, got {sun_leo}\"
assert _dignity_in_sign('Sun', 'Aries') == 'exalted', f\"Sun in Aries should be exalted\"
assert _dignity_in_sign('Sun', 'Libra') == 'debilitated', f\"Sun in Libra should be debilitated\"
assert _dignity_in_sign('Mars', 'Capricorn') == 'exalted', f\"Mars in Capricorn should be exalted\"
assert _dignity_in_sign('Jupiter', 'Cancer') == 'exalted', f\"Jupiter in Cancer should be exalted\"
assert _dignity_in_sign('Saturn', 'Libra') == 'exalted', f\"Saturn in Libra should be exalted\"
print('OK    F3 dignity primitive sanity checks passed (6 classical assertions)')

import main
print(f'OK    main.app has {len(main.app.routes)} routes registered')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_script] if is_root
           else ["python3", "-c", smoke_script])
    result = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.stderr.strip():
        print(f"   ── stderr ──")
        for line in result.stderr.strip().split("\n"):
            print(f"   {line}")
    return result.returncode == 0


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════

def main():
    print("=" * 70)
    print("F3 — Strength Module Installer (3 endpoints)")
    print("=" * 70)

    if not os.path.exists(MAIN_PY):
        fail(f"{MAIN_PY} not found")
    if not os.path.exists(STRENGTH_PY):
        fail(f"{STRENGTH_PY} not found — scp it to /opt/astro/ first")
    print(f"✅ Found {STRENGTH_PY}")

    # Pre-check: strength.py imports cleanly
    print("\n── Pre-check: strength.py imports cleanly as user `trading` ──")
    smoke_pre = """
import sys
sys.path.insert(0, '/opt/astro')
import strength
print(f'strength loaded, public funcs: '
      f'{[n for n in dir(strength) if n.startswith(\"handle_\")]}')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_pre] if is_root
           else ["python3", "-c", smoke_pre])
    r = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if r.returncode != 0:
        fail(f"strength.py failed to import:\n{r.stderr}\n{r.stdout}")
    print(f"   {r.stdout.strip()}")

    with open(MAIN_PY, "r") as f:
        content = f.read()
    orig_size = len(content)
    orig_lines = content.count("\n") + 1
    print(f"\nmain.py: {orig_size} bytes, {orig_lines} lines")

    # Idempotency
    if (MARKER_IMPORT in content
            and MARKER_INPUT_CLS in content
            and MARKER_ENDPOINTS in content):
        print("\n✅ All F3 markers already present — patch was applied. No changes.")
        return

    # Anchor validation
    if F2B_IMPORT_TAIL not in content:
        fail("F2b import tail anchor not found in main.py — was F2b applied?")
    print("✅ F2b anchor confirmed")
    if PITRA_INPUT_ANCHOR not in content:
        fail("PitraDoshaInput anchor not found in main.py — was F2b applied?")
    print("✅ PitraDoshaInput anchor confirmed")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    main_backup = f"{MAIN_PY}.before_f3_{ts}"
    shutil.copy2(MAIN_PY, main_backup)
    print(f"✅ Backup: {main_backup}")

    # Phase B: Inject imports
    if MARKER_IMPORT not in content:
        content = content.replace(F2B_IMPORT_TAIL, F2B_PLUS_F3_IMPORT_BLOCK, 1)
        print("✅ Injected F3 import block after F2b imports")

    # Phase C: Inject StrengthInput class
    if MARKER_INPUT_CLS not in content:
        content = content.replace(
            PITRA_INPUT_ANCHOR,
            PITRA_INPUT_ANCHOR + STRENGTH_INPUT_BLOCK,
            1
        )
        print("✅ Injected StrengthInput class after PitraDoshaInput")

    # Phase D: Append endpoints
    if MARKER_ENDPOINTS not in content:
        if not content.endswith("\n"):
            content += "\n"
        content += F3_ENDPOINT_BLOCK
        print("✅ Appended 3 F3 endpoint registrations")

    with open(MAIN_PY, "w") as f:
        f.write(content)
    new_size = len(content)
    new_lines = content.count("\n") + 1
    print(f"\n✅ Wrote main.py: {new_size} bytes ({new_size - orig_size:+d}), "
          f"{new_lines} lines ({new_lines - orig_lines:+d})")

    # Phase E: Snapshot + syntax
    snap = f"{MAIN_PY}.after_f3_{ts}"
    shutil.copy2(MAIN_PY, snap)
    print(f"✅ Snapshot: {snap}")
    syntax_check(MAIN_PY, restore_pairs=[(main_backup, MAIN_PY)])

    # Phase F: Full smoke
    print("\n── Phase F: Layered smoke (as `trading`, INCLUDES main.py) ──")
    ok = smoke_test_as_trading()
    if not ok:
        fail("Smoke test failed — rolling back",
             restore_pairs=[(main_backup, MAIN_PY)])

    print("\n" + "=" * 70)
    print("F3 PATCH APPLIED — next steps:")
    print("  sudo systemctl restart astro && sleep 3")
    print("  curl http://localhost:8001/astro/health      ← MUST return 200")
    print("  Then run verification sweep (see F3 runbook)")
    print("=" * 70)


if __name__ == "__main__":
    main()
