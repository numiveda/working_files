"""
patch_main_esoteric.py — Adds 27 Esoteric Remedies (Module 3b) endpoints to /opt/astro/main.py

Same proven safe-insertion pattern.
Marker: # ── ESOTERIC REMEDIES MODULE (3b) ──

Run: sudo python3 patch_main_esoteric.py
"""

import re
import sys
from pathlib import Path

MAIN_PY = Path("/opt/astro/main.py")
MARKER_START = "# ── ESOTERIC REMEDIES MODULE (3b) ──"


IMPORT_BLOCK = """
# ── Esoteric Remedies module (3b) imports ──
from remedies_esoteric import (
    planetary_hours_info, goetia_reference, planetary_squares,
    olympic_spirits, talismans_summary,
    atharva_suktas_by_purpose, atharva_healing_hymns,
    atharva_protection_hymns, atharva_abhichar_nullifier, atharva_peace_invocations,
    personal_mahavidya, kavachas_catalog, devi_for_purpose,
    dasha_mahavidya_full, navadurga_correspondence,
    vbt_dharana_for_chart, vbt_breath_techniques, vbt_awareness_techniques,
    vbt_all_112, vbt_devotional_practices,
    tree_of_life, sephirot_for_chart, kabbalistic_paths, divine_names_planetary,
    decan_ruler, hellenistic_time_lord, planetary_deities_cross_tradition,
)

"""


ENDPOINT_BLOCK = '''
# ══════════════════════════════════════════════════════════════════════
# ── ESOTERIC REMEDIES MODULE (3b) ──
# 27 endpoints — Solomonic + Atharva Vedic + Tantric + VBT + Kabbalistic + Egyptian/Hellenistic
# All sources public domain. Classical correspondence reference framing.
# ══════════════════════════════════════════════════════════════════════

class EsotericPurposeInput(BaseModel):
    purpose: str


class EsotericPlanetInput(BaseModel):
    planet: Optional[str] = None


class EsotericWeekdayInput(BaseModel):
    weekday: Optional[str] = None


# ── Solomonic (5) ──

@app.post("/astro/remedies/esoteric/solomonic/planetary_hours")
def esoteric_planetary_hours(inp: EsotericWeekdayInput, _: str = Depends(verify_key)):
    """Classical Chaldean planetary hour system + day rulers + best uses."""
    return planetary_hours_info(weekday=inp.weekday)


@app.post("/astro/remedies/esoteric/solomonic/goetia")
def esoteric_goetia(inp: EsotericPlanetInput, _: str = Depends(verify_key)):
    """72 Goetia reference (first 18 listed) — academic/correspondence reference only."""
    return goetia_reference(planet=inp.planet)


@app.get("/astro/remedies/esoteric/solomonic/planetary_squares")
def esoteric_planetary_squares(_: str = Depends(verify_key)):
    """Planetary magic squares (Kameas) from Agrippa."""
    return planetary_squares()


@app.get("/astro/remedies/esoteric/solomonic/olympic_spirits")
def esoteric_olympic_spirits(_: str = Depends(verify_key)):
    """7 Olympic Spirits from Arbatel of Magic (1575)."""
    return olympic_spirits()


@app.get("/astro/remedies/esoteric/solomonic/talismans")
def esoteric_talismans(_: str = Depends(verify_key)):
    """Classical Hermetic planetary talisman composition (metal, color, timing)."""
    return talismans_summary()


# ── Atharva Vedic (5) ──

@app.post("/astro/remedies/esoteric/atharva/by_purpose")
def esoteric_atharva_by_purpose(inp: EsotericPurposeInput, _: str = Depends(verify_key)):
    """Atharva Veda hymns by purpose: healing, protection, peace, prosperity, nullification."""
    return atharva_suktas_by_purpose(purpose=inp.purpose)


@app.get("/astro/remedies/esoteric/atharva/healing_hymns")
def esoteric_atharva_healing(_: str = Depends(verify_key)):
    """Atharva Veda Bhaishajya (healing) hymns catalog."""
    return atharva_healing_hymns()


@app.get("/astro/remedies/esoteric/atharva/protection_hymns")
def esoteric_atharva_protection(_: str = Depends(verify_key)):
    """Atharva Veda Raksha (protection) hymns catalog."""
    return atharva_protection_hymns()


@app.get("/astro/remedies/esoteric/atharva/abhichar_nullifier")
def esoteric_atharva_nullifier(_: str = Depends(verify_key)):
    """Atharva Veda DEFENSIVE hymns for nullification — self-protection only."""
    return atharva_abhichar_nullifier()


@app.get("/astro/remedies/esoteric/atharva/peace_invocations")
def esoteric_atharva_peace(_: str = Depends(verify_key)):
    """Atharva Veda Shanti (peace) invocations."""
    return atharva_peace_invocations()


# ── Tantric (5) ──

@app.post("/astro/remedies/esoteric/tantric/personal_mahavidya")
def esoteric_personal_mahavidya(inp: BirthInput, _: str = Depends(verify_key)):
    """Personal Mahavidya by weakest planet + Atmakaraka."""
    return personal_mahavidya(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.get("/astro/remedies/esoteric/tantric/kavachas")
def esoteric_kavachas(_: str = Depends(verify_key)):
    """Classical kavachas (armor mantras) catalog."""
    return kavachas_catalog()


@app.post("/astro/remedies/esoteric/tantric/devi_for_purpose")
def esoteric_devi_purpose(inp: EsotericPurposeInput, _: str = Depends(verify_key)):
    """Devi recommendation by purpose (wealth, knowledge, marriage, etc.)."""
    return devi_for_purpose(purpose=inp.purpose)


@app.get("/astro/remedies/esoteric/tantric/dasha_mahavidya")
def esoteric_dasha_mahavidya(_: str = Depends(verify_key)):
    """Full Dasha Mahavidya (10 Wisdom Goddesses) catalog."""
    return dasha_mahavidya_full()


@app.get("/astro/remedies/esoteric/tantric/navadurga")
def esoteric_navadurga(_: str = Depends(verify_key)):
    """Navadurga (9 forms of Durga) — Navaratri correspondence."""
    return navadurga_correspondence()


# ── Vigyan Bhairava Tantra (5) ──

@app.post("/astro/remedies/esoteric/vbt/dharana_for_chart")
def esoteric_vbt_dharana(inp: BirthInput, _: str = Depends(verify_key)):
    """Recommend Vigyan Bhairava dharana based on weakest planet in chart."""
    return vbt_dharana_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.get("/astro/remedies/esoteric/vbt/breath_techniques")
def esoteric_vbt_breath(_: str = Depends(verify_key)):
    """VBT breath-based dharanas."""
    return vbt_breath_techniques()


@app.get("/astro/remedies/esoteric/vbt/awareness_techniques")
def esoteric_vbt_awareness(_: str = Depends(verify_key)):
    """VBT pure awareness dharanas."""
    return vbt_awareness_techniques()


@app.get("/astro/remedies/esoteric/vbt/all_112")
def esoteric_vbt_all(_: str = Depends(verify_key)):
    """VBT — categorization of all 112 dharanas + sample translations."""
    return vbt_all_112()


@app.get("/astro/remedies/esoteric/vbt/devotional_practices")
def esoteric_vbt_devotional(_: str = Depends(verify_key)):
    """VBT devotional/bhava-based dharanas."""
    return vbt_devotional_practices()


# ── Kabbalistic (4) ──

@app.get("/astro/remedies/esoteric/kabbalistic/tree_of_life")
def esoteric_tree_of_life(_: str = Depends(verify_key)):
    """Tree of Life — 10 sephiroth with planetary attributions."""
    return tree_of_life()


@app.post("/astro/remedies/esoteric/kabbalistic/sephirot_for_chart")
def esoteric_sephirot_chart(inp: BirthInput, _: str = Depends(verify_key)):
    """Personal sephirot mapping — Lagna lord, current MD, Atmakaraka sephiroth."""
    return sephirot_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.get("/astro/remedies/esoteric/kabbalistic/paths")
def esoteric_kabbalistic_paths(_: str = Depends(verify_key)):
    """22 paths of the Tree of Life with planetary path summary."""
    return kabbalistic_paths()


@app.get("/astro/remedies/esoteric/kabbalistic/divine_names")
def esoteric_divine_names(_: str = Depends(verify_key)):
    """Divine names + planetary archangels (Hermetic Qabalah)."""
    return divine_names_planetary()


# ── Egyptian / Hellenistic (3) ──

@app.post("/astro/remedies/esoteric/hellenic/decan_ruler")
def esoteric_decan_ruler(inp: BirthInput, _: str = Depends(verify_key)):
    """36-decan system — Lagna sign decans + full 36 table."""
    return decan_ruler(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/esoteric/hellenic/time_lord")
def esoteric_time_lord(inp: BirthInput, _: str = Depends(verify_key)):
    """Hellenistic profections — current year's profected house lord."""
    return hellenistic_time_lord(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.get("/astro/remedies/esoteric/hellenic/planetary_deities")
def esoteric_planetary_deities(_: str = Depends(verify_key)):
    """Cross-tradition planetary deity correspondence (Vedic, Egyptian, Greek, Roman, Norse, etc.)."""
    return planetary_deities_cross_tradition()

# ── END ESOTERIC REMEDIES MODULE (3b) ──
'''


def main():
    if not MAIN_PY.exists():
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    content = MAIN_PY.read_text()

    if MARKER_START in content:
        print(f"⏭️  Esoteric module already patched. Skipping.")
        return

    if "from fastapi import" not in content:
        print("ERROR: main.py doesn't look like a FastAPI app"); sys.exit(1)
    if "verify_key" not in content:
        print("ERROR: verify_key not defined"); sys.exit(1)
    if "BirthInput" not in content:
        print("ERROR: BirthInput model not defined"); sys.exit(1)

    pat = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = pat.search(content)
    if not match:
        print("ERROR: 'app = FastAPI(' not found"); sys.exit(1)

    insertion_point = match.start()
    if insertion_point > 0 and content[insertion_point - 1] != '\n':
        print(f"ERROR: 'app = FastAPI(' not at start of line"); sys.exit(1)

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    MAIN_PY.write_text(new_content)
    print(f"✅ Patched {MAIN_PY}")
    print(f"   Added: 27 Esoteric Remedies (3b) endpoints")
    print(f"   Marker: {MARKER_START}")
    print(f"   File size: {len(new_content)} bytes (was {len(content)})")

    print("\n🔍 Verifying syntax...")
    import py_compile
    try:
        py_compile.compile(str(MAIN_PY), doraise=True)
        print("✅ Syntax OK — ready to restart astro service")
    except py_compile.PyCompileError as e:
        print(f"❌ SYNTAX ERROR: {e}"); sys.exit(1)


if __name__ == "__main__":
    main()
