"""
patch_main_iching.py — Wires 10 I-Ching (D3) endpoints into main.py.

Uses verify_key auth. Idempotent.

Run from /opt/astro:
    sudo python3 patch_main_iching.py
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── ICHING D3 MODULE ──"


IMPORT_BLOCK = '''
# ── ICHING D3 MODULE IMPORTS ──
from iching import (
    handle_profile                 as iching_handle_profile,
    handle_cast_question           as iching_handle_cast_question,
    handle_daily_hexagram          as iching_handle_daily_hexagram,
    handle_hexagram_lookup         as iching_handle_hexagram_lookup,
    handle_trigram_lookup          as iching_handle_trigram_lookup,
    handle_changing_lines_analysis as iching_handle_changing_lines_analysis,
    handle_year_ahead_hexagrams    as iching_handle_year_ahead_hexagrams,
    handle_decision_hexagram       as iching_handle_decision_hexagram,
    handle_shuffle_cast            as iching_handle_shuffle_cast,
    handle_question_focused        as iching_handle_question_focused,
)
# ── END ICHING D3 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── ICHING D3 MODULE ──
# Phase D — Module D3 — I-Ching (10 endpoints)
# Source: King Wen sequence (~1100 BCE, public domain); Wilhelm-Baynes 1924
# Architecture: Birth-anchored deterministic 3-coin casting via SHA-256 RNG
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _IchingBaseModel
from typing import Optional as _IchingOptional, List as _IchingList


class IchingBirthInput(_IchingBaseModel):
    """Optional birth — if absent, casts are fresh-random."""
    dob: _IchingOptional[str] = None
    fresh_shuffle: _IchingOptional[bool] = False


class IchingProfileInput(IchingBirthInput):
    pass


class IchingCastQuestionInput(IchingBirthInput):
    question_text: _IchingOptional[str] = ""


class IchingDailyInput(IchingBirthInput):
    target_date: _IchingOptional[str] = None


class IchingHexLookupInput(_IchingBaseModel):
    hexagram_number: int


class IchingTrigramInput(_IchingBaseModel):
    trigram_name: _IchingOptional[str] = None


class IchingChangingLinesInput(_IchingBaseModel):
    hexagram_number: int
    changing_line_numbers: _IchingList[int]


class IchingYearInput(IchingBirthInput):
    start_year: _IchingOptional[int] = None


class IchingDecisionInput(IchingBirthInput):
    decision_context: _IchingOptional[str] = ""


class IchingQuestionFocusedInput(IchingBirthInput):
    question_text: str


def _iching_birth_to_dict(inp) -> _IchingOptional[dict]:
    if inp.dob is None:
        return None
    return {"dob": inp.dob}


@app.post("/astro/iching/profile")
def iching_profile_ep(inp: IchingProfileInput, _: str = Depends(verify_key)):
    """Master I-Ching synthesis — daily + life-path hexagrams + headlines."""
    return iching_handle_profile(_iching_birth_to_dict(inp))


@app.post("/astro/iching/cast_question")
def iching_cast_question_ep(inp: IchingCastQuestionInput, _: str = Depends(verify_key)):
    """Cast for a specific question. Returns primary + changing lines + resultant."""
    return iching_handle_cast_question(inp.question_text or "",
                                        _iching_birth_to_dict(inp),
                                        inp.fresh_shuffle or False)


@app.post("/astro/iching/daily_hexagram")
def iching_daily_ep(inp: IchingDailyInput, _: str = Depends(verify_key)):
    """One hexagram for the target date (defaults to today). Birth-seeded."""
    return iching_handle_daily_hexagram(_iching_birth_to_dict(inp),
                                         inp.target_date,
                                         inp.fresh_shuffle or False)


@app.post("/astro/iching/hexagram_lookup")
def iching_hex_lookup_ep(inp: IchingHexLookupInput, _: str = Depends(verify_key)):
    """Lookup hexagram by King Wen number (1-64)."""
    return iching_handle_hexagram_lookup(inp.hexagram_number)


@app.post("/astro/iching/trigram_lookup")
def iching_trigram_lookup_ep(inp: IchingTrigramInput, _: str = Depends(verify_key)):
    """Lookup trigram by name (Heaven/Earth/Thunder/etc.) or get all 8."""
    return iching_handle_trigram_lookup(inp.trigram_name)


@app.post("/astro/iching/changing_lines_analysis")
def iching_changing_lines_ep(inp: IchingChangingLinesInput, _: str = Depends(verify_key)):
    """Interpret specific changing lines of a hexagram + compute resultant."""
    return iching_handle_changing_lines_analysis(inp.hexagram_number,
                                                  inp.changing_line_numbers)


@app.post("/astro/iching/year_ahead_hexagrams")
def iching_year_ahead_ep(inp: IchingYearInput, _: str = Depends(verify_key)):
    """12 hexagrams, one per month, for the start_year (defaults to current)."""
    return iching_handle_year_ahead_hexagrams(_iching_birth_to_dict(inp),
                                               inp.start_year,
                                               inp.fresh_shuffle or False)


@app.post("/astro/iching/decision_hexagram")
def iching_decision_ep(inp: IchingDecisionInput, _: str = Depends(verify_key)):
    """Decision reading — proceed/wait/mixed verdict based on hexagram archetype."""
    return iching_handle_decision_hexagram(inp.decision_context or "",
                                            _iching_birth_to_dict(inp),
                                            inp.fresh_shuffle or False)


@app.post("/astro/iching/shuffle_cast")
def iching_shuffle_ep(_: str = Depends(verify_key)):
    """Fresh non-deterministic cast — not reproducible."""
    return iching_handle_shuffle_cast()


@app.post("/astro/iching/question_focused")
def iching_question_focused_ep(inp: IchingQuestionFocusedInput, _: str = Depends(verify_key)):
    """Birth+question-seeded reading. Same question + same birth = same cast."""
    return iching_handle_question_focused(inp.question_text,
                                           _iching_birth_to_dict(inp),
                                           inp.fresh_shuffle or False)

# ── END ICHING D3 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present in main.py.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_iching_d3_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_iching_d3_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ I-Ching D3 module patched into main.py")
    print("   10 endpoints under /astro/iching/* — engine reaches 243 endpoints")


if __name__ == "__main__":
    main()
