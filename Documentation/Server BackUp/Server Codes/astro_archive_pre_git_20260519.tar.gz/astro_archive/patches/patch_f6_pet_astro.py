#!/usr/bin/env python3
"""
patch_f6_pet_astro.py
─────────────────────────────────────────────────────────────────────────
F6 — Pet Astrology: 3 endpoints (compatibility, naming, personality)

PREREQUISITES:
    - /opt/astro/pet_astro.py present (scp'd separately)
    - F9 applied (we splice after F9's imports)

PHASES:
    A — Preconditions + pre-import smoke that pet_astro.py loads cleanly
    B — Inject import block after F9's imports
    C — Inject PetInput + PetCompatInput Pydantic classes after BirthdayInput
    D — Append 3 endpoint registrations
    E — Snapshot
    F — Full layered smoke INCLUDING main.py with F6 functional assertions

Idempotent. Auto-rollback on syntax or smoke failure.

Usage:
    sudo python3 /opt/astro/patch_f6_pet_astro.py

Author: Claude (F6, 2026-05-18)
"""

import os
import sys
import shutil
import subprocess
import py_compile
from datetime import datetime

MAIN_PY    = "/opt/astro/main.py"
PET_PY     = "/opt/astro/pet_astro.py"

MARKER_IMPORT    = "# ── F6: Pet Astrology imports (2026-05-18) ──"
MARKER_INPUT_CLS = "# ── F6: PetInput + PetCompatInput (2026-05-18) ──"
MARKER_ENDPOINTS = "# ── F6: /astro/pet/* endpoints (2026-05-18) ──"

# Anchor: F9 import tail
F9_IMPORT_TAIL = """from birthday_quick import (
    handle_birthday_quick     as bq_handle_quick,
    handle_birthday_headline  as bq_handle_headline,
)"""

F9_PLUS_F6_IMPORT_BLOCK = """from birthday_quick import (
    handle_birthday_quick     as bq_handle_quick,
    handle_birthday_headline  as bq_handle_headline,
)


{MARKER_IMPORT}
from pet_astro import (
    handle_pet_compatibility   as pet_handle_compatibility,
    handle_pet_naming          as pet_handle_naming,
    handle_pet_personality     as pet_handle_personality,
)""".replace("{MARKER_IMPORT}", MARKER_IMPORT)


# Anchor: F9 BirthdayInput class
BIRTHDAY_INPUT_ANCHOR = '''# ── F9: BirthdayInput (2026-05-18) ──
class BirthdayInput(BaseModel):
    """Input for /astro/birthday/* endpoints."""
    birth: BirthInput
    query_date: Optional[str] = None    # YYYY-MM-DD; defaults to today'''

PET_INPUT_BLOCK = '''


{MARKER_INPUT_CLS}
class PetInput(BaseModel):
    """
    Pet input — supports either full birth details or acquisition details.

    Mode 1 (birth): dob, time, lat, lon, timezone
    Mode 2 (acquisition): acquisition_date, acquisition_time, acquisition_lat,
                          acquisition_lon, acquisition_timezone
    """
    # Mode 1 — full birth chart
    dob:      Optional[str] = None
    time:     Optional[str] = None
    lat:      Optional[float] = None
    lon:      Optional[float] = None
    timezone: Optional[str] = "Asia/Kolkata"
    # Mode 2 — acquisition (when pet was brought home)
    acquisition_date:     Optional[str] = None
    acquisition_time:     Optional[str] = None
    acquisition_lat:      Optional[float] = None
    acquisition_lon:      Optional[float] = None
    acquisition_timezone: Optional[str] = "Asia/Kolkata"


class PetCompatInput(BaseModel):
    """Input for /astro/pet/compatibility — pet + owner."""
    pet:   PetInput
    owner: BirthInput'''.replace("{MARKER_INPUT_CLS}", MARKER_INPUT_CLS)


F6_ENDPOINT_BLOCK = '''


{MARKER_ENDPOINTS}

@app.post("/astro/pet/compatibility", dependencies=[Depends(verify_key)])
def pet_compatibility(p: PetCompatInput):
    """
    Pet-owner compatibility via adapted nakshatra koots
    (Tara, Yoni, Gana, Graha Maitri — total max 18).

    Pet input supports two modes:
      - Birth: dob + time + lat + lon + timezone
      - Acquisition: acquisition_date + acquisition_time + acquisition_lat +
                     acquisition_lon + acquisition_timezone

    Owner input: standard birth details (BirthInput).

    Returns: per-koot scores with explanations, total score, percentage, band,
    and verdict. Classically grounded in BPHS Ch. 7 + Hora Sara yoni hierarchy.
    """
    try:
        pet_dict = p.pet.dict(exclude_none=True)
        owner_dict = {
            "dob": p.owner.dob, "time": p.owner.time,
            "lat": p.owner.lat, "lon": p.owner.lon,
            "timezone": p.owner.timezone,
        }
        return pet_handle_compatibility(pet_dict, owner_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pet/naming", dependencies=[Depends(verify_key)])
def pet_naming(p: PetInput):
    """
    Pet naming via classical akshara from operative nakshatra-pada.

    Returns the pada-specific akshara, all 4 alternatives for the nakshatra,
    and illustrative pet-name suggestions for each akshara.
    """
    try:
        pet_dict = p.dict(exclude_none=True)
        return pet_handle_naming(pet_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/pet/personality", dependencies=[Depends(verify_key)])
def pet_personality(p: PetInput):
    """
    Pet personality from natal/operative chart.

    Birth mode: full personality (Moon nakshatra + Sun sign + lagna + ruling planet).
    Acquisition mode: nakshatra-only personality (Sun/lagna at acquisition
                       don't represent permanent pet nature; honest classical scope).

    Returns: nakshatra traits, yoni animal signature, gana classification,
    ruling planet, and personality synthesis.
    """
    try:
        pet_dict = p.dict(exclude_none=True)
        return pet_handle_personality(pet_dict)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
'''.replace("{MARKER_ENDPOINTS}", MARKER_ENDPOINTS)


# ═══════════════════════════════════════════════════════════════════════
# Utilities
# ═══════════════════════════════════════════════════════════════════════

def fail(msg, restore_pairs=None):
    print(f"\n❌ ERROR: {msg}")
    if restore_pairs:
        for backup, target in restore_pairs:
            if backup and os.path.exists(backup):
                shutil.copy2(backup, target)
                print(f"   🔄 Restored {target} from {backup}")
    sys.exit(1)


def syntax_check(path, restore_pairs=None):
    try:
        py_compile.compile(path, doraise=True)
        print(f"   ✅ Syntax OK: {path}")
    except py_compile.PyCompileError as e:
        fail(f"Syntax error in {path}: {e}", restore_pairs=restore_pairs)


def smoke_test_as_trading():
    """Layered smoke INCLUDING main.py + F6 functional assertions."""
    smoke_script = r"""
import sys, traceback
sys.path.insert(0, '/opt/astro')
layers = [
    ('swisseph',       'swisseph'),
    ('dashaflow',      'dashaflow'),
    ('astro_helpers',  'astro_helpers'),
    ('compatibility',  'compatibility'),
    ('relationships',  'relationships'),
    ('nakshatra',      'nakshatra'),
    ('transit',        'transit'),
    ('eclipse',        'eclipse'),
    ('pitra_dosha',    'pitra_dosha'),
    ('strength',       'strength'),
    ('birthday_quick', 'birthday_quick'),
    ('pet_astro',      'pet_astro'),
    ('main',           'main'),
]
for label, modname in layers:
    try:
        __import__(modname)
        print(f'OK    {label}')
    except Exception:
        print(f'FAIL  {label}')
        traceback.print_exc()
        sys.exit(1)

# F6 sanity: koot scorers behave classically
from pet_astro import (
    _score_tara, _score_yoni, _score_gana, _score_graha_maitri,
    _NAKSHATRA_TO_GANA, _NAKSHATRA_AKSHARAS, _NAKSHATRA_PET_TRAITS,
)

# Tara same nakshatra → Janma tara (mixed, 1.5 pts)
t = _score_tara('Ashwini', 'Ashwini')
assert t['tara'] == 'Janma' and t['score'] == 1.5, f"Same nak tara fail: {t}"

# Tara Mrigashira from Swati → Ati-Mitra (verified earlier in F9)
t = _score_tara('Mrigashira', 'Swati')
assert t['tara'] == 'Ati-Mitra' and t['score'] == 3.0, f"Ati-Mitra fail: {t}"

# Yoni same animal opposite gender → max (4 pts)
# Ashwini (Horse, M) + Shatabhisha (Horse, F)
y = _score_yoni('Ashwini', 'Shatabhisha')
assert y['score'] == 4.0, f"Same-yoni-opposite-gender expected 4.0, got {y}"

# Gana: Deva-Deva → 6 pts (Ashwini + Mrigashira both Deva)
g = _score_gana('Ashwini', 'Mrigashira')
assert g['score'] == 6.0, f"Deva-Deva should be 6.0, got {g}"

# Gana: Manushya-Rakshasa → 0 pts (Bharani Manushya + Krittika Rakshasa)
g = _score_gana('Bharani', 'Krittika')
assert g['score'] == 0.0, f"Manushya-Rakshasa should be 0.0, got {g}"

# Graha Maitri: same lord → 5 pts (Ashwini and Magha both Ketu-ruled)
gm = _score_graha_maitri('Ashwini', 'Magha')
assert gm['score'] == 5.0, f"Same-lord should be 5.0, got {gm}"

# Akshara: Pushya should have ['Hu', 'He', 'Ho', 'Da']
assert _NAKSHATRA_AKSHARAS['Pushya'] == ['Hu', 'He', 'Ho', 'Da'], f"Pushya aksharas mismatch"

# Pet trait: Pushya is 'most loyal'
assert 'loyal' in _NAKSHATRA_PET_TRAITS['Pushya'].lower(), "Pushya trait should mention loyalty"

print('OK    F6 koot scorers sanity passed (7 classical assertions)')

import main
print(f'OK    main.app has {len(main.app.routes)} routes registered')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_script] if is_root
           else ["python3", "-c", smoke_script])
    result = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.stderr.strip():
        print(f"   ── stderr ──")
        for line in result.stderr.strip().split("\n"):
            print(f"   {line}")
    return result.returncode == 0


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════

def main():
    print("=" * 70)
    print("F6 — Pet Astrology Module Installer (3 endpoints)")
    print("=" * 70)

    if not os.path.exists(MAIN_PY):
        fail(f"{MAIN_PY} not found")
    if not os.path.exists(PET_PY):
        fail(f"{PET_PY} not found — scp it to /opt/astro/ first")
    print(f"✅ Found {PET_PY}")

    # Pre-check
    print("\n── Pre-check: pet_astro.py imports cleanly as user `trading` ──")
    smoke_pre = """
import sys
sys.path.insert(0, '/opt/astro')
import pet_astro
print(f'pet_astro loaded, public funcs: '
      f'{[n for n in dir(pet_astro) if n.startswith("handle_")]}')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_pre] if is_root
           else ["python3", "-c", smoke_pre])
    r = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if r.returncode != 0:
        fail(f"pet_astro.py failed to import:\n{r.stderr}\n{r.stdout}")
    print(f"   {r.stdout.strip()}")

    with open(MAIN_PY, "r") as f:
        content = f.read()
    orig_size = len(content)
    orig_lines = content.count("\n") + 1
    print(f"\nmain.py: {orig_size} bytes, {orig_lines} lines")

    if (MARKER_IMPORT in content
            and MARKER_INPUT_CLS in content
            and MARKER_ENDPOINTS in content):
        print("\n✅ All F6 markers already present — patch was applied. No changes.")
        return

    # Anchor validation
    if F9_IMPORT_TAIL not in content:
        fail("F9 import tail anchor not found in main.py — was F9 applied?")
    print("✅ F9 anchor confirmed")
    if BIRTHDAY_INPUT_ANCHOR not in content:
        fail("BirthdayInput anchor not found in main.py — was F9 applied?")
    print("✅ BirthdayInput anchor confirmed")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    main_backup = f"{MAIN_PY}.before_f6_{ts}"
    shutil.copy2(MAIN_PY, main_backup)
    print(f"✅ Backup: {main_backup}")

    # Phase B: imports
    if MARKER_IMPORT not in content:
        content = content.replace(F9_IMPORT_TAIL, F9_PLUS_F6_IMPORT_BLOCK, 1)
        print("✅ Injected F6 import block after F9 imports")

    # Phase C: Pydantic classes
    if MARKER_INPUT_CLS not in content:
        content = content.replace(
            BIRTHDAY_INPUT_ANCHOR,
            BIRTHDAY_INPUT_ANCHOR + PET_INPUT_BLOCK,
            1
        )
        print("✅ Injected PetInput + PetCompatInput classes after BirthdayInput")

    # Phase D: endpoints
    if MARKER_ENDPOINTS not in content:
        if not content.endswith("\n"):
            content += "\n"
        content += F6_ENDPOINT_BLOCK
        print("✅ Appended 3 F6 endpoint registrations")

    with open(MAIN_PY, "w") as f:
        f.write(content)
    new_size = len(content)
    new_lines = content.count("\n") + 1
    print(f"\n✅ Wrote main.py: {new_size} bytes ({new_size - orig_size:+d}), "
          f"{new_lines} lines ({new_lines - orig_lines:+d})")

    # Phase E: snapshot + syntax
    snap = f"{MAIN_PY}.after_f6_{ts}"
    shutil.copy2(MAIN_PY, snap)
    print(f"✅ Snapshot: {snap}")
    syntax_check(MAIN_PY, restore_pairs=[(main_backup, MAIN_PY)])

    # Phase F: full smoke
    print("\n── Phase F: Layered smoke (as `trading`, INCLUDES main.py + F6 asserts) ──")
    ok = smoke_test_as_trading()
    if not ok:
        fail("Smoke test failed — rolling back",
             restore_pairs=[(main_backup, MAIN_PY)])

    print("\n" + "=" * 70)
    print("F6 PATCH APPLIED — next steps:")
    print("  sudo systemctl restart astro && sleep 3")
    print("  curl http://localhost:8001/astro/health      ← MUST return 200")
    print("  Then run verification sweep (see F6 runbook)")
    print("=" * 70)


if __name__ == "__main__":
    main()
