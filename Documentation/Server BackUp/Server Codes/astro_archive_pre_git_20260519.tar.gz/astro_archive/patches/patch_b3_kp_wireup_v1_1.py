"""
patch_b3_kp_wireup_v1_1.py — Round 2 HOTFIX

ISSUE FOUND POST-DEPLOY:
    Round 2 left cuspal_sublords_for_category empty in the response.
    Root cause: my code assumed kp_pro returns cuspal_sub_lords as a dict
    keyed by house number, but it's actually a LIST of 12 dicts where each
    dict contains {"house": int, "sub_lord": str, ...}.

FIX:
    Replace the dict-probing logic with list-iteration filtered by house.
    Also fix the parallel logic in the kp_yes_no synthesis that depends
    on the same data structure.

NO regression risk: This only fixes the synthesis section. Response shape
unchanged. Method/classical_source unchanged. Other tests stayed green.

Run from /opt/astro:
    sudo python3 patch_b3_kp_wireup_v1_1.py

Idempotent: marker prevents double-application.
"""

import re
import sys
import os
import shutil
from datetime import datetime

PRASHNA_PY = "/opt/astro/prashna.py"
BACKUP_DIR = "/opt/astro"
MARKER_V1   = "# ── B3 KP WIRE-UP (Round 2) ──"
MARKER_V1_1 = "# ── B3 KP WIRE-UP (Round 2 v1.1) ──"


# ════════════════════════════════════════════════════════════════════════
# OLD BUGGY SECTION (treats cuspal_sub_lords as dict)
# ════════════════════════════════════════════════════════════════════════

OLD_SECTION = '''    # ── Extract cuspal sub-lords for relevant category houses ──
    all_cuspal_sublords = kp_pro_analysis.get("cuspal_sub_lords", {}).get("cuspal_sub_lords", {})
    cuspal_sublords_for_category = {}
    for house_num in positive_houses + negative_houses:
        house_key = f"house_{house_num}" if f"house_{house_num}" in all_cuspal_sublords else str(house_num)
        # Try multiple key formats kp_pro might use
        for candidate in [f"house_{house_num}", str(house_num), house_num]:
            if candidate in all_cuspal_sublords:
                cuspal_sublords_for_category[f"house_{house_num}"] = all_cuspal_sublords[candidate]
                break

    # ── KP yes/no synthesis ──
    # Classical rule: If sub-lords of POSITIVE houses signify the matter, YES.
    # If negative-house sub-lords are involved, NO or obstacles.
    positive_sublords_set = set()
    for h, data in cuspal_sublords_for_category.items():
        if int(h.replace("house_", "")) in positive_houses:
            if isinstance(data, dict):
                sl = data.get("sub_lord")
                if sl:
                    positive_sublords_set.add(sl)

    negative_sublords_set = set()
    for h, data in cuspal_sublords_for_category.items():
        if int(h.replace("house_", "")) in negative_houses:
            if isinstance(data, dict):
                sl = data.get("sub_lord")
                if sl:
                    negative_sublords_set.add(sl)'''


# ════════════════════════════════════════════════════════════════════════
# NEW FIXED SECTION (iterates the list correctly)
# ════════════════════════════════════════════════════════════════════════

NEW_SECTION = '''    # ── B3 KP WIRE-UP (Round 2 v1.1) ── Fixed: cuspal_sub_lords is a LIST not dict
    # Extract cuspal sub-lords for relevant category houses ──
    cuspal_list = kp_pro_analysis.get("cuspal_sub_lords", {}).get("cuspal_sub_lords", [])
    # cuspal_list is a list of dicts like:
    #   {"house": 1, "cusp_sign": "Leo", "cusp_degree": 0.5976,
    #    "longitude": 120.5976, "nakshatra": "Magha",
    #    "star_lord": "Ketu", "sub_lord": "Ketu", "sub_sub_lord": "Saturn"}

    # Build house-keyed lookup for category houses
    cuspal_sublords_for_category = {}
    for cusp_data in cuspal_list:
        if not isinstance(cusp_data, dict):
            continue
        h = cusp_data.get("house")
        if h in positive_houses or h in negative_houses:
            cuspal_sublords_for_category[f"house_{h}"] = cusp_data

    # ── KP yes/no synthesis ──
    # Classical rule: If sub-lords of POSITIVE houses signify the matter, YES.
    # If negative-house sub-lords are involved, NO or obstacles.
    positive_sublords_set = set()
    negative_sublords_set = set()
    for cusp_data in cuspal_list:
        if not isinstance(cusp_data, dict):
            continue
        h = cusp_data.get("house")
        sl = cusp_data.get("sub_lord")
        if not sl:
            continue
        if h in positive_houses:
            positive_sublords_set.add(sl)
        elif h in negative_houses:
            negative_sublords_set.add(sl)'''


def main():
    if not os.path.exists(PRASHNA_PY):
        print(f"ERROR: {PRASHNA_PY} not found")
        sys.exit(1)

    with open(PRASHNA_PY, "r") as f:
        content = f.read()

    if MARKER_V1_1 in content:
        print(f"SKIP: {MARKER_V1_1} already present.")
        sys.exit(0)

    if MARKER_V1 not in content:
        print(f"ERROR: Round 2 v1 hasn't been applied yet (no '{MARKER_V1}' marker found)")
        print("       Run patch_b3_kp_wireup.py first.")
        sys.exit(2)

    if OLD_SECTION not in content:
        print("ERROR: Could not find the old buggy section to replace.")
        print("       Expected exact text not present. Manual review needed.")
        sys.exit(3)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/prashna.py.before_b3_v1_1_{ts}"
    shutil.copyfile(PRASHNA_PY, backup_path)
    print(f"✅ Backup written: {backup_path}")

    original_lines = len(content.split("\n"))
    print(f"   Original prashna.py: {original_lines} lines")
    print()

    # Replace the buggy section
    content = content.replace(OLD_SECTION, NEW_SECTION, 1)
    print("✅ Replaced buggy dict-iteration with list-iteration")

    # Write back
    with open(PRASHNA_PY, "w") as f:
        f.write(content)

    new_lines = len(content.split("\n"))
    print(f"   New prashna.py: {new_lines} lines (delta: {new_lines - original_lines:+d})")

    after_path = f"{BACKUP_DIR}/prashna.py.after_b3_v1_1_{ts}"
    shutil.copyfile(PRASHNA_PY, after_path)
    print(f"✅ After snapshot: {after_path}")
    print()
    print("✅ Hotfix complete. Restart astro and re-test the kp_yes_no_signal.")


if __name__ == "__main__":
    main()
