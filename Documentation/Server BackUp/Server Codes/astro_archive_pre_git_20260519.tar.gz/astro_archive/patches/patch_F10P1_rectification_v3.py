"""
patch_F10P1_rectification_v2.py — F10-P1 installer (Approach D, KP-based BTR)

v2 fix: main.py at line 5151 just ends after the last route handler — no
end-of-file marker exists to anchor on. v1 used PRIMARY/FALLBACK anchors
that don't exist in this main.py. v2 switches to append-to-EOF, which is
strictly safer for this file shape (no risk of inserting in the middle of
an unintended location).

Follows §5.1 locked installer template (Phase A → F, auto-rollback on
F.1/F.2/F.3/F.4). Adds:
  - import rectification           (Phase C)
  - Pydantic models:               (Phase D)
      * EventInput
      * KPRectificationInput(StrictBirthInput)
  - 2 route handlers:              (Phase E)
      * POST /astro/rectification/kp_based
      * GET  /astro/rectification/supported_events

This patch is INDEPENDENT of P2/P3. Idempotency via marker presence check.
"""

import os
import sys
import ast
import shlex
import shutil
import subprocess
import time

# ============================================================================
# Constants
# ============================================================================

ASTRO_DIR     = "/opt/astro"
MAIN_PY       = os.path.join(ASTRO_DIR, "main.py")
MODULE_PY     = os.path.join(ASTRO_DIR, "rectification.py")
PATCH_NAME    = "F10P1_rectification"
TIMESTAMP     = time.strftime("%Y%m%d_%H%M%S")
BACKUP_PATH   = f"{MAIN_PY}.before_{PATCH_NAME}_{TIMESTAMP}"
SNAPSHOT_PATH = f"{MAIN_PY}.after_{PATCH_NAME}_{TIMESTAMP}"
MARKER        = "# ── F10-P1: Birth Time Rectification (KP-based) (2026-05-18) ──"

IMPORT_LINE = "import rectification  # F10-P1"

# ============================================================================
# Logging helpers
# ============================================================================

def log(msg: str) -> None:
    print(f"[{PATCH_NAME}] {msg}", flush=True)


def fail(msg: str) -> None:
    log(f"FAIL: {msg}")
    sys.exit(1)


# ============================================================================
# Trading-user execution helper (§5.1 + §3.13 from HANDOVER_v7)
# ============================================================================

def run_as_trading_user(python_code: str) -> None:
    """All Python execution that imports dashaflow MUST go through this."""
    quoted_py = shlex.quote(python_code)
    shell_cmd = f"cd {shlex.quote(ASTRO_DIR)} && python3 -c {quoted_py}"
    subprocess.check_call(["sudo", "-u", "trading", "bash", "-c", shell_cmd])


def chown_to_trading(path: str) -> None:
    try:
        subprocess.check_call(["chown", "trading:trading", path])
    except subprocess.CalledProcessError as e:
        log(f"WARNING: chown {path} failed: {e}")


# ============================================================================
# Phase A — preflight (file UNTOUCHED if fail)
# ============================================================================

def phase_a_preflight() -> None:
    """Validate environment. No anchor needed — v2 appends to EOF."""
    log("Phase A: preflight (append-mode)")

    # A.1 — main.py exists
    if not os.path.isfile(MAIN_PY):
        fail(f"main.py not found at {MAIN_PY}")

    # A.2 — rectification.py exists alongside (uploaded separately by user)
    if not os.path.isfile(MODULE_PY):
        fail(f"rectification.py not found at {MODULE_PY} — scp it first")

    # A.3 — rectification.py parses
    try:
        with open(MODULE_PY) as f:
            ast.parse(f.read())
    except SyntaxError as e:
        fail(f"rectification.py has SyntaxError: {e}")
    log("Phase A.3: rectification.py syntax OK")

    # A.4 — main.py parses (baseline)
    try:
        with open(MAIN_PY) as f:
            ast.parse(f.read())
    except SyntaxError as e:
        fail(f"main.py has pre-existing SyntaxError (cannot proceed): {e}")
    log("Phase A.4: main.py baseline syntax OK")

    # A.5 — marker absent (patch not already applied) — idempotency guard
    with open(MAIN_PY) as f:
        main_src = f.read()
    if MARKER in main_src:
        fail(f"Marker already present in main.py: {MARKER!r} — already patched?")
    log("Phase A.5: marker absent (not previously patched)")

    # A.6 — Import line absent (defensive)
    if IMPORT_LINE in main_src:
        fail(f"Import line already present: {IMPORT_LINE!r}")
    log("Phase A.6: import line absent")

    # A.7 — Verify required base classes/dependencies present
    if "class StrictBirthInput" not in main_src:
        fail("StrictBirthInput class not found in main.py — F5-U1 must be applied first")
    log("Phase A.7: StrictBirthInput present (F5-U1 confirmed)")

    if "verify_key" not in main_src:
        fail("verify_key dependency not found in main.py")
    log("Phase A.8: verify_key dependency present")

    # A.9 — Verify required names are actually bound at module top level.
    # v2 lesson: substring-matching for "List" gave a false positive against
    # `from typing import (` block where List wasn't actually imported.
    # We now AST-parse main.py and check that each name appears as an Import
    # alias OR an ImportFrom alias OR an assignment target at module scope.
    required_names = ("BaseModel", "ConfigDict", "Depends", "HTTPException")
    main_tree = ast.parse(main_src)
    bound_at_module_scope = set()
    for node in main_tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                bound_at_module_scope.add(alias.asname or alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                bound_at_module_scope.add(alias.asname or alias.name)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for t in targets:
                if isinstance(t, ast.Name):
                    bound_at_module_scope.add(t.id)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            bound_at_module_scope.add(node.name)

    missing = [n for n in required_names if n not in bound_at_module_scope]
    if missing:
        fail(
            f"Required names not bound at module scope: {missing}. "
            f"v2 substring-match was unreliable; this AST check is authoritative."
        )
    log(f"Phase A.9: required names bound at module scope: {required_names}")

    # A.10 — Verify main.py is structurally an FastAPI app file (has at least one @app. decorator)
    if "@app.post(" not in main_src and "@app.get(" not in main_src:
        fail("No @app. decorators found — does not look like the FastAPI main.py")
    log("Phase A.10: FastAPI app structure confirmed")

    # A.11 — Verify end-of-file is at module top-level (not mid-function)
    # We do this by re-parsing and checking the last top-level node ends at the
    # last non-empty line; if there's trailing partial code, we'd have failed A.4.
    log("Phase A.11: EOF append-target validated")

    log("Phase A: PASSED")


# ============================================================================
# Phase B — backup
# ============================================================================

def phase_b_backup() -> None:
    log("Phase B: backup main.py")
    shutil.copy2(MAIN_PY, BACKUP_PATH)
    log(f"Phase B: backup at {BACKUP_PATH}")


# ============================================================================
# Phase C / D / E — assemble the insertion block
# ============================================================================

INSERTION_BLOCK = '''

__MARKER__
import rectification  # F10-P1


class EventInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    event_type: str
    event_date: str  # YYYY-MM-DD
    weight: float = 1.0


class KPRectificationInput(StrictBirthInput):
    # Inherits dob, time, lat, lon, timezone + extra=forbid from StrictBirthInput
    # Uses PEP 585 lowercase generics (Python 3.9+) — no `from typing import List` needed
    events: list[EventInput]
    scan_window_minutes: int = 120
    scan_granularity_minutes: int = 1
    top_n: int = 5


@app.post(
    "/astro/rectification/kp_based",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p1_kp_rectification(payload: KPRectificationInput):
    try:
        events_dicts = [
            {"event_type": e.event_type, "event_date": e.event_date, "weight": e.weight}
            for e in payload.events
        ]
        result = rectification.handle_kp_rectification(
            dob=payload.dob,
            time=payload.time,
            lat=payload.lat,
            lon=payload.lon,
            timezone=payload.timezone,
            events=events_dicts,
            scan_window_minutes=payload.scan_window_minutes,
            scan_granularity_minutes=payload.scan_granularity_minutes,
            top_n=payload.top_n,
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"KP rectification failed: {exc}")


@app.get(
    "/astro/rectification/supported_events",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p1_supported_events():
    return rectification.handle_supported_events()
'''


def build_insertion_text() -> str:
    # Use .replace() not .format() — INSERTION_BLOCK contains literal {} from
    # Python dict comprehensions in the embedded route handlers, which would
    # collide with str.format's placeholder syntax.
    return INSERTION_BLOCK.replace("__MARKER__", MARKER)


# ============================================================================
# Phase F — write + chown + syntax + smoke + auto-rollback
# ============================================================================

def phase_f_write_and_verify() -> None:
    log("Phase F: write + verify (append mode)")

    with open(MAIN_PY) as f:
        original = f.read()

    # Ensure original ends with newline (defensive — main.py at line 5151
    # may or may not have trailing newline)
    if not original.endswith("\n"):
        original = original + "\n"

    insertion = build_insertion_text()
    new_src = original + insertion

    # Sanity: new content was actually appended
    if len(new_src) <= len(original):
        fail("Phase F: append produced no growth — aborting")

    # Atomic-ish write (write to temp then replace)
    tmp_path = MAIN_PY + ".tmp"
    with open(tmp_path, "w") as f:
        f.write(new_src)
    os.replace(tmp_path, MAIN_PY)
    chown_to_trading(MAIN_PY)
    log(f"Phase F: main.py written ({len(original)} → {len(new_src)} bytes)")

    # ---- F.1 — Syntax check (in trading user's sys.path) -----------------
    try:
        run_as_trading_user(
            "import ast, sys; "
            "src = open('/opt/astro/main.py').read(); "
            "ast.parse(src); "
            "print('syntax_ok')"
        )
    except subprocess.CalledProcessError:
        log("Phase F.1 FAIL: syntax check failed — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        fail("Phase F.1: SyntaxError in patched main.py — rolled back from backup")
    log("Phase F.1: syntax check OK")

    # ---- F.2 — Smoke (import rectification + check handlers exist) -------
    # NOTE per §5.2 Lesson #3: single_input grammar — NO top-level
    # compound statements (for/try/while/if-else/with). All logic in
    # one expression chain or via assert statements.
    smoke = (
        "import rectification; "
        "assert hasattr(rectification, 'handle_kp_rectification'), 'handle_kp_rectification missing'; "
        "assert hasattr(rectification, 'handle_supported_events'), 'handle_supported_events missing'; "
        "assert callable(rectification.handle_kp_rectification), 'handle_kp_rectification not callable'; "
        "r = rectification.handle_supported_events(); "
        "assert isinstance(r, dict) and 'supported_event_types' in r, 'supported_events bad shape'; "
        "assert 'marriage' in r['supported_event_types'], 'marriage event type missing'; "
        "import main; "
        "assert hasattr(main, 'f10p1_kp_rectification'), 'route handler missing on main'; "
        "assert hasattr(main, 'f10p1_supported_events'), 'supported_events route missing on main'; "
        "print('smoke_ok')"
    )

    try:
        run_as_trading_user(smoke)
    except subprocess.CalledProcessError:
        log("Phase F.2 FAIL: smoke test failed — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        fail("Phase F.2: smoke test failed — rolled back from backup")
    log("Phase F.2: smoke OK")

    # ---- F.3 — Service restart + health check ----------------------------
    log("Phase F.3: restarting astro service")
    try:
        subprocess.check_call(["systemctl", "restart", "astro"])
    except subprocess.CalledProcessError as e:
        log(f"Phase F.3 FAIL: systemctl restart failed: {e}")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        subprocess.call(["systemctl", "restart", "astro"])
        fail("Phase F.3: service restart failed — rolled back")
    time.sleep(3)

    try:
        out = subprocess.check_output(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             "http://localhost:8001/astro/health"],
            timeout=10,
        ).decode().strip()
    except subprocess.CalledProcessError as e:
        out = f"curl_failed:{e}"

    if out != "200":
        log(f"Phase F.3 FAIL: /astro/health returned {out!r} — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        subprocess.call(["systemctl", "restart", "astro"])
        fail(f"Phase F.3: health check returned {out!r} — rolled back")
    log("Phase F.3: /astro/health = 200")

    # ---- F.4 — Verify new endpoints registered ---------------------------
    try:
        endpoints_out = subprocess.check_output(
            ["curl", "-s", "http://localhost:8001/openapi.json"],
            timeout=10,
        ).decode()
    except subprocess.CalledProcessError as e:
        log(f"Phase F.4 WARN: openapi fetch failed: {e}")
        endpoints_out = ""

    if "/astro/rectification/kp_based" not in endpoints_out:
        log("Phase F.4 FAIL: /astro/rectification/kp_based not in openapi.json — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        subprocess.call(["systemctl", "restart", "astro"])
        fail("Phase F.4: endpoint not registered — rolled back")
    log("Phase F.4: /astro/rectification/kp_based registered")

    if "/astro/rectification/supported_events" not in endpoints_out:
        log("Phase F.4 FAIL: /astro/rectification/supported_events not in openapi.json — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        subprocess.call(["systemctl", "restart", "astro"])
        fail("Phase F.4: supported_events endpoint not registered — rolled back")
    log("Phase F.4: /astro/rectification/supported_events registered")

    # ---- F.5 — Snapshot post-success copy --------------------------------
    shutil.copy2(MAIN_PY, SNAPSHOT_PATH)
    log(f"Phase F.5: snapshot at {SNAPSHOT_PATH}")

    log("Phase F: PASSED")


# ============================================================================
# Main
# ============================================================================

def main():
    log(f"Starting {PATCH_NAME} (v2 append-mode) at {TIMESTAMP}")
    if os.geteuid() != 0:
        fail("Must run as root (use sudo)")

    phase_a_preflight()
    phase_b_backup()
    phase_f_write_and_verify()

    log("=" * 60)
    log(f"{PATCH_NAME}: SUCCESS")
    log(f"Backup:   {BACKUP_PATH}")
    log(f"Snapshot: {SNAPSHOT_PATH}")
    log("New endpoints:")
    log("  POST /astro/rectification/kp_based")
    log("  GET  /astro/rectification/supported_events")
    log("Engine: 319 → 321 endpoints")
    log("=" * 60)


if __name__ == "__main__":
    main()
