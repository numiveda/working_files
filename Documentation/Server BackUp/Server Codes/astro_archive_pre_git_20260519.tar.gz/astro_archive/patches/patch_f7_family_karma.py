#!/usr/bin/env python3
"""
patch_f7_family_karma.py — F7 Family Tree Karma installer (v1)

Installs /astro/karma/family_patterns, /astro/karma/ancestral_strengths,
/astro/karma/lineage_yogas, /astro/karma/karaka_inheritance,
/astro/karma/dasha_lineage into main.py.

Module file family_karma.py must already be present at /opt/astro/family_karma.py.

Built using the locked v4 + F5-U1 pattern:
- run_as_trading_user (subprocess via `sudo -u trading bash -c`) for dashaflow
- chown_to_trading after every file write
- byte-verified anchors with cat -A done BEFORE writing (Section 3.12)
- auto-rollback on Phase F.1 (syntax) or Phase F.2 (smoke) failure
- StrictBirthInput reuse (defined in main.py by F5-U1) for HTTP-layer hygiene
- Smoke string: ZERO top-level compound statements (no for/try/while/if-else
  with bodies) — uses _t() helper-via-exec pattern from F5-U1 if compound
  logic needed (S3 lesson)

Phase A — Precondition + anchor validation (file UNTOUCHED if fail)
Phase B — Backup main.py
Phase C — Insert F7 import block (after F5 imports, before END COMPATIBILITY C1)
Phase D — Insert F7 Pydantic input models (after F5 inputs, before CompatibilityInput)
Phase E — Append F7 routes to end of main.py
Phase F — Snapshot + chown + syntax check + layered smoke (auto-rollback if fail)

Idempotency: marker comment "# ── F7: Family Karma module imports (2026-05-18) ──"
is checked first; if present, exit cleanly.

Author: Claude (F7, 2026-05-18)
"""

import os
import sys
import shutil
import shlex
import subprocess
import time

# ─── Configuration ──────────────────────────────────────────────────────────
ASTRO_DIR        = "/opt/astro"
MAIN_PY          = os.path.join(ASTRO_DIR, "main.py")
FAMILY_KARMA_PY  = os.path.join(ASTRO_DIR, "family_karma.py")
PATCH_NAME       = "f7_family_karma"
TIMESTAMP        = time.strftime("%Y%m%d_%H%M%S")
BACKUP_PATH      = f"{MAIN_PY}.before_{PATCH_NAME}_{TIMESTAMP}"
SNAPSHOT_PATH    = f"{MAIN_PY}.after_{PATCH_NAME}_{TIMESTAMP}"
MARKER           = "# ── F7: Family Karma module imports (2026-05-18) ──"


# ─── Anchors (byte-verified post-F5-U1 from production main.py 2026-05-18) ──

# Anchor A1: F7 imports go after F5's import block close, before
# the END COMPATIBILITY C1 marker.
# Byte-verified: F5 imports close at line 314 ")", line 315 blank,
# line 316 "# ── END COMPATIBILITY C1 IMPORTS ──"
ANCHOR_F5_IMPORT_BLOCK_CLOSE = (
    "from pregnancy import (\n"
    "    handle_conception_muhurta        as pg_handle_conception_muhurta,\n"
    "    handle_santana_yogas             as pg_handle_santana_yogas,\n"
    "    handle_prenatal_remedies         as pg_handle_prenatal_remedies,\n"
    "    handle_bala_arishta              as pg_handle_bala_arishta,\n"
    "    handle_newborn_naming_window     as pg_handle_newborn_naming_window,\n"
    "    handle_garbha_shanti_remedies    as pg_handle_garbha_shanti_remedies,\n"
    "    PCPNDT_NOTE                      as PG_PCPNDT_NOTE,\n"
    ")\n"
    "\n"
    "# ── END COMPATIBILITY C1 IMPORTS ──"
)

NEW_F5_PLUS_F7_IMPORTS = (
    "from pregnancy import (\n"
    "    handle_conception_muhurta        as pg_handle_conception_muhurta,\n"
    "    handle_santana_yogas             as pg_handle_santana_yogas,\n"
    "    handle_prenatal_remedies         as pg_handle_prenatal_remedies,\n"
    "    handle_bala_arishta              as pg_handle_bala_arishta,\n"
    "    handle_newborn_naming_window     as pg_handle_newborn_naming_window,\n"
    "    handle_garbha_shanti_remedies    as pg_handle_garbha_shanti_remedies,\n"
    "    PCPNDT_NOTE                      as PG_PCPNDT_NOTE,\n"
    ")\n"
    "\n"
    "\n"
    "# ── F7: Family Karma module imports (2026-05-18) ──\n"
    "from family_karma import (\n"
    "    handle_family_patterns         as fk_handle_family_patterns,\n"
    "    handle_ancestral_strengths     as fk_handle_ancestral_strengths,\n"
    "    handle_lineage_yogas           as fk_handle_lineage_yogas,\n"
    "    handle_karaka_inheritance      as fk_handle_karaka_inheritance,\n"
    "    handle_dasha_lineage           as fk_handle_dasha_lineage,\n"
    ")\n"
    "\n"
    "# ── END COMPATIBILITY C1 IMPORTS ──"
)


# Anchor A2: F7 input wrappers go after F5's GarbhaShantiInput, before
# CompatibilityInput. Byte-verified from production: GarbhaShantiInput at 761,
# CompatibilityInput at 773 → there are blank lines between them.
# We'll use a more robust anchor: the END of GarbhaShantiInput class through
# the START of CompatibilityInput class.
ANCHOR_GARBHA_TO_COMPATIBILITY = (
    "class GarbhaShantiInput(BaseModel):\n"
    "    \"\"\"Input for /astro/pregnancy/garbha_shanti_remedies — classical spiritual practices.\n"
    "\n"
    "    Classical practices ONLY. Always supplementary to medical care.\n"
    "    \"\"\"\n"
    "    model_config = ConfigDict(extra=\"forbid\")\n"
    "    mother_chart:       StrictBirthInput\n"
    "    gestational_month:  Optional[int] = None   # 1-9\n"
    "    father_chart:       Optional[StrictBirthInput] = None\n"
    "\n"
    "\n"
    "\n"
    "class CompatibilityInput(BaseModel):"
)

NEW_GARBHA_PLUS_F7_PLUS_COMPATIBILITY = (
    "class GarbhaShantiInput(BaseModel):\n"
    "    \"\"\"Input for /astro/pregnancy/garbha_shanti_remedies — classical spiritual practices.\n"
    "\n"
    "    Classical practices ONLY. Always supplementary to medical care.\n"
    "    \"\"\"\n"
    "    model_config = ConfigDict(extra=\"forbid\")\n"
    "    mother_chart:       StrictBirthInput\n"
    "    gestational_month:  Optional[int] = None   # 1-9\n"
    "    father_chart:       Optional[StrictBirthInput] = None\n"
    "\n"
    "\n"
    "# ── F7: Family Karma inputs (2026-05-18) ──\n"
    "# All F7 inputs use StrictBirthInput (from F5-U1) to reject unknown\n"
    "# fields at the HTTP layer. self_birth is required; ancestor charts are\n"
    "# optional and reduce synthesis depth gracefully when absent.\n"
    "#\n"
    "class FamilyPatternsInput(BaseModel):\n"
    "    \"\"\"Input for /astro/karma/family_patterns — multi-chart pattern detection.\"\"\"\n"
    "    model_config = ConfigDict(extra=\"forbid\")\n"
    "    self_birth:                       StrictBirthInput\n"
    "    mother_birth:                     Optional[StrictBirthInput] = None\n"
    "    father_birth:                     Optional[StrictBirthInput] = None\n"
    "    paternal_grandfather_birth:       Optional[StrictBirthInput] = None\n"
    "    maternal_grandfather_birth:       Optional[StrictBirthInput] = None\n"
    "\n"
    "\n"
    "class AncestralStrengthsInput(BaseModel):\n"
    "    \"\"\"Input for /astro/karma/ancestral_strengths — 4th/9th/12th deep dive + overlay.\"\"\"\n"
    "    model_config = ConfigDict(extra=\"forbid\")\n"
    "    self_birth:    StrictBirthInput\n"
    "    mother_birth:  Optional[StrictBirthInput] = None\n"
    "    father_birth:  Optional[StrictBirthInput] = None\n"
    "\n"
    "\n"
    "class LineageYogasInput(BaseModel):\n"
    "    \"\"\"Input for /astro/karma/lineage_yogas — classical multi-generation yoga catalog.\"\"\"\n"
    "    model_config = ConfigDict(extra=\"forbid\")\n"
    "    self_birth:    StrictBirthInput\n"
    "    mother_birth:  Optional[StrictBirthInput] = None\n"
    "    father_birth:  Optional[StrictBirthInput] = None\n"
    "\n"
    "\n"
    "class KarakaInheritanceInput(BaseModel):\n"
    "    \"\"\"Input for /astro/karma/karaka_inheritance — Jaimini karaka cross-chart synthesis.\"\"\"\n"
    "    model_config = ConfigDict(extra=\"forbid\")\n"
    "    self_birth:                       StrictBirthInput\n"
    "    mother_birth:                     Optional[StrictBirthInput] = None\n"
    "    father_birth:                     Optional[StrictBirthInput] = None\n"
    "    paternal_grandfather_birth:       Optional[StrictBirthInput] = None\n"
    "    maternal_grandfather_birth:       Optional[StrictBirthInput] = None\n"
    "\n"
    "\n"
    "class DashaLineageInput(BaseModel):\n"
    "    \"\"\"Input for /astro/karma/dasha_lineage — cross-chart dasha overlap timing.\"\"\"\n"
    "    model_config = ConfigDict(extra=\"forbid\")\n"
    "    self_birth:        StrictBirthInput\n"
    "    mother_birth:      Optional[StrictBirthInput] = None\n"
    "    father_birth:      Optional[StrictBirthInput] = None\n"
    "    lookahead_years:   Optional[int] = 20\n"
    "\n"
    "\n"
    "\n"
    "class CompatibilityInput(BaseModel):"
)


# Helper for routes — produces a {dob, time, lat, lon, timezone} dict from
# a StrictBirthInput Pydantic model. The route functions use this inline.
# (No anchor for it; it's inlined into each route.)

# Anchor A3: F7 routes append at end-of-file. File ends with LF
# after `raise HTTPException(status_code=400, detail=str(e))`.
F7_ROUTES_APPEND = (
    "\n"
    "\n"
    "# ── F7: /astro/karma/* endpoints (2026-05-18) ──\n"
    "#\n"
    "# Multi-chart family-karma synthesis on top of existing single-chart\n"
    "# modules (pitra_dosha, karmic, children_education). Inputs use\n"
    "# StrictBirthInput for HTTP-layer hygiene.\n"
    "#\n"
    "\n"
    "def _fk_birth_dict(b):\n"
    "    \"\"\"Convert a StrictBirthInput Pydantic model to a dict for handler call.\"\"\"\n"
    "    if b is None:\n"
    "        return None\n"
    "    return {\n"
    "        \"dob\":      b.dob,\n"
    "        \"time\":     b.time,\n"
    "        \"lat\":      b.lat,\n"
    "        \"lon\":      b.lon,\n"
    "        \"timezone\": b.timezone,\n"
    "    }\n"
    "\n"
    "\n"
    "@app.post(\"/astro/karma/family_patterns\", dependencies=[Depends(verify_key)])\n"
    "def karma_family_patterns(f: FamilyPatternsInput):\n"
    "    \"\"\"\n"
    "    Multi-chart pattern detection. Calls existing pitra_dosha + karmic +\n"
    "    children_education handlers on each provided chart, then surfaces\n"
    "    shared affliction signatures, transmitted/broken yogas, and\n"
    "    inherited Putra-Pitri combinations.\n"
    "\n"
    "    self_birth is required; mother/father/grandfather charts are optional\n"
    "    and increase synthesis depth.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        return fk_handle_family_patterns(\n"
    "            self_birth                  = _fk_birth_dict(f.self_birth),\n"
    "            mother_birth                = _fk_birth_dict(f.mother_birth),\n"
    "            father_birth                = _fk_birth_dict(f.father_birth),\n"
    "            paternal_grandfather_birth  = _fk_birth_dict(f.paternal_grandfather_birth),\n"
    "            maternal_grandfather_birth  = _fk_birth_dict(f.maternal_grandfather_birth),\n"
    "        )\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
    "\n"
    "\n"
    "@app.post(\"/astro/karma/ancestral_strengths\", dependencies=[Depends(verify_key)])\n"
    "def karma_ancestral_strengths(a: AncestralStrengthsInput):\n"
    "    \"\"\"\n"
    "    Deep dive on 4th (mother lineage), 9th (father lineage), 12th\n"
    "    (ancestral karma) houses for self chart, with optional cross-chart\n"
    "    overlay from parent charts.\n"
    "\n"
    "    Reuses karmic.handle_twelfth_house_moksha and pitra_dosha.profile.\n"
    "    Adds matri/pitri transmission overlay if parent charts provided.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        return fk_handle_ancestral_strengths(\n"
    "            self_birth   = _fk_birth_dict(a.self_birth),\n"
    "            mother_birth = _fk_birth_dict(a.mother_birth),\n"
    "            father_birth = _fk_birth_dict(a.father_birth),\n"
    "        )\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
    "\n"
    "\n"
    "@app.post(\"/astro/karma/lineage_yogas\", dependencies=[Depends(verify_key)])\n"
    "def karma_lineage_yogas(l: LineageYogasInput):\n"
    "    \"\"\"\n"
    "    Detect classical lineage-specific yogas across charts:\n"
    "    Pitri-Continuity, Matri-Continuity, Pitri-Rupture, Matri-Rupture,\n"
    "    Putra-Pitri inherited, Kuladevi-Activation, Rahu-Lineage-Shift,\n"
    "    Ketu-Ancestral-Release.\n"
    "\n"
    "    Sources: Jaimini Sutras Ch. 2; BPHS Ch. 32; Phaladeepika Ch. 13;\n"
    "    Saravali Ch. 23.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        return fk_handle_lineage_yogas(\n"
    "            self_birth   = _fk_birth_dict(l.self_birth),\n"
    "            mother_birth = _fk_birth_dict(l.mother_birth),\n"
    "            father_birth = _fk_birth_dict(l.father_birth),\n"
    "        )\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
    "\n"
    "\n"
    "@app.post(\"/astro/karma/karaka_inheritance\", dependencies=[Depends(verify_key)])\n"
    "def karma_karaka_inheritance(k: KarakaInheritanceInput):\n"
    "    \"\"\"\n"
    "    Jaimini karaka cross-chart comparison. For each of the 7 karakas\n"
    "    (Atmakaraka, Amatyakaraka, Bhratrikaraka, Matrikaraka, Putrakaraka,\n"
    "    Gnatikaraka, Darakaraka), compare self vs. each provided ancestor:\n"
    "    same planet (continued/intensified/released) or different (shifted).\n"
    "\n"
    "    Source: Jaimini Upadesha Sutras Ch. 2; BPHS Ch. 32.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        return fk_handle_karaka_inheritance(\n"
    "            self_birth                  = _fk_birth_dict(k.self_birth),\n"
    "            mother_birth                = _fk_birth_dict(k.mother_birth),\n"
    "            father_birth                = _fk_birth_dict(k.father_birth),\n"
    "            paternal_grandfather_birth  = _fk_birth_dict(k.paternal_grandfather_birth),\n"
    "            maternal_grandfather_birth  = _fk_birth_dict(k.maternal_grandfather_birth),\n"
    "        )\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
    "\n"
    "\n"
    "@app.post(\"/astro/karma/dasha_lineage\", dependencies=[Depends(verify_key)])\n"
    "def karma_dasha_lineage(d: DashaLineageInput):\n"
    "    \"\"\"\n"
    "    Cross-chart dasha overlap analysis. Identifies periods where self's\n"
    "    Mahadasha planet matches a parent's MD planet — classical activation\n"
    "    window for inherited karma in that planet's domain.\n"
    "\n"
    "    Source: BPHS Ch. 46-52 (Vimshottari); Phaladeepika Ch. 26.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        return fk_handle_dasha_lineage(\n"
    "            self_birth      = _fk_birth_dict(d.self_birth),\n"
    "            mother_birth    = _fk_birth_dict(d.mother_birth),\n"
    "            father_birth    = _fk_birth_dict(d.father_birth),\n"
    "            lookahead_years = d.lookahead_years or 20,\n"
    "        )\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
)


# ─── Phase logic ────────────────────────────────────────────────────────────

def log(msg: str) -> None:
    print(f"[patch_f7] {msg}", flush=True)


def fail(msg: str, code: int = 1) -> None:
    print(f"[patch_f7] FAIL: {msg}", file=sys.stderr, flush=True)
    sys.exit(code)


def run_as_trading_user(python_code: str) -> None:
    """Subprocess via sudo -u trading bash -c (locked pattern; v4 lesson)."""
    quoted_py = shlex.quote(python_code)
    shell_cmd = f"cd {shlex.quote(ASTRO_DIR)} && python3 -c {quoted_py}"
    subprocess.check_call(["sudo", "-u", "trading", "bash", "-c", shell_cmd])


def chown_to_trading(path: str) -> None:
    try:
        subprocess.check_call(["chown", "trading:trading", path])
    except subprocess.CalledProcessError as e:
        log(f"WARNING: chown {path} failed: {e}")


def phase_a_preflight() -> str:
    log("Phase A — precondition + anchor validation")

    if not os.path.isfile(MAIN_PY):
        fail(f"main.py not found at {MAIN_PY}")
    if not os.path.isfile(FAMILY_KARMA_PY):
        fail(f"family_karma.py not found at {FAMILY_KARMA_PY} — upload first")

    with open(MAIN_PY, "r", encoding="utf-8") as f:
        content = f.read()

    if MARKER in content:
        log("Marker already present — patch is idempotent, exiting.")
        sys.exit(0)

    # Anchor 1: F5 import close → END marker
    a1 = content.count(ANCHOR_F5_IMPORT_BLOCK_CLOSE)
    if a1 != 1:
        fail(f"Anchor A1 (F5 imports close) appears {a1} times; expected 1.")

    # Anchor 2: GarbhaShantiInput → CompatibilityInput
    a2 = content.count(ANCHOR_GARBHA_TO_COMPATIBILITY)
    if a2 != 1:
        fail(f"Anchor A2 (GarbhaShantiInput → CompatibilityInput) appears "
             f"{a2} times; expected 1. main.py may have drifted post-F5-U1.")

    # Module-level checks for family_karma.py
    try:
        run_as_trading_user(
            "import ast; ast.parse(open('/opt/astro/family_karma.py').read())"
        )
    except subprocess.CalledProcessError:
        fail("family_karma.py syntax check failed")

    log("Verifying family_karma.py imports cleanly...")
    cmd = (
        "import family_karma; "
        "assert hasattr(family_karma, 'handle_family_patterns'); "
        "assert hasattr(family_karma, 'handle_ancestral_strengths'); "
        "assert hasattr(family_karma, 'handle_lineage_yogas'); "
        "assert hasattr(family_karma, 'handle_karaka_inheritance'); "
        "assert hasattr(family_karma, 'handle_dasha_lineage'); "
        "assert hasattr(family_karma, 'F7_CITATIONS'); "
        "assert hasattr(family_karma, 'LINEAGE_YOGA_CATALOG'); "
        "assert len(family_karma.LINEAGE_YOGA_CATALOG) == 8, 'must have 8 lineage yogas'; "
        "assert len(family_karma.KARAKA_ROLES) == 7, 'must have 7 karakas'; "
        "print('family_karma.py imports OK')"
    )
    try:
        run_as_trading_user(cmd)
    except subprocess.CalledProcessError:
        fail("family_karma.py import test failed — fix module before re-running")

    log("Phase A — OK (file untouched)")
    return content


def phase_b_backup() -> None:
    log(f"Phase B — backing up main.py → {BACKUP_PATH}")
    shutil.copy2(MAIN_PY, BACKUP_PATH)
    if not os.path.isfile(BACKUP_PATH):
        fail("Backup creation failed")
    log("Phase B — OK")


def phase_c_imports(content: str) -> str:
    log("Phase C — inserting F7 import block")
    new_content = content.replace(ANCHOR_F5_IMPORT_BLOCK_CLOSE,
                                  NEW_F5_PLUS_F7_IMPORTS, 1)
    if new_content == content:
        fail("Phase C: anchor replacement made no change")
    if new_content.count(MARKER) != 1:
        fail(f"Phase C: marker count = {new_content.count(MARKER)} (expected 1)")
    log("Phase C — OK")
    return new_content


def phase_d_models(content: str) -> str:
    log("Phase D — inserting F7 Pydantic input models")
    new_content = content.replace(ANCHOR_GARBHA_TO_COMPATIBILITY,
                                  NEW_GARBHA_PLUS_F7_PLUS_COMPATIBILITY, 1)
    if new_content == content:
        fail("Phase D: anchor replacement made no change")
    for cls in ("FamilyPatternsInput", "AncestralStrengthsInput",
                "LineageYogasInput", "KarakaInheritanceInput",
                "DashaLineageInput"):
        if f"class {cls}(BaseModel)" not in new_content:
            fail(f"Phase D: {cls} not inserted")
    log("Phase D — OK")
    return new_content


def phase_e_routes(content: str) -> str:
    log("Phase E — appending F7 routes to end of main.py")
    new_content = content + F7_ROUTES_APPEND
    for route in ("/astro/karma/family_patterns",
                  "/astro/karma/ancestral_strengths",
                  "/astro/karma/lineage_yogas",
                  "/astro/karma/karaka_inheritance",
                  "/astro/karma/dasha_lineage"):
        if route not in new_content:
            fail(f"Phase E: route {route} not present after append")
    log("Phase E — OK")
    return new_content


def phase_f_write_and_verify(new_content: str) -> None:
    log(f"Phase F — writing new main.py + snapshot → {SNAPSHOT_PATH}")
    with open(MAIN_PY, "w", encoding="utf-8") as f:
        f.write(new_content)
    shutil.copy2(MAIN_PY, SNAPSHOT_PATH)
    chown_to_trading(MAIN_PY)
    chown_to_trading(SNAPSHOT_PATH)
    chown_to_trading(BACKUP_PATH)
    log("Phase F — chown trading:trading applied")

    # F.1 — Syntax check
    log("Phase F.1 — syntax check on new main.py")
    try:
        run_as_trading_user(
            "import ast; ast.parse(open('/opt/astro/main.py').read())"
        )
    except subprocess.CalledProcessError:
        log("Syntax check FAILED — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        fail("Phase F.1: syntax error, rolled back")

    # F.2 — Layered smoke (ZERO top-level compound statements per F5 v1 lesson)
    # Assertions mirror production smoke EXACTLY (per F5 v2 lesson)
    log("Phase F.2 — layered smoke (import family_karma → run handlers → import main)")
    smoke = (
        "import family_karma; "
        # Module shape
        "assert hasattr(family_karma, 'handle_family_patterns'); "
        "assert hasattr(family_karma, 'handle_ancestral_strengths'); "
        "assert hasattr(family_karma, 'handle_lineage_yogas'); "
        "assert hasattr(family_karma, 'handle_karaka_inheritance'); "
        "assert hasattr(family_karma, 'handle_dasha_lineage'); "
        "assert len(family_karma.LINEAGE_YOGA_CATALOG) == 8; "
        "assert len(family_karma.KARAKA_ROLES) == 7; "
        # Birth dicts for test
        "self_b = {'dob':'1990-01-01','time':'10:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}; "
        "mom_b  = {'dob':'1965-03-15','time':'06:30','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}; "
        "dad_b  = {'dob':'1960-08-20','time':'14:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}; "
        # Endpoint 1: family_patterns
        "r1 = family_karma.handle_family_patterns(self_birth=self_b, mother_birth=mom_b, father_birth=dad_b); "
        "assert 'error' not in r1, f'family_patterns errored: {r1.get(\"error\")}'; "
        "assert 'self_analysis' in r1; "
        "assert 'parents_analysis' in r1; "
        "assert 'cross_generation_patterns' in r1; "
        "assert 'modules_status' in r1 and r1['modules_status']['pitra_dosha'] == True; "
        # Endpoint 2: ancestral_strengths
        "r2 = family_karma.handle_ancestral_strengths(self_birth=self_b, mother_birth=mom_b, father_birth=dad_b); "
        "assert 'error' not in r2, f'ancestral_strengths errored: {r2.get(\"error\")}'; "
        "assert 'fourth_house_mother' in r2; "
        "assert 'ninth_house_father' in r2; "
        "assert 'twelfth_house_ancestral_karma' in r2; "
        # Endpoint 3: lineage_yogas
        "r3 = family_karma.handle_lineage_yogas(self_birth=self_b, mother_birth=mom_b, father_birth=dad_b); "
        "assert 'error' not in r3, f'lineage_yogas errored: {r3.get(\"error\")}'; "
        "assert 'lineage_yogas_found' in r3; "
        "assert 'yoga_catalog_evaluated' in r3 and len(r3['yoga_catalog_evaluated']) == 8; "
        # Endpoint 4: karaka_inheritance
        "r4 = family_karma.handle_karaka_inheritance(self_birth=self_b, mother_birth=mom_b, father_birth=dad_b); "
        "assert 'error' not in r4, f'karaka_inheritance errored: {r4.get(\"error\")}'; "
        "assert 'karaka_inheritance_map' in r4; "
        "assert len(r4['karaka_inheritance_map']) == 7; "
        "assert 'classifications_summary' in r4; "
        # Endpoint 5: dasha_lineage
        "r5 = family_karma.handle_dasha_lineage(self_birth=self_b, mother_birth=mom_b, father_birth=dad_b, lookahead_years=20); "
        "assert 'error' not in r5, f'dasha_lineage errored: {r5.get(\"error\")}'; "
        "assert 'self_current_dasha' in r5; "
        "assert 'cross_generation_overlaps' in r5; "
        # Single-chart only call (no parents): family_patterns with self only
        "r6 = family_karma.handle_family_patterns(self_birth=self_b); "
        "assert 'error' not in r6, f'self-only errored: {r6.get(\"error\")}'; "
        "assert r6['parents_analysis']['mother']['provided'] == False; "
        # Disclaimer + citations on every response
        "assert 'disclaimer' in r1; "
        "assert 'disclaimer' in r2; "
        "assert 'disclaimer' in r3; "
        "assert 'disclaimer' in r4; "
        "assert 'disclaimer' in r5; "
        "assert 'classical_sources' in r1; "
        "assert 'classical_sources' in r2; "
        "assert 'classical_sources' in r3; "
        "assert 'classical_sources' in r4; "
        "assert 'classical_sources' in r5; "
        # NOW import main.py — the critical layered test
        "import main; "
        "print('Smoke: all 30+ assertions PASSED, main.py imports OK')"
    )
    try:
        run_as_trading_user(smoke)
    except subprocess.CalledProcessError:
        log("Smoke test FAILED — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        fail("Phase F.2: smoke test failed, rolled back")

    log("Phase F — OK (changes committed, snapshot saved)")


def main() -> None:
    print("=" * 72)
    print("patch_f7_family_karma.py — F7 Family Tree Karma installer")
    print(f"Timestamp: {TIMESTAMP}")
    print(f"Backup will go to:   {BACKUP_PATH}")
    print(f"Snapshot will go to: {SNAPSHOT_PATH}")
    print("Reuse-first: F7 imports pitra_dosha + karmic + children_education")
    print("=" * 72)

    content = phase_a_preflight()
    phase_b_backup()
    content = phase_c_imports(content)
    content = phase_d_models(content)
    content = phase_e_routes(content)
    phase_f_write_and_verify(content)

    print("=" * 72)
    print("F7 patch installation: SUCCESS")
    print("Next step: sudo systemctl restart astro && sleep 3")
    print("Expected: Total paths: 319 (was 314, +5)")
    print("=" * 72)


if __name__ == "__main__":
    main()
