#!/usr/bin/env python3
"""
patch_u10_hygiene_v2.py
─────────────────────────────────────────────────────────────────────────
U10 v2 — Hygiene Pass (2 fixes; Fix 3 DROPPED)

v2 CHANGES (vs v1):
    - Fix 3 (delete dead CompatibilityInput) is REMOVED. v1 misdiagnosed
      the line-490 class as dead. It is in fact load-bearing for the
      /astro/compatibility endpoint at line ~686 (definition order matters
      in Python: the endpoint sees line-490's class at parse time,
      regardless of the line-2419 redefinition that comes later).
    - Phase E smoke test now ALSO imports main.py itself. v1's smoke
      missed the crash because it imported every dependency EXCEPT the
      file being modified. Lesson learned, harness corrected.
    - Better failure attribution: if the main.py import fails, smoke
      shows the exact error from the failed import.

Scope:
  Fix 2 — rename ascendant_lord → lagna_lord in relationships.py
          (single-line; corrects F1a responses that returned null)
  Fix 1 — add /astro/nakshatra/compatibility_from_birth endpoint
          (new endpoint accepting BirthInput, calls existing
           analyze_compatibility() from nakshatra.py)

Phases:
  PHASE A — Fix 2 (relationships.py)
  PHASE B — Fix 1 (main.py — append new endpoint)
  PHASE C — Syntax check (both files)
  PHASE D — Snapshots
  PHASE E — Layered import smoke INCLUDING main.py

Idempotent. Auto-rollback on syntax error or smoke failure.

Usage:
  sudo python3 /opt/astro/patch_u10_hygiene_v2.py

Author: Claude (U10 v2, 2026-05-17)
"""

import os
import sys
import shutil
import subprocess
import py_compile
from datetime import datetime

MAIN_PY          = "/opt/astro/main.py"
RELATIONSHIPS_PY = "/opt/astro/relationships.py"

MARKER_FIX2 = "# ── U10 fix-2: lagna_lord rename ──"
MARKER_FIX1 = "# ── U10 fix-1: /astro/nakshatra/compatibility_from_birth ──"

# ═══════════════════════════════════════════════════════════════════════
# FIX 2 — rename in relationships.py
# ═══════════════════════════════════════════════════════════════════════
FIX2_OLD = '        "ascendant_lord":   essentials.get("ascendant_lord"),'
FIX2_NEW = ('        "lagna_lord":      essentials.get("lagna_lord"),'
            '  ' + MARKER_FIX2)

# ═══════════════════════════════════════════════════════════════════════
# FIX 1 — new endpoint appended at end of main.py
# ═══════════════════════════════════════════════════════════════════════
FIX1_BLOCK = '''


{MARKER_FIX1}
class NakshatraCompatFromBirthInput(BaseModel):
    person1: BirthInput
    person2: BirthInput


@app.post("/astro/nakshatra/compatibility_from_birth")
async def nakshatra_compatibility_from_birth(
    inp: NakshatraCompatFromBirthInput,
    _: str = Depends(verify_key),
):
    """
    BirthInput-shaped variant of /astro/nakshatra/compatibility.

    Casts both charts, extracts each native's Moon nakshatra, and runs
    the same 4-factor (Gana/Nadi/Yoni/Varna) classical analysis.
    Lets callers use the standard person1/person2 birth payload that
    every other compatibility endpoint accepts, instead of pre-computing
    nakshatra names.

    The original /astro/nakshatra/compatibility (with nak1/nak2 string
    inputs) remains available and unchanged.
    """
    try:
        from nakshatra import analyze_compatibility
        c1 = cast_chart(
            dob=inp.person1.dob, time=inp.person1.time,
            lat=inp.person1.lat, lon=inp.person1.lon,
            timezone=inp.person1.timezone,
        )
        c2 = cast_chart(
            dob=inp.person2.dob, time=inp.person2.time,
            lat=inp.person2.lat, lon=inp.person2.lon,
            timezone=inp.person2.timezone,
        )
        nak1 = c1["planets"]["Moon"].get("nakshatra")
        nak2 = c2["planets"]["Moon"].get("nakshatra")
        if not (nak1 and nak2):
            raise HTTPException(
                status_code=500,
                detail=(f"Could not extract Moon nakshatra from one or both "
                        f"charts (got: p1={nak1!r}, p2={nak2!r})"),
            )
        result = analyze_compatibility(nak1, nak2)
        return {
            "success": True,
            "person1_moon_nakshatra": nak1,
            "person2_moon_nakshatra": nak2,
            "data": result,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Nakshatra-from-birth compatibility failed: {e}",
        )
'''.replace("{MARKER_FIX1}", MARKER_FIX1)


def fail(msg, restore_pairs=None):
    print(f"\n❌ ERROR: {msg}")
    if restore_pairs:
        for backup, target in restore_pairs:
            if backup and os.path.exists(backup):
                shutil.copy2(backup, target)
                print(f"   🔄 Restored {target} from {backup}")
    sys.exit(1)


def syntax_check(path, restore_pairs=None):
    try:
        py_compile.compile(path, doraise=True)
        print(f"   ✅ Syntax OK: {path}")
    except py_compile.PyCompileError as e:
        fail(f"Syntax error in {path}: {e}", restore_pairs=restore_pairs)


def smoke_test_as_trading():
    """
    Layered smoke test as user `trading`.

    v2 IMPROVEMENT: includes `main` in the layers. The v1 harness
    imported every dependency but the file being modified, which let
    a NameError in main.py slip through. v2 imports main last (after
    its deps are verified) and surfaces the exact error if main fails.
    """
    smoke_script = """
import sys, traceback
sys.path.insert(0, '/opt/astro')
layers = [
    ('swisseph',      'swisseph'),
    ('dashaflow',     'dashaflow'),
    ('astro_helpers', 'astro_helpers'),
    ('compatibility', 'compatibility'),
    ('relationships', 'relationships'),
    ('nakshatra',     'nakshatra'),
    ('main',          'main'),    # ← v2: include main.py itself
]
for label, modname in layers:
    try:
        m = __import__(modname)
        print(f'OK    {label}')
    except Exception:
        print(f'FAIL  {label}')
        # Print full traceback for the failed layer
        traceback.print_exc()
        sys.exit(1)

# Verify specific symbols still resolvable
from relationships import handle_friendship, handle_mentor, handle_family
from nakshatra import analyze_compatibility
import main
# Confirm the FastAPI app has at least the pre-patch baseline routes
n_routes = len(main.app.routes)
print(f'OK    handlers + nakshatra.analyze_compatibility')
print(f'OK    main.app has {n_routes} routes registered')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_script] if is_root
           else ["python3", "-c", smoke_script])
    result = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.stderr.strip():
        print(f"   ── stderr ──")
        for line in result.stderr.strip().split("\n"):
            print(f"   {line}")
    return result.returncode == 0


def main():
    print("=" * 70)
    print("U10 v2 — Hygiene Pass (Fix 2 + Fix 1; Fix 3 dropped)")
    print("=" * 70)

    if not os.path.exists(MAIN_PY):
        fail(f"{MAIN_PY} not found")
    if not os.path.exists(RELATIONSHIPS_PY):
        fail(f"{RELATIONSHIPS_PY} not found")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    rel_backup  = None
    main_backup = None

    # ═══════════════════════════════════════════════════════════════
    # PHASE A — Fix 2 (relationships.py)
    # ═══════════════════════════════════════════════════════════════
    print("\n── Phase A: Fix 2 (rename ascendant_lord → lagna_lord) ──")
    with open(RELATIONSHIPS_PY, "r") as f:
        rel_content = f.read()

    if MARKER_FIX2 in rel_content:
        print("   ⏭️  Marker present — Fix 2 already applied, skipping")
    else:
        if FIX2_OLD not in rel_content:
            fail(f"Fix 2 anchor not found in relationships.py.\n"
                 f"   Expected line:\n   {FIX2_OLD}")
        rel_backup = f"{RELATIONSHIPS_PY}.before_u10v2_{ts}"
        shutil.copy2(RELATIONSHIPS_PY, rel_backup)
        print(f"   ✅ Backup: {rel_backup}")
        new_rel = rel_content.replace(FIX2_OLD, FIX2_NEW, 1)
        with open(RELATIONSHIPS_PY, "w") as f:
            f.write(new_rel)
        print(f"   ✅ Replaced ascendant_lord → lagna_lord")
        syntax_check(RELATIONSHIPS_PY,
                     restore_pairs=[(rel_backup, RELATIONSHIPS_PY)])

    # ═══════════════════════════════════════════════════════════════
    # PHASE B — Fix 1 (append new endpoint to main.py)
    # ═══════════════════════════════════════════════════════════════
    print("\n── Phase B: Fix 1 (append /astro/nakshatra/compatibility_from_birth) ──")
    with open(MAIN_PY, "r") as f:
        main_content = f.read()

    if MARKER_FIX1 in main_content:
        print("   ⏭️  Marker present — Fix 1 already applied, skipping")
    else:
        main_backup = f"{MAIN_PY}.before_u10v2_{ts}"
        shutil.copy2(MAIN_PY, main_backup)
        print(f"   ✅ Backup: {main_backup}")
        if not main_content.endswith("\n"):
            main_content += "\n"
        main_content += FIX1_BLOCK
        with open(MAIN_PY, "w") as f:
            f.write(main_content)
        print(f"   ✅ Appended new endpoint")

        # Syntax check (with auto-rollback of BOTH files if main fails)
        restore = [(main_backup, MAIN_PY)]
        if rel_backup:
            restore.append((rel_backup, RELATIONSHIPS_PY))
        syntax_check(MAIN_PY, restore_pairs=restore)

    # ═══════════════════════════════════════════════════════════════
    # PHASE C — Snapshot after-state
    # ═══════════════════════════════════════════════════════════════
    print("\n── Phase C: Snapshots after-state ──")
    if rel_backup:
        snap = f"{RELATIONSHIPS_PY}.after_u10v2_{ts}"
        shutil.copy2(RELATIONSHIPS_PY, snap)
        print(f"   ✅ {snap}")
    if main_backup:
        snap = f"{MAIN_PY}.after_u10v2_{ts}"
        shutil.copy2(MAIN_PY, snap)
        print(f"   ✅ {snap}")
    if not (rel_backup or main_backup):
        print("   ⏭️  No changes made; skipping snapshot")

    # ═══════════════════════════════════════════════════════════════
    # PHASE D — Smoke test INCLUDING main.py (v2 improvement)
    # ═══════════════════════════════════════════════════════════════
    print("\n── Phase D: Layered smoke (as user `trading`, INCLUDES main.py) ──")
    ok = smoke_test_as_trading()
    if not ok:
        restore = []
        if main_backup: restore.append((main_backup, MAIN_PY))
        if rel_backup:  restore.append((rel_backup, RELATIONSHIPS_PY))
        fail("Smoke test failed — see traceback above for failed layer",
             restore_pairs=restore)

    print("\n" + "=" * 70)
    print("U10 v2 PATCH APPLIED — next steps:")
    print("  sudo systemctl restart astro && sleep 3")
    print("  curl http://localhost:8001/astro/health     ← MUST return 200, not just check systemctl")
    print("  Then run verification sweep (see U10v2 runbook)")
    print("=" * 70)


if __name__ == "__main__":
    main()
