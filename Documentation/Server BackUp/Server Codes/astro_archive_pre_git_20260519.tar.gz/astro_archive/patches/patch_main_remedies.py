"""
patch_main_remedies.py — Adds 18 Master Remedies endpoints to /opt/astro/main.py

Same proven safe-insertion pattern (v2 style):
- Imports inserted right before `app = FastAPI(`
- Endpoints appended at end of file

Idempotent — skips if marker present.

Run from /opt/astro/ with sudo:
    sudo python3 patch_main_remedies.py
"""

import re
import sys
from pathlib import Path

MAIN_PY = Path("/opt/astro/main.py")
MARKER_START = "# ── MASTER REMEDIES MODULE (3a) ──"


IMPORT_BLOCK = """
# ── Master Remedies module (3a) imports ──
from remedies import (
    gemstones_for_chart,
    rudrakshas_for_chart,
    mantras_for_chart,
    yantras_for_chart,
    ishta_devata_for_chart,
    donations_for_chart,
    fasting_for_chart,
    color_therapy_for_chart,
    sound_therapy_for_chart,
    aromatherapy_for_chart,
    name_numerology,
    mobile_analysis,
    vehicle_analysis,
    signature_guidance,
    lucky_dates,
    remedies_for_chart,
    remedies_by_purpose,
    full_catalog as remedies_full_catalog,
)

"""


ENDPOINT_BLOCK = '''
# ══════════════════════════════════════════════════════════════════════
# ── MASTER REMEDIES MODULE (3a) ──
# 18 endpoints — Vedic + Therapeutic + Numerology + Master
# Sources: Brihat Samhita, BPHS, Garuda Purana, Atharva Veda, Cheiro
# ══════════════════════════════════════════════════════════════════════

class RemedyNameInput(BaseModel):
    name: str
    dob: str            # YYYY-MM-DD


class RemedyMobileInput(BaseModel):
    mobile: str
    dob: str


class RemedyVehicleInput(BaseModel):
    registration: str
    dob: str


class RemedyDobOnlyInput(BaseModel):
    dob: str


class RemedyChartWithNameInput(BaseModel):
    dob: str
    time: str
    lat: float
    lon: float
    timezone: Optional[str] = "Asia/Kolkata"
    name: Optional[str] = None


class RemedyPurposeInput(BaseModel):
    purpose: str
    dob: str
    time: str
    lat: float
    lon: float
    timezone: Optional[str] = "Asia/Kolkata"


# ── Master endpoints (3) ──

@app.post("/astro/remedies/for_chart")
def remedies_master_for_chart(inp: RemedyChartWithNameInput, _: str = Depends(verify_key)):
    """MASTER — full personalized remedies (Vedic + Therapeutic + Numerology) for a chart."""
    return remedies_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata", name=inp.name,
    )


@app.post("/astro/remedies/by_purpose")
def remedies_master_by_purpose(inp: RemedyPurposeInput, _: str = Depends(verify_key)):
    """Filter remedies by life-area: wealth_and_prosperity, health_and_longevity, career_and_authority, relationship_and_marriage, education_and_intelligence, spirituality_and_moksha, obstacle_removal, protection_from_negativity, saturn_sade_sati_relief."""
    return remedies_by_purpose(
        purpose=inp.purpose, dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.get("/astro/remedies/full_catalog")
def remedies_master_full_catalog(_: str = Depends(verify_key)):
    """Return complete catalog (all 4 JSONs) for inspection/export."""
    return remedies_full_catalog()


# ── Vedic endpoints (7) ──

@app.post("/astro/remedies/vedic/gemstones")
def remedies_vedic_gemstones(inp: BirthInput, _: str = Depends(verify_key)):
    """Gemstones for chart — filtered by classical safety rules (no 6/8/12 lords)."""
    return gemstones_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/vedic/rudrakshas")
def remedies_vedic_rudrakshas(inp: BirthInput, _: str = Depends(verify_key)):
    """Rudrakshas for chart — based on afflicted planets."""
    return rudrakshas_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/vedic/mantras")
def remedies_vedic_mantras(inp: BirthInput, _: str = Depends(verify_key)):
    """Mantras for weakest planet + all afflicted planets."""
    return mantras_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/vedic/yantras")
def remedies_vedic_yantras(inp: BirthInput, _: str = Depends(verify_key)):
    """Yantras — afflicted planet specific + universal home yantras."""
    return yantras_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/vedic/ishta_devata")
def remedies_vedic_ishta_devata(inp: BirthInput, _: str = Depends(verify_key)):
    """Determine personal deity from Atmakaraka + 12th lord."""
    return ishta_devata_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/vedic/donations")
def remedies_vedic_donations(inp: BirthInput, _: str = Depends(verify_key)):
    """Donations for afflicted planets — items, recipients, day."""
    return donations_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/vedic/fasting")
def remedies_vedic_fasting(inp: BirthInput, _: str = Depends(verify_key)):
    """Fasting for weakest planet — vrat name, rules."""
    return fasting_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


# ── Therapeutic endpoints (3) ──

@app.post("/astro/remedies/therapeutic/colors")
def remedies_therapeutic_colors(inp: BirthInput, _: str = Depends(verify_key)):
    """Color therapy — strengthen weakest, avoid 6/8/12 lord colors."""
    return color_therapy_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/therapeutic/sound")
def remedies_therapeutic_sound(inp: BirthInput, _: str = Depends(verify_key)):
    """Sound/raga/frequency therapy for weakest planet."""
    return sound_therapy_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/remedies/therapeutic/aromatherapy")
def remedies_therapeutic_aroma(inp: BirthInput, _: str = Depends(verify_key)):
    """Aromatherapy — essential oils, incense per planet."""
    return aromatherapy_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


# ── Numerology endpoints (5) ──

@app.post("/astro/remedies/numerology/name")
def remedies_numerology_name(inp: RemedyNameInput, _: str = Depends(verify_key)):
    """Chaldean name numerology — compatibility with Driver/Conductor."""
    return name_numerology(name=inp.name, dob=inp.dob)


@app.post("/astro/remedies/numerology/mobile")
def remedies_numerology_mobile(inp: RemedyMobileInput, _: str = Depends(verify_key)):
    """Mobile number analysis — digit sum, compatibility, recommendations."""
    return mobile_analysis(mobile=inp.mobile, dob=inp.dob)


@app.post("/astro/remedies/numerology/vehicle")
def remedies_numerology_vehicle(inp: RemedyVehicleInput, _: str = Depends(verify_key)):
    """Vehicle registration analysis — safety and resale guidance."""
    return vehicle_analysis(registration=inp.registration, dob=inp.dob)


@app.post("/astro/remedies/numerology/signature")
def remedies_numerology_signature(inp: RemedyDobOnlyInput, _: str = Depends(verify_key)):
    """Signature principles + planet-specific pen recommendation."""
    return signature_guidance(dob=inp.dob)


@app.post("/astro/remedies/numerology/lucky_dates")
def remedies_numerology_lucky_dates(inp: RemedyDobOnlyInput, _: str = Depends(verify_key)):
    """Lucky dates of month based on Driver + universal Indian dates."""
    return lucky_dates(dob=inp.dob)

# ── END MASTER REMEDIES MODULE (3a) ──
'''


def main():
    if not MAIN_PY.exists():
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    content = MAIN_PY.read_text()

    if MARKER_START in content:
        print(f"⏭️  Master Remedies module already patched. Skipping.")
        return

    if "from fastapi import" not in content:
        print("ERROR: main.py doesn't look like a FastAPI app")
        sys.exit(1)
    if "verify_key" not in content:
        print("ERROR: verify_key not defined")
        sys.exit(1)
    if "BirthInput" not in content:
        print("ERROR: BirthInput model not defined")
        sys.exit(1)

    # Safe insertion right before `app = FastAPI(`
    pat = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = pat.search(content)
    if not match:
        print("ERROR: 'app = FastAPI(' not found")
        sys.exit(1)

    insertion_point = match.start()
    if insertion_point > 0 and content[insertion_point - 1] != '\n':
        print(f"ERROR: 'app = FastAPI(' not at start of line")
        sys.exit(1)

    new_content = (
        content[:insertion_point]
        + IMPORT_BLOCK
        + content[insertion_point:]
    )
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    MAIN_PY.write_text(new_content)
    print(f"✅ Patched {MAIN_PY}")
    print(f"   Added: 18 Master Remedies (3a) endpoints")
    print(f"   Marker: {MARKER_START}")
    print(f"   File size: {len(new_content)} bytes (was {len(content)})")

    print("\n🔍 Verifying syntax...")
    import py_compile
    try:
        py_compile.compile(str(MAIN_PY), doraise=True)
        print("✅ Syntax OK — ready to restart astro service")
    except py_compile.PyCompileError as e:
        print(f"❌ SYNTAX ERROR: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
