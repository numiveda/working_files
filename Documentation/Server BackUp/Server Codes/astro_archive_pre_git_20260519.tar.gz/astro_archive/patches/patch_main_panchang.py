"""
patch_main_panchang.py — Wires 6 Panchang (C4) endpoints into main.py.

Uses verify_key auth pattern. Idempotent.

Run from /opt/astro:
    sudo python3 patch_main_panchang.py
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── PANCHANG C4 MODULE ──"


IMPORT_BLOCK = '''
# ── PANCHANG C4 MODULE IMPORTS ──
from panchang import (
    handle_full       as panchang_handle_full,
    handle_tithi      as panchang_handle_tithi,
    handle_nakshatra  as panchang_handle_nakshatra,
    handle_yoga       as panchang_handle_yoga,
    handle_karana     as panchang_handle_karana,
    handle_rahu_kalam as panchang_handle_rahu_kalam,
)
# ── END PANCHANG C4 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── PANCHANG C4 MODULE ──
# Phase C — Module C4 — Daily Panchang (6 endpoints)
# Sources: BPHS Ch. 99 (Panchang Adhyaya), classical calendar tradition
# Note: Phase A has /astro/panchang endpoint already (legacy);
#       C4 namespace uses /astro/panchang/* sub-paths (no collision)
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _PanchangBaseModel
from typing import Optional as _PanchangOptional


class PanchangInput(_PanchangBaseModel):
    date: str             # YYYY-MM-DD
    lat: float
    lon: float
    timezone: _PanchangOptional[str] = "Asia/Kolkata"


@app.post("/astro/panchang/full")
def panchang_full_ep(inp: PanchangInput, _: str = Depends(verify_key)):
    """Full Panchang — all 5 limbs + Rahu Kaal/Yama Gandam/Gulika Kalam time bands."""
    return panchang_handle_full(inp.date, inp.lat, inp.lon, inp.timezone or "Asia/Kolkata")


@app.post("/astro/panchang/tithi")
def panchang_tithi_ep(inp: PanchangInput, _: str = Depends(verify_key)):
    """Tithi only (lunar day, name, paksha)."""
    return panchang_handle_tithi(inp.date, inp.lat, inp.lon, inp.timezone or "Asia/Kolkata")


@app.post("/astro/panchang/nakshatra")
def panchang_nakshatra_ep(inp: PanchangInput, _: str = Depends(verify_key)):
    """Nakshatra of the Moon for the date + ruling planet."""
    return panchang_handle_nakshatra(inp.date, inp.lat, inp.lon, inp.timezone or "Asia/Kolkata")


@app.post("/astro/panchang/yoga")
def panchang_yoga_ep(inp: PanchangInput, _: str = Depends(verify_key)):
    """Yoga (Sun+Moon longitude segment) + favorability classification."""
    return panchang_handle_yoga(inp.date, inp.lat, inp.lon, inp.timezone or "Asia/Kolkata")


@app.post("/astro/panchang/karana")
def panchang_karana_ep(inp: PanchangInput, _: str = Depends(verify_key)):
    """Karana (half-tithi) + Bhadra warning flag."""
    return panchang_handle_karana(inp.date, inp.lat, inp.lon, inp.timezone or "Asia/Kolkata")


@app.post("/astro/panchang/rahu_kalam")
def panchang_rahu_kalam_ep(inp: PanchangInput, _: str = Depends(verify_key)):
    """Rahu Kalam + Yama Gandam + Gulika Kalam time bands (NOAA sunrise/sunset)."""
    return panchang_handle_rahu_kalam(inp.date, inp.lat, inp.lon, inp.timezone or "Asia/Kolkata")

# ── END PANCHANG C4 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present in main.py.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_panchang_c4_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_panchang_c4_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ Panchang C4 module patched into main.py")
    print("   6 endpoints under /astro/panchang/*")


if __name__ == "__main__":
    main()
