"""
patch_main_prashna.py — Adds 10 Prashna (Horary) endpoints (Module B3)

NEW: PrashnaInput Pydantic model for question-moment inputs.

Same proven safe-insertion pattern.
Marker: # ── PRASHNA MODULE (B3) ──

Run: sudo python3 patch_main_prashna.py
"""

import re
import sys
from pathlib import Path

MAIN_PY = Path("/opt/astro/main.py")
MARKER_START = "# ── PRASHNA MODULE (B3) ──"


IMPORT_BLOCK = """
# ── Prashna module (B3) imports ──
from prashna import (
    full_prashna_profile,
    lagna_analysis_endpoint as prashna_lagna,
    moon_analysis_endpoint as prashna_moon,
    significator_endpoint as prashna_significator,
    timing_endpoint as prashna_timing,
    yes_no_endpoint as prashna_yes_no,
    kp_horary_endpoint as prashna_kp,
    aroodha_lagna_endpoint as prashna_aroodha,
    swara_endpoint as prashna_swara,
    specific_query_endpoint as prashna_specific,
)

"""


ENDPOINT_BLOCK = '''
# ══════════════════════════════════════════════════════════════════════
# ── PRASHNA MODULE (B3) ──
# 10 endpoints — Prashna (Horary) astrology
# Sources: Tajik Neelakanthi, Prashna Marga, KP methodology,
#          Brihat Samhita commentary, Daivagya Vallabha
# ══════════════════════════════════════════════════════════════════════

class PrashnaInput(BaseModel):
    """Input schema for Prashna (horary) endpoints.

    Question is cast at the moment it is asked — NOT birth time.
    """
    question_datetime: str        # ISO format e.g. "2026-05-16T11:30:00"
    question_lat: float
    question_lon: float
    question_timezone: Optional[str] = "Asia/Kolkata"
    question_category: Optional[str] = "general"  # marriage, career, health, travel, finance, missing_item, legal_matter, general
    question_text: Optional[str] = None


@app.post("/astro/prashna/profile")
def prashna_profile_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Master Prashna profile — complete horary chart analysis."""
    return full_prashna_profile(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        timezone=inp.question_timezone or "Asia/Kolkata",
        category=inp.question_category or "general",
        question_text=inp.question_text,
    )


@app.post("/astro/prashna/lagna_analysis")
def prashna_lagna_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Lagna at moment of question + signature interpretation."""
    return prashna_lagna(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/moon_analysis")
def prashna_moon_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Moon's role in answering the question (Chandra Lagna analysis)."""
    return prashna_moon(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/significator")
def prashna_significator_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Karaka identification for the question category."""
    return prashna_significator(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        category=inp.question_category or "general",
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/timing")
def prashna_timing_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """When the matter will resolve."""
    return prashna_timing(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        category=inp.question_category or "general",
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/yes_no")
def prashna_yes_no_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Binary YES/NO answer — multi-method synthesis (classical + KP)."""
    return prashna_yes_no(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        category=inp.question_category or "general",
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/kp_horary")
def prashna_kp_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """KP horary — Ruling Planets + cuspal sub-lord framework."""
    return prashna_kp(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        category=inp.question_category or "general",
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/aroodha_lagna")
def prashna_aroodha_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Aroodha Lagna (Jaimini horary technique) — public manifestation indicator."""
    return prashna_aroodha(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/swara")
def prashna_swara_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Swara (breath/nostril) analysis rules at moment of question."""
    return prashna_swara(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        timezone=inp.question_timezone or "Asia/Kolkata",
    )


@app.post("/astro/prashna/specific_query")
def prashna_specific_ep(inp: PrashnaInput, _: str = Depends(verify_key)):
    """Category-templated reading combining all techniques."""
    return prashna_specific(
        question_datetime=inp.question_datetime,
        lat=inp.question_lat, lon=inp.question_lon,
        category=inp.question_category or "general",
        timezone=inp.question_timezone or "Asia/Kolkata",
        question_text=inp.question_text,
    )

# ── END PRASHNA MODULE (B3) ──
'''


def main():
    if not MAIN_PY.exists():
        print(f"ERROR: {MAIN_PY} not found"); sys.exit(1)

    content = MAIN_PY.read_text()

    if MARKER_START in content:
        print(f"⏭️  Prashna module already patched. Skipping.")
        return

    if "from fastapi import" not in content:
        print("ERROR: main.py doesn't look like a FastAPI app"); sys.exit(1)
    if "verify_key" not in content:
        print("ERROR: verify_key not defined"); sys.exit(1)
    if "class BirthInput" not in content and "BirthInput" not in content:
        print("ERROR: BirthInput model not defined"); sys.exit(1)

    pat = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = pat.search(content)
    if not match:
        print("ERROR: 'app = FastAPI(' not found"); sys.exit(1)

    insertion_point = match.start()
    if insertion_point > 0 and content[insertion_point - 1] != '\n':
        print(f"ERROR: 'app = FastAPI(' not at start of line"); sys.exit(1)

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    MAIN_PY.write_text(new_content)
    print(f"✅ Patched {MAIN_PY}")
    print(f"   Added: 10 Prashna (B3) endpoints + PrashnaInput schema")
    print(f"   Marker: {MARKER_START}")
    print(f"   File size: {len(new_content)} bytes (was {len(content)})")

    print("\n🔍 Verifying syntax...")
    import py_compile
    try:
        py_compile.compile(str(MAIN_PY), doraise=True)
        print("✅ Syntax OK — ready to restart astro service")
    except py_compile.PyCompileError as e:
        print(f"❌ SYNTAX ERROR: {e}"); sys.exit(1)


if __name__ == "__main__":
    main()
