"""
patch_b1_vikriti_v2.py — Round 4 of post-Phase-D cleanup. THE BIG ONE.

PURPOSE:
    B1 _vikriti_current() previously used ONLY MD+AD dosha lords + natal
    afflictions. The endpoint name and docstring promised "current dosha
    imbalance" but the implementation ignored:
        - Real-time planetary transits (Sun/Mars/Saturn/Moon TODAY)
        - Current Ritu (Vedic season) per Charaka Samhita
        - Age-bracket dominant dosha (Bala/Madhya/Vriddha)
        - Today's lunar state (waxing kapha-builder vs waning vata-stirrer)

    This patch replaces _vikriti_current() with a composite synthesis
    incorporating all 5 components, properly cited per classical Ayurveda
    + Jyotish sources.

CLASSICAL SOURCES:
    - Charaka Samhita Vimana Sthana Ch.8 (Vikriti analysis)
    - Charaka Samhita Sutra Sthana Ch.6 (Ritucharya)
    - Sushruta Samhita Sutra Sthana Ch.6 (Seasonal regimen)
    - Sarvartha Chintamani Ch.15 (Jyotish health analysis)
    - Phaladeepika Ch.6 (Dosha through planetary lords)

WHAT CHANGES:
    1. /opt/astro/health.py:
       - Adds imports for swisseph + datetime + zoneinfo
       - Adds SIGN_TO_RITU lookup (12 signs → 6 Ritus with dosha mapping)
       - Adds AGE_BRACKET_DOSHA lookup
       - Adds _compute_current_transits() helper using swisseph
       - Adds _compute_current_ritu() helper
       - Adds _compute_age_bracket() helper
       - Adds _compute_lunar_state() helper
       - Replaces _vikriti_current(ch) with _vikriti_current(ch, birth)
         where `birth` provides DOB for age computation
       - Updates the endpoint wrapper (vikriti_endpoint) to pass birth dict
    2. No changes to main.py — endpoint signature unchanged at API level

RESPONSE SHAPE CHANGES:
    Old: 7 keys, dasha-only
    New: 12+ keys including current_transits, current_ritu, age_bracket,
         lunar_state, composite_vikriti_emphasis, classical_synthesis

EFFORT: ~90 minutes (largest enhancement in the cleanup pass).

Run from /opt/astro:
    sudo python3 patch_b1_vikriti_v2.py

Idempotent: marker check prevents double-application.
"""

import re
import sys
import os
import shutil
from datetime import datetime

HEALTH_PY = "/opt/astro/health.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── B1 VIKRITI v2 (Round 4) ──"


# ════════════════════════════════════════════════════════════════════════
# NEW HELPERS + REPLACED FUNCTION + UPDATED ENDPOINT WRAPPER
# ════════════════════════════════════════════════════════════════════════

NEW_BLOCK = '''# ── B1 VIKRITI v2 (Round 4) ──
# Composite Vikriti synthesis: dasha + transits + Ritu + age + lunar state.
# Classical: Charaka Vimana Ch.8; Sutra Ch.6 (Ritucharya); Phaladeepika Ch.6;
#            Sarvartha Chintamani Ch.15 (Jyotish health analysis).

import swisseph as _swe
from datetime import datetime as _dt, timezone as _tz, date as _date
from zoneinfo import ZoneInfo as _ZoneInfo


# ── Classical Ritu → dosha mapping (Charaka Samhita Sutra Ch.6) ──
# Each sidereal sign maps to one of 6 Ritus. Each Ritu has classical
# accumulating/vitiating doshas based on environmental conditions.
_SIGNS_ORDER_VIKRITI = ["Aries","Taurus","Gemini","Cancer","Leo","Virgo",
                        "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"]

_SIGN_TO_RITU = {
    # (Ritu Sanskrit, season English, [vitiated doshas], classical note)
    0:  ("Vasanta",  "spring",     ["kapha"],          "Kapha accumulated in winter vitiates; energy of growth"),
    1:  ("Vasanta",  "spring",     ["kapha"],          "Kapha accumulated in winter vitiates; energy of growth"),
    2:  ("Grishma",  "summer",     ["vata"],           "Vata accumulates from heat-depleted body fluids; bodily strength wanes"),
    3:  ("Grishma",  "summer",     ["vata"],           "Vata accumulates from heat-depleted body fluids; bodily strength wanes"),
    4:  ("Varsha",   "monsoon",    ["pitta", "vata"],  "Pitta accumulates from monsoon dampness; vata vitiated by chill"),
    5:  ("Varsha",   "monsoon",    ["pitta", "vata"],  "Pitta accumulates from monsoon dampness; vata vitiated by chill"),
    6:  ("Sharad",   "autumn",     ["pitta"],          "Pitta vitiates strongly after monsoon — peak pitta season"),
    7:  ("Sharad",   "autumn",     ["pitta"],          "Pitta vitiates strongly after monsoon — peak pitta season"),
    8:  ("Hemanta",  "pre-winter", ["kapha"],          "Kapha accumulates from cold/heavy foods; strength returns"),
    9:  ("Hemanta",  "pre-winter", ["kapha"],          "Kapha accumulates from cold/heavy foods; strength returns"),
    10: ("Shishira", "winter",     ["kapha", "vata"],  "Kapha peaks; vata accumulates from dryness and cold"),
    11: ("Shishira", "winter",     ["kapha", "vata"],  "Kapha peaks; vata accumulates from dryness and cold"),
}


# ── Age-bracket dominant dosha (Charaka Vimana Ch.8) ──
def _compute_age_bracket(dob: str) -> Dict:
    """Bala (childhood = kapha), Madhya (middle = pitta), Vriddha (old = vata)."""
    try:
        y, m, d = map(int, dob.split("-"))
        birth = _date(y, m, d)
        today = _date.today()
        age = (today - birth).days / 365.25
    except Exception:
        return {"bracket": None, "age_years": None, "dominant_dosha": None,
                "note": "DOB unparseable"}

    if age < 16:
        bracket, dom = "Bala", "kapha"
        note = "Bala (childhood, <16 yrs) — kapha-dominant phase; growth, accumulation"
    elif age < 60:
        bracket, dom = "Madhya", "pitta"
        note = "Madhya (middle, 16-60 yrs) — pitta-dominant phase; transformation, work, achievement"
    else:
        bracket, dom = "Vriddha", "vata"
        note = "Vriddha (elder, 60+ yrs) — vata-dominant phase; deterioration, dryness, depletion"

    return {
        "bracket":        bracket,
        "age_years":      round(age, 1),
        "dominant_dosha": dom,
        "classical_note": note,
        "citation":       "Charaka Samhita Vimana Sthana Ch.8",
    }


# ── Current transits via swisseph (sidereal Lahiri to match engine) ──
def _compute_current_transits() -> Dict:
    """Compute current sidereal Lahiri positions of Sun, Moon, Mars, Saturn."""
    _swe.set_sid_mode(_swe.SIDM_LAHIRI)
    now = _dt.now(_tz.utc)
    jd = _swe.julday(now.year, now.month, now.day, now.hour + now.minute / 60.0)

    planet_ids = {"Sun": _swe.SUN, "Moon": _swe.MOON, "Mars": _swe.MARS,
                  "Saturn": _swe.SATURN}
    transits = {}
    for name, pid in planet_ids.items():
        pos, _ = _swe.calc_ut(jd, pid, _swe.FLG_SIDEREAL | _swe.FLG_SPEED)
        lon = pos[0]
        sign_idx = int(lon // 30)
        transits[name] = {
            "sign":             _SIGNS_ORDER_VIKRITI[sign_idx],
            "degree_in_sign":   round(lon % 30, 2),
            "longitude":        round(lon, 4),
            "is_retrograde":    pos[3] < 0,
            "daily_speed":      round(pos[3], 4),
        }

    return {
        "computed_at":    now.strftime("%Y-%m-%d %H:%M UTC"),
        "ayanamsha":      "Lahiri",
        "positions":      transits,
    }


# ── Current Ritu (Vedic season) from Sun's sidereal position ──
def _compute_current_ritu(transits: Dict) -> Dict:
    """Map Sun's sidereal sign to one of 6 Ritus per Charaka Samhita."""
    sun = transits.get("positions", {}).get("Sun", {})
    sun_sign = sun.get("sign")
    if not sun_sign or sun_sign not in _SIGNS_ORDER_VIKRITI:
        return {"name": None, "season": None, "vitiated_doshas": [], "note": "Sun position unavailable"}

    sign_idx = _SIGNS_ORDER_VIKRITI.index(sun_sign)
    ritu_name, season, doshas, note = _SIGN_TO_RITU[sign_idx]

    return {
        "name":             ritu_name,
        "season":           season,
        "sun_sign":         sun_sign,
        "vitiated_doshas":  doshas,
        "classical_note":   note,
        "citation":         "Charaka Samhita Sutra Sthana Ch.6 (Ritucharya); Sushruta Samhita Sutra Ch.6",
    }


# ── Lunar state (waxing/waning) — affects daily dosha balance ──
def _compute_lunar_state(transits: Dict) -> Dict:
    """Moon's relationship to Sun determines waxing (kapha-building) or waning (vata-stirring)."""
    sun = transits.get("positions", {}).get("Sun", {})
    moon = transits.get("positions", {}).get("Moon", {})
    if not sun or not moon:
        return {"phase": None, "note": "Sun/Moon positions unavailable"}

    sun_lon = sun.get("longitude", 0)
    moon_lon = moon.get("longitude", 0)

    # Tithi calculation: (Moon longitude - Sun longitude) / 12, mod 30
    diff = (moon_lon - sun_lon) % 360
    tithi_num = int(diff // 12) + 1  # 1 to 30
    is_waxing = tithi_num <= 15  # Shukla paksha (waxing) = 1-15, Krishna paksha (waning) = 16-30

    if is_waxing:
        phase = "Shukla Paksha (waxing)"
        dosha_effect = ["kapha"]
        note = "Waxing Moon builds kapha (anabolic, nourishing). Body retains, accumulates."
    else:
        phase = "Krishna Paksha (waning)"
        dosha_effect = ["vata"]
        note = "Waning Moon stirs vata (catabolic, depleting). Body releases, dries."

    # Tithi-specific names for first/last days
    if tithi_num == 15:
        tithi_label = "Purnima (Full Moon) — peak kapha"
    elif tithi_num == 30:
        tithi_label = "Amavasya (New Moon) — peak vata"
    elif tithi_num == 1:
        tithi_label = "Pratipada (just past Amavasya)"
    else:
        tithi_label = f"Tithi {tithi_num}"

    return {
        "phase":            phase,
        "tithi_num":        tithi_num,
        "tithi_label":      tithi_label,
        "dosha_effect":     dosha_effect,
        "classical_note":   note,
        "citation":         "Brihat Samhita Ch.4-5 (lunar effects on dosha); Charaka Sutra Ch.6",
    }


# ── Transit dosha analysis: where are Sun/Mars/Saturn/Moon now? ──
def _analyze_transit_doshas(transits: Dict) -> Dict:
    """Map current transit planets to their dosha contributions."""
    positions = transits.get("positions", {})

    contributions = []
    if positions.get("Sun"):
        contributions.append({
            "planet": "Sun", "in_sign": positions["Sun"]["sign"],
            "dosha":  ["pitta"],
            "note":   "Sun transit contributes pitta heat; emphasizes pitta in current sign",
        })
    if positions.get("Mars"):
        contributions.append({
            "planet": "Mars", "in_sign": positions["Mars"]["sign"],
            "dosha":  ["pitta"],
            "is_retrograde": positions["Mars"].get("is_retrograde", False),
            "note":   "Mars transit aggravates pitta; retrograde Mars intensifies inflammation",
        })
    if positions.get("Saturn"):
        contributions.append({
            "planet": "Saturn", "in_sign": positions["Saturn"]["sign"],
            "dosha":  ["vata"],
            "is_retrograde": positions["Saturn"].get("is_retrograde", False),
            "note":   "Saturn transit aggravates vata; brings dryness, stiffness, depletion",
        })
    if positions.get("Moon"):
        contributions.append({
            "planet": "Moon", "in_sign": positions["Moon"]["sign"],
            "dosha":  ["vata", "kapha"],
            "note":   "Moon transit modulates vata-kapha; rapid sign change every ~2.25 days",
        })

    # Aggregate vitiated doshas
    aggregate = set()
    for c in contributions:
        for d in c.get("dosha", []):
            aggregate.add(d)

    return {
        "planet_contributions":  contributions,
        "aggregate_doshas":      sorted(aggregate),
        "citation":              "Sarvartha Chintamani Ch.15 (transit health analysis); Phaladeepika Ch.6 (planetary dosha lords)",
    }


def _vikriti_current(ch: Dict, birth: Dict = None) -> Dict:
    """
    Composite Vikriti synthesis — Charaka + Jyotish tradition.

    Components:
        1. Dasha-period dosha (MD + AD lords' doshas)
        2. Current transit dosha (Sun/Mars/Saturn/Moon NOW via swisseph)
        3. Ritu (Vedic season) dosha emphasis
        4. Age-bracket dominant dosha (Bala/Madhya/Vriddha)
        5. Today's lunar state (waxing kapha vs waning vata)

    Returns composite analysis with each component cited per classical source.
    """
    # ── Component 1: Dasha-period dosha (existing logic, preserved) ──
    md = ch.get("current_md")
    ad = ch.get("current_ad")
    md_dosha = PLANET_TO_DOSHA.get(md, []) if md else []
    ad_dosha = PLANET_TO_DOSHA.get(ad, []) if ad else []
    dasha_emphasis = sorted(set(md_dosha + ad_dosha))

    # ── Component 2: Natal afflictions (existing logic, preserved) ──
    afflicted = afflicted_planets(ch)
    afflicted_doshas = sorted(set(
        d for ap in afflicted for d in PLANET_TO_DOSHA.get(ap["planet"], [])
    ))

    # ── Component 3: Current transits (NEW) ──
    transits = _compute_current_transits()
    transit_analysis = _analyze_transit_doshas(transits)
    transit_doshas = transit_analysis["aggregate_doshas"]

    # ── Component 4: Ritu (NEW) ──
    ritu = _compute_current_ritu(transits)
    ritu_doshas = ritu.get("vitiated_doshas", [])

    # ── Component 5: Age bracket (NEW) ──
    age = _compute_age_bracket(birth.get("dob")) if birth and birth.get("dob") else \
          {"bracket": None, "dominant_dosha": None, "note": "Birth DOB not provided"}

    # ── Component 6: Lunar state (NEW) ──
    lunar = _compute_lunar_state(transits)
    lunar_doshas = lunar.get("dosha_effect", [])

    # ── Composite synthesis ──
    # Count dosha occurrences across all 5 streams + natal affliction
    all_streams = []
    if dasha_emphasis:           all_streams.extend([("dasha", d) for d in dasha_emphasis])
    if transit_doshas:           all_streams.extend([("transit", d) for d in transit_doshas])
    if ritu_doshas:              all_streams.extend([("ritu", d) for d in ritu_doshas])
    if age.get("dominant_dosha"):all_streams.append(("age", age["dominant_dosha"]))
    if lunar_doshas:             all_streams.extend([("lunar", d) for d in lunar_doshas])
    if afflicted_doshas:         all_streams.extend([("affliction", d) for d in afflicted_doshas])

    dosha_score = {"vata": 0, "pitta": 0, "kapha": 0}
    dosha_sources = {"vata": [], "pitta": [], "kapha": []}
    for source, d in all_streams:
        if d in dosha_score:
            dosha_score[d] += 1
            dosha_sources[d].append(source)

    # Determine dominant + secondary
    sorted_doshas = sorted(dosha_score.items(), key=lambda x: -x[1])
    dominant_dosha = sorted_doshas[0][0] if sorted_doshas[0][1] > 0 else None
    secondary_dosha = sorted_doshas[1][0] if len(sorted_doshas) > 1 and sorted_doshas[1][1] > 0 else None

    # Build interpretive paragraph
    interpretation_parts = []
    if dominant_dosha:
        srcs = ", ".join(sorted(set(dosha_sources[dominant_dosha])))
        interpretation_parts.append(
            f"Composite Vikriti shows {dominant_dosha.upper()} dominance "
            f"(score {dosha_score[dominant_dosha]}, sources: {srcs})."
        )
    if secondary_dosha:
        srcs = ", ".join(sorted(set(dosha_sources[secondary_dosha])))
        interpretation_parts.append(
            f"Secondary emphasis: {secondary_dosha} (score {dosha_score[secondary_dosha]}, sources: {srcs})."
        )
    if ritu.get("name"):
        interpretation_parts.append(
            f"Current Ritu is {ritu['name']} ({ritu['season']}) — classically vitiates {', '.join(ritu['vitiated_doshas'])}."
        )
    if age.get("bracket"):
        interpretation_parts.append(
            f"Age-bracket: {age['bracket']} — life-phase emphasizes {age['dominant_dosha']}."
        )
    if lunar.get("tithi_label"):
        interpretation_parts.append(
            f"Lunar phase: {lunar['tithi_label']} ({lunar['phase']}) — stirs {', '.join(lunar['dosha_effect'])}."
        )
    interpretation_parts.append(
        "Recommended: counter the dominant dosha through diet/lifestyle aligned with classical Charaka regimens for this Ritu and age-bracket."
    )

    return {
        # ── Composite synthesis (NEW — top of response for LLM clarity) ──
        "composite_vikriti": {
            "dominant_dosha":     dominant_dosha,
            "secondary_dosha":    secondary_dosha,
            "dosha_scores":       dosha_score,
            "dosha_sources":      dosha_sources,
            "interpretation":     " ".join(interpretation_parts),
        },

        # ── 5 component analyses (NEW) ──
        "dasha_component": {
            "current_md":      md,
            "current_md_dosha":md_dosha,
            "current_ad":      ad,
            "current_ad_dosha":ad_dosha,
            "emphasis":        dasha_emphasis,
            "citation":        "Vimshottari Dasha tradition (BPHS); Phaladeepika Ch.6",
        },
        "transit_component": {
            "transits":        transits,
            "analysis":        transit_analysis,
        },
        "ritu_component":     ritu,
        "age_component":      age,
        "lunar_component":    lunar,

        # ── Natal affliction (existing, preserved) ──
        "natal_affliction_doshas": afflicted_doshas,

        # ── Backward-compat keys (preserved from v1) ──
        "current_md":              md,
        "current_md_dosha":        md_dosha,
        "current_ad":              ad,
        "current_ad_dosha":        ad_dosha,
        "current_dosha_emphasis":  dasha_emphasis,
        "afflicted_planet_doshas": afflicted_doshas,
        "interpretation":          " ".join(interpretation_parts),

        # ── Method + sources ──
        "method": (
            "Composite Vikriti synthesis: dasha-dosha (Vimshottari) + current transit "
            "positions (Swiss Ephemeris Lahiri) + Ritu/season (Charaka) + age-bracket "
            "dominant dosha (Charaka Vimana Ch.8) + lunar state (waxing kapha / waning vata)."
        ),
        "classical_sources": [
            "Charaka Samhita Vimana Sthana Ch.8 — Vikriti analysis, age-bracket doshas",
            "Charaka Samhita Sutra Sthana Ch.6 — Ritucharya (seasonal regimen)",
            "Sushruta Samhita Sutra Sthana Ch.6 — Seasonal dosha vitiation",
            "Sarvartha Chintamani Ch.15 — Jyotish health analysis with transits",
            "Phaladeepika Ch.6 — Planetary dosha lords and health timing",
            "Brihat Samhita Ch.4-5 — Lunar effects on body fluids and doshas",
        ],
    }
# ── END B1 VIKRITI v2 ──
'''


# Updated endpoint wrapper that passes birth dict
UPDATED_WRAPPER = '''def vikriti_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:
    ch = extract_chart_essentials(get_chart(dob, time, lat, lon, timezone))
    birth_dict = {"dob": dob, "time": time, "lat": lat, "lon": lon, "timezone": timezone}
    return _vikriti_current(ch, birth_dict)'''


# ════════════════════════════════════════════════════════════════════════
# PATCH LOGIC
# ════════════════════════════════════════════════════════════════════════

OLD_FUNCTION_START = 'def _vikriti_current(ch: Dict) -> Dict:'


def find_old_function_block(content: str) -> tuple:
    """Locate the old _vikriti_current() function."""
    start_idx = content.find(OLD_FUNCTION_START)
    if start_idx == -1:
        return (None, None)

    search_from = start_idx + len(OLD_FUNCTION_START)
    next_def = content.find("\ndef ", search_from)
    next_section = content.find("\n# ════", search_from)

    candidates = [x for x in (next_def, next_section) if x != -1]
    if not candidates:
        end_idx = len(content)
    else:
        end_idx = min(candidates) + 1

    return (start_idx, end_idx)


OLD_WRAPPER_START = 'def vikriti_endpoint(dob: str, time: str, lat: float, lon: float, timezone: str = "Asia/Kolkata") -> Dict:'


def find_old_wrapper_block(content: str) -> tuple:
    start_idx = content.find(OLD_WRAPPER_START)
    if start_idx == -1:
        return (None, None)

    search_from = start_idx + len(OLD_WRAPPER_START)
    next_def = content.find("\ndef ", search_from)
    next_section = content.find("\n# ════", search_from)

    candidates = [x for x in (next_def, next_section) if x != -1]
    if not candidates:
        end_idx = len(content)
    else:
        end_idx = min(candidates) + 1

    return (start_idx, end_idx)


def main():
    if not os.path.exists(HEALTH_PY):
        print(f"ERROR: {HEALTH_PY} not found")
        sys.exit(1)

    with open(HEALTH_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/health.py.before_b1_vikriti_v2_{ts}"
    shutil.copyfile(HEALTH_PY, backup_path)
    print(f"✅ Backup written: {backup_path}")

    original_lines = len(content.split("\n"))
    print(f"   Original health.py: {original_lines} lines")
    print()

    # ── Step 1: Replace _vikriti_current function ──
    start_idx, end_idx = find_old_function_block(content)
    if start_idx is None:
        print("ERROR: Could not locate _vikriti_current function")
        sys.exit(2)

    pre_line  = content[:start_idx].count("\n") + 1
    post_line = content[:end_idx].count("\n") + 1
    print(f"✅ Step 1/2: Found _vikriti_current at lines {pre_line}-{post_line} ({end_idx-start_idx} chars)")
    content = content[:start_idx] + NEW_BLOCK + content[end_idx:]
    print(f"            Replaced with v2 (composite Charaka+Jyotish synthesis)")

    # ── Step 2: Replace vikriti_endpoint wrapper ──
    start_idx, end_idx = find_old_wrapper_block(content)
    if start_idx is None:
        print("ERROR: Could not locate vikriti_endpoint wrapper")
        sys.exit(3)

    pre_line  = content[:start_idx].count("\n") + 1
    post_line = content[:end_idx].count("\n") + 1
    print(f"✅ Step 2/2: Found vikriti_endpoint at lines {pre_line}-{post_line}")
    content = content[:start_idx] + UPDATED_WRAPPER + "\n" + content[end_idx:]
    print(f"            Updated wrapper to pass birth dict to _vikriti_current")

    # ── Final write ──
    with open(HEALTH_PY, "w") as f:
        f.write(content)

    new_lines = len(content.split("\n"))
    delta = new_lines - original_lines
    print()
    print(f"✅ B1 Vikriti v2 complete.")
    print(f"   New health.py: {new_lines} lines (delta: {'+' if delta >= 0 else ''}{delta})")

    after_path = f"{BACKUP_DIR}/health.py.after_b1_vikriti_v2_{ts}"
    shutil.copyfile(HEALTH_PY, after_path)
    print(f"✅ After snapshot: {after_path}")


if __name__ == "__main__":
    main()
