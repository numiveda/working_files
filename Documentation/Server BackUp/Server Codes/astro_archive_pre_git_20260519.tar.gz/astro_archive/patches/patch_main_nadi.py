"""
patch_main_nadi.py — Wires 6 Nadi (D5) endpoints into main.py.

Uses verify_key auth. Idempotent.

Run from /opt/astro:
    sudo python3 patch_main_nadi.py
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── NADI D5 MODULE ──"


IMPORT_BLOCK = '''
# ── NADI D5 MODULE IMPORTS ──
from nadi import (
    handle_profile                  as nadi_handle_profile,
    handle_moon_pada_analysis       as nadi_handle_moon_pada_analysis,
    handle_ak_nakshatra_signature   as nadi_handle_ak_nakshatra_signature,
    handle_pada_attributes          as nadi_handle_pada_attributes,
    handle_bhrigu_aspects           as nadi_handle_bhrigu_aspects,
    handle_nakshatra_yogas          as nadi_handle_nakshatra_yogas,
)
# ── END NADI D5 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── NADI D5 MODULE ──
# Phase D — Module D5 — Nadi Astrology (6 endpoints)
# Sources: Brihat Samhita, Bhrigu Samhita, classical Nadi tradition
# ════════════════════════════════════════════════════════════════════════

def _nadi_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/nadi/profile")
def nadi_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master Nadi synthesis — Moon-pada + AK-nakshatra + Bhrigu + yogas."""
    return nadi_handle_profile(_nadi_birth_dict(inp))


@app.post("/astro/nadi/moon_pada_analysis")
def nadi_moon_pada_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Moon's nakshatra-pada deep-dive — deity/animal/varna/gana + Gandanta detection."""
    return nadi_handle_moon_pada_analysis(_nadi_birth_dict(inp))


@app.post("/astro/nadi/ak_nakshatra_signature")
def nadi_ak_signature_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Atmakaraka's nakshatra signature — soul's karmic-vibrational identity."""
    return nadi_handle_ak_nakshatra_signature(_nadi_birth_dict(inp))


@app.post("/astro/nadi/pada_attributes")
def nadi_pada_attributes_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Per-planet pada attributes — deity/yoni/varna/gana/body_part/dosha across all 9 planets."""
    return nadi_handle_pada_attributes(_nadi_birth_dict(inp))


@app.post("/astro/nadi/bhrigu_aspects")
def nadi_bhrigu_aspects_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Bhrigu Nadi 2nd-from-planet result patterns + classical Bhrigu principles."""
    return nadi_handle_bhrigu_aspects(_nadi_birth_dict(inp))


@app.post("/astro/nadi/nakshatra_yogas")
def nadi_yogas_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Classical nakshatra-level yogas — Gandanta, Mula, Ashlesha, Jyeshtha + Rahu-Ketu intensifiers."""
    return nadi_handle_nakshatra_yogas(_nadi_birth_dict(inp))

# ── END NADI D5 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present in main.py.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_nadi_d5_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_nadi_d5_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ Nadi D5 module patched into main.py")
    print("   6 endpoints under /astro/nadi/* — engine reaches 233 endpoints")


if __name__ == "__main__":
    main()
