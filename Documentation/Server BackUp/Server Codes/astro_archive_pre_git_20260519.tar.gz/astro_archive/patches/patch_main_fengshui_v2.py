"""
patch_main_fengshui_v2.py — Adds 9 Feng Shui endpoints to /opt/astro/main.py

v2 FIX: Uses guaranteed-safe insertion points.
- Imports inserted RIGHT BEFORE `app = FastAPI(` line (no risk of breaking
  multi-line imports, since FastAPI() initialization is always at module scope)
- Endpoints appended at end of file

Safe, idempotent: skips if endpoints already present.
Marker: # ── FENG SHUI PERSONAL MODULE ──

Run from /opt/astro/ as the trading user with sudo:
    sudo python3 patch_main_fengshui_v2.py
"""

import re
import sys
from pathlib import Path

MAIN_PY = Path("/opt/astro/main.py")
MARKER_START = "# ── FENG SHUI PERSONAL MODULE ──"


# ════════════════════════════════════════════════════════════════════════
# IMPORT BLOCK — Inserted right before `app = FastAPI(`
# ════════════════════════════════════════════════════════════════════════

IMPORT_BLOCK = """
# ── Feng Shui module imports ──
from feng_shui import (
    full_personal_profile, calculate_kua, get_eight_directions,
    calculate_year_animal, calculate_day_master, element_interactions,
    calculate_lo_shu, flying_stars_for_year, get_bagua_home_map,
    feng_shui_compatibility, year_outlook,
)
from feng_shui_data import KUA_TO_TRIGRAM

"""


# ════════════════════════════════════════════════════════════════════════
# ENDPOINT BLOCK — Appended at end of file
# ════════════════════════════════════════════════════════════════════════

ENDPOINT_BLOCK = '''
# ══════════════════════════════════════════════════════════════════════
# ── FENG SHUI PERSONAL MODULE ──
# 9 endpoints — Classical Bazhai + Bazi + Lo Shu + Flying Stars
# Sources: Ba Zhai Ming Jing, Bazi Four Pillars, Lo Shu, Xuan Kong Fei Xing
# ══════════════════════════════════════════════════════════════════════

class FengShuiInput(BaseModel):
    dob: str           # YYYY-MM-DD
    gender: str        # "male" or "female"
    time: Optional[str] = "12:00"
    lat: Optional[float] = None
    lon: Optional[float] = None
    timezone: Optional[str] = "Asia/Kolkata"
    target_year: Optional[int] = None


class FengShuiCompatInput(BaseModel):
    person_a: FengShuiInput
    person_b: FengShuiInput


def _parse_fs_input(inp):
    """Helper — parse FengShuiInput into year, month, day components."""
    try:
        year, month, day = inp.dob.split("-")
        return int(year), int(month), int(day)
    except Exception:
        raise HTTPException(status_code=400, detail=f"Invalid dob format. Use YYYY-MM-DD. Got: {inp.dob}")


@app.post("/astro/fengshui/profile")
def fengshui_profile(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Master endpoint — full personal Feng Shui profile."""
    y, m, d = _parse_fs_input(inp)
    return full_personal_profile(y, m, d, inp.gender, inp.target_year)


@app.post("/astro/fengshui/kua")
def fengshui_kua(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Kua number + trigram + East/West group + compatible Kuas."""
    y, m, d = _parse_fs_input(inp)
    return calculate_kua(y, inp.gender, m, d)


@app.post("/astro/fengshui/directions")
def fengshui_directions(inp: FengShuiInput, _: str = Depends(verify_key)):
    """8 directions ranked — 4 lucky + 4 unlucky."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    return get_eight_directions(kua["kua_effective"])


@app.post("/astro/fengshui/elements")
def fengshui_elements(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Bazi Day Master + Year Animal Element + Wu Xing interactions."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    return {
        "year_animal":       calculate_year_animal(kua["solar_year_used"]),
        "day_master":        calculate_day_master(y, m, d),
        "personal_element":  element_interactions(kua["personal_element"]),
        "classical_source":  "Bazi Four Pillars + Wu Xing",
    }


@app.post("/astro/fengshui/loshu")
def fengshui_loshu(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Lo Shu Grid 3x3 with missing/excessive numbers analysis."""
    y, m, d = _parse_fs_input(inp)
    return calculate_lo_shu(y, m, d)


@app.post("/astro/fengshui/flying_stars")
def fengshui_flying_stars(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Xuan Kong Flying Stars for given year + native's personal palace star."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    target = inp.target_year or 2026
    return flying_stars_for_year(kua["kua_effective"], target)


@app.post("/astro/fengshui/bagua_home")
def fengshui_bagua_home(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Bagua home map — 9 life areas with colors, materials, alignment."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    return get_bagua_home_map(kua["kua_effective"])


@app.post("/astro/fengshui/compatibility")
def fengshui_compatibility_endpoint(inp: FengShuiCompatInput, _: str = Depends(verify_key)):
    """Two-person Feng Shui compatibility."""
    a_y, a_m, a_d = _parse_fs_input(inp.person_a)
    b_y, b_m, b_d = _parse_fs_input(inp.person_b)
    return feng_shui_compatibility(
        {"birth_year": a_y, "birth_month": a_m, "birth_day": a_d, "gender": inp.person_a.gender},
        {"birth_year": b_y, "birth_month": b_m, "birth_day": b_d, "gender": inp.person_b.gender},
    )


@app.post("/astro/fengshui/year_outlook")
def fengshui_year_outlook(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Personal year outlook — flying stars + zodiac year compatibility."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    target = inp.target_year or 2026
    return year_outlook(kua["kua_effective"], y, target)

# ── END FENG SHUI PERSONAL MODULE ──
'''


# ════════════════════════════════════════════════════════════════════════
# PATCHING LOGIC — Safer insertion points
# ════════════════════════════════════════════════════════════════════════

def main():
    if not MAIN_PY.exists():
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    content = MAIN_PY.read_text()

    # Idempotency
    if MARKER_START in content:
        print(f"⏭️  Feng Shui module already patched. Skipping.")
        return

    # Sanity checks
    if "from fastapi import" not in content:
        print("ERROR: main.py doesn't look like a FastAPI app")
        sys.exit(1)

    if "verify_key" not in content:
        print("ERROR: main.py doesn't define verify_key dependency")
        sys.exit(1)

    if "BaseModel" not in content:
        print("ERROR: BaseModel not imported in main.py")
        sys.exit(1)

    # ── 1. Find SAFE insertion point: right before "app = FastAPI(" ──
    # This is always at module scope, never inside a multi-line statement.
    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)

    if not match:
        print("ERROR: Could not find 'app = FastAPI(' in main.py")
        print("       Cannot safely insert imports. Aborting.")
        sys.exit(1)

    insertion_point = match.start()

    # Confirm the line at this position is at the start of a line (not indented)
    # by checking the character just before it is a newline
    if insertion_point > 0 and content[insertion_point - 1] != '\n':
        print(f"ERROR: 'app = FastAPI(' at position {insertion_point} is not at start of line")
        sys.exit(1)

    # ── 2. Inject imports right before app = FastAPI ──
    new_content = (
        content[:insertion_point]
        + IMPORT_BLOCK
        + content[insertion_point:]
    )

    # ── 3. Append endpoints at end of file ──
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    # ── 4. Write back ──
    MAIN_PY.write_text(new_content)
    print(f"✅ Patched {MAIN_PY}")
    print(f"   Added: 9 Feng Shui endpoints")
    print(f"   Marker: {MARKER_START}")
    print(f"   File size: {len(new_content)} bytes (was {len(content)})")

    # ── 5. Syntax check ──
    print("\n🔍 Verifying syntax...")
    import py_compile
    try:
        py_compile.compile(str(MAIN_PY), doraise=True)
        print("✅ Syntax OK — ready to restart astro service")
    except py_compile.PyCompileError as e:
        print(f"❌ SYNTAX ERROR in patched main.py:")
        print(f"   {e}")
        print("\n   Restore backup:")
        print("   cp /opt/astro/main.py.before_fengshui_patch_20260516_040000 /opt/astro/main.py")
        sys.exit(1)


if __name__ == "__main__":
    main()
