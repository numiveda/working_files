"""
patch_main_varshaphala.py — Wires 10 Varshaphala (C2) endpoints into main.py.

Introduces a new Pydantic schema: VarshaphalaInput (BirthInput + year).
Uses verified verify_key auth pattern.

Run from /opt/astro:
    sudo python3 patch_main_varshaphala.py

Idempotent.
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── VARSHAPHALA C2 MODULE ──"


IMPORT_BLOCK = '''
# ── VARSHAPHALA C2 MODULE IMPORTS ──
from varshaphala import (
    handle_profile               as varsha_handle_profile,
    handle_cast_chart            as varsha_handle_cast_chart,
    handle_muntha                as varsha_handle_muntha,
    handle_year_lord             as varsha_handle_year_lord,
    handle_tajik_aspects         as varsha_handle_tajik_aspects,
    handle_sahams                as varsha_handle_sahams,
    handle_monthly_predictions   as varsha_handle_monthly_predictions,
    handle_dasha_for_year        as varsha_handle_dasha_for_year,
    handle_event_timing          as varsha_handle_event_timing,
    handle_year_remedies         as varsha_handle_year_remedies,
)
# ── END VARSHAPHALA C2 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── VARSHAPHALA C2 MODULE ──
# Phase C — Module C2 — Annual chart / solar return (10 endpoints)
# Sources: Tajik Neelakanthi (~16th c.), Varshaphala Paddhati, Phaladeepika Ch. 8
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _VarshaBaseModel

class VarshaphalaInput(_VarshaBaseModel):
    birth: BirthInput
    year: int   # Target Varsha year (e.g., 2026 = the solar year starting from solar return in 2026)


def _varsha_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/varshaphala/profile")
def varsha_profile_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Master Varshaphala synthesis — solar return + Muntha + Varshesha + yogas + Sahams + remedies."""
    return varsha_handle_profile(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/cast_chart")
def varsha_cast_chart_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Solar return chart for target year — iterative Sun-longitude convergence."""
    return varsha_handle_cast_chart(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/muntha")
def varsha_muntha_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Muntha sign + lord + house in solar return chart."""
    return varsha_handle_muntha(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/year_lord")
def varsha_year_lord_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Varshesha (Year Lord) selection from 5 classical candidates."""
    return varsha_handle_year_lord(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/tajik_aspects")
def varsha_tajik_aspects_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Ithasala / Eesharafa / Mutthasila yoga detection in solar return chart."""
    return varsha_handle_tajik_aspects(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/sahams")
def varsha_sahams_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """20 classical Sahams (Hellenistic-Tajik Lots) — Punya, Vidya, Yashas, Mitra, etc."""
    return varsha_handle_sahams(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/monthly_predictions")
def varsha_monthly_predictions_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """12-month breakdown — each month's Muntha house and themes."""
    return varsha_handle_monthly_predictions(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/dasha_for_year")
def varsha_dasha_for_year_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Mudda dasha — Vimshottari ratios compressed to solar return year."""
    return varsha_handle_dasha_for_year(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/event_timing")
def varsha_event_timing_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Key event windows synthesized from Muntha + Year Lord + Sahams."""
    return varsha_handle_event_timing(_varsha_birth_dict(inp.birth), inp.year)


@app.post("/astro/varshaphala/year_remedies")
def varsha_year_remedies_ep(inp: VarshaphalaInput, _: str = Depends(verify_key)):
    """Year-specific classical remedies based on Varshesha and Muntha placement."""
    return varsha_handle_year_remedies(_varsha_birth_dict(inp.birth), inp.year)

# ── END VARSHAPHALA C2 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present in main.py.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_varsha_c2_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_varsha_c2_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ Varshaphala C2 module patched into main.py")
    print("   10 endpoints under /astro/varshaphala/*")


if __name__ == "__main__":
    main()
