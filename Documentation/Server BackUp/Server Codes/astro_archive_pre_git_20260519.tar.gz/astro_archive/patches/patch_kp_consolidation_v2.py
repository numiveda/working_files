"""
patch_kp_consolidation_v2.py — Round 1 of post-Phase-D cleanup. (v2 - regex fix)

V2 CHANGE FROM v1:
    The OLD_KP_ENDPOINT_PATTERN in v1 used [^)]* which doesn't handle nested
    parentheses correctly. The decorator @app.post("/astro/kp",
    dependencies=[Depends(verify_key)]) has nested parens — Depends(verify_key)
    — and [^)]* stops at the first inner `)`. v2 uses a literal exact match
    for the decorator-line + def-line pair.

PURPOSE:
    Consolidate KP code paths. Currently /astro/kp uses vedicastro library
    (which had the tropical-zodiac bug pre-hotfix). KP Pro (D4) uses Swiss
    Ephemeris directly. After hotfix both return identical sidereal Lahiri
    positions, but two code paths still exist.

    This patch:
    1. Replaces /astro/kp body to internally call kp_handle_profile()
    2. Removes vedicastro import entirely (no longer needed)
    3. Removes _get_kp_chart() helper (orphaned after #1)
    4. Removes _utc_offset() helper (only used by _get_kp_chart)
    5. Updates file docstring to reflect single-source KP architecture
    6. Adds _deprecation_note in /astro/kp response (Option B: return KP Pro shape)

NET RESULT:
    - Engine reaches single source of truth for KP (kp_pro.py)
    - vedicastro dependency removed from main.py
    - /astro/kp and /astro/kp/profile return identical responses
    - All future KP enhancements happen in ONE place (kp_pro.py)
    - Lines removed: ~70  |  Lines added: ~25

Run from /opt/astro:
    sudo python3 patch_kp_consolidation_v2.py

Idempotent: checks for marker before re-applying.
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── KP CONSOLIDATION (Round 1) ──"


# ════════════════════════════════════════════════════════════════════════
# NEW /astro/kp ENDPOINT BODY
# Replaces the entire old function with a thin wrapper that calls
# kp_handle_profile() and adds a deprecation note for transparency.
# ════════════════════════════════════════════════════════════════════════

NEW_KP_ENDPOINT = '''# ── KP CONSOLIDATION (Round 1) ──
# Was: vedicastro-backed KP (had tropical-zodiac bug pre-hotfix).
# Now: thin wrapper around kp_handle_profile() — single KP code path.
# Hotfix history: ayanamsha="KP" -> "Lahiri" applied 2026-05-17.
# Consolidation: vedicastro dependency removed 2026-05-17.
@app.post("/astro/kp", dependencies=[Depends(verify_key)])
def kp_chart(b: BirthInput):
    """
    KP (Krishnamurti Paddhati) full chart synthesis.

    Internally calls kp_handle_profile() from kp_pro.py — same engine that
    powers /astro/kp/profile. Returns the comprehensive KP analysis:
    lagna sub-lord, planet sub-lords, cuspal sub-lords (Placidus), birth
    ruling planets, significators (4-level hierarchy), all keyed for
    downstream LLM consumption.

    This endpoint is preserved for backward compatibility with myJyotish
    chat. For new code, /astro/kp/profile is the canonical path.
    """
    out = kp_handle_profile({
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    })
    out["_deprecation_note"] = (
        "This endpoint mirrors /astro/kp/profile. "
        "For new integrations, prefer /astro/kp/profile."
    )
    return out
# ── END KP CONSOLIDATION ──
'''


# ════════════════════════════════════════════════════════════════════════
# IMPROVED APPROACH: instead of one complex regex for the endpoint,
# locate it by index-search and slice it out. Much safer than a single
# regex trying to handle nested parens, variable function body lengths,
# and the end-of-function boundary.
# ════════════════════════════════════════════════════════════════════════

# Anchors for finding the OLD endpoint
OLD_ENDPOINT_START = '@app.post("/astro/kp", dependencies=[Depends(verify_key)])\ndef kp_chart(b: BirthInput):'

# The OLD function ends when the NEXT decorator or top-level def appears.
# We need to find the first '@app.' or 'def ' at column 0 (no leading whitespace)
# that occurs AFTER the start anchor.

def find_endpoint_block(content: str) -> tuple:
    """
    Find (start_index, end_index) of the old /astro/kp endpoint block.
    Returns (None, None) if not found.
    """
    start_idx = content.find(OLD_ENDPOINT_START)
    if start_idx == -1:
        return (None, None)

    # Find the next top-level @app. or def after this point
    search_from = start_idx + len(OLD_ENDPOINT_START)
    next_decorator = content.find("\n@app.", search_from)
    next_def       = content.find("\ndef ",  search_from)

    # Pick whichever comes first (and is not -1)
    candidates = [x for x in (next_decorator, next_def) if x != -1]
    if not candidates:
        # End of file
        end_idx = len(content)
    else:
        # +1 to consume the leading \n so the inserted block has clean separation
        end_idx = min(candidates) + 1

    return (start_idx, end_idx)


# Patterns 1, 2, 3, 5, 6 (these worked in v1 — keeping them)
IMPORT_PATTERN = re.compile(
    r'^from vedicastro import VedicAstro as _VedicAstro\s*\n',
    re.MULTILINE
)

UTC_OFFSET_PATTERN = re.compile(
    r'def _utc_offset\(timezone: str\) -> str:\n'
    r'    """Convert timezone string to UTC offset string for vedicastro\."""\n'
    r'(    .*\n)+?'
    r'(?=\n*def |\n*@app\.|\n*# |\Z)',
    re.MULTILINE
)

GET_KP_CHART_PATTERN = re.compile(
    r'def _get_kp_chart\(b: BirthInput\):\n'
    r'    """Build vedicastro KP horoscope object\."""\n'
    r'(    .*\n)+?'
    r'(?=\n*def |\n*@app\.|\n*# |\Z)',
    re.MULTILINE
)

DOCSTRING_PATTERN = re.compile(
    r'^(Replaces AstrologyAPI with self-hosted Swiss Ephemeris via dashaflow) \+ vedicastro \(KP\)',
    re.MULTILINE
)

COMMENT_PATTERN = re.compile(
    r'^# ── Critical: set Swiss Ephemeris data path BEFORE any flatlib/vedicastro import ──',
    re.MULTILINE
)


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present in main.py.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_kp_consolidation_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"✅ Backup written: {backup_path}")

    original_lines = len(content.split("\n"))
    print(f"   Original main.py: {original_lines} lines")
    print()

    # ── Step 1: Replace OLD /astro/kp endpoint with NEW one ────────────
    start_idx, end_idx = find_endpoint_block(content)
    if start_idx is None:
        print("ERROR: Could not locate old /astro/kp endpoint via anchor search.")
        print(f"       Looking for: {OLD_ENDPOINT_START[:60]}...")
        sys.exit(3)

    # Calculate which lines we're removing (for verbose output)
    pre_lines  = content[:start_idx].count("\n") + 1
    post_lines = content[:end_idx].count("\n") + 1
    print(f"✅ Step 1/6: Found old /astro/kp endpoint at lines {pre_lines}-{post_lines} ({end_idx - start_idx} chars)")

    content = content[:start_idx] + NEW_KP_ENDPOINT + "\n\n" + content[end_idx:]
    print(f"            Replaced with new wrapper (calls kp_handle_profile)")

    # ── Step 2: Remove vedicastro import ──────────────────────────────
    if not IMPORT_PATTERN.search(content):
        print("⚠️  Step 2/6: vedicastro import not found (already removed?)")
    else:
        content = IMPORT_PATTERN.sub("", content)
        print("✅ Step 2/6: Removed 'from vedicastro import' line")

    # ── Step 3: Remove _utc_offset function ───────────────────────────
    if not UTC_OFFSET_PATTERN.search(content):
        print("⚠️  Step 3/6: _utc_offset function not found (already removed?)")
    else:
        content = UTC_OFFSET_PATTERN.sub("", content)
        print("✅ Step 3/6: Removed _utc_offset() function")

    # ── Step 4: Remove _get_kp_chart function ─────────────────────────
    if not GET_KP_CHART_PATTERN.search(content):
        print("⚠️  Step 4/6: _get_kp_chart function not found (already removed?)")
    else:
        content = GET_KP_CHART_PATTERN.sub("", content)
        print("✅ Step 4/6: Removed _get_kp_chart() function")

    # ── Step 5: Update docstring ──────────────────────────────────────
    if DOCSTRING_PATTERN.search(content):
        content = DOCSTRING_PATTERN.sub(
            r"\1 (KP via kp_pro.py - vedicastro removed 2026-05-17)",
            content
        )
        print("✅ Step 5/6: Updated file docstring")
    else:
        print("⚠️  Step 5/6: Docstring on line 4 not in expected format")

    # ── Step 6: Update comment on line 17 ─────────────────────────────
    if COMMENT_PATTERN.search(content):
        content = COMMENT_PATTERN.sub(
            "# ── Critical: set Swiss Ephemeris data path BEFORE any flatlib import ──",
            content
        )
        print("✅ Step 6/6: Updated flatlib comment")
    else:
        print("⚠️  Step 6/6: Comment on line 17 not in expected format")

    # ── Final write ──────────────────────────────────────────────────
    with open(MAIN_PY, "w") as f:
        f.write(content)

    new_lines = len(content.split("\n"))
    delta = original_lines - new_lines
    print()
    print(f"✅ KP Consolidation complete.")
    print(f"   New main.py: {new_lines} lines (delta: {'-' if delta>=0 else '+'}{abs(delta)} lines)")

    after_path = f"{BACKUP_DIR}/main.py.after_kp_consolidation_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"✅ After snapshot: {after_path}")


if __name__ == "__main__":
    main()
