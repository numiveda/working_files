"""
main_patches_yogas.py — Source-of-truth for main.py yogas patches.

NOTE: Uses verify_key (NOT verify_api_key) — locked in from Delivery 1.
NOTE: Uses timezone=birth.timezone (NOT tz=) — locked in from Delivery 1.

5 new endpoints:
  POST /astro/yogas/detect    — full scan of all 198 yogas
  POST /astro/yogas/active    — only present yogas
  POST /astro/yogas/positive  — only beneficial yogas present (sorted by strength)
  POST /astro/yogas/negative  — only harmful yogas/doshas present (sorted by strength)
  GET  /astro/yogas/catalog   — no chart needed; full catalog (with optional family filter)
  GET  /astro/yogas/single/{yoga_id}  — single yoga lookup
"""

# ─────────────────────────────────────────────────────────────────────────────
# BLOCK A: IMPORTS
# ─────────────────────────────────────────────────────────────────────────────
BLOCK_A_IMPORTS = '''
# === BEGIN YOGAS-V2 IMPORTS ===
from yogas import (
    detect_all       as yogasv2_detect_all,
    detect_active    as yogasv2_detect_active,
    detect_positive  as yogasv2_detect_positive,
    detect_negative  as yogasv2_detect_negative,
    get_catalog      as yogasv2_get_catalog,
    get_yoga         as yogasv2_get_yoga,
)
# === END YOGAS-V2 IMPORTS ===
'''

# ─────────────────────────────────────────────────────────────────────────────
# BLOCK B: MODELS (none needed — all use existing BirthInput)
# ─────────────────────────────────────────────────────────────────────────────
BLOCK_B_MODELS = ''  # no new models for yogas

# ─────────────────────────────────────────────────────────────────────────────
# BLOCK C: ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────
BLOCK_C_ENDPOINTS = '''
# === BEGIN YOGAS-V2 ENDPOINTS ===

@app.post("/astro/yogas/detect")
async def yogasv2_detect(birth: BirthInput, _: str = Depends(verify_key)):
    """Full yoga scan: detect all 198 yogas and return all (active + non-active)."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        return yogasv2_detect_all(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yogas detect failed: {str(e)}")


@app.post("/astro/yogas/active")
async def yogasv2_active(birth: BirthInput, _: str = Depends(verify_key)):
    """Return only the yogas currently present in the chart."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        return yogasv2_detect_active(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yogas active failed: {str(e)}")


@app.post("/astro/yogas/positive")
async def yogasv2_positive(birth: BirthInput, _: str = Depends(verify_key)):
    """Active positive yogas only, sorted by strength descending."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        return yogasv2_detect_positive(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yogas positive failed: {str(e)}")


@app.post("/astro/yogas/negative")
async def yogasv2_negative(birth: BirthInput, _: str = Depends(verify_key)):
    """Active negative yogas (doshas, arishtas) only, sorted by strength descending."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        return yogasv2_detect_negative(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yogas negative failed: {str(e)}")


@app.get("/astro/yogas/catalog")
async def yogasv2_catalog(family: str = None, _: str = Depends(verify_key)):
    """Full catalog of all 198 yogas (no chart needed). Optional family filter."""
    try:
        return yogasv2_get_catalog(family_filter=family)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yogas catalog failed: {str(e)}")


@app.get("/astro/yogas/single/{yoga_id}")
async def yogasv2_single(yoga_id: str, _: str = Depends(verify_key)):
    """Lookup a single yoga's metadata by ID."""
    try:
        return yogasv2_get_yoga(yoga_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yoga lookup failed: {str(e)}")


# === END YOGAS-V2 ENDPOINTS ===
'''
