"""
patch_F10P3_rectification.py — F10-P3 installer (FINAL F10 patch)

Adds Approach C (Nadi Amshas) + Master Synthesis.

Follows the §5.1 locked installer template, hardened by P1+P2 lessons:
  - Lesson #8 : Append-to-EOF, no anchor search
  - Lesson #9 : .replace() not .format() for marker substitution
  - Lesson #10: AST-verify import names at module scope
  - Lesson #11: HH:MM only — inherited via _p1._build_candidate_times reuse

What this patch adds:
  - import rectification_p3        (Phase C)
  - Pydantic models:               (Phase D)
      * TraitDimensionsInput
      * NadiAmshaRectificationInput(StrictBirthInput)
      * MasterEventInput
      * MasterRectificationInput(StrictBirthInput)
  - 3 route handlers:              (Phase E)
      * POST /astro/rectification/nadi_amshas
      * POST /astro/rectification/master
      * GET  /astro/rectification/nadi_amshas/info

Requires F10-P1 + F10-P2 already installed (P3 reuses both).
"""

import os
import sys
import ast
import shlex
import shutil
import subprocess
import time

# ============================================================================
# Constants
# ============================================================================

ASTRO_DIR     = "/opt/astro"
MAIN_PY       = os.path.join(ASTRO_DIR, "main.py")
MODULE_PY     = os.path.join(ASTRO_DIR, "rectification_p3.py")
P1_MODULE_PY  = os.path.join(ASTRO_DIR, "rectification.py")
P2_MODULE_PY  = os.path.join(ASTRO_DIR, "rectification_p2.py")
PATCH_NAME    = "F10P3_rectification"
TIMESTAMP     = time.strftime("%Y%m%d_%H%M%S")
BACKUP_PATH   = f"{MAIN_PY}.before_{PATCH_NAME}_{TIMESTAMP}"
SNAPSHOT_PATH = f"{MAIN_PY}.after_{PATCH_NAME}_{TIMESTAMP}"
MARKER        = "# ── F10-P3: BTR Approach C (Nadi Amshas) + Master Synthesis (2026-05-18) ──"

IMPORT_LINE = "import rectification_p3  # F10-P3"

# Marker checks for P1 and P2 dependencies
P1_MARKER_CHECK = "# ── F10-P1: Birth Time Rectification (KP-based)"
P2_MARKER_CHECK = "# ── F10-P2: BTR Approaches A (Parashari) + B (Tattva)"


# ============================================================================
# Logging helpers
# ============================================================================

def log(msg: str) -> None:
    print(f"[{PATCH_NAME}] {msg}", flush=True)


def fail(msg: str) -> None:
    log(f"FAIL: {msg}")
    sys.exit(1)


def run_as_trading_user(python_code: str) -> None:
    quoted_py = shlex.quote(python_code)
    shell_cmd = f"cd {shlex.quote(ASTRO_DIR)} && python3 -c {quoted_py}"
    subprocess.check_call(["sudo", "-u", "trading", "bash", "-c", shell_cmd])


def chown_to_trading(path: str) -> None:
    try:
        subprocess.check_call(["chown", "trading:trading", path])
    except subprocess.CalledProcessError as e:
        log(f"WARNING: chown {path} failed: {e}")


# ============================================================================
# Phase A — preflight
# ============================================================================

def phase_a_preflight() -> None:
    log("Phase A: preflight (append-mode, requires P1+P2)")

    if not os.path.isfile(MAIN_PY):
        fail(f"main.py not found at {MAIN_PY}")

    if not os.path.isfile(MODULE_PY):
        fail(f"rectification_p3.py not found at {MODULE_PY} — scp it first")

    if not os.path.isfile(P1_MODULE_PY):
        fail(f"rectification.py (P1) not found at {P1_MODULE_PY} — apply F10-P1 first")
    log("Phase A.2a: F10-P1 module present (rectification.py)")

    if not os.path.isfile(P2_MODULE_PY):
        fail(f"rectification_p2.py (P2) not found at {P2_MODULE_PY} — apply F10-P2 first")
    log("Phase A.2b: F10-P2 module present (rectification_p2.py)")

    try:
        with open(MODULE_PY) as f:
            ast.parse(f.read())
    except SyntaxError as e:
        fail(f"rectification_p3.py has SyntaxError: {e}")
    log("Phase A.3: rectification_p3.py syntax OK")

    try:
        with open(MAIN_PY) as f:
            ast.parse(f.read())
    except SyntaxError as e:
        fail(f"main.py has pre-existing SyntaxError: {e}")
    log("Phase A.4: main.py baseline syntax OK")

    with open(MAIN_PY) as f:
        main_src = f.read()

    if MARKER in main_src:
        fail(f"P3 marker already present: {MARKER!r}")
    log("Phase A.5: P3 marker absent (not previously patched)")

    if IMPORT_LINE in main_src:
        fail(f"P3 import line already present: {IMPORT_LINE!r}")
    log("Phase A.6: P3 import line absent")

    if P1_MARKER_CHECK not in main_src:
        fail("F10-P1 marker not found in main.py — P3 depends on P1 being installed")
    log("Phase A.7a: F10-P1 marker present")

    if P2_MARKER_CHECK not in main_src:
        fail("F10-P2 marker not found in main.py — P3 depends on P2 being installed")
    log("Phase A.7b: F10-P2 marker present")

    if "class StrictBirthInput" not in main_src:
        fail("StrictBirthInput class not found — F5-U1 must be applied first")
    log("Phase A.8: StrictBirthInput present (F5-U1 confirmed)")

    if "verify_key" not in main_src:
        fail("verify_key dependency not found in main.py")
    log("Phase A.9: verify_key dependency present")

    # Lesson #10: AST-verify required names at module scope
    required_names = ("BaseModel", "ConfigDict", "Depends", "HTTPException")
    main_tree = ast.parse(main_src)
    bound_at_module_scope = set()
    for node in main_tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                bound_at_module_scope.add(alias.asname or alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                bound_at_module_scope.add(alias.asname or alias.name)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for t in targets:
                if isinstance(t, ast.Name):
                    bound_at_module_scope.add(t.id)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            bound_at_module_scope.add(node.name)

    missing = [n for n in required_names if n not in bound_at_module_scope]
    if missing:
        fail(f"Required names not bound at module scope: {missing}")
    log(f"Phase A.10: required names bound at module scope: {required_names}")

    log("Phase A: PASSED")


# ============================================================================
# Phase B — backup
# ============================================================================

def phase_b_backup() -> None:
    log("Phase B: backup main.py")
    shutil.copy2(MAIN_PY, BACKUP_PATH)
    log(f"Phase B: backup at {BACKUP_PATH}")


# ============================================================================
# Insertion block
# ============================================================================

INSERTION_BLOCK = '''

__MARKER__
import rectification_p3  # F10-P3


class NadiAmshaRectificationInput(StrictBirthInput):
    # Inherits dob, time, lat, lon, timezone + extra=forbid from StrictBirthInput
    # user_traits is a dict of trait_dimension -> trait_value
    # e.g. {"body_type": "lean", "complexion": "wheatish", "voice": "soft"}
    user_traits: dict[str, str]
    scan_window_minutes: int = 30
    scan_granularity_minutes: int = 1
    top_n: int = 5


class MasterEventInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    event_type: str
    event_date: str
    weight: float = 1.0


class MasterRectificationInput(StrictBirthInput):
    # All inputs optional — master uses whichever data the user has.
    # Must have at least one of: events, observed_tattva, user_traits.
    events: list[MasterEventInput] = []
    observed_tattva: str | None = None
    user_traits: dict[str, str] = {}
    scan_window_minutes: int = 120
    scan_granularity_minutes: int = 1


@app.post(
    "/astro/rectification/nadi_amshas",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p3_nadi_amsha_rectification(payload: NadiAmshaRectificationInput):
    try:
        result = rectification_p3.handle_nadi_amsha_rectification(
            dob=payload.dob,
            time=payload.time,
            lat=payload.lat,
            lon=payload.lon,
            timezone=payload.timezone,
            user_traits=payload.user_traits,
            scan_window_minutes=payload.scan_window_minutes,
            scan_granularity_minutes=payload.scan_granularity_minutes,
            top_n=payload.top_n,
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Nadi amsha rectification failed: {exc}")


@app.post(
    "/astro/rectification/master",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p3_master_rectification(payload: MasterRectificationInput):
    try:
        events_list = [
            {"event_type": e.event_type, "event_date": e.event_date, "weight": e.weight}
            for e in payload.events
        ] if payload.events else None

        result = rectification_p3.handle_master_rectification(
            dob=payload.dob,
            time=payload.time,
            lat=payload.lat,
            lon=payload.lon,
            timezone=payload.timezone,
            events=events_list,
            observed_tattva=payload.observed_tattva,
            user_traits=payload.user_traits or None,
            scan_window_minutes=payload.scan_window_minutes,
            scan_granularity_minutes=payload.scan_granularity_minutes,
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Master rectification failed: {exc}")


@app.get(
    "/astro/rectification/nadi_amshas/info",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p3_nadi_amshas_info():
    return rectification_p3.handle_nadi_amshas_info()
'''


def build_insertion_text() -> str:
    return INSERTION_BLOCK.replace("__MARKER__", MARKER)


# ============================================================================
# Phase F — write + verify + auto-rollback
# ============================================================================

def phase_f_write_and_verify() -> None:
    log("Phase F: write + verify (append mode)")

    with open(MAIN_PY) as f:
        original = f.read()

    if not original.endswith("\n"):
        original = original + "\n"

    insertion = build_insertion_text()
    new_src = original + insertion

    if len(new_src) <= len(original):
        fail("Phase F: append produced no growth — aborting")

    tmp_path = MAIN_PY + ".tmp"
    with open(tmp_path, "w") as f:
        f.write(new_src)
    os.replace(tmp_path, MAIN_PY)
    chown_to_trading(MAIN_PY)
    log(f"Phase F: main.py written ({len(original)} → {len(new_src)} bytes)")

    # F.1 — syntax
    try:
        run_as_trading_user(
            "import ast; "
            "src = open('/opt/astro/main.py').read(); "
            "ast.parse(src); "
            "print('syntax_ok')"
        )
    except subprocess.CalledProcessError:
        log("Phase F.1 FAIL: syntax check failed — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        fail("Phase F.1: SyntaxError — rolled back")
    log("Phase F.1: syntax check OK")

    # F.2 — smoke (single_input grammar, no top-level compounds per Lesson #3)
    smoke = (
        "import rectification_p3 as rp3; "
        "assert hasattr(rp3, 'handle_nadi_amsha_rectification'), 'handle_nadi_amsha_rectification missing'; "
        "assert hasattr(rp3, 'handle_master_rectification'), 'handle_master_rectification missing'; "
        "assert hasattr(rp3, 'handle_nadi_amshas_info'), 'handle_nadi_amshas_info missing'; "
        "assert callable(rp3.handle_master_rectification), 'handle_master_rectification not callable'; "
        "r = rp3.handle_nadi_amshas_info(); "
        "assert isinstance(r, dict) and 'total_amshas' in r, 'nadi_amshas_info bad shape'; "
        "assert r['total_amshas'] == 1800, 'expected 1800 total amshas'; "
        "a = rp3._amsha_for_longitude(314.51); "
        "assert a['sign'] == 'Aquarius', 'Aquarius longitude mapping wrong'; "
        "assert 1 <= a['amsha_index'] <= 150, 'amsha_index out of range'; "
        "import main; "
        "assert hasattr(main, 'f10p3_nadi_amsha_rectification'), 'nadi_amsha route missing on main'; "
        "assert hasattr(main, 'f10p3_master_rectification'), 'master route missing on main'; "
        "assert hasattr(main, 'f10p3_nadi_amshas_info'), 'info route missing on main'; "
        "print('smoke_ok')"
    )

    try:
        run_as_trading_user(smoke)
    except subprocess.CalledProcessError:
        log("Phase F.2 FAIL: smoke test failed — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        fail("Phase F.2: smoke test failed — rolled back")
    log("Phase F.2: smoke OK")

    # F.3 — service restart + health check
    log("Phase F.3: restarting astro service")
    try:
        subprocess.check_call(["systemctl", "restart", "astro"])
    except subprocess.CalledProcessError as e:
        log(f"Phase F.3 FAIL: systemctl restart failed: {e}")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        subprocess.call(["systemctl", "restart", "astro"])
        fail("Phase F.3: service restart failed — rolled back")
    time.sleep(3)

    try:
        out = subprocess.check_output(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             "http://localhost:8001/astro/health"],
            timeout=10,
        ).decode().strip()
    except subprocess.CalledProcessError as e:
        out = f"curl_failed:{e}"

    if out != "200":
        log(f"Phase F.3 FAIL: /astro/health returned {out!r} — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        subprocess.call(["systemctl", "restart", "astro"])
        fail(f"Phase F.3: health check returned {out!r} — rolled back")
    log("Phase F.3: /astro/health = 200")

    # F.4 — verify new endpoints registered
    try:
        endpoints_out = subprocess.check_output(
            ["curl", "-s", "http://localhost:8001/openapi.json"],
            timeout=10,
        ).decode()
    except subprocess.CalledProcessError as e:
        log(f"Phase F.4 WARN: openapi fetch failed: {e}")
        endpoints_out = ""

    expected_endpoints = [
        "/astro/rectification/nadi_amshas",
        "/astro/rectification/master",
        "/astro/rectification/nadi_amshas/info",
    ]
    for ep in expected_endpoints:
        if ep not in endpoints_out:
            log(f"Phase F.4 FAIL: {ep} not in openapi.json — auto-rollback")
            shutil.copy2(BACKUP_PATH, MAIN_PY)
            chown_to_trading(MAIN_PY)
            subprocess.call(["systemctl", "restart", "astro"])
            fail(f"Phase F.4: endpoint {ep} not registered — rolled back")
        log(f"Phase F.4: {ep} registered")

    # F.5 — snapshot
    shutil.copy2(MAIN_PY, SNAPSHOT_PATH)
    log(f"Phase F.5: snapshot at {SNAPSHOT_PATH}")

    log("Phase F: PASSED")


# ============================================================================
# Main
# ============================================================================

def main():
    log(f"Starting {PATCH_NAME} at {TIMESTAMP}")
    if os.geteuid() != 0:
        fail("Must run as root (use sudo)")

    phase_a_preflight()
    phase_b_backup()
    phase_f_write_and_verify()

    log("=" * 60)
    log(f"{PATCH_NAME}: SUCCESS")
    log(f"Backup:   {BACKUP_PATH}")
    log(f"Snapshot: {SNAPSHOT_PATH}")
    log("New endpoints:")
    log("  POST /astro/rectification/nadi_amshas")
    log("  POST /astro/rectification/master")
    log("  GET  /astro/rectification/nadi_amshas/info")
    log("Engine: 324 → 327 endpoints")
    log("F10 COMPLETE: all four BTR approaches + master synthesis live")
    log("=" * 60)


if __name__ == "__main__":
    main()
