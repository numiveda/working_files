"""
patch_main_health.py — Adds 15 Health + Chakra + Ayurveda endpoints (Module B1)

Same proven safe-insertion pattern as Phase A.
Marker: # ── HEALTH MODULE (B1) ──

Run: sudo python3 patch_main_health.py
"""

import re
import sys
from pathlib import Path

MAIN_PY = Path("/opt/astro/main.py")
MARKER_START = "# ── HEALTH MODULE (B1) ──"


IMPORT_BLOCK = """
# ── Health module (B1) imports ──
from health import (
    full_health_profile,
    body_parts_endpoint as health_body_parts,
    illness_predisposition_endpoint as health_illness,
    tridosha_endpoint as health_tridosha,
    prakriti_endpoint as health_prakriti,
    vikriti_endpoint as health_vikriti,
    chakras_endpoint as health_chakras,
    chakra_balancing_for_chart as health_chakra_balancing,
    healing_windows_endpoint as health_healing_windows,
    avoidance_windows_endpoint as health_avoidance_windows,
    diet_endpoint as health_diet,
    yoga_pranayama_endpoint as health_yoga_pranayama,
    mental_health_endpoint as health_mental,
    longevity_endpoint as health_longevity,
    health_remedies_endpoint as health_remedies,
)

"""


ENDPOINT_BLOCK = '''
# ══════════════════════════════════════════════════════════════════════
# ── HEALTH MODULE (B1) ──
# 15 endpoints — Health + Chakra + Ayurveda
# Sources: Charaka Samhita, Sushruta Samhita, Ashtanga Hridaya,
#          Hatha Yoga Pradipika, BPHS, Sarvartha Chintamani
# ══════════════════════════════════════════════════════════════════════

@app.post("/astro/health/profile")
def health_profile(inp: BirthInput, _: str = Depends(verify_key)):
    """Master endpoint — full Health + Chakra + Ayurveda profile."""
    return full_health_profile(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/body_parts")
def health_body_parts_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Body parts by house + planet; afflicted organs in chart."""
    return health_body_parts(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/illness_predisposition")
def health_illness_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Disease tendencies from 6th house, 8th house, ascendant afflictions."""
    return health_illness(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/tridosha")
def health_tridosha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Vata/Pitta/Kapha analysis from planets + signs in chart."""
    return health_tridosha(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/prakriti")
def health_prakriti_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Birth constitution (Prakriti) from Lagna + Moon nakshatra."""
    return health_prakriti(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/vikriti_current")
def health_vikriti_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Current dosha imbalance (Vikriti) from current dasha + afflictions."""
    return health_vikriti(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/chakras")
def health_chakras_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """7 chakras with personal afflicted/balanced status based on planetary placements."""
    return health_chakras(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/chakra_balancing")
def health_chakra_balancing_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Specific chakra balancing practices prioritized by chart afflictions."""
    return health_chakra_balancing(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/healing_windows")
def health_healing_windows_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Best dasha/transit windows for medical treatment."""
    return health_healing_windows(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/avoidance_windows")
def health_avoidance_windows_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Windows to avoid major medical procedures."""
    return health_avoidance_windows(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/ayurvedic_diet")
def health_diet_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Dietary recommendations by Prakriti."""
    return health_diet(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/yoga_pranayama")
def health_yoga_pranayama_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Yoga asanas + pranayama for native's chart."""
    return health_yoga_pranayama(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/mental_health")
def health_mental_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Mind analysis (Moon, Mercury, 5th house) — stress patterns, predispositions."""
    return health_mental(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/longevity_factors")
def health_longevity_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Ayurvedic + astrological longevity factors assessment."""
    return health_longevity(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/health/health_remedies")
def health_remedies_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Health-specific remedies from chart afflictions."""
    return health_remedies(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )

# ── END HEALTH MODULE (B1) ──
'''


def main():
    if not MAIN_PY.exists():
        print(f"ERROR: {MAIN_PY} not found"); sys.exit(1)

    content = MAIN_PY.read_text()

    if MARKER_START in content:
        print(f"⏭️  Health module already patched. Skipping.")
        return

    if "from fastapi import" not in content:
        print("ERROR: main.py doesn't look like a FastAPI app"); sys.exit(1)
    if "verify_key" not in content:
        print("ERROR: verify_key not defined"); sys.exit(1)
    if "BirthInput" not in content:
        print("ERROR: BirthInput model not defined"); sys.exit(1)

    pat = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = pat.search(content)
    if not match:
        print("ERROR: 'app = FastAPI(' not found"); sys.exit(1)

    insertion_point = match.start()
    if insertion_point > 0 and content[insertion_point - 1] != '\n':
        print(f"ERROR: 'app = FastAPI(' not at start of line"); sys.exit(1)

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    MAIN_PY.write_text(new_content)
    print(f"✅ Patched {MAIN_PY}")
    print(f"   Added: 15 Health (B1) endpoints")
    print(f"   Marker: {MARKER_START}")
    print(f"   File size: {len(new_content)} bytes (was {len(content)})")

    print("\n🔍 Verifying syntax...")
    import py_compile
    try:
        py_compile.compile(str(MAIN_PY), doraise=True)
        print("✅ Syntax OK — ready to restart astro service")
    except py_compile.PyCompileError as e:
        print(f"❌ SYNTAX ERROR: {e}"); sys.exit(1)


if __name__ == "__main__":
    main()
