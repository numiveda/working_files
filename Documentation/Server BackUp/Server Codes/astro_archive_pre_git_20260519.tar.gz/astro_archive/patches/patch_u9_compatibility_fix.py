#!/usr/bin/env python3
"""
patch_u9_compatibility_fix.py
─────────────────────────────────────────────────────────────────────────
U9 — Fix /astro/compatibility signature mismatch.

PROBLEM:
    main.py line 670 calls calculate_ashtakoot(person1_dob=..., ...) with
    kwargs that the actual function does not accept. Real signature is:
        calculate_ashtakoot(male_moon_lon: float, female_moon_lon: float,
                            male_chart=None, female_chart=None)
    The endpoint has been returning 400 errors.

FIX:
    Replace endpoint body to delegate to compat_handle_profile() — the
    modern master synthesis handler already imported at line 218 as
    compat_handle_profile. Same input shape (person dicts), richer
    output (12-component synthesis: ashtakoot + manglik + nadi + bhakoot
    + D9 + 7H + karakas + longevity + dasha + synastry + muhurta).

    Also removes the legacy `calculate_ashtakoot` import at line 31 since
    nothing else in /opt/astro/ references it (verified by diagnostic).

CHARACTERISTICS:
    - Idempotent: re-running this patch is a no-op (marker check).
    - Reversible: backup file created with timestamp.
    - Anchor-based replacement (Pattern 1 from handover principles).
    - Net change: ~+2 lines main.py, -1 import.

Usage:
    sudo python3 /opt/astro/patch_u9_compatibility_fix.py

Author: Claude (F1 prep session, 2026-05-17)
"""

import os
import re
import sys
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
MARKER = "# ── U9: /astro/compatibility modernized (2026-05-17) ──"

# ─────────────────────────────────────────────────────────────────────
# Anchor strings — copied verbatim from diagnostic output
# ─────────────────────────────────────────────────────────────────────

OLD_IMPORT_LINE = "    calculate_ashtakoot,\n"

OLD_ENDPOINT = '''@app.post("/astro/compatibility", dependencies=[Depends(verify_key)])
def compatibility(c: CompatibilityInput):
    try:
        result = calculate_ashtakoot(
            person1_dob=c.person1.dob, person1_time=c.person1.time,
            person1_lat=c.person1.lat, person1_lon=c.person1.lon,
            person1_tz=c.person1.timezone,
            person2_dob=c.person2.dob, person2_time=c.person2.time,
            person2_lat=c.person2.lat, person2_lon=c.person2.lon,
            person2_tz=c.person2.timezone,
        )
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))'''

NEW_ENDPOINT = '''@app.post("/astro/compatibility", dependencies=[Depends(verify_key)])
def compatibility(c: CompatibilityInput):
    """
    Marriage compatibility — master 12-component synthesis.

    {MARKER}
    Previously called legacy calculate_ashtakoot() with wrong kwargs.
    Now delegates to compat_handle_profile() which returns the full
    Ashtakoot + Manglik + Nadi + Bhakoot + D9 + 7H + Karakas + Longevity
    + Dasha + Synastry + Marriage Muhurta synthesis.
    """
    try:
        p1 = {"dob": c.person1.dob, "time": c.person1.time,
              "lat": c.person1.lat, "lon": c.person1.lon,
              "timezone": c.person1.timezone}
        p2 = {"dob": c.person2.dob, "time": c.person2.time,
              "lat": c.person2.lat, "lon": c.person2.lon,
              "timezone": c.person2.timezone}
        result = compat_handle_profile(p1, p2, relationship_type="marriage")
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))'''.replace("{MARKER}", MARKER)


def main():
    print("=" * 70)
    print("U9 — /astro/compatibility signature fix")
    print("=" * 70)

    # ── Step 1: read file ──
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    original_size = len(content)
    original_lines = content.count("\n") + 1
    print(f"main.py size: {original_size} bytes, {original_lines} lines")

    # ── Step 2: idempotency check ──
    if MARKER in content:
        print(f"\n✅ Marker already present — U9 was applied previously.")
        print("   No changes made (idempotent).")
        return

    # ── Step 3: validate anchors exist ──
    if OLD_ENDPOINT not in content:
        print(f"\n❌ ERROR: Old endpoint block not found verbatim.")
        print(f"   Expected exact string starting with:")
        print(f"   '@app.post(\"/astro/compatibility\"...'")
        print(f"   Either the file has already been modified, or layout differs.")
        sys.exit(1)
    print(f"✅ Found OLD_ENDPOINT anchor.")

    if OLD_IMPORT_LINE not in content:
        print(f"\n⚠️  WARNING: legacy import line not found:")
        print(f"   {OLD_IMPORT_LINE!r}")
        print(f"   Endpoint fix will proceed; import cleanup skipped.")
        skip_import_cleanup = True
    else:
        print(f"✅ Found legacy import line for removal.")
        skip_import_cleanup = False

    # ── Step 4: backup ──
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = f"{MAIN_PY}.before_u9_compat_fix_{ts}"
    shutil.copy2(MAIN_PY, backup)
    print(f"✅ Backup: {backup}")

    # ── Step 5: apply endpoint replacement ──
    new_content = content.replace(OLD_ENDPOINT, NEW_ENDPOINT, 1)
    assert OLD_ENDPOINT not in new_content, "Replacement failed — old block still present"
    assert NEW_ENDPOINT in new_content, "Replacement failed — new block not inserted"
    print(f"✅ Replaced /astro/compatibility endpoint body.")

    # ── Step 6: remove legacy import (best-effort) ──
    if not skip_import_cleanup:
        new_content = new_content.replace(OLD_IMPORT_LINE, "", 1)
        # Double-check we didn't accidentally remove twice or hit nothing
        if OLD_IMPORT_LINE.strip() not in new_content:
            print(f"✅ Removed legacy `calculate_ashtakoot` import.")
        else:
            print(f"⚠️  Legacy import removal may have left a residue — verify manually.")

    # ── Step 7: write ──
    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    new_size = len(new_content)
    new_lines = new_content.count("\n") + 1
    print(f"\n✅ Wrote new main.py: {new_size} bytes ({new_size - original_size:+d}), "
          f"{new_lines} lines ({new_lines - original_lines:+d})")

    # ── Step 8: snapshot after ──
    snap_after = f"{MAIN_PY}.after_u9_compat_fix_{ts}"
    shutil.copy2(MAIN_PY, snap_after)
    print(f"✅ Snapshot: {snap_after}")

    # ── Step 9: syntax check ──
    print("\n── Syntax check ──")
    import py_compile
    try:
        py_compile.compile(MAIN_PY, doraise=True)
        print("✅ Syntax OK")
    except py_compile.PyCompileError as e:
        print(f"❌ SYNTAX ERROR — rolling back from {backup}")
        shutil.copy2(backup, MAIN_PY)
        print(f"   Restored. Error was: {e}")
        sys.exit(1)

    print("\n" + "=" * 70)
    print("U9 PATCH APPLIED — next steps:")
    print("  sudo systemctl restart astro && sleep 3")
    print("  systemctl status astro | grep -E 'Memory|Active'")
    print("  Then run smoke test (see U9_PATCH_INSTRUCTIONS.md)")
    print("=" * 70)


if __name__ == "__main__":
    main()
