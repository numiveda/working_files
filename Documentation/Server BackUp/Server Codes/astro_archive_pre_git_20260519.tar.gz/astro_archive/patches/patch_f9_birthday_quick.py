#!/usr/bin/env python3
"""
patch_f9_birthday_quick.py
─────────────────────────────────────────────────────────────────────────
F9 — Birthday Quick: 2 endpoints (quick + headline)

PREREQUISITES:
    - /opt/astro/birthday_quick.py present (scp'd separately)
    - F3 applied (we splice after F3's imports)

PHASES:
    A — Preconditions + pre-import smoke that birthday_quick.py loads cleanly
    B — Inject import block after F3's imports
    C — Inject BirthdayInput Pydantic class after StrengthInput
    D — Append 2 endpoint registrations
    E — Snapshot
    F — Full layered smoke INCLUDING main.py (U10v2 hardening)
        with built-in F9 functional assertions

Idempotent. Auto-rollback on syntax or smoke failure.

Usage:
    sudo python3 /opt/astro/patch_f9_birthday_quick.py

Author: Claude (F9, 2026-05-18)
"""

import os
import sys
import shutil
import subprocess
import py_compile
from datetime import datetime

MAIN_PY        = "/opt/astro/main.py"
BIRTHDAY_PY    = "/opt/astro/birthday_quick.py"

MARKER_IMPORT    = "# ── F9: Birthday Quick imports (2026-05-18) ──"
MARKER_INPUT_CLS = "# ── F9: BirthdayInput (2026-05-18) ──"
MARKER_ENDPOINTS = "# ── F9: /astro/birthday/* endpoints (2026-05-18) ──"

# Anchor: F3 import block tail
F3_IMPORT_TAIL = """from strength import (
    handle_vimshopaka_bala         as st_handle_vimshopaka_bala,
    handle_planetary_summary       as st_handle_planetary_summary,
    handle_strength_comprehensive  as st_handle_comprehensive,
)"""

F3_PLUS_F9_IMPORT_BLOCK = """from strength import (
    handle_vimshopaka_bala         as st_handle_vimshopaka_bala,
    handle_planetary_summary       as st_handle_planetary_summary,
    handle_strength_comprehensive  as st_handle_comprehensive,
)


{MARKER_IMPORT}
from birthday_quick import (
    handle_birthday_quick     as bq_handle_quick,
    handle_birthday_headline  as bq_handle_headline,
)""".replace("{MARKER_IMPORT}", MARKER_IMPORT)


# Anchor: StrengthInput class (F3 marker)
STRENGTH_INPUT_ANCHOR = '''# ── F3: StrengthInput (2026-05-18) ──
class StrengthInput(BaseModel):
    """Input for /astro/strength/* endpoints."""
    birth: BirthInput'''

BIRTHDAY_INPUT_BLOCK = '''


{MARKER_INPUT_CLS}
class BirthdayInput(BaseModel):
    """Input for /astro/birthday/* endpoints."""
    birth: BirthInput
    query_date: Optional[str] = None    # YYYY-MM-DD; defaults to today'''.replace("{MARKER_INPUT_CLS}", MARKER_INPUT_CLS)


F9_ENDPOINT_BLOCK = '''


{MARKER_ENDPOINTS}

@app.post("/astro/birthday/quick", dependencies=[Depends(verify_key)])
def birthday_quick(b: BirthdayInput):
    """
    Full daily astrological snapshot for the native on query_date.

    Returns: panchang, active dasha (5 levels), tara state, transit highlights
    (Saturn/Jupiter/Rahu/Ketu houses from natal), auspicious + inauspicious
    daily yogas (Sarvartha Siddhi, Amrit Siddhi, Vish, Mrityu, Dwi/Tripushkar,
    Guru Pushya, Ravi Pushya), mood, and headline.

    query_date defaults to today. Accepts any YYYY-MM-DD for past/future queries.
    """
    try:
        birth_dict = {
            "dob": b.birth.dob, "time": b.birth.time,
            "lat": b.birth.lat, "lon": b.birth.lon,
            "timezone": b.birth.timezone,
        }
        return bq_handle_quick(birth_dict, query_date=b.query_date)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/birthday/headline", dependencies=[Depends(verify_key)])
def birthday_headline(b: BirthdayInput):
    """
    One-sentence summary of the day. Trimmed response for WhatsApp/push messages.

    Returns: {query_date, headline, mood, mood_emoji, key_signal}
    """
    try:
        birth_dict = {
            "dob": b.birth.dob, "time": b.birth.time,
            "lat": b.birth.lat, "lon": b.birth.lon,
            "timezone": b.birth.timezone,
        }
        return bq_handle_headline(birth_dict, query_date=b.query_date)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
'''.replace("{MARKER_ENDPOINTS}", MARKER_ENDPOINTS)


# ═══════════════════════════════════════════════════════════════════════
# Utilities
# ═══════════════════════════════════════════════════════════════════════

def fail(msg, restore_pairs=None):
    print(f"\n❌ ERROR: {msg}")
    if restore_pairs:
        for backup, target in restore_pairs:
            if backup and os.path.exists(backup):
                shutil.copy2(backup, target)
                print(f"   🔄 Restored {target} from {backup}")
    sys.exit(1)


def syntax_check(path, restore_pairs=None):
    try:
        py_compile.compile(path, doraise=True)
        print(f"   ✅ Syntax OK: {path}")
    except py_compile.PyCompileError as e:
        fail(f"Syntax error in {path}: {e}", restore_pairs=restore_pairs)


def smoke_test_as_trading():
    """Layered smoke INCLUDING main.py + F9 functional assertions."""
    smoke_script = r"""
import sys, traceback
sys.path.insert(0, '/opt/astro')
layers = [
    ('swisseph',       'swisseph'),
    ('dashaflow',      'dashaflow'),
    ('astro_helpers',  'astro_helpers'),
    ('compatibility',  'compatibility'),
    ('relationships',  'relationships'),
    ('nakshatra',      'nakshatra'),
    ('transit',        'transit'),
    ('eclipse',        'eclipse'),
    ('pitra_dosha',    'pitra_dosha'),
    ('strength',       'strength'),
    ('birthday_quick', 'birthday_quick'),
    ('main',           'main'),
]
for label, modname in layers:
    try:
        __import__(modname)
        print(f'OK    {label}')
    except Exception:
        print(f'FAIL  {label}')
        traceback.print_exc()
        sys.exit(1)

# Functional check: tara math
from birthday_quick import _compute_tara, _detect_daily_yogas
# Janma → Janma offset 0 → Janma tara (idx 1)
t = _compute_tara('Swati', 'Swati')
assert t['tara_idx'] == 1 and t['tara_name'] == 'Janma', f"Janma tara fail: {t}"
# Offset 1 → Sampat
t = _compute_tara('Vishakha', 'Swati')
assert t['tara_idx'] == 2 and t['tara_name'] == 'Sampat', f"Sampat tara fail: {t}"
# Offset 2 → Vipat
t = _compute_tara('Anuradha', 'Swati')
assert t['tara_idx'] == 3 and t['tara_name'] == 'Vipat', f"Vipat tara fail: {t}"
print('OK    F9 tara math sanity checks passed (3 cases)')

# Yoga detection: today's expected yogas (Monday + Mrigashira + Shukla Dwitiya)
sample_panchang = {
    'tithi':     {'number': 2, 'name': 'Dwitiya', 'paksha': 'Shukla'},
    'vara':      {'name': 'Monday', 'lord': 'Moon'},
    'nakshatra': {'name': 'Mrigashira', 'pada': 1, 'lord': 'Mars'},
    'yoga':      {'index': 6, 'name': 'Sukarma'},
    'karana':    'Kaulava',
}
y = _detect_daily_yogas(sample_panchang)
aus_names = [a['name'] for a in y['auspicious']]
# Monday + Mrigashira is in classical Sarvartha Siddhi AND Amrit Siddhi
assert 'Sarvartha Siddhi Yoga' in aus_names, f"Sarvartha Siddhi missing: got {aus_names}"
assert 'Amrit Siddhi Yoga' in aus_names, f"Amrit Siddhi missing: got {aus_names}"
# Monday tithi 2 is NOT Vish (Mon Vish: 6, 11) and NOT Mrityu (Mon Mrityu: 11)
inaus_names = [a['name'] for a in y['inauspicious']]
assert 'Vish Yoga' not in inaus_names, f"Vish should not fire: got {inaus_names}"
assert 'Mrityu Yoga' not in inaus_names, f"Mrityu should not fire: got {inaus_names}"
print(f'OK    F9 yoga detection sanity passed (Mon+Mrigashira+Tithi2): {len(aus_names)} aus, {len(inaus_names)} inaus')

import main
print(f'OK    main.app has {len(main.app.routes)} routes registered')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_script] if is_root
           else ["python3", "-c", smoke_script])
    result = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.stderr.strip():
        print(f"   ── stderr ──")
        for line in result.stderr.strip().split("\n"):
            print(f"   {line}")
    return result.returncode == 0


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════

def main():
    print("=" * 70)
    print("F9 — Birthday Quick Module Installer (2 endpoints)")
    print("=" * 70)

    if not os.path.exists(MAIN_PY):
        fail(f"{MAIN_PY} not found")
    if not os.path.exists(BIRTHDAY_PY):
        fail(f"{BIRTHDAY_PY} not found — scp it to /opt/astro/ first")
    print(f"✅ Found {BIRTHDAY_PY}")

    # Pre-check: birthday_quick.py imports cleanly
    print("\n── Pre-check: birthday_quick.py imports cleanly as user `trading` ──")
    smoke_pre = """
import sys
sys.path.insert(0, '/opt/astro')
import birthday_quick
print(f'birthday_quick loaded, public funcs: '
      f'{[n for n in dir(birthday_quick) if n.startswith("handle_")]}')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_pre] if is_root
           else ["python3", "-c", smoke_pre])
    r = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if r.returncode != 0:
        fail(f"birthday_quick.py failed to import:\n{r.stderr}\n{r.stdout}")
    print(f"   {r.stdout.strip()}")

    with open(MAIN_PY, "r") as f:
        content = f.read()
    orig_size = len(content)
    orig_lines = content.count("\n") + 1
    print(f"\nmain.py: {orig_size} bytes, {orig_lines} lines")

    # Idempotency
    if (MARKER_IMPORT in content
            and MARKER_INPUT_CLS in content
            and MARKER_ENDPOINTS in content):
        print("\n✅ All F9 markers already present — patch was applied. No changes.")
        return

    # Anchor validation
    if F3_IMPORT_TAIL not in content:
        fail("F3 import tail anchor not found in main.py — was F3 applied?")
    print("✅ F3 anchor confirmed")
    if STRENGTH_INPUT_ANCHOR not in content:
        fail("StrengthInput anchor not found in main.py — was F3 applied?")
    print("✅ StrengthInput anchor confirmed")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    main_backup = f"{MAIN_PY}.before_f9_{ts}"
    shutil.copy2(MAIN_PY, main_backup)
    print(f"✅ Backup: {main_backup}")

    # Phase B: Inject imports
    if MARKER_IMPORT not in content:
        content = content.replace(F3_IMPORT_TAIL, F3_PLUS_F9_IMPORT_BLOCK, 1)
        print("✅ Injected F9 import block after F3 imports")

    # Phase C: Inject BirthdayInput class
    if MARKER_INPUT_CLS not in content:
        content = content.replace(
            STRENGTH_INPUT_ANCHOR,
            STRENGTH_INPUT_ANCHOR + BIRTHDAY_INPUT_BLOCK,
            1
        )
        print("✅ Injected BirthdayInput class after StrengthInput")

    # Phase D: Append endpoints
    if MARKER_ENDPOINTS not in content:
        if not content.endswith("\n"):
            content += "\n"
        content += F9_ENDPOINT_BLOCK
        print("✅ Appended 2 F9 endpoint registrations")

    with open(MAIN_PY, "w") as f:
        f.write(content)
    new_size = len(content)
    new_lines = content.count("\n") + 1
    print(f"\n✅ Wrote main.py: {new_size} bytes ({new_size - orig_size:+d}), "
          f"{new_lines} lines ({new_lines - orig_lines:+d})")

    # Phase E: Snapshot + syntax
    snap = f"{MAIN_PY}.after_f9_{ts}"
    shutil.copy2(MAIN_PY, snap)
    print(f"✅ Snapshot: {snap}")
    syntax_check(MAIN_PY, restore_pairs=[(main_backup, MAIN_PY)])

    # Phase F: Full smoke with F9 functional assertions
    print("\n── Phase F: Layered smoke (as `trading`, INCLUDES main.py + F9 asserts) ──")
    ok = smoke_test_as_trading()
    if not ok:
        fail("Smoke test failed — rolling back",
             restore_pairs=[(main_backup, MAIN_PY)])

    print("\n" + "=" * 70)
    print("F9 PATCH APPLIED — next steps:")
    print("  sudo systemctl restart astro && sleep 3")
    print("  curl http://localhost:8001/astro/health      ← MUST return 200")
    print("  Then run verification sweep (see F9 runbook)")
    print("=" * 70)


if __name__ == "__main__":
    main()
