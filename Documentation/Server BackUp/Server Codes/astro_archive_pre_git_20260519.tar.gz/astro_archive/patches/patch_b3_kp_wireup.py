"""
patch_b3_kp_wireup.py — Round 2 of post-Phase-D cleanup.

PURPOSE:
    Wire B3 Prashna's KP horary endpoint to consume D4 KP Pro's full
    sub-lord computation. Previously B3 returned only the Ruling Planets
    framework with the explicit deferral:
        "...full sub-lord calc deferred to KP-specific computation library."
    Now that D4 provides it, B3 redeems that deferral.

WHAT CHANGES:
    1. Modifies /opt/astro/prashna.py:
       - Adds import for kp_handle_profile from kp_pro
       - Replaces kp_horary_endpoint() body to call kp_handle_profile()
         on a synthetic-birth dict built from the question moment
       - Synthesizes category-focused yes/no signal from cuspal sub-lords
       - Removes the "deferred" disclaimer
    2. No changes to main.py (endpoint signature preserved)
    3. Backward compatibility: response keeps existing keys + adds new ones

RESPONSE SHAPE AFTER PATCH:
    Old keys preserved (RP framework, classical metadata)
    NEW keys added:
        - kp_pro_analysis: full kp_handle_profile output at question moment
        - cuspal_sublords_for_category: sub-lord of each relevant cusp
        - kp_yes_no_signal: synthesis based on category houses' sub-lords
        - method: upgraded to reflect actual computation

EFFORT: ~30 minutes including build, deploy, and stress test.

Run from /opt/astro:
    sudo python3 patch_b3_kp_wireup.py

Idempotent: checks for marker before re-applying.
"""

import re
import sys
import os
import shutil
from datetime import datetime

PRASHNA_PY = "/opt/astro/prashna.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── B3 KP WIRE-UP (Round 2) ──"


# ════════════════════════════════════════════════════════════════════════
# NEW kp_horary_endpoint BODY
# Replaces the old one which had the "deferred" note.
# ════════════════════════════════════════════════════════════════════════

NEW_FUNCTION = '''# ── B3 KP WIRE-UP (Round 2) ──
# Was: returned RP framework only, with "deferred sub-lord computation" note.
# Now: consumes kp_handle_profile() from kp_pro.py for full sub-lord analysis
#      at the question moment, plus category-focused yes/no synthesis.
def kp_horary_endpoint(question_datetime: str, lat: float, lon: float,
                        category: str = "general",
                        timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """
    KP Horary (Prashna) analysis at the question moment.

    Casts the question-moment chart as a "synthetic birth" and runs full
    D4 KP Pro analysis on it: lagna sub-lord, planet sub-lords, all 12
    cuspal sub-lords (Placidus + Lahiri), birth ruling planets, and the
    4-level significator hierarchy.

    Then synthesizes a category-focused KP yes/no signal by examining
    the sub-lords of the cusps relevant to the question category.

    Classical source: K.S. Krishnamurti "Krishnamurti Paddhati" Vol 1-6.
    """
    # ── Build synthetic-birth dict from question moment ──
    dob, time_part = question_datetime.split("T") if "T" in question_datetime else (question_datetime, "12:00:00")
    time_hm = ":".join(time_part.split(":")[:2])
    synthetic_birth = {
        "dob":      dob,
        "time":     time_hm,
        "lat":      lat,
        "lon":      lon,
        "timezone": timezone,
    }

    # ── Run full D4 KP Pro at question moment ──
    kp_pro_analysis = kp_handle_profile(synthetic_birth)

    # ── Existing B3 metadata (kept for backward compat) ──
    weekday = _get_weekday(question_datetime)
    cat_data = QUESTION_CATEGORIES.get(category, QUESTION_CATEGORIES["general"])

    # Category house mapping from existing data
    houses_for_cat = KP_HORARY_SYSTEM["cuspal_sublord_principle"]["houses_for_questions"].get(category, {})
    positive_houses = houses_for_cat.get("positive", [])
    negative_houses = houses_for_cat.get("negative", [])

    # ── Extract cuspal sub-lords for relevant category houses ──
    all_cuspal_sublords = kp_pro_analysis.get("cuspal_sub_lords", {}).get("cuspal_sub_lords", {})
    cuspal_sublords_for_category = {}
    for house_num in positive_houses + negative_houses:
        house_key = f"house_{house_num}" if f"house_{house_num}" in all_cuspal_sublords else str(house_num)
        # Try multiple key formats kp_pro might use
        for candidate in [f"house_{house_num}", str(house_num), house_num]:
            if candidate in all_cuspal_sublords:
                cuspal_sublords_for_category[f"house_{house_num}"] = all_cuspal_sublords[candidate]
                break

    # ── KP yes/no synthesis ──
    # Classical rule: If sub-lords of POSITIVE houses signify the matter, YES.
    # If negative-house sub-lords are involved, NO or obstacles.
    positive_sublords_set = set()
    for h, data in cuspal_sublords_for_category.items():
        if int(h.replace("house_", "")) in positive_houses:
            if isinstance(data, dict):
                sl = data.get("sub_lord")
                if sl:
                    positive_sublords_set.add(sl)

    negative_sublords_set = set()
    for h, data in cuspal_sublords_for_category.items():
        if int(h.replace("house_", "")) in negative_houses:
            if isinstance(data, dict):
                sl = data.get("sub_lord")
                if sl:
                    negative_sublords_set.add(sl)

    # Get the 5 RPs from KP Pro
    brp = kp_pro_analysis.get("birth_ruling_planets", {})
    rps_unique = brp.get("unique_rps") if isinstance(brp, dict) else None
    if not rps_unique and isinstance(brp, dict):
        rps_unique = list({
            brp.get("lagna_sign_lord"),
            brp.get("lagna_star_lord"),
            brp.get("moon_sign_lord"),
            brp.get("moon_star_lord"),
            brp.get("day_lord"),
        } - {None})

    rps_set = set(rps_unique or [])

    # KP yes/no logic:
    # YES if positive-house sub-lords overlap with RPs (planets are "ready to deliver")
    # NO  if negative-house sub-lords overlap with RPs
    pos_rp_match = positive_sublords_set & rps_set
    neg_rp_match = negative_sublords_set & rps_set

    if pos_rp_match and not neg_rp_match:
        signal = "YES"
        reasoning = f"Positive-house sub-lord(s) {sorted(pos_rp_match)} match ruling planets"
    elif neg_rp_match and not pos_rp_match:
        signal = "NO"
        reasoning = f"Negative-house sub-lord(s) {sorted(neg_rp_match)} match ruling planets"
    elif pos_rp_match and neg_rp_match:
        signal = "MIXED"
        reasoning = f"Both positive ({sorted(pos_rp_match)}) and negative ({sorted(neg_rp_match)}) RP overlaps — outcome uncertain or delayed"
    else:
        signal = "INCONCLUSIVE"
        reasoning = "No RP overlap with positive or negative cuspal sub-lords — chart not ripe for prediction; consult again at different moment"

    return {
        # ── Backward-compatible keys ──
        "question_datetime":     question_datetime,
        "question_category":     category,
        "weekday":               weekday,
        "ruling_planets":        brp,  # now using KP Pro's 5-RP system
        "rp_use":                KP_HORARY_SYSTEM["ruling_planets_method"]["use"],
        "rp_method_components":  KP_HORARY_SYSTEM["ruling_planets_method"]["components"],
        "cuspal_principle":      KP_HORARY_SYSTEM["cuspal_sublord_principle"]["description"],
        "houses_for_category":   houses_for_cat,
        "house_groupings_kp":    KP_HORARY_SYSTEM["house_groupings_kp"],

        # ── NEW: full D4 KP Pro analysis at question moment ──
        "kp_pro_analysis":       kp_pro_analysis,

        # ── NEW: category-focused synthesis ──
        "cuspal_sublords_for_category": cuspal_sublords_for_category,
        "kp_yes_no_signal":      {
            "signal":     signal,
            "reasoning":  reasoning,
            "category":   category,
            "positive_houses":             positive_houses,
            "negative_houses":             negative_houses,
            "ruling_planets":              sorted(rps_set),
            "positive_house_sublords":     sorted(positive_sublords_set),
            "negative_house_sublords":     sorted(negative_sublords_set),
            "pos_rp_match":                sorted(pos_rp_match),
            "neg_rp_match":                sorted(neg_rp_match),
        },

        # ── Method + citation ──
        "method":            "Full KP horary via kp_pro D4: Placidus cusps + Lahiri ayanamsha + 249 sub-lord algorithm applied to question moment. Category synthesis via classical positive/negative house framework.",
        "classical_source":  "K.S. Krishnamurti 'Krishnamurti Paddhati' Vol 1-6; Vimshottari from BPHS.",
    }
# ── END B3 KP WIRE-UP ──
'''


# ════════════════════════════════════════════════════════════════════════
# REGEX TO LOCATE OLD FUNCTION
# ════════════════════════════════════════════════════════════════════════

# Find the entire old kp_horary_endpoint by anchor + boundary search
OLD_FUNCTION_START = 'def kp_horary_endpoint(question_datetime: str, lat: float, lon: float,'


def find_old_function_block(content: str) -> tuple:
    """Find (start, end) bounds of old kp_horary_endpoint by anchor + next-def search."""
    start_idx = content.find(OLD_FUNCTION_START)
    if start_idx == -1:
        return (None, None)

    search_from = start_idx + len(OLD_FUNCTION_START)
    next_def = content.find("\ndef ", search_from)
    next_section = content.find("\n# ════", search_from)

    candidates = [x for x in (next_def, next_section) if x != -1]
    if not candidates:
        end_idx = len(content)
    else:
        end_idx = min(candidates) + 1  # +1 to include the leading newline

    return (start_idx, end_idx)


# Import block insertion — add kp_handle_profile import after the prashna_data import
IMPORT_PATTERN = re.compile(
    r'(from prashna_data import \([^)]*\))',
    re.DOTALL
)
IMPORT_REPLACEMENT_SUFFIX = '''

# ── B3 KP WIRE-UP (Round 2) ─ Import KP Pro for full sub-lord computation ──
from kp_pro import handle_profile as kp_handle_profile'''


def main():
    if not os.path.exists(PRASHNA_PY):
        print(f"ERROR: {PRASHNA_PY} not found")
        sys.exit(1)

    with open(PRASHNA_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present in prashna.py.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/prashna.py.before_b3_kp_wireup_{ts}"
    shutil.copyfile(PRASHNA_PY, backup_path)
    print(f"✅ Backup written: {backup_path}")

    original_lines = len(content.split("\n"))
    print(f"   Original prashna.py: {original_lines} lines")
    print()

    # ── Step 1: Add import for kp_handle_profile ──
    if "from kp_pro import" in content:
        print("⚠️  Step 1/2: kp_pro import already present (idempotent skip)")
    elif IMPORT_PATTERN.search(content):
        content = IMPORT_PATTERN.sub(r"\1" + IMPORT_REPLACEMENT_SUFFIX, content, count=1)
        print("✅ Step 1/2: Added 'from kp_pro import handle_profile as kp_handle_profile'")
    else:
        print("ERROR: Could not locate prashna_data import to anchor new import")
        sys.exit(2)

    # ── Step 2: Replace old kp_horary_endpoint function ──
    start_idx, end_idx = find_old_function_block(content)
    if start_idx is None:
        print("ERROR: Could not locate old kp_horary_endpoint function")
        sys.exit(3)

    pre_line  = content[:start_idx].count("\n") + 1
    post_line = content[:end_idx].count("\n") + 1
    block_size = end_idx - start_idx
    print(f"✅ Step 2/2: Found old kp_horary_endpoint at lines {pre_line}-{post_line} ({block_size} chars)")

    content = content[:start_idx] + NEW_FUNCTION + content[end_idx:]
    print(f"            Replaced with new wired-up version (~150 lines)")

    # ── Final write ──
    with open(PRASHNA_PY, "w") as f:
        f.write(content)

    new_lines = len(content.split("\n"))
    delta = new_lines - original_lines
    print()
    print(f"✅ B3 KP Wire-Up complete.")
    print(f"   New prashna.py: {new_lines} lines (delta: {'+' if delta >= 0 else ''}{delta})")

    after_path = f"{BACKUP_DIR}/prashna.py.after_b3_kp_wireup_{ts}"
    shutil.copyfile(PRASHNA_PY, after_path)
    print(f"✅ After snapshot: {after_path}")


if __name__ == "__main__":
    main()
