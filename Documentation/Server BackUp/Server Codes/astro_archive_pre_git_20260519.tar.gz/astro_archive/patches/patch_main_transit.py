"""
patch_main_transit.py — Idempotent patch to wire 12 transit endpoints into main.py
(v2 — fixes verify_api_key → verify_key + matches existing main.py auth pattern)

Run from /opt/astro:
    sudo python3 patch_main_transit.py

Uses the proven Phase A/B insertion pattern:
    Anchor: ^app\\s*=\\s*FastAPI\\s*\\(   (column-0 MULTILINE regex)
    Imports inserted BEFORE this anchor
    Endpoint block APPENDED at end of file

Auth pattern verified from existing prashna/career endpoints in main.py:
    @app.post("/path")
    def handler(inp: SchemaInput, _: str = Depends(verify_key)):

Idempotent: detects existing marker and skips if already patched.
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── TRANSIT C0 MODULE ──"


IMPORT_BLOCK = '''
# ── TRANSIT C0 MODULE IMPORTS ──
from transit import (
    handle_profile               as transit_handle_profile,
    handle_current_positions     as transit_handle_current_positions,
    handle_personal_houses       as transit_handle_personal_houses,
    handle_sade_sati             as transit_handle_sade_sati,
    handle_jupiter_transit       as transit_handle_jupiter_transit,
    handle_saturn_transit        as transit_handle_saturn_transit,
    handle_rahu_ketu_transit     as transit_handle_rahu_ketu_transit,
    handle_eclipses_impact       as transit_handle_eclipses_impact,
    handle_gochara_phala         as transit_handle_gochara_phala,
    handle_ashtaka_varga_transit as transit_handle_ashtaka_varga_transit,
    handle_major_alerts_12months as transit_handle_major_alerts_12months,
    handle_retrograde_periods    as transit_handle_retrograde_periods,
)
# ── END TRANSIT C0 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── TRANSIT C0 MODULE ──
# Phase C0 — Transit Engine (12 endpoints)
# Sources: BPHS Ch. 41, Phaladeepika Ch. 26-27, Saravali Ch. 39, BPHS Ch. 67
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _TransitBaseModel
from typing import Optional as _TransitOptional

class TransitInput(_TransitBaseModel):
    birth: BirthInput
    transit_date: _TransitOptional[str] = None      # ISO "YYYY-MM-DD"; default = today
    transit_time: _TransitOptional[str] = "12:00"   # HH:MM; default = midday


def _transit_birth_dict(birth: BirthInput) -> dict:
    return {
        "dob":      birth.dob,
        "time":     birth.time,
        "lat":      birth.lat,
        "lon":      birth.lon,
        "timezone": birth.timezone,
    }


@app.post("/astro/transit/profile")
def transit_profile_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Master transit overview synthesizing all key transit signals."""
    return transit_handle_profile(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/current_positions")
def transit_current_positions_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """All 9 planets' current sidereal positions for transit moment."""
    return transit_handle_current_positions(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/personal_houses")
def transit_personal_houses_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Planets transiting through native's natal houses (from Lagna + from Moon)."""
    return transit_handle_personal_houses(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/sade_sati")
def transit_sade_sati_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Saturn Sade Sati exact phase + remediation guidance."""
    return transit_handle_sade_sati(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/jupiter_transit")
def transit_jupiter_transit_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Current Jupiter transit + house-from-Lagna effects + AV strength."""
    return transit_handle_jupiter_transit(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/saturn_transit")
def transit_saturn_transit_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Saturn deep transit analysis with Sade Sati cross-reference + AV strength."""
    return transit_handle_saturn_transit(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/rahu_ketu_transit")
def transit_rahu_ketu_transit_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Rahu-Ketu nodal axis transit (~18 month cadence)."""
    return transit_handle_rahu_ketu_transit(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/eclipses_impact")
def transit_eclipses_impact_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Eclipse axis (Rahu/Ketu) proximity to natal Sun/Moon/Lagna."""
    return transit_handle_eclipses_impact(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/gochara_phala")
def transit_gochara_phala_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Classical Gochara Phala per planet (with Vedha blockage check)."""
    return transit_handle_gochara_phala(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/ashtaka_varga_transit")
def transit_ashtaka_varga_transit_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Bhinnashtaka + Sarvashtaka Varga strength of current transits."""
    return transit_handle_ashtaka_varga_transit(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/major_alerts_12months")
def transit_major_alerts_12months_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Major transit events forecasted for next 12 months (quarterly sampling)."""
    return transit_handle_major_alerts_12months(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )


@app.post("/astro/transit/retrograde_periods")
def transit_retrograde_periods_ep(inp: TransitInput, _: str = Depends(verify_key)):
    """Personal impact of current retrograde periods (Mercury/Venus/Mars/Jupiter/Saturn)."""
    return transit_handle_retrograde_periods(
        _transit_birth_dict(inp.birth),
        inp.transit_date, inp.transit_time,
    )

# ── END TRANSIT C0 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    # Idempotency check
    if MARKER in content:
        print(f"SKIP: {MARKER} already present in main.py. Patch already applied.")
        sys.exit(0)

    # Backup
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_transit_c0_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    # Find safe insertion point: ^app\s*=\s*FastAPI\s*\(
    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor in main.py — refusing to patch")
        sys.exit(2)
    insertion_point = match.start()

    # Inject imports before app = FastAPI(
    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    # Append endpoint block at end
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    # Save "after" snapshot too
    after_path = f"{BACKUP_DIR}/main.py.after_transit_c0_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ Transit C0 module patched into main.py (v2 — verify_key auth)")
    print("   12 endpoints under /astro/transit/*")
    print("   Restart with: sudo systemctl restart astro")


if __name__ == "__main__":
    main()
