"""
main_patches_nakshatra.py — Source-of-truth for what gets patched into main.py.

The auto-patcher (patch_main_nakshatra.py) reads these BLOCK markers and
injects them at the right places in main.py:

  BLOCK A: imports (top of file after existing imports)
  BLOCK B: Pydantic models (after existing models)
  BLOCK C: endpoint functions (before "@app.on_event" or at end of routes)
"""

# ─────────────────────────────────────────────────────────────────────────────
# BLOCK A: IMPORTS (added near top of main.py)
# ─────────────────────────────────────────────────────────────────────────────
BLOCK_A_IMPORTS = '''
# === BEGIN NAKSHATRA IMPORTS ===
from nakshatra import (
    analyze_full         as nakshatra_analyze_full,
    analyze_janma        as nakshatra_analyze_janma,
    analyze_all_planets  as nakshatra_analyze_all_planets,
    analyze_tara         as nakshatra_analyze_tara,
    analyze_compatibility as nakshatra_analyze_compatibility,
    get_static           as nakshatra_get_static,
)
# === END NAKSHATRA IMPORTS ===
'''

# ─────────────────────────────────────────────────────────────────────────────
# BLOCK B: PYDANTIC MODELS (added after existing models)
# ─────────────────────────────────────────────────────────────────────────────
BLOCK_B_MODELS = '''
# === BEGIN NAKSHATRA MODELS ===
class NakshatraCompatibilityInput(BaseModel):
    nak1: str
    nak2: str
# === END NAKSHATRA MODELS ===
'''

# ─────────────────────────────────────────────────────────────────────────────
# BLOCK C: ENDPOINTS (added at end of route definitions, before lifecycle hooks)
# ─────────────────────────────────────────────────────────────────────────────
BLOCK_C_ENDPOINTS = '''
# === BEGIN NAKSHATRA ENDPOINTS ===

@app.post("/astro/nakshatra")
async def nakshatra_full(birth: BirthInput, _: str = Depends(verify_api_key)):
    """Full nakshatra analysis: Janma + Surya + Lagna + all 9 planets summary."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, tz=birth.timezone,
        )
        return nakshatra_analyze_full(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Nakshatra analysis failed: {str(e)}")


@app.post("/astro/nakshatra/janma")
async def nakshatra_janma(birth: BirthInput, _: str = Depends(verify_api_key)):
    """Janma (Moon) nakshatra deep dive — the foundational reading."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, tz=birth.timezone,
        )
        return nakshatra_analyze_janma(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Janma analysis failed: {str(e)}")


@app.post("/astro/nakshatra/all_planets")
async def nakshatra_all_planets(birth: BirthInput, _: str = Depends(verify_api_key)):
    """Full 16-attribute + 9-pada-sub-attribute analysis for all 9 planets (heavy payload)."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, tz=birth.timezone,
        )
        return nakshatra_analyze_all_planets(chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"All-planets analysis failed: {str(e)}")


@app.post("/astro/nakshatra/tara")
async def nakshatra_tara(birth: BirthInput, _: str = Depends(verify_api_key)):
    """27-Tara cycle from Janma + current Moon transit Tara."""
    try:
        chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, tz=birth.timezone,
        )
        # Build a transit chart for today for current-tara lookup
        from datetime import datetime
        now = datetime.now()
        transit_chart = cast_chart(
            dob=now.strftime("%Y-%m-%d"),
            time=now.strftime("%H:%M"),
            lat=birth.lat, lon=birth.lon, tz=birth.timezone,
        )
        return nakshatra_analyze_tara(chart, transit_chart=transit_chart)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Tara analysis failed: {str(e)}")


@app.post("/astro/nakshatra/compatibility")
async def nakshatra_compatibility(
    inp: NakshatraCompatibilityInput,
    _: str = Depends(verify_api_key),
):
    """Quick 4-factor nakshatra compatibility (Gana/Nadi/Yoni/Varna)."""
    try:
        return nakshatra_analyze_compatibility(inp.nak1, inp.nak2)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Compatibility failed: {str(e)}")


@app.get("/astro/nakshatra/static/{name}")
async def nakshatra_static(
    name: str, pada: int = 1,
    _: str = Depends(verify_api_key),
):
    """Pure encyclopedia lookup — no birth chart needed. Used by the chat app."""
    try:
        return nakshatra_get_static(name, pada)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Static lookup failed: {str(e)}")


# === END NAKSHATRA ENDPOINTS ===
'''
