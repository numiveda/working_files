"""
patch_F10P2_rectification.py — F10-P2 installer

Adds Approach A (Parashari event correlation) + Approach B (Tattva).

Follows §5.1 locked installer template, hardened by P1's lessons:
  - Lesson #8 (P1 v1): Append-to-EOF, no anchor search
  - Lesson #9 (P1 v2): .replace() not .format() for marker substitution
  - Lesson #10 (P1 v2): AST-verify import names at module scope
  - Lesson #11 (P1 v3 module): HH:MM only — already handled by reusing
    _p1._build_candidate_times which now returns correct format

What this patch adds:
  - import rectification_p2        (Phase C)
  - Pydantic models:               (Phase D)
      * EventInputP2 (reused shape from P1's EventInput)
      * EventBasedRectificationInput(StrictBirthInput)
      * TattvaRectificationInput(StrictBirthInput)
  - 3 route handlers:              (Phase E)
      * POST /astro/rectification/event_based
      * POST /astro/rectification/tattva
      * GET  /astro/rectification/supported_tattvas
"""

import os
import sys
import ast
import shlex
import shutil
import subprocess
import time

# ============================================================================
# Constants
# ============================================================================

ASTRO_DIR     = "/opt/astro"
MAIN_PY       = os.path.join(ASTRO_DIR, "main.py")
MODULE_PY     = os.path.join(ASTRO_DIR, "rectification_p2.py")
P1_MODULE_PY  = os.path.join(ASTRO_DIR, "rectification.py")  # must exist first
PATCH_NAME    = "F10P2_rectification"
TIMESTAMP     = time.strftime("%Y%m%d_%H%M%S")
BACKUP_PATH   = f"{MAIN_PY}.before_{PATCH_NAME}_{TIMESTAMP}"
SNAPSHOT_PATH = f"{MAIN_PY}.after_{PATCH_NAME}_{TIMESTAMP}"
MARKER        = "# ── F10-P2: BTR Approaches A (Parashari) + B (Tattva) (2026-05-18) ──"

IMPORT_LINE = "import rectification_p2  # F10-P2"

# Also need the F10-P1 marker for idempotency check (P2 requires P1 to be live)
P1_MARKER_CHECK = "# ── F10-P1: Birth Time Rectification (KP-based)"

# ============================================================================
# Logging helpers
# ============================================================================

def log(msg: str) -> None:
    print(f"[{PATCH_NAME}] {msg}", flush=True)


def fail(msg: str) -> None:
    log(f"FAIL: {msg}")
    sys.exit(1)


def run_as_trading_user(python_code: str) -> None:
    quoted_py = shlex.quote(python_code)
    shell_cmd = f"cd {shlex.quote(ASTRO_DIR)} && python3 -c {quoted_py}"
    subprocess.check_call(["sudo", "-u", "trading", "bash", "-c", shell_cmd])


def chown_to_trading(path: str) -> None:
    try:
        subprocess.check_call(["chown", "trading:trading", path])
    except subprocess.CalledProcessError as e:
        log(f"WARNING: chown {path} failed: {e}")


# ============================================================================
# Phase A — preflight
# ============================================================================

def phase_a_preflight() -> None:
    log("Phase A: preflight (append-mode, append-only since P1)")

    if not os.path.isfile(MAIN_PY):
        fail(f"main.py not found at {MAIN_PY}")

    if not os.path.isfile(MODULE_PY):
        fail(f"rectification_p2.py not found at {MODULE_PY} — scp it first")

    if not os.path.isfile(P1_MODULE_PY):
        fail(f"rectification.py (P1) not found at {P1_MODULE_PY} — apply F10-P1 first")
    log("Phase A.2: F10-P1 module present (rectification.py)")

    try:
        with open(MODULE_PY) as f:
            ast.parse(f.read())
    except SyntaxError as e:
        fail(f"rectification_p2.py has SyntaxError: {e}")
    log("Phase A.3: rectification_p2.py syntax OK")

    try:
        with open(MAIN_PY) as f:
            ast.parse(f.read())
    except SyntaxError as e:
        fail(f"main.py has pre-existing SyntaxError: {e}")
    log("Phase A.4: main.py baseline syntax OK")

    with open(MAIN_PY) as f:
        main_src = f.read()

    # Idempotency: P2 marker absent
    if MARKER in main_src:
        fail(f"P2 marker already present in main.py: {MARKER!r}")
    log("Phase A.5: P2 marker absent (not previously patched)")

    if IMPORT_LINE in main_src:
        fail(f"P2 import line already present: {IMPORT_LINE!r}")
    log("Phase A.6: P2 import line absent")

    # P1 must already be installed (P2 reuses _p1.* helpers via the route handlers
    # which call rectification_p2.handle_*; those call into rectification.* internally)
    if P1_MARKER_CHECK not in main_src:
        fail(
            "F10-P1 marker not found in main.py — P2 depends on P1's "
            "rectification module being installed first."
        )
    log("Phase A.7: F10-P1 marker present (P1 confirmed live)")

    if "class StrictBirthInput" not in main_src:
        fail("StrictBirthInput class not found — F5-U1 must be applied first")
    log("Phase A.8: StrictBirthInput present (F5-U1 confirmed)")

    if "verify_key" not in main_src:
        fail("verify_key dependency not found in main.py")
    log("Phase A.9: verify_key dependency present")

    # Lesson #10: AST-verify required names at module scope
    required_names = ("BaseModel", "ConfigDict", "Depends", "HTTPException")
    main_tree = ast.parse(main_src)
    bound_at_module_scope = set()
    for node in main_tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                bound_at_module_scope.add(alias.asname or alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                bound_at_module_scope.add(alias.asname or alias.name)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for t in targets:
                if isinstance(t, ast.Name):
                    bound_at_module_scope.add(t.id)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            bound_at_module_scope.add(node.name)

    missing = [n for n in required_names if n not in bound_at_module_scope]
    if missing:
        fail(f"Required names not bound at module scope: {missing}")
    log(f"Phase A.10: required names bound at module scope: {required_names}")

    log("Phase A: PASSED")


# ============================================================================
# Phase B — backup
# ============================================================================

def phase_b_backup() -> None:
    log("Phase B: backup main.py")
    shutil.copy2(MAIN_PY, BACKUP_PATH)
    log(f"Phase B: backup at {BACKUP_PATH}")


# ============================================================================
# Insertion block (C/D/E combined)
# ============================================================================

INSERTION_BLOCK = '''

__MARKER__
import rectification_p2  # F10-P2


class EventInputP2(BaseModel):
    model_config = ConfigDict(extra="forbid")
    event_type: str
    event_date: str  # YYYY-MM-DD
    weight: float = 1.0


class EventBasedRectificationInput(StrictBirthInput):
    # Inherits dob, time, lat, lon, timezone + extra=forbid from StrictBirthInput
    events: list[EventInputP2]
    scan_window_minutes: int = 120
    scan_granularity_minutes: int = 1
    top_n: int = 5


class TattvaRectificationInput(StrictBirthInput):
    observed_tattva: str  # one of: fire, earth, air, water, ether
    scan_window_minutes: int = 120
    scan_granularity_minutes: int = 1


@app.post(
    "/astro/rectification/event_based",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p2_event_based_rectification(payload: EventBasedRectificationInput):
    try:
        events_dicts = [
            {"event_type": e.event_type, "event_date": e.event_date, "weight": e.weight}
            for e in payload.events
        ]
        result = rectification_p2.handle_event_based_rectification(
            dob=payload.dob,
            time=payload.time,
            lat=payload.lat,
            lon=payload.lon,
            timezone=payload.timezone,
            events=events_dicts,
            scan_window_minutes=payload.scan_window_minutes,
            scan_granularity_minutes=payload.scan_granularity_minutes,
            top_n=payload.top_n,
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Event-based rectification failed: {exc}")


@app.post(
    "/astro/rectification/tattva",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p2_tattva_rectification(payload: TattvaRectificationInput):
    try:
        result = rectification_p2.handle_tattva_rectification(
            dob=payload.dob,
            time=payload.time,
            lat=payload.lat,
            lon=payload.lon,
            timezone=payload.timezone,
            observed_tattva=payload.observed_tattva,
            scan_window_minutes=payload.scan_window_minutes,
            scan_granularity_minutes=payload.scan_granularity_minutes,
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Tattva rectification failed: {exc}")


@app.get(
    "/astro/rectification/supported_tattvas",
    dependencies=[Depends(verify_key)],
    tags=["rectification"],
)
def f10p2_supported_tattvas():
    return rectification_p2.handle_supported_tattvas()
'''


def build_insertion_text() -> str:
    return INSERTION_BLOCK.replace("__MARKER__", MARKER)


# ============================================================================
# Phase F — write + verify + auto-rollback
# ============================================================================

def phase_f_write_and_verify() -> None:
    log("Phase F: write + verify (append mode)")

    with open(MAIN_PY) as f:
        original = f.read()

    if not original.endswith("\n"):
        original = original + "\n"

    insertion = build_insertion_text()
    new_src = original + insertion

    if len(new_src) <= len(original):
        fail("Phase F: append produced no growth — aborting")

    tmp_path = MAIN_PY + ".tmp"
    with open(tmp_path, "w") as f:
        f.write(new_src)
    os.replace(tmp_path, MAIN_PY)
    chown_to_trading(MAIN_PY)
    log(f"Phase F: main.py written ({len(original)} → {len(new_src)} bytes)")

    # F.1 — syntax
    try:
        run_as_trading_user(
            "import ast; "
            "src = open('/opt/astro/main.py').read(); "
            "ast.parse(src); "
            "print('syntax_ok')"
        )
    except subprocess.CalledProcessError:
        log("Phase F.1 FAIL: syntax check failed — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        fail("Phase F.1: SyntaxError in patched main.py — rolled back")
    log("Phase F.1: syntax check OK")

    # F.2 — smoke (single_input grammar, no top-level compounds per Lesson #3)
    smoke = (
        "import rectification_p2 as rp2; "
        "assert hasattr(rp2, 'handle_event_based_rectification'), 'handle_event_based_rectification missing'; "
        "assert hasattr(rp2, 'handle_tattva_rectification'), 'handle_tattva_rectification missing'; "
        "assert hasattr(rp2, 'handle_supported_tattvas'), 'handle_supported_tattvas missing'; "
        "assert callable(rp2.handle_event_based_rectification), 'handle_event_based_rectification not callable'; "
        "r = rp2.handle_supported_tattvas(); "
        "assert isinstance(r, dict) and 'supported_tattvas' in r, 'supported_tattvas bad shape'; "
        "assert 'fire' in r['supported_tattvas'] and 'ether' in r['supported_tattvas'], 'tattva list wrong'; "
        "import main; "
        "assert hasattr(main, 'f10p2_event_based_rectification'), 'event_based route missing on main'; "
        "assert hasattr(main, 'f10p2_tattva_rectification'), 'tattva route missing on main'; "
        "assert hasattr(main, 'f10p2_supported_tattvas'), 'supported_tattvas route missing on main'; "
        "print('smoke_ok')"
    )

    try:
        run_as_trading_user(smoke)
    except subprocess.CalledProcessError:
        log("Phase F.2 FAIL: smoke test failed — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        fail("Phase F.2: smoke test failed — rolled back")
    log("Phase F.2: smoke OK")

    # F.3 — service restart + health check
    log("Phase F.3: restarting astro service")
    try:
        subprocess.check_call(["systemctl", "restart", "astro"])
    except subprocess.CalledProcessError as e:
        log(f"Phase F.3 FAIL: systemctl restart failed: {e}")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        subprocess.call(["systemctl", "restart", "astro"])
        fail("Phase F.3: service restart failed — rolled back")
    time.sleep(3)

    try:
        out = subprocess.check_output(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             "http://localhost:8001/astro/health"],
            timeout=10,
        ).decode().strip()
    except subprocess.CalledProcessError as e:
        out = f"curl_failed:{e}"

    if out != "200":
        log(f"Phase F.3 FAIL: /astro/health returned {out!r} — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        subprocess.call(["systemctl", "restart", "astro"])
        fail(f"Phase F.3: health check returned {out!r} — rolled back")
    log("Phase F.3: /astro/health = 200")

    # F.4 — verify new endpoints registered
    try:
        endpoints_out = subprocess.check_output(
            ["curl", "-s", "http://localhost:8001/openapi.json"],
            timeout=10,
        ).decode()
    except subprocess.CalledProcessError as e:
        log(f"Phase F.4 WARN: openapi fetch failed: {e}")
        endpoints_out = ""

    expected_endpoints = [
        "/astro/rectification/event_based",
        "/astro/rectification/tattva",
        "/astro/rectification/supported_tattvas",
    ]
    for ep in expected_endpoints:
        if ep not in endpoints_out:
            log(f"Phase F.4 FAIL: {ep} not in openapi.json — auto-rollback")
            shutil.copy2(BACKUP_PATH, MAIN_PY)
            chown_to_trading(MAIN_PY)
            subprocess.call(["systemctl", "restart", "astro"])
            fail(f"Phase F.4: endpoint {ep} not registered — rolled back")
        log(f"Phase F.4: {ep} registered")

    # F.5 — snapshot
    shutil.copy2(MAIN_PY, SNAPSHOT_PATH)
    log(f"Phase F.5: snapshot at {SNAPSHOT_PATH}")

    log("Phase F: PASSED")


# ============================================================================
# Main
# ============================================================================

def main():
    log(f"Starting {PATCH_NAME} at {TIMESTAMP}")
    if os.geteuid() != 0:
        fail("Must run as root (use sudo)")

    phase_a_preflight()
    phase_b_backup()
    phase_f_write_and_verify()

    log("=" * 60)
    log(f"{PATCH_NAME}: SUCCESS")
    log(f"Backup:   {BACKUP_PATH}")
    log(f"Snapshot: {SNAPSHOT_PATH}")
    log("New endpoints:")
    log("  POST /astro/rectification/event_based")
    log("  POST /astro/rectification/tattva")
    log("  GET  /astro/rectification/supported_tattvas")
    log("Engine: 321 → 324 endpoints")
    log("=" * 60)


if __name__ == "__main__":
    main()
