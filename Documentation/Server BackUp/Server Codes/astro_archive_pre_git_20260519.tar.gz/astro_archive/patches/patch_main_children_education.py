"""
patch_main_children_education.py — Wires 8 C5 endpoints into main.py.

5 endpoints under /astro/children/*, 3 under /astro/education/*.
Uses verify_key auth. Idempotent.

Run from /opt/astro:
    sudo python3 patch_main_children_education.py
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── CHILDREN/EDUCATION C5 MODULE ──"


IMPORT_BLOCK = '''
# ── CHILDREN/EDUCATION C5 MODULE IMPORTS ──
from children_education import (
    handle_children_profile     as c5_handle_children_profile,
    handle_5th_house_analysis   as c5_handle_5th_house,
    handle_conception_timing    as c5_handle_conception_timing,
    handle_d7_saptamsha         as c5_handle_d7_saptamsha,
    handle_putra_dosha          as c5_handle_putra_dosha,
    handle_education_profile    as c5_handle_education_profile,
    handle_4th_5th_synthesis    as c5_handle_4th_5th_synthesis,
    handle_foreign_study_yoga   as c5_handle_foreign_study_yoga,
)
# ── END CHILDREN/EDUCATION C5 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── CHILDREN/EDUCATION C5 MODULE ──
# Phase C — Module C5 — 5th house deep-dive (children) + Education (8 endpoints)
# Sources: BPHS Ch. 28, Saravali Ch. 35, Phaladeepika Ch. 9, Sarvartha Chintamani Ch. 14
# ════════════════════════════════════════════════════════════════════════

def _c5_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/children/profile")
def c5_children_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master children analysis — 5th house + Putra Dosha + D7 + conception timing synthesis."""
    return c5_handle_children_profile(_c5_birth_dict(inp))


@app.post("/astro/children/5th_house_analysis")
def c5_5th_house_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """5th house deep-dive — sign, lord, occupants, aspects."""
    return c5_handle_5th_house(_c5_birth_dict(inp))


@app.post("/astro/children/conception_timing")
def c5_conception_timing_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Conception-favorable dasha windows (Jupiter, 5th lord, Moon, Venus periods)."""
    return c5_handle_conception_timing(_c5_birth_dict(inp))


@app.post("/astro/children/d7_saptamsha")
def c5_d7_saptamsha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """D7 Saptamsha (children-specific divisional chart) synthesis."""
    return c5_handle_d7_saptamsha(_c5_birth_dict(inp))


@app.post("/astro/children/putra_dosha")
def c5_putra_dosha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Putra Dosha detection — 5 classical patterns + severity + remedies."""
    return c5_handle_putra_dosha(_c5_birth_dict(inp))


@app.post("/astro/education/profile")
def c5_education_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master education analysis — Mercury/Jupiter karakas + house synthesis + foreign-study."""
    return c5_handle_education_profile(_c5_birth_dict(inp))


@app.post("/astro/education/4th_5th_synthesis")
def c5_education_4th_5th_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """2/4/5/9 house education synthesis + Saraswati/Budhaditya yoga detection."""
    return c5_handle_4th_5th_synthesis(_c5_birth_dict(inp))


@app.post("/astro/education/foreign_study_yoga")
def c5_education_foreign_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Foreign education yoga detection — 6 classical patterns + strength rollup."""
    return c5_handle_foreign_study_yoga(_c5_birth_dict(inp))

# ── END CHILDREN/EDUCATION C5 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present in main.py.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_c5_children_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_c5_children_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ Children/Education C5 module patched into main.py")
    print("   8 endpoints: 5 under /astro/children/* + 3 under /astro/education/*")
    print("   This is the FINAL Phase C module — engine reaches 208 endpoints!")


if __name__ == "__main__":
    main()
