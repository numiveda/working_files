#!/usr/bin/env python3
"""
patch_u10_hygiene.py
─────────────────────────────────────────────────────────────────────────
U10 — Hygiene Pass (3 fixes)

Scope:
  Fix 2 (smallest risk first): rename ascendant_lord → lagna_lord in
         relationships.py. F1a was reading a non-existent field;
         extract_chart_essentials returns lagna_lord (Sanskrit-correct).

  Fix 3 (low risk):  delete dead CompatibilityInput class at main.py:490.
         Phase A leftover; superseded by the Phase C class at line 2419
         which is the live one (used by /astro/compat/profile and others).

  Fix 1 (additive):  add /astro/nakshatra/compatibility_from_birth endpoint.
         Existing /astro/nakshatra/compatibility takes raw nakshatra names
         which is inconsistent with the rest of the engine. New endpoint
         accepts standard BirthInput pair, extracts Moon nakshatras, and
         delegates to the same analyze_compatibility() function.

DELIBERATELY OUT OF SCOPE:
  - Move of /opt/astro/main.py line-2419 CompatibilityInput class.
    The line-2419 class is inside the deliberate Phase C module
    namespacing block (lines 2409-2414). Moving it up to the top-level
    Pydantic section would collapse that boundary and erase Phase C
    architectural intent. NOT a move worth making.

Phases (each with own anchor checks; later phases skip if earlier failed):
  PHASE A — Fix 2 (relationships.py)
  PHASE B — Fix 3 (delete dead class in main.py)
  PHASE C — Fix 1 (new endpoint in main.py)
  PHASE D — Syntax check on both modified files
  PHASE E — Verify import smoke as user `trading`

Idempotent. Backups before/after with timestamps. Auto-rollback on any
syntax or smoke failure.

Usage:
  sudo python3 /opt/astro/patch_u10_hygiene.py

Author: Claude (U10, 2026-05-17)
"""

import os
import sys
import shutil
import subprocess
import py_compile
from datetime import datetime

MAIN_PY          = "/opt/astro/main.py"
RELATIONSHIPS_PY = "/opt/astro/relationships.py"

# Unique markers for each fix
MARKER_FIX2 = "# ── U10 fix-2: lagna_lord rename ──"
MARKER_FIX3 = "# ── U10 fix-3: dead CompatibilityInput removed ──"
MARKER_FIX1 = "# ── U10 fix-1: /astro/nakshatra/compatibility_from_birth ──"

# ═══════════════════════════════════════════════════════════════════════
# FIX 2 — Anchor + replacement in relationships.py
# ═══════════════════════════════════════════════════════════════════════
# Anchor: the _safe_essentials_summary function in relationships.py
# Currently uses "ascendant_lord" key — extract_chart_essentials returns
# "lagna_lord". Single-field rename.

FIX2_OLD = '        "ascendant_lord":   essentials.get("ascendant_lord"),'
FIX2_NEW = ('        "lagna_lord":      essentials.get("lagna_lord"),'
            '  ' + MARKER_FIX2)

# ═══════════════════════════════════════════════════════════════════════
# FIX 3 — Anchor + replacement in main.py
# ═══════════════════════════════════════════════════════════════════════
# The dead class at lines 490-492. Confirmed dead because Phase C
# defines a richer CompatibilityInput at line 2419 that overrides it.
# Anchor uses surrounding context (the line right before + right after
# the class) so it's uniquely identifiable.

FIX3_OLD = """class CompatibilityInput(BaseModel):
    person1: BirthInput
    person2: BirthInput


class MuhurthaInput(BaseModel):"""

FIX3_NEW = MARKER_FIX3 + "\nclass MuhurthaInput(BaseModel):"

# ═══════════════════════════════════════════════════════════════════════
# FIX 1 — New endpoint registration to append to main.py
# ═══════════════════════════════════════════════════════════════════════
# Reuses existing NakshatraCompatibilityInput model is not appropriate
# here since we want BirthInput. We add a small model + endpoint.

FIX1_BLOCK = '''


{MARKER_FIX1}
class NakshatraCompatFromBirthInput(BaseModel):
    person1: BirthInput
    person2: BirthInput


@app.post("/astro/nakshatra/compatibility_from_birth")
async def nakshatra_compatibility_from_birth(
    inp: NakshatraCompatFromBirthInput,
    _: str = Depends(verify_key),
):
    """
    BirthInput-shaped variant of /astro/nakshatra/compatibility.

    Casts both charts, extracts each native's Moon nakshatra, and runs
    the same 4-factor (Gana/Nadi/Yoni/Varna) classical analysis.
    Lets callers use the standard person1/person2 birth payload that
    every other compatibility endpoint accepts, instead of pre-computing
    nakshatra names.

    For pre-computed nakshatra-name inputs, /astro/nakshatra/compatibility
    remains available (and unchanged).
    """
    try:
        from nakshatra import analyze_compatibility
        c1 = cast_chart(
            dob=inp.person1.dob, time=inp.person1.time,
            lat=inp.person1.lat, lon=inp.person1.lon,
            timezone=inp.person1.timezone,
        )
        c2 = cast_chart(
            dob=inp.person2.dob, time=inp.person2.time,
            lat=inp.person2.lat, lon=inp.person2.lon,
            timezone=inp.person2.timezone,
        )
        nak1 = c1["planets"]["Moon"].get("nakshatra")
        nak2 = c2["planets"]["Moon"].get("nakshatra")
        if not (nak1 and nak2):
            raise HTTPException(
                status_code=500,
                detail=(f"Could not extract Moon nakshatra from one or both "
                        f"charts (got: p1={nak1!r}, p2={nak2!r})"),
            )
        result = analyze_compatibility(nak1, nak2)
        return {
            "success": True,
            "person1_moon_nakshatra": nak1,
            "person2_moon_nakshatra": nak2,
            "data": result,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Nakshatra-from-birth compatibility failed: {e}",
        )
'''.replace("{MARKER_FIX1}", MARKER_FIX1)


# ═══════════════════════════════════════════════════════════════════════
# Utilities
# ═══════════════════════════════════════════════════════════════════════

def fail(msg, restore_pairs=None):
    """Print error; if restore_pairs is provided as [(backup, target), ...],
    restore each before exiting."""
    print(f"\n❌ ERROR: {msg}")
    if restore_pairs:
        for backup, target in restore_pairs:
            if backup and os.path.exists(backup):
                shutil.copy2(backup, target)
                print(f"   🔄 Restored {target} from {backup}")
    sys.exit(1)


def syntax_check(path, restore_pairs=None):
    """Validate Python syntax; restore-on-fail if pairs given."""
    try:
        py_compile.compile(path, doraise=True)
        print(f"   ✅ Syntax OK: {path}")
    except py_compile.PyCompileError as e:
        fail(f"Syntax error in {path}: {e}", restore_pairs=restore_pairs)


def smoke_test_as_trading():
    """Layered smoke test as user trading (mirrors astro service env)."""
    smoke_script = """
import sys
sys.path.insert(0, '/opt/astro')
layers = [
    ('swisseph',      'swisseph'),
    ('dashaflow',     'dashaflow'),
    ('astro_helpers', 'astro_helpers'),
    ('compatibility', 'compatibility'),
    ('relationships', 'relationships'),
    ('nakshatra',     'nakshatra'),
]
for label, modname in layers:
    try:
        m = __import__(modname)
        print(f'OK    {label}')
    except Exception as e:
        print(f'FAIL  {label} {type(e).__name__}: {e}')
        sys.exit(1)
# Verify F1a handlers still importable
from relationships import handle_friendship, handle_mentor, handle_family
# Verify nakshatra.analyze_compatibility still importable
from nakshatra import analyze_compatibility
print('OK    handlers + nakshatra.analyze_compatibility')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_script] if is_root
           else ["python3", "-c", smoke_script])
    result = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.stderr.strip():
        print(f"   ── stderr ──")
        for line in result.stderr.strip().split("\n"):
            print(f"   {line}")
    return result.returncode == 0


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════

def main():
    print("=" * 70)
    print("U10 — Hygiene Pass (3 fixes)")
    print("=" * 70)

    if not os.path.exists(MAIN_PY):
        fail(f"{MAIN_PY} not found")
    if not os.path.exists(RELATIONSHIPS_PY):
        fail(f"{RELATIONSHIPS_PY} not found")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    # ═══════════════════════════════════════════════════════════════
    # PHASE A — Fix 2: lagna_lord rename in relationships.py
    # ═══════════════════════════════════════════════════════════════
    print("\n── Phase A: Fix 2 (rename ascendant_lord → lagna_lord) ──")
    with open(RELATIONSHIPS_PY, "r") as f:
        rel_content = f.read()
    rel_backup = None
    if MARKER_FIX2 in rel_content:
        print("   ⏭️  Marker present — Fix 2 already applied, skipping")
    else:
        if FIX2_OLD not in rel_content:
            fail(f"Anchor for Fix 2 not found in relationships.py.\n"
                 f"   Expected line:\n   {FIX2_OLD}")
        rel_backup = f"{RELATIONSHIPS_PY}.before_u10_{ts}"
        shutil.copy2(RELATIONSHIPS_PY, rel_backup)
        print(f"   ✅ Backup: {rel_backup}")
        new_rel = rel_content.replace(FIX2_OLD, FIX2_NEW, 1)
        with open(RELATIONSHIPS_PY, "w") as f:
            f.write(new_rel)
        print(f"   ✅ Replaced ascendant_lord → lagna_lord")
        syntax_check(RELATIONSHIPS_PY,
                     restore_pairs=[(rel_backup, RELATIONSHIPS_PY)])

    # ═══════════════════════════════════════════════════════════════
    # PHASE B + C — Fix 3 (delete dead class) + Fix 1 (new endpoint)
    # Both in main.py. Single backup, both edits, single syntax check.
    # ═══════════════════════════════════════════════════════════════
    print("\n── Phase B+C: Fix 3 (delete dead class) + Fix 1 (new endpoint) ──")
    with open(MAIN_PY, "r") as f:
        main_content = f.read()

    main_backup = None
    fix3_applied = False
    fix1_applied = False

    # Idempotency
    f3_already = MARKER_FIX3 in main_content
    f1_already = MARKER_FIX1 in main_content

    if f3_already and f1_already:
        print("   ⏭️  Both Fix 3 + Fix 1 markers present — already applied, skipping")
    else:
        # Validate Fix 3 anchor
        if not f3_already:
            if FIX3_OLD not in main_content:
                fail("Anchor for Fix 3 not found in main.py.\n"
                     "   Expected the 3-line dead CompatibilityInput class\n"
                     "   followed by MuhurthaInput class around line 490.\n"
                     "   File may have been modified since diagnostic.")

        main_backup = f"{MAIN_PY}.before_u10_{ts}"
        shutil.copy2(MAIN_PY, main_backup)
        print(f"   ✅ Backup: {main_backup}")

        # Apply Fix 3
        if not f3_already:
            main_content = main_content.replace(FIX3_OLD, FIX3_NEW, 1)
            fix3_applied = True
            print(f"   ✅ Fix 3 applied — dead CompatibilityInput removed")

        # Apply Fix 1
        if not f1_already:
            if not main_content.endswith("\n"):
                main_content += "\n"
            main_content += FIX1_BLOCK
            fix1_applied = True
            print(f"   ✅ Fix 1 applied — /astro/nakshatra/compatibility_from_birth appended")

        # Write
        with open(MAIN_PY, "w") as f:
            f.write(main_content)

        # Syntax check
        restore = []
        if main_backup:
            restore.append((main_backup, MAIN_PY))
        if rel_backup:
            restore.append((rel_backup, RELATIONSHIPS_PY))
        syntax_check(MAIN_PY, restore_pairs=restore)

    # ═══════════════════════════════════════════════════════════════
    # PHASE D — Snapshot after-state
    # ═══════════════════════════════════════════════════════════════
    print("\n── Phase D: Snapshots after-state ──")
    if rel_backup:  # only snapshot if we actually changed it
        snap = f"{RELATIONSHIPS_PY}.after_u10_{ts}"
        shutil.copy2(RELATIONSHIPS_PY, snap)
        print(f"   ✅ {snap}")
    if main_backup:
        snap = f"{MAIN_PY}.after_u10_{ts}"
        shutil.copy2(MAIN_PY, snap)
        print(f"   ✅ {snap}")
    if not (rel_backup or main_backup):
        print("   ⏭️  No changes made; skipping snapshot")

    # ═══════════════════════════════════════════════════════════════
    # PHASE E — Import smoke test as user trading
    # ═══════════════════════════════════════════════════════════════
    print("\n── Phase E: Layered import smoke (as user `trading`) ──")
    ok = smoke_test_as_trading()
    if not ok:
        # Roll back BOTH files if smoke fails
        restore = []
        if main_backup: restore.append((main_backup, MAIN_PY))
        if rel_backup:  restore.append((rel_backup, RELATIONSHIPS_PY))
        fail("Smoke test failed — see layer marked FAIL above", restore_pairs=restore)

    print("\n" + "=" * 70)
    print("U10 PATCH APPLIED — next steps:")
    print("  sudo systemctl restart astro && sleep 3")
    print("  systemctl status astro | grep -E 'Memory|Active'")
    print("  Then run verification sweep (see U10_PATCH_INSTRUCTIONS.md)")
    print("=" * 70)


if __name__ == "__main__":
    main()
