"""
patch_b2_d10_wireup.py — Round 3 of post-Phase-D cleanup.

PURPOSE:
    B2 d10_deep_dive previously returned D1 chart data through "D10 principles"
    instead of casting the actual D10 chart. This patch wires it to consume
    dashaflow's pre-computed D10 sign data (which is present on every planet
    via chart["planets"][p]["d10_sign"]).

WHAT CHANGES:
    1. Modifies /opt/astro/career_wealth.py:
       - Adds _compute_d10_chart(chart) helper that builds real D10 chart
         from dashaflow's pre-computed d10_sign fields on each planet
       - Replaces d10_deep_dive() to:
         * Compute REAL D10 lagna (not D1 lagna)
         * Show REAL D10 10th house and its lord
         * Show AmK position in D10 (Jaimini career indicator)
         * Show D10 Lagna lord's house in D10 (primary career field)
         * Identify planets in D10's 10th house (career-defining placements)
       - Keeps old D10_ANALYSIS_PRINCIPLES rules for downstream LLM context
    2. No changes to main.py
    3. Endpoint signature preserved

RESPONSE CHANGES:
    Before: lagna=D1Aquarius, tenth_house=D1Scorpio, just rules text
    After:  real D10 lagna, real D10 chart, AmK's D10 placement, full synthesis

EFFORT: ~30 minutes including build, deploy, and stress test.

Run from /opt/astro:
    sudo python3 patch_b2_d10_wireup.py

Idempotent: marker check prevents double-application.
"""

import re
import sys
import os
import shutil
from datetime import datetime

CAREER_WEALTH_PY = "/opt/astro/career_wealth.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── B2 D10 WIRE-UP (Round 3) ──"


# ════════════════════════════════════════════════════════════════════════
# NEW HELPER + REPLACED FUNCTION
# ════════════════════════════════════════════════════════════════════════

NEW_BLOCK = '''# ── B2 D10 WIRE-UP (Round 3) ──
# Was: d10_deep_dive used D1 chart through "D10 principles" — never cast actual D10.
# Now: builds real D10 chart from dashaflow's pre-computed d10_sign fields,
#      analyses D10 lagna, D10 10th house, AmK's D10 placement, planet placements.

_SIGNS_ORDER_LOCAL = ["Aries","Taurus","Gemini","Cancer","Leo","Virgo",
                      "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"]

# Sign-lord lookup (Vedic standard, no exaltation/debility overrides here)
_SIGN_TO_LORD_LOCAL = {
    "Aries": "Mars",         "Taurus": "Venus",   "Gemini": "Mercury",
    "Cancer": "Moon",        "Leo": "Sun",        "Virgo": "Mercury",
    "Libra": "Venus",        "Scorpio": "Mars",   "Sagittarius": "Jupiter",
    "Capricorn": "Saturn",   "Aquarius": "Saturn","Pisces": "Jupiter",
}


def _compute_d10_chart(chart: Dict) -> Dict:
    """
    Build the actual D10 (Dashamsha) chart from dashaflow's pre-computed d10_sign
    fields. dashaflow already computes d10_sign for the lagna and every planet —
    we just extract and compute house numbers relative to D10 lagna.

    Returns:
        {
            "lagna": {"sign": "...", "lord": "..."},
            "planets": {
                "Sun":  {"sign": "...", "house": int},
                ...
            },
            "tenth_house": {
                "sign": "...",
                "sign_lord": "...",
                "planets_in_10": ["..."],
            },
            "lagna_lord_in_d10": {"planet": "...", "house": int, "sign": "..."}
        }
    """
    lagna_obj = chart.get("lagna", {})
    if isinstance(lagna_obj, dict):
        d10_lagna_sign = lagna_obj.get("d10_sign")
    else:
        d10_lagna_sign = None

    if not d10_lagna_sign or d10_lagna_sign not in _SIGNS_ORDER_LOCAL:
        # Fallback — D10 lagna unavailable
        return {
            "lagna":       None,
            "planets":     {},
            "tenth_house": None,
            "note":        "D10 data unavailable from chart cast",
        }

    lagna_idx = _SIGNS_ORDER_LOCAL.index(d10_lagna_sign)
    d10_lagna_lord = _SIGN_TO_LORD_LOCAL.get(d10_lagna_sign)

    def sign_to_house(sign):
        if not sign or sign not in _SIGNS_ORDER_LOCAL:
            return None
        return ((_SIGNS_ORDER_LOCAL.index(sign) - lagna_idx) % 12) + 1

    # Build D10 planet placements
    d10_planets = {}
    for planet, pdata in chart.get("planets", {}).items():
        if isinstance(pdata, dict):
            d10_sign = pdata.get("d10_sign")
            d10_house = sign_to_house(d10_sign)
            d10_planets[planet] = {
                "sign":  d10_sign,
                "house": d10_house,
            }

    # D10 10th house = sign at index (lagna_idx + 9) % 12
    d10_10th_sign = _SIGNS_ORDER_LOCAL[(lagna_idx + 9) % 12]
    d10_10th_lord = _SIGN_TO_LORD_LOCAL.get(d10_10th_sign)
    planets_in_d10_10th = [p for p, pd in d10_planets.items() if pd.get("house") == 10]
    d10_10th_lord_house = d10_planets.get(d10_10th_lord, {}).get("house") if d10_10th_lord else None

    # D10 Lagna lord's placement
    lagna_lord_data = d10_planets.get(d10_lagna_lord, {})

    return {
        "lagna": {
            "sign":   d10_lagna_sign,
            "lord":   d10_lagna_lord,
        },
        "planets": d10_planets,
        "tenth_house": {
            "sign":            d10_10th_sign,
            "sign_lord":       d10_10th_lord,
            "lord_house":      d10_10th_lord_house,
            "planets_in_10":   planets_in_d10_10th,
        },
        "lagna_lord_in_d10": {
            "planet": d10_lagna_lord,
            "house":  lagna_lord_data.get("house"),
            "sign":   lagna_lord_data.get("sign"),
        },
    }


def d10_deep_dive(dob: str, time: str, lat: float, lon: float,
                  timezone: str = "Asia/Kolkata") -> Dict[str, Any]:
    """
    D10 Dashamsha deep dive — career direction, authority lines.

    Casts the ACTUAL D10 chart (not D1-through-D10-lens) using dashaflow's
    pre-computed d10_sign fields. Analyses D10 lagna, D10 10th house, the
    placement of Amatyakaraka in D10 (strongest Jaimini career indicator),
    and the location of the D10 Lagna lord (defines primary career field).

    Classical sources: Phaladeepika Ch. 7 (D10 Dashamsha doctrine), Jaimini
    Sutras Adhyaya 1 (Karakamsha/AmK methodology), BPHS Ch. 7 (Divisional
    chart construction).
    """
    chart = get_chart(dob, time, lat, lon, timezone)
    ch    = extract_chart_essentials(chart)
    d10   = _compute_d10_chart(chart)

    # Where is AmK in D10? (Most important Jaimini career signature.)
    amk_planet = ch.get("amatyakaraka")
    amk_in_d10 = d10.get("planets", {}).get(amk_planet, {}) if amk_planet else {}

    # Where is AK (Atmakaraka)? Sometimes used for soul-purpose career bridging
    ak_planet = ch.get("atmakaraka")
    ak_in_d10 = d10.get("planets", {}).get(ak_planet, {}) if ak_planet else {}

    # Sun + Saturn special placements in D10 (authority vs. service orientation)
    sun_in_d10    = d10.get("planets", {}).get("Sun", {})
    saturn_in_d10 = d10.get("planets", {}).get("Saturn", {})

    # Synthesize career signature
    signature_lines = []
    d10_lagna_data = d10.get("lagna") or {}
    if d10_lagna_data.get("sign"):
        signature_lines.append(
            f"D10 Lagna in {d10_lagna_data['sign']} ruled by {d10_lagna_data['lord']} — "
            f"primary career orientation defined by {d10_lagna_data['lord']}'s nature."
        )
    if d10.get("lagna_lord_in_d10", {}).get("house"):
        ll = d10["lagna_lord_in_d10"]
        signature_lines.append(
            f"D10 Lagna lord {ll['planet']} placed in D10 house {ll['house']} "
            f"(sign: {ll['sign']}) — primary career field indicator."
        )
    if amk_in_d10.get("house"):
        signature_lines.append(
            f"AmK ({amk_planet}) in D10 house {amk_in_d10['house']} "
            f"(sign: {amk_in_d10.get('sign')}) — Jaimini career karaka placement; "
            f"strongest indicator of profession's domain."
        )
    if d10.get("tenth_house", {}).get("planets_in_10"):
        planets_str = ", ".join(d10["tenth_house"]["planets_in_10"])
        signature_lines.append(
            f"Planets in D10's 10th house: {planets_str} — peak-career-defining placements."
        )
    if d10.get("tenth_house", {}).get("lord_house"):
        th = d10["tenth_house"]
        signature_lines.append(
            f"D10 10th lord {th['sign_lord']} placed in D10 house {th['lord_house']} — "
            f"defines where career peak energy manifests."
        )

    return {
        "actual_d10_chart":     d10,                           # NEW — real D10 data
        "career_signature":     signature_lines,               # NEW — synthesized reading
        "amatyakaraka": {                                      # ENHANCED — now with D10 placement
            "planet":            amk_planet,
            "d1_position":       ch.get("amatyakaraka_full"),
            "d10_position":      amk_in_d10,
        },
        "atmakaraka": {                                        # NEW — for soul-purpose bridging
            "planet":            ak_planet,
            "d10_position":      ak_in_d10,
        },
        "sun_in_d10":           sun_in_d10,                    # NEW — authority orientation
        "saturn_in_d10":        saturn_in_d10,                 # NEW — service orientation
        "d1_tenth_house":       _tenth_house_summary(ch),      # KEPT — D1 10th for cross-ref
        "d10_principles":       D10_ANALYSIS_PRINCIPLES,       # KEPT — interpretation rules
        "method":               "Real D10 chart synthesis via dashaflow d10_sign data + Jaimini AmK methodology + classical D10 doctrine. AmK and lagna lord placements computed in actual D10 (not D1).",
        "classical_source":     "Phaladeepika Ch. 7 (D10 Dashamsha) + Jaimini Sutras Adhyaya 1 (Karakamsha/AmK) + BPHS Ch. 7 (Divisional chart construction).",
    }
# ── END B2 D10 WIRE-UP ──
'''


# ════════════════════════════════════════════════════════════════════════
# REGEX TO LOCATE OLD FUNCTION
# ════════════════════════════════════════════════════════════════════════

OLD_FUNCTION_START = 'def d10_deep_dive(dob: str, time: str, lat: float, lon: float,'


def find_old_function_block(content: str) -> tuple:
    """Find (start, end) of old d10_deep_dive by anchor + next-def boundary."""
    start_idx = content.find(OLD_FUNCTION_START)
    if start_idx == -1:
        return (None, None)

    search_from = start_idx + len(OLD_FUNCTION_START)
    next_def = content.find("\ndef ", search_from)
    next_section = content.find("\n# ════", search_from)

    candidates = [x for x in (next_def, next_section) if x != -1]
    if not candidates:
        end_idx = len(content)
    else:
        end_idx = min(candidates) + 1

    return (start_idx, end_idx)


def main():
    if not os.path.exists(CAREER_WEALTH_PY):
        print(f"ERROR: {CAREER_WEALTH_PY} not found")
        sys.exit(1)

    with open(CAREER_WEALTH_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/career_wealth.py.before_b2_d10_wireup_{ts}"
    shutil.copyfile(CAREER_WEALTH_PY, backup_path)
    print(f"✅ Backup written: {backup_path}")

    original_lines = len(content.split("\n"))
    print(f"   Original career_wealth.py: {original_lines} lines")
    print()

    # Find and replace the old d10_deep_dive function
    start_idx, end_idx = find_old_function_block(content)
    if start_idx is None:
        print("ERROR: Could not locate old d10_deep_dive function")
        sys.exit(2)

    pre_line  = content[:start_idx].count("\n") + 1
    post_line = content[:end_idx].count("\n") + 1
    block_size = end_idx - start_idx
    print(f"✅ Found old d10_deep_dive at lines {pre_line}-{post_line} ({block_size} chars)")

    content = content[:start_idx] + NEW_BLOCK + content[end_idx:]
    print(f"            Replaced with _compute_d10_chart helper + wired d10_deep_dive")

    # Write back
    with open(CAREER_WEALTH_PY, "w") as f:
        f.write(content)

    new_lines = len(content.split("\n"))
    delta = new_lines - original_lines
    print()
    print(f"✅ B2 D10 Wire-Up complete.")
    print(f"   New career_wealth.py: {new_lines} lines (delta: {'+' if delta >= 0 else ''}{delta})")

    after_path = f"{BACKUP_DIR}/career_wealth.py.after_b2_d10_wireup_{ts}"
    shutil.copyfile(CAREER_WEALTH_PY, after_path)
    print(f"✅ After snapshot: {after_path}")


if __name__ == "__main__":
    main()
