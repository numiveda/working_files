"""
patch_main_fengshui.py — Adds 9 Feng Shui endpoints to /opt/astro/main.py

Safe, idempotent: skips if endpoints already present.
Marker: # ── FENG SHUI PERSONAL MODULE ──

Run from /opt/astro/ as the trading user:
    python3 patch_main_fengshui.py

To remove: delete everything between the start and end markers.
"""

import re
import sys
from pathlib import Path

MAIN_PY = Path("/opt/astro/main.py")
MARKER_START = "# ── FENG SHUI PERSONAL MODULE ──"
MARKER_END = "# ── END FENG SHUI PERSONAL MODULE ──"

# ════════════════════════════════════════════════════════════════════════
# CODE TO INJECT — Feng Shui endpoints + import + Pydantic model
# ════════════════════════════════════════════════════════════════════════

IMPORT_LINE = "from feng_shui import (\n    full_personal_profile, calculate_kua, get_eight_directions,\n    calculate_year_animal, calculate_day_master, element_interactions,\n    calculate_lo_shu, flying_stars_for_year, get_bagua_home_map,\n    feng_shui_compatibility, year_outlook,\n)\nfrom feng_shui_data import KUA_TO_TRIGRAM"


ENDPOINT_BLOCK = '''
# ══════════════════════════════════════════════════════════════════════
# ── FENG SHUI PERSONAL MODULE ──
# 9 endpoints — Classical Bazhai + Bazi + Lo Shu + Flying Stars
# Sources: Ba Zhai Ming Jing, Bazi Four Pillars, Lo Shu, Xuan Kong Fei Xing
# ══════════════════════════════════════════════════════════════════════

class FengShuiInput(BaseModel):
    dob: str           # YYYY-MM-DD
    gender: str        # "male" or "female"
    time: Optional[str] = "12:00"     # Optional, only matters for Day Master accuracy
    lat: Optional[float] = None
    lon: Optional[float] = None
    timezone: Optional[str] = "Asia/Kolkata"
    target_year: Optional[int] = None  # For year outlook / flying stars; defaults to current year


class FengShuiCompatInput(BaseModel):
    person_a: FengShuiInput
    person_b: FengShuiInput


def _parse_fs_input(inp: FengShuiInput):
    """Helper — parse FengShuiInput into year, month, day components."""
    try:
        year, month, day = inp.dob.split("-")
        return int(year), int(month), int(day)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid dob format. Use YYYY-MM-DD. Got: {inp.dob}")


@app.post("/astro/fengshui/profile")
def fengshui_profile(inp: FengShuiInput, _: str = Depends(verify_key)):
    """
    Master endpoint — full personal Feng Shui profile.
    Returns: Kua, 8 directions, elements, animal, day master, Lo Shu,
    flying stars, Bagua home map, year outlook, synthesis (colors/numbers/career).
    """
    y, m, d = _parse_fs_input(inp)
    return full_personal_profile(y, m, d, inp.gender, inp.target_year)


@app.post("/astro/fengshui/kua")
def fengshui_kua(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Kua number + trigram + East/West group + compatible Kuas."""
    y, m, d = _parse_fs_input(inp)
    return calculate_kua(y, inp.gender, m, d)


@app.post("/astro/fengshui/directions")
def fengshui_directions(inp: FengShuiInput, _: str = Depends(verify_key)):
    """8 directions ranked — 4 lucky (Sheng Qi/Tian Yi/Yan Nian/Fu Wei) + 4 unlucky."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    return get_eight_directions(kua["kua_effective"])


@app.post("/astro/fengshui/elements")
def fengshui_elements(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Bazi Day Master + Year Animal Element + Wu Xing interactions (colors, supporting, draining, harming)."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    return {
        "year_animal":       calculate_year_animal(kua["solar_year_used"]),
        "day_master":        calculate_day_master(y, m, d),
        "personal_element":  element_interactions(kua["personal_element"]),
        "classical_source":  "Bazi Four Pillars + Wu Xing",
    }


@app.post("/astro/fengshui/loshu")
def fengshui_loshu(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Lo Shu Grid 3×3 with missing/excessive numbers analysis."""
    y, m, d = _parse_fs_input(inp)
    return calculate_lo_shu(y, m, d)


@app.post("/astro/fengshui/flying_stars")
def fengshui_flying_stars(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Xuan Kong Flying Stars for given year + native's personal palace star."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    target = inp.target_year or 2026
    return flying_stars_for_year(kua["kua_effective"], target)


@app.post("/astro/fengshui/bagua_home")
def fengshui_bagua_home(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Bagua home map — 9 life areas with colors, materials, objects, personal alignment."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    return get_bagua_home_map(kua["kua_effective"])


@app.post("/astro/fengshui/compatibility")
def fengshui_compatibility(inp: FengShuiCompatInput, _: str = Depends(verify_key)):
    """Two-person Feng Shui compatibility: Kua groups, elements, year animals, day masters."""
    a_y, a_m, a_d = _parse_fs_input(inp.person_a)
    b_y, b_m, b_d = _parse_fs_input(inp.person_b)
    return feng_shui_compatibility(
        {"birth_year": a_y, "birth_month": a_m, "birth_day": a_d, "gender": inp.person_a.gender},
        {"birth_year": b_y, "birth_month": b_m, "birth_day": b_d, "gender": inp.person_b.gender},
    )


@app.post("/astro/fengshui/year_outlook")
def fengshui_year_outlook(inp: FengShuiInput, _: str = Depends(verify_key)):
    """Personal year outlook — flying stars + zodiac year compatibility + themes."""
    y, m, d = _parse_fs_input(inp)
    kua = calculate_kua(y, inp.gender, m, d)
    target = inp.target_year or 2026
    return year_outlook(kua["kua_effective"], y, target)

# ── END FENG SHUI PERSONAL MODULE ──
'''


# ════════════════════════════════════════════════════════════════════════
# PATCHING LOGIC
# ════════════════════════════════════════════════════════════════════════

def main():
    if not MAIN_PY.exists():
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    content = MAIN_PY.read_text()

    # Idempotency check
    if MARKER_START in content:
        print(f"⏭️  Feng Shui module already patched into {MAIN_PY}. Skipping.")
        print("   To re-patch: manually delete content between markers and rerun.")
        return

    # Verify dependencies exist
    if "from fastapi import" not in content:
        print("ERROR: main.py doesn't look like a FastAPI app")
        sys.exit(1)

    if "verify_key" not in content:
        print("ERROR: main.py doesn't define verify_key dependency")
        sys.exit(1)

    if "BaseModel" not in content:
        print("ERROR: BaseModel not imported in main.py")
        sys.exit(1)

    # ── 1. Insert import block ──
    # Find a good place: right after the last import line in the top-of-file imports
    import_lines = re.findall(r'^(from\s+\S+\s+import\s+[^\n]+|import\s+[^\n]+)$', content, re.MULTILINE)
    if not import_lines:
        print("ERROR: Couldn't find import block in main.py")
        sys.exit(1)

    last_import = import_lines[-1]
    last_import_pos = content.rfind(last_import) + len(last_import)

    new_content = (
        content[:last_import_pos]
        + "\n\n# ── Feng Shui module imports ──\n"
        + IMPORT_LINE
        + content[last_import_pos:]
    )

    # ── 2. Append endpoint block at end of file ──
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    # ── 3. Write back ──
    MAIN_PY.write_text(new_content)
    print(f"✅ Patched {MAIN_PY}")
    print(f"   Added: 9 Feng Shui endpoints")
    print(f"   Marker: {MARKER_START}")
    print(f"   File size: {len(new_content)} bytes (was {len(content)})")

    # ── 4. Syntax check ──
    print("\n🔍 Verifying syntax...")
    import py_compile
    try:
        py_compile.compile(str(MAIN_PY), doraise=True)
        print("✅ Syntax OK — ready to restart astro service")
    except py_compile.PyCompileError as e:
        print(f"❌ SYNTAX ERROR in patched main.py:\n{e}")
        print("\n   Restore backup:")
        print("   cp /opt/astro/main.py.pre_phase_a_backup_20260516_033338 /opt/astro/main.py")
        sys.exit(1)


if __name__ == "__main__":
    main()
