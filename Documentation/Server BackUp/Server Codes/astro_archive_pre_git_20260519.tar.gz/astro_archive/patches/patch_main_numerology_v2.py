#!/usr/bin/env python3
"""
patch_main_numerology_v2.py — Auto-patches main.py with Numerology v2 blocks.

Uses the proven multi-line-import-aware insertion (locked in from yogas_v2/timeline).
"""
import ast
import os
import re
import shutil
import sys
from datetime import datetime
from main_patches_numerology_v2 import (
    BLOCK_A_IMPORTS, BLOCK_B_MODELS, BLOCK_C_ENDPOINTS,
)

MAIN_PATH = "/opt/astro/main.py"


def _find_safe_import_insert_line(lines):
    """Walk past multi-line imports to find the last safely-after-imports line."""
    last_safe = 0
    i = 0
    while i < min(300, len(lines)):
        line = lines[i].strip()
        if line.startswith(("import ", "from ")) and not line.startswith("#"):
            if "(" in line and ")" not in line:
                j = i + 1
                while j < len(lines):
                    if ")" in lines[j]:
                        last_safe = j
                        i = j
                        break
                    j += 1
            else:
                last_safe = i
        i += 1
    return last_safe


def _find_models_insert_line(content):
    """
    Find a safe spot to insert pydantic models. After existing BaseModel classes.
    Returns insertion position (byte offset) or None.
    """
    # Find the last class definition with BaseModel as base
    matches = list(re.finditer(
        r"^class\s+\w+\s*\(\s*BaseModel\s*\)\s*:.*?(?=\n(?:class\s|\@app\.|def\s|#\s*[─-]))",
        content,
        flags=re.MULTILINE | re.DOTALL,
    ))
    if matches:
        last_match = matches[-1]
        return last_match.end()
    return None


def patch():
    if not os.path.exists(MAIN_PATH):
        print(f"❌ {MAIN_PATH} not found")
        sys.exit(1)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = f"{MAIN_PATH}.backup_numv2_{ts}"
    shutil.copy2(MAIN_PATH, backup)
    print(f"✓ Backup created: {backup}")

    with open(MAIN_PATH, "r", encoding="utf-8") as f:
        content = f.read()

    original = content
    changes_made = []

    # ─── BLOCK A: imports ───────────────────────────────────────────────────
    if "BEGIN NUMEROLOGY V2 IMPORTS" in content:
        print("⊙ BLOCK A (imports): already present, skipping")
    else:
        lines = content.split("\n")
        last_safe = _find_safe_import_insert_line(lines)
        print(f"  → Inserting imports after line {last_safe + 1}")
        lines.insert(last_safe + 1, BLOCK_A_IMPORTS.strip())
        content = "\n".join(lines)
        changes_made.append("BLOCK A (imports)")
        print("✓ BLOCK A (imports) added")

    # ─── BLOCK B: models ────────────────────────────────────────────────────
    if "BEGIN NUMEROLOGY V2 MODELS" in content:
        print("⊙ BLOCK B (models): already present, skipping")
    else:
        insert_pos = _find_models_insert_line(content)
        if insert_pos is None:
            # Fallback: insert before first @app.post
            m = re.search(r"\n@app\.(post|get)\(", content)
            insert_pos = m.start() if m else len(content)
        content = content[:insert_pos] + "\n\n" + BLOCK_B_MODELS.strip() + "\n" + content[insert_pos:]
        changes_made.append("BLOCK B (models)")
        print("✓ BLOCK B (models) added")

    # ─── BLOCK C: endpoints ─────────────────────────────────────────────────
    if "BEGIN NUMEROLOGY V2 ENDPOINTS" in content:
        print("⊙ BLOCK C (endpoints): already present, skipping")
    else:
        on_event_match = re.search(r"\n@app\.on_event\(", content)
        if on_event_match:
            pos = on_event_match.start()
            content = content[:pos] + "\n\n" + BLOCK_C_ENDPOINTS.strip() + "\n\n" + content[pos:]
            print("✓ BLOCK C (endpoints) added before @app.on_event")
        else:
            main_block = re.search(r"\nif\s+__name__\s*==\s*[\"']__main__[\"']", content)
            if main_block:
                pos = main_block.start()
                content = content[:pos] + "\n\n" + BLOCK_C_ENDPOINTS.strip() + "\n\n" + content[pos:]
                print("✓ BLOCK C (endpoints) added before __main__ block")
            else:
                content = content.rstrip() + "\n\n" + BLOCK_C_ENDPOINTS.strip() + "\n"
                print("✓ BLOCK C (endpoints) appended at end of file")
        changes_made.append("BLOCK C (endpoints)")

    # ─── Validate ───────────────────────────────────────────────────────────
    try:
        ast.parse(content)
    except SyntaxError as e:
        print(f"❌ Syntax error after patching: {e}")
        bad_lines = content.split("\n")
        ln = e.lineno or 0
        for i in range(max(0, ln - 3), min(len(bad_lines), ln + 3)):
            marker = " >>>" if i + 1 == ln else "    "
            print(f"  {marker} {i+1:4d}: {bad_lines[i]}")
        print(f"   Rolling back from {backup}")
        shutil.copy2(backup, MAIN_PATH)
        sys.exit(1)

    if content == original:
        print("⊙ No changes needed")
        return

    with open(MAIN_PATH, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"✓ main.py patched successfully")
    print(f"  Changes: {', '.join(changes_made)}")
    print(f"  Backup retained: {backup}")


if __name__ == "__main__":
    patch()
