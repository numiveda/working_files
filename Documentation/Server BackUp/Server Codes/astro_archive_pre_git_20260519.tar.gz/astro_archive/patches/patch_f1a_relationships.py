#!/usr/bin/env python3
"""
patch_f1a_relationships.py
─────────────────────────────────────────────────────────────────────────
F1a — Mount the new relationships module (friendship / mentor / family).

PREREQUISITES:
    - /opt/astro/relationships.py must already be present (scp'd separately)
    - U9 must have been applied (this is verified by checking the U9 marker)

PATCH STEPS:
    1. Idempotency: bail if F1a marker already present
    2. Verify relationships.py exists and imports cleanly
    3. Backup main.py
    4. Inject RelationshipInput Pydantic model after CompatibilityInput
    5. Inject `from relationships import (...)` block after compatibility import
    6. Inject 3 endpoint registrations at end of file
    7. Snapshot after
    8. Syntax check; rollback if fails

CHARACTERISTICS:
    - Idempotent (marker check)
    - Reversible (backup with timestamp)
    - Loud (asserts at every step; fails before partial state)

Author: Claude (F1a, 2026-05-17)
"""

import os
import sys
import shutil
import subprocess
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
RELATIONSHIPS_PY = "/opt/astro/relationships.py"

MARKER_IMPORT = "# ── F1a: Non-Marriage Relationships (2026-05-17) ──"
MARKER_ENDPOINTS = "# ── F1a: /astro/relationship/* (2026-05-17) ──"
MARKER_INPUT_CLASS = "# ── F1a: RelationshipInput (2026-05-17) ──"

# ─────────────────────────────────────────────────────────────────────
# Anchor strings (copied verbatim from diagnostic output)
# ─────────────────────────────────────────────────────────────────────

# Anchor 1: end of compatibility import block (line 229 in diagnostic)
COMPAT_IMPORT_TAIL = """    handle_timing_for_marriage      as compat_handle_timing_for_marriage,"""

# Anchor 2: BirthInput class (line 436 in diagnostic) — we splice RelationshipInput nearby
# Use CompatibilityInput (line 468) as the closer anchor
COMPAT_INPUT_ANCHOR = """class CompatibilityInput(BaseModel):"""

# ─────────────────────────────────────────────────────────────────────
# Blocks to inject
# ─────────────────────────────────────────────────────────────────────

F1A_IMPORT_BLOCK = """

{MARKER_IMPORT}
from relationships import (
    handle_friendship  as rel_handle_friendship,
    handle_mentor      as rel_handle_mentor,
    handle_family      as rel_handle_family,
)
""".replace("{MARKER_IMPORT}", MARKER_IMPORT)


F1A_INPUT_CLASS_BLOCK = """

{MARKER_INPUT_CLASS}
class RelationshipInput(BaseModel):
    person1: BirthInput
    person2: BirthInput
    # Optional context — improves synthesis but never required.
    # For mentor: role1/role2 ∈ {"mentor", "mentee"}
    # For family: any free-text label (e.g. "mother", "elder_sibling")
    role1: Optional[str] = None
    role2: Optional[str] = None
    # For family endpoint only: "parent-child" | "sibling" | "extended"
    subtype: Optional[str] = None
""".replace("{MARKER_INPUT_CLASS}", MARKER_INPUT_CLASS)


F1A_ENDPOINTS_BLOCK = '''

{MARKER_ENDPOINTS}

@app.post("/astro/relationship/friendship", dependencies=[Depends(verify_key)])
def relationship_friendship(r: RelationshipInput):
    """
    Friendship compatibility — emotional + intellectual rapport.
    Frame: 3rd house (peers), 11th house (gains/friends); karakas Mercury, Moon, Venus.
    Returns multi-stream evidence (koot + moon-synastry + house-overlay + Mercury-Moon cross)
    with composite score 0-100 and classical citations.
    """
    try:
        p1 = {"dob": r.person1.dob, "time": r.person1.time,
              "lat": r.person1.lat, "lon": r.person1.lon,
              "timezone": r.person1.timezone}
        p2 = {"dob": r.person2.dob, "time": r.person2.time,
              "lat": r.person2.lat, "lon": r.person2.lon,
              "timezone": r.person2.timezone}
        result = rel_handle_friendship(p1, p2, role1=r.role1, role2=r.role2)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/relationship/mentor", dependencies=[Depends(verify_key)])
def relationship_mentor(r: RelationshipInput):
    """
    Mentor / Guru-Shishya compatibility.
    Frame: 5H (disciple from guru) / 9H (guru from disciple); karaka Jupiter, AK resonance.
    Roles (optional): role1/role2 in {"mentor","mentee"}; if absent, returns both directional readings.
    Multi-stream evidence with composite score 0-100 and classical citations.
    """
    try:
        p1 = {"dob": r.person1.dob, "time": r.person1.time,
              "lat": r.person1.lat, "lon": r.person1.lon,
              "timezone": r.person1.timezone}
        p2 = {"dob": r.person2.dob, "time": r.person2.time,
              "lat": r.person2.lat, "lon": r.person2.lon,
              "timezone": r.person2.timezone}
        result = rel_handle_mentor(p1, p2, role1=r.role1, role2=r.role2)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/relationship/family", dependencies=[Depends(verify_key)])
def relationship_family(r: RelationshipInput):
    """
    Family compatibility — parent-child, sibling, or extended.
    Subtype (optional, defaults to "extended"):
        "parent-child" → 4/9/10/5 houses; Matri/Pitri/Putra karakas
        "sibling"      → 3/11 houses;     Bhratrikaraka
        "extended"     → all family houses + all 4 family karakas
    Multi-stream evidence + composite score 0-100 + classical citations.
    """
    try:
        p1 = {"dob": r.person1.dob, "time": r.person1.time,
              "lat": r.person1.lat, "lon": r.person1.lon,
              "timezone": r.person1.timezone}
        p2 = {"dob": r.person2.dob, "time": r.person2.time,
              "lat": r.person2.lat, "lon": r.person2.lon,
              "timezone": r.person2.timezone}
        result = rel_handle_family(p1, p2,
                                    role1=r.role1, role2=r.role2,
                                    subtype=r.subtype)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
'''.replace("{MARKER_ENDPOINTS}", MARKER_ENDPOINTS)


def fail(msg):
    print(f"\n❌ ERROR: {msg}")
    sys.exit(1)


def main():
    print("=" * 70)
    print("F1a — Relationships module installer")
    print("=" * 70)

    # ── Step 1: Preconditions ──
    if not os.path.exists(MAIN_PY):
        fail(f"{MAIN_PY} not found")

    if not os.path.exists(RELATIONSHIPS_PY):
        fail(f"{RELATIONSHIPS_PY} not found — scp it to /opt/astro/ first")

    # Check relationships.py syntax + imports work in isolation
    print(f"✅ Found {RELATIONSHIPS_PY}")
    print("Running import smoke test...")
    smoke = subprocess.run(
        ["python3", "-c",
         "import sys; sys.path.insert(0, '/opt/astro'); "
         "import relationships; "
         "print('   funcs:', [n for n in dir(relationships) "
         "if n.startswith('handle_')])"],
        capture_output=True, text=True, cwd="/opt/astro"
    )
    if smoke.returncode != 0:
        fail(f"relationships.py import failed:\n{smoke.stderr}")
    print(smoke.stdout)
    print("✅ relationships.py imports cleanly")

    # ── Step 2: Read main.py ──
    with open(MAIN_PY, "r") as f:
        content = f.read()

    orig_size = len(content)
    orig_lines = content.count("\n") + 1
    print(f"\nmain.py: {orig_size} bytes, {orig_lines} lines")

    # ── Step 3: Idempotency check ──
    if MARKER_IMPORT in content or MARKER_ENDPOINTS in content or MARKER_INPUT_CLASS in content:
        print(f"\n✅ F1a marker present — patch was already applied. No changes.")
        return

    # ── Step 4: Validate U9 has been applied (sanity) ──
    if "U9: /astro/compatibility modernized" not in content:
        fail("U9 marker not found in main.py. F1a requires U9 to be applied first "
             "(it confirms the compatibility codepath is healthy). Run "
             "patch_u9_compatibility_fix.py before F1a.")
    print("✅ U9 marker confirmed in main.py")

    # ── Step 5: Validate splice anchors exist ──
    if COMPAT_IMPORT_TAIL not in content:
        fail(f"Anchor 1 (compatibility import tail) not found in main.py. "
             f"compatibility import block may have been edited.")
    print("✅ Anchor 1 found (compatibility import tail)")

    if COMPAT_INPUT_ANCHOR not in content:
        fail(f"Anchor 2 (CompatibilityInput class) not found in main.py.")
    print("✅ Anchor 2 found (CompatibilityInput)")

    # ── Step 6: Backup ──
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = f"{MAIN_PY}.before_f1a_relationships_{ts}"
    shutil.copy2(MAIN_PY, backup)
    print(f"✅ Backup: {backup}")

    # ── Step 7: Inject import block (after compatibility import block) ──
    # Find end of the compatibility import block: line containing tail anchor + the closing ")"
    idx = content.find(COMPAT_IMPORT_TAIL)
    # Find the next ")" after this line — that closes the import (...)
    close_idx = content.find(")", idx)
    if close_idx == -1:
        fail("Could not locate closing paren of compatibility import block")
    insert_at = close_idx + 1  # right after the ")"
    new_content = content[:insert_at] + F1A_IMPORT_BLOCK + content[insert_at:]
    print("✅ Injected import block after compatibility import")

    # ── Step 8: Inject RelationshipInput class (before CompatibilityInput) ──
    # We place it BEFORE CompatibilityInput so RelationshipInput appears in the Pydantic
    # docs near other compatibility inputs. Also avoids the duplicate CompatibilityInput
    # at line 2389 we noticed in diagnostic (which is fine to leave alone).
    anchor_idx = new_content.find(COMPAT_INPUT_ANCHOR)
    if anchor_idx == -1:
        fail("Lost anchor after first injection — should not happen")
    new_content = (new_content[:anchor_idx]
                   + F1A_INPUT_CLASS_BLOCK
                   + "\n\n"
                   + new_content[anchor_idx:])
    print("✅ Injected RelationshipInput class before CompatibilityInput")

    # ── Step 9: Append endpoint block at end of file ──
    if not new_content.endswith("\n"):
        new_content += "\n"
    new_content += F1A_ENDPOINTS_BLOCK
    print("✅ Appended 3 endpoint registrations at end of file")

    # ── Step 10: Write ──
    with open(MAIN_PY, "w") as f:
        f.write(new_content)
    new_size = len(new_content)
    new_lines = new_content.count("\n") + 1
    print(f"\n✅ Wrote new main.py: {new_size} bytes ({new_size - orig_size:+d}), "
          f"{new_lines} lines ({new_lines - orig_lines:+d})")

    # ── Step 11: Snapshot after ──
    snap = f"{MAIN_PY}.after_f1a_relationships_{ts}"
    shutil.copy2(MAIN_PY, snap)
    print(f"✅ Snapshot: {snap}")

    # ── Step 12: Syntax check ──
    print("\n── Syntax check ──")
    import py_compile
    try:
        py_compile.compile(MAIN_PY, doraise=True)
        print("✅ main.py syntax OK")
    except py_compile.PyCompileError as e:
        print(f"❌ SYNTAX ERROR — rolling back from {backup}")
        shutil.copy2(backup, MAIN_PY)
        print(f"   Restored. Error was: {e}")
        sys.exit(1)

    print("\n" + "=" * 70)
    print("F1a PATCH APPLIED — next steps:")
    print("  sudo systemctl restart astro && sleep 3")
    print("  systemctl status astro | grep -E 'Memory|Active'")
    print("  Then run smoke + cross-validation tests")
    print("  (see F1A_PATCH_INSTRUCTIONS.md)")
    print("=" * 70)


if __name__ == "__main__":
    main()
