"""
patch_main_karmic.py — Wires 9 Karmic (D1) endpoints into main.py.

Uses verify_key auth pattern. Idempotent.

Run from /opt/astro:
    sudo python3 patch_main_karmic.py
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── KARMIC D1 MODULE ──"


IMPORT_BLOCK = '''
# ── KARMIC D1 MODULE IMPORTS ──
from karmic import (
    handle_profile               as karmic_handle_profile,
    handle_karakamsha            as karmic_handle_karakamsha,
    handle_atmakaraka_journey    as karmic_handle_atmakaraka_journey,
    handle_ketu_past_life        as karmic_handle_ketu_past_life,
    handle_rahu_forward_karma    as karmic_handle_rahu_forward_karma,
    handle_twelfth_house_moksha  as karmic_handle_twelfth_house_moksha,
    handle_kaal_sarpa            as karmic_handle_kaal_sarpa,
    handle_upapada_karma         as karmic_handle_upapada_karma,
    handle_arudha_padas          as karmic_handle_arudha_padas,
)
# ── END KARMIC D1 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── KARMIC D1 MODULE ──
# Phase D — Module D1 — Past Life / Karmic (9 endpoints)
# Sources: Jaimini Upadesha Sutras, BPHS Ch. 24/32, Phaladeepika Ch. 6,
#          Garga Hora (Kaal Sarpa)
# ════════════════════════════════════════════════════════════════════════

def _karmic_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/karmic/profile")
def karmic_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master karmic synthesis — Karakamsha + AK + Ketu + Rahu + 12th + Kaal Sarpa + Upapada."""
    return karmic_handle_profile(_karmic_birth_dict(inp))


@app.post("/astro/karmic/karakamsha")
def karmic_karakamsha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """AK's D9 placement + Ishta Devata + soul's ultimate direction."""
    return karmic_handle_karakamsha(_karmic_birth_dict(inp))


@app.post("/astro/karmic/atmakaraka_journey")
def karmic_ak_journey_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Atmakaraka by sign — past-life soul lesson + intensity by degree."""
    return karmic_handle_atmakaraka_journey(_karmic_birth_dict(inp))


@app.post("/astro/karmic/ketu_past_life")
def karmic_ketu_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Ketu's sign + nakshatra — past-life karmic capacity and skill."""
    return karmic_handle_ketu_past_life(_karmic_birth_dict(inp))


@app.post("/astro/karmic/rahu_forward_karma")
def karmic_rahu_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Rahu's sign + house — forward developmental karma to embrace."""
    return karmic_handle_rahu_forward_karma(_karmic_birth_dict(inp))


@app.post("/astro/karmic/twelfth_house_moksha")
def karmic_moksha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """12th house occupants + lord — moksha/liberation karma path."""
    return karmic_handle_twelfth_house_moksha(_karmic_birth_dict(inp))


@app.post("/astro/karmic/kaal_sarpa")
def karmic_kaal_sarpa_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Kaal Sarpa dosha detection + classical 12-type identification + remedies."""
    return karmic_handle_kaal_sarpa(_karmic_birth_dict(inp))


@app.post("/astro/karmic/upapada_karma")
def karmic_upapada_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Upapada Lagna spouse karma reading per Jaimini Upadesha Sutras."""
    return karmic_handle_upapada_karma(_karmic_birth_dict(inp))


@app.post("/astro/karmic/arudha_padas")
def karmic_arudha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """All 12 Arudha Padas — worldly projections of each life-area."""
    return karmic_handle_arudha_padas(_karmic_birth_dict(inp))

# ── END KARMIC D1 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present in main.py.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_karmic_d1_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_karmic_d1_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ Karmic D1 module patched into main.py")
    print("   9 endpoints under /astro/karmic/* — engine reaches 217 endpoints")


if __name__ == "__main__":
    main()
