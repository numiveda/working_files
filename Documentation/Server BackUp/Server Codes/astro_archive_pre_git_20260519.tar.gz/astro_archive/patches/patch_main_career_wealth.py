"""
patch_main_career_wealth.py — Adds 12 Career + Wealth endpoints (Module B2)

Same proven safe-insertion pattern.
Marker: # ── CAREER + WEALTH MODULE (B2) ──

Run: sudo python3 patch_main_career_wealth.py
"""

import re
import sys
from pathlib import Path

MAIN_PY = Path("/opt/astro/main.py")
MARKER_START = "# ── CAREER + WEALTH MODULE (B2) ──"


IMPORT_BLOCK = """
# ── Career + Wealth module (B2) imports ──
from career_wealth import (
    full_career_profile,
    d10_deep_dive,
    karaka_analysis_for_chart,
    natural_career_fields_endpoint,
    career_timing_endpoint,
    professional_dasha_endpoint,
    full_wealth_profile,
    dhana_yogas_endpoint,
    income_sources_endpoint,
    wealth_risk_areas_endpoint,
    income_windows_endpoint,
    wealth_remedies_endpoint,
)

"""


ENDPOINT_BLOCK = '''
# ══════════════════════════════════════════════════════════════════════
# ── CAREER + WEALTH MODULE (B2) ──
# 12 endpoints — Career (6) + Wealth (6)
# Sources: BPHS Ch. 35-40, Phaladeepika, Jataka Parijata, Saravali,
#          Sarvartha Chintamani, Jaimini Sutras
# ══════════════════════════════════════════════════════════════════════

# ── Career endpoints (6) ──

@app.post("/astro/career/profile")
def career_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master career profile — karakas, D10, raja yogas, fields."""
    return full_career_profile(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/career/d10_deep_dive")
def career_d10_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """D10 Dashamsha analysis — career direction."""
    return d10_deep_dive(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/career/karaka_analysis")
def career_karaka_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Career karakas — Sun, Saturn, Mercury, Jupiter + AK/AmK."""
    return karaka_analysis_for_chart(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/career/natural_fields")
def career_fields_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Compatible career fields from chart placements."""
    return natural_career_fields_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/career/timing")
def career_timing_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Best dasha periods for career moves, promotions."""
    return career_timing_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/career/professional_dasha")
def career_dasha_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Current MD/AD lord's career-relevance analysis."""
    return professional_dasha_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


# ── Wealth endpoints (6) ──

@app.post("/astro/wealth/profile")
def wealth_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master wealth profile — Dhana yogas, sources, risks, remedies."""
    return full_wealth_profile(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/wealth/dhana_yogas")
def wealth_dhana_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """All wealth-bestowing yogas detected in chart."""
    return dhana_yogas_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/wealth/income_sources")
def wealth_sources_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """11th house lord + planets indicating income sources."""
    return income_sources_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/wealth/risk_areas")
def wealth_risk_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Loss patterns — 12th, 8th, Kemadruma, Daridra yogas."""
    return wealth_risk_areas_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/wealth/income_windows")
def wealth_windows_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Best dasha windows for income peaks."""
    return income_windows_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/wealth/wealth_remedies")
def wealth_remedies_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Wealth-specific remedies — Kubera, Lakshmi, Sri Yantra, behavioral."""
    return wealth_remedies_endpoint(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )

# ── END CAREER + WEALTH MODULE (B2) ──
'''


def main():
    if not MAIN_PY.exists():
        print(f"ERROR: {MAIN_PY} not found"); sys.exit(1)

    content = MAIN_PY.read_text()

    if MARKER_START in content:
        print(f"⏭️  Career+Wealth module already patched. Skipping.")
        return

    if "from fastapi import" not in content:
        print("ERROR: main.py doesn't look like a FastAPI app"); sys.exit(1)
    if "verify_key" not in content:
        print("ERROR: verify_key not defined"); sys.exit(1)
    if "BirthInput" not in content:
        print("ERROR: BirthInput model not defined"); sys.exit(1)

    pat = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = pat.search(content)
    if not match:
        print("ERROR: 'app = FastAPI(' not found"); sys.exit(1)

    insertion_point = match.start()
    if insertion_point > 0 and content[insertion_point - 1] != '\n':
        print(f"ERROR: 'app = FastAPI(' not at start of line"); sys.exit(1)

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    MAIN_PY.write_text(new_content)
    print(f"✅ Patched {MAIN_PY}")
    print(f"   Added: 12 Career + Wealth (B2) endpoints")
    print(f"   Marker: {MARKER_START}")
    print(f"   File size: {len(new_content)} bytes (was {len(content)})")

    print("\n🔍 Verifying syntax...")
    import py_compile
    try:
        py_compile.compile(str(MAIN_PY), doraise=True)
        print("✅ Syntax OK — ready to restart astro service")
    except py_compile.PyCompileError as e:
        print(f"❌ SYNTAX ERROR: {e}"); sys.exit(1)


if __name__ == "__main__":
    main()
