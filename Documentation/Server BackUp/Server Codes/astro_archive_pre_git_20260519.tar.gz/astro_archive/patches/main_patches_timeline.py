"""
main_patches_timeline.py — Patches for the 4 timeline endpoints.

Endpoints:
  POST /astro/yogas/timeline/annual   — Next 12 months
  POST /astro/yogas/timeline/5year    — Next 5 years
  POST /astro/yogas/timeline/10year   — Next 10 years
  POST /astro/yogas/timeline/15year   — Next 15 years

All use existing BirthInput. The transit_fn passes through cast_chart() against
the target date, and dasha_fn uses the timeline_dasha_walker module.
"""

BLOCK_A_IMPORTS = '''
# === BEGIN TIMELINE IMPORTS ===
from yogas_timeline import (
    timeline_annual, timeline_5year, timeline_10year, timeline_15year,
)
from timeline_dasha_walker import get_dasha_state as _tl_get_dasha_state
from datetime import datetime as _tl_datetime
# === END TIMELINE IMPORTS ===
'''


BLOCK_C_ENDPOINTS = '''
# === BEGIN TIMELINE ENDPOINTS ===

def _build_timeline_callables(natal_chart, birth_dt, birth: BirthInput):
    """Build the dasha_fn and transit_fn callables for the timeline engine."""
    moon_lon = natal_chart.get("planets", {}).get("Moon", {}).get("longitude", 0.0)

    def dasha_fn(target_date):
        return _tl_get_dasha_state(moon_lon, birth_dt, target_date)

    def transit_fn(target_date):
        return cast_chart(
            dob=target_date.strftime("%Y-%m-%d"),
            time=target_date.strftime("%H:%M"),
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )

    return dasha_fn, transit_fn


@app.post("/astro/yogas/timeline/annual")
async def yogas_timeline_annual(birth: BirthInput, _: str = Depends(verify_key)):
    """Annual (12-month) yoga activation timeline. Used for the Annual Compass Report."""
    try:
        natal_chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        birth_dt = _tl_datetime.fromisoformat(f"{birth.dob}T{birth.time}:00")
        dasha_fn, transit_fn = _build_timeline_callables(natal_chart, birth_dt, birth)
        return timeline_annual(natal_chart, birth_dt, dasha_fn, transit_fn)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Annual timeline failed: {str(e)}")


@app.post("/astro/yogas/timeline/5year")
async def yogas_timeline_5year(birth: BirthInput, _: str = Depends(verify_key)):
    """5-year yoga activation timeline. Mid-term wealth/career planning horizon."""
    try:
        natal_chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        birth_dt = _tl_datetime.fromisoformat(f"{birth.dob}T{birth.time}:00")
        dasha_fn, transit_fn = _build_timeline_callables(natal_chart, birth_dt, birth)
        return timeline_5year(natal_chart, birth_dt, dasha_fn, transit_fn)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"5-year timeline failed: {str(e)}")


@app.post("/astro/yogas/timeline/10year")
async def yogas_timeline_10year(birth: BirthInput, _: str = Depends(verify_key)):
    """10-year yoga activation timeline. Long-term life-chapter horizon."""
    try:
        natal_chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        birth_dt = _tl_datetime.fromisoformat(f"{birth.dob}T{birth.time}:00")
        dasha_fn, transit_fn = _build_timeline_callables(natal_chart, birth_dt, birth)
        return timeline_10year(natal_chart, birth_dt, dasha_fn, transit_fn)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"10-year timeline failed: {str(e)}")


@app.post("/astro/yogas/timeline/15year")
async def yogas_timeline_15year(birth: BirthInput, _: str = Depends(verify_key)):
    """15-year yoga activation timeline. Full Mahadasha cycle context."""
    try:
        natal_chart = cast_chart(
            dob=birth.dob, time=birth.time,
            lat=birth.lat, lon=birth.lon, timezone=birth.timezone,
        )
        birth_dt = _tl_datetime.fromisoformat(f"{birth.dob}T{birth.time}:00")
        dasha_fn, transit_fn = _build_timeline_callables(natal_chart, birth_dt, birth)
        return timeline_15year(natal_chart, birth_dt, dasha_fn, transit_fn)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"15-year timeline failed: {str(e)}")


# === END TIMELINE ENDPOINTS ===
'''
