"""
patch_main_transit_aspects.py — Adds 2 transit-aspects endpoints to main.py.

Endpoints:
    /astro/transit/applying_aspects_to_natal — current applying/separating
    /astro/transit/upcoming_exact_aspects   — forward-stepped exact aspect calendar

Run from /opt/astro:
    sudo python3 patch_main_transit_aspects.py
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── TRANSIT ASPECTS U3 MODULE ──"


IMPORT_BLOCK = '''
# ── TRANSIT ASPECTS U3 MODULE IMPORTS ──
from transit_aspects import (
    handle_applying_aspects_to_natal as txa_handle_applying,
    handle_upcoming_exact_aspects    as txa_handle_upcoming,
)
# ── END TRANSIT ASPECTS U3 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── TRANSIT ASPECTS U3 MODULE ──
# Phase D — Upgrade 3 — Applying/separating transit aspects + exact-aspect calendar
# Source: Ptolemy "Tetrabiblos" + BPHS Ch. 26 + Swiss Eph 2.10
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _TxaBaseModel
from typing import Optional as _TxaOptional


class TxaApplyingInput(_TxaBaseModel):
    birth: BirthInput
    moment: _TxaOptional[str] = None  # ISO datetime; defaults to now UTC
    tradition: _TxaOptional[str] = "both"  # "western", "vedic", or "both"
    min_orb: _TxaOptional[float] = 0.0
    max_orb: _TxaOptional[float] = 8.0


class TxaUpcomingInput(_TxaBaseModel):
    birth: BirthInput
    days_ahead: _TxaOptional[int] = 30
    moment_start: _TxaOptional[str] = None
    tradition: _TxaOptional[str] = "western"
    step_hours: _TxaOptional[float] = 6.0


def _txa_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/transit/applying_aspects_to_natal")
def txa_applying_ep(inp: TxaApplyingInput, _: str = Depends(verify_key)):
    """Currently-active transit aspects to natal planets with applying/separating + orb."""
    return txa_handle_applying(
        _txa_birth_dict(inp.birth),
        moment=inp.moment,
        tradition=inp.tradition or "both",
        min_orb=inp.min_orb if inp.min_orb is not None else 0.0,
        max_orb=inp.max_orb if inp.max_orb is not None else 8.0,
    )


@app.post("/astro/transit/upcoming_exact_aspects")
def txa_upcoming_ep(inp: TxaUpcomingInput, _: str = Depends(verify_key)):
    """Forward-step Swiss Eph to find upcoming exact transit-to-natal aspects."""
    return txa_handle_upcoming(
        _txa_birth_dict(inp.birth),
        days_ahead=inp.days_ahead or 30,
        moment_start=inp.moment_start,
        tradition=inp.tradition or "western",
        step_hours=inp.step_hours or 6.0,
    )

# ── END TRANSIT ASPECTS U3 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_txa_u3_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_txa_u3_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ Transit Aspects U3 patched into main.py")
    print("   2 new endpoints under /astro/transit/* — engine reaches 261 endpoints")


if __name__ == "__main__":
    main()
