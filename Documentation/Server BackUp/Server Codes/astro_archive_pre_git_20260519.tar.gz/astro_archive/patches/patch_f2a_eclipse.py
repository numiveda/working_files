#!/usr/bin/env python3
"""
patch_f2a_eclipse.py
─────────────────────────────────────────────────────────────────────────
F2a — Eclipse module: 3 endpoints (natal_eclipses, upcoming, sade_sati_extension)

PREREQUISITES:
    - /opt/astro/eclipse.py must be present (scp'd separately)
    - F1a marker must be present (we splice the import block after F1a/F1b)

PHASES:
    A — Preconditions + smoke test that eclipse.py imports cleanly
    B — Inject import block in main.py
    C — Inject EclipseInput Pydantic class
    D — Append 3 endpoint registrations
    E — Snapshot
    F — Full layered smoke INCLUDING main.py (U10v2 hardening pattern)

Idempotent. Auto-rollback on syntax or smoke failure.

Usage:
    sudo python3 /opt/astro/patch_f2a_eclipse.py

Author: Claude (F2a, 2026-05-17)
"""

import os
import sys
import shutil
import subprocess
import py_compile
from datetime import datetime

MAIN_PY     = "/opt/astro/main.py"
ECLIPSE_PY  = "/opt/astro/eclipse.py"

MARKER_IMPORT     = "# ── F2a: Eclipse module imports (2026-05-17) ──"
MARKER_INPUT_CLS  = "# ── F2a: EclipseInput (2026-05-17) ──"
MARKER_ENDPOINTS  = "# ── F2a: /astro/eclipse/* endpoints (2026-05-17) ──"

# Anchor: the F1b import block (which extends F1a's). We splice F2a imports after it.
F1B_IMPORT_TAIL = """    MATRIX_HARD_CEILING        as REL_MATRIX_HARD_CEILING,
)"""

# Replacement: F1b block unchanged + F2a import lines appended right after
F1B_PLUS_F2A_IMPORT_BLOCK = """    MATRIX_HARD_CEILING        as REL_MATRIX_HARD_CEILING,
)


{MARKER_IMPORT}
from eclipse import (
    handle_natal_eclipses                  as ecl_handle_natal_eclipses,
    handle_upcoming_eclipses               as ecl_handle_upcoming_eclipses,
    handle_sade_sati_eclipse_extension     as ecl_handle_sade_sati_extension,
    NATAL_WINDOW_DEFAULT_DAYS              as ECL_NATAL_WINDOW_DEFAULT,
    NATAL_WINDOW_MAX_DAYS                  as ECL_NATAL_WINDOW_MAX,
    UPCOMING_YEARS_DEFAULT                 as ECL_UPCOMING_YEARS_DEFAULT,
    UPCOMING_YEARS_MAX                     as ECL_UPCOMING_YEARS_MAX,
)""".replace("{MARKER_IMPORT}", MARKER_IMPORT)


# Anchor: the RelationshipInput class (F1a marker) — we splice EclipseInput after
RELATIONSHIP_INPUT_ANCHOR = """# ── F1a: RelationshipInput (2026-05-17) ──
class RelationshipInput(BaseModel):
    person1: BirthInput
    person2: BirthInput
    # Optional context — improves synthesis but never required.
    # For mentor: role1/role2 ∈ {"mentor", "mentee"}
    # For family: any free-text label (e.g. "mother", "elder_sibling")
    role1: Optional[str] = None
    role2: Optional[str] = None
    # For family endpoint only: "parent-child" | "sibling" | "extended"
    subtype: Optional[str] = None"""

ECLIPSE_INPUT_BLOCK = '''

{MARKER_INPUT_CLS}
class EclipseInput(BaseModel):
    """Input for /astro/eclipse/* endpoints (and Sade-Sati eclipse extension)."""
    birth: BirthInput
    # natal_eclipses: window (days) before+after birth; default 30, max 180
    window_days: Optional[int] = None
    # upcoming_eclipses
    query_date: Optional[str] = None    # YYYY-MM-DD
    years_ahead: Optional[int] = None   # default 5, max 100
'''.replace("{MARKER_INPUT_CLS}", MARKER_INPUT_CLS)


F2A_ENDPOINT_BLOCK = '''


{MARKER_ENDPOINTS}

@app.post("/astro/eclipse/natal_eclipses", dependencies=[Depends(verify_key)])
def eclipse_natal_eclipses(e: EclipseInput):
    """
    Solar+lunar eclipses around birth (configurable window).
    Default ±30 days, max ±180 days. Classical interaction analysis vs
    natal lagna/Moon/Sun: lagna-grahan, chandra-grahan, surya-grahan triggers,
    plus BPHS Ch.25 house-from-Moon interpretation.
    """
    try:
        birth_dict = {
            "dob": e.birth.dob, "time": e.birth.time,
            "lat": e.birth.lat, "lon": e.birth.lon,
            "timezone": e.birth.timezone,
        }
        wd = e.window_days if e.window_days is not None else ECL_NATAL_WINDOW_DEFAULT
        return ecl_handle_natal_eclipses(birth_dict, window_days=wd)
    except Exception as ex:
        raise HTTPException(status_code=400, detail=str(ex))


@app.post("/astro/eclipse/upcoming", dependencies=[Depends(verify_key)])
def eclipse_upcoming(e: EclipseInput):
    """
    Eclipses ahead with personal-impact analysis.
    Default 5 years ahead, max 100 years. Each eclipse annotated with
    natal interaction (distance from lagna/Moon/Sun, BPHS house-from-Moon).
    """
    try:
        birth_dict = {
            "dob": e.birth.dob, "time": e.birth.time,
            "lat": e.birth.lat, "lon": e.birth.lon,
            "timezone": e.birth.timezone,
        }
        ya = e.years_ahead if e.years_ahead is not None else ECL_UPCOMING_YEARS_DEFAULT
        return ecl_handle_upcoming_eclipses(
            birth_dict, query_date=e.query_date, years_ahead=ya)
    except Exception as ex:
        raise HTTPException(status_code=400, detail=str(ex))


@app.post("/astro/eclipse/sade_sati_extension", dependencies=[Depends(verify_key)])
def eclipse_sade_sati_extension(e: EclipseInput):
    """
    Saturn-eclipse intersection during Sade Sati.

    Layers eclipse computation over the rich Sade Sati handler. Lists eclipses
    within ±2 years of query_date and marks those where Saturn (at eclipse
    moment) falls in the 12th/1st/2nd from natal Moon — the active Sade Sati
    zone, classically signifying intensification of the Sade Sati phase.
    """
    try:
        birth_dict = {
            "dob": e.birth.dob, "time": e.birth.time,
            "lat": e.birth.lat, "lon": e.birth.lon,
            "timezone": e.birth.timezone,
        }
        return ecl_handle_sade_sati_extension(
            birth_dict, query_date=e.query_date)
    except Exception as ex:
        raise HTTPException(status_code=400, detail=str(ex))
'''.replace("{MARKER_ENDPOINTS}", MARKER_ENDPOINTS)


# ═══════════════════════════════════════════════════════════════════════
# Utilities
# ═══════════════════════════════════════════════════════════════════════

def fail(msg, restore_pairs=None):
    print(f"\n❌ ERROR: {msg}")
    if restore_pairs:
        for backup, target in restore_pairs:
            if backup and os.path.exists(backup):
                shutil.copy2(backup, target)
                print(f"   🔄 Restored {target} from {backup}")
    sys.exit(1)


def syntax_check(path, restore_pairs=None):
    try:
        py_compile.compile(path, doraise=True)
        print(f"   ✅ Syntax OK: {path}")
    except py_compile.PyCompileError as e:
        fail(f"Syntax error in {path}: {e}", restore_pairs=restore_pairs)


def smoke_test_as_trading():
    """Layered smoke INCLUDING main.py (U10v2 hardening pattern)."""
    smoke_script = """
import sys, traceback
sys.path.insert(0, '/opt/astro')
layers = [
    ('swisseph',      'swisseph'),
    ('dashaflow',     'dashaflow'),
    ('astro_helpers', 'astro_helpers'),
    ('compatibility', 'compatibility'),
    ('relationships', 'relationships'),
    ('nakshatra',     'nakshatra'),
    ('transit',       'transit'),
    ('eclipse',       'eclipse'),
    ('main',          'main'),
]
for label, modname in layers:
    try:
        __import__(modname)
        print(f'OK    {label}')
    except Exception:
        print(f'FAIL  {label}')
        traceback.print_exc()
        sys.exit(1)

from eclipse import (
    handle_natal_eclipses, handle_upcoming_eclipses,
    handle_sade_sati_eclipse_extension,
    NATAL_WINDOW_DEFAULT_DAYS, NATAL_WINDOW_MAX_DAYS,
    UPCOMING_YEARS_DEFAULT, UPCOMING_YEARS_MAX,
)
print(f'OK    eclipse module API '
      f'(natal_default={NATAL_WINDOW_DEFAULT_DAYS}, natal_max={NATAL_WINDOW_MAX_DAYS}, '
      f'upcoming_default={UPCOMING_YEARS_DEFAULT}, upcoming_max={UPCOMING_YEARS_MAX})')

import main
print(f'OK    main.app has {len(main.app.routes)} routes registered')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_script] if is_root
           else ["python3", "-c", smoke_script])
    result = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.stderr.strip():
        print(f"   ── stderr ──")
        for line in result.stderr.strip().split("\n"):
            print(f"   {line}")
    return result.returncode == 0


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════

def main():
    print("=" * 70)
    print("F2a — Eclipse module installer (3 endpoints)")
    print("=" * 70)

    if not os.path.exists(MAIN_PY):
        fail(f"{MAIN_PY} not found")
    if not os.path.exists(ECLIPSE_PY):
        fail(f"{ECLIPSE_PY} not found — scp it to /opt/astro/ first")
    print(f"✅ Found {ECLIPSE_PY}")

    # Sanity check eclipse.py loads
    print("\n── Pre-check: eclipse.py imports cleanly as user `trading` ──")
    smoke_pre = """
import sys
sys.path.insert(0, '/opt/astro')
import eclipse
print(f'eclipse module loaded, public funcs: '
      f'{[n for n in dir(eclipse) if n.startswith(\"handle_\")]}')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_pre] if is_root
           else ["python3", "-c", smoke_pre])
    r = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if r.returncode != 0:
        fail(f"eclipse.py failed to import:\n{r.stderr}\n{r.stdout}")
    print(f"   {r.stdout.strip()}")

    with open(MAIN_PY, "r") as f:
        content = f.read()
    orig_size = len(content)
    orig_lines = content.count("\n") + 1
    print(f"\nmain.py: {orig_size} bytes, {orig_lines} lines")

    # Idempotency
    if (MARKER_IMPORT in content
            and MARKER_INPUT_CLS in content
            and MARKER_ENDPOINTS in content):
        print("\n✅ All F2a markers already present — patch was applied. No changes.")
        return

    # Anchor validation
    if F1B_IMPORT_TAIL not in content:
        fail("F1b import tail anchor not found in main.py — was F1b applied?")
    print("✅ F1b anchor confirmed")
    if RELATIONSHIP_INPUT_ANCHOR not in content:
        fail("RelationshipInput anchor not found in main.py — was F1a applied?")
    print("✅ F1a anchor confirmed")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    main_backup = f"{MAIN_PY}.before_f2a_{ts}"
    shutil.copy2(MAIN_PY, main_backup)
    print(f"✅ Backup: {main_backup}")

    # ── Phase B: Inject import block ──
    if MARKER_IMPORT not in content:
        content = content.replace(F1B_IMPORT_TAIL, F1B_PLUS_F2A_IMPORT_BLOCK, 1)
        print("✅ Injected F2a import block after F1b imports")
    else:
        print("⏭️  F2a import marker present, skipping")

    # ── Phase C: Inject EclipseInput class after RelationshipInput ──
    if MARKER_INPUT_CLS not in content:
        # Insert AFTER the RelationshipInput class
        content = content.replace(
            RELATIONSHIP_INPUT_ANCHOR,
            RELATIONSHIP_INPUT_ANCHOR + ECLIPSE_INPUT_BLOCK,
            1
        )
        print("✅ Injected EclipseInput class after RelationshipInput")
    else:
        print("⏭️  EclipseInput marker present, skipping")

    # ── Phase D: Append endpoints ──
    if MARKER_ENDPOINTS not in content:
        if not content.endswith("\n"):
            content += "\n"
        content += F2A_ENDPOINT_BLOCK
        print("✅ Appended 3 F2a endpoint registrations")
    else:
        print("⏭️  Endpoint marker present, skipping")

    with open(MAIN_PY, "w") as f:
        f.write(content)
    new_size = len(content)
    new_lines = content.count("\n") + 1
    print(f"\n✅ Wrote main.py: {new_size} bytes ({new_size - orig_size:+d}), "
          f"{new_lines} lines ({new_lines - orig_lines:+d})")

    # ── Phase E: Snapshot + syntax ──
    snap = f"{MAIN_PY}.after_f2a_{ts}"
    shutil.copy2(MAIN_PY, snap)
    print(f"✅ Snapshot: {snap}")
    syntax_check(MAIN_PY, restore_pairs=[(main_backup, MAIN_PY)])

    # ── Phase F: Full smoke (including main.py) ──
    print("\n── Phase F: Layered smoke (as user `trading`, INCLUDES main.py) ──")
    ok = smoke_test_as_trading()
    if not ok:
        fail("Smoke test failed — rolling back main.py",
             restore_pairs=[(main_backup, MAIN_PY)])

    print("\n" + "=" * 70)
    print("F2a PATCH APPLIED — next steps:")
    print("  sudo systemctl restart astro && sleep 3")
    print("  curl http://localhost:8001/astro/health      ← MUST return 200")
    print("  Then run verification sweep (see F2A runbook)")
    print("=" * 70)


if __name__ == "__main__":
    main()
