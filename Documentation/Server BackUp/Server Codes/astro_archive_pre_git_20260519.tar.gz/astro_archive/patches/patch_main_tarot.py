"""
patch_main_tarot.py — Wires 10 Tarot (D2) endpoints into main.py.

Uses verify_key auth. Idempotent.

Run from /opt/astro:
    sudo python3 patch_main_tarot.py
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── TAROT D2 MODULE ──"


IMPORT_BLOCK = '''
# ── TAROT D2 MODULE IMPORTS ──
from tarot import (
    handle_profile           as tarot_handle_profile,
    handle_daily_card        as tarot_handle_daily_card,
    handle_three_card        as tarot_handle_three_card,
    handle_celtic_cross      as tarot_handle_celtic_cross,
    handle_year_ahead        as tarot_handle_year_ahead,
    handle_decision          as tarot_handle_decision,
    handle_card_meaning      as tarot_handle_card_meaning,
    handle_suit_overview     as tarot_handle_suit_overview,
    handle_shuffle           as tarot_handle_shuffle,
    handle_question_focused  as tarot_handle_question_focused,
)
# ── END TAROT D2 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── TAROT D2 MODULE ──
# Phase D — Module D2 — Rider-Waite-Smith Tarot (10 endpoints)
# Source: RWS deck (1909, public domain); Waite's Pictorial Key (1910)
# Architecture: Birth-anchored deterministic RNG seeding; no chart casting
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _TarotBaseModel
from typing import Optional as _TarotOptional


class TarotBirthInput(_TarotBaseModel):
    """Optional birth — if absent, draws are fresh-random."""
    dob: _TarotOptional[str] = None
    time: _TarotOptional[str] = None
    fresh_shuffle: _TarotOptional[bool] = False


class TarotProfileInput(TarotBirthInput):
    pass


class TarotDailyInput(TarotBirthInput):
    target_date: _TarotOptional[str] = None  # YYYY-MM-DD, defaults to today


class TarotSpreadInput(TarotBirthInput):
    context: _TarotOptional[str] = ""


class TarotYearInput(TarotBirthInput):
    start_year: _TarotOptional[int] = None


class TarotDecisionInput(TarotBirthInput):
    decision_context: _TarotOptional[str] = ""


class TarotCardLookupInput(_TarotBaseModel):
    card_name: str


class TarotSuitInput(_TarotBaseModel):
    suit: _TarotOptional[str] = None


class TarotQuestionInput(TarotBirthInput):
    question_text: str


def _tarot_birth_to_dict(inp) -> _TarotOptional[dict]:
    """Convert TarotBirthInput to dict-or-None for engine."""
    if inp.dob is None:
        return None
    return {"dob": inp.dob, "time": inp.time or "12:00"}


@app.post("/astro/tarot/profile")
def tarot_profile_ep(inp: TarotProfileInput, _: str = Depends(verify_key)):
    """Master Tarot reading — birth-seeded Celtic Cross + daily card synthesis."""
    return tarot_handle_profile(_tarot_birth_to_dict(inp))


@app.post("/astro/tarot/daily_card")
def tarot_daily_ep(inp: TarotDailyInput, _: str = Depends(verify_key)):
    """Single card for the target date (defaults to today). Birth-seeded if DOB provided."""
    return tarot_handle_daily_card(_tarot_birth_to_dict(inp), inp.target_date,
                                    inp.fresh_shuffle or False)


@app.post("/astro/tarot/three_card")
def tarot_three_card_ep(inp: TarotSpreadInput, _: str = Depends(verify_key)):
    """Past/Present/Future three-card spread."""
    return tarot_handle_three_card(_tarot_birth_to_dict(inp), inp.context or "",
                                    inp.fresh_shuffle or False)


@app.post("/astro/tarot/celtic_cross")
def tarot_celtic_ep(inp: TarotSpreadInput, _: str = Depends(verify_key)):
    """Full 10-card Celtic Cross spread."""
    return tarot_handle_celtic_cross(_tarot_birth_to_dict(inp), inp.context or "",
                                      inp.fresh_shuffle or False)


@app.post("/astro/tarot/year_ahead")
def tarot_year_ahead_ep(inp: TarotYearInput, _: str = Depends(verify_key)):
    """12 cards, one per month, for the start_year (defaults to current year)."""
    return tarot_handle_year_ahead(_tarot_birth_to_dict(inp), inp.start_year,
                                    inp.fresh_shuffle or False)


@app.post("/astro/tarot/decision")
def tarot_decision_ep(inp: TarotDecisionInput, _: str = Depends(verify_key)):
    """5-card decision spread (situation/path-A/path-B/needed/recommendation)."""
    return tarot_handle_decision(_tarot_birth_to_dict(inp), inp.decision_context or "",
                                  inp.fresh_shuffle or False)


@app.post("/astro/tarot/card_meaning")
def tarot_card_meaning_ep(inp: TarotCardLookupInput, _: str = Depends(verify_key)):
    """Lookup a specific card by name (case-insensitive). E.g. 'The Fool', 'Ace of Cups'."""
    return tarot_handle_card_meaning(inp.card_name)


@app.post("/astro/tarot/suit_overview")
def tarot_suit_overview_ep(inp: TarotSuitInput, _: str = Depends(verify_key)):
    """Suit-level themes. If suit=None, returns overview of all 4 suits + Major Arcana."""
    return tarot_handle_suit_overview(inp.suit)


@app.post("/astro/tarot/shuffle")
def tarot_shuffle_ep(_: str = Depends(verify_key)):
    """Fresh non-deterministic full deck shuffle. Returns 78-card order."""
    return tarot_handle_shuffle()


@app.post("/astro/tarot/question_focused")
def tarot_question_focused_ep(inp: TarotQuestionInput, _: str = Depends(verify_key)):
    """3-card draw focused on user-provided question. Deterministic per question+birth."""
    return tarot_handle_question_focused(inp.question_text, _tarot_birth_to_dict(inp),
                                          inp.fresh_shuffle or False)

# ── END TAROT D2 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present in main.py.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_tarot_d2_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_tarot_d2_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ Tarot D2 module patched into main.py")
    print("   10 endpoints under /astro/tarot/* — engine reaches 227 endpoints")


if __name__ == "__main__":
    main()
