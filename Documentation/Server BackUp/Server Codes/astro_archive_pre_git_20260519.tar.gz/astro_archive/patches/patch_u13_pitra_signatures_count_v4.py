#!/usr/bin/env python3
"""
patch_u13_pitra_signatures_count.py
─────────────────────────────────────────────────────────────────────────
U13 — Fix Pitra Dosha signature counting semantics.

Background:
  /astro/pitra_dosha/profile returns `signatures_checked: len(sigs)` where
  `sigs` is the list of DETECTED signatures (positively present, or error
  fallback). For Arunav (no Pitra Dosha): returns 0.

  The field name "signatures_checked" reads as "how many signature types
  the engine evaluated" — which is NOT what it returns. The actual value
  is "how many detected".

  True signature type count: 12 (when 9th lord data is available, which
  is the normal case) or 9 (rare edge case when 9th lord data missing).

Refactor:
  _detect_signatures now returns:
    {"signatures": [...detected...], "types_evaluated": <int>}

  Both handle_pitra_dosha_profile and handle_pitra_dosha_intensity
  consume the new shape and expose `signature_types_evaluated` in their
  response. `signatures_checked` is preserved for back-compat with the
  old (detected-count) meaning.

PREREQUISITES:
  - F2b applied
  - All subsequent F-modules (F3, F9, F6, F6b) deployed and stable

PHASES:
  A — Pre-check
  B — Refactor _detect_signatures internal counting
  C — Update handle_pitra_dosha_profile caller + response shape
  D — Update handle_pitra_dosha_intensity caller + response shape
  E — Snapshot + syntax check
  F — Layered smoke + functional assertions

Idempotent. Auto-rollback on failure.

Usage:
    sudo python3 /opt/astro/patch_u13_pitra_signatures_count.py

Author: Claude (U13, 2026-05-18)
"""

import os
import sys
import shutil
import subprocess
import py_compile
from datetime import datetime

PITRA_PY = "/opt/astro/pitra_dosha.py"
MAIN_PY  = "/opt/astro/main.py"

MARKER_U13 = "# ── U13: signature type counting refactor (2026-05-18) ──"


# ═══════════════════════════════════════════════════════════════════════
# Anchor 1: _detect_signatures function — replace the entire function
# ═══════════════════════════════════════════════════════════════════════

OLD_FN_HEADER = """def _detect_signatures(prim: Dict[str, Any],
                        birth: Dict[str, Any]) -> List[Dict[str, Any]]:
    \"\"\"
    Detect classical Pitra Dosha signatures. Each entry:
      {name, present, severity (1-3), evidence (text), source}

    Severity scale:
      1 = mild signature  (counts but not dominant)
      2 = moderate
      3 = strong/primary
    \"\"\"
    sigs: List[Dict[str, Any]] = []"""

NEW_FN_HEADER = """def _detect_signatures(prim: Dict[str, Any],
                        birth: Dict[str, Any]) -> Dict[str, Any]:
    \"\"\"
    Detect classical Pitra Dosha signatures. Returns:
      {
        "signatures":      [...list of detected signatures...],
        "types_evaluated": int  # how many distinct signature types we checked
      }

    Each signature entry: {name, present, severity (1-3), evidence (text), source}

    Severity scale:
      1 = mild signature  (counts but not dominant)
      2 = moderate
      3 = strong/primary

    %s
    Signature type evaluation count:
      - Signatures 1-5b always evaluated: 8 types
      - Signature 6 (9th lord) evaluated only when nl_data available: +3 types
      - Signature 8 (Surya grahan) always evaluated: +1 type
      Total: 9 minimum, 12 typical (when 9th lord data present)
    \"\"\"
    sigs: List[Dict[str, Any]] = []
    types_evaluated: int = 0""" % MARKER_U13


# ═══════════════════════════════════════════════════════════════════════
# Anchor 2: Signature 1 block — add counter
# ═══════════════════════════════════════════════════════════════════════

OLD_SIG1 = """    # ── Signature 1: Sun-Rahu conjunction (classical PRIMARY trigger) ──
    sun_rahu_same_house = (sun.get("house") == rahu.get("house"))"""

NEW_SIG1 = """    # ── Signature 1: Sun-Rahu conjunction (classical PRIMARY trigger) ──
    types_evaluated += 1
    sun_rahu_same_house = (sun.get("house") == rahu.get("house"))"""


# ═══════════════════════════════════════════════════════════════════════
# Anchor 3: Signature 2 block
# ═══════════════════════════════════════════════════════════════════════

OLD_SIG2 = """    # ── Signature 2: Sun-Ketu conjunction ──
    sun_ketu_same_house = (sun.get("house") == ketu.get("house"))"""

NEW_SIG2 = """    # ── Signature 2: Sun-Ketu conjunction ──
    types_evaluated += 1
    sun_ketu_same_house = (sun.get("house") == ketu.get("house"))"""


# ═══════════════════════════════════════════════════════════════════════
# Anchor 4: Signature 3 block (counts as 2 — rahu_aspects + ketu_aspects)
# ═══════════════════════════════════════════════════════════════════════

OLD_SIG3 = """    # ── Signature 3: Rahu/Ketu aspects Sun by sign ──
    sun_sign = sun.get("sign")"""

NEW_SIG3 = """    # ── Signature 3: Rahu/Ketu aspects Sun by sign ──
    types_evaluated += 2  # rahu_aspects_sun + ketu_aspects_sun
    sun_sign = sun.get("sign")"""


# ═══════════════════════════════════════════════════════════════════════
# Anchor 5: Signature 4 block (sun_saturn_conjunction + saturn_aspects_sun
#   are mutually exclusive — only one path fires; both are evaluated together)
# ═══════════════════════════════════════════════════════════════════════

OLD_SIG4 = """    # ── Signature 4: Sun-Saturn conjunction or Saturn aspects Sun ──
    sun_saturn_same_house = (sun.get("house") == saturn.get("house"))"""

NEW_SIG4 = """    # ── Signature 4: Sun-Saturn conjunction or Saturn aspects Sun ──
    types_evaluated += 1
    sun_saturn_same_house = (sun.get("house") == saturn.get("house"))"""


# ═══════════════════════════════════════════════════════════════════════
# Anchor 6: Signature 5 block (sun_combust + sun_weak_dignity, both eval'd)
# ═══════════════════════════════════════════════════════════════════════

OLD_SIG5 = """    # ── Signature 5: Sun is combust or fallen (debilitated) ──
    if sun.get("is_combust"):"""

NEW_SIG5 = """    # ── Signature 5: Sun is combust or fallen (debilitated) ──
    types_evaluated += 2  # sun_combust + sun_weak_dignity (both evaluated)
    if sun.get("is_combust"):"""


# ═══════════════════════════════════════════════════════════════════════
# Anchor 7: Signature 6 — 9th lord (3 sub-types, evaluated only when nl_data exists)
# ═══════════════════════════════════════════════════════════════════════

OLD_SIG6 = """    # ── Signature 6: 9th lord afflicted ──
    nl_data = prim.get("ninth_lord_data") or {}
    if nl_data:"""

NEW_SIG6 = """    # ── Signature 6: 9th lord afflicted ──
    nl_data = prim.get("ninth_lord_data") or {}
    if nl_data:
        types_evaluated += 3  # ninth_lord_in_dusthana + _weak + _combust"""


# ═══════════════════════════════════════════════════════════════════════
# Anchor 8: Signature 8 — Surya grahan (Signature 7 is a no-op, skip)
# ═══════════════════════════════════════════════════════════════════════

OLD_SIG8 = """    # ── Signature 8: Surya grahan (eclipse on natal Sun) — reuse F2a! ──
    # This is the F2a/F2b integration point.
    try:"""

NEW_SIG8 = """    # ── Signature 8: Surya grahan (eclipse on natal Sun) — reuse F2a! ──
    # This is the F2a/F2b integration point.
    types_evaluated += 1
    try:"""


# ═══════════════════════════════════════════════════════════════════════
# Anchor 9: Return statement — change from "return sigs" to dict
# ═══════════════════════════════════════════════════════════════════════

# Use the surya_grahan fallback's closing as predecessor anchor (unique enough)
OLD_RETURN = """            "source":   "N/A",
        })

    return sigs"""

NEW_RETURN = """            "source":   "N/A",
        })

    return {"signatures": sigs, "types_evaluated": types_evaluated}"""


# ═══════════════════════════════════════════════════════════════════════
# Anchor 10: handle_pitra_dosha_profile — update caller
# ═══════════════════════════════════════════════════════════════════════

OLD_PROFILE_CALL = """    sigs = _detect_signatures(prim, birth)
    present = [s for s in sigs if s.get("present")]

    # Classify"""

NEW_PROFILE_CALL = """    detection_result = _detect_signatures(prim, birth)
    sigs = detection_result["signatures"]
    types_evaluated = detection_result["types_evaluated"]
    present = [s for s in sigs if s.get("present")]

    # Classify"""


# Add the new field to the profile response (after signatures_checked)
OLD_PROFILE_RESPONSE = """        "signatures_present":    present,
        "signatures_checked":    len(sigs),
        "signatures_present_count": len(present),"""

NEW_PROFILE_RESPONSE = """        "signatures_present":         present,
        "signatures_checked":         len(sigs),          # detected (back-compat with U13)
        "signature_types_evaluated":  types_evaluated,     # NEW: total signature TYPES checked
        "signatures_present_count":   len(present),"""


# ═══════════════════════════════════════════════════════════════════════
# Anchor 11: handle_pitra_dosha_intensity — update caller + add field
# ═══════════════════════════════════════════════════════════════════════

OLD_INTENSITY_CALL = """    sigs = _detect_signatures(prim, birth)
    present = [s for s in sigs if s.get("present")]

    SEVERITY_WEIGHT = {3: 30, 2: 15, 1: 5}"""

NEW_INTENSITY_CALL = """    detection_result = _detect_signatures(prim, birth)
    sigs = detection_result["signatures"]
    types_evaluated = detection_result["types_evaluated"]
    present = [s for s in sigs if s.get("present")]

    SEVERITY_WEIGHT = {3: 30, 2: 15, 1: 5}"""


OLD_INTENSITY_RESPONSE = """        "signatures_present_count": len(present),
        "top_contributors": top_contributors,
        "classical_sources": F2B_CITATIONS["intensity"],
    }"""

NEW_INTENSITY_RESPONSE = """        "signatures_present_count":   len(present),
        "signature_types_evaluated":  types_evaluated,     # NEW (U13)
        "top_contributors": top_contributors,
        "classical_sources": F2B_CITATIONS["intensity"],
    }"""


# ═══════════════════════════════════════════════════════════════════════
# Utilities
# ═══════════════════════════════════════════════════════════════════════

def fail(msg, restore_pairs=None):
    print(f"\n❌ ERROR: {msg}")
    if restore_pairs:
        for backup, target in restore_pairs:
            if backup and os.path.exists(backup):
                shutil.copy2(backup, target)
                print(f"   🔄 Restored {target} from {backup}")
    sys.exit(1)


def syntax_check(path, restore_pairs=None):
    try:
        py_compile.compile(path, doraise=True)
        print(f"   ✅ Syntax OK: {path}")
    except py_compile.PyCompileError as e:
        fail(f"Syntax error in {path}: {e}", restore_pairs=restore_pairs)


def smoke_test_as_trading():
    """Layered smoke INCLUDING main.py + U13 functional assertions."""
    smoke_script = r"""
import sys, traceback
sys.path.insert(0, '/opt/astro')
layers = [
    ('swisseph',       'swisseph'),
    ('dashaflow',      'dashaflow'),
    ('astro_helpers',  'astro_helpers'),
    ('compatibility',  'compatibility'),
    ('relationships',  'relationships'),
    ('nakshatra',      'nakshatra'),
    ('transit',        'transit'),
    ('eclipse',        'eclipse'),
    ('pitra_dosha',    'pitra_dosha'),
    ('strength',       'strength'),
    ('birthday_quick', 'birthday_quick'),
    ('pet_astro',      'pet_astro'),
    ('pet_muhurta',    'pet_muhurta'),
    ('main',           'main'),
]
for label, modname in layers:
    try:
        __import__(modname)
        print(f'OK    {label}')
    except Exception:
        print(f'FAIL  {label}')
        traceback.print_exc()
        sys.exit(1)

# U13 functional asserts: _detect_signatures returns the new shape
from pitra_dosha import _detect_signatures, _extract_pitra_primitives, handle_pitra_dosha_profile, handle_pitra_dosha_intensity

birth_arunav = {"dob": "1980-12-31", "time": "09:40",
                 "lat": 26.1445, "lon": 91.7362, "timezone": "Asia/Kolkata"}

prim = _extract_pitra_primitives(birth_arunav)
result = _detect_signatures(prim, birth_arunav)

# Shape
assert isinstance(result, dict), f"_detect_signatures should return dict, got {type(result)}"
assert "signatures" in result, f"missing 'signatures' key: {list(result.keys())}"
assert "types_evaluated" in result, f"missing 'types_evaluated' key: {list(result.keys())}"
assert isinstance(result["signatures"], list)
assert isinstance(result["types_evaluated"], int)

# Range (should be 9-12)
assert 9 <= result["types_evaluated"] <= 12, f"types_evaluated should be 9-12, got {result['types_evaluated']}"
print(f'OK    U13 _detect_signatures returns dict with types_evaluated={result["types_evaluated"]}')

# Arunav should have 12 types evaluated (has 9th lord data)
assert result["types_evaluated"] == 12, f"Arunav (has 9th lord data) should have 12 types_evaluated, got {result['types_evaluated']}"
print('OK    U13 Arunav has 12 signature types evaluated (9th lord data present)')

# Endpoint response check
r = handle_pitra_dosha_profile(birth_arunav)
assert "signatures_checked" in r, "profile response missing signatures_checked (back-compat broken)"
assert "signature_types_evaluated" in r, "profile response missing new signature_types_evaluated field"
assert r["signature_types_evaluated"] == 12, f"profile types_evaluated should be 12, got {r['signature_types_evaluated']}"
assert r["signatures_checked"] == 0, f"Arunav has no detected signatures; signatures_checked should be 0, got {r['signatures_checked']}"
print(f'OK    U13 /pitra_dosha/profile response: signatures_checked=0, signature_types_evaluated=12')

# Intensity endpoint check
r = handle_pitra_dosha_intensity(birth_arunav)
assert "signature_types_evaluated" in r, "intensity response missing new field"
assert r["signature_types_evaluated"] == 12
print(f'OK    U13 /pitra_dosha/intensity response includes signature_types_evaluated=12')

import main
print(f'OK    main.app has {len(main.app.routes)} routes registered')
"""
    is_root = (os.geteuid() == 0)
    cmd = (["sudo", "-u", "trading", "python3", "-c", smoke_script] if is_root
           else ["python3", "-c", smoke_script])
    result = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.stderr.strip():
        print(f"   ── stderr ──")
        for line in result.stderr.strip().split("\n"):
            print(f"   {line}")
    return result.returncode == 0


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════

def main():
    print("=" * 70)
    print("U13 — Pitra Dosha Signature Type Counting Refactor")
    print("=" * 70)

    if not os.path.exists(PITRA_PY):
        fail(f"{PITRA_PY} not found")

    with open(PITRA_PY, "r") as f:
        content = f.read()
    orig_size = len(content)
    orig_lines = content.count("\n") + 1
    print(f"\npitra_dosha.py: {orig_size} bytes, {orig_lines} lines")

    # Idempotency check
    if MARKER_U13 in content:
        print("\n✅ U13 marker already present — patch was applied. No changes.")
        return

    # Anchor validation — verify all expected anchors exist
    expected_anchors = [
        ("function header",        OLD_FN_HEADER),
        ("sig 1 anchor",            OLD_SIG1),
        ("sig 2 anchor",            OLD_SIG2),
        ("sig 3 anchor",            OLD_SIG3),
        ("sig 4 anchor",            OLD_SIG4),
        ("sig 5 anchor",            OLD_SIG5),
        ("sig 6 anchor",            OLD_SIG6),
        ("sig 8 anchor",            OLD_SIG8),
        ("return statement",        OLD_RETURN),
        ("profile call",            OLD_PROFILE_CALL),
        ("profile response",        OLD_PROFILE_RESPONSE),
        ("intensity call",          OLD_INTENSITY_CALL),
        ("intensity response",      OLD_INTENSITY_RESPONSE),
    ]
    for name, anchor in expected_anchors:
        if anchor not in content:
            fail(f"Anchor not found: {name}\n  Expected text:\n  {anchor[:200]}...")
    print(f"✅ All 13 anchors confirmed")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    pitra_backup = f"{PITRA_PY}.before_u13_{ts}"
    shutil.copy2(PITRA_PY, pitra_backup)
    print(f"✅ Backup: {pitra_backup}")

    # Apply replacements
    replacements = [
        ("function header",       OLD_FN_HEADER,       NEW_FN_HEADER),
        ("sig 1 counter",          OLD_SIG1,            NEW_SIG1),
        ("sig 2 counter",          OLD_SIG2,            NEW_SIG2),
        ("sig 3 counter",          OLD_SIG3,            NEW_SIG3),
        ("sig 4 counter",          OLD_SIG4,            NEW_SIG4),
        ("sig 5 counter",          OLD_SIG5,            NEW_SIG5),
        ("sig 6 counter",          OLD_SIG6,            NEW_SIG6),
        ("sig 8 counter",          OLD_SIG8,            NEW_SIG8),
        ("return shape",           OLD_RETURN,          NEW_RETURN),
        ("profile call",           OLD_PROFILE_CALL,    NEW_PROFILE_CALL),
        ("profile response",       OLD_PROFILE_RESPONSE, NEW_PROFILE_RESPONSE),
        ("intensity call",         OLD_INTENSITY_CALL,  NEW_INTENSITY_CALL),
        ("intensity response",     OLD_INTENSITY_RESPONSE, NEW_INTENSITY_RESPONSE),
    ]
    for name, old, new in replacements:
        if old in content:
            content = content.replace(old, new, 1)
            print(f"   ✅ Applied: {name}")
        else:
            fail(f"Anchor disappeared mid-patch: {name}",
                 restore_pairs=[(pitra_backup, PITRA_PY)])

    with open(PITRA_PY, "w") as f:
        f.write(content)
    new_size = len(content)
    new_lines = content.count("\n") + 1
    print(f"\n✅ Wrote pitra_dosha.py: {new_size} bytes ({new_size - orig_size:+d}), "
          f"{new_lines} lines ({new_lines - orig_lines:+d})")

    snap = f"{PITRA_PY}.after_u13_{ts}"
    shutil.copy2(PITRA_PY, snap)
    print(f"✅ Snapshot: {snap}")
    syntax_check(PITRA_PY, restore_pairs=[(pitra_backup, PITRA_PY)])

    print("\n── Phase F: Layered smoke (as `trading`, INCLUDES main.py + U13 asserts) ──")
    ok = smoke_test_as_trading()
    if not ok:
        fail("Smoke test failed — rolling back",
             restore_pairs=[(pitra_backup, PITRA_PY)])

    print("\n" + "=" * 70)
    print("U13 PATCH APPLIED — next steps:")
    print("  sudo systemctl restart astro && sleep 3")
    print("  curl http://localhost:8001/astro/health      ← MUST return 200")
    print("  Then verify /astro/pitra_dosha/profile response contains:")
    print("    'signature_types_evaluated': 12")
    print("=" * 70)


if __name__ == "__main__":
    main()
