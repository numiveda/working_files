"""
patch_main_compatibility.py — Wires 12 Compatibility (C1) endpoints into main.py

Uses the verified auth pattern from Phase B (verify_key, not verify_api_key).
Introduces a new Pydantic schema: CompatibilityInput (two BirthInput + relationship_type).

Run from /opt/astro:
    sudo python3 patch_main_compatibility.py

Idempotent.
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── COMPATIBILITY C1 MODULE ──"


IMPORT_BLOCK = '''
# ── COMPATIBILITY C1 MODULE IMPORTS ──
from compatibility import (
    handle_profile                  as compat_handle_profile,
    handle_ashtakoot                as compat_handle_ashtakoot,
    handle_manglik                  as compat_handle_manglik,
    handle_nadi_dosha               as compat_handle_nadi_dosha,
    handle_bhakoot_dosha            as compat_handle_bhakoot_dosha,
    handle_dasha_compatibility      as compat_handle_dasha_compatibility,
    handle_synastry_aspects         as compat_handle_synastry_aspects,
    handle_d9_navamsha_compat       as compat_handle_d9_navamsha_compat,
    handle_seventh_house_synthesis  as compat_handle_seventh_house_synthesis,
    handle_venus_jupiter_synthesis  as compat_handle_venus_jupiter_synthesis,
    handle_longevity_match          as compat_handle_longevity_match,
    handle_timing_for_marriage      as compat_handle_timing_for_marriage,
)
# ── END COMPATIBILITY C1 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── COMPATIBILITY C1 MODULE ──
# Phase C — Module C1 — Two-chart Vedic compatibility (12 endpoints)
# Sources: BPHS Ch. 44, Phaladeepika Ch. 7, Saravali Ch. 27-28,
#          Hora Sara, Muhurta Chintamani, Jataka Parijata Ch. 14
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _CompatBaseModel
from typing import Optional as _CompatOptional

class CompatibilityInput(_CompatBaseModel):
    person1: BirthInput
    person2: BirthInput
    relationship_type: _CompatOptional[str] = "marriage"
    person1_gender: _CompatOptional[str] = "M"
    person2_gender: _CompatOptional[str] = "F"


def _compat_birth_dict(b: BirthInput, gender: str) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
        "gender":   gender,
    }


@app.post("/astro/compat/profile")
def compat_profile_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Master compatibility synthesis — Ashtakoot + Manglik + 7th + karakas + D9 + longevity."""
    return compat_handle_profile(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
        inp.relationship_type or "marriage",
    )


@app.post("/astro/compat/ashtakoot")
def compat_ashtakoot_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Full 8-Kuta 36-point Ashtakoot matching."""
    return compat_handle_ashtakoot(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
        inp.relationship_type or "marriage",
    )


@app.post("/astro/compat/manglik")
def compat_manglik_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Mars dosha analysis for both charts with classical cancellations."""
    return compat_handle_manglik(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/nadi_dosha")
def compat_nadi_dosha_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Nadi Kuta detailed analysis (most weighted: 8/36 points)."""
    return compat_handle_nadi_dosha(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/bhakoot_dosha")
def compat_bhakoot_dosha_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Bhakoot Kuta — Moon-sign distance dosha with cancellations."""
    return compat_handle_bhakoot_dosha(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/dasha_compatibility")
def compat_dasha_compatibility_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Current and upcoming dasha overlap between both natives."""
    return compat_handle_dasha_compatibility(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/synastry_aspects")
def compat_synastry_aspects_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Cross-chart aspect mapping — each person's planets in partner's houses."""
    return compat_handle_synastry_aspects(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/d9_navamsha_compat")
def compat_d9_navamsha_compat_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """D9 Navamsha marriage-chart synthesis (deepest marriage indicator)."""
    return compat_handle_d9_navamsha_compat(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/seventh_house_synthesis")
def compat_seventh_house_synthesis_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Both natives' 7th houses analyzed for partnership indications."""
    return compat_handle_seventh_house_synthesis(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/venus_jupiter_synthesis")
def compat_venus_jupiter_synthesis_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Marriage karakas Venus + Jupiter cross-analysis between charts."""
    return compat_handle_venus_jupiter_synthesis(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/longevity_match")
def compat_longevity_match_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """8th house (Ayur Bhava) comparison for joint longevity per Jataka Parijata Ch. 14."""
    return compat_handle_longevity_match(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )


@app.post("/astro/compat/timing_for_marriage")
def compat_timing_for_marriage_ep(inp: CompatibilityInput, _: str = Depends(verify_key)):
    """Marriage muhurta general guidance + each partner's favorable dasha periods."""
    return compat_handle_timing_for_marriage(
        _compat_birth_dict(inp.person1, inp.person1_gender),
        _compat_birth_dict(inp.person2, inp.person2_gender),
    )

# ── END COMPATIBILITY C1 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present in main.py. Patch already applied.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_compat_c1_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor in main.py — refusing to patch")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_compat_c1_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ Compatibility C1 module patched into main.py")
    print("   12 endpoints under /astro/compat/*")
    print("   Restart with: sudo systemctl restart astro")


if __name__ == "__main__":
    main()
