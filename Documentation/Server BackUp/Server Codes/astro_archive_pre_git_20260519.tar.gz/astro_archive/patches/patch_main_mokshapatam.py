"""
patch_main_mokshapatam.py — Wires 9 Moksha Patam (E2) endpoints into main.py.

Run from /opt/astro:
    sudo python3 patch_main_mokshapatam.py
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── MOKSHAPATAM E2 MODULE ──"


IMPORT_BLOCK = '''
# ── MOKSHAPATAM E2 MODULE IMPORTS ──
from mokshapatam import (
    handle_profile             as mp_handle_profile,
    handle_board_catalog       as mp_handle_board_catalog,
    handle_chakra_catalog      as mp_handle_chakra_catalog,
    handle_past_life_weight    as mp_handle_past_life_weight,
    handle_chakra_analysis     as mp_handle_chakra_analysis,
    handle_cumulative_pattern  as mp_handle_cumulative_pattern,
    handle_journey_narrative   as mp_handle_journey_narrative,
    handle_chart_data          as mp_handle_chart_data,
    handle_validate_journey    as mp_handle_validate_journey,
)
# ── END MOKSHAPATAM E2 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── MOKSHAPATAM E2 MODULE ──
# Phase E — Module E2 — Moksha Patam karmic journey analysis (9 endpoints)
# Source: Classical Indian Moksha Patam (72-square soul-evolution game)
# Port of myMokshaPatam repo (numiveda/myMokshaPatam) — analysis-only architecture
# Client owns game loop; engine analyzes completed journey deterministically.
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _MpBaseModel, Field as _MpField
from typing import Optional as _MpOptional, List as _MpList, Any as _MpAny, Dict as _MpDict


class MpRollItem(_MpBaseModel):
    roll_number: _MpOptional[int] = None
    dice:        _MpOptional[int] = None
    age_before:  _MpOptional[int] = None
    age_after:   _MpOptional[int] = None
    house_after: int
    snake_hit:   _MpOptional[bool] = False
    snake_from:  _MpOptional[int] = None
    snake_to:    _MpOptional[int] = None
    ladder_hit:  _MpOptional[bool] = False
    ladder_from: _MpOptional[int] = None
    ladder_to:   _MpOptional[int] = None


class MpPastLifeWeightInput(_MpBaseModel):
    phase1_roll_count: int


class MpChakraAnalysisInput(_MpBaseModel):
    journey: _MpList[_MpDict[str, _MpAny]]


class MpCumulativePatternInput(_MpBaseModel):
    journey:           _MpList[_MpDict[str, _MpAny]]
    phase1_roll_count: int
    end_condition:     str  # "house_68" or "age_80"
    final_house:       int


class MpJourneyNarrativeInput(_MpBaseModel):
    journey:           _MpList[_MpDict[str, _MpAny]]
    phase1_roll_count: _MpOptional[int] = 0


class MpChartDataInput(_MpBaseModel):
    journey: _MpList[_MpDict[str, _MpAny]]


class MpValidateInput(_MpBaseModel):
    phase1_roll_count: int
    end_condition:     str
    final_house:       int
    final_age:         _MpOptional[int] = None
    total_rolls:       _MpOptional[int] = None
    journey:           _MpList[_MpDict[str, _MpAny]]


class MpProfileInput(_MpBaseModel):
    journey:           _MpList[_MpDict[str, _MpAny]]
    phase1_roll_count: int
    end_condition:     str
    final_house:       int
    final_age:         int
    total_rolls:       _MpOptional[int] = None


@app.post("/astro/mokshapatam/profile")
def mp_profile_ep(inp: MpProfileInput, _: str = Depends(verify_key)):
    """MASTER: full Moksha Patam analysis (validation + chakra + pattern + narrative + chart)."""
    return mp_handle_profile(
        journey=inp.journey,
        phase1_roll_count=inp.phase1_roll_count,
        end_condition=inp.end_condition,
        final_house=inp.final_house,
        final_age=inp.final_age,
        total_rolls=inp.total_rolls,
    )


@app.post("/astro/mokshapatam/board_catalog")
def mp_board_catalog_ep(_: str = Depends(verify_key)):
    """All 72 houses with attributes (chakra, type, snake_to, ladder_to, meaning)."""
    return mp_handle_board_catalog()


@app.post("/astro/mokshapatam/chakra_catalog")
def mp_chakra_catalog_ep(_: str = Depends(verify_key)):
    """All 8 chakras with theme + house assignments."""
    return mp_handle_chakra_catalog()


@app.post("/astro/mokshapatam/past_life_weight")
def mp_past_life_weight_ep(inp: MpPastLifeWeightInput, _: str = Depends(verify_key)):
    """Phase 1 roll count → karma label (very_clear/light/moderate/significant/heavy)."""
    return mp_handle_past_life_weight(inp.phase1_roll_count)


@app.post("/astro/mokshapatam/chakra_analysis")
def mp_chakra_analysis_ep(inp: MpChakraAnalysisInput, _: str = Depends(verify_key)):
    """Per-chakra time/virtue/vice/neutral breakdown of a completed journey."""
    return mp_handle_chakra_analysis(inp.journey)


@app.post("/astro/mokshapatam/cumulative_pattern")
def mp_cumulative_pattern_ep(inp: MpCumulativePatternInput, _: str = Depends(verify_key)):
    """Dominant snake, dominant ladder, trajectory, chakra-most-time, karmic label."""
    return mp_handle_cumulative_pattern(
        journey=inp.journey,
        phase1_roll_count=inp.phase1_roll_count,
        end_condition=inp.end_condition,
        final_house=inp.final_house,
    )


@app.post("/astro/mokshapatam/journey_narrative")
def mp_journey_narrative_ep(inp: MpJourneyNarrativeInput, _: str = Depends(verify_key)):
    """Text narrative of full journey for AI consumption."""
    return mp_handle_journey_narrative(inp.journey, inp.phase1_roll_count or 0)


@app.post("/astro/mokshapatam/chart_data")
def mp_chart_data_ep(inp: MpChartDataInput, _: str = Depends(verify_key)):
    """3-panel visualization data: chakra_time, virtue_vs_vice, journey_arc."""
    return mp_handle_chart_data(inp.journey)


@app.post("/astro/mokshapatam/validate_journey")
def mp_validate_journey_ep(inp: MpValidateInput, _: str = Depends(verify_key)):
    """Verify journey structural consistency (houses valid, ages monotonic, snake/ladder match catalog)."""
    journey_input = {
        "phase1_roll_count": inp.phase1_roll_count,
        "end_condition":     inp.end_condition,
        "final_house":       inp.final_house,
        "final_age":         inp.final_age,
        "total_rolls":       inp.total_rolls,
        "journey":           inp.journey,
    }
    return mp_handle_validate_journey(journey_input)

# ── END MOKSHAPATAM E2 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_mokshapatam_e2_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_mokshapatam_e2_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ Moksha Patam E2 module patched into main.py")
    print("   9 new endpoints under /astro/mokshapatam/* — engine reaches 282 endpoints")


if __name__ == "__main__":
    main()
