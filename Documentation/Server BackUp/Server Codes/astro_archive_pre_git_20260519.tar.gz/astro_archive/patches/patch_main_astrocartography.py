"""
patch_main_astrocartography.py — Wires 6 Astrocartography (D6) endpoints into main.py.

Uses verify_key auth. Idempotent.

Run from /opt/astro:
    sudo python3 patch_main_astrocartography.py
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── ASTROCARTOGRAPHY D6 MODULE ──"


IMPORT_BLOCK = '''
# ── ASTROCARTOGRAPHY D6 MODULE IMPORTS ──
from astrocartography import (
    handle_profile             as acg_handle_profile,
    handle_planetary_lines     as acg_handle_planetary_lines,
    handle_relocate_chart      as acg_handle_relocate_chart,
    handle_local_space         as acg_handle_local_space,
    handle_location_compare    as acg_handle_location_compare,
    handle_optimal_locations   as acg_handle_optimal_locations,
)
# ── END ASTROCARTOGRAPHY D6 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── ASTROCARTOGRAPHY D6 MODULE ──
# Phase D — Module D6 — Astrocartography / Relocation (6 endpoints)
# Source: Jim Lewis "Astro*Carto*Graphy" (1976) + classical relocation (Vettius Valens)
# Uses Swiss Ephemeris 2.10 directly for RA/Dec/GMST/ARMC.
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _AcgBaseModel
from typing import Optional as _AcgOptional, List as _AcgList


class AcgRelocateInput(_AcgBaseModel):
    birth: BirthInput
    new_lat: float
    new_lon: float
    new_timezone: _AcgOptional[str] = None
    location_name: _AcgOptional[str] = None


class AcgLocationItem(_AcgBaseModel):
    name: _AcgOptional[str] = None
    lat: float
    lon: float
    timezone: _AcgOptional[str] = None


class AcgLocationCompareInput(_AcgBaseModel):
    birth: BirthInput
    locations: _AcgList[AcgLocationItem]


class AcgOptimalInput(_AcgBaseModel):
    birth: BirthInput
    theme: str  # career_success, wealth_finance, love_relationships, spiritual_growth, etc.
    top_n: _AcgOptional[int] = 10
    region: _AcgOptional[str] = None


def _acg_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/astrocartography/profile")
def acg_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master astrocartography synthesis — all 36 lines + parans + headlines."""
    return acg_handle_profile(_acg_birth_dict(inp))


@app.post("/astro/astrocartography/planetary_lines")
def acg_planetary_lines_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """All 36 planetary lines: 4 lines × 9 planets (MC/IC meridians + AC/DC latitude-curves)."""
    return acg_handle_planetary_lines(_acg_birth_dict(inp))


@app.post("/astro/astrocartography/relocate_chart")
def acg_relocate_ep(inp: AcgRelocateInput, _: str = Depends(verify_key)):
    """Recast chart at new location. Returns relocated lagna + planet-house shifts vs birth chart."""
    return acg_handle_relocate_chart(
        _acg_birth_dict(inp.birth),
        inp.new_lat, inp.new_lon,
        inp.new_timezone, inp.location_name,
    )


@app.post("/astro/astrocartography/local_space")
def acg_local_space_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Directional azimuths from birthplace to major destinations (~70 cities)."""
    return acg_handle_local_space(_acg_birth_dict(inp))


@app.post("/astro/astrocartography/location_compare")
def acg_location_compare_ep(inp: AcgLocationCompareInput, _: str = Depends(verify_key)):
    """Compare angular-planet placements across multiple locations."""
    locs = [{"name": l.name, "lat": l.lat, "lon": l.lon, "timezone": l.timezone}
            for l in inp.locations]
    return acg_handle_location_compare(_acg_birth_dict(inp.birth), locs)


@app.post("/astro/astrocartography/optimal_locations")
def acg_optimal_ep(inp: AcgOptimalInput, _: str = Depends(verify_key)):
    """Recommend top cities for a given life-theme (career_success / love_relationships / spiritual_growth / etc.)."""
    return acg_handle_optimal_locations(
        _acg_birth_dict(inp.birth),
        inp.theme, inp.top_n or 10, inp.region,
    )

# ── END ASTROCARTOGRAPHY D6 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present in main.py.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_acg_d6_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_acg_d6_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ Astrocartography D6 module patched into main.py")
    print("   6 endpoints under /astro/astrocartography/* — engine reaches 259 endpoints")


if __name__ == "__main__":
    main()
