"""
patch_main_kp.py — Wires 10 KP Pro (D4) endpoints into main.py.

Uses verify_key auth. Idempotent.

Run from /opt/astro:
    sudo python3 patch_main_kp.py
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── KP PRO D4 MODULE ──"


IMPORT_BLOCK = '''
# ── KP PRO D4 MODULE IMPORTS ──
from kp_pro import (
    handle_profile                as kp_handle_profile,
    handle_sub_lord_for_longitude as kp_handle_sub_lord_for_longitude,
    handle_planet_sub_lords       as kp_handle_planet_sub_lords,
    handle_lagna_sub_lord         as kp_handle_lagna_sub_lord,
    handle_cuspal_sub_lords       as kp_handle_cuspal_sub_lords,
    handle_ruling_planets         as kp_handle_ruling_planets,
    handle_significators          as kp_handle_significators,
    handle_house_significators    as kp_handle_house_significators,
    handle_moment_lookup          as kp_handle_moment_lookup,
    handle_query_horoscope        as kp_handle_query_horoscope,
)
# ── END KP PRO D4 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── KP PRO D4 MODULE ──
# Phase D — Module D4 — Krishnamurti Paddhati (10 endpoints)
# Source: K.S. Krishnamurti "Krishnamurti Paddhati" (1971); Vimshottari from BPHS
# KP-lite: Lahiri ayanamsha + equal-house cusps (engine note)
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _KpBaseModel
from typing import Optional as _KpOptional, List as _KpList


class KpLongitudeInput(_KpBaseModel):
    longitude: float  # 0-360 zodiac longitude


class KpRulingPlanetsInput(_KpBaseModel):
    """At least one of birth OR query_moment+query_lat+query_lon required."""
    birth: _KpOptional[BirthInput] = None
    query_moment: _KpOptional[str] = None
    query_lat: _KpOptional[float] = None
    query_lon: _KpOptional[float] = None
    query_timezone: _KpOptional[str] = "Asia/Kolkata"


class KpHouseSignificatorInput(_KpBaseModel):
    birth: BirthInput
    house: int  # 1-12


class KpMomentInput(_KpBaseModel):
    query_moment: str  # ISO datetime
    query_lat: float
    query_lon: float
    query_timezone: _KpOptional[str] = "Asia/Kolkata"


class KpQueryHoroscopeInput(_KpBaseModel):
    birth: BirthInput
    query_moment: str
    query_lat: float
    query_lon: float
    question_house: int  # 1-12
    query_timezone: _KpOptional[str] = "Asia/Kolkata"


def _kp_birth_dict(b: BirthInput) -> dict:
    return {
        "dob":      b.dob,
        "time":     b.time,
        "lat":      b.lat,
        "lon":      b.lon,
        "timezone": b.timezone,
    }


@app.post("/astro/kp/profile")
def kp_profile_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Master KP-lite synthesis — Lagna sub-lord + planet sub-lords + cusps + RPs + significators."""
    return kp_handle_profile(_kp_birth_dict(inp))


@app.post("/astro/kp/sub_lord_for_longitude")
def kp_sub_lord_lon_ep(inp: KpLongitudeInput, _: str = Depends(verify_key)):
    """Compute star/sub/sub-sub lord for ANY zodiac longitude (0-360)."""
    return kp_handle_sub_lord_for_longitude(inp.longitude)


@app.post("/astro/kp/planet_sub_lords")
def kp_planet_sub_lords_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Sub-lords for all 9 planets in the chart."""
    return kp_handle_planet_sub_lords(_kp_birth_dict(inp))


@app.post("/astro/kp/lagna_sub_lord")
def kp_lagna_sl_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Lagna sub-lord — the single most important KP indicator."""
    return kp_handle_lagna_sub_lord(_kp_birth_dict(inp))


@app.post("/astro/kp/cuspal_sub_lords")
def kp_cuspal_sl_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Sub-lords for all 12 house cusps (equal-house from Lagna)."""
    return kp_handle_cuspal_sub_lords(_kp_birth_dict(inp))


@app.post("/astro/kp/ruling_planets")
def kp_ruling_planets_ep(inp: KpRulingPlanetsInput, _: str = Depends(verify_key)):
    """5 KP Ruling Planets at birth, at query moment, or both."""
    birth_dict = _kp_birth_dict(inp.birth) if inp.birth else None
    return kp_handle_ruling_planets(
        birth=birth_dict,
        query_moment=inp.query_moment,
        query_lat=inp.query_lat,
        query_lon=inp.query_lon,
        query_timezone=inp.query_timezone or "Asia/Kolkata",
    )


@app.post("/astro/kp/significators")
def kp_significators_ep(inp: BirthInput, _: str = Depends(verify_key)):
    """Each planet's signified houses per KP hierarchy."""
    return kp_handle_significators(_kp_birth_dict(inp))


@app.post("/astro/kp/house_significators")
def kp_house_sig_ep(inp: KpHouseSignificatorInput, _: str = Depends(verify_key)):
    """Which planets signify a given house (1-12) at all 4 KP levels."""
    return kp_handle_house_significators(_kp_birth_dict(inp.birth), inp.house)


@app.post("/astro/kp/moment_lookup")
def kp_moment_ep(inp: KpMomentInput, _: str = Depends(verify_key)):
    """KP analysis for arbitrary moment — RPs + Lagna sub-lord at that moment."""
    return kp_handle_moment_lookup(
        inp.query_moment, inp.query_lat, inp.query_lon,
        inp.query_timezone or "Asia/Kolkata",
    )


@app.post("/astro/kp/query_horoscope")
def kp_query_horoscope_ep(inp: KpQueryHoroscopeInput, _: str = Depends(verify_key)):
    """KP yes/no for a question — compare birth significators of question_house with current RPs."""
    return kp_handle_query_horoscope(
        _kp_birth_dict(inp.birth),
        inp.query_moment, inp.query_lat, inp.query_lon,
        inp.question_house,
        inp.query_timezone or "Asia/Kolkata",
    )

# ── END KP PRO D4 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present in main.py.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_kp_d4_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_kp_d4_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ KP Pro D4 module patched into main.py")
    print("   10 endpoints under /astro/kp/* — engine reaches 253 endpoints")


if __name__ == "__main__":
    main()
