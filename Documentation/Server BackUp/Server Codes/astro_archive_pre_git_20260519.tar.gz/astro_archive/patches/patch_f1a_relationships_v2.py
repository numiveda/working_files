#!/usr/bin/env python3
"""
patch_f1a_relationships_v2.py
─────────────────────────────────────────────────────────────────────────
F1a — Mount the new relationships module (friendship / mentor / family).

v2 CHANGES (vs v1):
    - Smoke test now runs as user `trading` (matching astro service),
      not as root (which is what `sudo python3 patch.py` accidentally
      gave us). Root can't see ~/.local/lib/python3.12/site-packages
      where dashaflow + swisseph are installed.
    - Layered smoke test: swisseph → dashaflow → astro_helpers →
      compatibility → relationships. Failure attribution is precise.
    - --skip-smoke flag added as escape hatch if v2's check still
      misfires for any environment subtlety we haven't anticipated.

PREREQUISITES:
    - /opt/astro/relationships.py must already be on disk (already there
      from v1's scp step)
    - U9 must have been applied (verified via marker presence)
    - Service must be running as user `trading` (per systemd unit)

PATCH STEPS:
    1. Preconditions (file present, U9 marker)
    2. Layered smoke test as trading user (swisseph → ... → relationships)
    3. Backup main.py
    4. Inject RelationshipInput Pydantic model
    5. Inject `from relationships import (...)` block
    6. Append 3 endpoint registrations
    7. Snapshot after
    8. Syntax check; rollback if fails

Usage:
    sudo python3 /opt/astro/patch_f1a_relationships_v2.py
    sudo python3 /opt/astro/patch_f1a_relationships_v2.py --skip-smoke

Author: Claude (F1a v2, 2026-05-17)
"""

import os
import sys
import shutil
import subprocess
import argparse
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
RELATIONSHIPS_PY = "/opt/astro/relationships.py"

MARKER_IMPORT = "# ── F1a: Non-Marriage Relationships (2026-05-17) ──"
MARKER_ENDPOINTS = "# ── F1a: /astro/relationship/* (2026-05-17) ──"
MARKER_INPUT_CLASS = "# ── F1a: RelationshipInput (2026-05-17) ──"

COMPAT_IMPORT_TAIL = """    handle_timing_for_marriage      as compat_handle_timing_for_marriage,"""
COMPAT_INPUT_ANCHOR = """class CompatibilityInput(BaseModel):"""

# ─────────────────────────────────────────────────────────────────────
# Blocks to inject (identical to v1 — only the harness changed)
# ─────────────────────────────────────────────────────────────────────

F1A_IMPORT_BLOCK = """

{MARKER_IMPORT}
from relationships import (
    handle_friendship  as rel_handle_friendship,
    handle_mentor      as rel_handle_mentor,
    handle_family      as rel_handle_family,
)
""".replace("{MARKER_IMPORT}", MARKER_IMPORT)


F1A_INPUT_CLASS_BLOCK = """

{MARKER_INPUT_CLASS}
class RelationshipInput(BaseModel):
    person1: BirthInput
    person2: BirthInput
    # Optional context — improves synthesis but never required.
    # For mentor: role1/role2 ∈ {"mentor", "mentee"}
    # For family: any free-text label (e.g. "mother", "elder_sibling")
    role1: Optional[str] = None
    role2: Optional[str] = None
    # For family endpoint only: "parent-child" | "sibling" | "extended"
    subtype: Optional[str] = None
""".replace("{MARKER_INPUT_CLASS}", MARKER_INPUT_CLASS)


F1A_ENDPOINTS_BLOCK = '''

{MARKER_ENDPOINTS}

@app.post("/astro/relationship/friendship", dependencies=[Depends(verify_key)])
def relationship_friendship(r: RelationshipInput):
    """
    Friendship compatibility — emotional + intellectual rapport.
    Frame: 3rd house (peers), 11th house (gains/friends); karakas Mercury, Moon, Venus.
    Returns multi-stream evidence (koot + moon-synastry + house-overlay + Mercury-Moon cross)
    with composite score 0-100 and classical citations.
    """
    try:
        p1 = {"dob": r.person1.dob, "time": r.person1.time,
              "lat": r.person1.lat, "lon": r.person1.lon,
              "timezone": r.person1.timezone}
        p2 = {"dob": r.person2.dob, "time": r.person2.time,
              "lat": r.person2.lat, "lon": r.person2.lon,
              "timezone": r.person2.timezone}
        result = rel_handle_friendship(p1, p2, role1=r.role1, role2=r.role2)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/relationship/mentor", dependencies=[Depends(verify_key)])
def relationship_mentor(r: RelationshipInput):
    """
    Mentor / Guru-Shishya compatibility.
    Frame: 5H (disciple from guru) / 9H (guru from disciple); karaka Jupiter, AK resonance.
    Roles (optional): role1/role2 in {"mentor","mentee"}; if absent, returns both directional readings.
    Multi-stream evidence with composite score 0-100 and classical citations.
    """
    try:
        p1 = {"dob": r.person1.dob, "time": r.person1.time,
              "lat": r.person1.lat, "lon": r.person1.lon,
              "timezone": r.person1.timezone}
        p2 = {"dob": r.person2.dob, "time": r.person2.time,
              "lat": r.person2.lat, "lon": r.person2.lon,
              "timezone": r.person2.timezone}
        result = rel_handle_mentor(p1, p2, role1=r.role1, role2=r.role2)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/astro/relationship/family", dependencies=[Depends(verify_key)])
def relationship_family(r: RelationshipInput):
    """
    Family compatibility — parent-child, sibling, or extended.
    Subtype (optional, defaults to "extended"):
        "parent-child" → 4/9/10/5 houses; Matri/Pitri/Putra karakas
        "sibling"      → 3/11 houses;     Bhratrikaraka
        "extended"     → all family houses + all 4 family karakas
    Multi-stream evidence + composite score 0-100 + classical citations.
    """
    try:
        p1 = {"dob": r.person1.dob, "time": r.person1.time,
              "lat": r.person1.lat, "lon": r.person1.lon,
              "timezone": r.person1.timezone}
        p2 = {"dob": r.person2.dob, "time": r.person2.time,
              "lat": r.person2.lat, "lon": r.person2.lon,
              "timezone": r.person2.timezone}
        result = rel_handle_family(p1, p2,
                                    role1=r.role1, role2=r.role2,
                                    subtype=r.subtype)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
'''.replace("{MARKER_ENDPOINTS}", MARKER_ENDPOINTS)


def fail(msg):
    print(f"\n❌ ERROR: {msg}")
    sys.exit(1)


def smoke_test_as_trading():
    """
    Layered smoke test of dependency chain, run as user `trading` to match
    the systemd User= directive of the astro service.

    Layers (foundation → leaf):
        1. swisseph         — Swiss Ephemeris (Principle 1: source of truth)
        2. dashaflow        — chart casting wrapper around swisseph
        3. astro_helpers    — shared utilities
        4. compatibility    — koot scorers F1a imports from
        5. relationships    — the new F1a module

    If any layer fails, name the precise layer.
    """
    print("\n── Smoke test (layered, as user `trading`) ──")

    smoke_script = """
import sys
sys.path.insert(0, '/opt/astro')
layers = [
    ('swisseph',      'swisseph'),
    ('dashaflow',     'dashaflow'),
    ('astro_helpers', 'astro_helpers'),
    ('compatibility', 'compatibility'),
    ('relationships', 'relationships'),
]
for label, modname in layers:
    try:
        m = __import__(modname)
        loc = getattr(m, '__file__', '(builtin/extension)')
        print(f'OK    {label:15s} {loc}')
    except Exception as e:
        print(f'FAIL  {label:15s} {type(e).__name__}: {e}')
        sys.exit(1)
# Now confirm the actual functions we need
from relationships import handle_friendship, handle_mentor, handle_family
print(f'OK    handlers        handle_friendship / handle_mentor / handle_family')
"""

    # Determine if we need to drop privileges. If we're already running as
    # trading, just invoke python3 directly. If running as root (typical
    # `sudo python3 patch.py`), use `sudo -u trading`.
    is_root = (os.geteuid() == 0)

    if is_root:
        cmd = ["sudo", "-u", "trading", "python3", "-c", smoke_script]
        print(f"   (running as root; dropping to user `trading` via sudo -u)")
    else:
        cmd = ["python3", "-c", smoke_script]
        print(f"   (already running as {os.environ.get('USER', '?')}; using python3 directly)")

    result = subprocess.run(cmd, capture_output=True, text=True, cwd="/opt/astro")

    # Echo both stdout and stderr for visibility
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            print(f"   {line}")
    if result.stderr.strip():
        print(f"   ── stderr ──")
        for line in result.stderr.strip().split("\n"):
            print(f"   {line}")

    if result.returncode != 0:
        fail("Smoke test failed at the layer marked FAIL above. "
             "If you believe this is a harness false-positive (e.g. the "
             "service runs fine but the smoke test environment differs), "
             "re-run with --skip-smoke.")

    print("✅ All dependency layers import cleanly")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-smoke", action="store_true",
                        help="Skip the layered smoke test (escape hatch)")
    args = parser.parse_args()

    print("=" * 70)
    print("F1a v2 — Relationships module installer")
    print("=" * 70)

    # ── Step 1: Preconditions ──
    if not os.path.exists(MAIN_PY):
        fail(f"{MAIN_PY} not found")
    if not os.path.exists(RELATIONSHIPS_PY):
        fail(f"{RELATIONSHIPS_PY} not found — scp it to /opt/astro/ first")
    print(f"✅ Found {RELATIONSHIPS_PY}")

    # ── Step 2: Smoke test ──
    if args.skip_smoke:
        print("\n⚠️  Smoke test SKIPPED (--skip-smoke flag). "
              "Relying on syntax check + systemctl restart as safety net.")
    else:
        smoke_test_as_trading()

    # ── Step 3: Read main.py ──
    with open(MAIN_PY, "r") as f:
        content = f.read()

    orig_size = len(content)
    orig_lines = content.count("\n") + 1
    print(f"\nmain.py: {orig_size} bytes, {orig_lines} lines")

    # ── Step 4: Idempotency check ──
    if MARKER_IMPORT in content or MARKER_ENDPOINTS in content or MARKER_INPUT_CLASS in content:
        print(f"\n✅ F1a marker present — patch was already applied. No changes.")
        return

    # ── Step 5: Confirm U9 was applied ──
    if "U9: /astro/compatibility modernized" not in content:
        fail("U9 marker not found in main.py. F1a requires U9 first.")
    print("✅ U9 marker confirmed in main.py")

    # ── Step 6: Splice anchors ──
    if COMPAT_IMPORT_TAIL not in content:
        fail("Anchor 1 (compatibility import tail) not found in main.py.")
    print("✅ Anchor 1 found (compatibility import tail)")

    if COMPAT_INPUT_ANCHOR not in content:
        fail("Anchor 2 (CompatibilityInput class) not found in main.py.")
    print("✅ Anchor 2 found (CompatibilityInput)")

    # ── Step 7: Backup ──
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = f"{MAIN_PY}.before_f1a_relationships_{ts}"
    shutil.copy2(MAIN_PY, backup)
    print(f"✅ Backup: {backup}")

    # ── Step 8: Inject import block after compatibility import block close ──
    idx = content.find(COMPAT_IMPORT_TAIL)
    close_idx = content.find(")", idx)
    if close_idx == -1:
        fail("Could not locate closing paren of compatibility import block")
    insert_at = close_idx + 1
    new_content = content[:insert_at] + F1A_IMPORT_BLOCK + content[insert_at:]
    print("✅ Injected import block after compatibility import")

    # ── Step 9: Inject RelationshipInput before CompatibilityInput ──
    anchor_idx = new_content.find(COMPAT_INPUT_ANCHOR)
    if anchor_idx == -1:
        fail("Lost anchor after first injection — should not happen")
    new_content = (new_content[:anchor_idx]
                   + F1A_INPUT_CLASS_BLOCK
                   + "\n\n"
                   + new_content[anchor_idx:])
    print("✅ Injected RelationshipInput class before CompatibilityInput")

    # ── Step 10: Append endpoints at end ──
    if not new_content.endswith("\n"):
        new_content += "\n"
    new_content += F1A_ENDPOINTS_BLOCK
    print("✅ Appended 3 endpoint registrations at end of file")

    # ── Step 11: Write ──
    with open(MAIN_PY, "w") as f:
        f.write(new_content)
    new_size = len(new_content)
    new_lines = new_content.count("\n") + 1
    print(f"\n✅ Wrote new main.py: {new_size} bytes ({new_size - orig_size:+d}), "
          f"{new_lines} lines ({new_lines - orig_lines:+d})")

    # ── Step 12: Snapshot ──
    snap = f"{MAIN_PY}.after_f1a_relationships_{ts}"
    shutil.copy2(MAIN_PY, snap)
    print(f"✅ Snapshot: {snap}")

    # ── Step 13: Syntax check ──
    print("\n── Syntax check ──")
    import py_compile
    try:
        py_compile.compile(MAIN_PY, doraise=True)
        print("✅ main.py syntax OK")
    except py_compile.PyCompileError as e:
        print(f"❌ SYNTAX ERROR — rolling back from {backup}")
        shutil.copy2(backup, MAIN_PY)
        print(f"   Restored. Error was: {e}")
        sys.exit(1)

    print("\n" + "=" * 70)
    print("F1a v2 PATCH APPLIED — next steps:")
    print("  sudo systemctl restart astro && sleep 3")
    print("  systemctl status astro | grep -E 'Memory|Active'")
    print("  Then run smoke + cross-validation tests")
    print("  (see F1A_PATCH_INSTRUCTIONS.md from previous delivery)")
    print("=" * 70)


if __name__ == "__main__":
    main()
