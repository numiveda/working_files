"""
patch_main_vastu.py — Adds 10 Astro Vastu endpoints to /opt/astro/main.py

Uses the same proven safe-insertion pattern from patch_main_fengshui_v2:
- Imports inserted right before `app = FastAPI(`
- Endpoints appended at end of file

Safe, idempotent: skips if endpoints already present.
Marker: # ── ASTRO VASTU MODULE ──

Run from /opt/astro/ with sudo:
    sudo python3 patch_main_vastu.py
"""

import re
import sys
from pathlib import Path

MAIN_PY = Path("/opt/astro/main.py")
MARKER_START = "# ── ASTRO VASTU MODULE ──"


IMPORT_BLOCK = """
# ── Astro Vastu module imports ──
from vastu import (
    full_vastu_profile,
    personal_directions_endpoint as vastu_personal_directions,
    plot_analysis as vastu_plot_analysis,
    room_placement_endpoint as vastu_room_placement,
    doshas_endpoint as vastu_doshas,
    remedies_endpoint as vastu_remedies,
    marma_points_endpoint as vastu_marma,
    auspicious_construction_endpoint as vastu_construction_muhurta,
    business_vastu_endpoint as vastu_business,
    yantra_directions as vastu_yantra_directions,
)

"""


ENDPOINT_BLOCK = '''
# ══════════════════════════════════════════════════════════════════════
# ── ASTRO VASTU MODULE ──
# 10 endpoints — Classical Vastu Shastra personalized to Vedic chart
# Sources: Manasara, Mayamatam, Brihat Samhita, Vishvakarma Prakash
# ══════════════════════════════════════════════════════════════════════

class VastuPlotInput(BaseModel):
    shape: str            # "square", "rectangle_NS", "ne_extended", "triangular", etc.
    slope: str            # "north", "northeast", "south", etc.
    road_facing: str      # main road direction
    water_body: Optional[str] = None   # placement of well/pond/borewell


class VastuDoshaInput(BaseModel):
    observations: list    # ["toilet_in_NE", "kitchen_in_SE", "staircase_at_center"]


class VastuBusinessInput(BaseModel):
    business_type: str    # "shop_retail", "office_corporate", "warehouse_factory", "restaurant_hospitality"


class VastuRemedyQuery(BaseModel):
    for_dosha: Optional[str] = None   # specific dosha key, or None for full catalog


@app.post("/astro/vastu/profile")
def vastu_profile(inp: BirthInput, _: str = Depends(verify_key)):
    """Master endpoint — full personal Vastu analysis tied to native's Vedic chart."""
    return full_vastu_profile(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/vastu/personal_directions")
def vastu_personal_dirs(inp: BirthInput, _: str = Depends(verify_key)):
    """8 directions personalized to native's chart — Lagna/Moon/AK/Dasha overlay."""
    return vastu_personal_directions(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/vastu/plot_analysis")
def vastu_plot(inp: VastuPlotInput, _: str = Depends(verify_key)):
    """Plot evaluation — shape, slope, road facing, water body — with composite score."""
    return vastu_plot_analysis(
        shape=inp.shape, slope=inp.slope,
        road_facing=inp.road_facing, water_body=inp.water_body,
    )


@app.post("/astro/vastu/room_placement")
def vastu_rooms(inp: BirthInput, _: str = Depends(verify_key)):
    """Full room placement matrix — 16 rooms × 8 directions with classical citations."""
    return vastu_room_placement(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/vastu/doshas")
def vastu_doshas_endpoint(inp: VastuDoshaInput, _: str = Depends(verify_key)):
    """Detect Vastu doshas from observations of the home."""
    return vastu_doshas(observations=inp.observations)


@app.post("/astro/vastu/remedies")
def vastu_remedies_endpoint(inp: VastuRemedyQuery, _: str = Depends(verify_key)):
    """Full Vastu remedies catalog — optionally filtered for a specific dosha."""
    return vastu_remedies(for_dosha=inp.for_dosha)


@app.get("/astro/vastu/marma_points")
def vastu_marma_endpoint(_: str = Depends(verify_key)):
    """Vastu Purusha Mandala (81-pada grid) + critical marma points."""
    return vastu_marma()


@app.post("/astro/vastu/auspicious_construction")
def vastu_construction(inp: BirthInput, _: str = Depends(verify_key)):
    """Construction muhurta — months, nakshatras, tithis, weekdays — chart-aware."""
    return vastu_construction_muhurta(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )


@app.post("/astro/vastu/business_vastu")
def vastu_business_endpoint(inp: VastuBusinessInput, _: str = Depends(verify_key)):
    """Business Vastu — commercial space configuration by type."""
    return vastu_business(business_type=inp.business_type)


@app.post("/astro/vastu/yantra_directions")
def vastu_yantra(inp: BirthInput, _: str = Depends(verify_key)):
    """Personal yantra placement directions based on afflicted planets in chart."""
    return vastu_yantra_directions(
        dob=inp.dob, time=inp.time, lat=inp.lat, lon=inp.lon,
        timezone=inp.timezone or "Asia/Kolkata",
    )

# ── END ASTRO VASTU MODULE ──
'''


def main():
    if not MAIN_PY.exists():
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    content = MAIN_PY.read_text()

    if MARKER_START in content:
        print(f"⏭️  Vastu module already patched. Skipping.")
        return

    if "from fastapi import" not in content:
        print("ERROR: main.py doesn't look like a FastAPI app")
        sys.exit(1)

    if "verify_key" not in content:
        print("ERROR: main.py doesn't define verify_key dependency")
        sys.exit(1)

    if "BirthInput" not in content:
        print("ERROR: BirthInput model not defined in main.py")
        sys.exit(1)

    # Safe insertion: right before "app = FastAPI("
    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)

    if not match:
        print("ERROR: Could not find 'app = FastAPI(' in main.py")
        sys.exit(1)

    insertion_point = match.start()

    if insertion_point > 0 and content[insertion_point - 1] != '\n':
        print(f"ERROR: 'app = FastAPI(' not at start of line")
        sys.exit(1)

    new_content = (
        content[:insertion_point]
        + IMPORT_BLOCK
        + content[insertion_point:]
    )

    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    MAIN_PY.write_text(new_content)
    print(f"✅ Patched {MAIN_PY}")
    print(f"   Added: 10 Astro Vastu endpoints")
    print(f"   Marker: {MARKER_START}")
    print(f"   File size: {len(new_content)} bytes (was {len(content)})")

    print("\n🔍 Verifying syntax...")
    import py_compile
    try:
        py_compile.compile(str(MAIN_PY), doraise=True)
        print("✅ Syntax OK — ready to restart astro service")
    except py_compile.PyCompileError as e:
        print(f"❌ SYNTAX ERROR in patched main.py:")
        print(f"   {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
