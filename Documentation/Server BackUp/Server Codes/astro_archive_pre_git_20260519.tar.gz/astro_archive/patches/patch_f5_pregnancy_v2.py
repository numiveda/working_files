#!/usr/bin/env python3
"""
patch_f5_pregnancy_v2.py — F5 Pregnancy Astrology installer (v2)

v1 → v2 fix: Phase F.2 smoke test failed with SyntaxError because the smoke
             string contained a `for` loop:
                 "for r in [r1,r2,...]:     assert 'disclaimer' in r; ..."
             passed through `python3 -c "..."`. The `-c` one-liner mode cannot
             parse a compound `for` loop with `;`-separated body statements
             reliably. Local pre-flight didn't catch this because it ran
             pregnancy.py as a real Python file (multi-line), not via `-c`.
             v1 failed cleanly at Phase F.2 — auto-rollback triggered, main.py
             restored from backup, no production damage.
             v2 unrolls the for loop into 12 explicit assertion statements,
             all `;`-separated and structurally simple. Brute-force safe.

Installs /astro/pregnancy/conception_muhurta, /astro/pregnancy/santana_yogas,
/astro/pregnancy/prenatal_remedies, /astro/pregnancy/bala_arishta,
/astro/pregnancy/newborn_naming_window, /astro/pregnancy/garbha_shanti_remedies
into main.py. Module file pregnancy.py must already be present at
/opt/astro/pregnancy.py.

Built using the verified v4 pattern from F4:
- run_as_trading_user (subprocess via `sudo -u trading bash -c`) — required
  because dashaflow is in trading's user-pip site-packages, not on root's path
- chown_to_trading after every file write — root writes would otherwise
  leave main.py as root:root, breaking the service on next restart
- byte-verified anchors with cat -A done BEFORE writing (HANDOVER_v6 Section 3.12)
- auto-rollback on Phase F.1 (syntax) or Phase F.2 (smoke) failure

Phase A — Precondition + anchor validation (file UNTOUCHED if fail)
Phase B — Backup main.py
Phase C — Insert F5 import block (after F4 imports, before END COMPATIBILITY C1)
Phase D — Insert F5 Pydantic input models (after F4 inputs, before CompatibilityInput)
Phase E — Append F5 routes to end of main.py
Phase F — Snapshot + chown + syntax check + layered smoke (auto-rollback if fail)

Idempotency: marker comment "# ── F5: Pregnancy module imports (2026-05-18) ──"
is checked first; if present, exit cleanly without changes.

PCPNDT compliance reminder: this module's endpoints intentionally do NOT
include foetal sex determination. The Garbha Linga Nirnaya classical topic
is documented as deliberately omitted in pregnancy.py's docstring.

Author: Claude (F5, 2026-05-18)
"""

import os
import sys
import shutil
import shlex
import subprocess
import time

# ─── Configuration ──────────────────────────────────────────────────────────
ASTRO_DIR     = "/opt/astro"
MAIN_PY       = os.path.join(ASTRO_DIR, "main.py")
PREGNANCY_PY  = os.path.join(ASTRO_DIR, "pregnancy.py")
PATCH_NAME    = "f5_pregnancy"
TIMESTAMP     = time.strftime("%Y%m%d_%H%M%S")
BACKUP_PATH   = f"{MAIN_PY}.before_{PATCH_NAME}_{TIMESTAMP}"
SNAPSHOT_PATH = f"{MAIN_PY}.after_{PATCH_NAME}_{TIMESTAMP}"
MARKER        = "# ── F5: Pregnancy module imports (2026-05-18) ──"

# ─── Anchors (byte-verified from production main.py on 2026-05-18 post-F4) ──

# Anchor A1: F5 imports go between F4 imports' closing ')' and the
# END COMPATIBILITY C1 marker. Byte-verified:
#   Line 302: ")"
#   Line 303: "" (blank — exactly 1)
#   Line 304: "# ── END COMPATIBILITY C1 IMPORTS ──"
ANCHOR_F4_IMPORT_BLOCK_CLOSE = (
    "from mundane import (\n"
    "    handle_country_outlook       as mn_handle_country_outlook,\n"
    "    handle_company_chart         as mn_handle_company_chart,\n"
    "    handle_election_prediction   as mn_handle_election_prediction,\n"
    "    COUNTRY_REGISTRY             as MN_COUNTRY_REGISTRY,\n"
    ")\n"
    "\n"
    "# ── END COMPATIBILITY C1 IMPORTS ──"
)

NEW_F4_PLUS_F5_IMPORTS = (
    "from mundane import (\n"
    "    handle_country_outlook       as mn_handle_country_outlook,\n"
    "    handle_company_chart         as mn_handle_company_chart,\n"
    "    handle_election_prediction   as mn_handle_election_prediction,\n"
    "    COUNTRY_REGISTRY             as MN_COUNTRY_REGISTRY,\n"
    ")\n"
    "\n"
    "\n"
    "# ── F5: Pregnancy module imports (2026-05-18) ──\n"
    "from pregnancy import (\n"
    "    handle_conception_muhurta        as pg_handle_conception_muhurta,\n"
    "    handle_santana_yogas             as pg_handle_santana_yogas,\n"
    "    handle_prenatal_remedies         as pg_handle_prenatal_remedies,\n"
    "    handle_bala_arishta              as pg_handle_bala_arishta,\n"
    "    handle_newborn_naming_window     as pg_handle_newborn_naming_window,\n"
    "    handle_garbha_shanti_remedies    as pg_handle_garbha_shanti_remedies,\n"
    "    PCPNDT_NOTE                      as PG_PCPNDT_NOTE,\n"
    ")\n"
    "\n"
    "# ── END COMPATIBILITY C1 IMPORTS ──"
)

# Anchor A2: F5 input models go between ElectionEventInput's last attribute and
# CompatibilityInput. Byte-verified:
#   Line 670: "    country_code:  Optional[str] = None"
#   Lines 671, 672, 673: blank (exactly 3)
#   Line 674: "class CompatibilityInput(BaseModel):"
ANCHOR_F4_INPUT_TO_COMPATIBILITY = (
    "class ElectionEventInput(BaseModel):\n"
    "    \"\"\"Input for /astro/mundane/election_prediction.\n"
    "\n"
    "    event: BirthInput-shaped chart of the civic event moment (e.g. poll opening).\n"
    "    country_code: optional ISO 3166-1 alpha-2 for national context overlay.\n"
    "\n"
    "    NOTE: This endpoint does NOT predict winners. Inputs containing party\n"
    "    or candidate names are ignored.\n"
    "    \"\"\"\n"
    "    event:         BirthInput\n"
    "    country_code:  Optional[str] = None\n"
    "\n"   # blank 671
    "\n"   # blank 672
    "\n"   # blank 673
    "class CompatibilityInput(BaseModel):"
)

NEW_F4_INPUT_PLUS_F5_PLUS_COMPAT = (
    "class ElectionEventInput(BaseModel):\n"
    "    \"\"\"Input for /astro/mundane/election_prediction.\n"
    "\n"
    "    event: BirthInput-shaped chart of the civic event moment (e.g. poll opening).\n"
    "    country_code: optional ISO 3166-1 alpha-2 for national context overlay.\n"
    "\n"
    "    NOTE: This endpoint does NOT predict winners. Inputs containing party\n"
    "    or candidate names are ignored.\n"
    "    \"\"\"\n"
    "    event:         BirthInput\n"
    "    country_code:  Optional[str] = None\n"
    "\n"
    "\n"
    "# ── F5: Pregnancy Astrology inputs (2026-05-18) ──\n"
    "#\n"
    "# PCPNDT compliance note: NONE of these schemas accept any field related to\n"
    "# foetal gender determination. This is deliberate engineering policy per the\n"
    "# Pre-Conception and Pre-Natal Diagnostic Techniques Act, 1994 (India).\n"
    "# Forbidden field names (gender, sex, linga, etc.) will trigger 400/422.\n"
    "#\n"
    "class PregnancyLocationInput(BaseModel):\n"
    "    \"\"\"Geo + timezone for muhurta scoring.\"\"\"\n"
    "    lat:      float\n"
    "    lon:      float\n"
    "    timezone: str = \"Asia/Kolkata\"\n"
    "\n"
    "\n"
    "class ConceptionMuhurtaInput(BaseModel):\n"
    "    \"\"\"Input for /astro/pregnancy/conception_muhurta — Garbhadhana scan.\"\"\"\n"
    "    female_chart:  BirthInput\n"
    "    male_chart:    Optional[BirthInput] = None\n"
    "    location:      PregnancyLocationInput\n"
    "    start_date:    Optional[str] = None   # YYYY-MM-DD; defaults to today\n"
    "    end_date:      Optional[str] = None   # YYYY-MM-DD; defaults to start+14d\n"
    "    max_days:      Optional[int] = 30     # cap; default 30\n"
    "\n"
    "\n"
    "class SantanaYogasInput(BaseModel):\n"
    "    \"\"\"Input for /astro/pregnancy/santana_yogas — couple's combined analysis.\"\"\"\n"
    "    person1: BirthInput\n"
    "    person2: BirthInput\n"
    "\n"
    "\n"
    "class PrenatalRemediesInput(BaseModel):\n"
    "    \"\"\"Input for /astro/pregnancy/prenatal_remedies — month-by-month Garbha Sanskara.\"\"\"\n"
    "    mother_chart:       BirthInput\n"
    "    gestational_month:  int            # 1-9\n"
    "    father_chart:       Optional[BirthInput] = None\n"
    "\n"
    "\n"
    "class BalaArishtaInput(BaseModel):\n"
    "    \"\"\"Input for /astro/pregnancy/bala_arishta — classical Bala-Arishta yoga screen.\n"
    "\n"
    "    SENSITIVE: returns classical karmic patterns + shanti remedies, NOT a\n"
    "    medical or psychological diagnosis.\n"
    "    \"\"\"\n"
    "    child_chart: BirthInput\n"
    "\n"
    "\n"
    "class NewbornNamingInput(BaseModel):\n"
    "    \"\"\"Input for /astro/pregnancy/newborn_naming_window — Namakarana muhurta + aksharas.\"\"\"\n"
    "    child_chart:     BirthInput\n"
    "    naming_location: PregnancyLocationInput\n"
    "\n"
    "\n"
    "class GarbhaShantiInput(BaseModel):\n"
    "    \"\"\"Input for /astro/pregnancy/garbha_shanti_remedies — classical spiritual practices.\n"
    "\n"
    "    Classical practices ONLY. Always supplementary to medical care.\n"
    "    \"\"\"\n"
    "    mother_chart:       BirthInput\n"
    "    gestational_month:  Optional[int] = None   # 1-9\n"
    "    father_chart:       Optional[BirthInput] = None\n"
    "\n"
    "\n"
    "\n"
    "class CompatibilityInput(BaseModel):"
)

# Anchor A3: append at end-of-file. File ends with the `raise HTTPException`
# line followed by \n. F5 routes append starting with \n for clean separation.
F5_ROUTES_APPEND = (
    "\n"
    "\n"
    "# ── F5: /astro/pregnancy/* endpoints (2026-05-18) ──\n"
    "#\n"
    "# PCPNDT compliance note: None of these endpoints accept or emit foetal\n"
    "# gender data. The Garbha Linga Nirnaya classical topic is deliberately\n"
    "# omitted from the engine per PCPNDT Act, 1994 (India). Module docstring\n"
    "# in pregnancy.py documents this engineering policy.\n"
    "#\n"
    "\n"
    "@app.post(\"/astro/pregnancy/conception_muhurta\", dependencies=[Depends(verify_key)])\n"
    "def pregnancy_conception_muhurta(c: ConceptionMuhurtaInput):\n"
    "    \"\"\"\n"
    "    Garbhadhana muhurta — day-by-day scan for auspicious conception\n"
    "    attempt windows. Reuses cast_chart + panchang shape from dashaflow.\n"
    "    Goes beyond /astro/children/conception_timing (which gives multi-year\n"
    "    dasha windows) by adding day-level muhurta scoring.\n"
    "\n"
    "    Returns top auspicious days + days to avoid + full ranked scan with\n"
    "    transparent scoring (every point labeled).\n"
    "    \"\"\"\n"
    "    try:\n"
    "        female_dict = {\n"
    "            \"dob\":      c.female_chart.dob,\n"
    "            \"time\":     c.female_chart.time,\n"
    "            \"lat\":      c.female_chart.lat,\n"
    "            \"lon\":      c.female_chart.lon,\n"
    "            \"timezone\": c.female_chart.timezone,\n"
    "        }\n"
    "        male_dict = None\n"
    "        if c.male_chart is not None:\n"
    "            male_dict = {\n"
    "                \"dob\":      c.male_chart.dob,\n"
    "                \"time\":     c.male_chart.time,\n"
    "                \"lat\":      c.male_chart.lat,\n"
    "                \"lon\":      c.male_chart.lon,\n"
    "                \"timezone\": c.male_chart.timezone,\n"
    "            }\n"
    "        location_dict = {\n"
    "            \"lat\":      c.location.lat,\n"
    "            \"lon\":      c.location.lon,\n"
    "            \"timezone\": c.location.timezone,\n"
    "        }\n"
    "        return pg_handle_conception_muhurta(\n"
    "            female_chart=female_dict,\n"
    "            male_chart=male_dict,\n"
    "            location=location_dict,\n"
    "            start_date=c.start_date,\n"
    "            end_date=c.end_date,\n"
    "            max_days=c.max_days or 30,\n"
    "        )\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
    "\n"
    "\n"
    "@app.post(\"/astro/pregnancy/santana_yogas\", dependencies=[Depends(verify_key)])\n"
    "def pregnancy_santana_yogas(s: SantanaYogasInput):\n"
    "    \"\"\"\n"
    "    Couple's combined santana yoga analysis. Reads each partner's 5th\n"
    "    lord, Jupiter, Putrakaraka (Jaimini); surfaces supportive indicators\n"
    "    and caution flags (Putra Dosha, Ketu in 5th, 5th lord in dusthana).\n"
    "\n"
    "    Output complements /astro/children/5th_house_analysis (single-person)\n"
    "    by combining BOTH partners' charts.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        p1 = {\n"
    "            \"dob\":      s.person1.dob,\n"
    "            \"time\":     s.person1.time,\n"
    "            \"lat\":      s.person1.lat,\n"
    "            \"lon\":      s.person1.lon,\n"
    "            \"timezone\": s.person1.timezone,\n"
    "        }\n"
    "        p2 = {\n"
    "            \"dob\":      s.person2.dob,\n"
    "            \"time\":     s.person2.time,\n"
    "            \"lat\":      s.person2.lat,\n"
    "            \"lon\":      s.person2.lon,\n"
    "            \"timezone\": s.person2.timezone,\n"
    "        }\n"
    "        return pg_handle_santana_yogas(person1_chart=p1, person2_chart=p2)\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
    "\n"
    "\n"
    "@app.post(\"/astro/pregnancy/prenatal_remedies\", dependencies=[Depends(verify_key)])\n"
    "def pregnancy_prenatal_remedies(r: PrenatalRemediesInput):\n"
    "    \"\"\"\n"
    "    Month-by-month Garbha Sanskara remedies for gestational month 1-9.\n"
    "    Returns the classical practices for the specified month plus mother's\n"
    "    chart-specific personalization (Jupiter, Moon, 5th lord state).\n"
    "\n"
    "    Sources: Garbha Upanishad; Sushruta Sharira Sthana; Charaka Sharira.\n"
    "    Output: spiritual practice guidance, NEVER medical advice.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        mother = {\n"
    "            \"dob\":      r.mother_chart.dob,\n"
    "            \"time\":     r.mother_chart.time,\n"
    "            \"lat\":      r.mother_chart.lat,\n"
    "            \"lon\":      r.mother_chart.lon,\n"
    "            \"timezone\": r.mother_chart.timezone,\n"
    "        }\n"
    "        father = None\n"
    "        if r.father_chart is not None:\n"
    "            father = {\n"
    "                \"dob\":      r.father_chart.dob,\n"
    "                \"time\":     r.father_chart.time,\n"
    "                \"lat\":      r.father_chart.lat,\n"
    "                \"lon\":      r.father_chart.lon,\n"
    "                \"timezone\": r.father_chart.timezone,\n"
    "            }\n"
    "        return pg_handle_prenatal_remedies(\n"
    "            mother_chart=mother,\n"
    "            gestational_month=r.gestational_month,\n"
    "            father_chart=father,\n"
    "        )\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
    "\n"
    "\n"
    "@app.post(\"/astro/pregnancy/bala_arishta\", dependencies=[Depends(verify_key)])\n"
    "def pregnancy_bala_arishta(b: BalaArishtaInput):\n"
    "    \"\"\"\n"
    "    Classical Bala-Arishta yoga screen for a child's chart.\n"
    "\n"
    "    SENSITIVE: returns classical early-childhood-affliction yoga findings\n"
    "    framed as karmic patterns + shanti remedies. NOT medical/psychological\n"
    "    diagnosis. Sources: BPHS Ch. 8; Jataka Tatva; Saravali Ch. 7.\n"
    "\n"
    "    Response carries `sensitive_topic_disclaimer` field.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        child = {\n"
    "            \"dob\":      b.child_chart.dob,\n"
    "            \"time\":     b.child_chart.time,\n"
    "            \"lat\":      b.child_chart.lat,\n"
    "            \"lon\":      b.child_chart.lon,\n"
    "            \"timezone\": b.child_chart.timezone,\n"
    "        }\n"
    "        return pg_handle_bala_arishta(child_chart=child)\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
    "\n"
    "\n"
    "@app.post(\"/astro/pregnancy/newborn_naming_window\", dependencies=[Depends(verify_key)])\n"
    "def pregnancy_newborn_naming_window(n: NewbornNamingInput):\n"
    "    \"\"\"\n"
    "    Namakarana muhurta + classical akshara letters from Janma Nakshatra.\n"
    "\n"
    "    Returns the pada-specific akshara, all 4 nakshatra aksharas as\n"
    "    alternatives, classical 10th/11th/12th day naming candidates with\n"
    "    muhurta scoring, and family-priest selection guidance.\n"
    "\n"
    "    Sources: Muhurta Chintamani Ch. 6; BPHS Ch. 100.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        child = {\n"
    "            \"dob\":      n.child_chart.dob,\n"
    "            \"time\":     n.child_chart.time,\n"
    "            \"lat\":      n.child_chart.lat,\n"
    "            \"lon\":      n.child_chart.lon,\n"
    "            \"timezone\": n.child_chart.timezone,\n"
    "        }\n"
    "        loc = {\n"
    "            \"lat\":      n.naming_location.lat,\n"
    "            \"lon\":      n.naming_location.lon,\n"
    "            \"timezone\": n.naming_location.timezone,\n"
    "        }\n"
    "        return pg_handle_newborn_naming_window(\n"
    "            child_chart=child, naming_location=loc,\n"
    "        )\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
    "\n"
    "\n"
    "@app.post(\"/astro/pregnancy/garbha_shanti_remedies\", dependencies=[Depends(verify_key)])\n"
    "def pregnancy_garbha_shanti_remedies(g: GarbhaShantiInput):\n"
    "    \"\"\"\n"
    "    Garbha Shanti remedies for problematic pregnancies (recurrent\n"
    "    miscarriage, complications, classical Garbha-pida indicators).\n"
    "\n"
    "    SENSITIVE: classical SPIRITUAL practices only, never medical. Always\n"
    "    supplementary to prescribed medical care, never substitutive.\n"
    "    Sources: Brahma Vaivarta Purana; Garuda Purana; classical Garbha\n"
    "    Raksha texts; Vaishnava Santana Gopala tradition.\n"
    "\n"
    "    Response carries `sensitive_topic_disclaimer` field.\n"
    "    \"\"\"\n"
    "    try:\n"
    "        mother = {\n"
    "            \"dob\":      g.mother_chart.dob,\n"
    "            \"time\":     g.mother_chart.time,\n"
    "            \"lat\":      g.mother_chart.lat,\n"
    "            \"lon\":      g.mother_chart.lon,\n"
    "            \"timezone\": g.mother_chart.timezone,\n"
    "        }\n"
    "        father = None\n"
    "        if g.father_chart is not None:\n"
    "            father = {\n"
    "                \"dob\":      g.father_chart.dob,\n"
    "                \"time\":     g.father_chart.time,\n"
    "                \"lat\":      g.father_chart.lat,\n"
    "                \"lon\":      g.father_chart.lon,\n"
    "                \"timezone\": g.father_chart.timezone,\n"
    "            }\n"
    "        return pg_handle_garbha_shanti_remedies(\n"
    "            mother_chart=mother,\n"
    "            gestational_month=g.gestational_month,\n"
    "            father_chart=father,\n"
    "        )\n"
    "    except Exception as e:\n"
    "        raise HTTPException(status_code=400, detail=str(e))\n"
)


# ─── Phase logic ────────────────────────────────────────────────────────────

def log(msg: str) -> None:
    print(f"[patch_f5] {msg}", flush=True)


def fail(msg: str, code: int = 1) -> None:
    print(f"[patch_f5] FAIL: {msg}", file=sys.stderr, flush=True)
    sys.exit(code)


def run_as_trading_user(python_code: str) -> None:
    """
    Execute a Python snippet inside the trading user's environment, from /opt/astro.
    Required because dashaflow is in /home/trading/.local/lib/python3.12/site-packages,
    only accessible to the trading user. See HANDOVER_v6+v7 Section 3.13.
    """
    quoted_py = shlex.quote(python_code)
    shell_cmd = f"cd {shlex.quote(ASTRO_DIR)} && python3 -c {quoted_py}"
    subprocess.check_call(
        ["sudo", "-u", "trading", "bash", "-c", shell_cmd],
    )


def chown_to_trading(path: str) -> None:
    """Ensure path is owned by trading:trading."""
    try:
        subprocess.check_call(["chown", "trading:trading", path])
    except subprocess.CalledProcessError as e:
        log(f"WARNING: chown {path} failed: {e} (continuing, verify manually)")


def phase_a_preflight() -> str:
    """Precondition + anchor validation. File UNTOUCHED on any failure."""
    log("Phase A — precondition + anchor validation")

    # A.1 — Files exist
    if not os.path.isfile(MAIN_PY):
        fail(f"main.py not found at {MAIN_PY}")
    if not os.path.isfile(PREGNANCY_PY):
        fail(f"pregnancy.py not found at {PREGNANCY_PY} — upload it first")

    # A.2 — Read main.py
    with open(MAIN_PY, "r", encoding="utf-8") as f:
        content = f.read()

    # A.3 — Idempotency check
    if MARKER in content:
        log("Marker already present in main.py — patch is idempotent, exiting.")
        sys.exit(0)

    # A.4 — Anchor A1 (F4 import block close → END marker) must be present exactly once
    a1_count = content.count(ANCHOR_F4_IMPORT_BLOCK_CLOSE)
    if a1_count != 1:
        fail(f"Anchor A1 (F4 import block close) appears {a1_count} times; "
             f"expected exactly 1. main.py may have drifted from the byte-verified state.")

    # A.5 — Anchor A2 (ElectionEventInput → CompatibilityInput) must be present exactly once
    a2_count = content.count(ANCHOR_F4_INPUT_TO_COMPATIBILITY)
    if a2_count != 1:
        fail(f"Anchor A2 (ElectionEventInput → CompatibilityInput) appears "
             f"{a2_count} times; expected exactly 1.")

    # A.6 — pregnancy.py syntax check (as trading user, for path consistency)
    try:
        run_as_trading_user(
            "import ast; ast.parse(open('/opt/astro/pregnancy.py').read())"
        )
    except subprocess.CalledProcessError:
        fail("pregnancy.py failed syntax check")

    # A.7 — pregnancy.py imports cleanly + has all expected handlers
    log("Verifying pregnancy.py imports cleanly...")
    cmd = (
        "import pregnancy; "
        "assert hasattr(pregnancy, 'handle_conception_muhurta'); "
        "assert hasattr(pregnancy, 'handle_santana_yogas'); "
        "assert hasattr(pregnancy, 'handle_prenatal_remedies'); "
        "assert hasattr(pregnancy, 'handle_bala_arishta'); "
        "assert hasattr(pregnancy, 'handle_newborn_naming_window'); "
        "assert hasattr(pregnancy, 'handle_garbha_shanti_remedies'); "
        "assert hasattr(pregnancy, 'PCPNDT_NOTE'); "
        "assert hasattr(pregnancy, 'NAKSHATRA_AKSHARAS_F5'); "
        "assert len(pregnancy.NAKSHATRA_AKSHARAS_F5) == 27, 'nakshatra count must be 27'; "
        "assert len(pregnancy.PRENATAL_MONTH_REMEDIES) == 9, 'prenatal months must be 9'; "
        "print('pregnancy.py imports OK')"
    )
    try:
        run_as_trading_user(cmd)
    except subprocess.CalledProcessError:
        fail("pregnancy.py import test failed — fix module before re-running patch")

    log("Phase A — OK (file untouched)")
    return content


def phase_b_backup() -> None:
    log(f"Phase B — backing up main.py → {BACKUP_PATH}")
    shutil.copy2(MAIN_PY, BACKUP_PATH)
    if not os.path.isfile(BACKUP_PATH):
        fail("Backup creation failed")
    log("Phase B — OK")


def phase_c_imports(content: str) -> str:
    log("Phase C — inserting F5 import block")
    new_content = content.replace(ANCHOR_F4_IMPORT_BLOCK_CLOSE,
                                  NEW_F4_PLUS_F5_IMPORTS, 1)
    if new_content == content:
        fail("Phase C: anchor replacement made no change (UNEXPECTED — Phase A passed)")
    if new_content.count(MARKER) != 1:
        fail(f"Phase C: marker count after insert = {new_content.count(MARKER)} (expected 1)")
    log("Phase C — OK (in memory)")
    return new_content


def phase_d_models(content: str) -> str:
    log("Phase D — inserting F5 Pydantic input models")
    new_content = content.replace(ANCHOR_F4_INPUT_TO_COMPATIBILITY,
                                  NEW_F4_INPUT_PLUS_F5_PLUS_COMPAT, 1)
    if new_content == content:
        fail("Phase D: anchor replacement made no change")
    for cls in ("PregnancyLocationInput", "ConceptionMuhurtaInput",
                "SantanaYogasInput", "PrenatalRemediesInput",
                "BalaArishtaInput", "NewbornNamingInput", "GarbhaShantiInput"):
        if f"class {cls}(BaseModel)" not in new_content:
            fail(f"Phase D: {cls} not inserted")
    log("Phase D — OK (in memory)")
    return new_content


def phase_e_routes(content: str) -> str:
    log("Phase E — appending F5 routes to end of main.py")
    new_content = content + F5_ROUTES_APPEND
    for route in ("/astro/pregnancy/conception_muhurta",
                  "/astro/pregnancy/santana_yogas",
                  "/astro/pregnancy/prenatal_remedies",
                  "/astro/pregnancy/bala_arishta",
                  "/astro/pregnancy/newborn_naming_window",
                  "/astro/pregnancy/garbha_shanti_remedies"):
        if route not in new_content:
            fail(f"Phase E: route {route} not present after append")
    log("Phase E — OK (in memory)")
    return new_content


def phase_f_write_and_verify(new_content: str) -> None:
    log(f"Phase F — writing new main.py + snapshot → {SNAPSHOT_PATH}")
    with open(MAIN_PY, "w", encoding="utf-8") as f:
        f.write(new_content)
    shutil.copy2(MAIN_PY, SNAPSHOT_PATH)

    chown_to_trading(MAIN_PY)
    chown_to_trading(SNAPSHOT_PATH)
    chown_to_trading(BACKUP_PATH)
    log("Phase F — chown trading:trading applied to main.py + snapshot + backup")

    # F.1 — Syntax check
    log("Phase F.1 — syntax check on new main.py")
    try:
        run_as_trading_user(
            "import ast; ast.parse(open('/opt/astro/main.py').read())"
        )
    except subprocess.CalledProcessError:
        log("Syntax check FAILED — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        fail("Phase F.1: syntax error in new main.py — rolled back from backup")

    # F.2 — Layered smoke: import pregnancy + run handler assertions + import main
    log("Phase F.2 — layered smoke (import pregnancy → run handlers → import main)")
    smoke = (
        "import pregnancy; "
        # Module-shape assertions
        "assert hasattr(pregnancy, 'PCPNDT_NOTE'), 'PCPNDT_NOTE missing'; "
        "assert 'sex' in pregnancy.PCPNDT_NOTE.lower(), 'PCPNDT_NOTE missing sex reference'; "
        "assert len(pregnancy.PRENATAL_MONTH_REMEDIES) == 9, 'must have 9 months'; "
        "assert len(pregnancy.NAKSHATRA_AKSHARAS_F5) == 27, 'must have 27 nakshatras'; "
        # Conception muhurta — small 3-day scan
        "r1 = pregnancy.handle_conception_muhurta("
        "female_chart={'dob':'1990-01-01','time':'10:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}, "
        "male_chart={'dob':'1988-06-15','time':'14:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}, "
        "location={'lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}, "
        "start_date='2026-06-01', end_date='2026-06-03', max_days=3); "
        "assert 'error' not in r1, f'conception_muhurta errored: {r1.get(\"error\")}'; "
        "assert 'full_ranked_scan' in r1, 'full_ranked_scan missing'; "
        "assert len(r1['full_ranked_scan']) == 3, f'expected 3 days, got {len(r1[\"full_ranked_scan\"])}'; "
        "assert 'pcpndt_note' in r1, 'pcpndt_note missing'; "
        # Santana yogas — couple
        "r2 = pregnancy.handle_santana_yogas("
        "person1_chart={'dob':'1990-01-01','time':'10:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}, "
        "person2_chart={'dob':'1988-06-15','time':'14:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}); "
        "assert 'error' not in r2, f'santana_yogas errored: {r2.get(\"error\")}'; "
        "assert 'verdict' in r2 and 'pcpndt_note' in r2; "
        # Prenatal remedies — month 5
        "r3 = pregnancy.handle_prenatal_remedies("
        "mother_chart={'dob':'1990-01-01','time':'10:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}, "
        "gestational_month=5); "
        "assert 'error' not in r3, f'prenatal_remedies errored: {r3.get(\"error\")}'; "
        "assert r3['gestational_month'] == 5 and 'month_remedies' in r3; "
        # Prenatal remedies — invalid month
        "r3b = pregnancy.handle_prenatal_remedies("
        "mother_chart={'dob':'1990-01-01','time':'10:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}, "
        "gestational_month=10); "
        "assert 'error' in r3b, 'month 10 should error'; "
        # Bala arishta — uses a child's chart
        "r4 = pregnancy.handle_bala_arishta("
        "child_chart={'dob':'2020-03-15','time':'07:30','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}); "
        "assert 'error' not in r4, f'bala_arishta errored: {r4.get(\"error\")}'; "
        "assert 'sensitive_topic_disclaimer' in r4, 'sensitive disclaimer missing'; "
        "assert 'overall_verdict' in r4; "
        # Newborn naming
        "r5 = pregnancy.handle_newborn_naming_window("
        "child_chart={'dob':'2026-05-15','time':'09:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}, "
        "naming_location={'lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}); "
        "assert 'error' not in r5, f'naming_window errored: {r5.get(\"error\")}'; "
        "assert 'janma_nakshatra' in r5 and 'all_aksharas_for_nakshatra' in r5; "
        "assert len(r5['candidate_namakarana_days']) >= 1; "
        # Garbha shanti — no month
        "r6 = pregnancy.handle_garbha_shanti_remedies("
        "mother_chart={'dob':'1990-01-01','time':'10:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}); "
        "assert 'error' not in r6, f'garbha_shanti errored: {r6.get(\"error\")}'; "
        "assert 'core_classical_practices' in r6 and 'sensitive_topic_disclaimer' in r6; "
        # PCPNDT defense — gender field in input should be rejected at handler level
        "r_gender = pregnancy.handle_santana_yogas("
        "person1_chart={'dob':'1990-01-01','time':'10:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata','gender':'M'}, "
        "person2_chart={'dob':'1988-06-15','time':'14:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}); "
        "assert 'error' in r_gender, 'PCPNDT gender field should be rejected'; "
        "assert 'PCPNDT' in r_gender.get('pcpndt_note','').upper() or 'pcpndt' in r_gender.get('pcpndt_note','').lower(); "
        # PCPNDT defense — linga field
        "r_linga = pregnancy.handle_bala_arishta("
        "child_chart={'dob':'2020-03-15','time':'07:30','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata','linga':'male'}); "
        "assert 'error' in r_linga, 'PCPNDT linga field should be rejected'; "
        # PCPNDT defense — string value 'predict gender'
        "r_predict = pregnancy.handle_conception_muhurta("
        "female_chart={'dob':'1990-01-01','time':'10:00','lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata','note':'please predict gender'}, "
        "male_chart=None, location={'lat':28.6139,'lon':77.2090,'timezone':'Asia/Kolkata'}); "
        "assert 'error' in r_predict, 'PCPNDT predict-gender string should be rejected'; "
        # Disclaimer + pcpndt_note present on all 6 endpoints
        # (unrolled for python3 -c compatibility — see v2 header)
        "assert 'disclaimer' in r1, 'r1 disclaimer missing'; "
        "assert 'pcpndt_note' in r1, 'r1 pcpndt_note missing'; "
        "assert 'disclaimer' in r2, 'r2 disclaimer missing'; "
        "assert 'pcpndt_note' in r2, 'r2 pcpndt_note missing'; "
        "assert 'disclaimer' in r3, 'r3 disclaimer missing'; "
        "assert 'pcpndt_note' in r3, 'r3 pcpndt_note missing'; "
        "assert 'disclaimer' in r4, 'r4 disclaimer missing'; "
        "assert 'pcpndt_note' in r4, 'r4 pcpndt_note missing'; "
        "assert 'disclaimer' in r5, 'r5 disclaimer missing'; "
        "assert 'pcpndt_note' in r5, 'r5 pcpndt_note missing'; "
        "assert 'disclaimer' in r6, 'r6 disclaimer missing'; "
        "assert 'pcpndt_note' in r6, 'r6 pcpndt_note missing'; "
        # NOW import main.py — the critical layered test (per Section 3.5)
        "import main; "
        "print('Smoke: all 22 assertions PASSED, main.py imports OK')"
    )
    try:
        run_as_trading_user(smoke)
    except subprocess.CalledProcessError:
        log("Smoke test FAILED — auto-rollback")
        shutil.copy2(BACKUP_PATH, MAIN_PY)
        chown_to_trading(MAIN_PY)
        fail("Phase F.2: smoke test failed — rolled back from backup")

    log("Phase F — OK (changes committed, snapshot saved)")


def main() -> None:
    print("=" * 72)
    print("patch_f5_pregnancy_v2.py — F5 Pregnancy Astrology installer")
    print(f"Timestamp: {TIMESTAMP}")
    print(f"Backup will go to:   {BACKUP_PATH}")
    print(f"Snapshot will go to: {SNAPSHOT_PATH}")
    print("PCPNDT compliance: Garbha Linga Nirnaya deliberately omitted")
    print("=" * 72)

    content = phase_a_preflight()
    phase_b_backup()
    new_content = phase_c_imports(content)
    new_content = phase_d_models(new_content)
    new_content = phase_e_routes(new_content)
    phase_f_write_and_verify(new_content)

    print("=" * 72)
    print("F5 patch installation: SUCCESS")
    print("Next step: sudo systemctl restart astro && sleep 3")
    print("Then: curl -s -o /dev/null -w 'HTTP %{http_code}\\n' http://localhost:8001/astro/health")
    print("And:  curl -s http://localhost:8001/openapi.json | python3 -c "
          "\"import json,sys; print('Total paths:', len(json.load(sys.stdin)['paths']))\"")
    print("Expected: HTTP 200, Total paths: 314 (was 308, +6)")
    print("=" * 72)


if __name__ == "__main__":
    main()
