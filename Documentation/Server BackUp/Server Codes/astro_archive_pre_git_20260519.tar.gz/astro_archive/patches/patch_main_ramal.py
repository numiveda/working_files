"""
patch_main_ramal.py — Wires 11 Ramal (E1) endpoints into main.py.

Run from /opt/astro:
    sudo python3 patch_main_ramal.py
"""

import re
import sys
import os
import shutil
from datetime import datetime

MAIN_PY = "/opt/astro/main.py"
BACKUP_DIR = "/opt/astro"
MARKER = "# ── RAMAL E1 MODULE ──"


IMPORT_BLOCK = '''
# ── RAMAL E1 MODULE IMPORTS ──
from ramal import (
    handle_profile           as ramal_handle_profile,
    handle_cast_chart        as ramal_handle_cast_chart,
    handle_cast_from_throws  as ramal_handle_cast_from_throws,
    handle_figure_from_throw as ramal_handle_figure_from_throw,
    handle_figure_lookup     as ramal_handle_figure_lookup,
    handle_figures_catalog   as ramal_handle_figures_catalog,
    handle_house_domains     as ramal_handle_house_domains,
    handle_hope_formula      as ramal_handle_hope_formula,
    handle_check_theft       as ramal_handle_check_theft,
    handle_check_captivity   as ramal_handle_check_captivity,
    handle_dot_count         as ramal_handle_dot_count,
    handle_question_reading  as ramal_handle_question_reading,
)
# ── END RAMAL E1 IMPORTS ──

'''


ENDPOINT_BLOCK = '''
# ════════════════════════════════════════════════════════════════════════
# ── RAMAL E1 MODULE ──
# Phase E — Module E1 — Ramal Shastra divination (11 endpoints)
# Source: Classical Indian Ramal (Zaycha system) — distinct from Western Geomancy
# Port of myRamal repo (numiveda/myRamal) — pure computational engine
# ════════════════════════════════════════════════════════════════════════

from pydantic import BaseModel as _RamalBaseModel
from typing import Optional as _RamalOptional, List as _RamalList


class RamalThrowInput(_RamalBaseModel):
    throw_values: _RamalList[int]  # 4 integers


class RamalMotherKeysInput(_RamalBaseModel):
    mother_keys: _RamalList[str]  # 4 row-pattern keys


class RamalThrowsInput(_RamalBaseModel):
    throws: _RamalList[_RamalList[int]]  # 4 throws × 4 integers each


class RamalFigureLookupInput(_RamalBaseModel):
    key: _RamalOptional[str] = None
    number: _RamalOptional[int] = None


class RamalQuestionInput(_RamalBaseModel):
    throws: _RamalList[_RamalList[int]]  # 4 throws × 4 integers
    question: str
    domain: _RamalOptional[str] = "other"
    first_name: _RamalOptional[str] = "Querent"


@app.post("/astro/ramal/profile")
def ramal_profile_ep(inp: RamalThrowsInput, _: str = Depends(verify_key)):
    """Master Ramal profile — 15-house chart + all 4 classical special rules applied."""
    return ramal_handle_profile(inp.throws)


@app.post("/astro/ramal/cast_chart")
def ramal_cast_chart_ep(inp: RamalMotherKeysInput, _: str = Depends(verify_key)):
    """4 Mother keys (e.g. 'odd-even-even-odd') → complete 15-house chart."""
    return ramal_handle_cast_chart(inp.mother_keys)


@app.post("/astro/ramal/cast_from_throws")
def ramal_cast_from_throws_ep(inp: RamalThrowsInput, _: str = Depends(verify_key)):
    """4 throws × 4 row values each → 4 Mothers → 15-house chart."""
    return ramal_handle_cast_from_throws(inp.throws)


@app.post("/astro/ramal/figure_from_throw")
def ramal_figure_from_throw_ep(inp: RamalThrowInput, _: str = Depends(verify_key)):
    """Single throw of 4 row values → 1 figure with attributes."""
    return ramal_handle_figure_from_throw(inp.throw_values)


@app.post("/astro/ramal/figure_lookup")
def ramal_figure_lookup_ep(inp: RamalFigureLookupInput, _: str = Depends(verify_key)):
    """Look up a figure by row-pattern key OR by classical number 1-16."""
    return ramal_handle_figure_lookup(key=inp.key, number=inp.number)


@app.post("/astro/ramal/figures_catalog")
def ramal_figures_catalog_ep(_: str = Depends(verify_key)):
    """Return all 16 figures + categories + natures."""
    return ramal_handle_figures_catalog()


@app.post("/astro/ramal/house_domains")
def ramal_house_domains_ep(_: str = Depends(verify_key)):
    """Return all 15 house meanings + domain→house mapping."""
    return ramal_handle_house_domains()


@app.post("/astro/ramal/hope_formula")
def ramal_hope_formula_ep(inp: RamalMotherKeysInput, _: str = Depends(verify_key)):
    """Triple Prastara for H11 hopes-domain."""
    return ramal_handle_hope_formula(inp.mother_keys)


@app.post("/astro/ramal/check_theft")
def ramal_check_theft_ep(inp: RamalMotherKeysInput, _: str = Depends(verify_key)):
    """Scan for theft indicators."""
    return ramal_handle_check_theft(inp.mother_keys)


@app.post("/astro/ramal/check_captivity")
def ramal_check_captivity_ep(inp: RamalMotherKeysInput, _: str = Depends(verify_key)):
    """Check H12/H15 captivity exception."""
    return ramal_handle_check_captivity(inp.mother_keys)


@app.post("/astro/ramal/dot_count")
def ramal_dot_count_ep(inp: RamalMotherKeysInput, _: str = Depends(verify_key)):
    """Bindu count → life/death verdict."""
    return ramal_handle_dot_count(inp.mother_keys)


@app.post("/astro/ramal/question_reading")
def ramal_question_reading_ep(inp: RamalQuestionInput, _: str = Depends(verify_key)):
    """Question-focused master: cast chart + apply domain rule + AI prompt context."""
    return ramal_handle_question_reading(
        throws=inp.throws,
        question=inp.question,
        domain=inp.domain or "other",
        first_name=inp.first_name or "Querent",
    )

# ── END RAMAL E1 MODULE ──
'''


def main():
    if not os.path.exists(MAIN_PY):
        print(f"ERROR: {MAIN_PY} not found")
        sys.exit(1)

    with open(MAIN_PY, "r") as f:
        content = f.read()

    if MARKER in content:
        print(f"SKIP: {MARKER} already present.")
        sys.exit(0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{BACKUP_DIR}/main.py.before_ramal_e1_{ts}"
    shutil.copyfile(MAIN_PY, backup_path)
    print(f"Backup written: {backup_path}")

    app_init_pattern = re.compile(r'^app\s*=\s*FastAPI\s*\(', re.MULTILINE)
    match = app_init_pattern.search(content)
    if not match:
        print("ERROR: Could not find 'app = FastAPI(' anchor")
        sys.exit(2)
    insertion_point = match.start()

    new_content = content[:insertion_point] + IMPORT_BLOCK + content[insertion_point:]
    new_content = new_content.rstrip() + "\n\n" + ENDPOINT_BLOCK + "\n"

    with open(MAIN_PY, "w") as f:
        f.write(new_content)

    after_path = f"{BACKUP_DIR}/main.py.after_ramal_e1_{ts}"
    shutil.copyfile(MAIN_PY, after_path)
    print(f"After snapshot: {after_path}")

    print("✅ Ramal E1 module patched into main.py")
    print("   11 new endpoints under /astro/ramal/* — engine reaches 272 endpoints")


if __name__ == "__main__":
    main()
