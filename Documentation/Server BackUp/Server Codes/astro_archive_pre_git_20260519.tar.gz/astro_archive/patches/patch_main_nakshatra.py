#!/usr/bin/env python3
"""
patch_main_nakshatra.py — Auto-patches /opt/astro/main.py with nakshatra blocks.

Behaviour:
  - Reads /opt/astro/main.py
  - Creates timestamped backup
  - Adds BLOCK_A imports (skips if already present)
  - Adds BLOCK_B models (skips if already present)
  - Adds BLOCK_C endpoints (skips if already present)
  - Syntax-validates result with ast.parse()
  - Rolls back on syntax error
"""
import ast
import os
import re
import shutil
import sys
from datetime import datetime
from main_patches_nakshatra import (
    BLOCK_A_IMPORTS,
    BLOCK_B_MODELS,
    BLOCK_C_ENDPOINTS,
)

MAIN_PATH = "/opt/astro/main.py"


def patch():
    if not os.path.exists(MAIN_PATH):
        print(f"❌ {MAIN_PATH} not found")
        sys.exit(1)

    # Backup
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = f"{MAIN_PATH}.backup_{ts}"
    shutil.copy2(MAIN_PATH, backup)
    print(f"✓ Backup created: {backup}")

    with open(MAIN_PATH, "r", encoding="utf-8") as f:
        content = f.read()

    original = content
    changes_made = []

    # ─── BLOCK A: imports ───────────────────────────────────────────────────
    if "BEGIN NAKSHATRA IMPORTS" in content:
        print("⊙ BLOCK A (imports): already present, skipping")
    else:
        # Insert after the last "from ... import ..." or "import ..." line in
        # the top region (first 100 lines)
        lines = content.split("\n")
        last_import = 0
        for i, line in enumerate(lines[:100]):
            if line.strip().startswith(("import ", "from ")) and not line.strip().startswith("#"):
                last_import = i
        # Insert after that line
        lines.insert(last_import + 1, BLOCK_A_IMPORTS.strip())
        content = "\n".join(lines)
        changes_made.append("BLOCK A (imports)")
        print("✓ BLOCK A (imports) added")

    # ─── BLOCK B: Pydantic models ──────────────────────────────────────────
    if "BEGIN NAKSHATRA MODELS" in content:
        print("⊙ BLOCK B (models): already present, skipping")
    else:
        # Find the last "class XxxInput(BaseModel):" block and insert after it
        # We look for the end of the last Pydantic class
        pattern = re.compile(
            r"class\s+\w+\s*\(\s*BaseModel\s*\)\s*:.*?(?=\n(?:class|\n@app|\ndef|\nasync def|\n@router|\Z))",
            re.DOTALL,
        )
        matches = list(pattern.finditer(content))
        if matches:
            last_match = matches[-1]
            insert_pos = last_match.end()
            content = content[:insert_pos] + "\n\n" + BLOCK_B_MODELS.strip() + "\n" + content[insert_pos:]
            changes_made.append("BLOCK B (models)")
            print("✓ BLOCK B (models) added")
        else:
            # Fallback: insert before the first @app route
            app_match = re.search(r"\n@app\.", content)
            if app_match:
                pos = app_match.start()
                content = content[:pos] + "\n\n" + BLOCK_B_MODELS.strip() + "\n\n" + content[pos:]
                changes_made.append("BLOCK B (models, fallback location)")
                print("✓ BLOCK B (models) added (fallback location)")
            else:
                print("❌ Cannot locate insertion point for BLOCK B")
                shutil.copy2(backup, MAIN_PATH)
                sys.exit(1)

    # ─── BLOCK C: endpoints ────────────────────────────────────────────────
    if "BEGIN NAKSHATRA ENDPOINTS" in content:
        print("⊙ BLOCK C (endpoints): already present, skipping")
    else:
        # Insert before "@app.on_event" if present, else at end of file
        on_event_match = re.search(r"\n@app\.on_event\(", content)
        if on_event_match:
            pos = on_event_match.start()
            content = content[:pos] + "\n\n" + BLOCK_C_ENDPOINTS.strip() + "\n\n" + content[pos:]
            print("✓ BLOCK C (endpoints) added before @app.on_event")
        else:
            # Try to insert before "if __name__" or just append
            main_block = re.search(r"\nif\s+__name__\s*==\s*[\"']__main__[\"']", content)
            if main_block:
                pos = main_block.start()
                content = content[:pos] + "\n\n" + BLOCK_C_ENDPOINTS.strip() + "\n\n" + content[pos:]
                print("✓ BLOCK C (endpoints) added before __main__ block")
            else:
                content = content.rstrip() + "\n\n" + BLOCK_C_ENDPOINTS.strip() + "\n"
                print("✓ BLOCK C (endpoints) appended at end of file")
        changes_made.append("BLOCK C (endpoints)")

    # ─── Validate syntax ────────────────────────────────────────────────────
    try:
        ast.parse(content)
    except SyntaxError as e:
        print(f"❌ Syntax error after patching: {e}")
        print(f"   Rolling back from {backup}")
        shutil.copy2(backup, MAIN_PATH)
        sys.exit(1)

    # ─── Write ───────────────────────────────────────────────────────────────
    if content == original:
        print("⊙ No changes needed — main.py already patched")
        return

    with open(MAIN_PATH, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"✓ main.py patched successfully")
    print(f"  Changes: {', '.join(changes_made)}")
    print(f"  Backup retained: {backup}")


if __name__ == "__main__":
    patch()
