"""
remedies_esoteric.py — Esoteric Remedies Engine (refactored)

REFACTOR CHANGES:
- Imports extract_chart_essentials, get_chart, afflicted_planets, weakest_planet,
  compute_house_lords from astro_helpers
- All output structures IDENTICAL to v1 — zero behavior change

Sub-systems:
- Solomonic / Western Hermetic (5 endpoints)
- Atharva Vedic (5 endpoints)
- Tantric Shakta (5 endpoints)
- Vigyan Bhairava Tantra (5 endpoints)
- Kabbalistic / Hermetic Qabalah (4 endpoints)
- Egyptian / Hellenistic (3 endpoints)
Total: 27 endpoints
"""

import json
import os
from typing import Dict, List, Optional, Any
from datetime import datetime

from astro_helpers import (
    extract_chart_essentials as _extract_chart,
    get_chart as _get_chart,
    afflicted_planets as _afflicted_planets,
    weakest_planet as _weakest_planet,
)


# ════════════════════════════════════════════════════════════════════════
# JSON LOADERS
# ════════════════════════════════════════════════════════════════════════

ESOTERIC_DIR = "/opt/astro/remedies_esoteric"

def _load(filename: str) -> Dict:
    path = os.path.join(ESOTERIC_DIR, filename)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

try:
    SOLOMONIC          = _load("remedies_solomonic.json")
    ATHARVA            = _load("remedies_atharva_vedic.json")
    TANTRIC            = _load("remedies_tantric.json")
    VBT                = _load("remedies_vbt.json")
    KABBALISTIC        = _load("remedies_kabbalistic.json")
    EGYPTIAN_HELLENIC  = _load("remedies_egyptian_hellenistic.json")
except Exception as e:
    raise RuntimeError(f"Failed to load esoteric catalogs from {ESOTERIC_DIR}: {e}")


# ════════════════════════════════════════════════════════════════════════
# SOLOMONIC ENDPOINTS (5)
# ════════════════════════════════════════════════════════════════════════

def planetary_hours_info(weekday: Optional[str] = None) -> Dict:
    out = {
        "system":          "Chaldean planetary hour system",
        "day_rulers":      SOLOMONIC["planetary_hours"]["day_rulers"],
        "hour_sequence":   SOLOMONIC["planetary_hours"]["hour_sequence_chaldean"],
        "first_hour_rule": SOLOMONIC["planetary_hours"]["first_hour_rule"],
        "calculation":     SOLOMONIC["planetary_hours"]["calculation"],
        "best_uses":       SOLOMONIC["planetary_hours"]["best_uses"],
        "classical_source":"Agrippa, Three Books of Occult Philosophy",
    }
    if weekday and weekday in SOLOMONIC["planetary_hours"]["day_rulers"]:
        out["today_ruler"] = SOLOMONIC["planetary_hours"]["day_rulers"][weekday]
    return out


def goetia_reference(planet: Optional[str] = None) -> Dict:
    return {
        "_disclaimer":      SOLOMONIC["goetia_72_spirits_reference"]["_disclaimer"],
        "first_18_listed":  SOLOMONIC["goetia_72_spirits_reference"]["first_18_kings_and_dukes"],
        "summary_by_planet":SOLOMONIC["goetia_72_spirits_reference"]["summary_by_planet"],
        "filtered_by_planet": [s for s in SOLOMONIC["goetia_72_spirits_reference"]["first_18_kings_and_dukes"]
                               if planet and s.get("planetary","").lower() == planet.lower()] if planet else None,
        "academic_note":    SOLOMONIC["goetia_72_spirits_reference"]["academic_note"],
        "classical_source": "Lemegeton Clavicula Salomonis (1641, public domain)",
    }


def planetary_squares() -> Dict:
    return {
        "squares":          SOLOMONIC["planetary_squares_kameas"]["squares"],
        "classical_source": SOLOMONIC["planetary_squares_kameas"]["_description"] + " — Agrippa 1533",
    }


def olympic_spirits() -> Dict:
    return {
        "olympic_spirits":  SOLOMONIC["olympic_spirits"]["spirits"],
        "use":              SOLOMONIC["olympic_spirits"]["use_classical"],
        "classical_source": SOLOMONIC["olympic_spirits"]["source"],
    }


def talismans_summary() -> Dict:
    return {
        "by_planet":        SOLOMONIC["planetary_talismans"]["by_planet"],
        "framing":          SOLOMONIC["planetary_talismans"]["framing"],
        "classical_source": "Agrippa + Picatrix tradition",
    }


# ════════════════════════════════════════════════════════════════════════
# ATHARVA VEDIC ENDPOINTS (5)
# ════════════════════════════════════════════════════════════════════════

def atharva_suktas_by_purpose(purpose: str) -> Dict:
    purpose = purpose.lower().replace(" ","_").replace("-","_")
    categories = {
        "healing":       ATHARVA["healing_hymns_bhaishajya"],
        "protection":    ATHARVA["protection_hymns_raksha"],
        "peace":         ATHARVA["peace_invocations_shanti"],
        "prosperity":    ATHARVA["prosperity_hymns_lakshmi"],
        "nullification": ATHARVA["abhichar_nullification"],
    }
    if purpose in categories:
        return {
            "purpose":          purpose,
            "hymns":            categories[purpose],
            "classical_source": "Atharva Veda Samhita (~1200 BCE, public domain)",
        }
    return {"error": "Unknown purpose", "available_purposes": list(categories.keys())}


def atharva_healing_hymns() -> Dict:
    return {
        "hymns":            ATHARVA["healing_hymns_bhaishajya"],
        "general_rules":    ATHARVA["general_practice_rules"],
        "classical_source": "Atharva Veda Bhaishajya section",
    }


def atharva_protection_hymns() -> Dict:
    return {
        "hymns":            ATHARVA["protection_hymns_raksha"],
        "general_rules":    ATHARVA["general_practice_rules"],
        "classical_source": "Atharva Veda Raksha section",
    }


def atharva_abhichar_nullifier() -> Dict:
    return {
        "disclaimer":       ATHARVA["abhichar_nullification"]["_disclaimer"],
        "defensive_hymns":  {k:v for k,v in ATHARVA["abhichar_nullification"].items() if not k.startswith("_")},
        "general_rules":    ATHARVA["general_practice_rules"],
        "classical_source": "Atharva Veda — DEFENSIVE hymns only",
    }


def atharva_peace_invocations() -> Dict:
    return {
        "hymns":            ATHARVA["peace_invocations_shanti"],
        "general_rules":    ATHARVA["general_practice_rules"],
        "classical_source": "Atharva Veda Shanti section",
    }


# ════════════════════════════════════════════════════════════════════════
# TANTRIC ENDPOINTS (5)
# ════════════════════════════════════════════════════════════════════════

def personal_mahavidya(dob: str, time: str, lat: float, lon: float, timezone="Asia/Kolkata") -> Dict:
    chart = _extract_chart(_get_chart(dob, time, lat, lon, timezone))
    weakest = _weakest_planet(chart)
    ak = chart["atmakaraka"]

    planet_to_mahavidya = {
        "Sun":     "Tripura_Sundari",
        "Moon":    "Bhuvaneshwari",
        "Mars":    "Bhairavi",
        "Mercury": "Matangi",
        "Jupiter": "Bagalamukhi",
        "Venus":   "Tripura_Sundari",
        "Saturn":  "Kali",
        "Rahu":    "Chinnamasta",
        "Ketu":    "Dhumavati",
    }

    by_weakest = None
    if weakest:
        key = planet_to_mahavidya.get(weakest)
        if key and key in TANTRIC["dasha_mahavidya"]["goddesses"]:
            by_weakest = {
                "planet": weakest,
                "mahavidya": key,
                "details": TANTRIC["dasha_mahavidya"]["goddesses"][key],
            }

    by_ak = None
    if ak:
        key = planet_to_mahavidya.get(ak)
        if key and key in TANTRIC["dasha_mahavidya"]["goddesses"]:
            by_ak = {
                "planet": ak,
                "mahavidya": key,
                "details": TANTRIC["dasha_mahavidya"]["goddesses"][key],
            }

    return {
        "for_weakest_planet": by_weakest,
        "for_atmakaraka":     by_ak,
        "all_mahavidyas":     TANTRIC["dasha_mahavidya"]["goddesses"],
        "practice_rules":     TANTRIC["general_practice_rules"],
        "classical_source":   "Shakta tradition: Dasha Mahavidya",
    }


def kavachas_catalog() -> Dict:
    return {
        "kavachas":         TANTRIC["kavachas"]["list"],
        "general_rules":    TANTRIC["general_practice_rules"],
        "classical_source": "Classical Stotra Samhitas",
    }


def devi_for_purpose(purpose: str) -> Dict:
    p = purpose.lower().replace(" ","_").replace("-","_")
    if p in TANTRIC["devi_by_purpose"]:
        return {
            "purpose":           p,
            "recommended_devis": TANTRIC["devi_by_purpose"][p],
            "classical_source":  "Devi Mahatmyam + Shakta Tantric tradition",
        }
    return {"error": "Unknown purpose", "available": list(TANTRIC["devi_by_purpose"].keys())}


def dasha_mahavidya_full() -> Dict:
    return {
        "ten_goddesses":    TANTRIC["dasha_mahavidya"]["goddesses"],
        "practice_rules":   TANTRIC["general_practice_rules"],
        "classical_source": "Shakta Pramoda, Devi Mahatmyam",
    }


def navadurga_correspondence() -> Dict:
    return {
        "nine_forms":       TANTRIC["navadurga"]["forms"],
        "classical_source": TANTRIC["navadurga"]["source"],
    }


# ════════════════════════════════════════════════════════════════════════
# VIGYAN BHAIRAVA TANTRA ENDPOINTS (5)
# ════════════════════════════════════════════════════════════════════════

def vbt_dharana_for_chart(dob: str, time: str, lat: float, lon: float, timezone="Asia/Kolkata") -> Dict:
    chart = _extract_chart(_get_chart(dob, time, lat, lon, timezone))
    weakest = _weakest_planet(chart)
    key = f"{weakest}_afflicted" if weakest else None

    if key and key in VBT["matching_dharanas_to_afflictions"]:
        match = VBT["matching_dharanas_to_afflictions"][key]
        recommended_dharanas = []
        for d_name in match["recommended"]:
            if d_name in VBT["sample_dharanas"]:
                recommended_dharanas.append({"name": d_name, "details": VBT["sample_dharanas"][d_name]})
            else:
                recommended_dharanas.append({"name": d_name, "details": "see classical text"})
        return {
            "weakest_planet":           weakest,
            "purpose":                  match["purpose"],
            "recommended_dharanas":     recommended_dharanas,
            "practice_rules":           VBT["general_practice_rules"],
            "classical_source":         "Vigyan Bhairava Tantra (~9th c. CE)",
        }
    return {"info": "No specific dharana mapping — practice any from sample_dharanas as starting point",
            "samples": VBT["sample_dharanas"]}


def vbt_breath_techniques() -> Dict:
    breath = {k:v for k,v in VBT["sample_dharanas"].items() if v.get("category") == "breath_techniques"}
    return {
        "breath_dharanas":  breath,
        "category_info":    VBT["categorization"]["categories"]["breath_techniques"],
        "practice_rules":   VBT["general_practice_rules"],
        "classical_source": "Vigyan Bhairava Tantra — verses 24-31, 49-50",
    }


def vbt_awareness_techniques() -> Dict:
    awareness = {k:v for k,v in VBT["sample_dharanas"].items() if v.get("category") == "awareness_techniques"}
    return {
        "awareness_dharanas":awareness,
        "category_info":    VBT["categorization"]["categories"]["awareness_techniques"],
        "practice_rules":   VBT["general_practice_rules"],
        "classical_source": "Vigyan Bhairava Tantra — verses 38-47",
    }


def vbt_all_112() -> Dict:
    return {
        "categorization":   VBT["categorization"],
        "sample_dharanas":  VBT["sample_dharanas"],
        "matching_to_afflictions": VBT["matching_dharanas_to_afflictions"],
        "practice_rules":   VBT["general_practice_rules"],
        "full_set_note":    VBT["full_set_note"],
        "classical_source": "Vigyan Bhairava Tantra (full text in classical commentaries)",
    }


def vbt_devotional_practices() -> Dict:
    devotional = {k:v for k,v in VBT["sample_dharanas"].items() if v.get("category") == "devotional_techniques"}
    return {
        "devotional_dharanas":devotional,
        "category_info":      VBT["categorization"]["categories"]["devotional_techniques"],
        "practice_rules":     VBT["general_practice_rules"],
        "classical_source":   "Vigyan Bhairava Tantra — verses 100-115",
    }


# ════════════════════════════════════════════════════════════════════════
# KABBALISTIC ENDPOINTS (4)
# ════════════════════════════════════════════════════════════════════════

def tree_of_life() -> Dict:
    return {
        "sephiroth":        KABBALISTIC["tree_of_life_sephiroth"]["sephiroth_list"],
        "22_paths_summary": KABBALISTIC["22_paths"],
        "classical_source": "Sefer Yetzirah, Sefer ha-Zohar, Agrippa, Hermetic tradition",
    }


def sephirot_for_chart(dob: str, time: str, lat: float, lon: float, timezone="Asia/Kolkata") -> Dict:
    chart = _extract_chart(_get_chart(dob, time, lat, lon, timezone))
    lagna_lord = chart["lagna_lord"]
    md = chart["current_md"]
    ak = chart["atmakaraka"]

    p_to_seph = {}
    for sep in KABBALISTIC["tree_of_life_sephiroth"]["sephiroth_list"]:
        p_to_seph[sep["planetary"]] = sep

    primary = p_to_seph.get(lagna_lord) if lagna_lord else None
    current = p_to_seph.get(md) if md else None
    ak_sep = p_to_seph.get(ak) if ak else None

    return {
        "lagna":                chart["lagna_sign"],
        "lagna_lord_sephirah":  primary,
        "current_md_sephirah":  current,
        "atmakaraka_sephirah":  ak_sep,
        "personal_chart_rules": KABBALISTIC["personal_chart_correspondence"]["rules"],
        "classical_source":     "Hermetic Qabalah personal mapping",
    }


def kabbalistic_paths() -> Dict:
    return {
        "paths_summary":    KABBALISTIC["22_paths"],
        "planetary_paths":  KABBALISTIC["22_paths"]["planetary_paths"],
        "classical_source": "Sefer Yetzirah + Hermetic Qabalah Golden Dawn tradition",
    }


def divine_names_planetary() -> Dict:
    return {
        "by_planet":        KABBALISTIC["divine_names_planetary"]["by_planet"],
        "archangels":       KABBALISTIC["planetary_archangels"]["by_planet"],
        "archangel_note":   KABBALISTIC["planetary_archangels"]["note"],
        "general_rules":    KABBALISTIC["general_practice_rules"],
        "classical_source": "Agrippa, Sefer ha-Zohar",
    }


# ════════════════════════════════════════════════════════════════════════
# EGYPTIAN / HELLENISTIC ENDPOINTS (3)
# ════════════════════════════════════════════════════════════════════════

def decan_ruler(dob: str, time: str, lat: float, lon: float, timezone="Asia/Kolkata") -> Dict:
    chart = _extract_chart(_get_chart(dob, time, lat, lon, timezone))
    lagna_sign = chart["lagna_sign"]

    decans_table = EGYPTIAN_HELLENIC["36_decans"]["table"]
    lagna_decans = decans_table.get(lagna_sign, []) if lagna_sign else []

    return {
        "lagna_sign":      lagna_sign,
        "decans_of_lagna_sign": lagna_decans,
        "all_36_decans":   decans_table,
        "interpretation":  EGYPTIAN_HELLENIC["36_decans"]["interpretation_use"],
        "comparison":      EGYPTIAN_HELLENIC["36_decans"]["comparison_note"],
        "classical_source":"Egyptian decan tradition + Hellenistic Chaldean rulership",
    }


def hellenistic_time_lord(dob: str, time: str, lat: float, lon: float, timezone="Asia/Kolkata") -> Dict:
    chart = _extract_chart(_get_chart(dob, time, lat, lon, timezone))

    current_year = datetime.now().year
    parts = dob.split("-")
    birth_year = int(parts[0])
    age = current_year - birth_year
    profected_house = (age % 12) + 1
    profected_lord = chart["house_lords"].get(profected_house)

    return {
        "current_age":         age,
        "profected_house":     profected_house,
        "profected_house_lord":profected_lord,
        "year_themes":         f"Year ruled by house {profected_house} significations through lord {profected_lord}",
        "systems_available":   EGYPTIAN_HELLENIC["hellenistic_time_lord_technique"]["systems"],
        "profections_full_table": EGYPTIAN_HELLENIC["hellenistic_time_lord_technique"]["profections_quick_rule"],
        "classical_source":    "Vettius Valens, Hellenistic profections tradition",
    }


def planetary_deities_cross_tradition() -> Dict:
    return {
        "cross_tradition_table": EGYPTIAN_HELLENIC["planetary_deities_cross_tradition"]["table"],
        "egyptian_specific":     EGYPTIAN_HELLENIC["egyptian_planetary_deities"]["by_planet"],
        "classical_source":      "Comparative classical traditions",
    }
